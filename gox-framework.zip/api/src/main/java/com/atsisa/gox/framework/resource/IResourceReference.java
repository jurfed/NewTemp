package com.atsisa.gox.framework.resource;

/**
 * Represents a reference to a resource.
 */
public interface IResourceReference {

    /**
     * Gets the fully qualified resource identifier.
     * @return the fully qualified resource identifier.
     */
    String getId();

    /**
     * Gets the resource type.
     * @return ResourceType type of the resource.
     */
    ResourceType getResourceType();
}
