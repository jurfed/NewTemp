package com.atsisa.gox.framework.utility.logger;

/**
 * An abstraction layers on logging API.
 */
public interface ILogger {

    /**
     * Gets current logger level.
     * @return logger level
     */
    LogLevel getLevel();

    /**
     * Sets the current logger logLevel.
     * @param logLevel logger logLevel
     */
    void setLevel(LogLevel logLevel);

    /**
     * Logs a debug message.
     * @param msg the message to display
     */
    void debug(String msg);

    /**
     * Logs a debug message.
     * @param msg  the message to display
     * @param args objects referenced from msg
     */
    void debug(String msg, Object... args);

    /**
     * Logs a debug message.
     * @param msg the message to display
     * @param e   the exception to logger
     */
    void debug(String msg, Throwable e);

    /**
     * Logs an informational message.
     * @param msg the message to display
     */
    void info(String msg);

    /**
     * Logs an info message.
     * @param msg the message to display
     * @param e   the exception to logger
     */
    void info(String msg, Throwable e);

    /**
     * Logs an info message.
     * @param msg  the message to display
     * @param args objects referenced from msg
     */
    void info(String msg, Object... args);

    /**
     * Logs a warning message.
     * @param msg the message to display
     */
    void warn(String msg);

    /**
     * Logs a warning message.
     * @param msg the message to display
     * @param e   the exception to logger
     */
    void warn(String msg, Throwable e);

    /**
     * Logs a warning message.
     * @param msg  the message to display
     * @param args objects referenced from msg
     */
    void warn(String msg, Object... args);

    /**
     * Logs an error message.
     * @param msg the message to display
     */
    void error(String msg);

    /**
     * Logs an error message.
     * @param msg the message to display
     * @param e   the exception to logger
     */
    void error(String msg, Throwable e);

    /**
     * Logs an error message.
     * @param msg  the message to display
     * @param args objects referenced from msg
     */
    void error(String msg, Object... args);

    /**
     * Logs a trace message.
     * @param msg the message to display
     */
    void trace(String msg);

    /**
     * Logs a trace message.
     * @param msg the message to display
     * @param e   the exception to logger
     */
    void trace(String msg, Throwable e);

    /**
     * Logs a trace message.
     * @param msg  the message to display
     * @param args objects referenced from msg
     */
    void trace(String msg, Object... args);
}
