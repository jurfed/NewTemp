package com.atsisa.gox.framework.eventbus;

import com.atsisa.gox.framework.utility.reflection.ReflectionException;

import rx.Observer;

/**
 * Specifies common methods of event bus.
 */
public interface IEventBus {

    /**
     * Publishes event into the bus.
     * @param event event object
     */
    void post(Object event);

    /**
     * Register event bus observer without filtering capabilities.
     * @param observer observer will receive all events posted to the bus
     * @return registration subscription
     */
    Subscription register(Observer observer);

    /**
     * Register event bus observer with simple class type filtering of events.
     * @param observer observer will receive events posted to the bus that match specified class filter
     * @param clazz    filtering class.
     * @return registration subscription
     */
    Subscription register(Observer observer, Class clazz);

    /**
     * Register event bus observer with simple class name filtering of events.
     * @param observer  observer will receive events posted to the bus that match specified class name filter
     * @param clazzName filtering class name
     * @return registration subscription
     * @throws ReflectionException when fails
     */
    Subscription register(Observer observer, String clazzName) throws ReflectionException;

    /**
     * Register event bus observer through annotation-based observer (@link Subscribe).
     * @param annotatedObserver observer will receive events posted to the bus that match specified class name filter
     * @return registration subscription
     * @throws ReflectionException when fails
     */
    Subscription register(Object annotatedObserver) throws ReflectionException;
}
