package com.atsisa.gox.framework.utility.reflection;

/**
 * Represents all problems regarding reflection.
 */
public class ReflectionException extends Exception {

    /**
     * Initializes a new instance of the ReflectionException class.
     */
    public ReflectionException() {
    }

    /**
     * Initializes a new instance of the ReflectionException class with a specific message.
     * @param message exception message
     */
    public ReflectionException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the ReflectionException class with a specific message and cause.
     * @param message exception message
     * @param cause   exception cause
     */
    public ReflectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
