package com.atsisa.gox.framework.resource;

/**
 * Gives ability to create {@link IResource} objects according to their
 * {@link ResourceDescription}s.
 */
public interface IResourceFactory {

    /**
     * Creates a resource according to provided description.
     * @param resourceDescription The resource description.
     * @return A new resource complying with its description.
     */
    IResource createResource(ResourceDescription resourceDescription);
}
