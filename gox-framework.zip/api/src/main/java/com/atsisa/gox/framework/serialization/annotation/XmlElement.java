package com.atsisa.gox.framework.serialization.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.atsisa.gox.framework.serialization.converter.IValueConverter;

/**
 * Marks a field to be serialized as an xml element.
 */
@Target({ ElementType.FIELD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface XmlElement {

    /**
     * The name of xml element.
     * @return name of xml element
     */
    String name() default "";

    /**
     * Optional element type.
     * @return element type
     */
    Class<?> type() default Void.class;

    /**
     * Defines a value converter class for this attribute.
     * @return value converter class for this attribute
     */
    Class<? extends IValueConverter>[] converters() default {};
}
