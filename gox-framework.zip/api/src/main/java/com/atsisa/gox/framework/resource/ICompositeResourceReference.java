package com.atsisa.gox.framework.resource;

/**
 * Represents a complex resource reference which can contain children.
 * @param <TResource> Type of a child resource.
 */
public interface ICompositeResourceReference<TResource extends IResourceReference> extends IResourceReference {

    /**
     * Gets the child resource of given name.
     * @param name The name of the resource.
     * @return A sub-resource associated with requested name, or null in case requested child does not exist.
     */
    TResource getChildResource(String name);
}
