package com.atsisa.gox.framework.event;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Game initialized event.
 */
@Reflect_Mini
public class GameInitializedEvent {

}
