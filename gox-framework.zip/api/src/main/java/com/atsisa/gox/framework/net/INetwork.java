package com.atsisa.gox.framework.net;

import com.atsisa.gox.framework.utility.Callback;

/**
 * Exposes methods for sending HTTP requests.
 */
public interface INetwork {

    /**
     * Creates and returns new http request.
     * @param url    - String
     * @param method - HttpMethod
     * @return HttpRequest
     */
    HttpRequest getHttpRequest(String url, HttpMethod method);

    /**
     * Sends a HTTP request.
     * @param request  request object
     * @param callback request callback
     */
    void sendHttpRequest(HttpRequest request, Callback<HttpResponse> callback);

}
