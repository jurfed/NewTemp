package com.atsisa.gox.framework.utility.reflection;

import java.lang.annotation.Annotation;

/**
 * Exposes methods for observing and modifying program execution at runtime.
 */
public interface IReflection {

    /**
     * Checks if given type is an array.
     * @param type type to check
     * @return true if given type is an array, false otherwise
     */
    boolean isArray(Class<?> type);

    /**
     * Gets a list of interfaces implemented by given type.
     * @param type type to check
     * @return a list of interfaces implemented by given type
     */
    Class<?>[] getInterfaces(Class<?> type);

    /**
     * Checks if given type is a primitive type.
     * @param type type to check
     * @return true if given type is a primitive type, false otherwise
     */
    boolean isPrimitive(Class<?> type);

    /**
     * Checks if given type is an enum.
     * @param type type to check
     * @return true if given type is an enum, false otherwise
     */
    boolean isEnum(Class<?> type);

    /**
     * Gets the fully qualified type name.
     * @param type type to get
     * @return the fully qualified type name
     */
    String getQualifiedName(Class<?> type);

    /**
     * Gets a simple type name.
     * @param type type to get
     * @return a simple type name
     */
    String getSimpleName(Class<?> type);

    /**
     * Gets the annotation of given type. If type has no annotation of given type null is returned.
     * @param <A>            annotation type
     * @param type           type to check
     * @param annotationType type of an annotation
     * @return the type annotation of given type
     */
    <A extends Annotation> A getAnnotation(Class<?> type, Class<A> annotationType);

    /**
     * Gets a collection of declared fields.
     * @param type type to get
     * @return a collection of declared fields
     */
    Field[] getFields(Class<?> type);

    /**
     * Gets a field with given name.
     * @param type      type to check
     * @param fieldName field name to fetch
     * @return a field object or null if no such field exists.
     */
    Field getField(Class<?> type, String fieldName);

    /**
     * Gets a collection of declared methods.
     * @param type type to get
     * @return a collection of declared methods
     */
    Method[] getMethods(Class<?> type);

    /**
     * Searches for a specific setMethod signature.
     * @param type       type to get
     * @param name       setMethod name
     * @param paramTypes parameter types
     * @return a setMethod object or null if setMethod could not be found
     */
    Method getMethod(Class<?> type, String name, Class<?>... paramTypes);

    /**
     * Creates a new instance of given type.
     * The type must have a default constructor.
     * @param type type to instantiate
     * @param <T>  type of an object
     * @return a new instance of given type.
     * @throws ReflectionException reflection exception when class cannot be instantiated
     */
    <T> T createInstance(Class<T> type) throws ReflectionException;

    /**
     * Creates a new instance of given type name.
     * The type must have a default constructor.
     * @param typeName type name to instantiate
     * @return a new instance of given type name.
     * @throws ReflectionException reflection exception when class cannot be instantiated
     */
    Object createInstance(String typeName) throws ReflectionException;

    /**
     * Gets the class object for the name.
     * @param className class name to retrieve
     * @return the class object
     * @throws ReflectionException reflection exception when class cannot be found
     */
    Class<?> getClassForName(String className) throws ReflectionException;

    /**
     * Gets the super class of given type.
     * @param type type to check
     * @return the super class of given type
     */
    Class<?> getSuperClass(Class<?> type);

    /**
     * Gets the item type of a given array type.
     * @param type array type to check
     * @return array item type
     */
    Class<?> getArrayItemType(Class<?> type);

    /**
     * Gets an object describing modifiers of given type.
     * @param type type to check
     * @return an object describing modifiers of given type
     */
    Member getModifiers(Class<?> type);

    /**
     * Fetches the getter setMethod object for given field and type.
     * The expected getter for boolean values starts with 'is'.
     * @param objType object type to fetch
     * @param field   field the getter should be fetched for
     * @return the getter setMethod object
     * @throws ReflectionException if the getter could not be found
     */
    Method fetchGetter(Class<?> objType, Field field) throws ReflectionException;

    /**
     * Fetches the setter setMethod object for given field and type.
     * @param objType object type to fetch
     * @param field   field the setter should be fetched for
     * @return the setter setMethod object
     * @throws ReflectionException if the setter could not be found
     */
    Method fetchSetter(Class<?> objType, Field field) throws ReflectionException;

    /**
     * Fetches a setMethod of given name across the inheritance hierarchy.
     * It filters public, non-static methods that exactly match given name.
     * If multiple methods are found, the first one is returned.
     * @param objType    object type to fetch
     * @param methodName setMethod name
     * @return a setMethod of given name.
     */
    Method fetchMethod(Class<?> objType, String methodName);

    /**
     * Tests whether the given {@code object} can be cast to the class represented by {@code objectType class}.
     * @param objectType object type
     * @param object     object to test
     * @return {@code true} if  given {@code object} can be cast to the class represented by {@code objectType class}
     */
    boolean isInstance(Class<?> objectType, Object object);
}
