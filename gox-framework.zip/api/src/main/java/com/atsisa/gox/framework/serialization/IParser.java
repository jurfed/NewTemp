package com.atsisa.gox.framework.serialization;

/**
 * Exposes methods for parsing serialized messages.
 */
public interface IParser {

    /**
     * Returns the expected format of a serialized messages.
     * @return serialization format
     */
    SerializationFormat getFormat();

    /**
     * Parses the object.
     * @param serializedString serialized string
     * @return a parsed object
     * @throws ParseException when given string could not be successfully parsed
     */
    IParsableObject parse(String serializedString) throws ParseException;
}
