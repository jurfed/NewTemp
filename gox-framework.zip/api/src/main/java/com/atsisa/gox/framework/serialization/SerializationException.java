package com.atsisa.gox.framework.serialization;

/**
 * Generic serialization exception for handling serialization errors.
 */
public class SerializationException extends Exception {

    /**
     * Initializes a new instance of the SerializationException class.
     */
    public SerializationException() {
    }

    /**
     * Initializes a new instance of the SerializationException class with given message.
     * @param message error message
     */
    public SerializationException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the SerializationException class with given message and cause.
     * @param message error message
     * @param cause   the inner exception (reason)
     */
    public SerializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
