package com.atsisa.gox.framework.eventbus;

/**
 * A subscription to an observable with an ability of unsubscribing.
 */
public interface Subscription {

    /**
     * Stops the receipt of notifications on the subscriber that was registered when this subscription was created.
     */
    void unsubscribe();

    /**
     * Indicates whether this Subscription is currently unsubscribed.
     * @return {@code true} if this Subscription is currently unsubscribed, {@code false} otherwise
     */
    boolean isUnsubscribed();
}
