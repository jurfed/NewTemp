package com.atsisa.gox.framework;

/**
 * Represents types of current application's lifecycle.
 */
public enum LifecycleEventType {

    /**
     * The procedure of starting application has successfully finished.
     * The game is ready to interact.
     */
    STARTED,

    /**
     * The procedure of disposing application has successfully finished.
     * The application's thread will be completed.
     */
    EXIT,

    /**
     * The procedure of pausing application has successfully finished.
     * The game is frozen, so cannot interact with the game.
     */
    PAUSED,

    /**
     * The procedure of resuming application has successfully finished.
     * The game is ready to interact after pause.
     */
    RESUMED
}