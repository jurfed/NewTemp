package com.atsisa.gox.framework;

/**
 * Used to receive lifecycle notifications.
 */
public interface ILifecycleListener {

    /**
     * Called when the application's lifecycle was changed.
     * @param type {@link LifecycleEventType}
     */
    void onChange(LifecycleEventType type);
}
