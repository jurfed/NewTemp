package com.atsisa.gox.framework.resource;

/**
 * Wrapper for image object.
 */
public interface IImageObjectWrapper<T> {

    /**
     * Gets image width.
     * @return int
     */
    float getWidth();

    /**
     * Gets image height.
     * @return int
     */
    float getHeight();

    /**
     * Returns image object, depends on platform.
     * @return T
     */
    T getNativeImage();

}
