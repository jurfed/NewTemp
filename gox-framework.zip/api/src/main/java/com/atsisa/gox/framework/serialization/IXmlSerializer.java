package com.atsisa.gox.framework.serialization;

/**
 * Exposes methods for serializing and deserializing
 * java objects into strings.
 */
public interface IXmlSerializer {

    /**
     * Returns the expected format of a serialized messages.
     * @return serialization format
     */
    SerializationFormat getFormat();

    /**
     * Sets a date serialization format.
     * @param dateFormat a string representation of date format
     */
    void setDateFormat(String dateFormat);

    /**
     * Gets a date serialization format pattern.
     * @return a string representation of date format pattern
     */
    String getDateFormat();

    /**
     * Serializes a java object into its string representation.
     * @param obj a java object to serialize
     * @return a string representation of given object
     * @throws SerializationException if given object could not be serialized
     */
    String serialize(Object obj) throws SerializationException;

    /**
     * Deserializes a string representation of an object to its java instance.
     * @param serializedObj serialized object
     * @param objType       type of the expcted deserialized object
     * @return deserialized java object
     * @throws SerializationException if given string could not be deserialized
     */
    Object deserialize(String serializedObj, Class<?> objType) throws SerializationException;

    /**
     * Deserializes a representation of an object in a implementation specific way based on provided className.
     * @param object    object
     * @param className full package string of serialized object class type
     * @return deserialized java object of className type
     * @throws SerializationException if given string could not be deserialized
     */
    Object deserialize(Object object, String className) throws SerializationException;

    /**
     * Adds a setter interceptor to the serializer.
     * Once added, it will intercept all situations just
     * before property setter invocation.
     * @param setterInterceptor a setter interceptor object
     */
    void addInterceptor(ISetterInterceptor setterInterceptor);

    /**
     * Removes a setter interceptor from the serializer.
     * @param setterInterceptor a setter interceptor object
     */
    void removeInterceptor(ISetterInterceptor setterInterceptor);

    /**
     * De-serializes an object of given type from XmlObject object structure.
     * @param xmlElement XML element representing a serialized object
     * @param className  full package string of serialized object class type
     * @return a JAVA object created from XML string
     * @throws SerializationException if something went wrong with deserialization
     */
    Object deserialize(XmlObject xmlElement, String className) throws SerializationException;

    /**
     * De-serializes an object of given type from XmlObject object structure.
     * @param xmlElement XML element representing a serialized object
     * @param objectType type of the serialized object
     * @param parentType parent type of the current serialized object.
     * @return a JAVA object created from XML string
     * @throws SerializationException if something went wrong with deserialization
     */
    Object deserialize(XmlObject xmlElement, Class<?> objectType, Class<?> parentType) throws SerializationException;

    /**
     * Deserializes a collection of objects from XML string.
     * @param xmlElement XML element representing a collection of serialized objects
     * @param objType    the collection type
     * @param parentType parent object type
     * @return a collection of objects
     * @throws SerializationException if the collection of XML elements could not be deserialized
     */
    Object deserializeCollection(XmlObject xmlElement, Class<?> objType, Class<?> parentType) throws SerializationException;
}
