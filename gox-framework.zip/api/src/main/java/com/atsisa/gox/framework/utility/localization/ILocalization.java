package com.atsisa.gox.framework.utility.localization;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Exposes methods for adapting region-specific data such as date formats.
 */
public interface ILocalization {

    /**
     * Formats a BigDecimal using provided number decimal format.
     * @param number        number to format
     * @param decimalFormat decimal format
     * @return a string representation of given number
     */
    String formatDecimalNumber(BigDecimal number, String decimalFormat);

    /**
     * Formats a date using default, sortable date format (ISO 8601).
     * @param date date to format
     * @return a string representation of given date
     */
    String formatDate(Date date);

    /**
     * Formats a date using given date format.
     * @param date   date to format
     * @param format date format to produce
     * @return a string representation of given date
     */
    String formatDate(Date date, String format);

    /**
     * Parses a date from string looking for sortable date format (ISO 8601).
     * @param date a string representation of a date to parse
     * @return a date object
     */
    Date parseDate(String date);

    /**
     * Parses a date from string looking for particular date format.
     * @param date   a string representation of a date to parse
     * @param format a date format
     * @return a date object
     */
    Date parseDate(String date, String format);
}
