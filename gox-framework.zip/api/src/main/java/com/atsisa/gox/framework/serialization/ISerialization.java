package com.atsisa.gox.framework.serialization;

/**
 * Exoses an abstraction layers for creating serializers of particular type.
 */
public interface ISerialization {

    /**
     * Gets a serializer of given serialization type.
     * @param serializerType type of serialization data
     * @return an implementation of a given data type serializer
     */
    IXmlSerializer getSerializer(SerializationFormat serializerType);

    /**
     * Gets a parser of given serialization type.
     * @param serializerType type of serialization data
     * @return an implementation of a given data type parser
     */
    IParser getParser(SerializationFormat serializerType);
}
