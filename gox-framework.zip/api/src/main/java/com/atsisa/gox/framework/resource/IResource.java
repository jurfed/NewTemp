package com.atsisa.gox.framework.resource;

/**
 * Representing single resource.
 */
public interface IResource extends IResourceReference {

    /**
     * Gets object description.
     * @return ResourceDescription
     */
    ResourceDescription getDescription();

    /**
     * Check if resource is loaded.
     * @return boolean true if loaded
     */
    boolean isLoaded();

    /**
     * Loads resource.
     * @param callback IResourceLoadingCallback
     */
    void load(IResourceLoadingCallback callback);

    /**
     * Unloads resource.
     */
    void unload();

    /**
     * Gets current resource state.
     * @return State
     */
    ResourceState getState();
}
