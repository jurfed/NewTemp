package com.atsisa.gox.framework.serialization;

import com.atsisa.gox.framework.utility.reflection.Field;
import com.atsisa.gox.framework.utility.reflection.Method;

/**
 * Exposes methods form intercepting moments of deserialization.
 * Interceptors of this kind might be combined in a pipeline.
 */
public interface ISetterInterceptor {

    /**
     * Called at final step of deserialization just before the setter setMethod
     * of a property is about to be invoked.
     * Returns a boolean which decides whether or not pipeline processing should be interrupted.
     * If the very first interceptor returns false, the setter will never be invoked.
     * @param setter   a setter setMethod which will be invoked
     * @param field    a corresponding setter's field
     * @param target   a target object containing a setter setMethod
     * @param rawValue a raw value which is about to be deserialized.
     * @return true, if the processing should be continued, false otherwise.
     */
    boolean beforeSetterInvoked(Method setter, Field field, Object target, String rawValue);
}
