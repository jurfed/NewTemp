package com.atsisa.gox.framework.utility.font;

/**
 * Manages fonts across the framework.
 */
public interface IFontRegistry {

    /**
     * Registers a font resource.
     * @param font A font resource to register.
     * @return true if font with the same name has already been registered, false otherwise.
     */
    boolean registerFont(IFontReference font);

    /**
     * Gets a font matching given name.
     * @param fontName The name of the font.
     * @return The font reference or null in case the font could not be found.
     */
    IFontReference getFont(String fontName);
}
