package com.atsisa.gox.framework.net;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.atsisa.gox.framework.utility.Callback;

/**
 * HTTP request object, which is wrapper for platform
 * specific (e.g. html, java) http request.
 */
public abstract class HttpRequest {

    /**
     * Http method.
     */
    private HttpMethod method;

    /**
     * Url.
     */
    private String url;

    /**
     * Header map list.
     */
    private Map<String, String> headers;

    /**
     * Content.
     */
    private String content;

    /**
     * HttpResponse reference.
     */
    private HttpResponse response;

    /**
     * Initializes a new instance of the HttpRequest class.
     * @param url    a request URL
     * @param method HTTP setMethod
     */
    public HttpRequest(String url, HttpMethod method) {
        this.url = url;
        this.method = method;
        headers = new HashMap<>();
    }

    /**
     * Gets the URL of the current Request.
     * @return the URL of the current Request
     */
    public String getUrl() {
        return url;
    }

    /**
     * Gets the HTTP setMethod.
     * @return the HTTP setMethod
     */
    public HttpMethod getMethod() {
        return method;
    }

    /**
     * Sends the request, delivering the response via callback.
     * @param callback HTTP response callback
     */
    public abstract void execute(final Callback<HttpResponse> callback);

    /**
     * Sets a string encoded in the corresponding Content-Encoding set in the headers,
     * with the data to send with the HTTP request. For example, in case of HTTP GET,
     * the content is used as the query string of the GET while on a HTTP POST
     * it is used to send the POST data.
     * @param value - String
     * @return current request
     */
    public HttpRequest setContent(String value) {
        content = value;
        return this;
    }

    /**
     * Adds the supplied request getHeaderByName.
     * @param name  the name of the getHeaderByName
     * @param value the value of the getHeaderByName
     * @return current request
     */
    public HttpRequest addHeader(String name, String value) {
        headers.put(name, value);
        return this;
    }

    /**
     * Gets the HTTP response object. This setMethod does not send the request.
     * @return the HTTP response object
     */
    public HttpResponse getResponse() {
        return response;
    }

    /**
     * Gets content.
     * @return String
     */
    public Optional<String> getContent() {
        return Optional.ofNullable(content);
    }

    /**
     * Gets header map list.
     * @return Map
     */
    public Map<String, String> getHeaders() {
        return headers;
    }

    /**
     * Sets response.
     * @param response - HttpResponse
     */
    protected void setResponse(HttpResponse response) {
        this.response = response;
    }
}
