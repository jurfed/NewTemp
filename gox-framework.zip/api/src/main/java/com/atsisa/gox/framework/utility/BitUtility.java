package com.atsisa.gox.framework.utility;

/**
 * Helper class with operations on bits.
 */
public final class BitUtility {

    /**
     * Instance of this class cannot be created.
     */
    private BitUtility() {
    }

    /**
     * Checks if one value is contained in second value.
     * @param value int
     * @param mask  int
     * @return boolean
     */
    public static boolean isSet(int value, int mask) {
        return (value & mask) != 0;
    }

    /**
     * Addition two values.
     * @param value int
     * @param mask  int
     * @return int
     */
    public static int set(int value, int mask) {
        return value | mask;
    }

    /**
     * Subtraction two values.
     * @param value - int
     * @param mask  - int
     * @return int
     */
    public static int unset(int value, int mask) {
        return value & ~mask;
    }

    /**
     * Combines two integers into one long with bit shift.
     * @param upper upper bits
     * @param lower lower bits
     * @return long
     */
    public static long combine(int upper, int lower) {
        return (long) upper << 32 | lower & Long.MAX_VALUE;
    }

}
