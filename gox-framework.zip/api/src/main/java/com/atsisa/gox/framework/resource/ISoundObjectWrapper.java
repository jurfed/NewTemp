package com.atsisa.gox.framework.resource;

/**
 * Wrapper for sound object.
 */
public interface ISoundObjectWrapper {

    /**
     * Plays sound from the beginning.
     * @return boolean
     */
    boolean play();

    /**
     * Stops sound and resets his position.
     */
    void stop();

    /**
     * Sets sound volume.
     * @param volume - float
     */
    void setVolume(float volume);

    /**
     * Prepares sound.
     * @return boolean
     */
    boolean prepare();

    /**
     * Returns a boolean value which indicating whether this sound is playing or not.
     * @return boolean
     */
    boolean isPlaying();

    /**
     * Returns a boolean value which indicating whether this sound is paused or not.
     * @return boolean
     */
    boolean isPaused();

    /**
     * Returns a boolean value which indicating whether this is already prepared and ready to start.
     * @return boolean
     */
    boolean isReady();

    /**
     * Pause sound.
     */
    void pause();

    /**
     * Resumes sound, which was already paused.
     * @return boolean
     */
    boolean resume();

    /**
     * Gets length of the sound in milliseconds.
     * @return int
     */
    int length();

    /**
     * Gets sound volume.
     * @return float
     */
    float getVolume();

    /**
     * Sets sound loop.
     * @param loop - boolean
     */
    void setLooping(boolean loop);
}
