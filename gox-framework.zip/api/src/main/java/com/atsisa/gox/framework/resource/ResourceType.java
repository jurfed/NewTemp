package com.atsisa.gox.framework.resource;

import java.util.HashMap;
import java.util.Map;

public enum ResourceType {

    BITMAP_FONT("BitmapFont", "bitmapfonts/"),
    CONFIG("Config"),
    QUEUES("Queues"),
    FONT("Font", "fonts/"),
    IMAGE("Image", "images/"),
    LAYOUT("Layout", "layouts/"),
    MOVIE("Movie", "movie/"),
    SOUND("Sound", "sounds/"),
    SPRITE_SHEET("SpriteSheet", "spritesheet/"),
    TEXT("Text"),
    XML("Xml", "xml/");

    private static final Map<String, ResourceType> fromString = new HashMap<>();

    static {
        for (ResourceType resourceType : values()) {
            fromString.put(resourceType.toString(), resourceType);
        }
    }

    private final String value;

    private final String path;

    ResourceType(String value) {
        this.value = value;
        path = "";
    }

    /**
     * Creates resource type with folder name given as parameter.
     * @param path - name of the folder
     */
    ResourceType(String value, String path) {
        this.value = value;
        this.path = path;
    }

    /**
     * Returns relative path to resource type.
     * @return relative path
     */
    public String getPath() {
        return path;
    }

    public static ResourceType fromString(String value) {
        return fromString.get(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
