package com.atsisa.gox.framework.utility.localization;

import java.util.Map;

import rx.Observable;

/**
 * Represents a specific language.
 */
public interface ITranslationProvider {

    /**
     * Asynchronously gets a map of translation, that correspond to language code.
     * @param languageCode the language code
     * @return a map of translations
     */
    Observable<Map<String, String>> getTranslation(String languageCode);
}
