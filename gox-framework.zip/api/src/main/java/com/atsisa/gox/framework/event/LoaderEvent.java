package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.ILoadingHandler;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Loader event class.
 */
@Reflect_Mini
public class LoaderEvent {

    /**
     * Event message.
     */
    private String message;

    /**
     * Loading handler which is associated with this event.
     */
    private ILoadingHandler loadingHandler;

    /**
     * Initializes a new instance of the LoaderEvent.
     * @param message        event message
     * @param loadingHandler loading handler
     */
    public LoaderEvent(String message, ILoadingHandler loadingHandler) {
        this.message = message;
        this.loadingHandler = loadingHandler;
    }

    /**
     * Gets information about the event.
     * @return event message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Gets a loading handler associated with this event.
     * @return LoadingHandler
     */
    public ILoadingHandler getLoadingHandler() {
        return loadingHandler;
    }

}
