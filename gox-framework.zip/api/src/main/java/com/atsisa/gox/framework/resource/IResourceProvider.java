package com.atsisa.gox.framework.resource;

/**
 * Extends the capabilities of {@link IResourceFactory} by
 * checking whether a certain resource type can be created.
 */
public interface IResourceProvider extends IResourceFactory {

    /**
     * Gets a value indicating whether this provider can createResource
     * a resource of given type.
     * @param resourceType The resource type that is about to be created.
     * @return True if this provider can createResource the resource of given type, false otherwise.
     */
    boolean canCreate(ResourceType resourceType);
}
