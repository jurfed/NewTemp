package com.atsisa.gox.framework.serialization;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * The simplest implementation of an XML object.
 */
public class XmlObject implements IParsableObject, Comparable<XmlObject> {

    /**
     * The XML namespace tag.
     */
    public static final String NAMESPACE_TAG = "xmlns";

    /**
     * Xpath format.
     */
    private static final String XPATH_FORMAT = "%s/%s[%s]";

    /**
     * Slash character.
     */
    private static final char SLASH_CHARACTER = '/';

    /**
     * The map of attributes.
     */
    private final Map<String, String> attributes;

    /**
     * A list of children elements.
     */
    private final List<XmlObject> children;

    /**
     * The element's name.
     */
    private String name;

    /**
     * A reference to transferred collection annotations.
     */
    private XmlCollectionElement collectionElement;

    /**
     * The element's XML namespace.
     */
    private String fullNamespace;

    /**
     * A reference to parent element.
     */
    private XmlObject parent;

    /**
     * A text value of the node.
     */
    private String value;

    /**
     * The owner document.
     */
    private XmlObjectDocument ownerDocument;

    /**
     * The namespace abbreviation.
     */
    private String namespaceAbbreviation;

    /**
     * Name of the closesst default namespace.
     */
    private String closestDefaultNamespace;

    /**
     * Initializes a new instance of the XmlObject class.
     */
    XmlObject() {
        attributes = new TreeMap<>();
        children = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the XmlObject class using particular object name.
     * @param name object name
     */
    XmlObject(String name) {
        attributes = new TreeMap<>();
        children = new ArrayList<>();
        this.name = name;
    }

    /**
     * Initializes a new instance of the XmlObject class using particular object name, parent and namespace.
     * @param name          object name
     * @param parent        object's parent
     * @param fullNamespace xml namespace
     */
    XmlObject(String name, XmlObject parent, String fullNamespace) {
        attributes = new TreeMap<>();
        children = new ArrayList<>();

        this.name = name;
        this.parent = parent;
        this.fullNamespace = fullNamespace;

        if (parent != null) {
            closestDefaultNamespace = parent.closestDefaultNamespace;
        }
    }

    /**
     * Gets the name of the closest default namespace.
     * @return closestDefaultNamespace name of the closest default namespace
     */
    public String getClosestDefaultNamespace() {
        return closestDefaultNamespace;
    }

    /**
     * Sets the name of the closest default namespace.
     * @param closestDefaultNamespace name of the closest default namespace
     */
    public void setClosestDefaultNamespace(String closestDefaultNamespace) {
        this.closestDefaultNamespace = closestDefaultNamespace;
    }

    /**
     * Gets the collection element annotation.
     * @return a collection element annotation
     */
    public XmlCollectionElement getCollectionElement() {
        return collectionElement;
    }

    /**
     * Sets the collection element annotation.
     * @param collectionElement a collection element annotation
     */
    public void setCollectionElement(XmlCollectionElement collectionElement) {
        this.collectionElement = collectionElement;
    }

    /**
     * Gets xml object's namespace.
     * @return a xml namespace
     */
    public String getNamespace() {
        if (!StringUtility.isNullOrEmpty(fullNamespace)) {
            return fullNamespace;
        } else {
            return closestDefaultNamespace;
        }
    }

    /**
     * Gets the document which owns this element.
     * @return The document which owns this element.
     */
    public XmlObjectDocument getOwnerDocument() {
        return ownerDocument;
    }

    /**
     * Sets the document which owns this element.
     * @param ownerDocument The document which owns this element
     */
    void setOwnerDocument(XmlObjectDocument ownerDocument) {
        this.ownerDocument = ownerDocument;
    }

    /**
     * Sets a xml namespace to the current element and all its children.
     * @param fullNamespace         a xml full namespace
     * @param namespaceAbbreviation a namespace abbreviation
     */
    void setNamespace(String fullNamespace, String namespaceAbbreviation) {
        this.fullNamespace = fullNamespace;
        this.namespaceAbbreviation = namespaceAbbreviation;
    }

    /**
     * Gets the parent of current element.
     * @return the parent of current element
     */
    public XmlObject getParent() {
        return parent;
    }

    /**
     * Gets all attributes of current XML object.
     * @return a map of attributes
     */
    public Map<String, String> getAttributes() {
        return attributes;
    }

    /**
     * Gets attribute based on specified name.
     * @param attributeName name of the attribute
     * @return value of the attribute
     */
    public String getAttribute(String attributeName) {
        return attributes.get(attributeName);
    }

    /**
     * Gets attribute based on specified name.
     * @param attributeName name of the attribute
     * @param defaultValue  default value in case there is no such attribute
     * @return value of the attribute
     */
    public String getAttribute(String attributeName, String defaultValue) {
        String val = attributes.get(attributeName);
        return val != null ? val : defaultValue;
    }

    /**
     * Adds a new attribute to the current XML object.
     * @param attributeKey   attribute key
     * @param attributeValue attribute value
     */
    public void addAttribute(String attributeKey, String attributeValue) {
        attributes.put(attributeKey, attributeValue);
    }

    /**
     * Gets the name of the current XML object.
     * @return a tag name of this object
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the current XML object.
     * @param name tag name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the node value.
     * @param value node value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the xml node including namespace resolution.
     * @return the value of the xml node.
     */
    @Override
    public String getValue() {
        return getValue(true);
    }

    /**
     * Gets the value of the xml node.
     * @param resolveNamespaces a value indicating whether the namespaces should be resolved.
     * @return the value of the xml node.
     */
    private String getValue(boolean resolveNamespaces) {
        if (!StringUtility.isNullOrEmpty(value)) {
            return value;
        }

        if (children == null || children.isEmpty()) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        for (XmlObject xmlObject : children) {
            sb.append(xmlObject.toXmlString(resolveNamespaces));
        }
        return sb.toString();
    }

    /**
     * Returns the xml string representation of an object by combining its attributes and inner xml data.
     * @return a combined xml representation of an object
     */
    public String toXmlString() {
        return toXmlString(true);
    }

    /**
     * Returns the xml string representation of an object by combining its attributes and inner xml data.
     * @param resolveNamespaces a value indicating whether the namespaces should be resolved.
     * @return a combined xml representation of an object.
     */
    private String toXmlString(boolean resolveNamespaces) {
        String innerValue = getValue(false);
        return toXmlString(innerValue, resolveNamespaces);
    }

    /**
     * Gets a list of children xml objects.
     * @return a list of children xml objects
     */
    public List<XmlObject> getChildren() {
        return children;
    }

    /**
     * Gets children xml object at specified position.
     * @param index index of the position
     * @return xml object
     */
    public XmlObject getChildren(int index) {
        return children.get(index);
    }

    /**
     * Adds a child xml object to the current one.
     * @param xmlObject a child xml object
     */
    public void addChild(XmlObject xmlObject) {
        children.add(xmlObject);
        xmlObject.parent = this;
    }

    /**
     * Add a child xml object to specified position.
     * @param xmlObject - a child xml object
     * @param position  - position
     */
    public void addChild(XmlObject xmlObject, int position) {
        children.add(position, xmlObject);
        xmlObject.parent = this;
    }

    /**
     * Adds child xml object before given name.
     * @param xmlObject - object to insert
     * @param childName - name of the currently stored child xml object
     */
    public void addChildBefore(XmlObject xmlObject, String childName) {
        for (int position = 0; position < children.size(); position++) {
            if (children.get(position).getName().equals(childName)) {
                children.add(position, xmlObject);
                return;
            }
        }
        throw new IllegalArgumentException(StringUtility.format("%s xml object cannot be inserted before %s. Element does not exist.", xmlObject, childName));
    }

    /**
     * Adds child xml object after given name.
     * @param xmlObject - object to insert
     * @param childName - name of the currently stored child xml object
     */
    public void addChildAfter(XmlObject xmlObject, String childName) {
        for (int position = 0; position < children.size(); position++) {
            if (children.get(position).getName().equals(childName)) {
                children.add(position + 1, xmlObject);
                return;
            }
        }
        throw new IllegalArgumentException(StringUtility.format("%s xml object cannot be inserted after %s. Element does not exist.", xmlObject, childName));
    }

    /**
     * Compares this object with other by sorting it lexicographically by name
     * @param xmlObject other xml object to compare
     * @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than the specified object.
     */
    @Override
    public int compareTo(XmlObject xmlObject) {
        if (xmlObject != null) {
            return getName().compareTo(xmlObject.getName());
        }
        return 1;
    }

    /**
     * Checks if the element has children.
     * @return value indicating whether current element has children
     */
    public boolean hasChildren() {
        return !children.isEmpty();
    }

    /**
     * Finds the first element matching given path.
     * The path is defined by simplified xpath syntax (Starting with either / for absolute path or // for any place in the XML)
     * Only xml elements are filtered.
     * @param path path
     * @return an element matching given path
     */
    public XmlObject findOne(String path) {
        List<XmlObject> list = find(path, true);
        return !list.isEmpty() ? list.get(0) : null;
    }

    /**
     * Finds a list of elements matching given path.
     * The path is defined by simplified xpath syntax (Starting with either / for absolute path or // for any place in the XML)
     * Only xml elements are filtered.
     * @param path path
     * @return a list of elements matching given path
     */
    public List<XmlObject> find(String path) {
        return find(path, false);
    }

    /**
     * Finds a list of elements matching given path.
     * @param path    path to match
     * @param onlyOne value indicating breaking search after first match
     * @return a list of elements matching given path.
     */
    private List<XmlObject> find(String path, boolean onlyOne) {
        List<XmlObject> results = new ArrayList<>();
        if (path.startsWith("//")) {
            find(path.substring(1), results, false, onlyOne);
        } else {
            find(path, results, true, onlyOne);
        }
        return results;
    }

    /**
     * Finds a list of elements matching given path.
     * @param path       path to match
     * @param results    a list of found objects
     * @param exactMatch value indicating exact (absolute) or any match
     * @param onlyOne    value indicating breaking search after first match
     */
    private void find(String path, List<XmlObject> results, boolean exactMatch, boolean onlyOne) {
        if (onlyOne && !results.isEmpty()) {
            return;
        }
        String currentXPath = getXPathForSearching();
        boolean found = exactMatch && currentXPath.equals(path) || currentXPath.endsWith(path);
        if (found) {
            results.add(this);
            if (onlyOne) {
                return;
            }
        }
        for (XmlObject child : children) {
            child.find(path, results, exactMatch, onlyOne);
        }
    }

    /**
     * Gets the XML string by interpreting node attributes and its inner value.
     * @param innerValue        node's inner value
     * @param resolveNamespaces a value indicating whether the namespaces should be resolved
     * @return the XML string representation of the node
     */
    protected String toXmlString(String innerValue, boolean resolveNamespaces) {
        StringBuilder sb = new StringBuilder();
        String fullName;
        if (StringUtility.isNullOrEmpty(namespaceAbbreviation)) {
            fullName = name;
        } else {
            fullName = namespaceAbbreviation + ':' + name;
        }

        sb.append('<');
        sb.append(fullName);
        appendXmlNamespaces(sb, resolveNamespaces);
        for (Map.Entry<String, String> entry : attributes.entrySet()) {
            sb.append(StringUtility.format(" %s=\"%s\"", entry.getKey(), entry.getValue()));
        }

        if (StringUtility.isNullOrEmpty(innerValue)) {
            sb.append("/>");
        } else {
            sb.append('>');
            sb.append(innerValue);
            sb.append("</");
            sb.append(fullName);
            sb.append('>');
        }
        return sb.toString();
    }

    /**
     * Processes XML namespaces and appends them to the string builder.
     * @param builder           The builder to append to
     * @param resolveNamespaces a value indicating whether the namespaces should be resolved
     */
    private void appendXmlNamespaces(final StringBuilder builder, boolean resolveNamespaces) {
        if (StringUtility.isNullOrEmpty(namespaceAbbreviation) && !StringUtility.isNullOrEmpty(fullNamespace)) {
            builder.append(' ');
            builder.append(NAMESPACE_TAG);
            builder.append("=\"");
            builder.append(fullNamespace);
            builder.append('"');
        }

        if (resolveNamespaces) {
            Map<String, String> namespaceMap = ownerDocument.getNamespaceMap();
            for (Map.Entry<String, String> entry : namespaceMap.entrySet()) {
                String value = entry.getValue();
                builder.append(' ');
                builder.append(NAMESPACE_TAG);
                if (!entry.getKey().isEmpty()) {
                    builder.append(':');
                    builder.append(entry.getKey());
                }
                builder.append("=\"");
                builder.append(value);
                builder.append('"');
            }
        }
    }

    /**
     * Gets the XPath location of the XML element.
     * @return the XPath location of the XML element
     */
    public String getXPathLocation() {
        if (parent == null) {
            return StringUtility.format(XPATH_FORMAT, "", name, 0);
        }
        return StringUtility.format(XPATH_FORMAT, parent.getXPathLocation(), name, parent.getChildren().indexOf(this) + 1);
    }

    /**
     * Gets the xpath of the current element.
     * @return String
     */
    private String getXPathForSearching() {
        if (parent == null) {
            return SLASH_CHARACTER + name;
        }
        return parent.getXPathForSearching() + SLASH_CHARACTER + name;
    }
}
