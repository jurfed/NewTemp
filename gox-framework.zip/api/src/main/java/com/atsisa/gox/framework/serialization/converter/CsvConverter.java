package com.atsisa.gox.framework.serialization.converter;

/**
 * Converts comma-separated values to a list of strings.
 */
public class CsvConverter extends SeparatedItemsConverter {

    /**
     * Initializes a new instance of the {@link CsvConverter} class.
     */
    public CsvConverter() {
        super(",");
    }
}
