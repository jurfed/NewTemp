package com.atsisa.gox.framework.serialization;

import java.util.Map;
import java.util.TreeMap;

/**
 * Represents parsed XML document.
 */
public class XmlObjectDocument implements IParsableObject {

    /**
     * A map of XML namespaces, maps abbreviations to full XML namespaces.
     */
    private final Map<String, String> namespaceMap;

    /**
     * A reference to document's root element.
     */
    private XmlObject documentElement;

    /**
     * Initializes a new instance of the {@link XmlObjectDocument} class.
     */
    XmlObjectDocument() {
        namespaceMap = new TreeMap<>();
    }

    /**
     * Sets current document's root element.
     * @param documentElement The root document element.
     */
    void setDocumentElement(XmlObject documentElement) {
        this.documentElement = documentElement;
    }

    @Override
    public String getName() {
        return documentElement != null ? documentElement.getName() : null;
    }

    @Override
    public String getValue() {
        return documentElement != null ? documentElement.toXmlString() : null;
    }

    /**
     * Gets the document's root element.
     * @return document's root element
     */
    public XmlObject getDocumentElement() {
        return documentElement;
    }

    /**
     * Gets the XML namespace map.
     * @return the XML namespace map
     */
    public Map<String, String> getNamespaceMap() {
        return namespaceMap;
    }

    /**
     * Creates a new XML element of given name, parent and namespace.
     * @param name      The element name.
     * @param parent    The parent element.
     * @param namespace The namespace.
     * @return A new XML element.
     */
    public XmlObject createElement(String name, XmlObject parent, String namespace) {
        XmlObject element = new XmlObject(name, parent, namespace);
        element.setOwnerDocument(this);
        return element;
    }

    /**
     * Creates a new XML element of given name.
     * @param name The element name.
     * @return A new XML element.
     */
    public XmlObject createElement(String name) {
        XmlObject element = new XmlObject(name);
        element.setOwnerDocument(this);
        return element;
    }
}
