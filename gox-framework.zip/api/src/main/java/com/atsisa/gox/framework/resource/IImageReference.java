package com.atsisa.gox.framework.resource;

/**
 * Represents a reference to the image resource.
 * @param <T> The type of a platform-specific image wrapper object.
 */
public interface IImageReference<T extends IImageObjectWrapper> extends IResourceReference {

    /**
     * Gets a platform-specific image wrapper object.
     * @return a platform-specific image wrapper object.
     */
    T getImageWrapperObject();
}
