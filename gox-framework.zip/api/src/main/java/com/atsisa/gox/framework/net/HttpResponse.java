package com.atsisa.gox.framework.net;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HTTP Response object, which is wrapper for platform
 * specific (e.g. html, java) http response.
 */
public abstract class HttpResponse {

    private int status;

    private Map<String, List<String>> headers;

    private byte[] inputStream;

    private String stringResult;

    public HttpResponse() {
        headers = new HashMap<>();
    }

    /**
     * Returns the data of the HTTP response as a String.
     * @return String
     */
    public String getResultAsString() {
        return stringResult;
    }

    /**
     * Returns the data of the HTTP response as byte array.
     * (not all platforms can support this)
     * @return byte[]
     */
    public byte[] getResultAsStream() {
        return inputStream;
    }

    /**
     * Returns the statusCode of the HTTP response.
     * @return int
     **/
    public int getStatus() {
        return status;
    }

    /**
     * Gets specific header.
     * @param name - String
     * @return String
     */
    public String getHeader(String name) {
        List<String> values = headers.get(name);
        if (values != null) {
            return values.get(0);
        }
        return null;
    }

    /**
     * Returns a Map of the headers. The keys are Strings that represent the header name.
     * Each values is a List of Strings that represent the corresponding header values.
     * @return a map of the headers
     */
    public Map<String, List<String>> getHeaders() {
        return headers;
    }

    /**
     * Sets result as string.
     * @param stringResult - String
     */
    protected void setStringResult(String stringResult) {
        this.stringResult = stringResult;
    }

    /**
     * Sets input stream as byte array.
     * @param inputStream - byte[]
     */
    protected void setInputStream(byte[] inputStream) {
        this.inputStream = inputStream;
    }

    /**
     * Sets status code.
     * @param status - int
     */
    protected void setStatus(int status) {
        this.status = status;
    }

    /**
     * Sets headers.
     * @param headers - Map
     */
    protected void setHeaders(Map<String, List<String>> headers) {
        this.headers = headers;
    }

}
