package com.atsisa.gox.framework.utility;

import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.timer.ITimerManager;

/**
 * Exposes utility methods for date formatting.
 */
public interface IUtility {

    /**
     * Gets an instance of the font registry.
     * @return an instance of the font registry.
     */
    IFontRegistry getFontRegistry();

    /**
     * Gets an instance of a reflection helper class.
     * @return an instance of a reflection helper class.
     */
    IReflection getReflection();

    /**
     * Gets a platform specific serialization helper object.
     * @return a serialization helper object.
     */
    ISerialization getSerialization();

    /**
     * Gets an instance of a localization helper.
     * @return an instance of a localization helper
     */
    ILocalization getLocalization();

    /**
     * Gets the timer manager.
     * @return The timer manager.
     */
    ITimerManager getTimerManager();

    /**
     * Gets an instance of a translator.
     * @return an instance of a translator
     */
    ITranslator getTranslator();
}
