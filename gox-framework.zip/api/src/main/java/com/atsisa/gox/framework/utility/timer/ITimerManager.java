package com.atsisa.gox.framework.utility.timer;

/**
 * Manages instances of {@link ITimer}s.
 */
public interface ITimerManager {

    /**
     * Gets a timer of given name provided
     * it has been launched before.
     * @param timerName The timer name to get.
     * @return A timer instance or null if no such timer was launched before.
     */
    ITimer getTimer(String timerName);

    /**
     * Gets a value indicating whether given timer has been launched before.
     * @param timerName The timer name to check.
     * @return True if the timer has been launched before, false otherwise.
     */
    boolean hasTimer(String timerName);
}
