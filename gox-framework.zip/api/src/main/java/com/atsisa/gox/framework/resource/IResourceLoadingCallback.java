package com.atsisa.gox.framework.resource;

/**
 * Interface for handle callback when source is loaded.
 */
public interface IResourceLoadingCallback {

    /**
     * Callback invokes when resource loading is failed.
     * @param description description of the object
     * @param resIndex    index of resource which caused error
     * @param resCount    number of all resources
     * @param cause       reason for error
     */
    void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause);

    /**
     * Callback invokes when resource loading is succeeded.
     * @param resource object
     * @param resIndex index of resource which was loaded
     * @param resCount number of all resources
     */
    void onSuccess(IResource resource, int resIndex, int resCount);

    /**
     * Called when all resources has been successfully loaded.
     */
    void resourcesLoaded();
}
