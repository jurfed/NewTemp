package com.atsisa.gox.framework.utility.localization;

import java.util.Optional;

/**
 * Represents an interface for translation.
 */
public interface ITranslator {

    /**
     * Translates a message template, where phrases are marked as follows: '{#Lang}'.
     * If phrase does not exist, the translation of this phrase will be omitted.
     * @param template a message template
     * @return a translated message template
     */
    String translateTemplate(String template);

    /**
     * Translates a single phrase.
     * @param phraseKey a phrase key
     * @return if translation exists optional has value, otherwise not
     */
    Optional<String> translatePhrase(String phraseKey);
}
