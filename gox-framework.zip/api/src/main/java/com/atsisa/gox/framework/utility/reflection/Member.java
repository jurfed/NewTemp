package com.atsisa.gox.framework.utility.reflection;

import java.lang.annotation.Annotation;

import com.atsisa.gox.framework.utility.BitUtility;

/**
 * Abstract member class implementation.
 */
public abstract class Member {

    /**
     * The {@code int} value representing the {@code public}
     * modifier.
     */
    public static final int PUBLIC = 0x00000001;

    /**
     * The {@code int} value representing the {@code private}
     * modifier.
     */
    public static final int PRIVATE = 0x00000002;

    /**
     * The {@code int} value representing the {@code protected}
     * modifier.
     */
    public static final int PROTECTED = 0x00000004;

    /**
     * The {@code int} value representing the {@code static}
     * modifier.
     */
    public static final int STATIC = 0x00000008;

    /**
     * The {@code int} value representing the {@code final}
     * modifier.
     */
    public static final int FINAL = 0x00000010;

    /**
     * The {@code int} value representing the {@code abstract}
     * modifier.
     */
    public static final int ABSTRACT = 0x00000400;

    /**
     * Represents member modifiers.
     */
    private final int modifiers;

    /**
     * Member's name.
     */
    private final String name;

    /**
     * A reference to specific implementation of a member.
     */
    private final Object wrappedMember;

    /**
     * Initializes a new instance of the Member class.
     * @param name          field's name
     * @param modifiers     member modifiers
     * @param wrappedMember a reference to specific implementation of a member
     */
    public Member(String name, int modifiers, Object wrappedMember) {
        this.name = name;
        this.modifiers = modifiers;
        this.wrappedMember = wrappedMember;
    }

    /**
     * Gets the name of the field.
     * @return the name of the field
     */
    public String getName() {
        return name;
    }

    /**
     * Gets a reference to specific implementation of a member.
     * @return a reference to specific implementation of a member
     */
    public Object getWrappedMember() {
        return wrappedMember;
    }

    /**
     * Checks if member is final.
     * @return true if it is final, false otherwise
     */
    public boolean isFinal() {
        return BitUtility.isSet(modifiers, FINAL);
    }

    /**
     * Checks if member is static.
     * @return true if it is static, false otherwise
     */
    public boolean isStatic() {
        return BitUtility.isSet(modifiers, STATIC);

    }

    /**
     * Checks if member is public.
     * @return true if it is public, false otherwise
     */
    public boolean isPublic() {
        return BitUtility.isSet(modifiers, PUBLIC);
    }

    /**
     * Checks if member is protected.
     * @return true if it is protected, false otherwise
     */
    public boolean isProtected() {
        return BitUtility.isSet(modifiers, PROTECTED);
    }

    /**
     * Checks if member is private.
     * @return true if it is private, false otherwise
     */
    public boolean isPrivate() {
        return BitUtility.isSet(modifiers, PRIVATE);
    }

    /**
     * Checks if member is abstract.
     * @return true if it is abstract, false otherwise
     */
    public boolean isAbstract() {
        return BitUtility.isSet(modifiers, ABSTRACT);
    }

    /**
     * Gets the annotation of current member. If type has no annotation of given type null is returned.
     * @param <A>            annotation type
     * @param annotationType type of an annotation
     * @return the type annotation of given type
     */
    public abstract <A extends Annotation> A getAnnotation(Class<A> annotationType);
}
