package com.atsisa.gox.framework.utility;

/**
 * Interface requiring implementation clone setMethod.
 * @param <T> - class
 */
public interface ICloneable<T> {

    /**
     * Gets a new instance of this object, which is a clone.
     * @return T
     */
    T clone();

}
