package com.atsisa.gox.framework.utility.reflection;

/**
 * Abstract field class implementation.
 */
public abstract class Field extends Member {

    /**
     * JavaField type.
     */
    private final Class<?> type;

    /**
     * Initializes a new instance of the Field class.
     * @param name          field's name
     * @param modifiers     member modifiers
     * @param type          field type
     * @param wrappedMember a reference to specific implementation of a member
     */
    public Field(String name, int modifiers, Class<?> type, Object wrappedMember) {
        super(name, modifiers, wrappedMember);
        this.type = type;
    }

    /**
     * Gets the field type.
     * @return the field type
     */
    public Class<?> getType() {
        return type;
    }

    /**
     * Sets the value of the field.
     * @param target target object
     * @param value  field's value
     * @throws ReflectionException if the field's value could not be modifier
     */
    public abstract void setValue(Object target, Object value) throws ReflectionException;

    /**
     * Gets the value of the field.
     * @param target target object
     * @return field's value
     * @throws ReflectionException if the field's value could not be fetched
     */
    public abstract Object getValue(Object target) throws ReflectionException;
}
