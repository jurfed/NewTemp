package com.atsisa.gox.framework.resource;

/**
 * Resource current state.
 */
public enum ResourceState {

    /**
     * Ready to load state.
     */
    READY_TO_LOAD,

    /**
     * Loading state.
     */
    LOADING,

    /**
     * Loaded state.
     */
    LOADED,

    /**
     * Error loading state.
     */
    ERROR_LOADING

}
