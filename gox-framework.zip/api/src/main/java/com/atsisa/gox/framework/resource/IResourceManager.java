package com.atsisa.gox.framework.resource;

import java.util.List;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.ILoadingHandler;
import com.atsisa.gox.framework.serialization.ParseException;

/**
 * Interface for managing list of resources.
 */
public interface IResourceManager extends ILoadingHandler, IDisposable {

    /**
     * Gets the resource of specific type and id.
     * @param resourceId   resource id
     * @param resourceType resource type
     * @return IResource resource object
     */
    IResource getResource(String resourceId, ResourceType resourceType);

    /**
     * Searches for a resource according to given resource reference.
     * @param resourceReference A resource reference in <code>@ResourceType/Resource/Subresource</code> format.
     * @param <T>               type of resource reference
     * @return A resource or null if the resource could not be found.
     */
    <T extends IResourceReference> T find(String resourceReference);

    /**
     * Gets all resources of specific type.
     * @param resourceType resource type
     * @return a list of resources
     */
    List<IResource> getAllResources(ResourceType resourceType);

    /**
     * Returns full path to the specific resource, based on resource target path and resource path from game config, platform ect.
     * @param resourceTargetPath - String
     * @return String
     */
    String getFullResourcePath(String resourceTargetPath);

    /**
     * Gets the resource of specific type.
     * @param <T>        resource type
     * @param resourceId resource id
     * @return IResource resource object
     */
    <T extends IResource> T getResource(String resourceId);

    /**
     * Loads a list of resources defined in a file.
     * @param resourceDescriptionFile describes text resource object with xml for resources
     */
    void load(String resourceDescriptionFile);

    /**
     * Loads list of resources.
     * @param resourceDescription object list of resources
     */
    void load(List<ResourceDescription> resourceDescription);

    /**
     * Loads list of resources.
     * @param resourceDescription object list of resources
     * @param loadMarkedAsRuntime - a boolean value that indicates whether resources marked as load runtime should be loaded or not.
     */
    void load(List<ResourceDescription> resourceDescription, boolean loadMarkedAsRuntime);

    /**
     * Deserializes resource xml file.
     * @param resource - text resource to deserialize
     * @return list of resource descriptions
     * @throws ParseException - if deserialziation fails
     */
    List<ResourceDescription> deserializeResourceXmlFile(IResource resource) throws ParseException;

    /**
     * Gets all resource format.
     * @return list
     */
    List<String> getResourceFormats();

    /**
     * Sets the resources config.
     * @param resourceFormats - list with resources
     */
    void setResourceFormats(List<String> resourceFormats);

    /**
     * Sets proper path to resource.
     * @param resourceDescription resource description
     * @return true if path is set correctly
     */
    boolean setPathToResource(ResourceDescription resourceDescription);

    /**
     * Returns if we have to stop when error occurs in resource.
     * @return boolean true if continue after error, false if not
     */
    boolean isResumeOnError();

    /**
     * Determines what happens when resource throws an error.
     * @param isResume boolean true if continue after error, false if not
     */
    void setResumeOnError(boolean isResume);

    /**
     * Unload specific resource.
     * @param resourceId resource id
     */
    void unload(String resourceId);

    /**
     * Unload specific resource.
     * @param resourceId        resource id
     * @param removeFromManager - if true, then resource will be removed from manager.
     */
    void unload(String resourceId, boolean removeFromManager);

    /**
     * Unloads all resources.
     */
    void unloadAll();

    /**
     * Adds a resource loading callback.
     * @param resourceLoadingCallback resources loading callback.
     */
    void addResourceLoadingCallback(IResourceLoadingCallback resourceLoadingCallback);

    /**
     * Removes a resource loading callback.
     * @param resourceLoadingCallback a resource loading callback.
     */
    void removeResourceLoadingCallback(IResourceLoadingCallback resourceLoadingCallback);

    /**
     * Gets resource factory.
     * @return IResourceFactory specific for each platform.
     */
    IResourceFactory getResourceFactory();
}
