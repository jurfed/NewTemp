package com.atsisa.gox.framework.event;

/**
 * Component initialized event.
 */
public class ComponentInitializedEvent {

    /**
     * The name of the component.
     */
    private String name;

    /**
     * Initializes a new instance of the ComponentInitializedEvent class.
     * @param name component name
     */
    public ComponentInitializedEvent(String name) {
        this.name = name;
    }

    /**
     * Gets component name.
     * @return component name
     */
    public String getName() {
        return name;
    }

}
