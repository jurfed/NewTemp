package com.atsisa.gox.framework.net;

/**
 * HTTP request type.
 */
public enum HttpMethod {
    /**
     * GET request.
     */
    GET,
    /**
     * POST request.
     */
    POST,

    /**
     * PUT request
     */
    PUT
}
