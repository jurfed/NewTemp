package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.LifecycleEventType;

/**
 * Lifecycle event.
 */
public class LifecycleEvent {

    /**
     * The lifecycle event type.
     */
    private final LifecycleEventType eventType;

    /**
     * Initializes a new instance of the {@link LifecycleEvent} class.
     *
     * @param eventType the the lifecycle event type
     */
    public LifecycleEvent(LifecycleEventType eventType) {
        this.eventType = eventType;
    }

    /**
     * Gets type of lifecycle event.
     * @return lifecycle event type
     */
    public LifecycleEventType getEventType() {
        return eventType;
    }
}
