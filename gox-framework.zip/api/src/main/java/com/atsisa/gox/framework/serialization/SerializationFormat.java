package com.atsisa.gox.framework.serialization;

/**
 * Describes possible serialization formats.
 */
public enum SerializationFormat {
    /**
     * JSON format.
     */
    JSON,
    /**
     * XML format.
     */
    XML
}
