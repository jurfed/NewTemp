package com.atsisa.gox.framework.utility.font;

/**
 * Represents a font reference.
 * @param <T> The type of platform-specific object representing the font.
 */
public interface IFontReference<T> {

    /**
     * Gets the font name.
     * @return The font name.
     */
    String getFontName();

    /**
     * Gets a platform-specific object representing the font.
     * @param fontSize The font size the font representation should be retrieved for.
     * @return A platform-specific object representing the font.
     */
    T getFontWrapperObject(int fontSize);
}
