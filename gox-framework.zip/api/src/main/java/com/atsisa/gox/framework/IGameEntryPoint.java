package com.atsisa.gox.framework;

import com.atsisa.gox.inject.IServiceResolverRegistry;

/**
 * Exposes methods for control the lifecycle of game.
 */
public interface IGameEntryPoint {

    /**
     * Gets the service resolver registry.
     *
     * @return {@link IServiceResolverRegistry}
     */
    IServiceResolverRegistry getRegistry();

    /**
     * Starts the game and blocks thread until the game closes.
     */
    void start();

    /**
     * Pauses the current running game.
     */
    void pause();

    /**
     * Resumes the current paused game.
     */
    void resume();

    /**
     * Adds listener to listen for lifecycle changes.
     *
     * @param listener the lifecycle listener
     * @return <tt>true</tt> if successfully added listener, otherwise <tt>false</tt> - probably this listener has already been added
     */
    boolean addLifecycleListener(ILifecycleListener listener);

    /**
     * Removes the specified listener from listeners.
     *
     * @param listener the lifecycle listener
     * @return <tt>true</tt> if successfully removed listener, otherwise <tt>false</tt> - probably this listener was not found
     */
    boolean removeLifecycleListener(ILifecycleListener listener);
}