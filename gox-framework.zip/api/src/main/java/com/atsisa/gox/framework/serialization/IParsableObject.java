package com.atsisa.gox.framework.serialization;

/**
 * A representation of the parsed object.
 */
public interface IParsableObject {

    /**
     * Gets the name of the parsed object.
     * @return the name of the parsed object
     */
    String getName();

    /**
     * Gets the value of the parsed object.
     * @return the value of the parsed object
     */
    String getValue();
}
