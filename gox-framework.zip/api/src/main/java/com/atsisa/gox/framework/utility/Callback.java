package com.atsisa.gox.framework.utility;

/**
 * Used to communicate asynchronous results.
 */
public interface Callback<T> {

    /**
     * A callback that chains failure to the supplied delegate callback.
     */
    abstract class Chain<T> implements Callback<T> {

        private Callback<?> onFailure;

        public Chain(Callback<?> onFailure) {
            this.onFailure = onFailure;
        }

        @Override
        public void onFailure(Throwable cause) {
            onFailure.onFailure(cause);
        }
    }

    /**
     * Called when the asynchronous request succeeded, supplying its result.
     * @param result result
     */
    void onSuccess(T result);

    /**
     * Called when the asynchronous request failed, supplying a cause for failure.
     * @param cause throwable
     */
    void onFailure(Throwable cause);
}
