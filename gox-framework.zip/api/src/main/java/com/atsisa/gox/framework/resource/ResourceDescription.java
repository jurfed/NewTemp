package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.CsvConverter;
import com.atsisa.gox.framework.utility.ICloneable;
import com.gwtent.reflection.client.annotations.Reflect_Full;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents resource description.
 * Url differs from target path. Url contains shortened path.
 * Example:
 * Image is situated in locations hi/images/customfolder/logo.png and low/images/customfolder/logo.png .
 * <p>
 * Valid url('url') to this resource will be:  "customfolder/logo.png" .
 * Valid format list ('formatList') will be: "hi,low" .
 * Type of resource ('resourceType'): "Image"
 * <p>
 * If active configuration is set as "hi", then calculated target path ('targetPath') would be: "hi/images/customfolder.png" .
 */
@Reflect_Full
@XmlElement(name = "resource")
public class ResourceDescription implements ICloneable<ResourceDescription> {

    /**
     * Mapping to list of formats. Converter CsvConverter is used to change String to List of Strings.
     */
    @XmlAttribute(name = "format", converters = CsvConverter.class)
    private List<String> formatList;

    /**
     * Resource ID.
     */
    @XmlAttribute
    private String id;

    /**
     * Resource Type(Audio, Image, Text etc.).
     */
    @XmlAttribute(name = "type")
    private ResourceType resourceType;

    /**
     * A boolean value that indicates whether this resource should be loaded at start or it will be loaded later.
     */
    @XmlAttribute(name = "loadRuntime")
    private boolean loadRuntime;

    /**
     * Inline url attribute.
     */
    @XmlAttribute
    private String url;

    /**
     * Path to resource.
     */
    private String targetPath;

    /**
     * Used format to build path.
     */
    private String usedFormat;

    /**
     * Empty constructor for serializer.
     */
    public ResourceDescription() {
        formatList = new ArrayList<>();
    }

    /**
     * Constructs resource description for default configuration.
     * @param id           id of the resource
     * @param url          url of the resource
     * @param resourceType type of resource(Sound, Image etc.)
     */
    public ResourceDescription(String id, String url, ResourceType resourceType) {
        this.id = id;
        this.url = url;
        this.resourceType = resourceType;
    }

    /**
     * Constructs resource description with target path.
     * @param id           id of resource
     * @param resourceType type of resource(Sound, Image etc.)
     * @param targetPath   single resource url
     */
    public ResourceDescription(String id, ResourceType resourceType, String targetPath) {
        this.id = id;
        this.resourceType = resourceType;
        this.targetPath = targetPath;
    }

    /**
     * Constructs resource description with url and format list. Target path is automatically set.
     * @param id           id of resource
     * @param url          url of the resource
     * @param resourceType type of resource(Sound, Image etc.)
     * @param formatList   list of resource formats
     */
    public ResourceDescription(String id, String url, ResourceType resourceType, List<String> formatList) {
        this.id = id;
        this.url = url;
        this.resourceType = resourceType;
        this.formatList = new ArrayList<>();
        if (formatList != null) {
            this.formatList.addAll(formatList);
        }
    }

    /**
     * Gets format list.
     * @return format list
     */
    public List<String> getFormatList() {
        return new ArrayList<>(formatList);
    }

    /**
     * Sets format list.
     * @param formatList format list
     */
    public void setFormatList(List<String> formatList) {
        this.formatList = formatList;
    }

    /**
     * Gets resource ID.
     * @return resource id string
     */
    public String getId() {
        return id;
    }

    /**
     * Sets resource ID.
     * @param id resource id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets a boolean value that indicates whether this resource should be loaded at start or later.
     * @return boolean - if true then this resource will be not loaded at start.
     */
    public boolean getLoadRuntime() {
        return loadRuntime;
    }

    /**
     * Sets a boolean value that indicates whether this resource should be loaded at start or later.
     * @param loadRuntime - if true then this resource will be not loaded at start.
     */
    public void setLoadRuntime(boolean loadRuntime) {
        this.loadRuntime = loadRuntime;
    }

    /**
     * Gets resource type.
     * @return ResourceType resource type
     */
    public ResourceType getResourceType() {
        return resourceType;
    }

    /**
     * Sets resource type.
     * @param resourceType resource type
     */
    public void setResourceType(ResourceType resourceType) {
        this.resourceType = resourceType;
    }

    /**
     * Gets URL (shortened path).
     * @return url
     */
    public String getUrl() {
        return url;
    }

    /**
     * Sets URL (shortened path).
     * @param url url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Gets target path.
     * @return target pat
     */
    public String getTargetPath() {
        return targetPath;
    }

    /**
     * Sets target path.
     * @param targetPath target path
     */
    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    /**
     * Gets format which was used to build target path.
     * @return String
     */
    public String getUsedFormat() {
        return usedFormat;
    }

    /**
     * Sets path to resource. It needs only format for which the path should be set.
     * @param format format, for which path should be set
     */
    public void setPathToResource(String format) {
        usedFormat = format;
        StringBuilder path = new StringBuilder(format);
        String prefix = resourceType.getPath();
        path.append('/').append(prefix).append(url);
        targetPath = path.toString();
    }

    @Override
    public ResourceDescription clone() {
        ResourceDescription newResourceDescription = new ResourceDescription(id, url, resourceType, formatList);
        newResourceDescription.loadRuntime = loadRuntime;
        return newResourceDescription;
    }

    @Override
    public String toString() {
        return "ResourceDescription{" + "id='" + id + '\'' + ", resourceType=" + resourceType + '}';
    }
}
