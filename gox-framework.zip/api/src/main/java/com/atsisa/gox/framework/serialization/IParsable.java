package com.atsisa.gox.framework.serialization;

/**
 * Exposes methods from parsing object's data.
 */
public interface IParsable {

    /**
     * Parses the response from XmlObject.
     * @param parsedObject xml object to parse
     * @throws ParseException if something went wrong with parsing
     */
    void parse(IParsableObject parsedObject) throws ParseException;
}
