package com.atsisa.gox.framework.event;

import java.util.Map;

import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a command for registering translation.
 */
@Reflectable
public class RegisterTranslationCommand {

    /**
     * A map of translations.
     */
    private final Map<String, String> translation;

    /**
     * A language code.
     */
    private final String languageCode;

    /**
     * Initializes a new instance of the {@link RegisterTranslationCommand} class.
     * @param languageCode language code
     * @param translation translation
     */
    public RegisterTranslationCommand(String languageCode, Map<String, String> translation) {
        this.translation = translation;
        this.languageCode = languageCode;
    }

    /**
     * Gets a map of translations.
     * @return map of translation
     */
    public Map<String, String> getTranslation() {
        return translation;
    }

    /**
     * Gets a language code.
     * @return language code
     */
    public String getLanguageCode() {
        return languageCode;
    }
}
