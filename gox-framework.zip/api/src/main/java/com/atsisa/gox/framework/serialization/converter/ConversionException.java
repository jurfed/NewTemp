package com.atsisa.gox.framework.serialization.converter;

/**
 * Defines error occurred during value conversion.
 */
public class ConversionException extends Exception {

    /**
     * Initializes a new instance of the ConversionException class.
     */
    public ConversionException() {
    }

    /**
     * Initializes a new instance of the ConversionException class with given message.
     * @param message error message
     */
    public ConversionException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the ConversionException class with given message and cause.
     * @param message error message
     * @param cause   the inner exception (reason)
     */
    public ConversionException(String message, Throwable cause) {
        super(message, cause);
    }

}
