package com.atsisa.gox.framework;

/**
 * Defines methods for objects that extends something.
 */
public interface IApiExtension {

    /**
     * Initializes extends.
     */
    void extend();

}
