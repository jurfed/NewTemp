package com.atsisa.gox.framework.utility.font;

/**
 * Defines a fallback action in case requested
 * font was not present in the {@link IFontRegistry}.
 */
public interface IFontRegistryFallback {

    /**
     * Resolves a font which was not registered in the {@link IFontRegistry}.
     * @param fontName The name of the font to resolve.
     * @return The font reference.
     */
    IFontReference getMissingFont(String fontName);
}
