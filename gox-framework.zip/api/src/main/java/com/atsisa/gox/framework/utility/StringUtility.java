package com.atsisa.gox.framework.utility;

import java.util.List;

/**
 * String representation utility class.
 */
public final class StringUtility {

    /**
     * An empty string.
     */
    public static final String EMPTY = "";

    /**
     * The replacement pattern.
     */
    public static final String PATTERN = "%s";

    /**
     * Instance of this class cannot be created.
     */
    private StringUtility() {
    }

    /**
     * Checks whether a given string is null or empty.
     * @param str string to check
     * @return true if string is null or empty, false otherwise
     */
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.equals(EMPTY);
    }

    /**
     * Returns a formatted string using the specified format string and arguments.
     * @param format A format string (with %s only)
     * @param args   Arguments for injection
     * @return A formatted string
     */
    public static String format(final String format, final Object... args) {
        if (isNullOrEmpty(format) || args == null) {
            return format;
        }
        int start = 0;
        int last = 0;
        int argsIndex = 0;
        final StringBuilder result = new StringBuilder();
        while ((start = format.indexOf(PATTERN, last)) != -1 && argsIndex < args.length) {
            result.append(format.substring(last, start));
            result.append(args[argsIndex++]);
            last = start + PATTERN.length();
        }

        result.append(format.substring(last));
        return result.toString();
    }

    /**
     * Returns a string with its first letter converted to upper case.
     * @param str string to convert
     * @return a string with upper case first letter
     */
    public static String toUpperFirst(final String str) {
        if (isNullOrEmpty(str)) {
            return str;
        }
        return Character.toUpperCase(str.charAt(0)) + str.substring(1);
    }

    /**
     * Returns a string with its first letter converted to lower case.
     * @param str string to convert
     * @return a string with lower case first letter
     */
    public static String toLowerFirst(final String str) {
        if (isNullOrEmpty(str)) {
            return str;
        }
        return Character.toLowerCase(str.charAt(0)) + str.substring(1);
    }

    /**
     * Joins a list of string into one string using string separator.
     * @param separator  string separator
     * @param stringList a list of strings
     * @return merged string
     */
    public static String join(String separator, List<String> stringList) {
        if (stringList != null && separator != null && !stringList.isEmpty()) {
            int count = stringList.size();
            StringBuilder joinBuffer = new StringBuilder(stringList.get(0));
            for (int idx = 1; idx < count; idx++) {
                joinBuffer.append(separator).append(stringList.get(idx));
            }
            return joinBuffer.toString();
        }
        return null;
    }

    /**
     * Creates a new string by concatenating enough leading pad characters to the target string to achieve a specified total length.
     * @param target target string
     * @param count  total length of a new string
     * @param c      a padding character
     * @return A new string that is equivalent to this instance, but right-aligned and padded on the left with as many c characters as needed to create a length
     * of count.
     */
    public static String padLeft(String target, int count, char c) {
        int targetLen = target.length();
        if (targetLen >= count) {
            return target;
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < count - targetLen; i++) {
                sb.append(c);
            }
            sb.append(target);
            return sb.toString();
        }
    }

    /**
     * Checks whether two strings are equal considering nulls as well.
     * @param left  The first string.
     * @param right The second string.
     * @return True if strings are equal, false otherwise.
     */
    public static boolean equals(String left, String right) {
        if (left != null) {
            return left.equals(right);
        } else {
            return right == null;
        }
    }

    /**
     * Checks if specific string is number or not.
     * @param str string value to check
     * @return true if string is a number
     */
    public static boolean isNumber(final String str) {
        try {
            Float.valueOf(str);
        } catch (NumberFormatException ex) {
            return false;
        }
        return true;
    }

}
