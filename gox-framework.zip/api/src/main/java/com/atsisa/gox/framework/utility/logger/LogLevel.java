package com.atsisa.gox.framework.utility.logger;

/**
 * Logging level hierarchy types.
 */
public enum LogLevel {

    /**
     * An trace message.
     */
    TRACE(0x83b13a),

    /**
     * An debug message.
     */
    DEBUG(0x39b1ef),

    /**
     * An info message.
     */
    INFO(0xf1db46),

    /**
     * An warn message.
     */
    WARN(0xd4802f),

    /**
     * An error message.
     */
    ERROR(0xc30000);

    /**
     * Color corresponding to log level.
     */
    private int logColor;

    /**
     * Creates a new instance of the LogLevel.
     * @param logColor - int
     */
    LogLevel(int logColor) {
        this.logColor = logColor;
    }

    /**
     * Returns color corresponding to log level.
     * @return int
     */
    public int getLogColor() {
        return logColor;
    }

}
