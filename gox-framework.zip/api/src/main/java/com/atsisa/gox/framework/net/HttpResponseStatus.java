package com.atsisa.gox.framework.net;

/**
 * A list of common response status codes of the HTTP protocol.
 * See https://en.wikipedia.org/wiki/List_of_HTTP_status_codes.
 **/
public enum HttpResponseStatus {

    /**
     * Standard response for successful HTTP requests. The actual response will depend on the request method used.
     * In a GET request, the response will contain an entity corresponding to the requested resource.
     * In a POST request, the response will contain an entity describing or containing the result of the action
     */
    OK(200),

    /**
     * The server cannot or will not process the request due to an apparent client error (e.g., malformed
     * request syntax, invalid request message framing, or deceptive request routing)
     */
    BAD_REQUEST(400);

    /**
     * Status code.
     */
    private int status;

    /**
     * Creates a new of the HttpResponseStatus class.
     * @param status - int
     */
    HttpResponseStatus(int status) {
        this.status = status;
    }

    /**
     * Gets status code.
     * @return int
     */
    public int getStatus() {
        return status;
    }

}
