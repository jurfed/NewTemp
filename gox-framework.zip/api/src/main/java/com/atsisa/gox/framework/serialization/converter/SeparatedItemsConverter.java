package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.serialization.IParsableObject;

import java.util.ArrayList;
import java.util.List;

/**
 * A converter for items separated with a custom separator.
 */
public abstract class SeparatedItemsConverter implements IValueConverter {

    /**
     * The separator.
     */
    private final String separator;

    /**
     * Initializes a new instance of the {@link SeparatedItemsConverter}
     * class.
     * @param separator The separator.
     */
    protected SeparatedItemsConverter(String separator) {
        this.separator = separator;
    }

    @Override
    public Class<?> getValueType() {
        return Object.class;
    }

    /**
     * Actually function is not implemented.
     * @param objToConvert a Java object instance
     * @return converted String
     */
    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException();
    }

    /**
     * Converts String into List of Strings.
     * @param serializedMessage a string representation of read text
     * @param parsedObject      - IParsedObject unused
     * @return List containing split String
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        if (serializedMessage == null) {
            return null;
        }
        if (serializedMessage.isEmpty()) {
            return new ArrayList<>();
        } else {

            String[] splitMessage = serializedMessage.split(separator);
            List<String> splitMessageList = new ArrayList<>();
            for (String message : splitMessage) {
                if (!message.isEmpty()) {
                    splitMessageList.add(message);
                }
            }
            return splitMessageList;
        }
    }
}
