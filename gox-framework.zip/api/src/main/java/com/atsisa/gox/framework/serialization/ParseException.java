package com.atsisa.gox.framework.serialization;

/**
 * Generic parsing exception for handling parser errors.
 */
public class ParseException extends Exception {

    /**
     * Initializes a new instance of the ParseException class.
     */
    public ParseException() {
    }

    /**
     * Initializes a new instance of the ParseException class with given message.
     * @param message error message
     */
    public ParseException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the ParseException class with given message and cause.
     * @param message error message
     * @param cause   the inner exception (reason)
     */
    public ParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
