package com.atsisa.gox.framework.serialization.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.atsisa.gox.framework.serialization.converter.IValueConverter;

/**
 * Marks a field to be serialized as an xml attribute.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface XmlAttribute {

    /**
     * The name of xml attribute.
     * @return name of xml attribute.
     */
    String name() default "";

    /**
     * Optional element type.
     * @return Optional element type
     */
    Class<?> type() default Void.class;

    /**
     * Defines a value converter class for this attribute.
     * @return value converter class for this attribute
     */
    Class<? extends IValueConverter>[] converters() default {};

    /**
     * Defines the order of assigning values to xml attributes, default is 255.
     * Lower numbers are processed earlier.
     * @return the order of assigning values to xml attributes, default is 255.
     */
    int order() default Integer.MAX_VALUE;
}
