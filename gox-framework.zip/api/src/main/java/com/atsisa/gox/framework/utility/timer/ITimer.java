package com.atsisa.gox.framework.utility.timer;

/**
 * Represents a generic timer.
 */
public interface ITimer {

    /**
     * Gets the name of this timer.
     * @return The timer name.
     */
    String getName();

    /**
     * Gets the time span this timer should last.
     * @return The time span this timer should last.
     */
    int getTimeSpan();

    /**
     * Sets the time span this timer should last.
     * @param timeSpan The time span this timer should last.
     */
    void setTimeSpan(int timeSpan);

    /**
     * Gets a value indicating whether this timer was canceled.
     * @return True if the timer was canceled before, false otherwise.
     */
    boolean isCanceled();

    /**
     * Gets a value indicating whether this timer is currently active.
     * @return True if the timer is working, false otherwise.
     */
    boolean isActive();

    /**
     * Starts this timer.
     * <p>
     * This operation does nothing in case the timer is already started.
     * </p>
     */
    void start();

    /**
     * Cancels this timer.
     * <p>
     * This operation does nothing in case the timer has already been canceled before.
     * </p>
     */
    void cancel();
}
