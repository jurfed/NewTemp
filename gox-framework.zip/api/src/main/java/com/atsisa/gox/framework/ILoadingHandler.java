package com.atsisa.gox.framework;

/**
 * Defines methods for objects that process something.
 */
public interface ILoadingHandler {

    /**
     * Gets the totals number of already loaded items.
     * @return the totals number of already loaded items
     */
    int getItemsLoaded();

    /**
     * Gets the total number of items to be loaded.
     * @return the total number of items to be loaded
     */
    int getItemsTotal();
}
