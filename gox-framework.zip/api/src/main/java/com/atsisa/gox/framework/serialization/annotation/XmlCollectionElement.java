package com.atsisa.gox.framework.serialization.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.atsisa.gox.framework.serialization.converter.IValueConverter;

/**
 * Marks a field to be serialized as an xml collection element.
 */
@Target({ ElementType.FIELD, ElementType.TYPE, ElementType.LOCAL_VARIABLE })
@Retention(RetentionPolicy.RUNTIME)
public @interface XmlCollectionElement {

    /**
     * The name of a collection element.
     * @return name of a collection element.
     */
    String name() default "";

    /**
     * The name of a single item element inside a collection element.
     * @return name of a single item element inside a collection element.
     */
    String itemName() default "";

    /**
     * The type of a collection item.
     * @return type of a collection item.
     */
    Class<?> itemType();

    /**
     * Defines a value converter class for this attribute.
     * @return a value converter class for this attribute.
     */
    Class<? extends IValueConverter>[] converters() default {};
}
