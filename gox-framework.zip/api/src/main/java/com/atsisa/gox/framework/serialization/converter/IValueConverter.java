package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.serialization.IParsableObject;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Exposes methods for object conversion during serialization.
 */
@Reflect_Full
public interface IValueConverter {

    /**
     * Gets the type of a value object.
     * @return the type of a value object
     */
    Class<?> getValueType();

    /**
     * Converts a Java object to its string representation.
     * @param objToConvert a Java object instance
     * @return a string representation of a Java object
     * @throws ConversionException then conversion fails
     */
    String convertTo(Object objToConvert) throws ConversionException;

    /**
     * Converts a string, parse object representation of a Java object to its instance.
     * @param serializedMessage a string representation of a Java object. Contains string without main element.
     * @param parsedObject      - IParsedObject. Contains parsed whole structure with main element.
     * @return a Java object instance
     * @throws ConversionException then conversion fails
     */
    Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException;
}
