package com.atsisa.gox.framework.utility.reflection;

/**
 * Abstract setMethod class implementation.
 */
public abstract class Method extends Member {

    /**
     * Initializes a new instance of the Method class.
     * @param name          field's name
     * @param modifiers     member modifiers
     * @param wrappedMember a reference to specific implementation of a member
     */
    public Method(String name, int modifiers, Object wrappedMember) {
        super(name, modifiers, wrappedMember);
    }

    /**
     * Invokes the setMethod and returns results.
     * @param target call target
     * @param params setMethod parameters
     * @return setMethod result
     * @throws ReflectionException reflection exception when setMethod cannot be invoked
     */
    public abstract Object invoke(Object target, Object... params) throws ReflectionException;

    /**
     * Gets an array of parameter type names.
     * @return an array of parameter type names
     */
    public abstract String[] getParameterTypes();

    /**
     * Gets a method return type name.
     * @return method return type name
     */
    public abstract String getReturnType();
}
