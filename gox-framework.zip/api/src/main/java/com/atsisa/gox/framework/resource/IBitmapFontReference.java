package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.utility.font.IFontReference;

/**
 * Represents a bitmap font.
 * @param <TFont> The type of platform-specific object representing the font.
 */
public interface IBitmapFontReference<TFont> extends IFontReference<TFont> {

    /**
     * Gets the default size of this bitmap font.
     * @return The default size of the font in pixels.
     */
    int getDefaultFontSize();
}
