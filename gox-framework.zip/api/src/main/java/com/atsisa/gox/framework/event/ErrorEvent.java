package com.atsisa.gox.framework.event;

/**
 * Error event class.
 */
public class ErrorEvent {

    /**
     * Information about error.
     */
    private Throwable throwable;

    /**
     * Initializes a new instance of the ErrorEvent class.
     * @param throwable throwable
     */
    public ErrorEvent(Throwable throwable) {
        this.throwable = throwable;
    }

    /**
     * Gets information about error.
     * @return throwable
     */
    public Throwable getThrowable() {
        return throwable;
    }

}
