package com.atsisa.gox.framework.view;

/**
 * Describes possible text horizontal alignments.
 */
public enum HorizontalAlign {
    CENTER,
    LEFT,
    RIGHT
}
