package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data about sound to stop.
 */
@XmlElement
@Reflect_Full
public class SoundActionData extends ActionData {

    /**
     * Id of the sound.
     */
    @XmlAttribute
    private String soundId;

    /**
     * Gets sound id.
     * @return sound id
     */
    public String getSoundId() {
        return soundId;
    }

    /**
     * Sets sound id.
     * @param soundId - id fo the sound
     */
    public void setSoundId(String soundId) {
        this.soundId = soundId;
    }
}
