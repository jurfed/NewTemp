package com.atsisa.gox.framework.rendering;

/**
 * Represents states of the {@link IInputEventDelegate} instance.
 */
public enum InputEventDelegateState {

    /**
     * The delegate is currently delegating events.
     */
    ACTIVE,

    /**
     * The delegate currently does not delegate events.
     */
    PAUSED
}
