package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * The ViewGroup class is the base class for all objects that can server as view containers on the stage.
 */
@XmlElement
@Reflect_Full
public class ViewGroup extends ViewGroupBase {

    /**
     * Children xml tag.
     */
    public static final String XML_CHILDREN_TAG = "children";

    /**
     * Initializes a new instance of the ViewGroup class.
     */
    public ViewGroup() {
        super();
    }

    /**
     * Initializes a new instance of the ViewGroup class.
     * @param renderer {@link IRenderer}
     */
    public ViewGroup(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Adds a view to ViewGroup list.
     * @param view - View
     */
    @Override
    public void addChild(View view) {
        super.addChild(view);
    }

    /**
     * Removes specific View from ViewGroup list.
     * @param view - View
     * @return boolean - "false" if view does not belong to this ViewGroup
     */
    @Override
    public boolean removeChild(View view) {
        return super.removeChild(view);
    }

    @Override
    public boolean removeChild(View view, boolean dispose) {
        return super.removeChild(view, dispose);
    }

    /**
     * Removes all view from ViewGroup list.
     */
    @Override
    public void removeAll() {
        super.removeAll();
    }
}
