package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data container for loop bundle actions process.
 */
@Reflect_Full
@XmlElement
public class LoopBundleActionData extends BundleActionData {

    /**
     * Repeat count.
     */
    @XmlAttribute(type = Integer.class)
    private int repeatCount;

    /**
     * Gets repeat count.
     * @return repeat count
     */
    public int getRepeatCount() {
        return repeatCount;
    }

    /**
     * Sets repeat count.
     * @param repeatCount repeat count
     */
    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
    }
}
