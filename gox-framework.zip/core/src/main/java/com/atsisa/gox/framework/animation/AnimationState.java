package com.atsisa.gox.framework.animation;

/**
 * Describes all possible {@link IAnimation} states.
 */
public enum AnimationState {

    /**
     * The animation is stopped.
     */
    STOPPED,

    /**
     * The animation is playing.
     */
    PLAYING,

    /**
     * The animation is paused.
     */
    PAUSED,

    /**
     * The animation is began stopping.
     */
    STOPPING
}
