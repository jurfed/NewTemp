package com.atsisa.gox.framework.serialization.converter;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/*
import tripleplay.particle.Effector;
import tripleplay.particle.effect.Alpha;
import tripleplay.particle.effect.Drag;
import tripleplay.particle.effect.Gravity;
import tripleplay.particle.effect.Move;
import tripleplay.util.Interpolator;
*/

/**
 * Particle effector list converter.
 */
@Reflectable(methods = false, fields = false)
public class ParticleEffectorsConverter implements IValueConverter {

    /**
     * Comma separated values converter.
     */
    private final CsvConverter csvConverter = new CsvConverter();

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of the ParticleEffectorsConverter class.
     */
    public ParticleEffectorsConverter() {
        logger = GameEngine.current().getLogger();
    }

    /**
     * Initializes a new instance of the ParticleEffectorsConverter class.
     * @param logger custom logger
     */
    public ParticleEffectorsConverter(ILogger logger) {
        this.logger = logger;
    }

    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException("Not implemented!");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        XmlObject xmlObject;
        if (parsedObject instanceof XmlObject) {
            xmlObject = (XmlObject) parsedObject;
        } else if (parsedObject instanceof XmlObjectDocument) {
            xmlObject = ((XmlObjectDocument) parsedObject).getDocumentElement();
        } else {
            throw new IllegalArgumentException("Failed to convert parsedObject");
        }

        /*List<Effector> effectorList = new ArrayList<Effector>();
        for (XmlObject child : xmlObject.getChildren()) {
            if (child.getName().equals("alpha")) {
                addEffectorToList(this.getAlphaEffector(child), effectorList);
            } else if (child.getName().equals("drag")) {
                addEffectorToList(this.getDragEffector(child), effectorList);
            } else if (child.getName().equals("gravity")) {
                addEffectorToList(this.getGravityEffector(child), effectorList);
            } else if (child.getName().equals("move")) {
                addEffectorToList(new Move(), effectorList);
            }
        }
        return effectorList;*/
        return null;
    }

    /**
     * Adds an effector to the effectorList if it is not null.
     * @param effector effector to add
     * @param effectorList list the effector should be added to
     */
    /*private void addEffectorToList(Effector effector, List<Effector> effectorList) {
        if (effector != null) {
            effectorList.add(effector);
        }
    }*/

    /**
     * Gets an alpha effector.
     * @param element alpha xml element
     * @return an alpha effector
     */
   /* private Effector getAlphaEffector(XmlObject element) {
        float start = element.getFloatAttribute("start", 1),
                end = element.getFloatAttribute("end", 0);
        String interpolatorAttr = element.getAttribute("interpolator");
        Interpolator interpolator = this.getInterpolator(interpolatorAttr, Interpolator.EASE_IN);
        return Alpha.byAge(interpolator, start, end);
    }

    *//**
     * Gets the interpolation.
     * @param interpolatorAttr interpolation attribute
     * @param defaultInterpolator default interpolation
     * @return interpolation
     *//*
    private Interpolator getInterpolator(String interpolatorAttr, Interpolator defaultInterpolator) {
        if (interpolatorAttr.equals("noop")) {
            return Interpolator.NOOP;
        } else if (interpolatorAttr.equals("linear")) {
            return Interpolator.LINEAR;
        } else if (interpolatorAttr.equals("ease-in")) {
             return Interpolator.EASE_IN;
        } else if (interpolatorAttr.equals("ease-out")) {
             return Interpolator.EASE_OUT;
        } else if (interpolatorAttr.equals("ease-inout")) {
             return Interpolator.EASE_INOUT;
        } else if (interpolatorAttr.equals("ease-in-back")) {
             return Interpolator.EASE_IN_BACK;
        } else if (interpolatorAttr.equals("ease-out-back")) {
             return Interpolator.EASE_OUT_BACK;
        } else if (interpolatorAttr.equals("bounce-out")) {
             return Interpolator.BOUNCE_OUT;
        } else if (interpolatorAttr.equals("ease-out-elastic")) {
            return Interpolator.EASE_OUT_ELASTIC;
        } else {
            return defaultInterpolator;
        }
    }

    *//**
     * Gets a drag effector.
     * @param element drag xml element
     * @return a drag effector
     *//*
    @SuppressWarnings("unchecked")
    private Effector getDragEffector(XmlObject element) {
        List<String> values = (List<String>) csvConverter.convertFrom(element.getAttribute("value"), null);
        if (values != null) {
            try {
                if (values.size() == 1) {
                    return new Drag(Float.parseFloat(values.get(0)));
                } else if (values.size() == 2) {
                    return new Drag(Float.parseFloat(values.get(0)),
                            Float.parseFloat(values.get(1)));
                }
            } catch (Exception ex) {
                this.logger.warn("ParticleEffectorsConverter | getDragEffector | Could not parse floats.", ex);
            }
        }
        this.logger.warn("ParticleEffectorsConverter | getDragEffector | Invalid value attribute of drag element");
        return null;
    }

    *//**
     * Gets a gravity effector.
     * @param element gravity xml element
     * @return gravity effector
     *//*
    private Effector getGravityEffector(XmlObject element) {
        float accel = element.getFloatAttribute("value", Gravity.EARTH_G);
        return new Gravity(accel);
    }*/

}
