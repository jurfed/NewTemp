package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Action responsible for handle visibility of selected view.
 */
@Reflect_Full
public class ChangeViewVisibilityAction extends ViewAction<ChangeViewVisibilityActionData> {

    /**
     * Initializes a new instance of the {@link ChangeViewVisibilityAction} class
     */
    public ChangeViewVisibilityAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ChangeViewVisibilityAction} class.
     * @param logger      a logger reference
     * @param eventBus    an eventBus reference
     * @param viewManager a viewManager reference
     */
    public ChangeViewVisibilityAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus, viewManager);
    }

    @Override
    public Class<ChangeViewVisibilityActionData> getActionDataType() {
        return ChangeViewVisibilityActionData.class;
    }

    @Override
    protected void execute() {
        targetView.setVisible(actionData.isVisible());
        finish();
    }

}
