package com.atsisa.gox.framework.utility;

import java.util.List;

/**
 * Denotes structures which hold a collection of points.
 */
public interface IPointsHolder {

    /**
     * Gets a collection of points.
     * @return A collection of points.
     */
    Iterable<Point> getPoints();

    /**
     * Sets a list of points.
     * @param points The list of points.
     */
    void setPoints(List<Point> points);
}
