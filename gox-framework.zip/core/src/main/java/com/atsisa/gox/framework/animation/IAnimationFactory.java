package com.atsisa.gox.framework.animation;

/**
 * Gives possibility to create {@link IAnimation} objects.
 */
public interface IAnimationFactory {

    /**
     * Creates a new {@link IAnimation}
     * of given type.
     * @param animationType The animation type to be created.
     * @param <T>           Type of the animation.
     * @return A new animation instance of requested type.
     */
    <T extends IAnimation> T createAnimation(Class<T> animationType);
}
