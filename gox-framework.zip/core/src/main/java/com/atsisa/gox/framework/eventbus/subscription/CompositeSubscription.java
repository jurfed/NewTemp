package com.atsisa.gox.framework.eventbus.subscription;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.eventbus.EventBus;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.gwtent.reflection.client.Reflectable;

import rx.Observer;

/**
 * Composite subscription representation.
 */
@Reflectable
public class CompositeSubscription implements Subscription {

    private final List<AnnotatedSubscriptionMetadata> annotatedSubscriptionMetadata;

    private final Map<Subscription, Observer> subscriptions;

    private final EventBus eventBus;

    private final ILogger logger;

    /**
     * Composite subscription constructor.
     * @param logger                        {@link ILogger}
     * @param eventBus                      {@link EventBus}
     * @param annotatedSubscriptionMetadata list of metadata extracted from annotated observer
     */
    public CompositeSubscription(ILogger logger, EventBus eventBus, List<AnnotatedSubscriptionMetadata> annotatedSubscriptionMetadata) {
        this.annotatedSubscriptionMetadata = annotatedSubscriptionMetadata;
        this.eventBus = eventBus;
        this.logger = logger;
        subscriptions = new HashMap<>();
    }

    @Override
    public void unsubscribe() {
        for (Subscription subscription : subscriptions.keySet()) {
            subscription.unsubscribe();
        }
    }

    @Override
    public boolean isUnsubscribed() {
        boolean result = true;
        for (Subscription subscription : subscriptions.keySet()) {
            if (!subscription.isUnsubscribed()) {
                result = false;
                break;
            }
        }
        return result;
    }

    public void subscribe() throws ReflectionException {
        for (AnnotatedSubscriptionMetadata subscriptionMetadata : annotatedSubscriptionMetadata) {
            SubscriptionBasedObserver observer = new SubscriptionBasedObserver(subscriptionMetadata, logger);
            Subscription subscription = eventBus.register(observer, observer.getEventType());
            subscriptions.put(subscription, observer);
        }
    }
}
