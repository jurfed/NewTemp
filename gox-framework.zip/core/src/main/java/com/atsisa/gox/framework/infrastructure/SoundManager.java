package com.atsisa.gox.framework.infrastructure;

import java.util.*;

import com.atsisa.gox.framework.resource.AbstractSoundResource;
import com.atsisa.gox.framework.resource.IResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.ISoundObjectWrapper;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * Class responsible for playing, looping, stopping and changing volume of the sound based on the id of the sound.
 */
public class SoundManager implements ISoundManager {

    /**
     * Cache for paused sounds by {@link #pauseAllSounds()} method.
     */
    private final List<String> pausedSoundIds = new LinkedList<>();

    /**
     * Reference to sound map, which stores id and reference to sound resource.
     */
    private Map<String, AbstractSoundResource> soundMap = new HashMap<>();

    /**
     * Reference to resource manager.
     */
    private final IResourceManager resourceManager;

    /**
     * Reference to a logger.
     */
    private final ILogger logger;

    /**
     * Constructor. Injects reference to resource manager and logger.
     * @param resourceManager reference to resource manager
     * @param logger          reference to logger
     */
    @Inject
    public SoundManager(IResourceManager resourceManager, ILogger logger) {
        this.resourceManager = resourceManager;
        this.logger = logger;
        logger.trace("SoundManager | ctor");
    }

    /**
     * Validates id of the sound.
     * @param id id of the sound
     */
    public void validate(String id) {
        if (StringUtility.isNullOrEmpty(id)) {
            logger.error("SoundManager | Id is null or empty");
            throw new IllegalArgumentException("SoundManager | Id is null or empty");
        } else if (!soundMap.containsKey(id)) {
            logger.error("SoundManager | Sound not found for: '%s'", id);
            throw new IllegalArgumentException("SoundManager | Sound not found");
        }
    }

    @Override
    public void loadResourcesToManager() {
        List<IResource> resourceList = resourceManager.getAllResources(ResourceType.SOUND);
        soundMap.clear();
        for (IResource resource : resourceList) {
            soundMap.put(resource.getId(), (AbstractSoundResource) resource);
            if (prepareSoundAfterLoad()) {
                prepare(resource.getId());
            }
        }
        logger.debug("SoundManager | number of sounds loaded: %s", soundMap.size());
    }

    @Override
    public void prepareSounds() {
        for (String id : soundMap.keySet()) {
            if (!prepare(id)) {
                logger.warn(StringUtility.format("SoundManager | prepareSounds | Problem with preparing sound with id: %s ", id));
            }
        }
    }

    @Override
    public boolean prepareSoundAfterLoad() {
        return true;
    }

    @Override
    public boolean isPlaying(String id) {
        validate(id);
        logger.debug("SoundManager | isPlaying | soundId: '%s'", id);

        return getSound(id).isPlaying();
    }

    @Override
    public boolean isPaused(String id) {
        validate(id);
        logger.debug("SoundManager | isPaused | soundId: '%s'", id);
        return getSound(id).isPaused();
    }

    @Override
    public boolean resume(String id) {
        validate(id);
        logger.debug("SoundManager | resume | soundId: '%s'", id);
        ISoundObjectWrapper sound = getSound(id);
        return sound.isPaused() && sound.resume();
    }

    @Override
    public boolean play(String id) {
        validate(id);
        logger.debug("SoundManager | play | soundId: '%s'", id);

        ISoundObjectWrapper sound = getSound(id);
        if (isPlaying(id)) {
            sound.stop();
        }
        return sound.play();
    }

    @Override
    public void stop(String id) {
        validate(id);
        logger.debug("SoundManager | stop | soundId: '%s'", id);

        getSound(id).stop();
    }

    @Override
    public void pause(String id) {
        validate(id);
        logger.debug("SoundManager | pause | soundId: '%s'", id);

        getSound(id).pause();
    }

    @Override
    public void setLooping(String id, boolean looping) {
        validate(id);
        logger.debug("SoundManager | setLooping | soundId: '%s'", id);

        getSound(id).setLooping(looping);
    }

    @Override
    public void setVolume(String id, float volume) {
        validate(id);
        logger.debug("SoundManager | setVolume | soundId: '%s'", id);

        if (volume < 0.0f) {
            volume = 0.0f;
        } else if (volume > 1.0f) {
            volume = 1.0f;
        }
        getSound(id).setVolume(volume);
    }

    @Override
    public float getVolume(String id) {
        validate(id);
        logger.debug("SoundManager | volume | soundId: '%s'", id);

        return getSound(id).getVolume();
    }

    @Override
    public int length(String id) {
        validate(id);
        logger.debug("SoundManager | length | soundId: %s", id);

        return getSound(id).length();
    }

    @Override
    public void stopAllSounds() {
        logger.debug("SoundManager | stopAllSounds");
        for (String soundId : soundMap.keySet()) {
            ISoundObjectWrapper sound = getSound(soundId);
            if (sound.isPlaying()) {
                sound.stop();
            }
        }
    }

    @Override
    public void pauseAllSounds() {
        logger.debug("SoundManager | pauseAllSounds");
        synchronized (pausedSoundIds) {
            for (String soundId : soundMap.keySet()) {
                ISoundObjectWrapper sound = getSound(soundId);
                if (sound.isPlaying()) {
                    sound.pause();
                    pausedSoundIds.add(soundId);
                }
            }
        }
    }

    @Override
    public void resumeAllSounds() {
        logger.debug("SoundManager | resumeAllSounds");
        synchronized (pausedSoundIds) {
            for (String soundId : new ArrayList<>(pausedSoundIds)) {
                ISoundObjectWrapper sound = getSound(soundId);
                if (sound.isPaused()) {
                    sound.resume();
                    pausedSoundIds.remove(soundId);
                }
            }
        }
    }

    /**
     * Returns sound from the map.
     * @param id id of the sound
     * @return sound from the map
     */
    private ISoundObjectWrapper getSound(String id) {
        return soundMap.get(id).getSound();
    }

    private boolean prepare(String id) {
        validate(id);
        ISoundObjectWrapper soundObjectWrapper = getSound(id);
        if (!soundObjectWrapper.isReady()) {
            logger.debug("SoundManager | prepare | soundId: '%s'", id);
            return soundObjectWrapper.prepare();
        }
        return false;
    }
}
