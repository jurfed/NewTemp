package com.atsisa.gox.framework.action;

import java.util.List;

/**
 * Meta-data holder for de-serialized queues definition.
 */
public class QueueMetadata {

    /**
     * List of actions.
     */
    private List<Action> actions;

    /**
     * Flag indicating whether a given queue execution should be forced.
     */
    private boolean forced;

    /**
     * Name of a given queue.
     */
    private String name;

    /**
     * Initializes a new instance of the {@link QueueMetadata} class.
     * @param name   the name of the action queue
     * @param forced flag indicating forced execution of the queue
     */
    public QueueMetadata(String name, boolean forced) {
        this.forced = forced;
        this.name = name;
    }

    /**
     * Sets list of actions associated with this queue.
     * @param actions list of actions that are associated with this queue.
     */
    public void setActions(List<Action> actions) {
        this.actions = actions;
    }

    /**
     * Gets list of actions associated with this queue.
     * @return list of actions associated with this queue
     */
    public List<Action> getActions() {
        return actions;
    }

    /**
     * Gets flag indicating forced queue execution.
     * @return true if the execution should be forced, false otherwise
     */
    public boolean isForced() {
        return forced;
    }

    /**
     * Gets name of the action queue.
     * @return string name of the action queue
     */
    public String getName() {
        return name;
    }
}
