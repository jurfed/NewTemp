package com.atsisa.gox.framework.model;

import java.util.Optional;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;

/**
 * Deferred property binding.
 * Resolves binding only on layout model updates
 */
public class DeferredLocalBinding extends AbstractDeferredBinding {

    /**
     * Reflection reference.
     */
    private IReflection reflection;

    /**
     * Initializes a new instance of the {@link DeferredLocalBinding} class.
     * @param propertyValue  property value
     * @param targetProperty target property object
     * @param reflection     reflection helper
     */
    public DeferredLocalBinding(String propertyValue, ObservableProperty targetProperty, IReflection reflection) {
        super(propertyValue, targetProperty);
        this.reflection = reflection;
    }

    /**
     * Initializes a new instance of the {@link DeferredLocalBinding} class.
     * @param propertyValue  property value
     * @param targetProperty target property object
     */
    public DeferredLocalBinding(String propertyValue, ObservableProperty targetProperty) {
        this(propertyValue, targetProperty, GameEngine.current().getUtility().getReflection());
    }

    @Override
    protected Optional<IObservableProperty> obtainObservableProperty(ScreenModel model) {
        String[] methodNameArr = propertyValue.split("\\.");
        Object currentModel = model;
        for (int i = 0; i < methodNameArr.length; i++) {
            String methodName = methodNameArr[i];
            Method method = reflection.getMethod(currentModel.getClass(), methodName);
            if (method != null) {
                try {
                    IObservableProperty observableProperty = (IObservableProperty) method.invoke(currentModel);
                    if (i < methodNameArr.length - 1) {
                        currentModel = observableProperty.get();
                    } else {
                        return Optional.of(observableProperty);
                    }
                } catch (ReflectionException e) {
                    logger.error("DeferredExternalBinding | setModel | Unable to invoke " + methodName
                            + "() setMethod, which should return an IObservableProperty object", e);
                    update();
                    return Optional.empty();
                }
            } else {
                logger.error("DeferredExternalBinding | setModel | Requested setMethod " + methodName
                        + "(), which should return an IObservableProperty object, could not be found!");
                update();
                return Optional.empty();
            }
        }

        return Optional.empty();
    }
}
