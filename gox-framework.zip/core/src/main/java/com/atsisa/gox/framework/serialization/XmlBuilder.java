package com.atsisa.gox.framework.serialization;

/**
 * XML Builder implementation. Useful for convenient creation of XML in code.
 */
public class XmlBuilder {

    /**
     * Current XML element object.
     */
    private XmlObject currentObject;

    /**
     * XML object document.
     */
    private XmlObjectDocument xmlObjectDocument;

    /**
     * A value indicating whether document has been ended.
     */
    private boolean documentEnded = false;

    /**
     * Starts a new XML element with empty namespace. If there was no previous element
     * the new element becomes a root element, otherwise it becomes a child of the current node.
     * @param name element name
     * @return xml builder
     */
    public XmlBuilder startElement(String name) {
        return startElement(name, null);
    }

    /**
     * Starts a new XML element with specified namespace. If there was no previous element the new element becomes a root element, otherwise it becomes a child
     * of the current node.
     * @param name      element name
     * @param namespace element namespace
     * @return xml builder
     */
    public XmlBuilder startElement(String name, String namespace) {
        if (currentObject == null) {
            xmlObjectDocument = new XmlObjectDocument();
        }

        XmlObject newObject = xmlObjectDocument.createElement(name, currentObject, namespace);
        if (currentObject == null) {
            xmlObjectDocument.setDocumentElement(newObject);
        } else {
            currentObject.addChild(newObject);
        }

        currentObject = newObject;
        return this;
    }

    /**
     * Writes an attribute to the current XML element.
     * @param name  attribute name
     * @param value attribute value
     * @return xml builder
     */
    public XmlBuilder writeAttribute(String name, String value) {
        validateCurrent();
        currentObject.addAttribute(name, value);
        return this;
    }

    /**
     * Ends a XML element. If the root element was reached the setMethod ends the whole XML document.
     * Otherwise it returns to the parent of the current node.
     * @return xml builder
     */
    public XmlBuilder endElement() {
        validateCurrent();
        if (currentObject.getParent() != null) {
            currentObject = currentObject.getParent();
        } else {
            documentEnded = true;
        }
        return this;
    }

    /**
     * Writes a value into current XML element.
     * @param value a node value transformed to string
     * @return xml builder
     */
    public XmlBuilder writeValue(Object value) {
        if (value != null) {
            return writeValue(value.toString());
        }
        return writeValue("");
    }

    /**
     * Writes a value into current XML element.
     * @param value a node value
     * @return xml builder
     */
    public XmlBuilder writeValue(String value) {
        validateCurrent();
        if (!currentObject.hasChildren()) {
            currentObject.setValue(value);
        } else {
            throw new UnsupportedOperationException("Cannot assign value to an element with children!");
        }
        return this;
    }

    /**
     * Validates if current element is not null and the document has not yet been closed.
     */
    private void validateCurrent() {
        if (currentObject == null) {
            throw new UnsupportedOperationException("Current XML element not defined!");
        }
        if (documentEnded) {
            throw new UnsupportedOperationException("XML root element has been finished!");
        }
    }

    /**
     * Returns the xml string representation of the root XML element.
     * @return the xml string representation of the root XML element
     */
    public String toXmlString() {
        return toXmlObject().toXmlString();
    }

    /**
     * Returns the xml object representing the root element of the document.
     * @return the xml object representing the root element of the document
     */
    public XmlObject toXmlObject() {
        if (documentEnded) {
            return currentObject;
        } else {
            throw new UnsupportedOperationException("XML root element not been finished!");
        }
    }
}
