package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Pauses currently active queue, processes another action queue which name is defined in the ExecuteQueueActionData structure and returns to previously
 * paused queue.
 */
@Reflect_Mini
public class ExecuteNowAction extends Action<ExecuteQueueActionData> {

    /**
     * An action manager reference.
     */
    private final IActionManager actionManager;

    /**
     * Creates a new instance of the ExecuteNowAction class.
     */
    public ExecuteNowAction() {
        actionManager = GameEngine.current().getActionManager();
    }

    /**
     * Creates a new instance of the ExecuteNowAction class.
     * @param logger        a logger reference
     * @param eventBus      an eventBus reference
     * @param actionManager an actionManager reference
     */
    public ExecuteNowAction(ILogger logger, IEventBus eventBus, IActionManager actionManager) {
        super(logger, eventBus);
        this.actionManager = actionManager;
    }

    @Override
    public Class<ExecuteQueueActionData> getActionDataType() {
        return ExecuteQueueActionData.class;
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || StringUtility.isNullOrEmpty(actionData.getQueueName())) {
            throw new ValidationException("The queue name cannot be null or empty.");
        }
    }

    /**
     * Pauses active queue, processes queue and returns to active queue.
     */
    @Override
    protected void execute() {
        String queueName = actionData.getQueueName();
        actionManager.processQueue(queueName);
    }
}
