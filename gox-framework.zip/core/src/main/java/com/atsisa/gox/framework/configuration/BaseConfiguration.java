package com.atsisa.gox.framework.configuration;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.action.ActionBinding;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.SkinListConverter;
import com.atsisa.gox.framework.view.Skin;
import com.gwtent.reflection.client.Reflectable;

/**
 * Base configuration class. Exposes all configuration properties
 */
@XmlElement
@Reflectable
public class BaseConfiguration implements IConfiguration {

    /**
     * A list of action bindings.
     */
    @XmlCollectionElement(name = "ActionBindings", itemName = "Binding", itemType = ActionBinding.class)
    private final List<ActionBinding> actionBindings = new ArrayList<>();

    /**
     * A list of skins.
     */
    @XmlElement(name = "Skins", converters = SkinListConverter.class)
    private final List<Skin> skinList = new ArrayList<>();

    /**
     * A list of properties.
     */
    @XmlCollectionElement(name = "Properties", itemName = "Property", itemType = ConfigurationProperty.class)
    private final List<ConfigurationProperty> properties = new ArrayList<>();

    /**
     * Action module list.
     */
    @XmlCollectionElement(name = "ActionModules", itemName = "ActionModule", itemType = String.class)
    private final List<String> actionModules = new ArrayList<>();

    /**
     * View module list.
     */
    @XmlCollectionElement(name = "ViewModules", itemName = "ViewModules", itemType = String.class)
    private final List<String> viewModules = new ArrayList<>();

    /**
     * Screens module list.
     */
    @XmlCollectionElement(name = "Screens", itemName = "Screen", itemType = String.class)
    private final List<String> screens = new ArrayList<>();

    @Override
    public List<ActionBinding> getActionBindings() {
        return actionBindings;
    }

    @Override
    public List<Skin> getSkinList() {
        return skinList;
    }

    @Override
    public List<ConfigurationProperty> getProperties() {
        return properties;
    }

    @Override
    public Object getProperty(String name) {
        for (ConfigurationProperty property : properties) {
            if (property.getName().equals(name)) {
                return property.getValue();
            }
        }
        return null;
    }

    @Override
    public List<String> getActionModules() {
        return actionModules;
    }

    @Override
    public List<String> getViewModules() {
        return viewModules;
    }

    @Override
    public List<String> getScreens() {
        return screens;
    }

    @Override
    public void merge(IConfiguration otherConfig) {
        actionBindings.addAll(otherConfig.getActionBindings());
        skinList.addAll(otherConfig.getSkinList());
        properties.addAll(otherConfig.getProperties());

        viewModules.addAll(otherConfig.getViewModules());
        actionModules.addAll(otherConfig.getActionModules());
        screens.addAll(otherConfig.getScreens());
    }
}
