package com.atsisa.gox.framework.animation;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data container for view animation.
 */
@XmlElement
@Reflect_Full
public class TweenViewAnimationData {

    /**
     * Length of animation.
     */
    @XmlElement
    private float timeSpan;

    /**
     * Destination X - coordinate.
     */
    @XmlElement
    private Float destinationX;

    /**
     * Destination Y - coordinate.
     */
    @XmlElement
    private Float destinationY;

    /**
     * Destination alpha level.
     */
    @XmlElement
    private Float destinationAlpha;

    /**
     * How much scale in X.
     */
    @XmlElement
    private Float destinationScaleX;

    /**
     * How much scale in Y.
     */
    @XmlElement
    private Float destinationScaleY;

    /**
     * Destination width of view object.
     */
    @XmlElement
    private Float destinationWidth;

    /**
     * Destination height of view object.
     */
    @XmlElement
    private Float destinationHeight;

    /**
     * Id of the sound.
     */
    @XmlElement
    private String soundId;

    /**
     * Delay before start animation.
     */
    @XmlElement
    private float delay;

    /**
     * Gets length of animation.
     * @return time in milliseconds
     */
    public float getTimeSpan() {
        return timeSpan;
    }

    /**
     * Sets length of animation.
     * @param timeLength time in milliseconds
     */
    public void setTimeSpan(float timeLength) {
        timeSpan = timeLength;
    }

    /**
     * Gets the delay before animation starts.
     * @return time in seconds
     */
    public float getDelay() {
        return delay;
    }

    /**
     * Sets the delay before animation starts.
     * @param value time in seconds
     */
    public void setDelay(float value) {
        delay = value;
    }

    /**
     * Gets the destination X coordinate of view object.
     * @return float
     */
    public Float getDestinationX() {
        return destinationX;
    }

    /**
     * Sets the destination X coordinate of view object.
     * @param value float
     */
    public void setDestinationX(Float value) {
        destinationX = value;
    }

    /**
     * Gets the destination Y coordinate of view object.
     * @return float
     */
    public Float getDestinationY() {
        return destinationY;
    }

    /**
     * Sets the destination Y coordinate of view object.
     * @param value float
     */
    public void setDestinationY(Float value) {
        destinationY = value;
    }

    /**
     * Gets the destination alpha level.
     * @return - alpha between 0 and 1f
     */
    public Float getDestinationAlpha() {
        return destinationAlpha;
    }

    /**
     * Sets the destination alpha level.
     * @param value - alpha between 0 and 1f
     */
    public void setDestinationAlpha(Float value) {
        destinationAlpha = value;
    }

    /**
     * Gets the horizontal scale (percentage) of an destination view.
     * @return float
     */
    public Float getDestinationScaleX() {
        return destinationScaleX;
    }

    /**
     * Sets the horizontal scale (percentage) of an destination view.
     * @param value float
     */
    public void setDestinationScaleX(Float value) {
        destinationScaleX = value;
    }

    /**
     * Gets the vertical scale (percentage) of an destination view.
     * @return float
     */
    public Float getDestinationScaleY() {
        return destinationScaleY;
    }

    /**
     * Sets the vertical scale (percentage) of an destination view.
     * @param value float
     */
    public void setDestinationScaleY(Float value) {
        destinationScaleY = value;
    }

    /**
     * Gets the destination width of view object.
     * @return width in pixels.
     */
    public Float getDestinationWidth() {
        return destinationWidth;
    }

    /**
     * Sets the destination width of view object.
     * @param value width in pixels.
     */
    public void setDestinationWidth(Float value) {
        destinationWidth = value;
    }

    /**
     * Gets the destination height of view object.
     * @return height in pixels
     */
    public Float getDestinationHeight() {
        return destinationHeight;
    }

    /**
     * Sets the destination height of view object.
     * @param value height in pixels
     */
    public void setDestinationHeight(Float value) {
        destinationHeight = value;
    }

    /**
     * Gets sound id.
     * @return sound id
     */
    public String getSoundId() {
        return soundId;
    }

    /**
     * Sets sound id.
     * @param soundId - sound id
     */
    public void setSoundId(String soundId) {
        this.soundId = soundId;
    }
}
