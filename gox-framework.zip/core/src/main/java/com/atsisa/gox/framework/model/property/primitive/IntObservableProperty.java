package com.atsisa.gox.framework.model.property.primitive;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservablePropertyContainer;

/**
 * A container class for primitive explicitly typed properties.
 */
public class IntObservableProperty extends ObservablePropertyContainer implements IObservableProperty {

    /**
     * Mutable boxing type for integer primitive holding old value.
     */
    private PrimitiveIntBox oldValueBox = new PrimitiveIntBox(0);

    /**
     * Mutable boxing type for integer primitive holding new value.
     */
    private PrimitiveIntBox newValueBox = new PrimitiveIntBox(0);

    /**
     * The value.
     */
    private int value;

    /**
     * The oldValue.
     */
    private int oldValue = Integer.MIN_VALUE;

    /**
     * The default value.
     */
    private int defaultValue;

    @Override
    public boolean hasDefaultValue() {
        return value == defaultValue;
    }

    @Override
    public Object getDefaultValue() {
        return defaultValue;
    }

    @Override
    public Class getType() {
        return int.class;
    }

    @Override
    public Object get() {
        return value;
    }

    @Override
    public boolean set(Object value) {
        return set((int) value);
    }

    public int getPrimitive() {
        return value;
    }

    @Override
    public void setDefaultValue(Object defaultValue) {
        this.defaultValue = (int) defaultValue;
    }

    /**
     * Sets the property value and notifies listeners about changes. Notification will only be triggered if the actual value has changed.
     * @param newValue new property value
     * @return true if a new value differs from the current value, false otherwise
     */
    public boolean set(int newValue) {
        if (value != newValue) {
            oldValue = value;
            oldValueBox.setValue(oldValue);
            value = newValue;
            newValueBox.setValue(value);
            notifyPropertyChanged(this, oldValueBox.getValue(), newValueBox.getValue());
            return true;
        }
        return false;
    }

}
