package com.atsisa.gox.framework.model;

/**
 * Layout behaviour listener. Exposes methods for layout state notifications.
 */
public interface ILayoutListener {

    /**
     * Called when the layout state changes.
     * @param layout    source layout
     * @param eventType type of a layout event
     */
    void onLayoutEvent(Layout layout, LayoutEventType eventType);
}
