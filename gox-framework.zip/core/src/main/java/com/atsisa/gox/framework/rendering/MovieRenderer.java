package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.IMovieLayer;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.IMovieCompleteListener;
import com.atsisa.gox.framework.view.MovieView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Base movie renderer.
 */
public class MovieRenderer extends LayerRenderer implements IMovieRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the MovieRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public MovieRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    /**
     * Gets a view class type.
     * @return MovieView.class
     */
    @Override
    public Class<?> getType() {
        return MovieView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        if (viewType == ViewType.MOVIE_VIEW) {
            lv.leftChanges = changes;
            lv.layer = (IMovieLayer) getViewLayer(view);
            lv.movieView = (MovieView) view;
            if (BitUtility.isSet(lv.leftChanges, MovieView.ViewPropertyName.MOVIE)) {
                lv.layer.setMovieFile(lv.movieView.getMovieResource());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, MovieView.ViewPropertyName.MOVIE);
            }
            if (BitUtility.isSet(lv.leftChanges, MovieView.ViewPropertyName.VOLUME)) {
                lv.layer.setVolume(lv.movieView.getVolume());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, MovieView.ViewPropertyName.VOLUME);
            }
            if (BitUtility.isSet(lv.leftChanges, MovieView.ViewPropertyName.STATE)) {
                MovieView.State movieState = lv.movieView.getCurrentState();
                if (movieState == MovieView.State.PAUSE) {
                    lv.layer.pause();
                } else if (movieState == MovieView.State.PLAYING) {
                    lv.layer.play();
                } else if (movieState == MovieView.State.STOPPED) {
                    lv.layer.stop();
                }
                lv.leftChanges = BitUtility.unset(lv.leftChanges, MovieView.ViewPropertyName.STATE);
            }
            if (BitUtility.isSet(lv.leftChanges, MovieView.ViewPropertyName.LOOP)) {
                lv.layer.setLoop(lv.movieView.isLoop());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, MovieView.ViewPropertyName.LOOP);
            }
            return lv.leftChanges;
        }
        return super.render(view, viewType, changes);
    }

    @Override
    public void registerCompleteListener(MovieView view, final IMovieCompleteListener listener) {
        IMovieLayer layer = (IMovieLayer) getViewLayer(view);
        layer.setOnCompletionListener(listener);
    }

    @Override
    public boolean unregisterCompleteListener(MovieView view, IMovieCompleteListener listener) {
        IMovieLayer layer = (IMovieLayer) getViewLayer(view);
        return layer.removeOnCompleteListener();
    }

    @Override
    public int getVideoHeight(MovieView view) {
        IMovieLayer layer = (IMovieLayer) getViewLayer(view);
        return layer.getVideoHeight();
    }

    @Override
    public int getVideoWidth(MovieView view) {
        IMovieLayer layer = (IMovieLayer) getViewLayer(view);
        return layer.getVideoWidth();
    }

    /**
     * Creates and returns new IMovieLayer platform specific implementation.
     * @param view - View
     * @return IMovieLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected IMovieLayer createLayer(View view) {
        return getLayerFactory().createMovieLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link MovieRenderer} render method.
     */
    private class LocalVariables {

        private IMovieLayer layer;

        private MovieView movieView;

        private int leftChanges;
    }
}
