package com.atsisa.gox.framework.utility.reflection;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Abstract reflection class.
 */
public abstract class AbstractReflection implements IReflection {

    private static final String BOOLEAN_GETTER_PREFIX = "is";

    private static final String GETTER_PREFIX = "get";

    private static final String SETTER_PREFIX = "set";

    @Override
    public Method fetchGetter(Class<?> objType, Field field) throws ReflectionException {
        String getterName = (getSimpleName(field.getType()).equalsIgnoreCase("boolean") ? BOOLEAN_GETTER_PREFIX : GETTER_PREFIX) + StringUtility
                .toUpperFirst(field.getName());
        Method getter = fetchMethod(objType, getterName);
        if (getter == null) {
            throw new ReflectionException(StringUtility.format("Could not find getter for field '%s' (%s).", field.getName(), getterName));
        }
        return getter;
    }

    @Override
    public Method fetchSetter(Class<?> objType, Field field) throws ReflectionException {
        String setterName = SETTER_PREFIX + StringUtility.toUpperFirst(field.getName());
        Method setter = fetchMethod(objType, setterName);
        if (setter == null) {
            throw new ReflectionException(StringUtility.format("Could not find setter for field '%s' (%s).", field.getName(), setterName));
        }
        return setter;
    }

    @Override
    public Method fetchMethod(Class<?> objType, String methodName) {
        while (true) {
            Method[] methods = getMethods(objType);
            for (Method method : methods) {
                if (method.getName().equals(methodName) && method.isPublic() && !method.isStatic()) {
                    return method;
                }
            }
            Class<?> superClass = objType.getSuperclass();
            if (superClass != null && superClass != Object.class) {
                objType = superClass;
                continue;
            }
            return null;
        }
    }

    @Override
    public Object createInstance(String typeName) throws ReflectionException {
        Class<?> type = getClassForName(typeName);
        return createInstance(type);
    }
}
