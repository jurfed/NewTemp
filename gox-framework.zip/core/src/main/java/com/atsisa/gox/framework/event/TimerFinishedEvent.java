package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.utility.timer.ITimer;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Occurs when a {@link ITimer} component finishes its time measurement.
 */
@Reflect_Mini
public final class TimerFinishedEvent {

    /**
     * The timer.
     */
    private final ITimer timer;

    /**
     * Initializes a new instance of the {@link TimerFinishedEvent}
     * class.
     * @param timer Corresponding timer.
     */
    public TimerFinishedEvent(ITimer timer) {
        this.timer = timer;
    }

    /**
     * Gets the timer this event was triggered by.
     * @return The timer corresponding to this event.
     */
    public ITimer getTimer() {
        return timer;
    }
}
