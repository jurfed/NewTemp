package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.utility.Rectangle;

/**
 * Exposes methods for basic renderer layer.
 */
public interface ILayer extends IDisposable {

    /**
     * Gets alpha of this layer.
     * @return float
     */
    float getAlpha();

    /**
     * Sets alpha of this layer.
     * @param alpha - float
     */
    void setAlpha(float alpha);

    /**
     * Gets position x of this layer.
     * @return float
     */
    float getX();

    /**
     * Gets position y of this layer.
     * @return float
     */
    float getY();

    /**
     * Sets position x of this layer.
     * @param x - float
     */
    void setX(float x);

    /**
     * Sets position y of this layer.
     * @param y - float
     */
    void setY(float y);

    /**
     * Sets visible of this layer.
     * @param visible - boolean
     */
    void setVisible(boolean visible);

    /**
     * Returns a boolean value that indicates whether this layer is visible or not.
     * @return boolean
     */
    boolean isVisible();

    /**
     * Sets mask of this layer.
     * @param maskRect - Rectangle
     */
    void setMask(Rectangle maskRect);

    /**
     * Returns parent of this layer.
     * @return ILayerContainer
     */
    ILayerContainer getParentContainer();

    /**
     * Sets scale x of this layer.
     * @param scale - float
     */
    void setScaleX(float scale);

    /**
     * Sets scale y of this layer.
     * @param scale - float
     */
    void setScaleY(float scale);

    /**
     * Returns scale x layer.
     * @return float
     */
    float getScaleX();

    /**
     * Returns scale y layer.
     * @return float
     */
    float getScaleY();

    /**
     * Disposes this layer.
     */
    void dispose();

    /**
     * Sets height for this layer.
     * @param height - float
     */
    void setHeight(float height);

    /**
     * Sets width for this layer.
     * @param width - float
     */
    void setWidth(float width);

    /**
     * Returns height of this layer.
     * @return float
     */
    float getHeight();

    /**
     * Returns width of this layer.
     * @return float
     */
    float getWidth();

    /**
     * Sets rotation for this layer.
     * @param rotation - float
     */
    void setRotation(float rotation);

    /**
     * Sets pivot for this layer.
     * @param x - float
     * @param y - float
     */
    void setOrigin(float x, float y);

}
