package com.atsisa.gox.framework.resource;

/**
 * Abstract image resource class.
 */
public abstract class AbstractImageResource<T extends IImageObjectWrapper> extends AbstractResource implements IImageReference<T> {

    /**
     * Array containing supported extensions of the files.
     */
    private static final String[] SUPPORTED_EXTENSIONS = { ".jpg", ".png" };

    /**
     * Represents Image object for specific platform.
     */
    private T imageObjectWrapper;

    /**
     * Creates resource object with given description.
     * @param description resource description object
     */
    public AbstractImageResource(ResourceDescription description) {
        super(description, ResourceType.IMAGE);
    }

    /**
     * Gets an image wrapper object for specific platform.
     * @return an image wrapper object
     */
    @Override
    public T getImageWrapperObject() {
        return imageObjectWrapper;
    }

    @Override
    public String[] getSupportedExtensions() {
        return SUPPORTED_EXTENSIONS;
    }

    /**
     * Sets an image wrapper object for specific platform.
     * @param imageObjectWrapper an image wrapper object
     */
    protected void setImageWrapperObject(T imageObjectWrapper) {
        this.imageObjectWrapper = imageObjectWrapper;
    }
}
