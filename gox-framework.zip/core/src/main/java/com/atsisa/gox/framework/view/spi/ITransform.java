package com.atsisa.gox.framework.view.spi;

/**
 * Exposes methods for transform object.
 */
public interface ITransform {

    /**
     * The total number of modifiers vertices.
     */
    int NUMBER_VERTICES = 8;

    /**
     * Index position for the top left x apex modifier.
     */
    int TOP_LEFT_X = 0;

    /**
     * Index position for the top left y apex modifier.
     */
    int TOP_LEFT_Y = 1;

    /**
     * Index position for the top right x apex modifier.
     */
    int TOP_RIGHT_X = 2;

    /**
     * Index position for the top right y apex modifier.
     */
    int TOP_RIGHT_Y = 3;

    /**
     * Index position for the bottom right x apex modifier.
     */
    int BOTTOM_RIGHT_X = 4;

    /**
     * Index position for the bottom right y apex modifier.
     */
    int BOTTOM_RIGHT_Y = 5;

    /**
     * Index position for the bottom left x apex modifier.
     */
    int BOTTOM_LEFT_X = 6;

    /**
     * Index position for the bottom left y apex modifier.
     */
    int BOTTOM_LEFT_Y = 7;

    /**
     * Sets apex modifier for x top left corner.
     * @param x float
     */
    void setTopLeftX(float x);

    /**
     * Sets apex modifier for y top left corner.
     * @param y float
     */
    void setTopLeftY(float y);

    /**
     * Sets apex modifier for x top right corner.
     * @param x float
     */
    void setTopRightX(float x);

    /**
     * Sets apex modifier for y top right corner.
     * @param y float
     */
    void setTopRightY(float y);

    /**
     * Sets apex modifier for x bottom right corner.
     * @param x float
     */
    void setBottomRightX(float x);

    /**
     * Sets apex modifier for y bottom right corner.
     * @param y float
     */
    void setBottomRightY(float y);

    /**
     * Sets apex modifier for x bottom left corner.
     * @param x float
     */
    void setBottomLeftX(float x);

    /**
     * Sets apex modifier for y bottom left corner.
     * @param y float
     */
    void setBottomLeftY(float y);

    /**
     * Gets list of modifiers vertices.
     * @return list of vertices
     */
    float[] getVertices();

    /**
     * Gets apex modifier for specific corner.
     * @param index position of modifier (use const from ITransform to identify position of specific modifier)
     * @return apex modifier
     */
    float getApex(int index);

    /**
     * Returns a boolean value that indicates whether this transform is zeroed or not.
     * @return boolean
     */
    boolean isZeroed();
}
