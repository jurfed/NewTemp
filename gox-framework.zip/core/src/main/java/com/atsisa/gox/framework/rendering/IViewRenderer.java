package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Exposes an abstraction layers for rendering specific views.
 */
public interface IViewRenderer extends IDisposable{

    /**
     * Gets a view class type.
     * @return a view class type.
     */
    Class<?> getType();

    /**
     * Renders a View based on its properties.
     * @param view     - View
     * @param viewType - ViewType
     * @param changes  - int
     * @return int
     */
    int render(View view, ViewType viewType, int changes);

    /**
     * Removes a View from the rendering cache.
     * @param view view to remove
     * @return true if operation succeeded, false otherwise
     */
    boolean dispose(View view);

    /**
     * Gets a rendering content for specific view.
     * @param view the view which rendering content should regard to
     * @return a rendering content
     */
    ILayer getContent(View view);

    /**
     * Registers specified view in the renderer and returns associated layers.
     * @param view - View
     * @return Object - ILayer
     */
    ILayer registerView(View view);
}
