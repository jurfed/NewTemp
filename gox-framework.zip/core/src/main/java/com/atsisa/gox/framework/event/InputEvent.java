package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.view.View;

/**
 * Represents input events regarding interactive views.
 */
public class InputEvent implements IEvent {

    /**
     * Input event type.
     */
    private InputEventType type;

    /**
     * Source of the event.
     */
    private View source;

    /**
     * Initializes a new instance of the InputEvent class.
     * @param type   input event type
     * @param source source of the event
     */
    public InputEvent(InputEventType type, View source) {
        this.type = type;
        this.source = source;
    }

    /**
     * Gets the event type.
     * @return event type
     */
    public InputEventType getType() {
        return type;
    }

    /**
     * Gets the source of the event.
     * @return the source of the event
     */
    @Override
    public View getSource() {
        return source;
    }

    @Override
    public void setSource(Object source) {
        this.source = (View) source;
    }

    /**
     * Sets the event type.
     * @param inputEventType input event type
     */
    public void setType(InputEventType inputEventType) {
        type = inputEventType;
    }

}
