package com.atsisa.gox.framework.utility.timer;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.command.CancelTimerCommand;
import com.atsisa.gox.framework.command.StartTimerCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Manages timers across the framework.
 */
@Reflect_Mini
public class TimerManager implements ITimerManager {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The timers.
     */
    private final Map<String, ITimer> timers;

    /**
     * The logger.
     */
    private final ILogger logger;

    /**
     * The renderer.
     */
    private final IRenderer renderer;

    /**
     * Initializes a new instance of the {@link TimerManager} using given event bus as a communication medium.
     * @param eventBus {@link IEventBus}
     * @param logger   {@link ILogger}
     * @param renderer {@link IRenderer}
     */
    @Inject
    public TimerManager(IEventBus eventBus, ILogger logger, IRenderer renderer) {
        this.eventBus = eventBus;
        this.logger = logger;
        this.renderer = renderer;
        timers = new HashMap<>();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new StartTimerCommandObserver(), StartTimerCommand.class);
        eventBus.register(new CancelTimerCommandObserver(), CancelTimerCommand.class);
    }

    @Override
    public ITimer getTimer(String timerName) {
        return timers.get(timerName);
    }

    @Override
    public boolean hasTimer(String timerName) {
        return timers.containsKey(timerName);
    }

    /**
     * Handles timer starting requests.
     * @param startTimerCommand The starting request.
     */
    @Subscribe
    public void handle(StartTimerCommand startTimerCommand) {
        ITimer timer = timers.get(startTimerCommand.getTimerName());
        if (timer == null) {
            timer = createTimer(startTimerCommand.getTimerName(), startTimerCommand.getDuration());
            timers.put(timer.getName(), timer);
        } else {
            if (timer.isActive()) {
                timer.cancel();
            }
            timer.setTimeSpan(startTimerCommand.getDuration());
        }
        timer.start();
    }

    /**
     * Handles timer cancellation requests.
     * @param cancelTimerCommand The cancellation request.
     */
    @Subscribe
    public void handle(CancelTimerCommand cancelTimerCommand) {
        ITimer timer = timers.get(cancelTimerCommand.getTimerName());
        if (timer != null) {
            timer.cancel();
        } else {
            logger.warn("Unable to cancel timer named '%s'. No such timer has been registered.", cancelTimerCommand.getTimerName());
        }
    }

    /**
     * Creates a new instance of a timer.
     * @param timerName The timer name.
     * @param timeSpan  The time span.
     * @return A new timer.
     */
    private ITimer createTimer(String timerName, int timeSpan) {
        return new Timer(timerName, timeSpan, eventBus, renderer, logger);
    }

    private class StartTimerCommandObserver extends NextObserver<StartTimerCommand> {

        @Override
        public void onNext(StartTimerCommand startTimerCommand) {
            handle(startTimerCommand);
        }
    }

    private class CancelTimerCommandObserver extends NextObserver<CancelTimerCommand> {

        @Override
        public void onNext(CancelTimerCommand cancelTimerCommand) {
            handle(cancelTimerCommand);
        }
    }
}
