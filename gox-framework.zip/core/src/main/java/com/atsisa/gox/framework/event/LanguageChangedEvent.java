package com.atsisa.gox.framework.event;

import java.util.Map;

/**
 * An event triggered when language was changed.
 */
public class LanguageChangedEvent {

    /**
     * New language code.
     */
    private final String languageCode;

    /**
     * Translations map.
     */
    private final Map<String, String> translations;

    /**
     * Initializes a new instance of the {@link LanguageChangedEvent} class.
     * @param languageCode new lang code.
     * @param translations map with translations.
     */
    public LanguageChangedEvent(String languageCode, Map<String, String> translations) {
        this.languageCode = languageCode;
        this.translations = translations;
    }

    /**
     * Gets a new language code.
     * @return language code.
     */
    public String getLanguageCode() {
        return languageCode;
    }

    /**
     * Gets translations map for new language.
     * @return map with translations.
     */
    public Map<String, String> getTranslations() {
        return translations;
    }
}
