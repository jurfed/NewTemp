package com.atsisa.gox.framework.utility;

/**
 * Timeout callback interface.
 */
public interface TimeoutCallback {

    /**
     * Called when time is up.
     */
    void onTimeout();

}
