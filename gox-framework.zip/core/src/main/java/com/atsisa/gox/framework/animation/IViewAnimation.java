package com.atsisa.gox.framework.animation;

import com.atsisa.gox.framework.view.View;

/**
 * Represents an animation with {@link View}
 * as its target.
 */
public interface IViewAnimation extends IAnimation {

    /**
     * Gets the target of this animation.
     * @return The view this animation concerns.
     */
    View getTargetView();
}
