package com.atsisa.gox.framework.model.property;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.model.IPropertyChangingListener;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * A property container base class. Which extend ViewProperty class adding a behaviour which inform about that value is changing.
 * @param <T> type of the view property
 */
public class ExtendedViewProperty<T> extends ViewProperty<T> {

    /**
     * Class field definition of index variable in notifyPropertyChanging method.
     */
    private int index;

    /**
     * Class field definition of size variable used in notifyPropertyChanging method.
     */
    private int size;

    /**
     * A list of property will be changed listeners.
     */
    private final List<IPropertyChangingListener> propertyChangingListeners;

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param type             type of the property's value
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     */
    public ExtendedViewProperty(Class<T> type, View view, ViewType viewType, int viewPropertyName) {
        super(type, view, viewType, viewPropertyName);
        propertyChangingListeners = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param type             type of the property's value
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     * @param defaultValue     default property's value
     */
    public ExtendedViewProperty(Class<T> type, View view, ViewType viewType, int viewPropertyName, T defaultValue) {
        super(type, view, viewType, viewPropertyName, defaultValue);
        propertyChangingListeners = new ArrayList<>();
    }

    /**
     * Adds a property changing listener.
     * @param listener property will be changed listener
     */
    public void addPropertyChangingListener(IPropertyChangingListener<T> listener) {
        if (!propertyChangingListeners.contains(listener)) {
            propertyChangingListeners.add(listener);
        }
    }

    /**
     * Removes a property changing listener.
     * @param listener property will be changed listener
     */
    public void removePropertyChangingListener(IPropertyChangingListener<T> listener) {
        propertyChangingListeners.remove(listener);
    }

    @Override
    public boolean set(T newValue) {
        if (isChangePossible(newValue)) {
            notifyPropertyChanging(this, get(), newValue);
            return super.set(newValue);
        }
        return false;
    }

    @Override
    public boolean set(T newValue, boolean notify) {
        if (isChangePossible(newValue)) {
            if (notify) {
                notifyPropertyChanging(this, get(), newValue);
            }
            return super.set(newValue, notify);
        }
        return false;
    }

    /**
     * Notifies all listeners that a property changing.
     * @param property     observable property
     * @param currentValue current value
     * @param newValue     new value
     */
    @SuppressWarnings("unchecked")
    private void notifyPropertyChanging(ObservableProperty property, Object currentValue, Object newValue) {
        size = propertyChangingListeners.size();
        for (index = 0; index < size; index++) {
            propertyChangingListeners.get(index).propertyChanging(property, currentValue, newValue);
        }
    }

    /**
     * Checks if change is possible.
     * @param newValue new property value
     * @return boolean
     */
    private boolean isChangePossible(T newValue) {
        if (get() == null) {
            if (newValue != null) {
                return true;
            }
        } else if (!get().equals(newValue)) {
            return true;
        }
        return false;
    }

}
