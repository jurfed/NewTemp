package com.atsisa.gox.framework.serialization.interceptor;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import com.atsisa.gox.framework.model.DeferredExternalBinding;
import com.atsisa.gox.framework.model.DeferredLocalBinding;
import com.atsisa.gox.framework.model.DeferredTemplateBinding;
import com.atsisa.gox.framework.model.PropertyBinding;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.serialization.ISetterInterceptor;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.Field;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.framework.view.View;
import com.google.gwt.regexp.shared.MatchResult;
import com.google.gwt.regexp.shared.RegExp;

/**
 * Model binding interceptor.
 * Intercepts a moments of deserialization,
 * creates and caches proper view-model binding objects.
 */
public class ModelBindingInterceptor implements ISetterInterceptor {

    /**
     * A reflection reference.
     */
    private IReflection reflection;

    /**
     * A logger reference.
     */
    private ILogger logger;

    /**
     * Binding starting tag.
     */
    private static final String START_TAG_LOCAL = "{";

    /**
     * Binding starting tag.
     */
    private static final String START_TAG_EXTERNAL = "{#";

    /**
     * Binding ending tag.
     */
    private static final String END_TAG = "}";

    /**
     * Regex for finding properties.
     */
    private static final RegExp TEMPLATE_PROPERTY_REGEX = RegExp.compile("\\{#(.*?)\\}");

    /**
     * A cached list of model bindings.
     */
    private List<PropertyBinding> bindings;

    /**
     * Initializes a new instance of the ModelBindingInterceptor class.
     * @param reflection reflection helper reference
     * @param logger     logger helper reference
     */
    public ModelBindingInterceptor(IReflection reflection, ILogger logger) {
        this.reflection = reflection;
        this.logger = logger;
        bindings = new LinkedList<>();
    }

    /**
     * Extracts a binding object from view property.
     * @param setter   a setter setMethod which will be invoked
     * @param field    corresponding setter's field
     * @param target   a target object containing a setter setMethod
     * @param rawValue a raw value which is about to be deserialized.
     * @return true if there is no match for the bound property, false otherwise
     */
    @Override
    public boolean beforeSetterInvoked(Method setter, Field field, Object target, String rawValue) {
        if (rawValue != null && target instanceof View) {

            String methodName = field.getName();

            try {
                Optional<PropertyBinding> optionalBinding = tryRetrieveExternalBinding(target, methodName, rawValue);
                if (!optionalBinding.isPresent()) {
                    optionalBinding = tryRetrieveLocalBinding(target, methodName, rawValue);

                    if (!optionalBinding.isPresent()) {
                        optionalBinding = tryRetrieveTemplateBinding(target, methodName, rawValue);
                    }
                }

                if (optionalBinding.isPresent() && !bindings.contains(optionalBinding.get())) {
                    bindings.add(optionalBinding.get());
                    return false;
                }

            } catch (ReflectionException e) {
                logger.error("PropertyBindingInterceptor | beforeSetterInvoked | Unable to invoke " + methodName
                        + "()  setMethod, which should return an IObservableProperty object", e);
            }
        }

        return true;
    }

    /**
     * Gets a cached list of model bindings.
     * @return a cached list of model bindings
     */
    public List<PropertyBinding> getBindings() {
        return bindings;
    }

    /**
     * Clears a cached list of model bindings.
     */
    public void clearBindings() {
        bindings.clear();
    }

    /**
     * Try retrieve a template binding according to specified object.
     * @param target        an object from which to retrieve observable property
     * @param methodName    a method name
     * @param propertyValue a property value
     * @return if retrieved successfully an optional has value, otherwise not
     * @throws ReflectionException a problem with method invocation on object
     */
    private Optional<PropertyBinding> tryRetrieveTemplateBinding(Object target, String methodName, String propertyValue) throws ReflectionException {

        if (isTemplateProperty(propertyValue)) {
            Optional<Method> methodOptional = tryRetrieveMethod(target.getClass(), methodName);
            if (methodOptional.isPresent()) {
                ObservableProperty observableProperty = (ObservableProperty) methodOptional.get().invoke(target);
                return Optional.of(new DeferredTemplateBinding(propertyValue, observableProperty));
            }
        }

        return Optional.empty();
    }

    /**
     * Try retrieve a external binding according to specified object.
     * @param target        an object from which to retrieve observable property
     * @param methodName    a method name
     * @param propertyValue a property value
     * @return if retrieved successfully an optional has value, otherwise not
     * @throws ReflectionException a problem with method invocation on object
     */
    private Optional<PropertyBinding> tryRetrieveExternalBinding(Object target, String methodName, String propertyValue) throws ReflectionException {

        Optional<String> optionalExternalProperty = tryExtractExternalProperty(propertyValue);

        if (optionalExternalProperty.isPresent()) {
            Optional<Method> methodOptional = tryRetrieveMethod(target.getClass(), methodName);
            if (methodOptional.isPresent()) {
                ObservableProperty observableProperty = (ObservableProperty) methodOptional.get().invoke(target);
                return Optional.of(new DeferredExternalBinding(optionalExternalProperty.get(), observableProperty));
            }
        }

        return Optional.empty();
    }

    /**
     * Try retrieve a local binding according to specified object.
     * @param target        an object from which to retrieve observable property
     * @param methodName    a method name
     * @param propertyValue a property value
     * @return if retrieved successfully an optional has value, otherwise not
     * @throws ReflectionException a problem with method invocation on object
     */
    private Optional<PropertyBinding> tryRetrieveLocalBinding(Object target, String methodName, String propertyValue) throws ReflectionException {

        Optional<String> optionalLocalProperty = tryExtractLocalProperty(propertyValue);
        if (optionalLocalProperty.isPresent()) {
            Optional<Method> methodOptional = tryRetrieveMethod(target.getClass(), methodName);
            if (methodOptional.isPresent()) {
                ObservableProperty observableProperty = (ObservableProperty) methodOptional.get().invoke(target);
                return Optional.of(new DeferredLocalBinding(optionalLocalProperty.get(), observableProperty));
            }
        }

        return Optional.empty();
    }

    /**
     * Verifies, whether a specified value matches to template schema.
     * @param propertyValue a property value
     * @return true if match, otherwise false
     */
    private boolean isTemplateProperty(String propertyValue) {
        MatchResult matcher = TEMPLATE_PROPERTY_REGEX.exec(propertyValue);
        return matcher != null;
    }

    /**
     * Try extract a local property from specified value.
     * @param propertyValue a property value
     * @return if successfully an optional has value, otherwise not
     */
    private Optional<String> tryExtractLocalProperty(String propertyValue) {
        return tryExtractProperty(START_TAG_LOCAL, END_TAG, propertyValue);
    }

    /**
     * Try extract a external property from specified value.
     * @param propertyValue a property value
     * @return if successfully an optional has value, otherwise not
     */
    private Optional<String> tryExtractExternalProperty(String propertyValue) {
        return tryExtractProperty(START_TAG_EXTERNAL, END_TAG, propertyValue);
    }

    /**
     * Try extract property according to specified tags.
     * @param startTag      a start tag
     * @param endTag        a end tag
     * @param propertyValue a property value
     * @return if successfully an optional has value, otherwise not
     */
    private Optional<String> tryExtractProperty(String startTag, String endTag, String propertyValue) {
        if (propertyValue.startsWith(startTag) && propertyValue.endsWith(endTag)) {
            int startIdxIncl = endTag.length();
            int endIdxExcl = propertyValue.length() - endTag.length();
            return Optional.of(propertyValue.substring(startIdxIncl, endIdxExcl));
        }

        return Optional.empty();
    }

    /**
     * Try retrieve a method from specified class.
     * @param targetClass a target class
     * @param methodName  a method name
     * @return if successfully an optional has value, otherwise not
     */
    private Optional<Method> tryRetrieveMethod(Class<?> targetClass, String methodName) {
        Method method = null;
        while (method == null && targetClass != Object.class) {
            method = reflection.fetchMethod(targetClass, methodName);
            targetClass = targetClass.getSuperclass();
        }

        if (method == null) {
            logger.error("PropertyBindingInterceptor | tryRetrieveMethod | Requested setMethod " + methodName
                    + "(), which should return an IObservableProperty object, could not found!");
            return Optional.empty();
        }
        return Optional.of(method);
    }
}
