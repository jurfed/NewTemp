package com.atsisa.gox.framework.resource;

/**
 * Queues resource class.
 */
public class QueuesResource extends XmlResource {

    /**
     * Queues resource type.
     */
    private static final ResourceType RESOURCE_TYPE = ResourceType.QUEUES;

    /**
     * Initializes a new instance of the {@link QueuesResource} class.
     * @param text reference to text
     */
    public QueuesResource(String text) {
        super(text, RESOURCE_TYPE);
    }

    /**
     * Initializes a new instance of the {@link QueuesResource} class.
     * @param description resource description
     */
    public QueuesResource(ResourceDescription description) {
        super(description, RESOURCE_TYPE);
    }
}
