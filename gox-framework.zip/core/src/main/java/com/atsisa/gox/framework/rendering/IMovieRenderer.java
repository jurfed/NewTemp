package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.view.IMovieCompleteListener;
import com.atsisa.gox.framework.view.MovieView;

/**
 * Movie rendering interface.
 */
public interface IMovieRenderer {

    /**
     * Registers movie complete listener to rendering.
     * @param view     - MovieView
     * @param listener - IMovieCompleteListener
     */
    void registerCompleteListener(MovieView view, IMovieCompleteListener listener);

    /**
     * Unregisters movie complete listener from rendering.
     * @param view     - MovieView
     * @param listener - IMovieCompleteListener
     * @return boolean
     */
    boolean unregisterCompleteListener(MovieView view, IMovieCompleteListener listener);

    /**
     * Gets original video height.
     * @param view - MovieView
     * @return int
     */
    int getVideoHeight(MovieView view);

    /**
     * Gets original video width.
     * @param view - MovieView
     * @return int
     */
    int getVideoWidth(MovieView view);
}
