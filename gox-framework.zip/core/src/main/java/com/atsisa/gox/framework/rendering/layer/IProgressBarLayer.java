package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.resource.IImageObjectWrapper;

/**
 * Exposes methods for progress bar layer.
 */
public interface IProgressBarLayer extends ILayer {

    /**
     * Sets image as progress bar.
     * @param imageObjectWrapper - IImageObjectWrapper
     */
    void setProgressBarImage(IImageObjectWrapper imageObjectWrapper);

    /**
     * Updates progress bar.
     * @param progress - float
     */
    void updateProgress(float progress);

    /**
     * Sets bar color.
     * @param color - int
     */
    void setColor(int color);
}
