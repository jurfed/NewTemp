package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data container for PauseAction process.
 */
@XmlElement
@Reflect_Full
public class PauseActionData extends ActionData {

    /**
     * Default time.
     */
    private static final int DEFAULT_TIME = 1000;

    /**
     * Pause time in milliseconds, one second is default time.
     */
    @XmlAttribute
    private int pauseTime = DEFAULT_TIME;

    /**
     * Sets pause time.
     * @param value pause time
     */
    public void setPauseTime(int value) {
        pauseTime = value;
    }

    /**
     * Gets pause time.
     * @return pause time
     */
    public int getPauseTime() {
        return pauseTime;
    }

}
