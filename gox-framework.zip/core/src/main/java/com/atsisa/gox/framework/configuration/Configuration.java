package com.atsisa.gox.framework.configuration;

import java.util.List;

import com.atsisa.gox.framework.action.ActionBinding;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.Skin;
import com.gwtent.reflection.client.Reflectable;

/**
 * Configuration model class.
 * Wraps all important configuration models
 * such as action bindings, action queues, actions, resources and so on.
 * Serializable via XmlSerializer.
 */
@XmlElement
@Reflectable
public class Configuration extends BaseConfiguration {

    /**
     * Sets a list of action bindings.
     * @param actionBindings a list of action bindings
     */
    public void setActionBindings(List<ActionBinding> actionBindings) {
        getActionBindings().addAll(actionBindings);
    }

    /**
     * Sets a list of skins.
     * @param skinList a list of skins
     */
    public void setSkinList(List<Skin> skinList) {
        getSkinList().addAll(skinList);
    }

    /**
     * Sets a list of properties.
     * @param properties a list of properties
     */
    public void setProperties(List<ConfigurationProperty> properties) {
        getProperties().addAll(properties);
    }

    /**
     * Sets a list of action modules class names.
     * @param actionModules a list of action modules class names
     */
    public void setActionModules(List<String> actionModules) {
        getActionModules().addAll(actionModules);
    }

    /**
     * Sets a list of view modules class names.
     * @param viewModules a list of  view modules class names
     */
    public void setViewModules(List<String> viewModules) {
        getViewModules().addAll(viewModules);
    }

    /**
     * Sets a list of screens class names.
     * @param screens a list of screens class names
     */
    public void setScreens(List<String> screens) {
        getScreens().addAll(screens);
    }

}
