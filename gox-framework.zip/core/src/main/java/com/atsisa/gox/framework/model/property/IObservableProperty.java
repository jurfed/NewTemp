package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.model.IPropertyChangedListener;

/**
 * Observable property interface.
 * Exposes methods for monitoring changes in property values
 * @param <T> type of the property value
 */
public interface IObservableProperty<T> {

    /**
     * Checks whether or not the property has currently default value assigned.
     * @return a boolean value indicating whether or not the property has currently default value assigned
     */
    boolean hasDefaultValue();

    /**
     * Gets the type of the property value.
     * @return the type of the property value
     */
    Class<T> getType();

    /**
     * Adds a property changed listener.
     * @param listener property changed listener
     */
    void addPropertyChangedListener(IPropertyChangedListener<T> listener);

    /**
     * Removes a property changed listener.
     * @param listener property changed listener
     */
    void removePropertyChangedListener(IPropertyChangedListener<T> listener);

    /**
     * Gets the property value.
     * @return the property value
     */
    T get();

    /**
     * Sets the property value.
     * @param value - new default value for the property.
     * @return boolean result of set operation.
     */
    boolean set(T value);

    /**
     * Gets the default value of the property.
     * @return default value of the property
     */
    T getDefaultValue();

    /**
     * Sets default value for the property.
     * @param defaultValue - new default value for the property.
     */
    void setDefaultValue(T defaultValue);
}
