package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * An action that will be automatically finished at the end of execution setMethod.
 * @param <T> type extends ActionData
 */
public abstract class SyncAction<T extends ActionData> extends Action<T> {

    /**
     * Initializes a new instance of the {@link SyncAction} class.
     */
    public SyncAction() {
    }

    /**
     * Initializes a new instance of the {@link SyncAction} class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public SyncAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    /**
     * Validates the action and delegates execution to the execute setMethod. Once the execution ends the finish setMethod is immediately called.
     */
    @Override
    void doExecute() {
        super.doExecute();
        if (getState() == ActionState.ACTIVE) {
            finish();
        }
    }
}
