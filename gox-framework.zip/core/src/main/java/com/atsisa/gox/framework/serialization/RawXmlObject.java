package com.atsisa.gox.framework.serialization;

import java.util.List;
import java.util.Map;

/**
 * Raw xml object class.
 */
public class RawXmlObject extends XmlObject {

    /**
     * Raw value.
     */
    private String rawValue;

    /**
     * Initializes a new instance of the RawXmlObject
     * @param rawValue raw value.
     */
    public RawXmlObject(String rawValue) {
        this.rawValue = rawValue;
    }

    @Override
    public String getNamespace() {
        raiseError();
        return null;
    }

    @Override
    public Map<String, String> getAttributes() {
        raiseError();
        return null;
    }

    @Override
    public String getAttribute(String attributeName) {
        raiseError();
        return null;
    }

    @Override
    public void addAttribute(String attributeKey, String attributeValue) {
        raiseError();
    }

    @Override
    public String getName() {
        raiseError();
        return null;
    }

    @Override
    public void setName(String name) {
        raiseError();
    }

    @Override
    public void setValue(String value) {
        raiseError();
    }

    @Override
    public String getValue() {
        raiseError();
        return null;
    }

    @Override
    protected String toXmlString(String innerValue, boolean resolveNamespaces) {
        return rawValue;
    }

    @Override
    public List<XmlObject> getChildren() {
        raiseError();
        return null;
    }

    @Override
    public XmlObject getChildren(int index) {
        raiseError();
        return null;
    }

    @Override
    public void addChild(XmlObject xmlObject) {
        raiseError();
    }

    @Override
    public int compareTo(XmlObject xmlObject) {
        return 1;
    }

    @Override
    public boolean hasChildren() {
        raiseError();
        return false;
    }

    @Override
    public XmlObject findOne(String path) {
        raiseError();
        return null;
    }

    @Override
    public List<XmlObject> find(String path) {
        raiseError();
        return null;
    }

    /**
     * Raises an instance of the UnsupportedOperationException class.
     */
    private void raiseError() {
        throw new UnsupportedOperationException("This is raw XML object. You cannot parse or modify it");
    }
}
