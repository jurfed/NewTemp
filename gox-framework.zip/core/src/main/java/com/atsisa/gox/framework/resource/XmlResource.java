package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.GameEngine;

/**
 * Xml resource class.
 */
public class XmlResource extends AbstractResource {

    /**
     * Array containing supported extensions of the files.
     */
    private static final String[] SUPPORTED_EXTENSIONS = { ".xml" };

    /**
     * Text resource.
     */
    private AbstractTextResource textResource;

    /**
     * IResourceFactory reference.
     */
    private IResourceFactory resourceFactory;

    /**
     * Xml as string.
     */
    private String xmlText;

    /**
     * Creates resource object with given xml as string.
     * @param xmlText - String
     */
    public XmlResource(String xmlText) {
        this(xmlText, ResourceType.XML);
    }

    /**
     * Creates resource object with given xml as string and specific resource type.
     * @param xmlText      - String
     * @param resourceType - ResourceType
     */
    public XmlResource(String xmlText, ResourceType resourceType) {
        super(null, resourceType);
        setText(xmlText);
    }

    /**
     * Creates resource object with given description.
     * @param description resource description object
     */
    public XmlResource(ResourceDescription description) {
        this(description, ResourceType.XML);
    }

    /**
     * Creates resource object with given description and resource type.
     * @param description  resource description object
     * @param resourceType resource type
     */
    public XmlResource(ResourceDescription description, ResourceType resourceType) {
        this(description, resourceType, GameEngine.current().getResourceManager().getResourceFactory());
    }

    /**
     * Creates resource object with given description, resource type and resource factory.
     * @param description     resource description object
     * @param resourceType    resource type
     * @param resourceFactory resource factory
     */
    public XmlResource(ResourceDescription description, ResourceType resourceType, IResourceFactory resourceFactory) {
        super(description, resourceType);
        this.resourceFactory = resourceFactory;
    }

    @Override
    public String[] getSupportedExtensions() {
        return SUPPORTED_EXTENSIONS;
    }

    /**
     * Returns xml as string.
     * @return String
     */
    public String getText() {
        return xmlText;
    }

    /**
     * Sets xml as string.
     * @param text - String
     */
    public void setText(String text) {
        xmlText = text;
    }

    @Override
    public void unload() {
        super.unload();
        if (textResource != null) {
            textResource.unload();
            textResource = null;
        }
    }

    @Override
    protected void doLoad() {
        ResourceDescription textDescription = getDescription().clone();
        GameEngine.current().getResourceManager().setPathToResource(textDescription);
        textDescription.setResourceType(ResourceType.TEXT);
        textResource = (AbstractTextResource) resourceFactory.createResource(textDescription);
        textResource.load(new ResourceLoadingCallbackAdapter() {

            @Override
            public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
                XmlResource.this.onError(cause.getMessage());
            }

            @Override
            public void onSuccess(IResource resource, int resIndex, int resCount) {
                setText(textResource.getText());
                onXmlResourceLoaded();
            }
        });
    }

    /**
     * Called when xml file resource will be successfully loaded.
     */
    protected void onXmlResourceLoaded() {
        onSuccess();
    }

    /**
     * Gets resource factory reference.
     * @return IResourceFactory
     */
    protected IResourceFactory getResourceFactory() {
        return resourceFactory;
    }
}
