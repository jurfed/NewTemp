package com.atsisa.gox.framework.animation;

import rx.functions.Action1;

/**
 * Implementation of IAnimation interface for Looped Animations.
 */
public class LoopedAnimation extends AbstractAnimation {

    /**
     * Given animation to repeat.
     */
    private final IAnimation animation;

    /**
     * Number of repeats of animation.
     */
    private int totalRepeats;

    /**
     * Number of animation repeats already executed.
     */
    private int currentLoopCounter;

    /**
     * Default constructor initializing animation to repeat.
     * @param animation given animation to repeat
     */
    public LoopedAnimation(IAnimation animation) {
        this.animation = animation;
        initialize(1);
    }

    /**
     * Constructor, which takes given number of animation repeats.
     * @param animation    given animation to repeat
     * @param totalRepeats given number of repeats
     */
    public LoopedAnimation(IAnimation animation, int totalRepeats) {
        this.animation = animation;
        initialize(totalRepeats);
    }

    /**
     * Initalizes class fields and invokes observeAnimation method.
     * @param totalRepeats number of repeats of given animation
     */
    private void initialize(int totalRepeats) {
        this.totalRepeats = totalRepeats;
        currentLoopCounter = 0;
        observeAnimation();
    }

    /**
     * Sets an Observer for given animation.
     */
    private void observeAnimation() {
        animation.getAnimationStateObservable().subscribe(new Action1<AnimationState>() {

            @Override
            public void call(AnimationState animationState) {
                if (animationState == AnimationState.STOPPED) {
                    if (!isStopped()) {
                        playNextRepeat();
                    }
                }
            }
        });
    }

    /**
     * Plays next repeat of animation if counter is less than given number of repeats. Stops animation otherwise.
     */
    private void playNextRepeat() {
        if (currentLoopCounter >= totalRepeats) {
            stop();
            return;
        }

        currentLoopCounter++;
        animation.play();
    }

    @Override
    public void play() {
        if (isPlaying()) {
            return;
        }

        if (isPaused()) {
            animation.play();
            return;
        }

        setAnimationState(AnimationState.PLAYING);
        playNextRepeat();
    }

    @Override
    public void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        setAnimationState(AnimationState.PAUSED);
        animation.pause();
    }

    @Override
    public void stop() {
        if (isStopped()) {
            return;
        }

        setAnimationState(AnimationState.STOPPED);
        animation.stop();
        currentLoopCounter = 0;
    }

    /**
     * Sets number of repeats of animation to given.
     * @param totalRepeats given number of repeats
     */
    public void setTotalRepeats(int totalRepeats) {
        this.totalRepeats = totalRepeats;
    }

    /**
     * Returns number of repeats of animation.
     * @return number of repeats
     */
    public int getTotalRepeats() {
        return totalRepeats;
    }
}
