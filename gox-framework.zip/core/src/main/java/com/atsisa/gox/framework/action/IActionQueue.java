package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.utility.IStateListener;

/**
 * Abstract Action Queue Interface.
 */
public interface IActionQueue {

    /**
     * Gets action queue name.
     * @return String
     */
    String getName();

    /**
     * Gets array actions.
     * @return IAction[]
     */
    IAction[] getActions();

    /**
     * Gets array action names.
     * @return String[]
     */
    String[] getActionNames();

    /**
     * Gets action queue id.
     * @return long
     */
    long getId();

    /**
     * Gets the state of the action queue.
     * @return the state of the action queue
     */
    ActionQueueState getState();

    /**
     * Gets last processing action.
     * @return IAction
     */
    IAction getLastActiveAction();

    /**
     * Gets array of action names.
     * @return String[]
     */
    String[] getActionToStringList();

    /**
     * Adds an action queue state listener.
     * @param listener an action queue state listener to add
     */
    void addStateListener(IStateListener<ActionQueueState> listener);

    /**
     * Removes an action queue state listener.
     * @param listener an action queue state listener to remove
     */
    void removeStateListener(IStateListener<ActionQueueState> listener);

    /**
     * Removes all action queue state listeners.
     */
    void clearStateListeners();

}
