package com.atsisa.gox.framework.resource;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.SpriteSheetDescription;

/**
 * Sprite sheet resource class.
 */
public abstract class SpriteSheetResource<TImgWrapper extends IImageObjectWrapper> extends XmlResource
        implements IImageReference<TImgWrapper>, ICompositeResourceReference<IImageReference<TImgWrapper>> {

    /**
     * ILogger implementation.
     */
    private ILogger logger;

    /**
     * IXmlSerializer implementation.
     */
    private IXmlSerializer serializer;

    /**
     * Sprite sheet description.
     */
    private SpriteSheetDescription spriteSheetDescription;

    /**
     * Frames.
     */
    private Map<String, SpriteSheetFrame> frames;

    /**
     * Creates a new instance of the SpriteSheetResource class.
     * @param description resource description object
     */
    protected SpriteSheetResource(ResourceDescription description) {
        super(description, ResourceType.SPRITE_SHEET, GameEngine.current().getResourceManager().getResourceFactory());

        IUtility utility = GameEngine.current().getUtility();
        ISerialization serialization = utility.getSerialization();
        serializer = serialization.getSerializer(SerializationFormat.XML);

        logger = GameEngine.current().getLogger();
        frames = new HashMap<>();
    }

    /**
     * Creates a new instance of the SpriteSheetResource class.
     * @param description     resource description object
     * @param newLogger       - ILogger implementation
     * @param newSerializer   - IXmlSerializer implementation
     * @param resourceFactory - IResourceFactory
     */
    protected SpriteSheetResource(ResourceDescription description, ILogger newLogger, IXmlSerializer newSerializer, IResourceFactory resourceFactory) {
        super(description, ResourceType.SPRITE_SHEET, resourceFactory);

        logger = newLogger;
        serializer = newSerializer;
        frames = new HashMap<>();
    }

    /**
     * Gets sprite sheet description.
     * @return SpriteSheetDescription
     */
    public SpriteSheetDescription getSpriteSheetDescription() {
        return spriteSheetDescription;
    }

    @Override
    public void unload() {
        super.unload();

        if (spriteSheetDescription != null) {
            AbstractImageResource imageResource = spriteSheetDescription.getSpriteSheetImageResource();
            if (imageResource != null) {
                imageResource.unload();
            }
        }

        spriteSheetDescription = null;
    }

    @Override
    public IImageReference<TImgWrapper> getChildResource(String name) {
        return getFrame(name);
    }

    @Override
    public TImgWrapper getImageWrapperObject() {
        if (spriteSheetDescription != null && spriteSheetDescription.getSpriteSheetImageResource() != null) {
            return (TImgWrapper) spriteSheetDescription.getSpriteSheetImageResource().getImageWrapperObject();
        }
        return null;
    }

    /**
     * Initializes the sprites.
     * @param spriteSheetDescription The sprite sheet description.
     */
    protected void initializeSprites(SpriteSheetDescription spriteSheetDescription) {
        if (spriteSheetDescription != null && spriteSheetDescription.getSprites() != null) {
            for (SpriteSheetDescription.Sprite sprite : spriteSheetDescription.getSprites()) {
                getOrCreateFrame(spriteSheetDescription, sprite.getName());
            }
        }
    }

    /**
     * Gets or creates a new texture region wrapper.
     * @param description The sprite sheet description.
     * @param name        The sprite name.
     * @return The texture region for given name.
     */
    private SpriteSheetFrame getOrCreateFrame(SpriteSheetDescription description, String name) {
        SpriteSheetFrame frame = frames.get(name);
        if (frame == null) {
            SpriteSheetDescription.Sprite sprite = description.getSprite(name);
            TImgWrapper wrapper = createFrameImageWrapper(sprite, description.getSpriteSheetImageResource());
            String frameId = getId() + '.' + name;
            frame = new SpriteSheetFrame(frameId, wrapper);
            frames.put(name, frame);
        }
        return frame;
    }

    /**
     * Creates an image object wrapper for a sprite.
     * @param sprite                   The sprite to create the image wrapper for.
     * @param spriteSheetImageResource The root image resource.
     * @return A sprite image object wrapper.
     */
    protected abstract TImgWrapper createFrameImageWrapper(SpriteSheetDescription.Sprite sprite, AbstractImageResource spriteSheetImageResource);

    @Override
    protected void onXmlResourceLoaded() {
        try {
            spriteSheetDescription = (SpriteSheetDescription) serializer.deserialize(getText(), SpriteSheetDescription.class);

            String spriteSheetImagePath = spriteSheetDescription.getImagePath();
            if (spriteSheetImagePath != null) {
                ResourceDescription originalDescription = getDescription();
                String usedFormat = originalDescription.getUsedFormat();

                ResourceDescription imageResourceDescription = originalDescription.clone();
                GameEngine.current().getResourceManager().setPathToResource(imageResourceDescription);
                imageResourceDescription.setUrl(spriteSheetImagePath);
                imageResourceDescription.setPathToResource(usedFormat);
                imageResourceDescription.setResourceType(ResourceType.IMAGE);

                AbstractImageResource imageResource = (AbstractImageResource) getResourceFactory().createResource(imageResourceDescription);
                spriteSheetDescription.setSpriteSheetImageResource(imageResource);
                imageResource.load(new ResourceLoadingCallbackAdapter() {

                    @Override
                    public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
                        SpriteSheetResource.this.onError(cause.getMessage());
                    }

                    @Override
                    public void onSuccess(IResource resource, int resIndex, int resCount) {
                        initializeSprites(spriteSheetDescription);
                        SpriteSheetResource.this.onSuccess();
                    }

                });
            } else {
                onError("Can not load bitmap font, because path to image resources for pages was not set.");
            }
        } catch (SerializationException ex) {
            onError(ex.getMessage());
        }
    }

    /**
     * Returns specific frame from sprite sheet as TextureRegion.
     * @param name - String
     * @return TextureRegion.
     */
    private IImageReference<TImgWrapper> getFrame(String name) {
        SpriteSheetDescription description = spriteSheetDescription;
        if (description != null) {
            return getOrCreateFrame(description, name);
        }
        return null;
    }

    /**
     * Represents a single sprite sheet frame.
     */
    private class SpriteSheetFrame implements IImageReference<TImgWrapper> {

        /**
         * The image object wrapper.
         */
        private final TImgWrapper imageObjectWrapper;

        /**
         * The full identifier.
         */
        private final String id;

        /**
         * Initializes a new instance of the {@link SpriteSheetFrame} class.
         * @param id                 The full sprite sheet frame identifier.
         * @param imageObjectWrapper The image object wrapper.
         */
        SpriteSheetFrame(String id, TImgWrapper imageObjectWrapper) {
            this.id = id;
            this.imageObjectWrapper = imageObjectWrapper;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public ResourceType getResourceType() {
            return ResourceType.SPRITE_SHEET;
        }

        @Override
        public TImgWrapper getImageWrapperObject() {
            return imageObjectWrapper;
        }
    }
}
