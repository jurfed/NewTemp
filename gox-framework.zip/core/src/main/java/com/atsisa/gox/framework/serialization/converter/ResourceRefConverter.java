package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.resource.IResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.IResourceReference;
import com.atsisa.gox.framework.resource.ResourceReference;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Converts a resource object from and to string resource description.
 */
public class ResourceRefConverter implements IValueConverter {

    /**
     * A resource manager reference.
     */
    private IResourceManager resourceManager;

    /**
     * Initializes a new instance of the ResourceRefConverter class.
     */
    public ResourceRefConverter() {
        this(GameEngine.current().getResourceManager());
    }

    /**
     * Initializes a new instance of the ResourceRefConverter class.
     * @param newResourceManager - IResourceManager implementation.
     */
    public ResourceRefConverter(IResourceManager newResourceManager) {
        resourceManager = newResourceManager;
    }

    /**
     * Gets the resource manager reference.
     * @return a resource manager reference
     */
    public IResourceManager getResourceManager() {
        return resourceManager;
    }

    /**
     * Sets the resource manager reference.
     * @param resourceManager a reference of the resource manager
     */
    public void setResourceManager(IResourceManager resourceManager) {
        this.resourceManager = resourceManager;
    }

    @Override
    public Class<?> getValueType() {
        return IResourceReference.class;
    }

    /**
     * Converts an object implementing {@link IResource} interface to its string representation.
     * @param objToConvert a Java object instance
     * @return a string representation of a resource object
     */
    @Override
    public String convertTo(Object objToConvert) {
        IResourceReference resourceName = (IResourceReference) objToConvert;
        if (resourceName != null) {
            return ResourceReference.convertToString(resourceName);
        }
        return null;
    }

    /**
     * Converts a string representation of a resource to its corresponding Java object.
     * @param serializedMessage a string representation of a Java object
     * @param parsedObject      - IParsedObject
     * @return an object implementing {@link IResource} interface
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (StringUtility.isNullOrEmpty(serializedMessage)) {
            return null;
        }
        try {
            IResourceReference resourceReference = resourceManager.find(serializedMessage);
            if (resourceReference == null) {
                throw new ConversionException("Could not find a resource by its reference: " + serializedMessage);
            }
            return resourceReference;
        } catch (IllegalArgumentException ex) {
            throw new ConversionException("Invalid resource reference: " + serializedMessage, ex);
        }
    }
}
