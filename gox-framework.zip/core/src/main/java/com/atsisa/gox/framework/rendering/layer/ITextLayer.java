package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.rendering.TextViewRenderer;
import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.view.HorizontalAlign;
import com.atsisa.gox.framework.view.VerticalAlign;

/**
 * Exposes methods for all types of text layer (normal text layer, bitmap font layer)
 * @param <TFont> The implementation-specific type of the font object.
 */
public interface ITextLayer<TFont> extends ILayer {

    /**
     * Sets font color.
     * @param color - int
     */
    void setFontColor(int color);

    /**
     * Sets the font reference.
     * @param fontReference The font reference.
     */
    void setFontReference(IFontReference<TFont> fontReference);

    /**
     * Gets text width.
     * @return float
     */
    float getTextWidth();

    /**
     * Gets text height.
     * @return float
     */
    float getTextHeight();

    /**
     * Sets text vertical align.
     * @param vAlign - VerticalAlign
     */
    void setVAlign(VerticalAlign vAlign);

    /**
     * Sets text horizontal align.
     * @param hAlign - HorizontalAlign
     */
    void setHAlign(HorizontalAlign hAlign);

    /**
     * Sets text value.
     * @param text - String
     */
    void setText(String text);

    /**
     * Sets a boolean value that indicates whether text will be automatically scaled down if textWidth is greater than width.
     * @param scaleAutoWidth - boolean
     */
    void setScaleAutoWidth(boolean scaleAutoWidth);

    /**
     * Sets font size.
     * @param fontSize - int
     */
    void setFontSize(int fontSize);

    /**
     * Sets a boolean value that indicates whether text is automatically word wrap if textWidth is greater than width.
     * @param wordWrap - boolean
     */
    void setWordWrap(boolean wordWrap);

    /**
     * Flushes all the changes passed from the {@link TextViewRenderer}.
     * @param changes A flag indicating a scope of changes as passed to the TextViewRenderer.
     */
    void update(int changes);
}
