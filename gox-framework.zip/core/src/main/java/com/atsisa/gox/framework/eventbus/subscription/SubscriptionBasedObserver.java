package com.atsisa.gox.framework.eventbus.subscription;

import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.gwtent.reflection.client.Reflectable;

import rx.Observer;

/**
 * Internal observer used during registration of @Subscribe annotated methods.
 */
@Reflectable
public class SubscriptionBasedObserver implements Observer {

    /**
     * Instance of subscription metadata.
     */
    private AnnotatedSubscriptionMetadata annotatedSubscriptionMetadata;

    /**
     * The logger reference.
     */
    private ILogger logger;

    /**
     * SubscriptionBasedObserver constructor.
     * @param annotatedSubscriptionMetadata metadata object containing reference to target subscriber
     * @param logger                        {@link ILogger}
     * @throws ReflectionException in case of problems with class casting
     */
    public SubscriptionBasedObserver(AnnotatedSubscriptionMetadata annotatedSubscriptionMetadata, ILogger logger) throws ReflectionException {
        this.annotatedSubscriptionMetadata = annotatedSubscriptionMetadata;
        this.logger = logger;
    }

    @Override
    public void onCompleted() {
        //TBD
    }

    @Override
    public void onError(Throwable e) {
        logger.error(e.getMessage(), e);
    }

    /**
     * Method receive event bus events in a form of Objects, yet those can be safely passed to underlying logic as type compliance is verified in the bus
     * itself.
     * @param object received events
     */
    @Override
    public void onNext(Object object) {
        try {
            annotatedSubscriptionMetadata.getSubscriptionMethod().invoke(annotatedSubscriptionMetadata.getTarget(), object);
        } catch (ReflectionException e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * Gets class of matched events.
     * @return class of matched events passed to this observer
     */
    public Class getEventType() {
        return annotatedSubscriptionMetadata.getEventType();
    }

}
