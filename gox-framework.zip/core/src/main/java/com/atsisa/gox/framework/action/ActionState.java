package com.atsisa.gox.framework.action;

/**
 * Action states enumeration.
 */
public enum ActionState {
    /**
     * Pending action.
     */
    PENDING,
    /**
     * Validated action.
     */
    VALIDATED,
    /**
     * Currently executing action.
     */
    ACTIVE,
    /**
     * Terminated action.
     */
    TERMINATED,
    /**
     * Successfully ended action.
     */
    SUCCEEDED,
    /**
     * Failed action.
     */
    FAILED
}
