package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.rendering.layer.ILayerFactory;
import com.atsisa.gox.framework.view.IViewPropertyChangedListener;
import com.atsisa.gox.framework.view.View;

/**
 * Provides a rendering abstraction layers.
 */
public interface IRenderer extends IViewPropertyChangedListener, IDisposable {

    /**
     * Gets view rendering based on specific class type.
     *
     * @param classType class type
     * @return IViewRenderer, "null" if class type will be not found
     */
    IViewRenderer getViewRenderer(Class<?> classType);

    /**
     * Called when game is started and the rendering is requested for the first time. This setMethod should start the
     * game loop
     *
     * @param rendererInitListener asynchronous initialization interface
     */
    void onCreate(IRendererInitListener rendererInitListener);

    /**
     * Gets the frames per seconds.
     *
     * @return int
     */
    int getFPS();

    /**
     * Renders all registered views.
     */
    void render();

    /**
     * Removes a View from the rendering cache.
     *
     * @param view view to remove
     * @return true if operation succeeded, false otherwise
     */
    boolean dispose(View view);

    /**
     * Registers specific view rendering.
     *
     * @param renderer - IViewRenderer
     */
    void registerViewRenderer(IViewRenderer renderer);

    /**
     * Adds game loop listener.
     *
     * @param listener - IGameLoopListener
     */
    void addGameLoopListener(IGameLoopListener listener);

    /**
     * Removes game loop listeners.
     *
     * @param listener - IGameLoopListener
     * @return boolean
     */
    boolean removeGameLoopListener(IGameLoopListener listener);

    /**
     * Initializes the view renderers. This setMethod should invoke a set of registerViewRenderer calls to initialize a
     * collection of available renderers.
     */
    void initializeViewRenderers();

    /**
     * Sets the root view (stage view) for the rendering.
     *
     * @param view root view
     */
    void setRootView(View view);

    /**
     * Checks whether or not the rendering has GL context available.
     *
     * @return a value indicating whether or not the rendering has GL context available
     */
    boolean hasGL();

    /**
     * Gets touch input event delegate.
     *
     * @param <T> type of layer
     * @return touch input event delegate.
     */
    <T extends ILayer> IInputEventDelegate<T> getTouchInputEventDelegate();

    /**
     * Gets keyboard input event delegate.
     *
     * @param <T> type of layer
     * @return keyboard input event delegate.
     */
    <T extends ILayer> IInputEventDelegate<T> getKeyboardInputEventDelegate();

    /**
     * Returns layer factory implementation.
     *
     * @return ILayerFactory
     */
    ILayerFactory getLayerFactory();

    /**
     * Generates next unique sequence number.
     *
     * @return int unique sequence number.
     */
    int generateNextSequentialNumber();

    /**
     * Pauses the rendering of the view.
     *
     * @return true if rendering has been paused successfully
     */
    boolean pause();

    /**
     * Resumes the rendering of the view.
     *
     * @return true if rendering has been resumed successfully
     */
    boolean resume();

    /**
     * Gets state of renderer.
     *
     * @return renderer state
     */
    RendererState getState();
}
