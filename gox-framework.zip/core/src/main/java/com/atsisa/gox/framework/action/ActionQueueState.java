package com.atsisa.gox.framework.action;

/**
 * Action queue states enumeration.
 */
public enum ActionQueueState {
    /**
     * Pending  action queue.
     */
    PENDING,
    /**
     * Currently executing action queue.
     */
    ACTIVE,
    /**
     * Paused action queue.
     */
    PAUSED,
    /**
     * Finished action queue.
     */
    FINISHED,
    /**
     * Destroyed action queue.
     */
    DESTROYED
}
