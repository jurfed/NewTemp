package com.atsisa.gox.framework.utility;

/**
 * Exposes methods for objects which needs to be initializable after specific behaviour
 * (e.g. on mobile browser after user interaction)
 */
public interface IForceInitializable {

    /**
     * Forcing the object to initialize.
     */
    void forceInitialize();

}
