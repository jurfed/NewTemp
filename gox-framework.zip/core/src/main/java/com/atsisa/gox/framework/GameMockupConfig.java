package com.atsisa.gox.framework;

import com.atsisa.gox.framework.configuration.GameConfiguration;

/**
 * Game Mockup configuration.
 */
public class GameMockupConfig extends GameConfiguration {

    /**
     * Initializes a new instance of the GameMockupConfig class.
     */
    public GameMockupConfig() {
        setResourcePath("Framework/");
        setAutoScale(false);
        setWidth(1920);
        setHeight(1080);
    }
}
