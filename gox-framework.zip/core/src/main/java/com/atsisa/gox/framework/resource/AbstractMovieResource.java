package com.atsisa.gox.framework.resource;

/**
 * Movie abstract resource.
 */
public abstract class AbstractMovieResource<T> extends AbstractResource {

    /**
     * Array containing supported extensions of the files.
     */
    private static final String[] SUPPORTED_EXTENSIONS = { ".mp4" };

    /**
     * Movie file.
     */
    private T movieObject;

    /**
     * Creates resource object with given description.
     * @param description resource description object
     */
    public AbstractMovieResource(ResourceDescription description) {
        super(description, ResourceType.MOVIE);
    }

    @Override
    public String[] getSupportedExtensions() {
        return SUPPORTED_EXTENSIONS;
    }

    /**
     * Gets movie object.
     * @return movie object
     */
    public T getMovieObject() {
        return movieObject;
    }

    /**
     * Sets movie object.
     * @param movieObject - T
     */
    protected void setMovieObject(T movieObject) {
        this.movieObject = movieObject;
    }
}
