package com.atsisa.gox.framework.infrastructure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.model.PropertyBinding;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.ISetterInterceptor;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.serialization.interceptor.ModelBindingInterceptor;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.view.AbstractViewModule;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.inject.Inject;

/**
 * An implementation of XML based view builder. Registers view modules and builds particular views using XML description.
 */
public class ViewBuilder implements IViewBuilder {

    /**
     * Logger reference.
     */
    private final ILogger logger;

    /**
     * View parser reference.
     */
    private IParser viewParser;

    /**
     * View serializer reference.
     */
    private IXmlSerializer viewSerializer;

    /**
     * Module map, maps XML namespace to module objects.
     */
    private Map<String, AbstractViewModule> moduleMap;

    /**
     * List of used view identifiers.
     */
    private List<String> usedIds;

    /**
     * Property binding interceptor.
     */
    private ModelBindingInterceptor propertyBindingInterceptor;

    /**
     * Initializes a new instance of the {@link ViewBuilder} class.
     * @param reflection    {@link IReflection}
     * @param logger        {@link ILogger}
     * @param parser        {@link IParser}
     * @param xmlSerializer {@link IXmlSerializer}
     */
    @Inject
    public ViewBuilder(IReflection reflection, ILogger logger, IParser parser, IXmlSerializer xmlSerializer) {
        this.logger = logger;
        moduleMap = new HashMap<>();
        viewParser = parser;
        viewSerializer = xmlSerializer;
        propertyBindingInterceptor = new ModelBindingInterceptor(reflection, logger);
    }

    @Override
    public ISetterInterceptor getPropertyBindingInterceptor() {
        return propertyBindingInterceptor;
    }

    @Override
    public void registerModule(AbstractViewModule viewModule) {
        logger.debug("ViewBuilder | registerModule | viewModule: %s", viewModule);
        moduleMap.put(viewModule.getXmlNamespace(), viewModule);
    }

    @Override
    public List<AbstractViewModule> getModules() {
        return new ArrayList<>(moduleMap.values());
    }

    @Override
    public View build(XmlResource resource, boolean shouldIdBeRegistered) throws ParseException {
        logger.debug("ViewBuilder | build | xmlResource: %s", resource);
        String serializedView = resource.getText();
        return build(serializedView, shouldIdBeRegistered);
    }

    @Override
    public View build(String serializedView, boolean shouldIdBeRegistered) throws ParseException {
        if (StringUtility.isNullOrEmpty(serializedView)) {
            throw new IllegalArgumentException("Serialized view description is null or empty.");
        }
        XmlObjectDocument xmlDocument = (XmlObjectDocument) viewParser.parse(serializedView);
        XmlObject xmlElement = xmlDocument.getDocumentElement();
        usedIds = new ArrayList<>();
        propertyBindingInterceptor.clearBindings();
        try {
            return createView(xmlElement, shouldIdBeRegistered);
        } catch (SerializationException ex) {
            throw new ParseException("Could not deserialize a type", ex);
        }
    }

    @Override
    public IParser getViewParser() {
        return viewParser;
    }

    @Override
    public IXmlSerializer getViewSerializer() {
        return viewSerializer;
    }

    /**
     * Creates a view object using xml element given as parameter.
     * @param xmlElement           {@link XmlObject}
     * @param shouldIdBeRegistered a boolean value that indicates whether new view id should be registered or not
     * @return a view object created    from xml element
     * @throws ParseException         throws when data in xml object are not correct
     * @throws SerializationException throws when during deserialize xml object, exception will occur
     */
    @Override
    public View createView(XmlObject xmlElement, boolean shouldIdBeRegistered) throws ParseException, SerializationException {
        return createView(xmlElement, shouldIdBeRegistered, null);
    }

    /**
     * Creates and returns view from given xml.
     * @param xmlElement           {@link XmlObject}
     * @param shouldIdBeRegistered a boolean value that indicates whether new view id should be registered or not
     * @param parent               {@link ViewGroup}
     * @return a view object created from xml element
     * @throws ParseException         throws when data in xml object are not correct
     * @throws SerializationException throws when during deserialize xml object, exception will occur
     */
    private View createView(XmlObject xmlElement, boolean shouldIdBeRegistered, ViewGroup parent) throws ParseException, SerializationException {
        String xmlNamespace = xmlElement.getNamespace();
        Class<?> viewClass = getClassFromModule(xmlElement.getName(), xmlNamespace);
        if (viewClass != null) {
            View view = (View) viewSerializer.deserialize(xmlElement, viewClass, null);
            if (view == null) {
                throw new ParseException(StringUtility.format("View is null for tag '%s'", xmlElement.getName()));
            }

            if (shouldIdBeRegistered) {
                if (view.getId() != null && usedIds.contains(view.getId())) {
                    throw new ParseException(StringUtility.format("Identifier '%s' has already been used.", view.getId()));
                }

                usedIds.add(view.getId());
            }
            if (parent != null) {
                view.setParent(parent);
            }
            if (view instanceof ViewGroup) {
                List<XmlObject> xmlChildren = getXmlViewChildren(xmlElement);
                if (xmlChildren != null) {
                    for (XmlObject xmlChild : xmlChildren) {
                        View childView = createView(xmlChild, shouldIdBeRegistered, (ViewGroup) view);
                        ((ViewGroup) view).addChild(childView);
                    }
                }
            }
            return view;
        }

        throw new ParseException(StringUtility.format("Could not get class for the '%s' name in '%s' namespace", xmlElement.getName(), xmlNamespace));
    }

    @Override
    public List<PropertyBinding> getPropertyBindings() {
        return propertyBindingInterceptor.getBindings();
    }

    /**
     * Finds in xml object xml views.
     * @param xmlObject - XmlObject
     * @return object xml views
     */
    private List<XmlObject> getXmlViewChildren(XmlObject xmlObject) {
        List<XmlObject> xmlElements = xmlObject.getChildren();
        if (xmlElements != null) {
            for (XmlObject xmlElement : xmlElements) {
                if (xmlElement.getName().equals(ViewGroup.XML_CHILDREN_TAG)) {
                    return xmlElement.getChildren();
                }
            }
        }
        return null;
    }

    /**
     * Gets a class object from view module
     * @param tagName      class name to check
     * @param xmlNamespace xml namespace to check
     * @return a class object from view module
     * @throws ParseException if parsing went wrong.
     */
    private Class<?> getClassFromModule(String tagName, String xmlNamespace) throws ParseException {
        AbstractViewModule module = moduleMap.get(xmlNamespace);
        if (module != null) {
            return module.getViewType(tagName);
        }
        throw new ParseException(StringUtility.format("No module has been registered for '%s' namespace", xmlNamespace));
    }
}
