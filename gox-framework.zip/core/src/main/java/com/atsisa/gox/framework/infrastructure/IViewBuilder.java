package com.atsisa.gox.framework.infrastructure;

import java.util.List;

import com.atsisa.gox.framework.model.PropertyBinding;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.ISetterInterceptor;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.view.AbstractViewModule;
import com.atsisa.gox.framework.view.View;

/**
 * Exposes methods for registering view modules and build particular views using theirs XML description.
 */
public interface IViewBuilder {

    /**
     * Registers a view module in the builder to use it later for mapping xml namespaces to particular view classes.
     * @param viewModule view module to register
     */
    void registerModule(AbstractViewModule viewModule);

    /**
     * Gets a list of registered view modules.
     * @return a list of registered view modules
     */
    List<AbstractViewModule> getModules();

    /**
     * Gets ViewParser reference.
     * @return ViewParser reference
     */
    IParser getViewParser();

    /**
     * Gets ViewSerializer reference.
     * @return ViewSerializer reference
     */
    IXmlSerializer getViewSerializer();

    /**
     * Builds the view objects hierarchy using text resource containing xml description.
     * @param resource             xml text resource to use during the build
     * @param shouldIdBeRegistered true if id should be registered
     * @return a root View object containing the whole view hierarchy
     * @throws ParseException if given text resource could not be parsed
     */
    View build(XmlResource resource, boolean shouldIdBeRegistered) throws ParseException;

    /**
     * Builds the view objects hierarchy using xml description given as parameter.
     * @param serializedView       the xml string describing the views
     * @param shouldIdBeRegistered true if id should be registered
     * @return a root View object containing the whole view hierarchy
     * @throws ParseException if given text resource could not be parsed
     */
    View build(String serializedView, boolean shouldIdBeRegistered) throws ParseException;

    /**
     * Builds the view objects hierarchy using xml object given as parameter.
     * @param xmlElement           the xml element with view structure
     * @param shouldIdBeRegistered - true if id should be registered
     * @return a root View object containing the whole view hierarchy
     * @throws ParseException         - if given xml object could not be parsed
     * @throws SerializationException - if given xml object could not be serialized
     */
    View createView(XmlObject xmlElement, boolean shouldIdBeRegistered) throws ParseException, SerializationException;

    /**
     * Gets a list of property bindings.
     * @return a list of property bindings
     */
    List<PropertyBinding> getPropertyBindings();

    /**
     * Gets a property binding interceptor.
     * @return a property binding interceptor
     */
    ISetterInterceptor getPropertyBindingInterceptor();
}
