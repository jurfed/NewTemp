package com.atsisa.gox.framework.resource;

/**
 * Resources loading callback adapter.
 * Use this to override only selected methods instead of whole IResourceLoadingCallback interface
 */
public class ResourceLoadingCallbackAdapter implements IResourceLoadingCallback {

    @Override
    public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
    }

    @Override
    public void onSuccess(IResource resource, int resIndex, int resCount) {
    }

    @Override
    public void resourcesLoaded() {
    }
}
