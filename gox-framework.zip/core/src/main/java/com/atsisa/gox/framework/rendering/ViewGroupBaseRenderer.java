package com.atsisa.gox.framework.rendering;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.rendering.layer.ILayerContainer;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.InteractiveView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.framework.view.ViewGroupBase;
import com.atsisa.gox.framework.view.ViewType;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

/**
 * Implementation of basic view group rendering.
 */
public class ViewGroupBaseRenderer extends GroupLayerRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Children layers.
     */
    private final List<ILayer> childrenLayers;

    /**
     * RootView for this rendering.
     */
    private View rootView;

    /**
     * Root layer.
     */
    private ILayerContainer rootLayer;

    /**
     * Initializes a new instance of the ViewGroupBaseRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public ViewGroupBaseRenderer(IRenderer renderer) {
        super(renderer);
        childrenLayers = new ArrayList<>();
        lv = new LocalVariables();
    }

    @Override
    public Class<?> getType() {
        return ViewGroupBase.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = changes;
        if (viewType == ViewType.VIEW_GROUP) {
            if (BitUtility.isSet(lv.leftChanges, ViewGroup.ViewPropertyName.CHILD)) {
                updateChildrenState((ViewGroupBase) view);
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ViewGroup.ViewPropertyName.CHILD);
            }
            return lv.leftChanges;
        } else if (viewType == ViewType.VIEW) {
            lv.leftChanges = clearWidthAndHeight(lv.leftChanges);
        }
        lv.leftChanges = super.render(view, viewType, lv.leftChanges);
        return lv.leftChanges;
    }

    /**
     * Updates in specific view group children state.
     * @param viewGroupBase {@link ViewGroupBase}
     */
    private void updateChildrenState(ViewGroupBase viewGroupBase) {
        childrenLayers.clear();
        removeChildren(viewGroupBase);
        lv.currentChildren = getChildrenRaw(viewGroupBase);
        if (!lv.currentChildren.isEmpty()) {
            viewGroupBase.reorder();
            lv.size = lv.currentChildren.size();
            for (lv.index = 0; lv.index < lv.size; lv.index++) {
                lv.child = lv.currentChildren.get(lv.index);
                lv.viewRenderer = getRenderer().getViewRenderer(lv.child.getClass());
                if (lv.viewRenderer != null) {
                    childrenLayers.add(lv.viewRenderer.getContent(lv.child));
                }
            }
            addChildren(childrenLayers, viewGroupBase);
        }
    }

    @Override
    protected void updateInteractive(InteractiveView interactiveView) {
        super.updateInteractive(interactiveView);
        ((ILayerContainer) getViewLayer(interactiveView)).setInteractiveChildren(interactiveView.isInteractive());
    }

    /**
     * Gets a Iterable of children.
     * @param viewGroup view group with children
     * @return a list of children
     */
    protected Iterable<? extends View> getChildren(View viewGroup) {
        return ((ViewGroupBase) viewGroup).getChildren();
    }

    /**
     * Gets a raw list of children.
     * @param viewGroup view group with children
     * @return ObjectArrayList a list of children
     */
    protected ObjectArrayList<View> getChildrenRaw(View viewGroup) {
        return ((ViewGroupBase) viewGroup).getChildrenRaw();
    }

    /**
     * Gets view layer.
     * @param view View
     * @return ILayerContainer
     */
    @Override
    public ILayer getViewLayer(View view) {
        if (view != rootView) {
            return super.getViewLayer(view);
        }
        return getRootLayer();
    }

    /**
     * Gets root layers.
     * @return Group
     */
    public ILayerContainer getRootLayer() {
        if (rootLayer == null) {
            rootLayer = getLayerFactory().createLayerContainer();
        }
        return rootLayer;
    }

    /**
     * Sets the root view.
     * @param rootView - View
     */
    public void setRootView(View rootView) {
        this.rootView = rootView;
        setKeyboardEventDelegate((InteractiveView) rootView);
    }

    /**
     * Holder for instances of local variables used in the {@link ViewGroupBaseRenderer} render method.
     */
    private class LocalVariables {

        private ObjectArrayList<View> currentChildren;

        private int size;

        private int index;

        private View child;

        private IViewRenderer viewRenderer;

        private int leftChanges;
    }
}
