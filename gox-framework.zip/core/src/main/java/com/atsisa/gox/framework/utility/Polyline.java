package com.atsisa.gox.framework.utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a polyline.
 */
public final class Polyline implements IPointsHolder {

    /**
     * Maximal line-rectangle intersection points.
     */
    private static final int MAX_LINE_RECT_INTERSECTIONS = 2;

    /**
     * Points.
     */
    private List<Point> points;

    /**
     * Offset x.
     */
    private float xOffset;

    /**
     * Offset y.
     */
    private float yOffset;

    /**
     * Initializes a new instance of {@link Polyline} class.
     * @param points A list of points.
     */
    public Polyline(List<Point> points) {
        setPoints(points);
    }

    /**
     * Gets the x offset.
     * @return the x offset.
     */
    public float getXOffset() {
        return xOffset;
    }

    /**
     * Sets the x offset.
     * @param xOffset the x offset
     */
    public void setXOffset(float xOffset) {
        this.xOffset = xOffset;
    }

    /**
     * Gets the y offset.
     * @return the y offset
     */
    public float getYOffset() {
        return yOffset;
    }

    /**
     * Sets the y offset.
     * @param yOffset the y offset
     */
    public void setYOffset(float yOffset) {
        this.yOffset = yOffset;
    }

    @Override
    public Iterable<Point> getPoints() {
        return points;
    }

    @Override
    public void setPoints(List<Point> points) {
        if (points == null || points.size() < 2) {
            throw new IllegalArgumentException("Polyline must have at least two points");
        }
        this.points = points;
    }

    /**
     * Cuts this line with a rectangle.
     * @param bound A bound object which should be used to cut the line.
     * @return A new line containing input line's points and an intersection points which are tagged with appropriate {@link Point#POINT_OFF_TAG} and {@link
     * Point#POINT_ON_TAG} tags.
     */
    public Polyline cutWith(IBound bound) {
        return cutWith(bound, new String[] { Point.POINT_OFF_TAG, Point.POINT_ON_TAG });
    }

    /**
     * Cuts this line with a rectangle.
     * @param bound       A bound object which should be used to cut the line.
     * @param cuttingTags An optional array of cutting tags which will be applied to each intersection point in a round-robin manner.
     * @return A new line containing input line's points and an intersection points which are tagged with given cutting tags (applied to intersection points in
     * a round-robin manner).
     */
    public Polyline cutWith(IBound bound, String[] cuttingTags) {
        if (bound == null) {
            throw new IllegalArgumentException("The bound cannot be null.");
        }
        List<Point> rectanglePoints = new ArrayList<>();
        for (Point point : bound.getBoundaries().getPoints()) {
            rectanglePoints.add(new Point(point.getX() + xOffset, point.getY() + yOffset));
        }
        Iterator<Point> pointIterator = getPoints().iterator();
        Point prevLinePt = pointIterator.next();
        List<Point> intersected = new ArrayList<>(MAX_LINE_RECT_INTERSECTIONS);
        LinkedList<Point> finalPoints = new LinkedList<>();
        int cutTagsIdx = 0;
        while (pointIterator.hasNext()) {
            finalPoints.add(prevLinePt);
            Point currLinePt = pointIterator.next();
            Point prevRectPt = rectanglePoints.get(rectanglePoints.size() - 1);
            Point prevIntersectionPt = null;
            for (int rectPointIdx = 0; rectPointIdx < rectanglePoints.size(); rectPointIdx++) {
                Point currRectPt = rectanglePoints.get(rectPointIdx);
                Point intersectionPt = MathUtility
                        .intersection(prevLinePt.getX(), prevLinePt.getY(), currLinePt.getX(), currLinePt.getY(), prevRectPt.getX(), prevRectPt.getY(),
                                currRectPt.getX(), currRectPt.getY());
                if (intersectionPt != null && !Objects.equals(prevIntersectionPt, intersectionPt)) {
                    intersected.add(intersectionPt);
                    prevIntersectionPt = intersectionPt;
                }
                prevRectPt = currRectPt;
                if (intersected.size() == MAX_LINE_RECT_INTERSECTIONS) {
                    // there is no point in processing further since the line-rectangle can have at most 2 intersections.
                    break;
                }
            }

            if (intersected.size() == MAX_LINE_RECT_INTERSECTIONS) {
                Point intersectPtA = intersected.get(0);
                Point intersectPtB = intersected.get(1);
                // reorder the intersection points if the second intersection is closer to the previous line point.
                float distanceA = MathUtility.distance(intersectPtA.getX(), intersectPtA.getY(), prevLinePt.getX(), prevLinePt.getY());
                float distanceB = MathUtility.distance(intersectPtB.getX(), intersectPtB.getY(), prevLinePt.getX(), prevLinePt.getY());
                if (distanceA > distanceB) {
                    Collections.reverse(intersected);
                }
            }

            // append intersection points with a proper tags.
            for (Point intersectedPt : intersected) {
                if (cuttingTags != null && cuttingTags.length > 0) {
                    intersectedPt.addTag(cuttingTags[cutTagsIdx % 2]);
                    cutTagsIdx++;
                }
                finalPoints.add(intersectedPt);
            }

            intersected.clear();
            prevLinePt = currLinePt;
        }

        finalPoints.add(prevLinePt);
        Polyline polyline = new Polyline(finalPoints);
        polyline.setXOffset(getXOffset());
        polyline.setYOffset(getYOffset());
        return polyline;
    }
}
