package com.atsisa.gox.framework.screen;

import com.atsisa.gox.framework.ILoadingHandler;

/**
 * Exposes methods for preloader screen.
 */
public interface IPreloaderScreen {

    /**
     * Adds loading handler.
     * @param loadingHandler - LoadingHandler
     * @param weight         - int
     */
    void addLoadingHandler(ILoadingHandler loadingHandler, int weight);

    /**
     * Initializes listening for events.
     */
    void initialize();
}
