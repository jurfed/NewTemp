package com.atsisa.gox.framework.resource;

import java.util.Map;

/**
 * Resolves resource references from a map of available resources.
 */
class ResourceReferenceResolver {

    /**
     * The separator for complex resource references.
     */
    private static final String SEPARATOR_REGEX = "/";

    /**
     * The available resources map.
     */
    private final Map<String, IResource> availableResources;

    /**
     * Initializes a new instance of the {@link ResourceReferenceResolver} class.
     * @param availableResources The map of available resources.
     */
    ResourceReferenceResolver(Map<String, IResource> availableResources) {
        this.availableResources = availableResources;
    }

    /**
     * Attempts to resolve given string representation of a resource reference.
     * @param resourceReference The resource reference to resolve in <code>@ResourceType/ResourceName/SubResource</code> format.
     * @param <T>               The type of expected resource.
     * @return Found resource reference or null if no such resource exists.
     */
    @SuppressWarnings("unchecked")
    public <T extends IResourceReference> T resolve(String resourceReference) {
        ResourceReference expectedResource = ResourceReference.fromString(resourceReference);
        String[] tokens = expectedResource.getId().split(SEPARATOR_REGEX);
        IResourceReference answer = availableResources.get(tokens[0]);
        if (answer != null) {
            if (expectedResource.getResourceType() != answer.getResourceType()) {
                return null;
            }
            int index = 1;
            while (answer != null && index < tokens.length) {
                if (answer instanceof ICompositeResourceReference) {
                    answer = ((ICompositeResourceReference) answer).getChildResource(tokens[index++]);
                } else {
                    return null;
                }
            }
        }
        return (T) answer;
    }
}
