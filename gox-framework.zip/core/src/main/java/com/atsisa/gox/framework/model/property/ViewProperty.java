package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.model.property.primitive.IViewProperty;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * A property container base class. Exposes methods for hooking up property listeners.
 * @param <T> type of the view property
 */
@SuppressWarnings("unchecked")
public class ViewProperty<T> extends ObservableProperty<T> implements IViewProperty {

    /**
     * View property name identifier.
     */
    private final int viewPropertyName;

    /**
     * View type identifier.
     */
    private final ViewType viewType;

    /**
     * Corresponding view.
     */
    private final View view;

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param type             type of the property's value
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     */
    public ViewProperty(Class<T> type, View view, ViewType viewType, int viewPropertyName) {
        super(type);
        this.view = view;
        addPropertyChangedListener(view);
        this.viewType = viewType;
        this.viewPropertyName = viewPropertyName;
    }

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param type             type of the property's value
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     * @param defaultValue     default property's value
     */
    public ViewProperty(Class<T> type, View view, ViewType viewType, int viewPropertyName, T defaultValue) {
        super(type, defaultValue);
        this.view = view;
        addPropertyChangedListener(view);
        this.viewType = viewType;
        this.viewPropertyName = viewPropertyName;
    }

    @Override
    public boolean set(T newValue) {
        if (super.set(newValue)) {
            view.propertyChanged(viewType, viewPropertyName);
            return true;
        }
        return false;
    }

    /**
     * Sets the property value and notifies listeners about changes. Notification will only be triggered if the actual
     * value has changed
     * @param newValue new property value
     * @param notify   when true, property change is notified, otherwise false
     * @return true if a new value differs from the current value, false otherwise
     */
    public boolean set(T newValue, boolean notify) {
        if (super.set(newValue)) {
            if (notify) {
                view.propertyChanged(viewType, viewPropertyName);
            }
            return true;
        }
        return false;
    }

    @Override
    public int getViewPropertyName() {
        return viewPropertyName;
    }

    @Override
    public ViewType getViewType() {
        return viewType;
    }

    @Override
    public View getView() {
        return view;
    }
}
