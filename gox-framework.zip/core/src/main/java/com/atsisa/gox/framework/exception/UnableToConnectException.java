package com.atsisa.gox.framework.exception;

/**
 * Indicates inability to connect.
 */
public class UnableToConnectException extends GameException {

    /**
     * Game message.
     */
    public static final String LANG_UNABLE_TO_CONNECT = "LangUnableToConnect";

    /**
     * Initializes a new instance of the UnableToConnectException using specific message.
     * @param message error message
     */
    public UnableToConnectException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the UnableToConnectException using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public UnableToConnectException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the UnableToConnectException using specific cause.
     * @param cause internal cause of error
     */
    public UnableToConnectException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getLocalizableMessage() {
        return LANG_UNABLE_TO_CONNECT;
    }
}
