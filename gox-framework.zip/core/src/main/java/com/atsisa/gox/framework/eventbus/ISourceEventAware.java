package com.atsisa.gox.framework.eventbus;

/**
 * Represents an event which is a direct
 * cause of other event.
 */
public interface ISourceEventAware {

    /**
     * Gets a source event which is a direct cause
     * this event was published.
     * @return a source event.
     */
    Object getSourceEvent();
}
