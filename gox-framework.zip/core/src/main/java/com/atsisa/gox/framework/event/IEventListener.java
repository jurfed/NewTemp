package com.atsisa.gox.framework.event;

/**
 * Provides a abstraction layers for event listeners.
 * @param <T> type of the event
 */
public interface IEventListener<T extends IEvent> {

    /**
     * Called when an event occurs.
     * @param event event data
     */
    void onEvent(T event);

}
