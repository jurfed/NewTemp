package com.atsisa.gox.framework.infrastructure;

import java.util.Set;

import com.atsisa.gox.framework.action.IActionBinder;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.google.inject.Inject;

/**
 * View manager components container.
 */
public class ViewManagerComponents {

    /**
     * View manager instance.
     */
    private IViewBuilder viewBuilder;

    /**
     * Skin manager instance.
     */
    private ISkinManager skinManager;

    /**
     * Action binder instance.
     */
    private IActionBinder actionBinder;

    /**
     * Resource manager instance.
     */
    private IResourceManager resourceManager;

    /**
     * Reflection instance.
     */
    private IReflection reflection;

    /**
     * IGameConfiguration instance.
     */
    private IGameConfiguration gameConfiguration;

    /**
     * A value indicating whether it is no longer possible to use setters in this container.
     */
    private boolean frozen;

    /**
     * Gets view builder.
     * @return view builder
     */
    public IViewBuilder getViewBuilder() {
        return viewBuilder;
    }

    /**
     * Sets view builder.
     * @param viewBuilder - view builder
     */
    @Inject
    public void setViewBuilder(IViewBuilder viewBuilder) {
        validateState();
        this.viewBuilder = viewBuilder;
    }

    /**
     * Sets game configuration.
     * @param gameConfiguration - IGameConfiguration
     */
    @Inject
    public void setGameConfiguration(IGameConfiguration gameConfiguration) {
        validateState();
        this.gameConfiguration = gameConfiguration;
    }

    /**
     * Gets game configuration.
     * @return IGameConfiguration.
     */
    public IGameConfiguration getGameConfiguration() {
        return gameConfiguration;
    }

    /**
     * Gets skin manager.
     * @return skin manager
     */
    public ISkinManager getSkinManager() {
        return skinManager;
    }

    /**
     * Sets skin manager.
     * @param skinManager - skin manager
     */
    @Inject
    public void setSkinManager(ISkinManager skinManager) {
        validateState();
        this.skinManager = skinManager;
    }

    /**
     * Gets action binder.
     * @return action binder
     */
    public IActionBinder getActionBinder() {
        return actionBinder;
    }

    /**
     * Sets action binder.
     * @param actionBinder - action binder
     */
    @Inject
    public void setActionBinder(IActionBinder actionBinder) {
        validateState();
        this.actionBinder = actionBinder;
    }

    /**
     * Gets resource manager.
     * @return resource manager
     */
    public IResourceManager getResourceManager() {
        return resourceManager;
    }

    /**
     * Sets resource manager.
     * @param resourceManager - resource manager
     */
    @Inject
    public void setResourceManager(IResourceManager resourceManager) {
        validateState();
        this.resourceManager = resourceManager;
    }

    /**
     * Gets reflection.
     * @return reflection
     */
    public IReflection getReflection() {
        return reflection;
    }

    /**
     * Sets reflection.
     * @param reflection - reflection
     */
    @Inject
    public void setReflection(IReflection reflection) {
        validateState();
        this.reflection = reflection;
    }

    /**
     * Freezes the components so that using setters will no longer be possible.
     */
    void freeze() {
        frozen = true;
    }

    /**
     * Validates if the current instance was frozen
     * and throws an exception if it was.
     */
    private void validateState() {
        if (frozen) {
            throw new UnsupportedOperationException("Cannot modify a reference of the GameEngine component!");
        }
    }
}
