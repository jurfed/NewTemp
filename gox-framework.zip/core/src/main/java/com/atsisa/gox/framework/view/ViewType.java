package com.atsisa.gox.framework.view;

/**
 * Contains a list basic views types.
 */
public enum ViewType {

    /**
     * Represents a view basic type.
     */
    VIEW,

    /**
     * Represents a view group type.
     */
    VIEW_GROUP,

    /**
     * Represents a image view type.
     */
    IMAGE_VIEW,

    /**
     * Represents a bitmap font view type.
     */
    BITMAP_FONT_VIEW,

    /**
     * Represents a text view type.
     */
    TEXT_VIEW,

    /**
     * Represents a line shape view type.
     */
    LINE_SHAPE_VIEW,

    /**
     * Represents a rectangle shape view type.
     */
    RECTANGLE_SHAPE_VIEW,

    /**
     * Represents a line view type.
     */
    LINE_VIEW,

    /**
     * Represents a particle view type.
     */
    PARTICLE_VIEW,

    /**
     * Represents a progress bar view type.
     */
    PROGRESS_BAR_VIEW,

    /**
     * Represents a interactive view type.
     */
    INTERACTIVE_VIEW,

    /**
     * Represents a abstract text view type.
     */
    ABSTRACT_TEXT_VIEW,

    /**
     * Represents a movie view type.
     */
    MOVIE_VIEW,

    /**
     * Represents a abstract keyframe animation type.
     */
    KEY_FRAME_ANIMATION,

    /**
     * Represents a button view type.
     */
    BUTTON_VIEW
}
