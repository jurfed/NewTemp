package com.atsisa.gox.framework.command;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.gwtent.reflection.client.Reflectable;

/**
 * A command used to show screen.
 */
@Reflectable
public class ShowScreenCommand extends ScreenCommand {

    /**
     * The animation that should be used to show the screen.
     */
    private TweenViewAnimationData showViewAnimationData;

    /**
     * Initializes a new instance of the {@link ShowScreenCommand} class.
     * @param screenId              the id of the screen
     * @param showViewAnimationData {@link TweenViewAnimationData}
     * @param triggeredByUser       a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public ShowScreenCommand(String screenId, TweenViewAnimationData showViewAnimationData, boolean triggeredByUser) {
        super(screenId, triggeredByUser);
        this.showViewAnimationData = showViewAnimationData;
    }

    /**
     * Initializes a new instance of the {@link ShowScreenCommand} class.
     * @param screenId              the id of the screen
     * @param showViewAnimationData {@link TweenViewAnimationData}
     */
    public ShowScreenCommand(String screenId, TweenViewAnimationData showViewAnimationData) {
        super(screenId);
        this.showViewAnimationData = showViewAnimationData;
    }

    /**
     * Returns an animation that should be used to show the screen.
     * @return an animation that should be used to show the screen
     */
    public TweenViewAnimationData getShowViewAnimationData() {
        return showViewAnimationData;
    }
}
