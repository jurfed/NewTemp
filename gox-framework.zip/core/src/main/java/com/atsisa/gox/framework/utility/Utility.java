package com.atsisa.gox.framework.utility;

import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.timer.ITimerManager;
import com.google.inject.Inject;

/**
 * Utility components container class.
 */
public class Utility implements IUtility {

    /**
     * Localization utility reference.
     */
    private final ILocalization localization;

    /**
     * JAVA font registry reference.
     */
    private final IFontRegistry fontRegistry;

    /**
     * Main rendering reference.
     */
    private final IReflection reflection;

    /**
     * A reference to the serialization object.
     */
    private final ISerialization serialization;

    /**
     * The timer manager.
     */
    private final ITimerManager timerManager;

    /**
     * The translator.
     */
    private final ITranslator translator;

    /**
     * Initializes a new instance of the Utility class.
     * @param fontRegistry  {@link IFontRegistry}
     * @param reflection    {@link IReflection}
     * @param serialization {@link ISerialization}
     * @param localization  {@link ILocalization}
     * @param timerManager  {@link ITimerManager}
     * @param translator    {@link ITranslator}
     */
    @Inject
    public Utility(IFontRegistry fontRegistry, IReflection reflection, ISerialization serialization, ILocalization localization, ITimerManager timerManager,
            ITranslator translator) {
        this.fontRegistry = fontRegistry;
        this.reflection = reflection;
        this.serialization = serialization;
        this.localization = localization;
        this.timerManager = timerManager;
        this.translator = translator;
    }

    @Override
    public IFontRegistry getFontRegistry() {
        return fontRegistry;
    }

    @Override
    public IReflection getReflection() {
        return reflection;
    }

    @Override
    public ISerialization getSerialization() {
        return serialization;
    }

    @Override
    public ILocalization getLocalization() {
        return localization;
    }

    @Override
    public ITimerManager getTimerManager() {
        return timerManager;
    }

    @Override
    public ITranslator getTranslator() {
        return translator;
    }
}
