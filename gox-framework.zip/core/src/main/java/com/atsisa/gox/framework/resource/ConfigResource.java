package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;

/**
 * Configuration resource class.
 */
public class ConfigResource extends XmlResource {

    /**
     * Configuration provider reference.
     */
    private final IConfigurationProvider configurationProvider;

    /**
     * Creates a new instance of the configuration resource.
     * @param text reference to text
     */
    public ConfigResource(String text) {
        this(text, GameEngine.current().getConfigurationProvider());
    }

    /**
     * Creates a new instance of the configuration resource.
     * @param text                  reference to text
     * @param configurationProvider configuration provider
     */
    public ConfigResource(String text, IConfigurationProvider configurationProvider) {
        super(text, ResourceType.CONFIG);
        this.configurationProvider = configurationProvider;
    }

    /**
     * Creates a new instance of the configuration resource.
     * @param resourceDescription resource description
     */
    public ConfigResource(ResourceDescription resourceDescription) {
        this(resourceDescription, GameEngine.current().getConfigurationProvider());
    }

    /**
     * Creates a new instance of the configuration resource.
     * @param resourceDescription   - resource description
     * @param configurationProvider - configuration provider
     */
    public ConfigResource(ResourceDescription resourceDescription, IConfigurationProvider configurationProvider) {
        super(resourceDescription, ResourceType.CONFIG);
        this.configurationProvider = configurationProvider;
    }

    @Override
    public void setText(String text) {
        super.setText(text);
        configurationProvider.populate(getText());
    }

}
