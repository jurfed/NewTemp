package com.atsisa.gox.framework.rendering.layer;

/**
 * Exposes methods for layer container.
 */
public interface ILayerContainer extends ILayer {

    /**
     * Adds a layer to this container.
     * @param layer - ILayer
     */
    void addChild(ILayer layer);

    /**
     * Removes all children/layers from this container.
     */
    void removeLayers();

    /**
     * Sets flag that layer has interactive children.
     * @param interactiveChildren true in layer has interactive children.
     */
    void setInteractiveChildren(boolean interactiveChildren);
}
