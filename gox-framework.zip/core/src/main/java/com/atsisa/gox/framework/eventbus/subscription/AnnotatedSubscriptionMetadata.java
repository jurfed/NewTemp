package com.atsisa.gox.framework.eventbus.subscription;

import java.util.Objects;

import com.atsisa.gox.framework.utility.reflection.Method;
import com.gwtent.reflection.client.Reflectable;

/**
 * Metadata class containing annotation-based subscription information.
 */
@Reflectable
public class AnnotatedSubscriptionMetadata {

    /**
     * Target object that has to be notified.
     */
    private final Object target;

    /**
     * Method reference that has to be invoked.
     */
    private final Method subscriptionMethod;

    /**
     * Filtering event type.
     */
    private final Class eventType;

    /**
     * Initializes a new instance of {@link AnnotatedSubscriptionMetadata}.
     * @param target             target object reference.
     * @param subscriptionMethod target object subscription method reference.
     * @param eventType          subscription filtering event.
     */
    public AnnotatedSubscriptionMetadata(Object target, Method subscriptionMethod, Class eventType) {
        this.target = target;
        this.subscriptionMethod = subscriptionMethod;
        this.eventType = eventType;
    }

    /**
     * Gets target object.
     * @return Object
     */
    public Object getTarget() {
        return target;
    }

    /**
     * Gets target object subscription method reference.
     * @return Method
     */
    public Method getSubscriptionMethod() {
        return subscriptionMethod;
    }

    /**
     * Gets target object subscription method filtering class.
     * @return Class
     */
    public Class getEventType() {
        return eventType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AnnotatedSubscriptionMetadata that = (AnnotatedSubscriptionMetadata) o;
        return Objects.equals(target, that.target) && Objects.equals(subscriptionMethod, that.subscriptionMethod) && Objects.equals(eventType, that.eventType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(target, subscriptionMethod, eventType);
    }
}
