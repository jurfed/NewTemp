package com.atsisa.gox.framework.view;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IMovieRenderer;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.AbstractMovieResource;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.atsisa.gox.framework.utility.ICloneable;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Movie view class.
 */
@Reflect_Full
@XmlElement
public class MovieView extends View implements ICloneable<MovieView> {

    /**
     * Describes possible movie states.
     */
    public enum State {

        /**
         * Represents playing state.
         */
        PLAYING,

        /**
         * Represents pause state.
         */
        PAUSE,

        /**
         * Represents stopped state.
         */
        STOPPED,

    }

    /**
     * Image view property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getMovieResource setMethod.
         */
        public static final int MOVIE = 1;

        /**
         * Represents a view property accessible via getState setMethod.
         */
        public static final int STATE = 1 << 1;

        /**
         * Represents a view property accessible via getVolume setMethod.
         */
        public static final int VOLUME = 1 << 2;

        /**
         * Represents a view property accessible via isLoop setMethod.
         */
        public static final int LOOP = 1 << 3;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

    /**
     * Movie resource reference.
     */
    @XmlAttribute(name = "src", type = AbstractMovieResource.class, converters = ResourceRefConverter.class)
    private final ViewProperty<AbstractMovieResource> movieResource = new ViewProperty<>(AbstractMovieResource.class, this, ViewType.MOVIE_VIEW,
            ViewPropertyName.MOVIE);

    /**
     * Current movie state.
     */
    private final ViewProperty<State> currentState = new ViewProperty<>(State.class, this, ViewType.MOVIE_VIEW, ViewPropertyName.STATE, State.STOPPED);

    /**
     * Movie volume value.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> volume = new ViewProperty<>(Float.class, this, ViewType.MOVIE_VIEW, ViewPropertyName.VOLUME, 1F);

    /**
     * A boolean value that indicates whether movie should be automatically play again after complete.
     */
    @XmlAttribute(type = Boolean.class)
    private final ViewProperty<Boolean> loop = new ViewProperty<>(Boolean.class, this, ViewType.MOVIE_VIEW, ViewPropertyName.LOOP, false);

    /**
     * A boolean value that indicates whether this movie should be automatically starts playing after movie resource will be set.
     */
    @XmlAttribute
    private boolean autoPlay;

    /**
     * Movie complete listener, which is registered in movie rendering.
     */
    private IMovieCompleteListener rendererMovieCompleteListener;

    /**
     * Movie complete listener list.
     */
    private List<IMovieCompleteListener> movieCompleteListeners = new ArrayList<>();

    /**
     * ILogger reference.
     */
    private ILogger logger;

    /**
     * Initializes a new instance of the MovieView class.
     */
    public MovieView() {
        this(GameEngine.current().getRenderer(), GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of the MovieView class.
     * @param renderer rendering reference
     * @param logger   logger reference
     */
    public MovieView(IRenderer renderer, ILogger logger) {
        super(renderer);
        this.logger = logger;
    }

    /**
     * Registers movie complete listener.
     * @param listener - IMovieCompleteListener
     */
    public void registerMovieCompleteListener(IMovieCompleteListener listener) {
        if (!movieCompleteListeners.contains(listener)) {
            movieCompleteListeners.add(listener);
        }
    }

    /**
     * Unregisters movie complete listener.
     * @param listener - IMovieCompleteListener
     * @return boolean
     */
    public boolean unregisterMovieCompleteListener(IMovieCompleteListener listener) {
        if (movieCompleteListeners != null) {
            try {
                return movieCompleteListeners.remove(listener);
            } catch (UnsupportedOperationException e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Gets an movie resource reference.
     * @return an movie resource.
     */
    public AbstractMovieResource getMovieResource() {
        return movieResource.get();
    }

    /**
     * Sets new movie resource.
     * @param newMovieResource - resource
     */
    public void setMovieResource(AbstractMovieResource newMovieResource) {
        movieResource.set(newMovieResource);
        registerListenerInMovieRenderer();
        if (autoPlay) {
            play();
        } else if (currentState.get() == State.PLAYING || currentState.get() == State.PAUSE) {
            stop();
        }
    }

    /**
     * Gets the movie resource property.
     * @return movie resource property
     */
    public IObservableProperty<AbstractMovieResource> movieResource() {
        return movieResource;
    }

    /**
     * Sets volume value.
     * @param value - float
     */
    public void setVolume(float value) {
        volume.set(value);
    }

    /**
     * Gets the volume property.
     * @return the volume property
     */
    public IObservableProperty<Float> volume() {
        return volume;
    }

    /**
     * Gets video volume value.
     * @return float
     */
    public float getVolume() {
        return volume.get();
    }

    /**
     * Sets a boolean value that indicates whether this movie should be automatically starts playing after movie resource will be set.
     * @param autoPlay boolean
     */
    public void setAutoPlay(boolean autoPlay) {
        this.autoPlay = autoPlay;
    }

    /**
     * Gets a boolean value which indicates whether movie is automatically play again after complete.
     * @return boolean
     */
    public boolean isLoop() {
        return loop.get();
    }

    /**
     * Sets a boolean value which indicates whether movie should be automatically played again after complete.
     * @param loop - boolean
     */
    public void setLoop(boolean loop) {
        this.loop.set(loop);
    }

    /**
     * Gets observable view property for loop.
     * @return observable view property for loop
     */
    public ViewProperty<Boolean> loop() {
        return loop;
    }

    /**
     * Gets current movie state.
     * @return State
     */
    public State getCurrentState() {
        return currentState.get();
    }

    /**
     * Starts/resume video.
     */
    public void play() {
        setState(State.PLAYING);
    }

    /**
     * Pause currently playing video.
     */
    public void pause() {
        setState(State.PAUSE);
    }

    /**
     * Stops current video.
     */
    public void stop() {
        setState(State.STOPPED);
    }

    /**
     * Returns info whether the video is playing or not.
     * @return boolean
     */
    public boolean isPlaying() {
        return currentState.get() == State.PLAYING;
    }

    /**
     * Creates and returns a new object with the same parameters.
     * @return MovieView
     */
    @Override
    public MovieView clone() {
        MovieView movieView = new MovieView(getRenderer(), logger);
        movieView.setMovieResource(getMovieResource());
        return movieView;
    }

    @Override
    public void dispose(){
        movieCompleteListeners.clear();
        super.dispose();
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.MOVIE_VIEW, ViewPropertyName.MOVIE | ViewPropertyName.STATE | ViewPropertyName.VOLUME | ViewPropertyName.LOOP);
        registerListenerInMovieRenderer();
    }

    /**
     * Registers listener in movie rendering.
     */
    private void registerListenerInMovieRenderer() {
        if (rendererMovieCompleteListener == null) {
            rendererMovieCompleteListener = this::onMovieComplete;
        }
        IMovieRenderer movieRenderer = (IMovieRenderer) getRenderer().getViewRenderer(getClass());
        movieRenderer.registerCompleteListener(this, rendererMovieCompleteListener);
    }

    /**
     * Called when currently playing movie is complete.
     */
    private void onMovieComplete() {
        setState(State.STOPPED);
        synchronized (movieCompleteListeners) {
            List<IMovieCompleteListener> tempListenerList = new ArrayList<>(movieCompleteListeners);
            for (IMovieCompleteListener listener : tempListenerList) {
                listener.onComplete();
            }
        }
    }

    /**
     * Changes current video state.
     * @param newState - State
     */
    private void setState(State newState) {
        if (currentState.get() != newState) {
            if (movieResource.get() != null) {
                if (currentState.get() == State.STOPPED && newState == State.PAUSE) {
                    logger.warn("MovieView | setState | can not pause video which is already stopped.");
                } else {
                    currentState.set(newState);
                }
            } else {
                logger.warn(StringUtility.format("MovieView | setState | can not change movie state to: %s, because movie resource was not set.", newState));
            }
        } else {
            logger.warn(StringUtility
                    .format("MovieView | setState | can not change movie to state to: %s, because movie is already in this state", currentState.get()));
        }
    }

}
