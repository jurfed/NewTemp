package com.atsisa.gox.framework.rendering;

import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.view.InteractiveView;

/**
 * Input event delegate. Propagates input events from layers to views.
 * @param <T> extends {@link ILayer}
 */
public abstract class InputEventDelegate<T extends ILayer> implements IInputEventDelegate<T> {

    /**
     * The state of this input delegate.
     */
    private final AtomicReference<InputEventDelegateState> delegateState = new AtomicReference<>(InputEventDelegateState.ACTIVE);

    /**
     * Bindings map, interactive views to layers.
     */
    private final Map<InteractiveView, T> bindings;

    /**
     * The active bindings.
     */
    private Map<InteractiveView, T> activeBindings;

    /**
     * Initializes a new instance of {@link InputEventDelegate} class.
     */
    protected InputEventDelegate() {
        bindings = new HashMap<>();
        activeBindings = bindings;
    }

    @Override
    public final void bind(InteractiveView interactiveView, T layer) {
        if (bindings.containsKey(interactiveView)) {
            return;
        }
        registerListener(layer);
        bindings.put(interactiveView, layer);
    }

    @Override
    public final void unbind(InteractiveView interactiveView) {
        if (bindings.containsKey(interactiveView)) {
            unregisterListener(bindings.get(interactiveView));
            bindings.remove(interactiveView);
        }
    }

    /**
     * Registers input listener from specific display object.
     * @param layer layer for registering listener
     */
    protected abstract void registerListener(T layer);

    /**
     * Unregisters input listener to specific display object.
     * @param layer layer for unregistering listener
     */
    protected abstract void unregisterListener(T layer);

    /**
     * Retrevies bound interactive view by layer.
     * @param layer bound layer
     * @return bound interactive view
     */
    protected final Optional<InteractiveView> retrieveInteractiveView(T layer) {
        return activeBindings.entrySet().stream().filter(entry -> entry.getValue().equals(layer)).map(Map.Entry::getKey).findFirst();
    }

    protected Map<InteractiveView, T> getBindings() {
        return bindings;
    }

    @Override
    public boolean pause(){
        if(delegateState.compareAndSet(InputEventDelegateState.ACTIVE, InputEventDelegateState.PAUSED)){
            activeBindings = Collections.emptyMap();
            return true;
        }
        return false;
    }

    @Override
    public boolean resume(){
        if(delegateState.compareAndSet(InputEventDelegateState.PAUSED, InputEventDelegateState.ACTIVE)){
            activeBindings = bindings;
            return true;
        }
        return false;
    }

    @Override
    public InputEventDelegateState getState() {
        return delegateState.get();
    }

    @Override
    public void clear(){
        bindings.clear();
        activeBindings.clear();
    }
}
