package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Data for {@link StartTimerAction}.
 */
@XmlElement
public class StartTimerActionData extends TimerActionData {

    /**
     * The timer duration.
     */
    @XmlAttribute
    private int duration;

    /**
     * Gets the timer duration.
     * @return the timer duration.
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Sets the timer duration.
     * @param duration the timer duration.
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }
}
