package com.atsisa.gox.framework.screen.event;

import com.atsisa.gox.framework.screen.Screen;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when the screen show started.
 */
@Reflectable
public class ScreenShowingEvent extends ScreenEvent {

    /**
     * Initializes a new instance of the {@link ScreenShowingEvent} class.
     * @param screen {@link Screen}
     */
    public ScreenShowingEvent(Screen screen) {
        super(screen);
    }
}
