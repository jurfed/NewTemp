package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Stops specific movie view.
 */
public class StopMovieAction extends MovieAction {

    /**
     * Creates a new instance of the StopMovieAction class.
     */
    public StopMovieAction() {
    }

    /**
     * Creates a new instance of the StopMovieAction class.
     * @param logger      a logger reference.
     * @param eventBus    an eventBus reference.
     * @param viewManager a viewManager reference.
     */
    public StopMovieAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus, viewManager);
    }

    @Override
    protected void execute() {
        movieView.stop();
        onFinish();
    }

}
