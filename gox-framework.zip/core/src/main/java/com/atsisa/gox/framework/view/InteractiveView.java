package com.atsisa.gox.framework.view;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.event.DragEventListener;
import com.atsisa.gox.framework.event.IEvent;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.InputEventListenerProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.rendering.InteractiveViewRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.converter.EventListenerConverter;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * An abstraction layers for interactive view.
 */
@Reflect_Full
public abstract class InteractiveView extends View {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Lists of objects that are listening for selected.
     */
    private final List<IEventListener> eventListeners;

    /**
     * A drag event listener.
     */
    private DragEventListener dragEventListener;

    /**
     * A value indicating whether or not the interactive view is draggable.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> draggable = new ObservableProperty<>(Boolean.class, false);

    /**
     * A value indicating whether or not the view should be snapped to center during dragging.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> snapToCenter = new ObservableProperty<>(Boolean.class, true);

    /**
     * Release listener.
     */
    @XmlAttribute(name = "onRelease", type = IEventListener.class, converters = EventListenerConverter.class)
    private final InputEventListenerProperty releaseListener = new InputEventListenerProperty(this, InputEventType.RELEASED);

    /**
     * Current button state info.
     */
    private final ViewProperty<InteractiveViewState> currentState = new ViewProperty<>(InteractiveViewState.class, this, ViewType.INTERACTIVE_VIEW,
            ViewPropertyName.STATE, InteractiveViewState.NORMAL_STATE);

    /**
     * Indicates that view has event listeners.
     */
    private final ViewProperty<Boolean> interactive = new ViewProperty<>(Boolean.class, this, ViewType.INTERACTIVE_VIEW, ViewPropertyName.INTERACTIVE,
            Boolean.FALSE);

    /**
     * Initializes a new instance of the AbstractInteractiveView class.
     */
    public InteractiveView() {
        lv = new LocalVariables();
        eventListeners = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the {@link InteractiveView} class.
     * @param renderer {@link IRenderer}
     */
    public InteractiveView(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
        eventListeners = new ArrayList<>();
    }

    /**
     * Gets current interactive view state.
     * @return interactive view state
     */
    public InteractiveViewState getCurrentState() {
        return currentState.get();
    }

    /**
     * Sets current state.
     * @param value {@link InteractiveViewState}
     */
    protected void setCurrentState(InteractiveViewState value) {
        currentState.set(value);
    }

    /**
     * Gets the state property.
     * @return state property.
     */
    public IObservableProperty<InteractiveViewState> currentState() {
        return currentState;
    }

    /**
     * Gets a boolean value that indicates whether this view is binds to native touch events.
     * @return boolean
     */
    public boolean isInteractive() {
        return interactive.get();
    }

    /**
     * Sets current state.
     * @param value {@link InteractiveViewState}
     */
    protected void setInteractive(boolean value) {
        interactive.set(value);
    }

    /**
     * Gets the state property.
     * @return state property.
     */
    public IObservableProperty<Boolean> interactive() {
        return interactive;
    }

    /**
     * Returns {true} if view has registered event listeners, otherwise {false}.
     * @return boolean.
     */
    public boolean hasEventListeners() {
        return !eventListeners.isEmpty();
    }

    /**
     * Registers new selected listener.
     * @param listener {@link IEventListener}
     */
    public void addEventListener(IEventListener listener) {
        if (listener != null) {
            if (!eventListeners.contains(listener)) {
                eventListeners.add(listener);
            }
            setInteractive(true);
        }
    }

    /**
     * Unregisters selected listener.
     * @param listener {@link IEventListener}.
     * @return boolean if "false" listener was not register to this view.
     */
    public boolean removeEventListener(IEventListener listener) {
        if (listener != null && listener == releaseListener.get()) {
            return releaseListener.set(null);
        }
        boolean result = eventListeners.remove(listener);
        if (eventListeners.isEmpty()) {
            setInteractive(false);
        }
        return result;
    }

    /**
     * Checks if the view is currently draggable.
     * @return a boolean value indicating whether or not current view is draggable.
     */
    public boolean isDraggable() {
        return draggable.get();
    }

    /**
     * Enables of disables dragging features in current interactive view.
     * @param draggable a value indicating enabling or disabling dragging features
     */
    public void setDraggable(boolean draggable) {
        if (draggable && dragEventListener == null) {
            dragEventListener = new DragEventListener(this);
            addEventListener(dragEventListener);
        } else if (!draggable) {
            removeEventListener(dragEventListener);
            dragEventListener = null;
        }
        this.draggable.set(draggable);
    }

    /**
     * Gets the draggable property.
     * @return the draggable property.
     */
    public IObservableProperty<Boolean> draggable() {
        return draggable;
    }

    /**
     * Gets a value indicating whether or not the view should be snapped to center.
     * @return a value indicating whether or not the view should be snapped to center.
     */
    public boolean isSnapToCenter() {
        return snapToCenter.get();
    }

    /**
     * Sets a value indicating whether or not the view should be snapped to center during dragging. The default value is
     * true.
     * @param snap a value indicating whether or not the view should be snapped to center.
     */
    public void setSnapToCenter(boolean snap) {
        snapToCenter.set(snap);
    }

    /**
     * Gets the snap to center property.
     * @return the snap to center property.
     */
    public IObservableProperty<Boolean> snapToCenter() {
        return snapToCenter;
    }

    /**
     * Triggers an event by notifying all the registered listeners.
     * @param event an event to trigger.
     */
    public void triggerEvent(IEvent event) {
        lv.viewInteractiveEvent = (InputEvent) event;
        lv.stateChanged = true;

        switch (lv.viewInteractiveEvent.getType()) {
            case TOUCH_START:
                setCurrentState(InteractiveViewState.DOWN_STATE);
                break;
            case MOUSE_OVER:
                setCurrentState(InteractiveViewState.OVER_STATE);
                break;
            case TOUCH_END:
                if (getCurrentState() != InteractiveViewState.NORMAL_STATE) {
                    lv.viewInteractiveEvent = new InputEvent(InputEventType.RELEASED, this);
                }
                setCurrentState(InteractiveViewState.NORMAL_STATE);
                break;
            case MOUSE_UP:
                if (getCurrentState() != InteractiveViewState.NORMAL_STATE) {
                    setCurrentState(InteractiveViewState.OVER_STATE);
                    lv.viewInteractiveEvent = new InputEvent(InputEventType.RELEASED, this);
                }
                break;
            case MOUSE_OUT:
                setCurrentState(InteractiveViewState.NORMAL_STATE);
                break;
            default:
                lv.stateChanged = false;
                break;
        }

        if (lv.stateChanged) {
            propertyChanged(ViewType.INTERACTIVE_VIEW, ViewPropertyName.STATE);
        }
        lv.size = eventListeners.size();
        for (lv.index = 0; lv.index < lv.size; lv.index++) {
            eventListeners.get(lv.index).onEvent(lv.viewInteractiveEvent);
        }
    }

    /**
     * Sets the release event listener by wrapping it into another listener which filters button releases.
     * @param releaseEventListener release event listener.
     */
    public void setReleaseListener(IEventListener<InputEvent> releaseEventListener) {
        releaseListener.set(releaseEventListener);
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.INTERACTIVE_VIEW, ViewPropertyName.STATE | ViewPropertyName.INTERACTIVE);
    }

    /**
     * Interactive view property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getState setMethod.
         */
        public static final int STATE = 1;

        /**
         * Represents a view property accessible via isInteractive setMethod.
         */
        public static final int INTERACTIVE = 1 << 1;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

    /**
     * Holder for instances of local variables used in the {@link InteractiveViewRenderer} render method.
     */
    class LocalVariables {

        private int index;

        private int size;

        private InputEvent viewInteractiveEvent;

        private boolean stateChanged;
    }
}
