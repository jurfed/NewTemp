package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.event.TimerFinishedEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.timer.ITimer;
import com.atsisa.gox.framework.utility.timer.ITimerManager;
import com.gwtent.reflection.client.Reflectable;

/**
 * Blocks the execution until the {@link TimerFinishedEvent} for given timer name is published.
 */
@Reflectable(fields = false)
public class WaitForTimerAction extends Action<WaitForTimerActionData> {

    /**
     * The timer manager.
     */
    private final ITimerManager timerManager;

    /**
     * The subscription.
     */
    private Subscription subscription;

    /**
     * The timer.
     */
    private ITimer timer;

    /**
     * Initializes a new instance of the {@link WaitForTimerAction} class.
     */
    public WaitForTimerAction() {
        timerManager = GameEngine.current().getUtility().getTimerManager();
    }

    /**
     * Initializes a new instance of the {@link WaitForTimerAction} class.
     * @param logger       {@link ILogger}
     * @param eventBus     {@link IEventBus}
     * @param timerManager {@link ITimerManager}
     */
    public WaitForTimerAction(ILogger logger, IEventBus eventBus, ITimerManager timerManager) {
        super(logger, eventBus);
        this.timerManager = timerManager;
    }

    @Override
    protected void execute() {
        subscription = eventBus.register(new NextObserver<TimerFinishedEvent>() {

            @Override
            public void onNext(TimerFinishedEvent timerFinishedEvent) {
                if (timerFinishedEvent.getTimer().getName().equals(actionData.getTimerName())) {
                    clearSubscription();
                    finish();
                }
            }
        }, TimerFinishedEvent.class);

        if (!timer.isActive()) {
            clearSubscription();
            finish();
        }
    }

    /**
     * Clears the subscription.
     */
    private void clearSubscription() {
        if (subscription != null) {
            subscription.unsubscribe();
        }
        subscription = null;
    }

    @Override
    protected void terminate() {
        clearSubscription();
        if (actionData.isCancelOnTerminate()) {
            timer.cancel();
        }
        finish();
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || actionData.getTimerName() == null) {
            throw new ValidationException("The timer name cannot be null.");
        }
        if (!timerManager.hasTimer(actionData.getTimerName())) {
            throw new ValidationException("The timer of given name does not exist in the TimerManager. Timer name: " + actionData.getTimerName());
        }
    }

    @Override
    protected void grabData() {
        timer = timerManager.getTimer(actionData.getTimerName());
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return WaitForTimerActionData.class;
    }
}
