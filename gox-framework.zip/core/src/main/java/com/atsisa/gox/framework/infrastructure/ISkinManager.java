package com.atsisa.gox.framework.infrastructure;

import com.atsisa.gox.framework.view.Skin;

/**
 * Interface for skin manager, which manages skins.
 */
public interface ISkinManager {

    /**
     * Gets skin with specific name.
     * @param name name of the skin
     * @return Skin. If skin is not found, then null is returned.
     */
    Skin getSkin(String name);
}
