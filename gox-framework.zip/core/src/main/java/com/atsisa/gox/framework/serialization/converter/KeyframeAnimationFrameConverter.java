package com.atsisa.gox.framework.serialization.converter;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.IResourceReference;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.KeyframeAnimationFrame;

/**
 * Converts the definition of keyframe animation frames.
 */
public class KeyframeAnimationFrameConverter extends PatternConverter {

    /**
     * Resource pattern attribute.
     */
    private static final String RESOURCE_PATTERN_ATTRIBUTE = "srcPattern";

    /**
     * Frames const.
     */
    private static final String FRAMES = "frames";

    /**
     * Frame const.
     */
    private static final String FRAME = "frame";

    /**
     * Name of the tag start.
     */
    private static final String START_TAG = "start";

    /**
     * Name of the tag end.
     */
    private static final String END_TAG = "end";

    /**
     * Name of the tag width.
     */
    private static final String WIDTH_TAG = "width";

    /**
     * Name of the tag height.
     */
    private static final String HEIGHT_TAG = "height";

    /**
     * Resource reference converter.
     */
    private final IValueConverter resourceConverter;

    /**
     * Resource manager reference.
     */
    private final IResourceManager resourceManager;

    /**
     * IXmlSerializer implementation.
     */
    private final IXmlSerializer serializer;

    /**
     * ILogger implementation.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of the KeyframeAnimationFrameConverter class.
     */
    public KeyframeAnimationFrameConverter() {
        ISerialization serialization = GameEngine.current().getUtility().getSerialization();
        serializer = serialization.getSerializer(SerializationFormat.XML);
        logger = GameEngine.current().getLogger();
        resourceManager = GameEngine.current().getResourceManager();
        resourceConverter = new ResourceRefConverter();
    }

    /**
     * Initializes a new instance of the KeyframeAnimationFrameConverter class.
     * @param newSerializer   - IXmlSerializer
     * @param newLogger       - ILogger
     * @param resourceManager - resource manager
     */
    public KeyframeAnimationFrameConverter(IXmlSerializer newSerializer, ILogger newLogger, IResourceManager resourceManager) {
        serializer = newSerializer;
        logger = newLogger;
        this.resourceManager = resourceManager;
        resourceConverter = new ResourceRefConverter();
    }

    /**
     * Gets the type of a value object
     * @return List.class
     */
    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    /**
     * Convert frames to xml string description.
     * @param objToConvert List of KeyframeAnimationFrame
     * @return position description
     */
    @Override
    @SuppressWarnings("unchecked")
    public String convertTo(Object objToConvert) {
        List<KeyframeAnimationFrame> keyframeAnimationFrames = (List<KeyframeAnimationFrame>) objToConvert;
        String description = StringUtility.format("<%s>", FRAMES);
        ResourceRefConverter resourceRefConverter = new ResourceRefConverter(resourceManager);
        IResourceReference resourceName;
        for (KeyframeAnimationFrame frame : keyframeAnimationFrames) {
            resourceName = frame.getImage();
            description = StringUtility
                    .format("%s<%s src=\"%s\" x=\"%s\" y=\"%s\"", description, FRAME, resourceRefConverter.convertTo(resourceName), frame.getX(), frame.getY());
            if (frame.getWidth() != 0) {
                description = StringUtility.format("%s width=\"%s\"", description, frame.getWidth());
            }
            if (frame.getHeight() != 0) {
                description = StringUtility.format("%s height=\"%s\"", description, frame.getHeight());
            }
            description = StringUtility.format("%s />", description);
        }

        description = StringUtility.format("%s</%s>", description, FRAMES);
        return description;
    }

    /**
     * Converts a string, parse object representation of frames.
     * @param serializedMessage a string representation of a Java object
     * @param parsedObject      IParsedObject
     * @return return List ofKeyframeAnimationFrame
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (serializedMessage == null || parsedObject == null) {
            return null;
        }
        XmlObject xmlObject;
        if (parsedObject instanceof XmlObject) {
            xmlObject = (XmlObject) parsedObject;
        } else if (parsedObject instanceof XmlObjectDocument) {
            xmlObject = ((XmlObjectDocument) parsedObject).getDocumentElement();
        } else {
            throw new ConversionException("Failed to convert parsedObject");
        }

        String srcPattern = xmlObject.getAttribute(RESOURCE_PATTERN_ATTRIBUTE);
        if (srcPattern != null) {
            return getFrameListUsingPattern(srcPattern, xmlObject);
        } else {
            return getFrameListUsingItems(xmlObject);
        }
    }

    /**
     * Gets a frame list using pattern description.
     * @param srcPattern image resource identifier pattern
     * @param xmlObject  xml element object
     * @return a list of animation frames
     */
    private List<KeyframeAnimationFrame> getFrameListUsingPattern(String srcPattern, XmlObject xmlObject) throws ConversionException {
        List<KeyframeAnimationFrame> frameList = new ArrayList<>();
        int start = Integer.parseInt(xmlObject.getAttribute(START_TAG));
        int end = Integer.parseInt(xmlObject.getAttribute(END_TAG));
        int width = 0;
        int height = 0;
        if (xmlObject.getAttribute(WIDTH_TAG) != null) {
            width = Integer.parseInt(xmlObject.getAttribute(WIDTH_TAG));
        }

        if (xmlObject.getAttribute(HEIGHT_TAG) != null) {
            height = Integer.parseInt(xmlObject.getAttribute(HEIGHT_TAG));
        }

        int[] patternSpan = getPatternSpan(srcPattern);
        for (int i = start; i <= end; i++) {
            String currentRef = getReference(srcPattern, patternSpan, i);
            KeyframeAnimationFrame frame = createFrame(width, height, currentRef);
            frameList.add(frame);
        }
        return frameList;
    }

    /**
     * Creates and returns new key frame animation object, it should be overwritten.
     * @param width       - int
     * @param height      - int
     * @param resourceRef - String
     * @return T extends KeyframeAnimationFrame
     */
    private KeyframeAnimationFrame createFrame(int width, int height, String resourceRef) throws ConversionException {
        try {
            IImageReference image = (IImageReference) resourceConverter.convertFrom(resourceRef, null);
            return new KeyframeAnimationFrame(image, width, height);
        } catch (ClassCastException ex) {
            throw new ConversionException("Unable to create an animation frame from the resource. Resource: " + resourceRef);
        }
    }

    /**
     * Gets a frame list using items description.
     * @param xmlObject xml element object
     * @return a list of animation frames
     */
    private List<KeyframeAnimationFrame> getFrameListUsingItems(XmlObject xmlObject) throws ConversionException {
        List<KeyframeAnimationFrame> frameList = new ArrayList<>();
        List<XmlObject> xmlChildren = xmlObject.getChildren();
        try {
            for (XmlObject xmlChild : xmlChildren) {
                if (xmlChild.getName().equals(FRAME)) {
                    KeyframeAnimationFrame frame = (KeyframeAnimationFrame) serializer.deserialize(xmlChild, KeyframeAnimationFrame.class, null);
                    frameList.add(frame);
                }
            }

            return frameList;
        } catch (SerializationException e) {
            logger.error(e.getMessage());
            throw new ConversionException("Unable to convert frames.", e);
        }
    }
}
