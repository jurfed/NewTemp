package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Action data class used in actions class who need information about the state.
 */
@XmlElement
public class StateActionData extends ActionData {

    /**
     * State.
     */
    @XmlAttribute
    private String state;

    /**
     * Gets state.
     * @return state.
     */
    public String getState() {
        return state;
    }

    /**
     * Sets new state.
     * @param state new state.
     */
    public void setState(String state) {
        this.state = state;
    }
}
