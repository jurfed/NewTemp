package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Hexadecimal color value converter.
 */
public class HexColorConverter implements IValueConverter {

    /**
     * Hexadecimal radix.
     */
    private static final int HEX_RADIX = 16;

    @Override
    public Class<?> getValueType() {
        return Integer.class;
    }

    @Override
    public String convertTo(Object objToConvert) {
        return StringUtility.format("#%s", Integer.toHexString((Integer) objToConvert));
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        if (serializedMessage != null && serializedMessage.startsWith("#")) {
            return Integer.parseInt(serializedMessage.substring(1), HEX_RADIX);
        }
        return null;
    }
}
