package com.atsisa.gox.framework.action;

import java.util.LinkedList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ActionStateException;
import com.atsisa.gox.framework.exception.AggregateException;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Represents a collection of actions executed in parallel.
 */
public class ParallelBundleAction extends Action<ParallelBundleActionData> {

    /**
     * The platform.
     */
    private final IPlatform platform;

    /**
     * The actions.
     */
    private List<Action> actions;

    /**
     * The finish condition strategy.
     */
    private IFinishConditionStrategy finishConditionStrategy;

    /**
     * The action listener.
     */
    private ActionListener actionListener;

    /**
     * Initializes a new instance of the {@link ParallelBundleAction} class.
     */
    public ParallelBundleAction() {
        platform = GameEngine.current().getPlatform();
    }

    /**
     * Initializes a new instance of the {@link ParallelBundleAction} class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     * @param platform a platform reference
     */
    public ParallelBundleAction(ILogger logger, IEventBus eventBus, IPlatform platform) {
        super(logger, eventBus);
        this.platform = platform;
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return ParallelBundleActionData.class;
    }

    @Override
    protected void grabData() {
        if (actionData == null) {
            return;
        }
        actions = actionData.getActions();
        finishConditionStrategy = createFinishConditionStrategy(actionData.getFinishCondition());
    }

    @Override
    protected void reset() {
        if (actions != null) {
            for (Action action : actions) {
                action.removeStateListener(actionListener);
                action.doReset();
            }
        }
        actions = null;
        finishConditionStrategy = null;
    }

    @Override
    protected void validate() throws ValidationException {
        if (actions == null || actions.isEmpty()) {
            throw new ValidationException("The collection of inner actions cannot be null or empty.");
        }
    }

    @Override
    protected void execute() {
        actionListener = new ActionListener();
        int index = 0;
        for (final Action action : actions) {
            action.setParentQueue(getParentQueue());
            action.setQueueIndex(index++);
            action.addStateListener(actionListener);
            platform.invokeLater(new Runnable() {

                @Override
                public void run() {
                    action.doExecute();
                }
            });
        }
    }

    @Override
    protected void terminate() {
        terminateActiveActions();
    }

    /**
     * Terminates active actions.
     */
    private synchronized void terminateActiveActions() {
        for (Action action : actions) {
            if (action.getState() == ActionState.ACTIVE) {
                action.doTerminate();
            }
        }
    }

    /**
     * Called when one of inner actions changes its state.
     * @param action      the action which changed the state
     * @param actionState the new action state
     */
    private synchronized void onActionStateChanged(Action action, ActionState actionState) {
        if (actionState != ActionState.SUCCEEDED && actionState != ActionState.FAILED) {
            return;
        }
        finishConditionStrategy.onActionFinished(action);
    }

    /**
     * Handles an action error.
     * @param error the action error
     */
    private void handleActionError(Throwable error) {
        fail(new ActionStateException("The ParallelBundleAction has failed because one of the inner actions has failed.", error), false);
    }

    /**
     * Creates a finish condition strategy based on a finish condition type.
     * @param finishCondition the finish condition type
     * @return the finish condition strategy
     */
    private IFinishConditionStrategy createFinishConditionStrategy(ParallelBundleActionData.FinishCondition finishCondition) {
        return finishCondition == ParallelBundleActionData.FinishCondition.ALL ? new AllFinishConditionStrategy() : new AnyFinishConditionStrategy();
    }

    /**
     * Represents parallel action's finish condition strategy.
     */
    private interface IFinishConditionStrategy {

        /**
         * Called when an action has either succeeded or failed.
         * @param action Finished action.
         */
        void onActionFinished(Action action);
    }

    /**
     * A strategy for finishing the action when at least one inner action is finished.
     */
    private class AnyFinishConditionStrategy implements IFinishConditionStrategy {

        @Override
        public void onActionFinished(Action action) {
            terminateActiveActions();
            switch (action.getState()) {
                case SUCCEEDED:
                    finish();
                    break;
                case FAILED:
                    handleActionError(action.getError());
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * A strategy for finishing the action when all inner actions are finished.
     */
    private class AllFinishConditionStrategy implements IFinishConditionStrategy {

        /**
         * A counter for finished actions.
         */
        private int finishedActionsCount;

        @Override
        public void onActionFinished(Action action) {
            finishedActionsCount++;
            if (finishedActionsCount != actions.size()) {
                return;
            }
            List<Throwable> errors = new LinkedList<>();
            boolean failed = false;
            for (Action currentAction : actions) {
                if (currentAction.getState() == ActionState.FAILED) {
                    failed = true;
                }
                if (currentAction.getError() != null) {
                    errors.add(currentAction.getError());
                }
            }
            if (failed) {
                Throwable innerException = !errors.isEmpty() ? new AggregateException(errors) : null;
                handleActionError(innerException);
            } else {
                finish();
            }
        }
    }

    /**
     * The action listener.
     */
    private class ActionListener implements IStateListener<ActionState> {

        @Override
        public void stateChanged(Object source, ActionState state) {
            onActionStateChanged((Action) source, state);
        }
    }
}
