package com.atsisa.gox.framework.command;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * A command which result in starting a new Timer component.
 */
@Reflect_Mini
public class StartTimerCommand {

    /**
     * The timer name.
     */
    private final String timerName;

    /**
     * The duration.
     */
    private final int duration;

    /**
     * Initializes a new instance of the {@link StartTimerCommand}
     * class.
     * @param timerName The timer name.
     * @param duration  The duration in milliseconds.
     */
    public StartTimerCommand(String timerName, int duration) {
        this.timerName = timerName;
        this.duration = duration;
    }

    /**
     * Gets the name of the timer.
     * @return the timer name.
     */
    public String getTimerName() {
        return timerName;
    }

    /**
     * Gets the timer duration in milliseconds.
     * @return the timer duration in milliseconds.
     */
    public int getDuration() {
        return duration;
    }
}
