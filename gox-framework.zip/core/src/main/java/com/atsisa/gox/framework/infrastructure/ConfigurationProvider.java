package com.atsisa.gox.framework.infrastructure;

import com.atsisa.gox.framework.configuration.BaseConfiguration;
import com.atsisa.gox.framework.configuration.Configuration;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.resource.ConfigResource;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * An implementation of the configuration provider interface.
 * Keeps the latest instance of the configuration created from text resources.
 */
public class ConfigurationProvider implements IConfigurationProvider {

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Current configuration object.
     */
    private final BaseConfiguration configuration;

    /**
     * A XML serializer.
     */
    private final IXmlSerializer serializer;

    /**
     * Initializes a new instance of the {@link ConfigurationProvider} class.
     * @param serializer {@link IXmlSerializer}
     * @param logger        {@link ILogger}
     */
    @Inject
    public ConfigurationProvider(IXmlSerializer serializer, ILogger logger) {
        logger.trace("ConfigurationProvider | ctor");
        this.serializer = serializer;
        configuration = new BaseConfiguration();
        this.logger = logger;
    }

    @Override
    public boolean populate(ConfigResource configResource) {
        return populate(configResource.getText());
    }

    @Override
    public boolean populate(String text) {
        logger.debug("ConfigurationProvider | populate");
        try {
            Configuration config = (Configuration) serializer.deserialize(text, Configuration.class);
            configuration.merge(config);
            return true;
        } catch (SerializationException e) {
            logger.error("ConfigurationProvider | populate | An error occurred during populating configuration object", e);
            return false;
        }
    }

    @Override
    public IConfiguration getConfiguration() {
        return configuration;
    }
}
