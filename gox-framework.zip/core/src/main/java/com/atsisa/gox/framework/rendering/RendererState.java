package com.atsisa.gox.framework.rendering;

/**
 * Represents state of the {@link IRenderer} class.
 */
public enum RendererState {

    /**
     * The delegate currently does not render views.
     */
    PAUSED,

    /**
     * The renderer currently rendering views.
     */
    ACTIVE
}
