package com.atsisa.gox.framework.animation;

import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.View;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenCallback;
import aurelienribon.tweenengine.TweenEquation;
import aurelienribon.tweenengine.equations.Linear;

/**
 * Implementation of tween class for View objects.
 */
public class TweenViewAnimation extends TweenAnimation implements IViewAnimation {

    /**
     * View object which is animated.
     */
    private View targetView;

    /**
     * What kind of tween are we using.
     */
    private TweenEquation tweenEquation;

    /**
     * View property which will be changed when animate.
     */
    private int tweenType;

    /**
     * Delay before start animation.
     */
    private float delay;

    /**
     * How much animation repeats.
     */
    private int repeatCount;

    /**
     * Watched states.
     */
    private int watchedStates;

    /**
     * Delay between animation repeats.
     */
    private float repeatDelay;

    /**
     * Duration of the animation.
     */
    private float timeSpan;

    /**
     * Destination X - coordinate.
     */
    private float destinationX;

    /**
     * Destination Y - coordinate.
     */
    private float destinationY;

    /**
     * Destination alpha level.
     */
    private float destinationAlpha;

    /**
     * How much scale in X.
     */
    private float destinationScaleX;

    /**
     * How much scale in Y.
     */
    private float destinationScaleY;

    /**
     * Destination width of view object.
     */
    private float destinationWidth;

    /**
     * Destination height of view object.
     */
    private float destinationHeight;

    /**
     * Constructor, which allow to set external manager. Set some default animation properties.
     * @param controller animation controller
     */
    public TweenViewAnimation(IAnimationController<TweenAnimation> controller) {
        super(controller);
        watchedStates = TweenCallback.COMPLETE;
        setTimeSpan(1.0f);
        setDestinationAlpha(1.0f);
        setTweenEquation(Linear.INOUT);
    }

    /**
     * Sets view animation data.
     * @param data - ViewAnimationData
     * @throws IllegalArgumentException the data is null.
     */
    public void setViewAnimationData(TweenViewAnimationData data) {
        if (data == null) {
            throw new IllegalArgumentException("The TweenViewAnimationData cannot be null.");
        }

        if (data.getDestinationX() != null) {
            setDestinationX(data.getDestinationX());
        }
        if (data.getDestinationY() != null) {
            setDestinationY(data.getDestinationY());
        }
        if (data.getDestinationAlpha() != null) {
            setDestinationAlpha(data.getDestinationAlpha());
        }
        if (data.getDestinationHeight() != null) {
            setDestinationHeight(data.getDestinationHeight());
        }
        if (data.getDestinationWidth() != null) {
            setDestinationWidth(data.getDestinationWidth());
        }
        if (data.getDestinationScaleX() != null) {
            setDestinationScaleX(data.getDestinationScaleX());
        }
        if (data.getDestinationScaleY() != null) {
            setDestinationScaleY(data.getDestinationScaleY());
        }
        setTimeSpan(data.getTimeSpan());
    }

    /**
     * Gets the tween ease type.
     * @return ease type
     */
    public TweenEquation getTweenEquation() {
        return tweenEquation;
    }

    /**
     * Sets the tween ease type.
     * @param tweenEquation ease type
     * @return this
     */
    public TweenViewAnimation setTweenEquation(TweenEquation tweenEquation) {
        this.tweenEquation = tweenEquation;
        return this;
    }

    /**
     * Gets the delay before animation starts.
     * @return time in seconds
     */
    public float getDelay() {
        return delay;
    }

    /**
     * Sets the delay before animation starts.
     * @param delay - time in seconds
     * @return this
     */
    public TweenViewAnimation setDelay(float delay) {
        this.delay = delay;
        return this;
    }

    /**
     * Gets the repeat animation count.
     * @return number of repetitions
     */
    public int getRepeatCount() {
        return repeatCount;
    }

    /**
     * Sets the repeat animation count.
     * @param repeatCount number of repetitions
     * @return this
     */
    public TweenViewAnimation setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
        return this;
    }

    /**
     * Gets the delay between animation repeat.
     * @return - time in seconds
     */
    public float getRepeatDelay() {
        return repeatDelay;
    }

    /**
     * Sets the delay between animation repeat.
     * @param repeatDelay - time in seconds
     * @return this
     */
    public TweenViewAnimation setRepeatDelay(float repeatDelay) {
        this.repeatDelay = repeatDelay;
        return this;
    }

    /**
     * Gets the destination alpha level.
     * @return - alpha between 0 and 1f
     */
    public float getDestinationAlpha() {
        return destinationAlpha;
    }

    /**
     * Sets the destination alpha level.
     * @param destinationAlpha - alpha between 0 and 1f
     * @return this
     */
    public TweenViewAnimation setDestinationAlpha(float destinationAlpha) {
        this.destinationAlpha = destinationAlpha;
        setTweenType(View.ViewPropertyName.ALPHA);
        return this;
    }

    /**
     * Gets the horizontal scale (percentage) of an destination view.
     * @return float
     */
    public float getDestinationScaleX() {
        return destinationScaleX;
    }

    /**
     * Sets the horizontal scale (percentage) of an destination view.
     * @param destinationScaleX float
     * @return this
     */
    public TweenViewAnimation setDestinationScaleX(float destinationScaleX) {
        this.destinationScaleX = destinationScaleX;
        setTweenType(View.ViewPropertyName.SCALE_X);
        return this;
    }

    /**
     * Gets the vertical scale (percentage) of an destination view.
     * @return float
     */
    public float getDestinationScaleY() {
        return destinationScaleY;
    }

    /**
     * Sets the vertical scale (percentage) of an destination view.
     * @param destinationScaleY float
     * @return this
     */
    public TweenViewAnimation setDestinationScaleY(float destinationScaleY) {
        this.destinationScaleY = destinationScaleY;
        setTweenType(View.ViewPropertyName.SCALE_Y);
        return this;
    }

    /**
     * Gets the destination width of view object.
     * @return width in pixels.
     */
    public float getDestinationWidth() {
        return destinationWidth;
    }

    /**
     * Sets the destination width of view object
     * @param destinationWidth width in pixels.
     * @return this
     */
    public TweenViewAnimation setDestinationWidth(float destinationWidth) {
        this.destinationWidth = destinationWidth;
        setTweenType(View.ViewPropertyName.WIDTH);
        return this;
    }

    /**
     * Gets the destination height of view object.
     * @return height in pixels
     */
    public float getDestinationHeight() {
        return destinationHeight;
    }

    /**
     * Sets the destination height of view object.
     * @param destinationHeight height in pixels
     * @return this
     */
    public TweenViewAnimation setDestinationHeight(float destinationHeight) {
        this.destinationHeight = destinationHeight;
        setTweenType(View.ViewPropertyName.HEIGHT);
        return this;
    }

    /**
     * Gets the ease type.
     * @return ease type
     */
    public int getTweenType() {
        return tweenType;
    }

    /**
     * Sets the ease type.
     * @param tweenType ease type
     * @return this
     */
    public TweenViewAnimation setTweenType(int tweenType) {
        this.tweenType = BitUtility.set(tweenType, this.tweenType);
        return this;
    }

    /**
     * Gets the destination X coordinate of view object.
     * @return float
     */
    public float getDestinationX() {
        return destinationX;
    }

    /**
     * Sets the destination X coordinate of view object.
     * @param destinationX float
     * @return this
     */
    public TweenViewAnimation setDestinationX(float destinationX) {
        this.destinationX = destinationX;
        setTweenType(View.ViewPropertyName.X);
        return this;
    }

    /**
     * Gets the destination Y coordinate of view object.
     * @return float
     */
    public float getDestinationY() {
        return destinationY;
    }

    /**
     * Sets the destination Y coordinate of view object.
     * @param destinationY float
     * @return this
     */
    public TweenViewAnimation setDestinationY(float destinationY) {
        this.destinationY = destinationY;
        setTweenType(View.ViewPropertyName.Y);
        return this;
    }

    /**
     * Gets length of animation.
     * @return time in milliseconds.
     */
    public float getTimeSpan() {
        return timeSpan;
    }

    /**
     * Sets length of animation.
     * @param timeSpan time in milliseconds.
     * @return this
     */
    public TweenViewAnimation setTimeSpan(float timeSpan) {
        this.timeSpan = timeSpan;
        return this;
    }

    /**
     * Sets a view with is a subject of this animation.
     * @param targetView object to animate
     * @return this
     */
    public TweenViewAnimation setTargetView(View targetView) {
        this.targetView = targetView;
        return this;
    }

    @Override
    public View getTargetView() {
        return targetView;
    }

    /**
     * Gets a flag indicating tween states watched on this animation.
     * @return A flag indicating tween states watched on this animation.
     */
    public int getWatchedStates() {
        return watchedStates;
    }

    /**
     * Sets a flag indicating tween states watched on this animation.
     * @param watchedStates a flag indicating tween states watched on this animation.
     * @return current instance of {@link TweenViewAnimation}
     */
    public TweenViewAnimation setWatchedStates(int watchedStates) {
        this.watchedStates = watchedStates;
        return this;
    }

    @Override
    public void setTween(BaseTween<Tween> tween) {
        throw new UnsupportedOperationException(
                "The tween cannot be overridden in this class. If you want to use custom predefined class, use TweenAnimation instead.");
    }

    /**
     * Creates tween object using properties selected before.
     * @return tween object
     */
    @Override
    protected BaseTween<Tween> createTween() {
        Tween tween = Tween.to(targetView, tweenType, timeSpan);
        return tween.target(getDestinationValues()).ease(tweenEquation).delay(delay).setCallbackTriggers(watchedStates).repeat(repeatCount, repeatDelay);
    }

    @Override
    protected void validateReadyToPlay() {
        if (targetView == null) {
            throw new IllegalStateException("The target view for the TweenViewAnimation has not been set.");
        }
    }

    /**
     * Creates an array of destination values.
     * @return An array of destination values.
     */
    private float[] getDestinationValues() {
        int propertiesAmount = Integer.bitCount(tweenType);
        float[] properties = new float[propertiesAmount];
        int index = 0;
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.X)) {
            properties[index++] = destinationX;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.Y)) {
            properties[index++] = destinationY;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.WIDTH)) {
            properties[index++] = destinationWidth;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.HEIGHT)) {
            properties[index++] = destinationHeight;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_X)) {
            properties[index++] = destinationScaleX;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_Y)) {
            properties[index++] = destinationScaleY;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.ALPHA)) {
            properties[index++] = destinationAlpha;
        }
        return properties;
    }
}
