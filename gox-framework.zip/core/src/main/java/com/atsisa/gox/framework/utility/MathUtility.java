package com.atsisa.gox.framework.utility;

/**
 * Utility class containing all math related aspects.
 */
public final class MathUtility {

    /**
     * Prevents from creating instances of this class.
     */
    private MathUtility() {
    }

    /**
     * Gets linearly interpolates between fromValue to toValue on progress position.
     * @param fromValue The start value.
     * @param toValue   The end value.
     * @param progress  The progress.
     * @return linearly interpolates between fromValue to toValue on progress position
     */
    public static float lerp(float fromValue, float toValue, float progress) {
        return fromValue + (toValue - fromValue) * progress;
    }

    /**
     * Limits given value to a selected range.
     * @param value The value.
     * @param min   The range start.
     * @param max   The range end.
     * @return A value greater than min and smaller than max.
     */
    public static float clamp(float value, float min, float max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    /**
     * Finds intersection of two rectangles.
     * @param rect1 - Rectangle
     * @param rect2 - Rectangle
     * @return intersection of two rectangles
     */
    public static Rectangle intersection(Rectangle rect1, Rectangle rect2) {
        float x2 = rect1.getX() + rect1.getWidth();
        float x4 = rect2.getX() + rect2.getWidth();
        float y1 = rect1.getY() - rect1.getHeight();
        float y3 = rect2.getY() - rect2.getHeight();

        float xL = Math.max(rect1.getX(), rect2.getX());
        float xR = Math.min(x2, x4);
        if (xR <= xL) {
            return null;
        } else {
            float yT = Math.max(y1, y3);
            float yB = Math.min(rect1.getY(), rect2.getY());
            if (yB <= yT) {
                return null;
            } else {
                return new Rectangle(xL, yB, xR - xL, yB - yT);
            }
        }
    }

    /**
     * Computes the intersection point of two line sections.
     * @param p0_x The X position of the first line's starting point.
     * @param p0_y The Y position of the first line's starting point.
     * @param p1_x The X position of the first line's end point.
     * @param p1_y The Y position of the first line's end point.
     * @param p2_x The X position of the second line's starting point.
     * @param p2_y The Y position of the second line's starting point.
     * @param p3_x The X position of the second line's end point.
     * @param p3_y The Y position of the second line's end point.
     * @return the intersection point of two line sections
     */
    public static Point intersection(float p0_x, float p0_y, float p1_x, float p1_y, float p2_x, float p2_y, float p3_x, float p3_y) {
        float s02_x;
        float s02_y;
        float s10_x;
        float s10_y;
        float s32_x;
        float s32_y;
        float s_numer;
        float t_numer;
        float denom;
        float t;
        s10_x = p1_x - p0_x;
        s10_y = p1_y - p0_y;
        s32_x = p3_x - p2_x;
        s32_y = p3_y - p2_y;

        denom = s10_x * s32_y - s32_x * s10_y;
        if (denom == 0) {
            return null;
        }

        boolean denomPositive = denom > 0;

        s02_x = p0_x - p2_x;
        s02_y = p0_y - p2_y;
        s_numer = s10_x * s02_y - s10_y * s02_x;
        if (s_numer < 0 == denomPositive) {
            return null;
        }

        t_numer = s32_x * s02_y - s32_y * s02_x;
        if (t_numer < 0 == denomPositive) {
            return null;
        }

        if (s_numer > denom == denomPositive || t_numer > denom == denomPositive) {
            return null;
        }

        // Collision detected
        t = t_numer / denom;

        Point intersection = new Point();
        intersection.setX(p0_x + t * s10_x);
        intersection.setY(p0_y + t * s10_y);
        return intersection;
    }

    /**
     * Returns the Euclidean distance between the specified two points.
     * @param x1 First point's X coordinate.
     * @param y1 First point's Y coordinate.
     * @param x2 Second point's X coordinate.
     * @param y2 Second point's Y coordinate.
     * @return the Euclidean distance
     */
    public static float distance(float x1, float y1, float x2, float y2) {
        return (float) Math.sqrt(distanceSq(x1, y1, x2, y2));
    }

    /**
     * Returns the squared Euclidean distance between the specified two points.
     * @param x1 First point's X coordinate
     * @param y1 First point's Y coordinate
     * @param x2 Second point's X coordinate
     * @param y2 Second point's Y coordinate
     * @return the squared Euclidean distance
     */
    public static float distanceSq(float x1, float y1, float x2, float y2) {
        x2 -= x1;
        y2 -= y1;
        return x2 * x2 + y2 * y2;
    }
}
