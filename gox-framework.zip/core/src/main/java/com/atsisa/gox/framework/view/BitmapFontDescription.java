package com.atsisa.gox.framework.view;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.resource.AbstractImageResource;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Bitmap font description.
 */
@Reflect_Full
@XmlElement(name = "font")
public class BitmapFontDescription {

    /**
     * Bitmap char description list.
     */
    @XmlCollectionElement(name = "chars", itemName = "char", itemType = Char.class)
    private List<Char> charList = new ArrayList<>();

    /**
     * Bitmap font page list.
     */
    @XmlCollectionElement(name = "pages", itemName = "page", itemType = Page.class)
    private List<Page> pageList = new ArrayList<>();

    /**
     * Bitmap font page description list.
     */
    @XmlCollectionElement(name = "kernings", itemName = "kerning", itemType = Kerning.class)
    private List<Kerning> kerningList = new ArrayList<>();

    /**
     * Common bitmap font settings.
     */
    @XmlElement(name = "common")
    private Common commonSettings;

    /**
     * Basic info about this bitmap font.
     */
    @XmlElement(name = "info")
    private Info fontInfo;

    /**
     * Creates a new instance of BitmapFontDescription class.
     */
    public BitmapFontDescription() {
        fontInfo = new Info();
        commonSettings = new Common();
    }

    /**
     * Sets image resource for specific bitmap font page.
     * @param imageResource - ImageResource.
     * @param pageId        - int
     */
    public void setPageImage(AbstractImageResource imageResource, int pageId) {
        for (Page page : pageList) {
            if (page.getId() == pageId) {
                page.setImageResource(imageResource);
                break;
            }
        }
    }

    /**
     * Gets image resource for specific bitmap font page.
     * @param pageId - int
     * @return ImageResource.
     */
    public AbstractImageResource getPageImage(int pageId) {
        for (Page page : pageList) {
            if (page.getId() == pageId) {
                return page.getImageResource();
            }
        }
        return null;
    }

    /**
     * Sets bitmap font common settings.
     * @param newCommonSettings - Common
     */
    public void setCommonSettings(Common newCommonSettings) {
        commonSettings = newCommonSettings;
    }

    /**
     * Sets basic info about bitmap font.
     * @param newInfo - Info
     */
    public void setFontInfo(Info newInfo) {
        fontInfo = newInfo;
    }

    /**
     * Gets default font size.
     * @return int
     */
    public int getDefaultFontSize() {
        if (fontInfo != null) {
            return fontInfo.getSize();
        }
        return 0;
    }

    /**
     * Sets default font size.
     * @param value - int
     */
    public void setDefaultFontSize(int value) {
        if (fontInfo != null) {
            fontInfo.setSize(value);
        }
    }

    /**
     * Gets font name.
     * @return String
     */
    public String getFontName() {
        if (fontInfo != null) {
            return fontInfo.getFace();
        }
        return "";
    }

    /**
     * Sets font name.
     * @param value - String
     */
    public void setFontName(String value) {
        if (fontInfo != null) {
            fontInfo.setFace(value);
        }
    }

    /**
     * Gets line height.
     * @return int
     */
    public int getLineHeight() {
        if (commonSettings != null) {
            return commonSettings.getLineHeight();
        }
        return 0;
    }

    /**
     * Sets line height.
     * @param value - int
     */
    public void setLineHeight(int value) {
        if (commonSettings != null) {
            commonSettings.setLineHeight(value);
        }
    }

    /**
     * Gets kerning list.
     * @return List of Kerning
     */
    public List<Kerning> getKerningList() {
        return kerningList;
    }

    /**
     * Sets kerning list.
     * @param kerningList List of Kerning
     */
    public void setKerningList(List<Kerning> kerningList) {
        this.kerningList = kerningList;
    }

    /**
     * Gets bitmap char description list.
     * @return List of Char
     */
    public List<Char> getCharList() {
        return charList;
    }

    /**
     * Sets bitmap char description list.
     * @param newCharList List of Char
     */
    public void setCharList(List<Char> newCharList) {
        charList = newCharList;
    }

    /**
     * Adds bitmap char description to list.
     * @param charDescription Char
     */
    public void addChar(Char charDescription) {
        charList.add(charDescription);
    }

    /**
     * Adds new page info with bitmap font image.
     * @param page Page
     */
    public void addPage(Page page) {
        pageList.add(page);
    }

    /**
     * Gets bitmap font page description list.
     * @return List of Page
     */
    public List<Page> getPageList() {
        return pageList;
    }

    /**
     * Sets bitmap font page description list.
     * @param newPageList List of Page
     */
    public void setPageList(List<Page> newPageList) {
        pageList = newPageList;
    }

    /**
     * Sets bold value.
     * @param bold int
     */
    public void setBold(int bold) {
        if (fontInfo != null) {
            fontInfo.setBold(bold);
        }
    }

    /**
     * Gets bold value.
     * @return int
     */
    public int getBold() {
        if (fontInfo != null) {
            return fontInfo.getBold();
        }
        return 0;
    }

    /**
     * Sets base value.
     * @param base int
     */
    public void setBase(int base) {
        if (commonSettings != null) {
            commonSettings.setBase(base);
        }
    }

    /**
     * Gets base value.
     * @return int
     */
    public int getBase() {
        if (commonSettings != null) {
            return commonSettings.getBase();
        }
        return 0;
    }

    /**
     * Gets spacing value.
     * @return String
     */
    public String getSpacing() {
        if (fontInfo != null) {
            return fontInfo.getSpacing();
        }
        return "";
    }

    /**
     * Sets spacing value.
     * @param spacing String
     */
    public void setSpacing(String spacing) {
        if (fontInfo != null) {
            fontInfo.setSpacing(spacing);
        }
    }

    /**
     * Gets padding value.
     * @return String
     */
    public String getPadding() {
        if (fontInfo != null) {
            return fontInfo.getPadding();
        }
        return "";
    }

    /**
     * Sets padding value.
     * @param padding - String
     */
    public void setPadding(String padding) {
        if (fontInfo != null) {
            fontInfo.setPadding(padding);
        }
    }

    /**
     * Gets italic value.
     * @return int
     */
    public int getItalic() {
        if (fontInfo != null) {
            return fontInfo.getItalic();
        }
        return 0;
    }

    /**
     * Sets italic value.
     * @param italic - int
     */
    public void setItalic(int italic) {
        if (fontInfo != null) {
            fontInfo.setItalic(italic);
        }
    }

    /**
     * Class describes common settings of bitmap font.
     */
    @XmlElement
    @Reflect_Full
    public static class Common {

        /**
         * Height of bitmap font line height.
         */
        @XmlAttribute
        private int lineHeight;

        /**
         * Base attribute.
         */
        @XmlAttribute
        private int base;

        /**
         * Gets base attribute value.
         * @return int
         */
        public int getBase() {
            return base;
        }

        /**
         * Sets base attribute value.
         * @param base - int
         */
        public void setBase(int base) {
            this.base = base;
        }

        /**
         * Sets bitmap font line height.
         * @param value - int
         */
        public void setLineHeight(int value) {
            lineHeight = value;
        }

        /**
         * Gets bitmap font line height.
         * @return int
         */
        public int getLineHeight() {
            return lineHeight;
        }

    }

    /**
     * Class describes kerning info.
     */
    @XmlElement
    @Reflect_Full
    public static class Kerning {

        /**
         * First char id.
         */
        @XmlAttribute
        private int first;

        /**
         * Second char id.
         */
        @XmlAttribute
        private int second;

        /**
         * Amount for specific kerning.
         */
        @XmlAttribute
        private int amount;

        /**
         * Gets first char id.
         * @return int
         */
        public int getFirst() {
            return first;
        }

        /**
         * Sets first char id.
         * @param first - int
         */
        public void setFirst(int first) {
            this.first = first;
        }

        /**
         * Gets char amount.
         * @return int
         */
        public int getAmount() {
            return amount;
        }

        /**
         * Sets char amount.
         * @param amount - int
         */
        public void setAmount(int amount) {
            this.amount = amount;
        }

        /**
         * Gets second char id.
         * @return int
         */
        public int getSecond() {
            return second;
        }

        /**
         * Sets second char id.
         * @param second - int
         */
        public void setSecond(int second) {
            this.second = second;
        }
    }

    /**
     * Class describes basic info of bitmap font.
     */
    @XmlElement
    @Reflect_Full
    public static class Info {

        /**
         * Font name.
         */
        @XmlAttribute
        private String face;

        /**
         * Default font size.
         */
        @XmlAttribute
        private int size;

        /**
         * Bold attribute.
         */
        @XmlAttribute
        private int bold;

        /**
         * Italic attribute.
         */
        @XmlAttribute
        private int italic;

        /**
         * Padding attribute.
         */
        @XmlAttribute
        private String padding;

        /**
         * Spacing attribute.
         */
        @XmlAttribute
        private String spacing;

        /**
         * Gets bold attribute value.
         * @return int
         */
        public int getBold() {
            return bold;
        }

        /**
         * Sets bold attribute value.
         * @param bold - int
         */
        public void setBold(int bold) {
            this.bold = bold;
        }

        /**
         * Gets spacing attribute value.
         * @return String
         */
        public String getSpacing() {
            return spacing;
        }

        /**
         * Sets spacing attribute value.
         * @param spacing - String
         */
        public void setSpacing(String spacing) {
            this.spacing = spacing;
        }

        /**
         * Gets padding attribute value.
         * @return String
         */
        public String getPadding() {
            return padding;
        }

        /**
         * Sets padding attribute value.
         * @param padding - String
         */
        public void setPadding(String padding) {
            this.padding = padding;
        }

        /**
         * Gets italic attribute value.
         * @return int
         */
        public int getItalic() {
            return italic;
        }

        /**
         * Sets italic attribute value.
         * @param italic - int
         */
        public void setItalic(int italic) {
            this.italic = italic;
        }

        /**
         * Sets font name.
         * @param value - String
         */
        public void setFace(String value) {
            face = value;
        }

        /**
         * Gets font name.
         * @return String
         */
        public String getFace() {
            return face;
        }

        /**
         * Sets default font size.
         * @param value - int
         */
        public void setSize(int value) {
            size = value;
        }

        /**
         * Gets default font size.
         * @return int
         */
        public int getSize() {
            return size;
        }

    }

    /**
     * Bitmap font page description.
     */
    @Reflect_Full
    @XmlElement
    public static class Page {

        /**
         * Page id.
         */
        @XmlAttribute
        private int id;

        /**
         * Path to page file.
         */
        @XmlAttribute(name = "file")
        private String filePath;

        /**
         * Bitmap font image resource for this page.
         */
        private AbstractImageResource imageResource;

        /**
         * Sets id page.
         * @param value - int
         */
        public void setId(int value) {
            id = value;
        }

        /**
         * Gets id page.
         * @return int
         */
        public int getId() {
            return id;
        }

        /**
         * Sets path to page file.
         * @param value - String
         */
        public void setFilePath(String value) {
            filePath = value;
        }

        /**
         * Gets path to page file.
         * @return String
         */
        public String getFilePath() {
            return filePath;
        }

        /**
         * Sets image resource for this page.
         * @param newImageResource - ImageResource
         */
        public void setImageResource(AbstractImageResource newImageResource) {
            imageResource = newImageResource;
        }

        /**
         * Gets image resource for this page.
         * @return ImageResource
         */
        public AbstractImageResource getImageResource() {
            return imageResource;
        }

    }

    /**
     * Single bitmap font char description.
     */
    @Reflect_Full
    @XmlElement
    public static class Char {

        /**
         * Id bitmap char, representing ASCII code.
         */
        @XmlAttribute
        private int id;

        /**
         * X position within the bitmap image file.
         */
        @XmlAttribute
        private int x;

        /**
         * Y position within the bitmap image file.
         */
        @XmlAttribute
        private int y;

        /**
         * Width of the character in the image file.
         */
        @XmlAttribute
        private int width;

        /**
         * Height of the character in the image file.
         */
        @XmlAttribute
        private int height;

        /**
         * Number of pixels to move right before drawing this character.
         */
        @XmlAttribute(name = "xoffset")
        private int xOffset;

        /**
         * Number of pixels to move down before drawing this character.
         */
        @XmlAttribute(name = "yoffset")
        private int yOffset;

        /**
         * Number of pixels to jump right after drawing this character.
         */
        @XmlAttribute(name = "xadvance")
        private int xAdvance;

        /**
         * Id page where this char is.
         */
        @XmlAttribute(name = "page")
        private int pageId;

        /**
         * Sets position x.
         * @param value - int
         */
        public void setX(int value) {
            x = value;
        }

        /**
         * Gets position x.
         * @return int
         */
        public int getX() {
            return x;
        }

        /**
         * Sets page id.
         * @param value - int
         */
        public void setPageId(int value) {
            pageId = value;
        }

        /**
         * Gets page id.
         * @return int
         */
        public int getPageId() {
            return pageId;
        }

        /**
         * Sets position y.
         * @param value - int
         */
        public void setY(int value) {
            y = value;
        }

        /**
         * Gets position y.
         * @return int
         */
        public int getY() {
            return y;
        }

        /**
         * Sets ASCII id.
         * @param value - int
         */
        public void setId(int value) {
            id = value;
        }

        /**
         * Gets ASCII id.
         * @return int
         */
        public int getId() {
            return id;
        }

        /**
         * Sets width.
         * @param value - int
         */
        public void setWidth(int value) {
            width = value;
        }

        /**
         * Gets width.
         * @return int
         */
        public int getWidth() {
            return width;
        }

        /**
         * Sets height.
         * @param value - int
         */
        public void setHeight(int value) {
            height = value;
        }

        /**
         * Gets height.
         * @return int
         */
        public int getHeight() {
            return height;
        }

        /**
         * Sets x offset.
         * @param value - int
         */
        public void setXOffset(int value) {
            xOffset = value;
        }

        /**
         * Gets x offset.
         * @return int
         */
        public int getXOffset() {
            return xOffset;
        }

        /**
         * Sets y offset.
         * @param value - int
         */
        public void setYOffset(int value) {
            yOffset = value;
        }

        /**
         * Gets y offset.
         * @return int
         */
        public int getYOffset() {
            return yOffset;
        }

        /**
         * Sets x advance.
         * @param value - int
         */
        public void setXAdvance(int value) {
            xAdvance = value;
        }

        /**
         * Gets x advance.
         * @return int
         */
        public int getXAdvance() {
            return xAdvance;
        }

    }

}
