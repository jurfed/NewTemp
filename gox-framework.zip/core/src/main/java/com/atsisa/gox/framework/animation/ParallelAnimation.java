package com.atsisa.gox.framework.animation;

import java.util.List;

import rx.functions.Action1;

/**
 * Implementation of IAnimation interface, which plays given list of animations all at once.
 */
public class ParallelAnimation extends AbstractAnimation {

    /**
     * List of given animations.
     */
    private final List<IAnimation> animations;

    /**
     * Number of animations, which are currently not stopped.
     */
    private int numberOfNotStoppedAnimations;

    /**
     * Constructor receiving list of animations.
     * @param animations given list of animations
     */
    public ParallelAnimation(List<IAnimation> animations) {
        this.animations = animations;
        observeAllAnimations();
    }

    /**
     * Sets an Observer for all animations on the animations list.
     */
    private void observeAllAnimations() {
        for (IAnimation animation : animations) {
            animation.getAnimationStateObservable().subscribe(new Action1<AnimationState>() {

                @Override
                public void call(AnimationState animationState) {
                    if (animationState == AnimationState.STOPPED) {
                        if (!isStopped()) {
                            decreaseNumberOfNotStoppedAnimations();
                        }
                    }
                }
            });
        }
    }

    /**
     * Decreases number of playing animations.
     */
    private void decreaseNumberOfNotStoppedAnimations() {
        numberOfNotStoppedAnimations--;

        if (numberOfNotStoppedAnimations == 0) {
            setAnimationState(AnimationState.STOPPED);
        }
    }

    @Override
    public synchronized void play() {
        if (isPlaying()) {
            return;
        }

        if (isPaused()) {
            for (IAnimation animation : animations) {
                if (animation.isPaused()) {
                    animation.play();
                }
            }

            return;
        }

        numberOfNotStoppedAnimations = animations.size();

        setAnimationState(AnimationState.PLAYING);

        for (IAnimation animation : animations) {
            animation.play();
        }
    }

    @Override
    public synchronized void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        setAnimationState(AnimationState.PAUSED);

        for (IAnimation animation : animations) {
            animation.pause();
        }
    }

    @Override
    public synchronized void stop() {
        if (isStopped()) {
            return;
        }

        setAnimationState(AnimationState.STOPPED);

        for (IAnimation animation : animations) {
            animation.stop();
        }

        numberOfNotStoppedAnimations = 0;
    }
}
