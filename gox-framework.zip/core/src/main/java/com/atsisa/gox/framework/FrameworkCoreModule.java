package com.atsisa.gox.framework;

import com.atsisa.gox.framework.action.ActionBinder;
import com.atsisa.gox.framework.action.ActionBuilder;
import com.atsisa.gox.framework.action.ActionManager;
import com.atsisa.gox.framework.action.IActionBinder;
import com.atsisa.gox.framework.action.IActionBuilder;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.animation.AnimationFactory;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenAnimationController;
import com.atsisa.gox.framework.eventbus.EventBus;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.ConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.ISkinManager;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.infrastructure.SkinManager;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.infrastructure.ViewBuilder;
import com.atsisa.gox.framework.infrastructure.ViewManager;
import com.atsisa.gox.framework.resource.FontResourceLoadingCallback;
import com.atsisa.gox.framework.resource.IResourceLoadingCallback;
import com.atsisa.gox.framework.screen.PreloaderScreen;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.Serialization;
import com.atsisa.gox.framework.serialization.XmlSerializer;
import com.atsisa.gox.framework.utility.FontRegistry;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.Utility;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.utility.localization.DefaultTranslationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.localization.Translator;
import com.atsisa.gox.framework.utility.timer.ITimerManager;
import com.atsisa.gox.framework.utility.timer.TimerManager;
import com.atsisa.gox.inject.AbstractModule;

import aurelienribon.tweenengine.TweenManager;

/**
 * Represents an IoC module which defines framework core dependencies.
 */
public class FrameworkCoreModule extends AbstractModule {

    @Override
    protected  void configure() {
        bind(GameEngineComponents.class).asEagerSingleton();

        bind(IUtility.class).to(Utility.class).asEagerSingleton();
        bind(ISerialization.class).to(Serialization.class).asEagerSingleton();
        bind(IXmlSerializer.class).to(XmlSerializer.class).asEagerSingleton();
        bind(IViewBuilder.class).to(ViewBuilder.class).asEagerSingleton();

        bind(ViewManager.class).asEagerSingleton();
        bind(IViewManager.class).to(ViewManager.class);
        bind(IDisposable.class).to(ViewManager.class);

        bind(ISkinManager.class).to(SkinManager.class).asEagerSingleton();
        bind(IActionBuilder.class).to(ActionBuilder.class).asEagerSingleton();
        bind(ISoundManager.class).to(SoundManager.class).asEagerSingleton();
        bind(IActionManager.class).to(ActionManager.class).asEagerSingleton();
        bind(IActionBinder.class).to(ActionBinder.class).asEagerSingleton();
        bind(IConfigurationProvider.class).to(ConfigurationProvider.class).asEagerSingleton();
        bind(IFontRegistry.class).to(FontRegistry.class).asEagerSingleton();
        bind(IEventBus.class).to(EventBus.class).asEagerSingleton();
        bind(IResourceLoadingCallback.class).to(FontResourceLoadingCallback.class).asEagerSingleton();

        bind(IGameEngine.class).to(GameEngine.class).asEagerSingleton();
        bind(IDisposable.class).to(IGameEngine.class);
        bind(IAnimationFactory.class).to(AnimationFactory.class).asEagerSingleton();
        bind(TweenAnimationController.class).asEagerSingleton();
        bind(TweenManager.class).asEagerSingleton();
        bind(ITimerManager.class).to(TimerManager.class).asEagerSingleton();

        bind(ScreenModel.class);
        bind(Screen.class).to(PreloaderScreen.class).asEagerSingleton();
        bind(ITranslationProvider.class).to(DefaultTranslationProvider.class).asEagerSingleton();
        bind(ITranslator.class).to(Translator.class).asEagerSingleton();

        bindConstant().named("PreloaderScreenLayoutId").to("preloader");
    }
}
