package com.atsisa.gox.framework.resource;

/**
 * Provider for {@link QueuesResource} type.
 */
public class QueuesResourceProvider implements IResourceProvider {

    @Override
    public boolean canCreate(ResourceType resourceType) {
        return resourceType == ResourceType.QUEUES;
    }

    @Override
    public IResource createResource(ResourceDescription resourceDescription) {
        return new QueuesResource(resourceDescription);
    }
}
