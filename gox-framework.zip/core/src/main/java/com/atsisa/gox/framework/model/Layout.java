package com.atsisa.gox.framework.model;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.view.View;

/**
 * Represents a layout that can be added to stage using ViewManager.
 */
public class Layout implements ILayout {

    /**
     * A value indicating whether the layout can be destroyed.
     */
    private final boolean disposable;

    /**
     * Model propertyBindings.
     */
    private final List<PropertyBinding> propertyBindings;

    /**
     * A list of layout listeners.
     */
    private final List<ILayoutListener> layoutListeners;

    /**
     * View manager instance.
     */
    private final IViewBuilder viewBuilder;

    /**
     * Layout identifier.
     */
    private final String id;

    /**
     * Layout xml resource (if available).
     */
    private XmlResource xmlResource;

    /**
     * Layout root view.
     */
    private View rootView;

    /**
     * Screen model.
     */
    private ScreenModel screenModel;

    /**
     * Initializes a new instance of the Layout class using specific id and text resource.
     * @param xmlResource layout text description resource
     * @param id          layout identifier
     */
    public Layout(XmlResource xmlResource, String id) {
        this.xmlResource = xmlResource;
        this.id = id;

        viewBuilder = GameEngine.current().getViewManager().getViewBuilder();
        disposable = true;
        propertyBindings = new ArrayList<>();
        layoutListeners = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the Layout class using specific id and root view.
     * @param rootView layout root view
     * @param id       layout identifier
     */
    public Layout(View rootView, String id) {
        this.rootView = rootView;
        this.id = id;

        viewBuilder = GameEngine.current().getViewManager().getViewBuilder();
        disposable = false;
        propertyBindings = new ArrayList<>();
        layoutListeners = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the Layout class using specific id and root view.
     * @param id          layout identifier
     * @param xmlResource the layout text resource to set
     * @param rootView    layout root view
     * @param viewBuilder view builder reference
     */
    public Layout(String id, XmlResource xmlResource, View rootView, IViewBuilder viewBuilder) {
        this.id = id;
        this.xmlResource = xmlResource;
        this.rootView = rootView;
        this.viewBuilder = viewBuilder;

        disposable = rootView == null;
        propertyBindings = new ArrayList<>();
        layoutListeners = new ArrayList<>();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public XmlResource getXmlResource() {
        return xmlResource;
    }

    @Override
    public View getRootView() {
        return rootView;
    }

    @Override
    public boolean isBuilt() {
        return rootView != null;
    }

    @Override
    public boolean isOnStage() {
        return isBuilt() && rootView.getParent() != null;
    }

    @Override
    public List<PropertyBinding> getPropertyBindings() {
        return propertyBindings;
    }

    @Override
    public ScreenModel getScreenModel() {
        return screenModel;
    }

    @Override
    public void setScreenModel(ScreenModel screenModel) {
        if (this.screenModel == screenModel) {
            return;
        }

        this.screenModel = screenModel;
        refresh();
    }

    @Override
    public void build() throws ParseException {
        if (xmlResource != null && !isBuilt()) {
            View view = viewBuilder.build(xmlResource, true);
            if (view == null) {
                throw new ParseException(StringUtility.format("ViewBuilder returned null root view for layout resource '%s'", xmlResource.getId()));
            }
            rootView = view;
            propertyBindings.addAll(viewBuilder.getPropertyBindings());
        }
    }

    @Override
    public void refresh() {
        if (screenModel != null && isOnStage()) {
            for (PropertyBinding propertyBinding : propertyBindings) {
                if (propertyBinding instanceof AbstractDeferredBinding) {
                    ((AbstractDeferredBinding) propertyBinding).setModel(screenModel);
                } else {
                    propertyBinding.update();
                }
            }
        }
    }

    @Override
    public void update(XmlResource xmlResource) {
        if (isBuilt()) {
            dispose();
        }
        this.xmlResource = xmlResource;
    }

    @Override
    public void addLayoutListener(ILayoutListener layoutListener) {
        layoutListeners.add(layoutListener);
    }

    @Override
    public void removeLayoutListener(ILayoutListener layoutListener) {
        layoutListeners.remove(layoutListener);
    }

    /**
     * Notifies listeners about the layout event.
     * @param layoutEventType layout event type
     */
    public void triggerEvent(LayoutEventType layoutEventType) {
        for (ILayoutListener layoutListener : layoutListeners) {
            layoutListener.onLayoutEvent(this, layoutEventType);
        }
    }

    @Override
    public void dispose() {
        for (PropertyBinding propertyBinding : propertyBindings) {
            propertyBinding.destroy();
        }
        propertyBindings.clear();
        layoutListeners.clear();
        rootView.dispose();
        rootView = null;
    }

    @Override
    public boolean isDisposable() {
        return disposable;
    }
}
