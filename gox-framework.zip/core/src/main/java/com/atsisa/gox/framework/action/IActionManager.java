package com.atsisa.gox.framework.action;

import java.util.List;

import com.atsisa.gox.framework.utility.IStateListener;

/**
 * Action Queue Manager Interface.
 */
public interface IActionManager {

    /**
     * Destroys action queue with the specified id.
     * @param id unique id of queue
     * @return false if queue does not exist in this action manager
     */
    boolean destroyActionQueue(long id);

    /**
     * Destroys currently active action queue.
     * @return true if there was an active queue, false otherwise
     */
    boolean destroyActiveQueue();

    /**
     * Destroys all currently paused action queues.
     * @return true if there was at lease one paused queue, false otherwise
     */
    boolean destroyPausedQueues();

    /**
     * Destroys all currently processed action queues.
     * @return true if there was at lease one queue, false otherwise
     */
    boolean destroyAllQueues();

    /**
     * Processes a single action.
     * @param action an action to execute
     * @return unique id of queue, which was created for this action, return "-1" if queue can not be created.
     */
    long processAction(Action action);

    /**
     * Terminates currently active action. Does nothing in case there is no active action.
     */
    void terminateActiveAction();

    /**
     * Processes a single action.
     * @param action   an action to execute
     * @param listener action queue state listener
     * @return unique id of queue, which was created for this action, return "-1" if queue can not be created
     */
    long processAction(Action action, IStateListener<ActionQueueState> listener);

    /**
     * Creates and runs a new action queue.
     * @param actionList list action to process
     * @return unique id of queue, return "-1" if queue can not be created
     */
    long processQueue(List<Action> actionList);

    /**
     * Creates and runs a new action queue.
     * @param actionList list action to process
     * @param listener   action queue state listener
     * @return unique id of queue, return "-1" if queue can not be created
     */
    long processQueue(List<Action> actionList, IStateListener<ActionQueueState> listener);

    /**
     * Creates and runs new action queue.
     * @param queueName unique queue name, which must be previously registered in ActionBuilder.
     * @return unique id of queue, return "-1" if queue can not be created.
     */
    long processQueue(String queueName);

    /**
     * Creates and runs new action queue.
     * @param queueName unique queue name, which must be previously registered in ActionBuilder.
     * @param asNext    a boolean value that indicates whether this queue should be process as the next or not.
     * @return unique id of queue, return "-1" if queue can not be created.
     */
    long processQueue(String queueName, boolean asNext);

    /**
     * Creates and runs new action queue.
     * @param queueName - unique queue name, which must be previously registered in ActionBuilder.
     * @param listener  action queue state listener
     * @return long - unique id of queue, return "-1" if queue can not be created.
     */
    long processQueue(String queueName, IStateListener<ActionQueueState> listener);

    /**
     * Creates and runs new action queue.
     * @param queueName unique queue name, which must be previously registered in ActionBuilder
     * @param listener  action queue state listener
     * @param asNext    a boolean value that indicates whether this queue should be process as the next or not
     * @return unique id of queue, return "-1" if queue can not be created
     */
    long processQueue(String queueName, IStateListener<ActionQueueState> listener, boolean asNext);

    /**
     * Gets action builder.
     * @return IActionBuilder
     */
    IActionBuilder getActionBuilder();

    /**
     * Gets action queue with the specified id.
     * @param id unique id action queue
     * @return IActionQueue, null if queue not exist
     */
    IActionQueue getActionQueueById(long id);

    /**
     * Checks whether a given queue name is registered.
     * @param queueName queue name
     * @return true if queue is registered, false otherwise
     */
    boolean isRegistered(String queueName);

    /**
     * Gets array action queues.
     * @return List of IActionQueue
     */
    List<IActionQueue> getActionQueues();

    /**
     * Gets current active queue.
     * @return IActionQueue
     */
    IActionQueue getActiveQueue();

    /**
     * Gets list paused queues.
     * @return list paused queues
     */
    List<IActionQueue> getPausedActionQueues();

    /**
     * Registers action resource based on its id.
     * @param resourceId resource id
     */
    void registerActionResource(String resourceId);

    /**
     * Registers the action queues from the resources.
     */
    void registerActionQueuesFromResources();

    /**
     * Registers action queue from action list.
     * @param name          queue name
     * @param queueMetadata queue metadata
     * @return true if queue has been properly registered
     */
    boolean registerQueue(String name, QueueMetadata queueMetadata);

    /**
     * Registers action queue from action list.
     * @param name          queue name
     * @param queueMetadata queue metadata
     * @param override      boolean value that indicates whether if queue with that name is already registered it will be overwritten or not
     * @return true if  queue has been properly registered
     */
    boolean registerQueue(String name, QueueMetadata queueMetadata, boolean override);

    /**
     * Gets an instance of the action binder.
     * @return an instance of the action binder
     */
    IActionBinder getActionBinder();

    /**
     * Gets an array of registered queue names.
     * @return an array of registered queue names
     */
    String[] getRegisteredQueueNames();

}
