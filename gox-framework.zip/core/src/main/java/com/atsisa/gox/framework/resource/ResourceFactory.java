package com.atsisa.gox.framework.resource;

import java.util.NoSuchElementException;
import java.util.Set;

import com.google.inject.Inject;

public class ResourceFactory implements IResourceFactory {

    private final Set<IResourceProvider> resourceProviders;

    @Inject
    public ResourceFactory(Set<IResourceProvider> resourceProviders) {
        this.resourceProviders = resourceProviders;
    }

    @Override
    public IResource createResource(ResourceDescription resourceDescription)  {
        for (IResourceProvider resourceProvider : resourceProviders) {
            if (resourceProvider.canCreate(resourceDescription.getResourceType())) {
                return resourceProvider.createResource(resourceDescription);
            }
        }

        throw new NoSuchElementException("The resource " + resourceDescription.getId() + " not found.");
    }
}
