package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.view.spi.IViewFilter;

/**
 * A view filter based on its tags.
 */
public final class TagViewFilter implements IViewFilter {

    /**
     * Tags.
     */
    private final String[] tags;

    /**
     * Initializes a new instance of the {@link TagViewFilter} class.
     * @param tags Tags accepted by this filter.
     */
    public TagViewFilter(String... tags) {
        if (tags == null || tags.length == 0) {
            throw new IllegalArgumentException("The tags cannot be null nor empty.");
        }
        this.tags = tags;
    }

    @Override
    public boolean isValid(View view) {
        for (String tag : tags) {
            if (view.hasTag(tag)) {
                return true;
            }
        }
        return false;
    }
}
