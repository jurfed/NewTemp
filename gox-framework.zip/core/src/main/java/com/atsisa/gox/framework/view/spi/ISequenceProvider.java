package com.atsisa.gox.framework.view.spi;

import rx.Observable;

/**
 * Provides sequence.
 * @param <T> type of iterable item.
 */
public interface ISequenceProvider<T> {

    /**
     * Creates and returns new sequence observable.
     * @param items iterable items
     * @return observable
     */
    Observable<T> createSequence(Iterable<? extends T> items);
}
