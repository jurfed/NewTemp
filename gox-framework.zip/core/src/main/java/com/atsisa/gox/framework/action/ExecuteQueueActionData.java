package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Contains information for ExecuteNext, ExecuteNow action regarding a queue which should be processed next.
 */
@XmlElement
@Reflect_Full
public class ExecuteQueueActionData extends ActionData {

    /**
     * Queue name.
     */
    @XmlAttribute
    private String queueName;

    /**
     * Gets the queue name.
     * @return the queue name
     */
    public String getQueueName() {
        return queueName;
    }

    /**
     * Sets the queue name.
     * @param queueName the queue name
     */
    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }
}
