package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data about movie.
 */
@XmlElement
@Reflect_Full
public class MovieActionData extends ActionData {

    /**
     * Movie id.
     */
    @XmlAttribute(type = String.class)
    private String movieId;

    /**
     * Layout id where is movie.
     */
    @XmlAttribute(type = String.class)
    private String layoutId;

    /**
     * Gets movie id.
     * @return String
     */
    public String getMovieId() {
        return movieId;
    }

    /**
     * Sets movie id.
     * @param movieId String
     */
    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    /**
     * Gets layout id.
     * @return String
     */
    public String getLayoutId() {
        return layoutId;
    }

    /**
     * Sets layout id.
     * @param layoutId String
     */
    public void setLayoutId(String layoutId) {
        this.layoutId = layoutId;
    }
}
