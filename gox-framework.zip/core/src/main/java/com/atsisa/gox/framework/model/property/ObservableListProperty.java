package com.atsisa.gox.framework.model.property;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Observable list property class.
 * @param <I> type of list items
 */
@XmlElement
public class ObservableListProperty<I> extends ObservableProperty<List> {

    /**
     * Initializes a new instance of the ObservableListProperty class.
     */
    public ObservableListProperty() {
        super(List.class, new ArrayList<I>());
    }

    /**
     * Initializes a new instance of the ObservableListProperty class.
     * @param defaultValue list default value
     */
    public ObservableListProperty(List<I> defaultValue) {
        super(List.class, defaultValue);
    }

    /**
     * Adds a new value to the list.
     * @param value - I
     * @return boolean
     */
    @SuppressWarnings("unchecked")
    public boolean addValue(I value) {
        List oldList = get();
        if (oldList != null) {
            List newList = oldList.subList(0, oldList.size());
            newList.add(value);
            return set(newList);
        }
        return false;
    }

    /**
     * Removes a specific value from list.
     * @param value - I
     * @return boolean
     */
    public boolean removeValue(I value) {
        List oldList = get();
        if (oldList != null) {
            List newList = oldList.subList(0, oldList.size());
            if (newList.contains(value)) {
                newList.remove(value);
                return set(newList);
            } else {
                return false;
            }
        }
        return false;
    }

}
