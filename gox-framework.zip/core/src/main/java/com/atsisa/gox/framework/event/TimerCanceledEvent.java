package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.utility.timer.ITimer;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Occurs when a {@link ITimer}
 * component time measurement has been canceled.
 */
@Reflect_Mini
public final class TimerCanceledEvent {

    /**
     * The timer.
     */
    private final ITimer timer;

    /**
     * Initializes a new instance of the {@link TimerCanceledEvent}
     * class.
     * @param timer Corresponding timer.
     */
    public TimerCanceledEvent(ITimer timer) {
        this.timer = timer;
    }

    /**
     * Gets the timer this event was triggered by.
     * @return The timer corresponding to this event.
     */
    public ITimer getTimer() {
        return timer;
    }
}
