package com.atsisa.gox.framework.utility;

/**
 * Finish callback.
 */
public interface IFinishCallback {

    /**
     * Called when finish of any kind occurs.
     */
    void onFinish();
}
