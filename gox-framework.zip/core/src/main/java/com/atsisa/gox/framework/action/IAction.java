package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.utility.IStateListener;

/**
 * Action Interface.
 * @param <T> type extends ActionData
 */
public interface IAction<T extends ActionData> {

    /**
     * Gets action data type for this action.
     * @return action data type for this action
     */
    Class<? extends ActionData> getActionDataType();

    /**
     * Gets the name of the action.
     * @return the name of the action
     */
    String getName();

    /**
     * Sets the name of the action.
     * @param value the name of the action
     */
    void setName(String value);

    /**
     * Gets the index of the action in queue.
     * @return the index of the action in queue
     */
    int getQueueIndex();

    /**
     * Gets an error if the action is in failed state.
     * @return an error throwable
     */
    Throwable getError();

    /**
     * Gets action parent bundle action, where it is using.
     * @return BundleAction
     */
    BundleAction getParentBundleAction();

    /**
     * Gets action parent queue, where it is using.
     * @return ActionQueue
     */
    ActionQueue getParentQueue();

    /**
     * Gets a state of the action.
     * @return a state of the action
     */
    ActionState getState();

    /**
     * Adds a listener which will be called on state changes.
     * @param listener - called on state changes
     */
    void addStateListener(IStateListener<ActionState> listener);

    /**
     * Removes a listener which will be called on state changes.
     * @param listener - called on state changes
     */
    void removeStateListener(IStateListener<ActionState> listener);

    /**
     * Checks if the action has any registered state listener.
     * @return true if the action has any registered state listener, false otherwise
     */
    boolean hasStateListeners();

    /**
     * Sets Action Data.
     * @param data class extends ActionData
     */
    void setActionData(T data);

    /**
     * Returns a value indicating that the action is either in SUCCEEDED, FAILED or TERMINATED state.
     * @return a value indicating action state
     */
    boolean isFinished();
}
