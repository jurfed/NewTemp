package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.resource.QueuesResource;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.serialization.interceptor.PropertyBindingInterceptor;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.google.inject.Inject;

/**
 * An implementation of XML based action builder. Registers action modules and builds particular actions using XML description.
 */
public class ActionBuilder implements IActionBuilder {

    /**
     * Name const.
     */
    private static final String NAME = "name";

    /**
     * Actions const.
     */
    private static final String ACTIONS = "actions";

    /**
     * Special name to recognize place where another queue should be copy/paste.
     */
    private static final String INSERT_QUEUE = "InsertQueue";

    /**
     * Reflection helper reference.
     */
    private final IReflection reflection;

    /**
     * Logger reference.
     */
    private final ILogger logger;

    /**
     * Action parser reference.
     */
    private IParser actionParser;

    /**
     * Action serializer reference.
     */
    private IXmlSerializer actionSerializer;

    /**
     * Queues descriptions, to create.
     */
    private final LinkedList<XmlObject> queuesDescriptions;

    /**
     * Module map, maps XML namespace to module objects.
     */
    private final Map<String, AbstractActionModule> moduleMap;

    /**
     * Initializes a new instance of the ActionBuilder class using particular serialization and reflection helpers.
     * @param reflection            {@link IReflection}
     * @param logger                {@link ILogger}
     * @param serializer            {@link IXmlSerializer}
     * @param parser                {@link IParser}
     */
    @Inject
    public ActionBuilder(IReflection reflection, ILogger logger, IXmlSerializer serializer, IParser parser) {
        this.reflection = reflection;
        this.logger = logger;
        queuesDescriptions = new LinkedList<>();
        moduleMap = new HashMap<>();
        this.actionParser = parser;
        this.actionSerializer = serializer;
    }

    @Override
    public void registerModule(AbstractActionModule actionModule) {
        if (actionModule != null) {
            moduleMap.put(actionModule.getXmlNamespace(), actionModule);
        }
    }

    @Override
    public boolean unregisterModule(AbstractActionModule actionModule) {
        if (actionModule != null) {
            return unregisterModule(actionModule.getXmlNamespace());
        }
        return false;
    }

    @Override
    public boolean unregisterModule(String namespace) {
        if (namespace != null) {
            AbstractActionModule removedModule = moduleMap.remove(namespace);
            if (removedModule != null) {
                return true;
            }
        }
        return false;
    }

    @Override
    public List<AbstractActionModule> getModules() {
        return new ArrayList<>(moduleMap.values());
    }

    @Override
    public void addQueues(QueuesResource resource) throws ParseException {
        String serializedQueues = resource.getText();
        addQueues(serializedQueues);
    }

    @Override
    public void addQueues(String serializedQueues) throws ParseException {
        XmlObjectDocument xmlDocument = (XmlObjectDocument) actionParser.parse(serializedQueues);
        XmlObject xmlElement = xmlDocument.getDocumentElement();
        queuesDescriptions.addFirst(xmlElement);
    }

    @Override
    public boolean containsQueue(String queueName) {
        return getQueueDescription(queueName) != null;
    }

    @Override
    public QueueMetadata getQueue(String queueName) {
        XmlObject queueDescription = getQueueDescription(queueName);
        QueueMetadata queueMetadata = null;
        if (queueDescription != null) {
            queueMetadata = createQueue(queueDescription);
        }
        return queueMetadata;
    }

    @Override
    public Action getAction(String actionName, String namespace) {
        Action action = null;
        try {
            Class<? extends Action> actionClass = getClassFromModule(actionName, namespace);
            try {
                action = reflection.createInstance(actionClass);
                action.setName(actionName);
            } catch (ReflectionException e) {
                logger.error(e.getMessage());
            }
        } catch (ParseException e) {
            logger.error(e.getMessage());
        }
        return action;
    }

    /**
     * Creates queue base on xml object.
     * @param queueDescription queue description
     * @return QueueMetadata
     */
    private QueueMetadata createQueue(XmlObject queueDescription) {
        QueueMetadata queueMetadata = new QueueMetadata(queueDescription.getAttribute(NAME), Boolean.valueOf(queueDescription.getAttribute("force")));
        queueMetadata.setActions(createQueueActions(queueDescription));
        return queueMetadata;
    }

    /**
     * Creates action list base on XmlObject list.
     * @param actionXmlObjects list of xml objects
     * @return list of actions
     */
    private List<Action> createActions(List<XmlObject> actionXmlObjects) {
        List<Action> actions = new ArrayList<>();
        Action action;
        String actionName;
        String actionNamespace;
        Class<? extends ActionData> actionDataType;
        ActionData actionData;
        XmlObject queueDescription;

        for (XmlObject actionXmlObject : actionXmlObjects) {
            actionName = actionXmlObject.getName();
            if (INSERT_QUEUE.equals(actionName)) {
                queueDescription = getQueueDescription(actionXmlObject.getAttribute(NAME));
                actions.addAll(createQueueActions(queueDescription));
                continue;
            }
            actionNamespace = actionXmlObject.getNamespace();
            action = getAction(actionName, actionNamespace);
            if (action != null) {
                actionDataType = action.getActionDataType();
                actionData = createActionData(actionXmlObject.toXmlString(), actionDataType);
                if (actionData instanceof IBundleActionData) {
                    populateBundleActionData((IBundleActionData) actionData, actionXmlObject);
                }
                action.setActionData(actionData);
                actions.add(action);
            }
        }
        return actions;
    }

    /**
     * Populates specific action bundle.
     * @param bundleActionData action bundle to populate
     * @param actionXmlObject  action bundle description
     */
    private void populateBundleActionData(IBundleActionData bundleActionData, XmlObject actionXmlObject) {
        List<XmlObject> innerActionXmlObjects = actionXmlObject.getChildren();
        List<Action> innerActions = createActions(innerActionXmlObjects);
        bundleActionData.setActions(innerActions);
    }

    /**
     * Creates actions for specific queue description.
     * @param queueDescription queue xml description
     */
    private List<Action> createQueueActions(XmlObject queueDescription) {
        List<XmlObject> queueChildren = queueDescription.getChildren();
        for (XmlObject child : queueChildren) {
            if (child.getName().equals(ACTIONS)) {
                return createActions(child.getChildren());
            }
        }
        return new ArrayList<>();
    }

    /**
     * Creates dynamically object extends ActionData, base on string.
     * @param actionDataToDeserialize action data to deserialize
     * @param actionDataType          action data type
     * @return object extends ActionData
     */
    private ActionData createActionData(String actionDataToDeserialize, Class<? extends ActionData> actionDataType) {
        ActionData actionData = null;
        if (actionDataType != null) {
            try {
                actionData = (ActionData) actionSerializer.deserialize(actionDataToDeserialize, actionDataType);
            } catch (SerializationException e) {
                logger.error(e.getMessage());
            }
        }
        return actionData;
    }

    /**
     * Gets xml object which describes specific queue.
     * @param name string
     * @return XmlObject
     */
    private XmlObject getQueueDescription(String name) {
        List<XmlObject> queues;
        for (XmlObject queuesDescription : queuesDescriptions) {
            queues = queuesDescription.getChildren();
            for (XmlObject queueDescription : queues) {
                if (queueDescription.getAttributes().get(NAME).equals(name)) {
                    return queueDescription;
                }
            }
        }
        return null;
    }

    /**
     * Gets a class object from action module.
     * @param tagName      class name to check
     * @param xmlNamespace xml namespace to check
     * @return a class object from action module
     * @throws ParseException if parsing went wrong
     */
    private Class<? extends Action> getClassFromModule(String tagName, String xmlNamespace) throws ParseException {
        AbstractActionModule module = moduleMap.get(xmlNamespace);
        if (module != null) {
            return module.getActionType(tagName);
        }
        throw new ParseException(StringUtility.format("No module has been registered for '%s' namespace", xmlNamespace));
    }

}
