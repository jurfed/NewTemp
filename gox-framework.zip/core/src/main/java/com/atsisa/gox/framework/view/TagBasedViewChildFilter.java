package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.view.spi.IStatefulViewChildFilter;

/**
 * Tag based view child filter, which is based on value from
 * {@link View#hasTag(String)} method, checks whether the view state value is the
 * same as one of View's tags.
 */
public class TagBasedViewChildFilter implements IStatefulViewChildFilter<String> {

    /**
     * Checks if given View has a tag which corresponds to the view state.
     * @param view      - View
     * @param viewState - String
     * @return boolean
     */
    @Override
    public boolean isValid(View view, String viewState) {
        return view.hasTag(viewState);
    }

}
