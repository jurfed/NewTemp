package com.atsisa.gox.framework.resource;

/**
 * Provider for {@link LayoutResource} type.
 */
public class LayoutResourceProvider implements IResourceProvider {

    @Override
    public boolean canCreate(ResourceType resourceType) {
        return resourceType == ResourceType.LAYOUT;
    }

    @Override
    public IResource createResource(ResourceDescription resourceDescription) {
        return new LayoutResource(resourceDescription);
    }
}
