package com.atsisa.gox.framework.utility;

import java.util.HashSet;
import java.util.Set;

/**
 * A tag container compliant with the {@link ITaggable} interface.
 */
public class TagContainer implements ITaggable {

    /**
     * Space delimiter.
     */
    private static String SPACE = " ";

    /**
     * A set of tags.
     */
    private Set<String> tags;

    /**
     * Initializes a new instance of the {@link TagContainer} class..
     */
    public TagContainer() {
        tags = new HashSet<>();
    }

    @Override
    public void setTags(Iterable<String> tags) {
        this.tags.clear();
        if (tags == null || Iterables.size(tags) == 0) {
            return;
        }

        for (String tag : tags) {
            validateTag(tag);
            this.tags.add(tag);
        }
    }

    @Override
    public Iterable<String> getTags() {
        return tags;
    }

    @Override
    public boolean hasTag(String tag) {
        validateTag(tag);
        return tags.contains(tag);
    }

    @Override
    public boolean hasTags() {
        return !tags.isEmpty();
    }

    @Override
    public boolean addTag(String tag) {
        validateTag(tag);
        return tags.add(tag);
    }

    @Override
    public boolean removeTag(String tag) {
        validateTag(tag);
        return tags.remove(tag);
    }

    /**
     * Validates the tag.
     * @param tag The tag to validate.
     */
    private void validateTag(String tag) {
        if (StringUtility.isNullOrEmpty(tag)) {
            throw new IllegalArgumentException("The tag cannot be null nor empty.");
        }
        if (tag.contains(SPACE)) {
            throw new IllegalArgumentException("Tag cannot contains spaces. Tag: " + tag);
        }
    }
}
