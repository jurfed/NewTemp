package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.view.View;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;

/**
 * Abstraction view rendering class, implements the basic behavior of the view rendering.
 */
public abstract class AbstractViewRenderer implements IViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the {@link AbstractViewRenderer} class..
     */
    public AbstractViewRenderer() {
        lv = new LocalVariables();
    }

    /**
     * Map views and the layers assigned to them.
     */
    protected Int2ObjectArrayMap<ILayer> viewLayerMap = new Int2ObjectArrayMap<>();

    @Override
    public ILayer getContent(View view) {
        return getViewLayer(view);
    }

    @Override
    public boolean dispose(View view) {
        lv.disposeLayer = viewLayerMap.remove(view.getUuid());
        if (lv.disposeLayer != null) {
            lv.disposeLayer.dispose();
            return true;
        }
        return false;
    }

    @Override
    public void dispose(){
        for (ILayer layer : viewLayerMap.values()){
            layer.dispose();
        }
        viewLayerMap.clear();
    }

    /**
     * Gets new rendering layers.
     * @param view view context
     * @param <T>  type of layer
     * @return Object - layers
     */
    protected abstract <T extends ILayer> T createLayer(View view);

    /**
     * Gets layers for specific view.
     * @param view - View
     * @return Object - ILayer
     */
    protected ILayer getViewLayer(View view) {
        if (view.getLayer() != null) {
            return view.getLayer();
        } else {
            return registerView(view);
        }
    }

    @Override
    public ILayer registerView(View view) {
        lv.fetchViewLayer = viewLayerMap.get(view.getUuid());
        if (lv.fetchViewLayer == null) {
            lv.fetchViewLayer = createLayer(view);
            viewLayerMap.put(view.getUuid(), lv.fetchViewLayer);
        }
        return lv.fetchViewLayer;
    }

    /**
     * Holder for instances of local variables used in the {@link AbstractViewRenderer} render method.
     */
    private class LocalVariables {

        private ILayer disposeLayer;

        private ILayer fetchViewLayer;
    }
}
