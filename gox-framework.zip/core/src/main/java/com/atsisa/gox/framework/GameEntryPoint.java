package com.atsisa.gox.framework;

import com.atsisa.gox.framework.event.LifecycleEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.rendering.IRenderer;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents core implementation of game entry point.
 */
public abstract class GameEntryPoint implements IGameEntryPoint {

    /**
     * Set of listeners.
     */
    private final Set<ILifecycleListener> listeners = new HashSet<>();

    @Override
    public void start(){
        registerObservers(getRegistry().getServiceResolver(IEventBus.class).resolveDefault());
    }

    @Override
    public void pause(){
        IRenderer renderer = getRegistry().getServiceResolver(IRenderer.class).resolveDefault();
        ISoundManager soundManager = getRegistry().getServiceResolver(ISoundManager.class).resolveDefault();
        renderer.pause();
        soundManager.pauseAllSounds();
        getRegistry().getServiceResolver(IEventBus.class).resolveDefault().post(new LifecycleEvent(LifecycleEventType.PAUSED));
    }

    @Override
    public void resume(){
        IRenderer renderer = getRegistry().getServiceResolver(IRenderer.class).resolveDefault();
        ISoundManager soundManager = getRegistry().getServiceResolver(ISoundManager.class).resolveDefault();
        renderer.resume();
        soundManager.resumeAllSounds();
        getRegistry().getServiceResolver(IEventBus.class).resolveDefault().post(new LifecycleEvent(LifecycleEventType.RESUMED));
    }

    @Override
    public boolean addLifecycleListener(ILifecycleListener listener) {
        return listeners.add(listener);
    }

    @Override
    public boolean removeLifecycleListener(ILifecycleListener listener) {
        return listeners.remove(listener);
    }

    /**
     * Registers observers on event bus.
     *
     * @param eventBus the event bus
     */
    private void registerObservers(IEventBus eventBus) {
        eventBus.register(new LifecycleEventObserver(), LifecycleEvent.class);
    }

    /**
     * Represents an observer for lifecycle events.
     */
    private class LifecycleEventObserver extends NextObserver<LifecycleEvent> {

        @Override
        public void onNext(LifecycleEvent lifecycleEvent) {
            for (ILifecycleListener listener : listeners) {
                listener.onChange(lifecycleEvent.getEventType());
            }
        }
    }

}