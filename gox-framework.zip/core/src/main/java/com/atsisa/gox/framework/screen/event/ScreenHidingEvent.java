package com.atsisa.gox.framework.screen.event;

import com.atsisa.gox.framework.screen.Screen;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when the screen started hiding.
 */
@Reflectable
public class ScreenHidingEvent extends ScreenEvent {

    /**
     * Initializes a new instance of the {@link ScreenHidingEvent} class.
     * @param screen {@link Screen}
     */
    public ScreenHidingEvent(Screen screen) {
        super(screen);
    }
}
