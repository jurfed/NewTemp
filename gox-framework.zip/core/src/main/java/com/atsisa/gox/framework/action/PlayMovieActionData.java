package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data about playing movie.
 */
@XmlElement
@Reflect_Full
public class PlayMovieActionData extends MovieActionData {

    /**
     * A boolean value that indicates whether action should wait for finish listener from movie or not.
     */
    @XmlAttribute(type = Boolean.class)
    private boolean waitForComplete;

    /**
     * Returns a boolean value that indicates whether action should wait for finish listener from movie or not.
     * @return boolean value
     */
    public boolean getWaitForComplete() {
        return waitForComplete;
    }

    /**
     * Sets a boolean value that indicates whether action should wait for finish listener from movie or not.
     * @param waitForComplete boolean value
     */
    public void setWaitForComplete(boolean waitForComplete) {
        this.waitForComplete = waitForComplete;
    }
}
