package com.atsisa.gox.framework.utility.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * An extension class for ArrayList providing access to list attributes which is helpful for xml serialization.
 * @param <T> type of the list item
 */
public class ArrayListWithAttributes<T> extends ArrayList<T> {

    /**
     * Serial version UID.
     */
    private static final long serialVersionUID = 928322366633062106L;

    /**
     * A map of attributes.
     */
    private Map<String, String> attributes;

    /**
     * List's serialization name.
     */
    private String serializationName;

    /**
     * Initializes a new instance of the ArrayListWithAttributes class.
     */
    public ArrayListWithAttributes() {
        attributes = new HashMap<>();
    }

    /**
     * Initializes a new instance of the ArrayListWithAttributes class
     * by adding all the elements in the collection given as parameter.
     * @param otherList a collection of elements to initialize with
     */
    public ArrayListWithAttributes(Collection<T> otherList) {
        this();
        addAll(otherList);
    }

    /**
     * Initializes a new instance of the ArrayListWithAttributes class
     * by adding all the elements in the array given as parameter.
     * @param otherArray an array of elements to initialize with
     */
    public ArrayListWithAttributes(T[] otherArray) {
        this();
        if (otherArray != null) {
            Collections.addAll(this, otherArray);
        }
    }

    /**
     * Gets the serialization name of the list.
     * It is helpful when the XmlCollectionElement has not been defined
     * @return the serialization name
     */
    public String getSerializationName() {
        return serializationName;
    }

    /**
     * Sets the serialization name of the list.
     * It is helpful when the XmlCollectionElement has not been defined
     * @param serializationName the serialization name
     */
    public void setSerializationName(String serializationName) {
        this.serializationName = serializationName;
    }

    /**
     * Checks if the list has an attribute defined.
     * @param attribute attribute name to check
     * @return true if attribute was defined, false otherwise
     */
    public boolean hasAttribute(String attribute) {
        return attributes.containsKey(attribute);
    }

    /**
     * Gets an attribute of the list. If it has not been defined null is returned.
     * @param attribute attribute name to get
     * @return the value of an attribute
     */
    public String getAttribute(String attribute) {
        return attributes.get(attribute);
    }

    /**
     * Adds an attribute to the list.
     * @param attribute attribute name to add
     * @param value     attribute value to add
     */
    public void addAttribute(String attribute, String value) {
        attributes.put(attribute, value);
    }

    /**
     * Gets a map of currently defined attibutes.
     * @return a map of attributes
     */
    public Map<String, String> getAttributes() {
        return attributes;
    }
}
