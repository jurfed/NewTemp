package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * An abstract class which is a helper action for any other actions which are waits for specific event to finish.
 * @param <T> type of event class
 */
public abstract class WaitForEventAction<T> extends Action {

    /**
     * Subscription for wait event.
     */
    private Subscription waitEventSubscription;

    /**
     * Initializes a new instance of the {@link WaitForEventAction} class.
     */
    public WaitForEventAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link WaitForEventAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public WaitForEventAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void reset() {
        super.reset();
        clearWaitEventSubscription();
    }

    /**
     * Clears subscription which is waiting for the event.
     */
    protected void clearWaitEventSubscription() {
        if (waitEventSubscription != null) {
            waitEventSubscription.unsubscribe();
            waitEventSubscription = null;
        }
    }

    @Override
    protected void terminate() {
        super.terminate();
        clearWaitEventSubscription();
    }

    @Override
    protected void execute() {
        registerEvents();
    }

    /**
     * Handles the event on which action awaits.
     * @param event the event on which action awaits
     */
    protected void handleEvent(T event) {
        finish();
    }

    @Override
    protected void finish() {
        clearWaitEventSubscription();
        super.finish();
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        waitEventSubscription = eventBus.register(new WaitEventObserver(), getEventClass());
    }

    /**
     * Wait for event observer.
     */
    private class WaitEventObserver extends NextObserver<T> {

        @Override
        public void onNext(T event) {
            handleEvent(event);
        }
    }

    /**
     * Gets the class wait event.
     * @return the class wait event
     */
    protected abstract Class<T> getEventClass();
}
