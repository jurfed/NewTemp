package com.atsisa.gox.framework.action;

/**
 * Interface for handle callback when all action in action queue will end.
 */
public interface ActionQueueFinishCallback {

    /**
     * Called when all actions in action queue will end.
     * @param queue IActionQueue
     */
    void onFinish(IActionQueue queue);

}
