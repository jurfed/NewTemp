package com.atsisa.gox.framework.command;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.gwtent.reflection.client.Reflectable;

/**
 * A command used to hide screen.
 */
@Reflectable
public class HideScreenCommand extends ScreenCommand {

    /**
     * The animation that should be used to hide the screen.
     */
    private TweenViewAnimationData hideViewAnimationData;

    /**
     * Initializes a new instance of the {@link HideScreenCommand} class.
     * @param screenId              the id of the screen
     * @param hideViewAnimationData {@link TweenViewAnimationData}
     * @param triggeredByUser       a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public HideScreenCommand(String screenId, TweenViewAnimationData hideViewAnimationData, boolean triggeredByUser) {
        super(screenId, triggeredByUser);
        this.hideViewAnimationData = hideViewAnimationData;
    }

    /**
     * Initializes a new instance of the {@link HideScreenCommand} class.
     * @param screenId              the id of the screen
     * @param hideViewAnimationData {@link TweenViewAnimationData}
     */
    public HideScreenCommand(String screenId, TweenViewAnimationData hideViewAnimationData) {
        super(screenId);
        this.hideViewAnimationData = hideViewAnimationData;
    }

    /**
     * Returns an animation that should be used to hide the screen.
     * @return an animation that should be used to hide the screen
     */
    public TweenViewAnimationData getHideViewAnimationData() {
        return hideViewAnimationData;
    }
}
