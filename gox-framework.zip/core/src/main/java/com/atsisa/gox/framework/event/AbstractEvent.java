package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.eventbus.ISourceEventAware;

/**
 * A basic support of event sourcing.
 */
public abstract class AbstractEvent implements ISourceEventAware {

    /**
     * A source event.
     */
    private Object sourceEvent;

    @Override
    public Object getSourceEvent() {
        return sourceEvent;
    }

    /**
     * Sets a source event which is a direct cause
     * this event was published.
     * @param sourceEvent a source event.
     */
    public void setSourceEvent(Object sourceEvent) {
        this.sourceEvent = sourceEvent;
    }
}
