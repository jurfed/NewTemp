package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.IProgressBarLayer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.ProgressBarView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Progress bar view rendering.
 */
public class ProgressBarViewRenderer extends InteractiveViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the ProgressBarViewRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public ProgressBarViewRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    @Override
    public Class<?> getType() {
        return ProgressBarView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = super.render(view, viewType, changes);
        lv.progressBarView = (ProgressBarView) view;
        lv.layer = (IProgressBarLayer) getContent(view);
        if (viewType == ViewType.IMAGE_VIEW) {
            if (BitUtility.isSet(lv.leftChanges, ImageView.ViewPropertyName.IMAGE)) {
                lv.image = lv.progressBarView.getImage();
                if (lv.image != null) {
                    lv.layer.setProgressBarImage(lv.image.getImageWrapperObject());
                }
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ImageView.ViewPropertyName.IMAGE);
            }
        } else if (viewType == ViewType.PROGRESS_BAR_VIEW) {
            lv.mask = ProgressBarView.ViewPropertyName.MAX_VALUE | ProgressBarView.ViewPropertyName.MIN_VALUE | ProgressBarView.ViewPropertyName.VALUE;
            if (BitUtility.isSet(lv.leftChanges, lv.mask)) {
                lv.progress = lv.progressBarView.getValue() / lv.progressBarView.getMaxValue();
                lv.layer.updateProgress(lv.progress);
                lv.leftChanges = BitUtility.unset(lv.leftChanges, lv.mask);
            }
            if (BitUtility.isSet(lv.leftChanges, ProgressBarView.ViewPropertyName.COLOR)) {
                lv.layer.setColor(lv.progressBarView.getColor());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ProgressBarView.ViewPropertyName.COLOR);
            }
        }
        return lv.leftChanges;
    }

    /**
     * Creates and returns new progress bar layers.
     * @param view - View
     * @return IProgressBarLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected IProgressBarLayer createLayer(View view) {
        return getLayerFactory().createProgressBarLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link ProgressBarViewRenderer} render method.
     */
    private class LocalVariables {

        private int mask;

        private float progress;

        private ProgressBarView progressBarView;

        private IProgressBarLayer layer;

        private IImageReference image;

        private int leftChanges;
    }
}
