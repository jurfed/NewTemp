package com.atsisa.gox.framework.eventbus;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IPlatform;

import rx.Observer;

/**
 * Decorator for observers to run notifications on them in main rendering thread.
 * @param <T> type of observer
 */
public class UIDispatcherObserver<T> implements Observer<T> {

    /**
     * {@link Observer} instance.
     */
    private final Observer<T> observer;

    /**
     * {@link IPlatform} reference.
     */
    private final IPlatform platform;

    /**
     * Initializes a new instance of the {@link UIDispatcherObserver} class.
     * @param observer {@link Observer}
     */
    public UIDispatcherObserver(Observer<T> observer) {
        this.observer = observer;
        platform = GameEngine.current().getPlatform();
    }

    @Override
    public void onCompleted() {
        platform.invokeLaterRendering(observer::onCompleted);
    }

    @Override
    public void onError(final Throwable e) {
        platform.invokeLaterRendering(() -> observer.onError(e));
    }

    @Override
    public void onNext(final T item) {
        platform.invokeLaterRendering(() -> observer.onNext(item));
    }
}
