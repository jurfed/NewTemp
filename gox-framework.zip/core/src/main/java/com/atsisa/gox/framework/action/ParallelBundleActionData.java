package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Action data for {@link ParallelBundleAction} class.
 */
@XmlElement
public class ParallelBundleActionData extends BundleActionData {

    /**
     * The finish condition.
     */
    @XmlAttribute
    private FinishCondition finishCondition = FinishCondition.ALL;

    /**
     * Gets the finish condition.
     * @return the finish condition.
     */
    public FinishCondition getFinishCondition() {
        return finishCondition;
    }

    /**
     * Sets the finish condition.
     * @param finishCondition The finish condition.
     */
    public void setFinishCondition(FinishCondition finishCondition) {
        this.finishCondition = finishCondition;
    }

    /**
     * The finish condition.
     */
    public enum FinishCondition {
        /**
         * The action ends when at least one inner action is finished.
         */
        ANY,
        /**
         * The action ends when all inner action are finished.
         */
        ALL
    }
}
