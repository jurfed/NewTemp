package com.atsisa.gox.framework.utility.localization;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.atsisa.gox.framework.command.ChangeLanguageCommand;
import com.atsisa.gox.framework.event.ErrorEvent;
import com.atsisa.gox.framework.event.LanguageChangedEvent;
import com.atsisa.gox.framework.event.RegisterTranslationCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.exception.ResourceException;
import com.atsisa.gox.framework.exception.UnableToConnectException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.StringUtility;
import com.google.inject.Inject;
import rx.Observable;

/**
 * Represents an implementation of {@link ITranslator} class.
 */
public class Translator implements ITranslator {

    /**
     * No translations.
     */
    private static final Map<String, String> NO_TRANSLATIONS = new HashMap<>();

    static {
        NO_TRANSLATIONS.put(GeneralSystemException.LANG_ERROR_GENERAL_SYSTEM_FAILURE, "Internal error.");
        NO_TRANSLATIONS.put(ResourceException.LANG_ERROR_CANNOT_PROCESS_GAME, "Internal error.");
        NO_TRANSLATIONS.put(UnableToConnectException.LANG_UNABLE_TO_CONNECT, "Unable to connect.");
    }

    /**
     * Active translations.
     */
    private Map<String, String> activeTranslations;

    /**
     * Event bus reference.
     */
    private final IEventBus eventBus;

    /**
     * Languages provider reference.
     */
    private final ITranslationProvider translationProvider;

    /**
     * Reference to the view manager.
     */
    private final IViewManager viewManager;

    /**
     * Initializes a new instance of the {@link Translator} class.
     * @param viewManager         {@link IViewManager}
     * @param eventBus            {@link IEventBus}
     * @param translationProvider {@link ITranslationProvider}
     */
    @Inject
    public Translator(IEventBus eventBus, ITranslationProvider translationProvider, IViewManager viewManager) {
        activeTranslations = NO_TRANSLATIONS;
        this.translationProvider = translationProvider;
        this.viewManager = viewManager;
        this.eventBus = eventBus;
        this.eventBus.register(new ChangeLanguageCommandObserver(), ChangeLanguageCommand.class);
        this.eventBus.register(new RegisterTranslationCommandObserver(), RegisterTranslationCommand.class);
    }

    @Override
    public String translateTemplate(String template) {
        int index = 0;
        int tokenState = 0;
        StringBuilder messageBuilder = new StringBuilder();
        StringBuilder tokenBuilder = new StringBuilder();

        while (index < template.length()) {
            char currentChar = template.charAt(index);
            if (currentChar == '{' && tokenState == 0 && '#' == template.charAt(index + 1)) {
                tokenState = 1;
            } else if (currentChar == '#' && tokenState == 1) {
                tokenState = 2;
            } else if (currentChar == '}' && tokenState == 2) {
                String token = tokenBuilder.toString();
                String localizedToken = translatePhrase(token).orElse(StringUtility.format("{#%s}", token));
                messageBuilder.append(localizedToken);
                tokenBuilder = new StringBuilder();
                tokenState = 0;
            } else {
                if (tokenState == 2) {
                    tokenBuilder.append(currentChar);
                } else {
                    messageBuilder.append(currentChar);
                }
            }
            index++;
        }

        if (tokenState == 2) {
            messageBuilder.append(tokenBuilder.toString());
        }
        return messageBuilder.toString();
    }

    @Override
    public Optional<String> translatePhrase(String phraseKey) {
        return Optional.ofNullable(activeTranslations.get(phraseKey));
    }

    /**
     * Updates models in all screens.
     */
    private void updateModels() {
        List<Screen> screenList = viewManager.getAllScreens();
        for (Screen screen : screenList) {
            if (screen.getModel() != null) {
                screen.getModel().update();
            }
        }
    }

    /**
     * Represents an observer for the {@link ChangeLanguageCommand} command.
     */
    private class ChangeLanguageCommandObserver extends NextObserver<ChangeLanguageCommand> {

        @Override
        public void onNext(ChangeLanguageCommand changeLanguageCommand) {
            Observable<Map<String, String>> translation = translationProvider.getTranslation(changeLanguageCommand.getLanguageCode());
            translation.subscribe(translationResponse -> {
                activeTranslations = translationResponse;
                updateModels();
                LanguageChangedEvent languageChangedEvent = new LanguageChangedEvent(changeLanguageCommand.getLanguageCode(), translationResponse);
                eventBus.post(languageChangedEvent);
            }, this::notifyErrorDuringChangingLanguage);
        }

        /**
         * Sends notification about that error occurred during the change.
         *
         * @param throwable exception.
         */
        private void notifyErrorDuringChangingLanguage(Throwable throwable) {
            eventBus.post(new ErrorEvent(throwable));
        }
    }

    /**
     * Represents an observer for register translation command.
     */
    private class RegisterTranslationCommandObserver extends NextObserver<RegisterTranslationCommand> {

        @Override
        public void onNext(RegisterTranslationCommand registerTranslationCommand) {
            activeTranslations = registerTranslationCommand.getTranslation();
            updateModels();
        }
    }
}
