package com.atsisa.gox.framework.model.property;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * List view property.
 * @param <T> type of the list items
 */
public class ListViewProperty<T extends Comparable<T>> extends ViewProperty<List> {

    /**
     * Initializes a new instance of the ListViewProperty class using an empty ArrayList as default value.
     * @param view             corresponding view
     * @param viewType         view type to update
     * @param viewPropertyName view property name to update
     */
    public ListViewProperty(View view, ViewType viewType, int viewPropertyName) {
        super(List.class, view, viewType, viewPropertyName, new ArrayList<T>());
    }

    /**
     * Initializes a new instance of the ListViewProperty class.
     * @param view             corresponding view
     * @param viewType         view type to update
     * @param viewPropertyName view property name to update
     * @param defaultValue     default list value
     */
    public ListViewProperty(View view, ViewType viewType, int viewPropertyName, List<T> defaultValue) {
        super(List.class, view, viewType, viewPropertyName, defaultValue);
    }

}
