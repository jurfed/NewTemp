package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ILineShapeLayer;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.LineShapeView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Line shape view rendering.
 */
public class LineShapeViewRenderer extends AbstractShapeRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the LineShapeViewRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public LineShapeViewRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    /**
     * Gets line shape view class type. return LineShapeView.class
     */
    @Override
    public Class<?> getType() {
        return LineShapeView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = changes;

        if (viewType == ViewType.LINE_SHAPE_VIEW) {
            lv.layer = (ILineShapeLayer) getViewLayer(view);
            if (BitUtility.isSet(lv.leftChanges, LineShapeView.ViewPropertyName.CLEAR_AREA)) {
                lv.layer.clear();
                lv.leftChanges = BitUtility.unset(lv.leftChanges, LineShapeView.ViewPropertyName.CLEAR_AREA);
            }
            if (BitUtility.isSet(lv.leftChanges, LineShapeView.ViewPropertyName.COLOR)) {
                lv.layer.setColor(((LineShapeView) view).getColor());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, LineShapeView.ViewPropertyName.COLOR);
            }
            if (BitUtility.isSet(lv.leftChanges, LineShapeView.ViewPropertyName.THICKNESS)) {
                lv.layer.setThickness(((LineShapeView) view).getThickness());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, LineShapeView.ViewPropertyName.THICKNESS);
            }
            if (BitUtility.isSet(lv.leftChanges, LineShapeView.ViewPropertyName.POINTS)) {
                lv.layer.drawLine(((LineShapeView) view).getPoints());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, LineShapeView.ViewPropertyName.POINTS);
            }
        } else {
            lv.leftChanges = super.render(view, viewType, lv.leftChanges);
        }
        return lv.leftChanges;
    }

    /**
     * Creates and returns a new line layer.
     * @param view - View
     * @return ILineShapeLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected ILineShapeLayer createLayer(View view) {
        return getLayerFactory().createLineLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link LineShapeViewRenderer} render method.
     */
    private class LocalVariables {

        private ILineShapeLayer layer;

        private int leftChanges;
    }
}
