package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.command.ShowScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Action responsible for either showing the screen if it is hidden or hiding it if it is visible.
 */
public class ToggleScreenAction extends ScreenAction {

    /**
     * The {@link IViewManager} reference.
     */
    private IViewManager viewManager;

    /**
     * Target screen reference.
     */
    private Screen targetScreen;

    /**
     * Initializes a new instance of the {@link ToggleScreenAction} class.
     */
    public ToggleScreenAction() {
        super();
        this.viewManager = GameEngine.current().getViewManager();
    }

    /**
     * Initializes a new instance of the {@link ToggleScreenAction} class.
     * @param logger      {@link ILogger}
     * @param eventBus    {@link IEventBus}
     * @param viewManager {@link IViewManager}
     */
    public ToggleScreenAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus);
        this.viewManager = viewManager;
    }

    @Override
    protected void grabData() {
        super.grabData();
        targetScreen = viewManager.getScreenById(getScreenId());
    }

    @Override
    protected void reset() {
        super.reset();
        targetScreen = null;
    }

    @Override
    protected void execute() {
        if (!targetScreen.isActive()) {
            eventBus.post(new ShowScreenCommand(getScreenId(), null));
        } else {
            eventBus.post(new HideScreenCommand(getScreenId(), null));
        }
        finish();
    }

    /**
     * Returns nothing, this action is not wait for any event.
     * @return nothing
     */
    @Override
    protected Class getEventClass() {
        return null;
    }

}
