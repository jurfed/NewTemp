package com.atsisa.gox.framework.resource;

/**
 * Abstract text resources class.
 */
public abstract class AbstractTextResource extends AbstractResource {

    /**
     * Text resource object.
     */
    private String text;

    /**
     * Creates resource object with given description.
     * @param description resource description object
     */
    public AbstractTextResource(ResourceDescription description) {
        super(description, ResourceType.TEXT);
    }

    /**
     * Creates a predefined text resource using particular text.
     * @param text initial text
     */
    public AbstractTextResource(String text) {
        this(text, ResourceType.TEXT);
    }

    /**
     * Creates a predefined text resource using particular text.
     * @param text         initial text
     * @param expectedType expected type of resource description
     */
    protected AbstractTextResource(String text, ResourceType expectedType) {
        super(null, expectedType);
        this.text = text;
        onSuccess();
    }

    /**
     * Creates resource object with given description.
     * @param description  resource description object
     * @param expectedType expected type of resource description
     */
    protected AbstractTextResource(ResourceDescription description, ResourceType expectedType) {
        super(description, expectedType);
    }

    /**
     * Gets Text object.
     * @return returns resource text
     */
    public String getText() {
        return text;
    }

    /**
     * Sets Text object.
     * @param text text which should be saved
     */
    public void setText(String text) {
        this.text = text;
    }

}
