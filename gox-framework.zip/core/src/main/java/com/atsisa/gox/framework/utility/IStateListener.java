package com.atsisa.gox.framework.utility;

/**
 * Generic state listener.
 * @param <T> type of the state
 */
public interface IStateListener<T extends Enum> {

    /**
     * Notifies about state changes.
     * @param source stateful object
     * @param state  changed state
     */
    void stateChanged(Object source, T state);
}
