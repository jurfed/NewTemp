package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.gwtent.reflection.client.Reflectable;

/**
 * Helper class to define text format properties.
 */
@Reflectable
@XmlElement
public class TextFormat {

    /**
     * Default fontName.
     */
    public static final String DEFAULT_FONT_NAME = "Arial";

    /**
     * Default fontName size.
     */
    public static final int DEFAULT_FONT_SIZE = 14;

    /**
     * Default color.
     */
    public static final int DEFAULT_COLOR = 0xffffff;

    /**
     * Scale auto width value.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> scaleAutoWidth = new ObservableProperty<>(Boolean.class, false);

    /**
     * Font size value.
     */
    @XmlAttribute(type = Integer.class)
    private final ObservableProperty<Integer> fontSize = new ObservableProperty<>(Integer.class, DEFAULT_FONT_SIZE);

    /**
     * Word wrap value.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> wordWrap = new ObservableProperty<>(Boolean.class, false);

    /**
     * Vertical align value.
     */
    @XmlAttribute(type = VerticalAlign.class)
    private final ObservableProperty<VerticalAlign> valign = new ObservableProperty<>(VerticalAlign.class, VerticalAlign.TOP);

    /**
     * Horizontal align value.
     */
    @XmlAttribute(type = HorizontalAlign.class)
    private final ObservableProperty<HorizontalAlign> halign = new ObservableProperty<>(HorizontalAlign.class, HorizontalAlign.LEFT);

    /**
     * Color value.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ObservableProperty<Integer> color = new ObservableProperty<>(Integer.class, DEFAULT_COLOR);

    /**
     * Font name value.
     */
    @XmlAttribute(type = String.class)
    private final ObservableProperty<String> fontName = new ObservableProperty<>(String.class, DEFAULT_FONT_NAME);

    /**
     * Gets the font name.
     * @return the font name.
     */
    public String getFontName() {
        return fontName.get();
    }

    /**
     * Sets the font name.
     * @param fontName the font name.
     */
    public void setFontName(String fontName) {
        this.fontName.set(fontName);
    }

    /**
     * Gets a boolean value that indicates whether text should be automatically scaled down or not if textWidth is greater than width.
     * @return boolean.
     */
    public boolean isScaleAutoWidth() {
        return scaleAutoWidth.get();
    }

    /**
     * Sets a boolean value that indicates whether text should be automatically scaled down or not if textWidth is greater than width.
     * @param scaleAutoWidth boolean.
     */
    public void setScaleAutoWidth(boolean scaleAutoWidth) {
        this.scaleAutoWidth.set(scaleAutoWidth);
    }

    /**
     * Gets the font size.
     * @return the font size.
     */
    public int getFontSize() {
        return fontSize.get();
    }

    /**
     * Sets the font size.
     * @param fontSize the font size.
     */
    public void setFontSize(int fontSize) {
        this.fontSize.set(fontSize);
    }

    /**
     * Gets a boolean value that indicates whether text should be automatically word wrap or not if textWidth is greater than width.
     * @return boolean.
     */
    public boolean isWordWrap() {
        return wordWrap.get();
    }

    /**
     * Sets a boolean value that indicates whether text will be automatically word wrap if textWidth is greater than width.
     * @param wordWrap boolean.
     */
    public void setWordWrap(boolean wordWrap) {
        this.wordWrap.set(wordWrap);
    }

    /**
     * Gets the vertical alignment of the text.
     * @return the vertical alignment.
     */
    public VerticalAlign getValign() {
        return valign.get();
    }

    /**
     * Sets the vertical alignment of the text.
     * @param valign the vertical alignment.
     */
    public void setValign(VerticalAlign valign) {
        this.valign.set(valign);
    }

    /**
     * Gets the horizontal alignment of the text.
     * @return the horizontal alignment of the text.
     */
    public HorizontalAlign getHalign() {
        return halign.get();
    }

    /**
     * Sets the horizontal alignment of the text.
     * @param halign the horizontal alignment.
     */
    public void setHalign(HorizontalAlign halign) {
        this.halign.set(halign);
    }

    /**
     * Gets the color of the text.
     * @return the color of the text.
     */
    public int getColor() {
        return color.get();
    }

    /**
     * Sets the color of the text.
     * Color must be in hex format (for example 0xffffff for white).
     * @param color the color of the text.
     */
    public void setColor(int color) {
        this.color.set(color);
    }

    /**
     * Gets the font name property.
     * @return font name property.
     */
    public ObservableProperty<String> fontName() {
        return fontName;
    }

    /**
     * Gets the color property.
     * @return color property.
     */
    public ObservableProperty<Integer> color() {
        return color;
    }

    /**
     * Gets the font size property.
     * @return font size property.
     */
    public ObservableProperty<Integer> fontSize() {
        return fontSize;
    }

    /**
     * Gets the horizontal align property.
     * @return horizontal align property.
     */
    public ObservableProperty<HorizontalAlign> haling() {
        return halign;
    }

    /**
     * Gets the vertical align property.
     * @return vertical align property.
     */
    public ObservableProperty<VerticalAlign> valing() {
        return valign;
    }

    /**
     * Gets the word wrap property.
     * @return word wrap property.
     */
    public ObservableProperty<Boolean> wordWrap() {
        return wordWrap;
    }

    /**
     * Gets the scale auto width property.
     * @return scale auto width property.
     */
    public ObservableProperty<Boolean> scaleAutoWidth() {
        return scaleAutoWidth;
    }
}
