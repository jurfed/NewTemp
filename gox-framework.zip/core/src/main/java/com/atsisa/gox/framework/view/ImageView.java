package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.view.spi.ITransform;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Basic image view.
 */
@Reflect_Full
@XmlElement
public class ImageView extends InteractiveView {

    /**
     * Boolean value that indicates whether image should be smoothed or not.
     */
    @XmlAttribute(type = Boolean.class)
    private final ViewProperty<Boolean> smoothing = new ViewProperty<>(Boolean.class, this, ViewType.IMAGE_VIEW, ViewPropertyName.SMOOTHING, false);

    /**
     * Image resource reference.
     */
    @XmlAttribute(name = "src", type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ViewProperty<IImageReference> image = new ViewProperty<>(IImageReference.class, this, ViewType.IMAGE_VIEW, ViewPropertyName.IMAGE);

    /**
     * Image transform object.
     */
    private final Transform transform;

    /**
     * Initializes a new instance of the ImageView class.
     */
    public ImageView() {
        transform = new Transform();
    }

    /**
     * Initializes a new instance of the ImageView class.
     * @param renderer {@link IRenderer}
     */
    public ImageView(IRenderer renderer) {
        super(renderer);
        transform = new Transform();
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        View view = skin.getView();
        if (view instanceof ImageView) {
            ImageView imageView = (ImageView) view;
            setImage(imageView.getImage());
            if (smoothing.hasDefaultValue()) {
                smoothing.set(imageView.isSmoothing());
            }
        }
    }

    /**
     * Gets a boolean value that indicates whether image should be smoothed or not.
     * @return boolean
     */
    public boolean isSmoothing() {
        return smoothing.get();
    }

    /**
     * Sets a value that indicates whether image should be smoothed or not.
     * @param smoothing - boolean
     */
    public void setSmoothing(boolean smoothing) {
        this.smoothing.set(smoothing);
    }

    /**
     * Gets smoothing observable view property.
     * @return smoothing observable view property
     */
    public ViewProperty<Boolean> smoothing() {
        return smoothing;
    }

    /**
     * Gets an image resource reference.
     * @return an image resource.
     */
    public IImageReference getImage() {
        return image.get();
    }

    /**
     * Sets new image resource.
     * @param imageReference - resource
     */
    public void setImage(IImageReference imageReference) {
        if (image.set(imageReference)) {
            if (width().hasDefaultValue()) {
                setWidth(getImage().getImageWrapperObject().getWidth());
            }
            if (height().hasDefaultValue()) {
                setHeight(getImage().getImageWrapperObject().getHeight());
            }
        }
    }

    /**
     * Returns image transform.
     * @return Transform
     */
    public ITransform getTransform() {
        return transform;
    }

    /**
     * Gets the image resource property.
     * @return image resource property
     */
    public IObservableProperty<IImageReference> image() {
        return image;
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.IMAGE_VIEW, ViewPropertyName.IMAGE | ViewPropertyName.TRANSFORM);
    }

    /**
     * Contains information about modifiers vertices for image view.
     */
    public final class Transform implements ITransform {

        /**
         * Contains information about all changes.
         */
        private int changes;

        /**
         * List of modifiers vertices.
         */
        private float[] modifiersVertices;

        /**
         * Initializes a new instance of the Transform class.
         */
        protected Transform() {
            modifiersVertices = new float[NUMBER_VERTICES];
        }

        @Override
        public void setTopLeftX(float x) {
            updateApex(TOP_LEFT_X, x);
        }

        @Override
        public void setTopLeftY(float y) {
            updateApex(TOP_LEFT_Y, y);
        }

        @Override
        public void setTopRightX(float x) {
            updateApex(TOP_RIGHT_X, x);
        }

        @Override
        public void setTopRightY(float y) {
            updateApex(TOP_RIGHT_Y, y);
        }

        @Override
        public void setBottomRightX(float x) {
            updateApex(BOTTOM_RIGHT_X, x);
        }

        @Override
        public void setBottomRightY(float y) {
            updateApex(BOTTOM_RIGHT_Y, y);
        }

        @Override
        public void setBottomLeftX(float x) {
            updateApex(BOTTOM_LEFT_X, x);
        }

        @Override
        public void setBottomLeftY(float y) {
            updateApex(BOTTOM_LEFT_Y, y);
        }

        @Override
        public float[] getVertices() {
            return modifiersVertices;
        }

        @Override
        public float getApex(int index) {
            if (index < NUMBER_VERTICES && index >= 0) {
                return modifiersVertices[index];
            }
            throw new IllegalArgumentException(
                    StringUtility.format("Apex at index position: %s, does not exist, allowed range is: 0-%s", index, NUMBER_VERTICES - 1));
        }

        @Override
        public boolean isZeroed() {
            return changes == 0;
        }

        /**
         * Updates specific apex value.
         * @param indexPosition index position in list
         * @param apexValue     new apex value
         */
        private void updateApex(int indexPosition, float apexValue) {
            if (modifiersVertices[indexPosition] != apexValue) {
                modifiersVertices[indexPosition] = apexValue;
                int bitPosition = 1 << indexPosition + 1;
                if (apexValue != 0) {
                    changes = BitUtility.set(changes, bitPosition);
                } else {
                    changes = BitUtility.unset(changes, bitPosition);
                }
                propertyChanged(ViewType.IMAGE_VIEW, ViewPropertyName.TRANSFORM);
            }
        }

    }

    /**
     * Image view property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getImageResource setMethod.
         */
        public static final int IMAGE = 1;

        /**
         * Represents a view property accessible via getSmoothing setMethod.
         */
        public static final int SMOOTHING = 1 << 1;

        /**
         * Represents a view property accessible via getTransform method.
         */
        public static final int TRANSFORM = 1 << 2;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

}
