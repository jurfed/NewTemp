package com.atsisa.gox.framework.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Used with commands which are can be triggered after user interaction.
 */
@Reflectable
public abstract class UserInteractionCommand {

    /**
     * Boolean value that indicates whether this command was triggered by user interaction or not.
     */
    private boolean triggeredByUser;

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public UserInteractionCommand(boolean triggeredByUser) {
        this.triggeredByUser = triggeredByUser;
    }

    /**
     * Gets a boolean value that indicates whether this command was triggered by user or not.
     * @return a boolean value that indicates whether this command was triggered by user or not.
     */
    public boolean isTriggeredByUser() {
        return triggeredByUser;
    }

}
