package com.atsisa.gox.framework.eventbus.subscription;

import com.atsisa.gox.framework.eventbus.Subscription;
import com.gwtent.reflection.client.Reflectable;

/**
 * Basic subscription representation.
 */
@Reflectable
public class RxSubscriptionWrapper implements Subscription {

    private rx.Subscription rxSubscription;

    /**
     * Creates a new instance of {@link RxSubscriptionWrapper}
     * @param rxSubscription inner RX subscription.
     */
    public RxSubscriptionWrapper(rx.Subscription rxSubscription) {
        this.rxSubscription = rxSubscription;
    }

    @Override
    public void unsubscribe() {
        rxSubscription.unsubscribe();
    }

    @Override
    public boolean isUnsubscribed() {
        return rxSubscription.isUnsubscribed();
    }
}
