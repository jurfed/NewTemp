package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.screen.event.ScreenHiddenEvent;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * Shows the screen by adding its layout to the stage.
 */
@Reflectable
public class HideScreenAction extends ScreenAction<ScreenHiddenEvent> {

    /**
     * Initializes a new instance of the {@link HideScreenAction} class.
     */
    public HideScreenAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link HideScreenAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public HideScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected Class<ScreenHiddenEvent> getEventClass() {
        return ScreenHiddenEvent.class;
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return AnimationScreenActionData.class;
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new HideScreenCommand(getScreenId(), ((AnimationScreenActionData) actionData).getViewAnimationData()));
    }
}
