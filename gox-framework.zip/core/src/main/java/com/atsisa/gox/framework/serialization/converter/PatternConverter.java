package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Base pattern converter class. It fills [XXX] with numbers.
 */
public abstract class PatternConverter implements IValueConverter {

    /**
     * Gets a reference by replacing the part of the pattern with index value.
     * @param resourceRefPattern pattern to replace
     * @param patternSpan        an array which describes start and end index for replacement (start = patternSpan[0], end = patternSpan[1])
     * @param index              a number that will be placed inside the pattern
     * @return a reference string
     */
    String getReference(String resourceRefPattern, int[] patternSpan, int index) {
        if (patternSpan != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(resourceRefPattern.substring(0, patternSpan[0]));
            int padLen = patternSpan[1] - patternSpan[0] - 1;
            sb.append(StringUtility.padLeft(String.valueOf(index), padLen, '0'));

            int secondPartStartIdx = patternSpan[1] + 1;
            int secondPartEndIdx = resourceRefPattern.length();
            if (secondPartEndIdx >= secondPartStartIdx) {
                sb.append(resourceRefPattern.substring(secondPartStartIdx, secondPartEndIdx));
            }
            return sb.toString();
        }
        return null;
    }

    /**
     * Gets an array describing start and end index for the pattern chunk that should be replaced.
     * @param resourceRefPattern pattern to replace
     * @return an array which describes start and end index for replacement (start = array[0], end = array[1])
     */
    int[] getPatternSpan(String resourceRefPattern) {
        char[] chars = resourceRefPattern.toCharArray();
        int startIdx = -1;
        int endIdx = -1;
        for (int idx = 0; idx < chars.length; idx++) {
            if (chars[idx] == '[') {
                startIdx = idx;
            } else if (chars[idx] == ']') {
                endIdx = idx;
                break;
            }
        }
        if (startIdx != -1 && endIdx != -1 && startIdx < endIdx) {
            return new int[] { startIdx, endIdx };
        }
        return null;
    }
}
