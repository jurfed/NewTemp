package com.atsisa.gox.framework.screen;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.ILoadingHandler;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.event.ErrorEvent;
import com.atsisa.gox.framework.event.GameInitializedEvent;
import com.atsisa.gox.framework.event.LoaderEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.Rectangle;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.HorizontalAlign;
import com.atsisa.gox.framework.view.ProgressBarView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.VerticalAlign;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Represents the splash screen during loading resources.
 */
public class PreloaderScreen extends BasicScreen implements IPreloaderScreen {

    /**
     * Default progress bar color.
     */
    private static final int DEFAULT_PROGRESS_BAR_COLOR = 0xB52222;

    /**
     * Relative progress bar height as percentage of the single screen height.
     */
    private static final float RELATIVE_PROGRESS_BAR_HEIGHT = 0.03F;

    /**
     * Default font size for fields.
     */
    private static final int FONT_SIZE = 22;

    /**
     * The maximum value that can achieve the progress bar.
     */
    private static final int PROGRESS_MAX_VALUE = 100;

    /**
     * Default progress bar view.
     */
    private ProgressBarView progressBarView;

    /**
     * Default percentage text view.
     */
    private TextView percentageTextView;

    /**
     * Info text view.
     */
    private TextView infoTextView;

    /**
     * Contains all loading handlers with their weights.
     */
    private Map<ILoadingHandler, Integer> loadingHandlers;

    /**
     * Total weight of all loading handlers.
     */
    private int totalLoadingHandlersWeight;

    /**
     * Total loaded percents.
     */
    private int totalPercentLoaded;

    /**
     * Reference to the game configuration.
     */
    private IGameConfiguration gameConfiguration;

    /**
     * Initializes a new instance of the {@link PreloaderScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public PreloaderScreen(@Named("PreloaderScreenLayoutId") String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        loadingHandlers = new HashMap<>();
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new LoaderEventObserver(), LoaderEvent.class);
        getEventBus().register(new GameInitializedEventObserver(), GameInitializedEvent.class);
    }

    @Override
    protected View createLayout() {
        ViewGroup viewGroup = new ViewGroup();

        gameConfiguration = GameEngine.current().getGameConfiguration();
        float singleScreenHeight = gameConfiguration.getSingleScreenHeight();
        float width = gameConfiguration.getWidth() / 2;
        int height = Math.round(gameConfiguration.getSingleScreenHeight() * RELATIVE_PROGRESS_BAR_HEIGHT);
        int numberOfScreens = gameConfiguration.getNumberOfScreens();
        Rectangle positionArea = new Rectangle(width / 2, (singleScreenHeight + height) / 2, width, height);

        progressBarView = createProgressBar(positionArea);
        viewGroup.addChild(progressBarView);

        percentageTextView = createTextView(positionArea);
        viewGroup.addChild(percentageTextView);

        float infoTextViewY = positionArea.getY() + positionArea.getHeight() * 2;
        positionArea.setY(infoTextViewY);
        infoTextView = createTextView(positionArea);
        viewGroup.addChild(infoTextView);

        moveViewToDisplay(viewGroup, numberOfScreens);
        return viewGroup;
    }

    /**
     * Moves given view to to selected display number.
     * @param view      view to move
     * @param displayNo display number
     */
    protected void moveViewToDisplay(View view, int displayNo) {
        if (displayNo <= gameConfiguration.getNumberOfScreens() && displayNo > 0) {
            float singleScreenHeight = gameConfiguration.getSingleScreenHeight();
            view.setY((displayNo - 1) * singleScreenHeight);
        }
    }

    @Override
    protected void beforeActivated() {
        validateLayout();
    }

    /**
     * Validates if all fields have been created.
     */
    protected void validateLayout() {
        if (percentageTextView == null) {
            notifyError(new IllegalArgumentException("PreloaderScreen | validateLayout | Percentage text view can not be null"));
        }
        if (progressBarView == null) {
            notifyError(new IllegalArgumentException("PreloaderScreen | validateLayout | Progress bar view can not be null"));
        }
    }

    /**
     * Reports an error using event bus.
     * @param throwable Throwable
     */
    private void notifyError(Throwable throwable) {
        ErrorEvent errorEvent = new ErrorEvent(throwable);
        getEventBus().post(errorEvent);
    }

    /**
     * Updates the progress.
     */
    private void updateProgress() {
        totalPercentLoaded = 0;
        float innerPercents;
        float handlerWeightPercents;
        for (Map.Entry<ILoadingHandler, Integer> entry : loadingHandlers.entrySet()) {
            innerPercents = (float) entry.getKey().getItemsLoaded() / entry.getKey().getItemsTotal();
            handlerWeightPercents = entry.getValue() / (float) totalLoadingHandlersWeight;
            totalPercentLoaded += innerPercents * handlerWeightPercents * PROGRESS_MAX_VALUE;
        }
        if (totalPercentLoaded > PROGRESS_MAX_VALUE) {
            totalPercentLoaded = PROGRESS_MAX_VALUE;
        }
        percentageTextView.setText(StringUtility.format("%s %", totalPercentLoaded));
        progressBarView.setMaxValue(PROGRESS_MAX_VALUE);
        progressBarView.setValue(totalPercentLoaded);
    }

    /**
     * Creates a progress bar view.
     * @param infoArea Rectangle
     * @return ProgressBarView
     */
    private ProgressBarView createProgressBar(Rectangle infoArea) {
        ProgressBarView progressBar = new ProgressBarView();
        progressBar.setWidth(infoArea.getWidth());
        progressBar.setX(infoArea.getWidth() / 2);
        progressBar.setHeight(infoArea.getHeight());
        progressBar.setY(infoArea.getY());
        progressBar.setColor(DEFAULT_PROGRESS_BAR_COLOR);
        return progressBar;
    }

    /**
     * Creates and returns text view.
     * @param infoArea Rectangle
     * @return TextView
     */
    private TextView createTextView(Rectangle infoArea) {
        TextView textView = new TextView();
        textView.setHeight(infoArea.getHeight());
        textView.setWidth(infoArea.getWidth());
        textView.setX(infoArea.getX());
        textView.setY(infoArea.getY());
        textView.setFontSize(FONT_SIZE);
        textView.setHalign(HorizontalAlign.CENTER);
        textView.setValign(VerticalAlign.MIDDLE);
        return textView;
    }

    @Override
    public void addLoadingHandler(ILoadingHandler loadingHandler, int weight) {
        totalLoadingHandlersWeight += weight;
        loadingHandlers.put(loadingHandler, weight);
    }

    /**
     * Updates preloader progress bar.
     * @param loaderEvent LoaderEvent
     */
    public void handleLoaderEvent(LoaderEvent loaderEvent) {
        infoTextView.setText(loaderEvent.getMessage());
        updateProgress();
    }

    /**
     * Hides pre-loader screen.
     */
    public void handleGameInitializedEvent() {
        hide();
    }

    private class LoaderEventObserver extends NextObserver<LoaderEvent> {

        @Override
        public void onNext(LoaderEvent loaderEvent) {
            handleLoaderEvent(loaderEvent);
        }
    }

    private class GameInitializedEventObserver extends NextObserver<GameInitializedEvent> {

        @Override
        public void onNext(GameInitializedEvent gameInitializedEvent) {
            handleGameInitializedEvent();
        }
    }

}
