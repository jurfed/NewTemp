package com.atsisa.gox.framework.action;

import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.Iterables;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data container for bundle actions process.
 */
@Reflect_Full
@XmlElement
public class BundleActionData extends ActionData implements IBundleActionData {

    /**
     * Bundle actions.
     */
    private List<Action> actions;

    /**
     * Initializes a new instance of the {@link BundleActionData} class.
     */
    public BundleActionData() {
        actions = Iterables.emptyList();
    }

    @Override
    public void setActions(List<Action> actions) {
        if (actions != null) {
            this.actions = actions;
        } else {
            throw new IllegalArgumentException("The action list cannot be null.");
        }
    }

    @Override
    public List<Action> getActions() {
        return actions;
    }

}
