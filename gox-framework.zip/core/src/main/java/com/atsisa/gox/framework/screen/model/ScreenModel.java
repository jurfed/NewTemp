package com.atsisa.gox.framework.screen.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.IPropertyProvider;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.model.property.ObservablePropertyContainer;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.google.inject.Inject;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

/**
 * A screen model. Use this class in your inheritance hierarchy if you want to use it as a data object in your layouts.
 */
@Reflectable(methods = false)
public class ScreenModel extends ObservablePropertyContainer implements IPropertyProvider {

    /**
     * Translator.
     */
    protected final ITranslator translator;

    /**
     * Map of templates.
     */
    private final Map<String, NamedProperty> templateMap;

    /**
     * Map of properties.
     */
    private final Map<String, NamedProperty> propertyMap;

    /**
     * Initializes a new instance of the {@link ScreenModel} class.
     * @param translator {@link ITranslator}
     */
    @Inject
    public ScreenModel(ITranslator translator) {
        this.translator = translator;
        propertyMap = new HashMap<>();
        templateMap = new HashMap<>();
    }

    /**
     * Initializes a new instance of the {@link ScreenModel} class.
     */
    public ScreenModel() {
        this(GameEngine.current().getUtility().getTranslator());
    }

    /**
     * Registers custom property to be available like others properties using: getProperty method.
     * @param namedProperty {@link NamedProperty}
     */
    protected void registerProperty(NamedProperty namedProperty) {
        propertyMap.put(namedProperty.getName(), namedProperty);
    }

    @Override
    @HasReflect
    public NamedProperty getProperty(String propertyKey) {
        return obtainProperty(propertyKey);
    }

    /**
     * Sets property value to specified key.
     * @param propertyKey   a property key
     * @param propertyValue a property value
     */
    public void setProperty(String propertyKey, Object propertyValue) {
        obtainProperty(propertyKey).set(propertyValue);
    }

    /**
     * Gets a template property. If does not exist, a new instance will be created.
     * @param templateKey a template key
     * @return a named property
     */
    public NamedProperty getTemplate(String templateKey) {
        return obtainTemplate(templateKey);
    }

    /**
     * Updates a properties in the screen model.
     */
    public void update() {
        updateProperties();
        updateTemplates();
    }

    /**
     * Clears all properties assigned to this model.
     */
    public void clear(){
        templateMap.clear();
        propertyMap.clear();
    }

    /**
     * Updates a templates in the screen model.
     */
    private void updateTemplates() {
        String translateMessage;
        for (Map.Entry<String, NamedProperty> entry : templateMap.entrySet()) {
            NamedProperty namedProperty = entry.getValue();
            translateMessage = translator.translateTemplate(namedProperty.getName());
            namedProperty.set(translateTemplateProperties(translateMessage));
        }
    }

    /**
     * Translate properties in specific template, where they are marked as follows: '{property}'.
     * @param template template to translate
     * @return a translated message
     */
    private String translateTemplateProperties(String template) {
        int index = 0;
        char currentChar;
        StringBuilder messageBuilder = new StringBuilder();
        StringBuilder propertyBuilder = null;
        boolean parsingProperty = false;
        while (index < template.length()) {
            currentChar = template.charAt(index);
            if (currentChar == '{' && !parsingProperty) {
                propertyBuilder = new StringBuilder();
                parsingProperty = true;
            } else if (currentChar == '}' && parsingProperty) {
                parsingProperty = false;
                Object propertyValue = getProperty(propertyBuilder.toString()).get();
                if (propertyValue != null) {
                    messageBuilder.append(propertyValue);
                } else {
                    messageBuilder.append('{');
                    messageBuilder.append(propertyBuilder.toString());
                    messageBuilder.append('}');
                }
            } else if (parsingProperty) {
                propertyBuilder.append(currentChar);
            } else {
                messageBuilder.append(currentChar);
            }
            index++;
        }
        if (parsingProperty) {
            propertyBuilder.insert(0, '{');
            messageBuilder.append(propertyBuilder.toString());
        }
        return messageBuilder.toString();
    }

    /**
     * Updates a properties in the screen model.
     */
    private void updateProperties() {
        for (Map.Entry<String, NamedProperty> entry : propertyMap.entrySet()) {
            Optional<String> optionalTranslation = translator.translatePhrase(entry.getKey());
            optionalTranslation.ifPresent(s -> entry.getValue().set(s));
        }
    }

    /**
     * Obtains a property. If does not exist, a new instance will be created.
     * @param propertyKey a property key
     * @return a named property
     */
    private NamedProperty obtainProperty(String propertyKey) {
        NamedProperty property = propertyMap.get(propertyKey);
        if (property == null) {
            property = new NamedProperty(Object.class, propertyKey);
            property.setDefaultValue();
            propertyMap.put(propertyKey, property);
        }
        return property;
    }

    /**
     * Obtains a template. If does not exist, a new instance will be created.
     * @param templateKey a property key
     * @return a named property
     */
    private NamedProperty obtainTemplate(String templateKey) {
        NamedProperty property = templateMap.get(templateKey);
        if (property == null) {
            property = new NamedProperty(Object.class, templateKey);
            property.setDefaultValue();
            templateMap.put(templateKey, property);
        }
        return property;
    }
}
