package com.atsisa.gox.framework.animation;

import rx.Observable;
import rx.subjects.PublishSubject;

/**
 * A base animation class holding the animation state.
 */
public abstract class AbstractAnimation implements IAnimation {

    /**
     * The animation state subject.
     */
    private final PublishSubject<AnimationState> animationStateSubject;

    /**
     * The animation state.
     */
    private AnimationState animationState;

    /**
     * Initializes the animation state to STOPPED.
     */
    protected AbstractAnimation() {
        animationStateSubject = PublishSubject.create();
        animationState = AnimationState.STOPPED;
    }

    @Override
    public synchronized boolean isPlaying() {
        return animationState == AnimationState.PLAYING;
    }

    @Override
    public synchronized boolean isPaused() {
        return animationState == AnimationState.PAUSED;
    }

    @Override
    public synchronized boolean isStopped() {
        return animationState == AnimationState.STOPPED;
    }

    @Override
    public synchronized AnimationState getAnimationState() {
        return animationState;
    }

    @Override
    public Observable<AnimationState> getAnimationStateObservable() {
        return animationStateSubject;
    }

    /**
     * Sets current animation state.
     * @param animationState The new animation state.
     */
    protected synchronized void setAnimationState(AnimationState animationState) {
        if (this.animationState == animationState) {
            return;
        }

        this.animationState = animationState;
        animationStateSubject.onNext(animationState);
    }
}
