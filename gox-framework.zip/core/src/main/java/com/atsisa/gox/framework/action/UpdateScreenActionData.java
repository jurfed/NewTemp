package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * A representation of update model action parameters.
 */
@XmlElement
@Reflect_Full
public class UpdateScreenActionData extends ActionData {

    /**
     * Id layout.
     */
    @XmlAttribute
    private String screenId;

    /**
     * Method name.
     */
    @XmlAttribute
    private String method;

    /**
     * Method parameters.
     */
    private Object[] methodParameters;

    /**
     * Initializes a new instance of the UpdateScreenActionData class.
     */
    public UpdateScreenActionData() {
        methodParameters = new Object[0];
    }

    /**
     * Initializes a new instance of the UpdateScreenActionData class.
     * @param screenId         screen identifier
     * @param method           update setMethod name
     * @param methodParameters update setMethod parameters
     */
    public UpdateScreenActionData(String screenId, String method, Object[] methodParameters) {
        this.screenId = screenId;
        this.method = method;
        this.methodParameters = methodParameters;
    }

    /**
     * Gets the screen identifier.
     * @return String the screen identifier
     */
    public String getScreenId() {
        return screenId;
    }

    /**
     * Sets the screen identifier.
     * @param screenId the screen identifier
     */
    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    /**
     * Gets the update setMethod name.
     * @return update setMethod name
     */
    public String getMethod() {
        return method;
    }

    /**
     * Sets the update setMethod name.
     * @param method update setMethod name
     */
    public void setMethod(String method) {
        this.method = method;
    }

    /**
     * Gets the setMethod parameters array.
     * @return setMethod parameters array
     */
    public Object[] getMethodParameters() {
        return methodParameters;
    }

    /**
     * Sets the setMethod parameters array.
     * @param methodParameters setMethod parameters array
     */
    public void setMethodParameters(Object[] methodParameters) {
        this.methodParameters = methodParameters;
    }
}
