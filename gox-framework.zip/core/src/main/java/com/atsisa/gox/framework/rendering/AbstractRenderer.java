package com.atsisa.gox.framework.rendering;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;

import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.layer.ILayerFactory;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;
import com.google.inject.Inject;

import it.unimi.dsi.fastutil.ints.Int2IntArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayFIFOQueue;

/**
 * Provides a common implementation for all renderers.
 */
public abstract class AbstractRenderer implements IRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * The active render function.
     */
    private Runnable activeRender = () -> {
    };

    /**
     * The state of renderer.
     */
    private AtomicReference<RendererState> state = new AtomicReference<>(RendererState.PAUSED);

    /**
     * The expected delta time.
     */
    private final float expectedDeltaTime;

    /**
     * Registered renders.
     */
    private Object2ObjectArrayMap<String, IViewRenderer> registeredRenderers;

    /**
     * Game loop listeners.
     */
    private final List<IGameLoopListener> gameLoopListeners;

    /**
     * Game loop listeners that has to be unregistered.
     */
    private final ObjectArrayFIFOQueue<IGameLoopListener> gameLoopListenersToRemove;

    /**
     * Reflection helper.
     */
    private IReflection reflection;

    /**
     * Initialization listener.
     */
    private IRendererInitListener initListener;

    /**
     * A logger reference.
     */
    private ILogger logger;

    /**
     * Layer factory reference.
     */
    private ILayerFactory layerFactory;

    /**
     * Views ID sequence field.
     */
    private int currentViewSequenceNumber;

    /**
     * Structure holding all changes occurred during the updateModel phase. It holds only primitive references to view
     * uuids, viewtype ordinals and changed properties.
     */
    private final Int2ObjectArrayMap<Int2IntArrayMap> changes;

    /**
     * Structure holding all render requests that has to be processed in the render phase.
     */
    private final ConcurrentLinkedQueue<ViewChangedEvent> viewChangesEvents;

    /**
     * ViewChangedEvent objects pool.
     */
    private final ConcurrentLinkedQueue<ViewChangedEvent> viewChangesEventsPool;

    /**
     * View manager reference.
     */
    private IViewManager viewManager;

    /**
     * Initializes a new instance of the {@link AbstractRenderer} class.
     * @param reflection        {@link IReflection}
     * @param logger            {@link ILogger}
     * @param layerFactory      {@link ILayerFactory}
     * @param gameConfiguration {@link IGameConfiguration}
     * @param viewManager       {@link IViewManager}
     */
    @Inject
    protected AbstractRenderer(IReflection reflection, ILogger logger, ILayerFactory layerFactory, IGameConfiguration gameConfiguration,
            IViewManager viewManager) {
        this.reflection = reflection;
        this.logger = logger;
        this.layerFactory = layerFactory;
        this.viewManager = viewManager;
        registeredRenderers = new Object2ObjectArrayMap<>();
        gameLoopListeners = new ArrayList<>();
        gameLoopListenersToRemove = new ObjectArrayFIFOQueue<>();

        lv = new LocalVariables();
        changes = new Int2ObjectArrayMap<>(1024);
        viewChangesEvents = new ConcurrentLinkedQueue<>();
        viewChangesEventsPool = new ConcurrentLinkedQueue<>();
        expectedDeltaTime = 1.0F / gameConfiguration.getFPS();
    }

    @Override
    public synchronized void registerViewRenderer(IViewRenderer renderer) {
        if (!registeredRenderers.containsKey(renderer.getType())) {
            registeredRenderers.put(renderer.getType().getName(), renderer);
        }
    }

    @Override
    public void addGameLoopListener(IGameLoopListener listener) {
        gameLoopListeners.add(listener);
    }

    @Override
    public boolean removeGameLoopListener(IGameLoopListener listener) {
        gameLoopListenersToRemove.enqueue(listener);
        return true;
    }

    @Override
    public boolean dispose(View view) {
        IViewRenderer renderer = getViewRenderer(view.getClass());
        if (renderer != null) {
            return renderer.dispose(view);
        } else {
            logger.warn("Renderer for %s not found", view.getClass());
            return false;
        }
    }

    @Override
    public void propertyChanged(View view, ViewType viewType, int property) {
        lv.viewChanges = changes.get(view.getUuid());
        if (lv.viewChanges == null) {
            lv.viewChanges = new Int2IntArrayMap(10);
            lv.viewChanges.defaultReturnValue(-1);
            changes.put(view.getUuid(), lv.viewChanges);
        }
        lv.tempChanges = lv.viewChanges.get(viewType.ordinal());
        if (lv.tempChanges > -1) {
            if (lv.tempChanges == property) {
                return;
            }
            lv.viewChanges.put(viewType.ordinal(), BitUtility.set(lv.tempChanges, property));
        } else {
            if (viewChangesEventsPool.isEmpty()) {
                lv.viewChangedEvent = new ViewChangedEvent();
            } else {
                lv.viewChangedEvent = viewChangesEventsPool.poll();
            }
            lv.viewChangedEvent.setView(view);
            lv.viewChangedEvent.setViewType(viewType);
            lv.viewChanges.put(viewType.ordinal(), property);
            viewChangesEvents.offer(lv.viewChangedEvent);
        }
    }

    @Override
    public IViewRenderer getViewRenderer(final Class<?> classType) {
        Class<?> clazzType = classType;
        while (true) {
            lv.localFetchViewRenderer = registeredRenderers.get(clazzType.getName());
            if (lv.localFetchViewRenderer != null) {
                return lv.localFetchViewRenderer;
            }
            lv.parentClassType = reflection.getSuperClass(clazzType);
            if (lv.parentClassType != null) {
                clazzType = lv.parentClassType;
                continue;
            }
            return null;
        }
    }

    @Override
    public void onCreate(IRendererInitListener rendererInitListener) {
        logger.debug("AbstractRenderer | onCreate");
        initializeViewRenderers();
        initListener = rendererInitListener;
        viewManager.init(this);
    }

    @Override
    public void render() {
        activeRender.run();
    }

    @Override
    public boolean pause() {
        if (state.compareAndSet(RendererState.ACTIVE, RendererState.PAUSED)) {
            logger.debug("Renderer has been set to %s state", RendererState.PAUSED);
            activeRender = () -> {
            };
            getKeyboardInputEventDelegate().pause();
            getTouchInputEventDelegate().pause();
            return true;
        }
        return false;
    }

    @Override
    public boolean resume() {
        if (state.compareAndSet(RendererState.PAUSED, RendererState.ACTIVE)) {
            logger.debug("Renderer has been set to %s state", RendererState.ACTIVE);
            activeRender = this::renderView;
            getKeyboardInputEventDelegate().resume();
            getTouchInputEventDelegate().resume();
            return true;
        }
        return false;
    }

    @Override
    public RendererState getState() {
        return state.get();
    }

    @Override
    public void dispose() {
        for (IViewRenderer viewRenderer : registeredRenderers.values()) {
            viewRenderer.dispose();
        }
        registeredRenderers.clear();
        gameLoopListeners.clear();
        changes.clear();
        viewChangesEvents.clear();
        viewChangesEventsPool.clear();
        getKeyboardInputEventDelegate().clear();
        getTouchInputEventDelegate().clear();
    }

    public Iterable<IViewRenderer> getAllViewRenderers() {
        return registeredRenderers.values();
    }

    /**
     * Notifies all registered game loop listeners about update.
     * @param delta the time span between last two frames in milliseconds divided by 1000
     */
    public void notifyGameLoopStep(final float delta) {
        lv.deltaTimeLeft += delta;
        if (lv.deltaTimeLeft >= expectedDeltaTime) {
            notifySingleGameLoopStep(lv.deltaTimeLeft);
            lv.deltaTimeLeft = 0;
        }
    }

    /**
     * Renders changes occurred in the view.
     */
    protected void renderView() {
        while (!viewChangesEvents.isEmpty()) {
            lv.renderViewChangedEvent = viewChangesEvents.poll();
            View v = lv.renderViewChangedEvent.getView();
            lv.localRenderRenderer = v.getViewRenderer();
            lv.leftChanges = lv.localRenderRenderer.render(lv.renderViewChangedEvent.getView(), lv.renderViewChangedEvent.getViewType(),
                    changes.get(lv.renderViewChangedEvent.getView().getUuid()).get(lv.renderViewChangedEvent.getViewType().ordinal()));
            changes.get(lv.renderViewChangedEvent.getView().getUuid()).put(lv.renderViewChangedEvent.getViewType().ordinal(), -1);
            viewChangesEventsPool.offer(lv.renderViewChangedEvent);
            if (lv.leftChanges > 0) {
                logger.error("Rendering did not process all changed properties: [changes] %s,[viewId] %s,[viewUuid] %s,[rendererType] %s ", lv.leftChanges,
                        lv.renderViewChangedEvent.getView().getId(), lv.renderViewChangedEvent.getView().getUuid(),
                        lv.renderViewChangedEvent.getView().getViewRenderer().getType());
            }
        }
    }

    /**
     * Notifies about a single game loop step (not longer than a single frame according to the configuration).
     * @param delta The time span between last two frames in milliseconds
     */
    private void notifySingleGameLoopStep(final float delta) {
        lv.gameLoopListenersSize = gameLoopListenersToRemove.size();
        for (lv.gameLoopListenersIndex = 0; lv.gameLoopListenersIndex < lv.gameLoopListenersSize; lv.gameLoopListenersIndex++) {
            gameLoopListeners.remove(gameLoopListenersToRemove.dequeue());
        }

        lv.gameLoopListenersSize = gameLoopListeners.size();
        for (lv.gameLoopListenersIndex = 0; lv.gameLoopListenersIndex < lv.gameLoopListenersSize; lv.gameLoopListenersIndex++) {
            gameLoopListeners.get(lv.gameLoopListenersIndex).onUpdate(delta);
        }
    }

    /**
     * Triggers rendererInitialized setMethod on initialization listener.
     */
    public void initCompleted() {
        if (initListener != null) {
            initListener.rendererInitialized();
        }
    }

    /**
     * Gets registered renders list.
     * @return list of IViewRenderer
     */
    protected Map<String, IViewRenderer> getRegisteredRenderers() {
        return registeredRenderers;
    }

    /**
     * Gets game loop listeners list.
     * @return list of IGameLoopListener
     */
    protected Iterable<IGameLoopListener> getGameLoopListeners() {
        return gameLoopListeners;
    }

    /**
     * Gets the reflection reference.
     * @return reflection reference
     */
    public IReflection getReflection() {
        return reflection;
    }

    /**
     * Gets the logger reference.
     * @return logger reference
     */
    public ILogger getLogger() {
        return logger;
    }

    @Override
    public ILayerFactory getLayerFactory() {
        return layerFactory;
    }

    @Override
    public int generateNextSequentialNumber() {
        return currentViewSequenceNumber++;
    }

    /**
     * Holds information about changes occurred in the given View since last render.
     */
    class ViewChangedEvent {

        /**
         * Changed view.
         */
        private View view;

        /**
         * View type of changed view.
         */
        private ViewType viewType;

        /**
         * Gets changed view.
         * @return changed view
         */
        public View getView() {
            return view;
        }

        /**
         * Gets changed view type.
         * @return changed view type
         */
        public ViewType getViewType() {
            return viewType;
        }

        /**
         * Sets changed view.
         * @param view changed view
         */
        public void setView(View view) {
            this.view = view;
        }

        /**
         * Sets changed view type.
         * @param viewType changed view type
         */
        public void setViewType(ViewType viewType) {
            this.viewType = viewType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            ViewChangedEvent that = (ViewChangedEvent) o;

            if (view != null ? !view.equals(that.view) : (that.view != null)) {
                return false;
            } else {
                return viewType == that.viewType;
            }
        }

        @Override
        public int hashCode() {
            int result = view != null ? view.hashCode() : 0;
            result = 31 * result + (viewType != null ? viewType.hashCode() : 0);
            return result;
        }

        /**
         * Reset all values of a given view changed event.
         * @return ViewChangedEvent
         */
        public ViewChangedEvent reset() {
            view = null;
            viewType = null;
            return this;
        }

    }

    /**
     * Holder for instances of local variables used in the {@link AbstractRenderer} render method.
     */
    private class LocalVariables {

        private IViewRenderer localFetchViewRenderer;

        private IViewRenderer localRenderRenderer;

        private ViewChangedEvent viewChangedEvent;

        private ViewChangedEvent renderViewChangedEvent;

        private Class<?> parentClassType;

        private int gameLoopListenersIndex;

        private int gameLoopListenersSize;

        private int leftChanges;

        private int tempChanges;

        private Int2IntArrayMap viewChanges;

        private float deltaTimeLeft;
    }
}
