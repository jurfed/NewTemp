package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ActionStateException;
import com.atsisa.gox.framework.exception.GameException;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * This is a base class for all action classes. Actions contains business logic of application. They usually are grouped into action queues and executed
 * sequential.
 * @param <T> the type extends ActionData
 */
@Reflectable(fields = false)
public abstract class Action<T extends ActionData> implements IAction<T>, IFinishCallback {

    /**
     * An event bus reference.
     */
    protected final IEventBus eventBus;

    /**
     * ILogger implementation.
     */
    protected final ILogger logger;

    /**
     * State listeners.
     */
    private final List<IStateListener<ActionState>> stateListeners;

    /**
     * Data for processing.
     */
    protected T actionData;

    /**
     * Current action state.
     */
    private ActionState state = ActionState.PENDING;

    /**
     * Bundle action where this action is used.
     */
    private BundleAction parentBundleAction;

    /**
     * Action name.
     */
    private String name;

    /**
     * Index of action in its queue. This value is sets up by Action queue.
     */
    private int queueIndex;

    /**
     * Reference to parent queue (a queue that this action is a part of).
     */
    private ActionQueue parentQueue;

    /**
     * A throwable error.
     */
    private Throwable error;

    /**
     * A value indicating that no further processing should be performed by the queue.
     */
    private boolean noFurtherProcessing;

    /**
     * Initializes a new instance of the {@link Action} class.
     */
    public Action() {
        logger = GameEngine.current().getLogger();
        logger.trace("Action | ctor | %s", this);

        eventBus = GameEngine.current().getEventBus();
        stateListeners = new ArrayList<>();
    }

    /**
     * Initializes a new instance of the {@link Action} class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public Action(ILogger logger, IEventBus eventBus) {
        this.logger = logger;
        logger.trace("Action | ctor | %s", this);

        this.eventBus = eventBus;
        stateListeners = new ArrayList<>();
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return null;
    }

    @Override
    public final BundleAction getParentBundleAction() {
        return parentBundleAction;
    }

    @Override
    public final String getName() {
        return name;
    }

    @Override
    public final void setName(final String value) {
        name = value;
    }

    @Override
    public final int getQueueIndex() {
        return queueIndex;
    }

    @Override
    public final ActionQueue getParentQueue() {
        return parentQueue;
    }

    @Override
    public final void setActionData(T data) {
        actionData = data;
    }

    /**
     * Gets qualified name.
     * @return string tree structure
     */
    public String getQualifiedName() {
        String structure = Integer.toString(queueIndex);
        if (parentBundleAction != null) {
            structure = StringUtility.format("%s.BundleAction[%s]", parentBundleAction.getQualifiedName(), queueIndex);
        } else if (parentQueue != null) {
            structure = StringUtility.format("Queue[%s].BundleAction[%s]", parentQueue.getId(), queueIndex);
        }
        return structure;
    }

    @Override
    public Throwable getError() {
        return error;
    }

    @Override
    public ActionState getState() {
        return state;
    }

    @Override
    public void addStateListener(IStateListener<ActionState> listener) {
        stateListeners.add(listener);
    }

    @Override
    public void removeStateListener(IStateListener<ActionState> listener) {
        stateListeners.remove(listener);
    }

    @Override
    public boolean hasStateListeners() {
        return !stateListeners.isEmpty();
    }

    @Override
    public boolean isFinished() {
        return state == ActionState.FAILED || state == ActionState.SUCCEEDED || state == ActionState.TERMINATED;
    }

    @Override
    public String toString() {
        if (!StringUtility.isNullOrEmpty(name)) {
            return StringUtility.format("%s (%s)", name, super.toString());
        }
        return super.toString();
    }

    /**
     * Executes the action with no interaction of the action manager.
     */
    public void executeStandalone() {
        doExecute();
    }

    @Override
    public void onFinish() {
        finish();
    }

    /**
     * Validates the action and delegates execution to the execute setMethod.
     */
    void doExecute() {
        logger.debug("Action | doExecute | %s", this);
        try {
            if (state == ActionState.PENDING) {
                grabData();
                validate();
                setState(ActionState.VALIDATED);
                if (parentQueue != null) {
                    logger.info("%s Executing '%s' action", getQualifiedName(), name);
                }
                setState(ActionState.ACTIVE);
                execute();
            } else {
                throw new ActionStateException(StringUtility.format("Could not process action. Invalid '%s' action state '%s'.", name, state.toString()));
            }
        } catch (Exception e) {
            error = e;
            setState(ActionState.FAILED, false);
        }
    }

    /**
     * Delegates termination to terminate setMethod and sets the action state to TERMINATED.
     */
    void doTerminate() {
        logger.debug("Action | doTerminate | %s", this);
        terminate();
        setState(ActionState.TERMINATED);
    }

    /**
     * Resets the action state to be reused.
     */
    void doReset() {
        logger.debug("Action | doReset | %s", this);
        reset();
        error = null;
        state = ActionState.PENDING;
        noFurtherProcessing = false;
    }

    /**
     * Sets parent bundle action.
     * @param action parent bundle action
     */
    final void setParentBundleAction(BundleAction action) {
        parentBundleAction = action;
    }

    /**
     * Sets the queue index.
     * @param value queue index
     */
    final void setQueueIndex(final int value) {
        queueIndex = value;
    }

    /**
     * Sets the parent queue.
     * @param queue the parent queue
     */
    final void setParentQueue(final ActionQueue queue) {
        parentQueue = queue;
    }

    /**
     * Gets a value indicating that no further processing should be performed by the queue.
     * @return a value indicating that no further processing should be performed by the queue
     */
    final boolean noFurtherProcessing() {
        return noFurtherProcessing;
    }

    /**
     * Cancels further queue processing.
     */
    protected final void cancelFurtherProcessing() {
        noFurtherProcessing = true;
    }

    /**
     * Allows further queue processing.
     */
    protected final void allowFurtherProcessing() {
        noFurtherProcessing = false;
    }

    /**
     * When execution of action is done, finish setMethod must be called. It will inform action queue that next action can be performed. This setMethod can be
     * called asynchronously. When execution of action is done, finish setMethod must be called. It will inform action queue that next action can be performed.
     * This setMethod can be called asynchronously.
     */
    protected void finish() {
        if (state != ActionState.ACTIVE) {
            error = new ActionStateException(StringUtility.format("Could not finish action. Invalid '%s' action state '%s'.", name, state.toString()));
            setState(ActionState.FAILED);
        } else {
            setState(ActionState.SUCCEEDED);
        }
    }

    /**
     * When execution of action proceeds, fail setMethod can be called to mark errors in asynchronous actions. This setMethod propagates the error to all game
     * error handlers.
     * @param cause reason for failing
     */
    protected final void fail(Throwable cause) {
        fail(cause, true);
    }

    /**
     * When execution of action proceeds, fail setMethod can be called to mark errors in asynchronous actions.
     * @param cause          reason for failing
     * @param propagateError a value indicating whether errors should be propagated to error handlers
     */
    protected final void fail(Throwable cause, boolean propagateError) {
        if (state != ActionState.ACTIVE) {
            error = new ActionStateException(StringUtility.format("Could not fail action. Invalid '%s' action state '%s'.", name, state.toString()));
        } else {
            error = cause;
        }
        logger.error("Action failed " + cause.getMessage(), cause);
        setState(ActionState.FAILED, propagateError);
    }

    /**
     * This setMethod contains business logic for the action. The setMethod is used to perform any required operations. Execution of this setMethod can be
     * performed only if validation was passed. Otherwise action will finished immediately and next action from queue will be processed. This setMethod need to
     * be overridden in child class.
     */
    protected abstract void execute();

    /**
     * Method can take data from other objects and save them in class parameters. Those parameters can be validated and used in execution of action later.
     */
    protected void grabData() {
    }

    /**
     * When overridden this setMethod is responsible for clearing the action after execution.
     */
    protected void reset() {
    }

    /**
     * Checks if the action can be executed or not. If the validation fails, an exception should be thrown and the action will not be proceed further.
     * Otherwise, the next phase of processing Action can be performed. This setMethod should be overridden in child class.
     * @throws ValidationException an exception should be thrown to fail the validation
     */
    protected void validate() throws ValidationException {
    }

    /**
     * When overridden, it should immediately terminate current action. The action after calling this setMethod should be considered as interrupted and ready to
     * be reset.
     */
    protected void terminate() {
    }

    /**
     * Sets the state of the action and propagates errors to error handlers Additionally, the setMethod fires stateChanged on all registered listeners.
     * @param state new action state
     */
    private void setState(ActionState state) {
        setState(state, true);
    }

    /**
     * Sets the state of the action. Additionally, the setMethod fires stateChanged on all registered listeners.
     * @param actionState     new action state
     * @param propagateErrors a value indicating whether errors should be propagated to error handlers
     */
    private void setState(ActionState actionState, boolean propagateErrors) {
        if (state == actionState) {
            return;
        }
        state = actionState;
        logger.trace("Action | setState | New '%s' action state: %s", this, state);

        if (state == ActionState.FAILED) {
            logger.error(StringUtility.format("Action failed! - %s", error.getMessage()), error.getCause());
            if (propagateErrors) {
                propagateErrors();
            }
        }
        List<IStateListener<ActionState>> list = new ArrayList<>(stateListeners);
        for (IStateListener<ActionState> listener : list) {
            listener.stateChanged(this, actionState);
        }
    }

    /**
     * Propagate errors.
     */
    private void propagateErrors() {
        if (error instanceof GameException) {
            eventBus.post(new ErrorOccurredEvent(error));
        } else {
            eventBus.post(new ErrorOccurredEvent(new GeneralSystemException(error)));
        }
    }
}
