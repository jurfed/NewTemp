package com.atsisa.gox.framework.utility.text;

/**
 * List ascii codes.
 */
public final class ASCIICode {

    /**
     * ASCII code for new line.
     */
    public static final int NEW_LINE = 10;

    /**
     * ASCII code for space.
     */
    public static final int SPACE = 32;

    /**
     * Private constructor.
     */
    private ASCIICode() {
    }

}
