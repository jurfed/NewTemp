package com.atsisa.gox.framework.animation;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenCallback;
import rx.Observable;
import rx.subjects.PublishSubject;

/**
 * Implementation of tween class for View objects.
 */
public class TweenAnimation extends AbstractAnimation {

    /**
     * The animation controller.
     */
    private final IAnimationController<TweenAnimation> controller;

    /**
     * The tween state subject.
     */
    private final PublishSubject<Integer> tweenStateSubject;

    /**
     * A Tween object.
     */
    private BaseTween<Tween> tween;

    /**
     * A predefined tween.
     */
    private BaseTween<Tween> predefinedTween;

    /**
     * The tween animation speed.
     */
    private float speed;

    /**
     * Constructor, which allow to set external manager. Set some default animation properties.
     * @param controller {@link IAnimationController}
     */
    public TweenAnimation(IAnimationController<TweenAnimation> controller) {
        this.controller = controller;
        tweenStateSubject = PublishSubject.create();
    }

    @Override
    public synchronized void play() {
        if (isPlaying()) {
            return;
        }

        if (isStopped()) {
            validateReadyToPlay();
            tween = createTween();
            tween.setCallback(new InternalTweenCallback());
            controller.play(this);
        } else {
            controller.resume(this);
        }

        setAnimationState(AnimationState.PLAYING);
    }

    @Override
    public synchronized void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        controller.pause(this);
        setAnimationState(AnimationState.PAUSED);
    }

    @Override
    public synchronized void stop() {
        if (isStopped()) {
            return;
        }

        controller.stop(this);
        tween = null;
        setAnimationState(AnimationState.STOPPED);
    }

    /**
     * <p>Allows to keep track of tween state changes.</p>
     * The following constants defined in the {@link TweenCallback} interface
     * can be passed as integers to denoted states:
     * <ul>
     * <li>{@link TweenCallback#BEGIN} - right after the delay (if any)</li>
     * <li>{@link TweenCallback#START} - at each iteration beginning</li>
     * <li>{@link TweenCallback#END} - at each iteration ending, before the repeat delay</li>
     * <li>{@link TweenCallback#COMPLETE} - at last END event</li>
     * <li>{@link TweenCallback#BACK_BEGIN} - at the beginning of the first backward iteration</li>
     * <li>{@link TweenCallback#BACK_START} - at each backward iteration beginning, after the repeat delay</li>
     * <li>{@link TweenCallback#BACK_END} - at each backward iteration ending</li>
     * <li>{@link TweenCallback#BACK_COMPLETE} - at last BACK_END event</li>
     * </ul>
     * @return An observable tween state.
     */
    public Observable<Integer> getTweenStateObservable() {
        return tweenStateSubject;
    }

    /**
     * Gets the tween which corresponds with this animation.
     * <p>
     * This object is only available when the animation is PLAYING, is PAUSED
     * or when this animation is passed to any of {@link IAnimationController}
     * methods.
     * </p>
     * @return The tween object.
     */
    public BaseTween<Tween> getTween() {
        return tween;
    }

    /**
     * Sets a custom tween for this animation.
     * @param tween A custom tween for the animation.
     */
    public void setTween(BaseTween<Tween> tween) {
        predefinedTween = tween;
    }

    /**
     * Gets the animation controller.
     * @return The animation controller.
     */
    protected IAnimationController<TweenAnimation> getController() {
        return controller;
    }

    /**
     * Creates tween object using properties selected before.
     * @return tween object
     */
    protected BaseTween<Tween> createTween() {
        return predefinedTween;
    }

    /**
     * Validates whether this instance is ready for play.
     */
    protected void validateReadyToPlay() {
        if (predefinedTween == null) {
            throw new IllegalStateException("The tween for the TweenAnimation has not been set.");
        }
    }

    /**
     * Gets the speed of this animation.
     * @return The relative speed of this animation.
     */
    public float getSpeed() {
        return speed;
    }

    /**
     * Sets the relative speed of this animation.
     * @param speed The speed.
     */
    public void setSpeed(float speed) {
        this.speed = speed;
    }

    /**
     * An internal tween callback responsible for stopping the animation.
     */
    private class InternalTweenCallback implements TweenCallback {

        /**
         * Called when tween event occurs.
         * @param type   Type of an event.
         * @param source The event source.
         */
        @Override
        public void onEvent(int type, BaseTween<?> source) {
            tweenStateSubject.onNext(type);
            if (type == TweenCallback.COMPLETE) {
                stop();
            }
        }
    }
}
