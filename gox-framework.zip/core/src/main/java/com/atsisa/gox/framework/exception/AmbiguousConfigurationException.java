package com.atsisa.gox.framework.exception;

/**
 * Exception thrown, when resource id is matching to at least two active configurations.
 */
public class AmbiguousConfigurationException extends RuntimeException {

    /**
     * Constructs a new exception without its detail message. The cause is not initialized.
     */
    public AmbiguousConfigurationException() {
    }

    /**
     * Constructs a new exception with the specified detail message.
     * @param message message of the exception
     */
    public AmbiguousConfigurationException(final String message) {
        super(message);
    }

    /**
     * Constructs a new exception with the specified detail message and cause.
     * @param message message of the exception
     * @param cause   cause of the exception
     */
    public AmbiguousConfigurationException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
