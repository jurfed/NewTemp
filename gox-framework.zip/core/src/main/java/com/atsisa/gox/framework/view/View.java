package com.atsisa.gox.framework.view;

import static java.lang.Integer.compare;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.model.IPropertyChangedListener;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.model.property.primitive.ExtendedIntViewProperty;
import com.atsisa.gox.framework.model.property.primitive.IViewProperty;
import com.atsisa.gox.framework.model.property.primitive.ViewFloatProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.rendering.IViewRenderer;
import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.SkinRefConverter;
import com.atsisa.gox.framework.serialization.converter.TagConverter;
import com.atsisa.gox.framework.utility.ITaggable;
import com.atsisa.gox.framework.utility.Rectangle;
import com.atsisa.gox.framework.utility.TagContainer;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * The View class is the base class for all objects that can be placed on stage.
 */
@XmlElement
@Reflect_Full
public abstract class View implements IPropertyChangedListener, Comparable<View>, ITaggable, IDisposable {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Unique identifier of the view.
     */
    private int uuid;

    /**
     * Id of View.
     */
    @XmlAttribute(type = String.class)
    private final ObservableProperty<String> id = new ObservableProperty<>(String.class);

    /**
     * Boolean value that indicates whether this view is visible or not.
     */
    @XmlAttribute(type = Boolean.class)
    private final ViewProperty<Boolean> visible = new ViewProperty<>(Boolean.class, this, ViewType.VIEW, ViewPropertyName.VISIBLE, true);

    /**
     * Float value that indicates alpha transparency of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty alpha = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.ALPHA, 1F);

    /**
     * Float value that indicates position x of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty x = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.X, 0F);

    /**
     * Float value that indicates position y of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty y = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.Y, 0F);

    /**
     * Float value that indicates width of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty width = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.WIDTH, 0F);

    /**
     * Float value that indicates height of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty height = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.HEIGHT, 0F);

    /**
     * Float value that indicates scale horizontal of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty scaleX = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.SCALE_X, 1F);

    /**
     * Float value that indicates scale vertical of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty scaleY = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.SCALE_Y, 1F);

    /**
     * The origin x position.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty originX = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.ORIGIN_X, 0F);

    /**
     * The origin y position.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty originY = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.ORIGIN_Y, 0F);

    /**
     * Float value that indicates rotation of the view.
     */
    @XmlAttribute(type = Float.class)
    private final ViewFloatProperty rotation = new ViewFloatProperty(this, ViewType.VIEW, ViewPropertyName.ROTATION, 0F);

    /**
     * Depth value that indicates depth of this view in parent container.
     */
    @XmlAttribute(type = Integer.class)
    private final ExtendedIntViewProperty depth = new ExtendedIntViewProperty(this, ViewType.VIEW, ViewPropertyName.DEPTH, 0);

    /**
     * Reference to skin, which is processed using skin converter.
     */
    @XmlAttribute(type = Skin.class, converters = SkinRefConverter.class, order = 0)
    private final ObservableProperty<Skin> skin = new ObservableProperty<>(Skin.class);

    /**
     * Mask shape for view.
     */
    @XmlElement(type = Rectangle.class)
    private final ViewProperty<Rectangle> mask = new ViewProperty<>(Rectangle.class, this, ViewType.VIEW, ViewPropertyName.MASK, null);

    /**
     * ViewGroup value that indicates parent of the view.
     */
    private final ViewProperty<ViewGroupBase> parent = new ViewProperty<>(ViewGroupBase.class, this, ViewType.VIEW, ViewPropertyName.PARENT);

    /**
     * A collection of tags.
     */
    @XmlAttribute(converters = TagConverter.class)
    private Iterable<String> tags;

    /**
     * Lists of objects that are listening for changes.
     */
    private List<IViewPropertyChangedListener> propertyChangedListeners;

    /**
     * IRenderer implementation.
     */
    private IRenderer renderer;

    /**
     * A tag container.
     */
    private final ITaggable tagContainer;

    /**
     * A value indicating whether the view was initialized or disposed.
     */
    private boolean initialized;

    /**
     * Reference to view layer for the purpose of render loop optimization.
     */
    private ILayer layer;

    /**
     * Reference to view renderer for the purpose of render loop optimization.
     */
    private IViewRenderer viewRenderer;

    /**
     * Initializes a new instance of the View class.
     */
    public View() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the View class.
     * @param renderer a rendering reference
     */
    public View(IRenderer renderer) {
        this.renderer = renderer;
        tagContainer = new TagContainer();
        uuid = renderer.generateNextSequentialNumber();
        propertyChangedListeners = new ArrayList<>();
        lv = new LocalVariables();
        viewRenderer = renderer.getViewRenderer(getClass());
    }

    /**
     * Draws current view using its corresponding view rendering.
     */
    public void redraw() {
        if (!initialized) {
            addPropertyChangedListener(renderer);
            init();
        }
        propertyChanged(ViewType.VIEW, ViewPropertyName.BASIC);
    }

    /**
     * Gets mask shape.
     * @return Rectangle
     */
    public Rectangle getMask() {
        return mask.get();
    }

    /**
     * Sets mask shape.
     * @param mask - Rectangle
     */
    public void setMask(Rectangle mask) {
        this.mask.set(mask);
    }

    /**
     * Sets depth value for this view.
     * @param value - int
     * @return this view reference
     */
    public View setDepth(int value) {
        depth.set(value);
        return this;
    }

    /**
     * Gets depth value.
     * @return int
     */
    public int getDepth() {
        return depth.getPrimitive();
    }

    /**
     * Gets the ViewGroup object that contains this view.
     * @return ViewGroup
     */
    public ViewGroupBase getParent() {
        return parent.get();
    }

    /**
     * Sets the ViewGroup object that contains this view.
     * @param newParent - ViewGroup
     * @return this view reference
     */
    public View setParent(ViewGroupBase newParent) {
        parent.set(newParent);
        return this;
    }

    /**
     * Gets the parent property.
     * @return parent property
     */
    public IObservableProperty<ViewGroupBase> parent() {
        return parent;
    }

    /**
     * Registers new property change listener.
     * @param listener - IPropertyChangeListener
     */
    public void addPropertyChangedListener(IViewPropertyChangedListener listener) {
        propertyChangedListeners.add(listener);
    }

    /**
     * Unregisters property change listener.
     * @param listener - IPropertyChangeListener
     * @return boolean - if "false" listener was not register to this view
     */
    public boolean removePropertyChangedListener(IViewPropertyChangedListener listener) {
        return propertyChangedListeners.remove(listener);
    }

    /**
     * Gets the origin x position from the transformation matrix.
     * @return the origin x position
     */
    public float getOriginX() {
        return originX.getPrimitive();
    }

    /**
     * Gets the origin x position and puts it into the transformation matrix.
     * @param value the origin x position
     * @return this view reference
     */
    public View setOriginX(float value) {
        originX.set(value);
        return this;
    }

    /**
     * Gets the origin y position from the transformation matrix.
     * @return the origin y position
     */
    public float getOriginY() {
        return originY.getPrimitive();
    }

    /**
     * Gets the origin y position and puts it into the transformation matrix.
     * @param value the origin y position
     * @return this view reference
     */
    public View setOriginY(float value) {
        originY.set(value);
        return this;
    }

    /**
     * Gets the rotation of the View instance, in degrees, from its original orientation.
     * @return float
     */
    public float getRotation() {
        return rotation.getPrimitive();
    }

    /**
     * Sets the rotation of the View instance, in degrees, from its original orientation.
     * @param value - float
     * @return this view reference
     */
    public View setRotation(float value) {
        rotation.set(value);
        return this;
    }

    /**
     * Gets the width of the view, in pixels.
     * @return float
     */
    public float getWidth() {
        return width.getPrimitive();
    }

    /**
     * Sets the width of the view, in pixels.
     * @param value - float
     * @return this view reference
     */
    public View setWidth(float value) {
        width.set(value);
        return this;
    }

    /**
     * Gets the horizontal scale (percentage) of an view.
     * @return float
     */
    public float getScaleX() {
        return scaleX.getPrimitive();
    }

    /**
     * Sets the horizontal scale (percentage) of an view.
     * @param value - float
     * @return this view reference
     */
    public View setScaleX(float value) {
        scaleX.set(value);
        return this;
    }

    /**
     * Gets the vertical scale (percentage) of an view.
     * @return float
     */
    public float getScaleY() {
        return scaleY.getPrimitive();
    }

    /**
     * Sets the vertical scale (percentage) of an view.
     * @param value - float
     * @return this view reference
     */
    public View setScaleY(float value) {
        scaleY.set(value);
        return this;
    }

    /**
     * Gets the height of the view, in pixels.
     * @return float
     */
    public float getHeight() {
        return height.getPrimitive();
    }

    /**
     * Sets the height of the view, in pixels.
     * @param value - float
     * @return this view reference
     */
    public View setHeight(float value) {
        height.set(value);
        return this;
    }

    /**
     * Gets the offset width of the view.
     * @return offset width of the view
     */
    public float getOffsetWidth() {
        return getWidth();
    }

    /**
     * Gets the offset height of the view.
     * @return offset height of the view
     */
    public float getOffsetHeight() {
        return getHeight();
    }

    /**
     * Gets id of the view.
     * @return String
     */
    public String getId() {
        return id.get();
    }

    /**
     * Sets id of the view.
     * @param value - String
     * @return this view reference
     */
    public View setId(String value) {
        id.set(value);
        return this;
    }

    /**
     * Gets whether the view is visible or not.
     * @return boolean
     */
    public boolean isVisible() {
        return visible.get();
    }

    /**
     * Sets whether the view is visible or not.
     * @param value - boolean
     * @return this view reference
     */
    public View setVisible(boolean value) {
        visible.set(value);
        return this;
    }

    /**
     * Sets the alpha transparency value of the object specified.
     * @param value - float
     * @return this view reference
     */
    public View setAlpha(float value) {
        alpha.set(value);
        return this;
    }

    /**
     * Gets the alpha transparency value of the object specified.
     * @return float
     */
    public float getAlpha() {
        return alpha.getPrimitive();
    }

    /**
     * Gets the x coordinate of the View instance relative to the local coordinates of the parent ViewGroup.
     * @return float
     */
    public float getX() {
        return x.getPrimitive();
    }

    /**
     * Sets the x coordinate of the View instance relative to the local coordinates of the parent ViewGroup.
     * @param value - float
     * @return this view reference
     */
    public View setX(float value) {
        x.set(value);
        return this;
    }

    /**
     * Gets the y coordinate of the View instance relative to the local coordinates of the parent ViewGroup.
     * @return float
     */
    public float getY() {
        return y.getPrimitive();
    }

    /**
     * Sets the y coordinate of the View instance relative to the local coordinates of the parent ViewGroup.
     * @param value - float
     * @return this view reference
     */
    public View setY(float value) {
        y.set(value);
        return this;
    }

    /**
     * Gets skin.
     * @return reference to the skin
     */
    public Skin getSkin() {
        return skin.get();
    }

    /**
     * Sets skin.
     * @param skin {@link Skin}
     */
    public void setSkin(Skin skin) {
        View view = skin.getView();
        if (visible.hasDefaultValue()) {
            visible.set(view.isVisible());
        }
        if (alpha.hasDefaultValue()) {
            alpha.set(view.getAlpha());
        }
        if (x.hasDefaultValue()) {
            x.set(view.getX());
        }
        if (y.hasDefaultValue()) {
            y.set(view.getY());
        }
        if (width.hasDefaultValue()) {
            width.set(view.getWidth());
        }
        if (height.hasDefaultValue()) {
            height.set(view.getHeight());
        }
        if (scaleX.hasDefaultValue()) {
            scaleX.set(view.getScaleX());
        }
        if (scaleY.hasDefaultValue()) {
            scaleY.set(view.getScaleY());
        }
        if (rotation.hasDefaultValue()) {
            rotation.set(view.getRotation());
        }
        if (depth.hasDefaultValue()) {
            depth.set(view.getDepth());
        }
        for (String tag : view.getTags()) {
            addTag(tag);
        }
        this.skin.set(skin);
    }

    /**
     * Gets position absolute x in game.
     * @return float
     */
    public float getAbsoluteX() {
        float absoluteX = getX() + getOriginX();
        View parent = getParent();
        while (parent != null) {
            absoluteX += parent.getX() + parent.getOriginX();
            parent = parent.getParent();
        }
        return absoluteX;
    }

    /**
     * Gets position absolute y in game.
     * @return float
     */
    public float getAbsoluteY() {
        float absoluteY = getY() + getOriginY();
        View parent = getParent();
        while (parent != null) {
            absoluteY += parent.getY() + parent.getOriginY();
            parent = parent.getParent();
        }
        return absoluteY;
    }

    /**
     * Removes view from stage and from rendering's memory.
     */
    @Override
    public void dispose() {
        clear();
        propertyChangedListeners.clear();
    }

    public void clear() {
        if (initialized) {
            removePropertyChangedListener(renderer);
            renderer.dispose(this);
            layer = null;
            initialized = false;
        }
    }

    /**
     * Gets a value indicating whether this view has been initialized.
     * @return a value indicating whether this view has been initialized.
     */
    public boolean isInitialized() {
        return initialized;
    }

    @Override
    public void propertyChanged(IObservableProperty source, Object oldValue, Object newValue) {
        if (source instanceof IViewProperty) {
            propertyChanged(((IViewProperty) source).getViewType(), ((IViewProperty) source).getViewPropertyName());
        }
    }

    /**
     * Gets IRenderer implementation.
     * @return IRenderer
     */
    protected IRenderer getRenderer() {
        return renderer;
    }

    /**
     * Triggers on all property change listeners that something has been changed.
     * @param viewType - long
     * @param property - long
     */
    public void propertyChanged(final ViewType viewType, final int property) {
        if (initialized) {
            lv.size = propertyChangedListeners.size();
            for (lv.index = 0; lv.index < lv.size; lv.index++) {
                propertyChangedListeners.get(lv.index).propertyChanged(this, viewType, property);
            }
        }
    }

    /**
     * Gets the id property.
     * @return the id property
     */
    public IObservableProperty<String> id() {
        return id;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty<Boolean> visible() {
        return visible;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty alpha() {
        return alpha;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty x() {
        return x;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty y() {
        return y;
    }

    /**
     * Gets the mask property.
     * @return the mask property
     */
    public ViewProperty<Rectangle> mask() {
        return mask;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty width() {
        return width;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty height() {
        return height;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty scaleX() {
        return scaleX;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty scaleY() {
        return scaleY;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty originX() {
        return originX;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty originY() {
        return originY;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty rotation() {
        return rotation;
    }

    /**
     * Gets the depth property.
     * @return the depth property
     */
    public ExtendedIntViewProperty depth() {
        return depth;
    }

    /**
     * Gets the visible property.
     * @return the visible property
     */
    public IObservableProperty<Skin> skin() {
        return skin;
    }

    @Override
    public void setTags(Iterable<String> classNames) {
        tagContainer.setTags(classNames);
        propertyChanged(ViewType.VIEW, ViewPropertyName.TAGS);
    }

    /**
     * Gets game instance wide unique identifier of this view.
     * @return int view unique identifier
     */
    public int getUuid() {
        return uuid;
    }

    @Override
    public Iterable<String> getTags() {
        return tagContainer.getTags();
    }

    @Override
    public boolean hasTag(String className) {
        return tagContainer.hasTag(className);
    }

    @Override
    public boolean addTag(String className) {
        if (tagContainer.addTag(className)) {
            propertyChanged(ViewType.VIEW, ViewPropertyName.TAGS);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeTag(String className) {
        if (tagContainer.removeTag(className)) {
            propertyChanged(ViewType.VIEW, ViewPropertyName.TAGS);
            return true;
        }
        return false;
    }

    @Override
    public boolean hasTags() {
        return tagContainer.hasTags();
    }

    /**
     * Initializes the view on a first redraw call.
     */
    protected void init() {
        if (viewRenderer != null) {
            layer = viewRenderer.registerView(this);
        }
        initialized = true;
    }

    /**
     * Gets rendering layer associated with the view. This was introduced for the performance purpose.
     * @return ILayer
     */
    public ILayer getLayer() {
        return layer;
    }

    /**
     * Gets view renderer associated with the view. This was introduced for the performance purpose.
     * @return IViewRenderer
     */
    public IViewRenderer getViewRenderer() {
        return viewRenderer;
    }

    @Override
    public int compareTo(View view) {
        return compare(getDepth(), view.getDepth());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        View view = (View) o;
        return uuid == view.uuid;
    }

    @Override
    public int hashCode() {
        return uuid;
    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getX setMethod.
         */
        public static final int X = 1;

        /**
         * Represents a view property accessible via getY setMethod.
         */
        public static final int Y = 1 << 1;

        /**
         * Represents a view property accessible via getWidth setMethod.
         */
        public static final int WIDTH = 1 << 2;

        /**
         * Represents a view property accessible via getHeight setMethod.
         */
        public static final int HEIGHT = 1 << 3;

        /**
         * Represents a view property accessible via getScaleX setMethod.
         */
        public static final int SCALE_X = 1 << 4;

        /**
         * Represents a view property accessible via getScaleY setMethod.
         */
        public static final int SCALE_Y = 1 << 5;

        /**
         * Represents a view property accessible via getRotation setMethod.
         */
        public static final int ROTATION = 1 << 6;

        /**
         * Represents a view property accessible via isVisible setMethod.
         */
        public static final int VISIBLE = 1 << 7;

        /**
         * Represents a view property accessible via getAlpha setMethod.
         */
        public static final int ALPHA = 1 << 8;

        /**
         * Represents a parent view changes.
         */
        public static final int PARENT = 1 << 9;

        /**
         * Represents a view property accessible via getDepth setMethod.
         */
        public static final int DEPTH = 1 << 10;

        /**
         * Represents a view property accessible via getOriginX setMethod.
         */
        public static final int ORIGIN_X = 1 << 11;

        /**
         * Represents a view property accessible via getOriginY setMethod.
         */
        public static final int ORIGIN_Y = 1 << 12;

        /**
         * Represents a view property accessible via getMask setMethod.
         */
        public static final int MASK = 1 << 13;

        /**
         * Represents a property accessible via get getTags method.
         */
        public static final int TAGS = 1 << 14;

        /**
         * Represents all basic properties to redraw.
         */
        public static final int BASIC = (1 << 15) - 1;

        /**
         * Represents all properties (Integer.MAX_VALUE)
         */
        public static final int ALL = Integer.MAX_VALUE;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

    /**
     * Holder for instances of local variables used in the {@link View} methods.
     */
    class LocalVariables {

        private int index;

        private int size;
    }
}
