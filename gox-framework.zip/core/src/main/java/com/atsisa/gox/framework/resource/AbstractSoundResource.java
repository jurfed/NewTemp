package com.atsisa.gox.framework.resource;

/**
 * Abstract audio resources class.
 */
public abstract class AbstractSoundResource<T extends ISoundObjectWrapper> extends AbstractResource {

    /**
     * Array containing supported extensions of the files.
     */
    public static final String[] SUPPORTED_EXTENSIONS = { ".mp3" };

    /**
     * Represents Sound object.
     */
    private T sound;

    /**
     * Creates resource object with given description and assets handler.
     * @param description resource description object
     */
    public AbstractSoundResource(ResourceDescription description) {
        super(description, ResourceType.SOUND);
    }

    /**
     * Gets sound wrapper object.
     * @return ISoundObjectWrapper
     */
    public T getSound() {
        return sound;
    }

    @Override
    public String[] getSupportedExtensions() {
        return SUPPORTED_EXTENSIONS;
    }

    /**
     * Sets sound wrapper object.
     * @param sound - ISoundObjectWrapper
     */
    protected void setSound(T sound) {
        this.sound = sound;
    }

}
