package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.GameEngine;

/**
 * Layout resource class.
 */
public class LayoutResource extends XmlResource {

    /**
     * Creates resource object with given description.
     * @param description resource description object
     */
    public LayoutResource(ResourceDescription description) {
        this(description, GameEngine.current().getResourceManager().getResourceFactory());
    }

    /**
     * Creates resource object with given description and resource factory.
     * @param description     resource description object
     * @param resourceFactory resource factory
     */
    public LayoutResource(ResourceDescription description, IResourceFactory resourceFactory) {
        super(description, ResourceType.LAYOUT, resourceFactory);
    }

}
