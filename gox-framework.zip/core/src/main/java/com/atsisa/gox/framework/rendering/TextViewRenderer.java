package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ITextLayer;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Text view rendering class.
 */
public class TextViewRenderer extends InteractiveViewRenderer implements ITextRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * The font registry.
     */
    private final IFontRegistry fontRegistry;

    /**
     * Initializes a new instance of the LibGdxTextViewRenderer class using custom rendering.
     * @param renderer     rendering reference
     * @param fontRegistry font registry.
     */
    public TextViewRenderer(IRenderer renderer, IFontRegistry fontRegistry) {
        super(renderer);
        this.fontRegistry = fontRegistry;
        lv = new LocalVariables();
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = super.render(view, viewType, changes);
        if (viewType == ViewType.TEXT_VIEW) {
            lv.layer = (ITextLayer) getContent(view);
            lv.textView = (TextView) view;
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.FONT_NAME)) {
                IFontReference font = fontRegistry.getFont(lv.textView.getFontName());
                lv.layer.setFontReference(font);
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.FONT_NAME);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.HALIGN)) {
                lv.layer.setHAlign(((TextView) view).getHalign());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.HALIGN);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.FONT_SIZE)) {
                lv.layer.setFontSize(((TextView) view).getFontSize());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.FONT_SIZE);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.VALIGN)) {
                lv.layer.setVAlign(((TextView) view).getValign());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.VALIGN);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.TEXT)) {
                lv.layer.setText(((TextView) view).getText());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.TEXT);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.SCALE_AUTO_WIDTH)) {
                lv.layer.setScaleAutoWidth(((TextView) view).getScaleAutoWidth());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.SCALE_AUTO_WIDTH);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.WORD_WRAP)) {
                lv.layer.setWordWrap(((TextView) view).getWordWrap());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.WORD_WRAP);
            }
            if (BitUtility.isSet(lv.leftChanges, TextView.ViewPropertyName.COLOR)) {
                lv.layer.setFontColor(lv.textView.color().get());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, TextView.ViewPropertyName.COLOR);
            }
            lv.layer.update(changes);
        }

        return lv.leftChanges;
    }

    @Override
    public Class<?> getType() {
        return TextView.class;
    }

    @Override
    public float getTextWidth(View view) {
        return ((ITextLayer) getContent(view)).getTextWidth();
    }

    @Override
    public float getTextHeight(View view) {
        return ((ITextLayer) getContent(view)).getTextHeight();
    }

    /**
     * Creates and returns new ITextLayer platform specific implementation.
     * @param view - View
     * @return ITextLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected ITextLayer createLayer(View view) {
        return getLayerFactory().createTextLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link TextViewRenderer} render method.
     */
    private class LocalVariables {

        private ITextLayer layer;

        private TextView textView;

        private int leftChanges;
    }
}
