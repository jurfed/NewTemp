package com.atsisa.gox.framework.view;

import java.util.List;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ListViewProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.atsisa.gox.framework.utility.IPointsHolder;
import com.atsisa.gox.framework.utility.MathUtility;
import com.atsisa.gox.framework.utility.Point;
import com.atsisa.gox.framework.utility.Rectangle;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Class describes the line shape.
 */
@XmlElement
@Reflect_Full
public class LineShapeView extends AbstractShape implements IPointsHolder {

    /**
     * LineShapeView property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a line shape view property accessible via getPointsList setMethod.
         */
        public static final int POINTS = 1;

        /**
         * Represents a line shape view property accessible via getColor setMethod.
         */
        public static final int COLOR = 1 << 1;

        /**
         * Represents a line shape view property accessible via getThickness setMethod.
         */
        public static final int THICKNESS = 1 << 2;

        /**
         * Represents a line shape view property accessible via getClearAreaList setMethod.
         */
        public static final int CLEAR_AREA = 1 << 3;
    }

    /**
     * Default line color.
     */
    public static final int DEFAULT_COLOR = 0x000000;

    /**
     * Area list where line should not be drawn.
     */
    private final ListViewProperty<Rectangle> clearAreaList = new ListViewProperty<>(this, ViewType.LINE_SHAPE_VIEW, ViewPropertyName.CLEAR_AREA);

    /**
     * Point list, used to draw basic line shape.
     */
    @XmlCollectionElement(itemName = "point", itemType = Point.class, name = "points")
    private final ListViewProperty<Point> points = new ListViewProperty<>(this, ViewType.LINE_SHAPE_VIEW, ViewPropertyName.POINTS);

    /**
     * Line color.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> color = new ViewProperty<>(Integer.class, this, ViewType.LINE_SHAPE_VIEW, ViewPropertyName.COLOR, DEFAULT_COLOR);

    /**
     * Line thickness.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> thickness = new ViewProperty<>(Integer.class, this, ViewType.LINE_SHAPE_VIEW, ViewPropertyName.THICKNESS, 1);

    /**
     * Initializes a new instance of the LineShapeView class.
     */
    public LineShapeView() {
    }

    /**
     * Initializes a new instance of the LineShapeView class.
     * @param renderer {@link IRenderer}
     */
    public LineShapeView(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Gets line color.
     * @return int
     */
    public int getColor() {
        return color.get();
    }

    /**
     * Sets line color.
     * @param color - int
     */
    public void setColor(int color) {
        this.color.set(color);
    }

    /**
     * Gets the color property.
     * @return the color property
     */
    public IObservableProperty<Integer> color() {
        return color;
    }

    /**
     * Gets line thickness.
     * @return int
     */
    public int getThickness() {
        return thickness.get();
    }

    /**
     * Sets line thickness.
     * @param thickness - int
     */
    public void setThickness(int thickness) {
        this.thickness.set(thickness);
        updateWidth();
        updateHeight();
    }

    /**
     * Gets the thickness property.
     * @return the thickness property
     */
    public IObservableProperty<Integer> thickness() {
        return thickness;
    }

    /**
     * Gets point list, which are used to draw line shape.
     * @return List of Point
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<Point> getPoints() {
        return points.get();
    }

    /**
     * Sets point list, which are used to draw line shape.
     * @param points List of Point
     */
    @Override
    public void setPoints(List<Point> points) {
        this.points.set(points);
        updateWidth();
        updateHeight();
    }

    /**
     * Gets the point list property.
     * @return point list property
     */
    public IObservableProperty<List> points() {
        return points;
    }

    /**
     * Adds point to line.
     * @param point - Point
     */
    public void addPoint(Point point) {
        if (point != null) {
            getPoints().add(point);
            updateWidth();
            updateHeight();
            propertyChanged(ViewType.LINE_SHAPE_VIEW, ViewPropertyName.POINTS);
        }
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        LineShapeView lineShapeView = (LineShapeView) skin.getView();
        if (thickness.hasDefaultValue()) {
            setThickness(lineShapeView.getThickness());
        }
        if (color.hasDefaultValue()) {
            setColor(lineShapeView.getColor());
        }
        if (points.hasDefaultValue()) {
            setPoints(lineShapeView.getPoints());
        }
    }

    /**
     * Clears all lines.
     */
    @Override
    public void clear() {
        if (getPoints() != null) {
            getPoints().clear();
        }
        removeAllClearArea();
        super.clear();
    }

    /**
     * Removes all clear area from line.
     */
    public void removeAllClearArea() {
        propertyChanged(ViewType.LINE_SHAPE_VIEW, ViewPropertyName.CLEAR_AREA);
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.LINE_SHAPE_VIEW, ViewPropertyName.POINTS | ViewPropertyName.CLEAR_AREA | ViewPropertyName.COLOR | ViewPropertyName.THICKNESS);
    }

    /**
     * Clears specific area.
     * @param rectangle - Rectangle
     */
    public void addClearRect(Rectangle rectangle) {
        getClearAreaList().add(rectangle);
        propertyChanged(ViewType.LINE_SHAPE_VIEW, ViewPropertyName.CLEAR_AREA);
    }

    /**
     * Gets area list where line should not be drawn.
     * @return area list where line should not be drawn
     */
    @SuppressWarnings("unchecked")
    public List<Rectangle> getClearAreaList() {
        return clearAreaList.get();
    }

    /**
     * Updates width according to the points.
     */
    private void updateWidth() {
        float width = getThickness();
        float posX = 0;
        for (Point point : getPoints()) {
            if (point.getX() > posX + width) {
                width = Math.abs(posX) + point.getX();
            }
            if (point.getX() < posX) {
                width += MathUtility.distance(point.getX(), 0, posX, 0);
                posX = point.getX();
            }
        }
        setWidth(width);
    }

    /**
     * Updates height according to the points.
     */
    private void updateHeight() {
        float height = getThickness();
        float posY = 0;
        for (Point point : getPoints()) {
            if (point.getY() > posY + height) {
                height = Math.abs(posY) + point.getY();
            }
            if (point.getY() < posY) {
                height += MathUtility.distance(0, point.getY(), 0, posY);
                posY = point.getY();
            }
        }
        setHeight(height);
    }
}
