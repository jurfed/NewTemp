package com.atsisa.gox.framework.serialization.converter;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.view.View;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Responsible for converting view collections to an instance extends the
 * {@link View} class.
 */
@Reflect_Mini
public class ViewCollectionConverter implements IValueConverter {

    /**
     * The view builder.
     */
    private final IViewBuilder viewBuilder;

    /**
     * Initializes a new instance of the
     * {@link ViewCollectionConverter} class.
     */
    public ViewCollectionConverter() {
        this(GameEngine.current().getViewManager().getViewBuilder());
    }

    /**
     * Initializes a new instance of the
     * {@link ViewCollectionConverter} class.
     * @param viewBuilder The view builder.
     */
    public ViewCollectionConverter(IViewBuilder viewBuilder) {
        this.viewBuilder = viewBuilder;
    }

    @Override
    public Class<?> getValueType() {
        return View.class;
    }

    @Override
    public String convertTo(Object objToConvert) throws ConversionException {
        throw new UnsupportedOperationException("Not implemented!");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (serializedMessage == null || parsedObject == null) {
            return null;
        }
        List<View> views = new ArrayList<>();
        List<XmlObject> xmlChildren = ((XmlObject) parsedObject).getChildren();
        for (XmlObject childXmlObject : xmlChildren) {
            try {
                View view = viewBuilder.createView(childXmlObject, true);
                views.add(view);
            } catch (Exception ex) {
                throw new ConversionException(ex.getMessage(), ex);
            }
        }
        return views;
    }
}
