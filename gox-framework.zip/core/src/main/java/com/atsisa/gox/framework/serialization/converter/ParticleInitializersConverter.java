package com.atsisa.gox.framework.serialization.converter;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * Particle initializer list converter.
 */
@Reflectable(methods = false, fields = false)
public class ParticleInitializersConverter implements IValueConverter {

    /**
     * Comma separated values converter.
     */
    private final CsvConverter csvConverter = new CsvConverter();

    /**
     * Hex color converter.
     */
    private final HexColorConverter hexColorConverter = new HexColorConverter();

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of the ParticleEffectorsConverter class.
     */
    public ParticleInitializersConverter() {
        logger = GameEngine.current().getLogger();
    }

    /**
     * Initializes a new instance of the ParticleEffectorsConverter class.
     * @param logger custom logger
     */
    public ParticleInitializersConverter(ILogger logger) {
        this.logger = logger;
    }

    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException("Not implemented!");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        XmlObject xmlObject;
        if (parsedObject instanceof XmlObject) {
            xmlObject = (XmlObject) parsedObject;
        } else if (parsedObject instanceof XmlObjectDocument) {
            xmlObject = ((XmlObjectDocument) parsedObject).getDocumentElement();
        } else {
            throw new IllegalArgumentException("Failed to convert parsedObject");
        }

       /* List<Initializer> initializerList = new ArrayList<Initializer>();
        for (XmlObject child : xmlObject.getChildren()) {
            if (child.getName().equals("lifespan")) {
                addInitializerToList(this.getLifespanInitializer(child), initializerList);
            } else if (child.getName().equals("color")) {
                addInitializerToList(this.getColorInitializer(child), initializerList);
            } else if (child.getName().equals("transform")) {
                addInitializerToList(this.getTransformInitializer(child), initializerList);
            } else if (child.getName().equals("velocity")) {
                addInitializerToList(this.getVelocityInitializer(child), initializerList);
            }
        }
        return initializerList;*/
        return new Object();
    }

    /**
     * Gets a velocity initializer.
     * @param element velocity xml element
     * @return velocity initializer
     */
    /*private Initializer getVelocityInitializer(XmlObject element) {
        String type = element.getAttribute("type");
        try {
            if (type != null) {
                if (type.equals("constant")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", 2);
                    if (values != null) {
                        return Velocity.constant(new Vector(values[0], values[1]));
                    }
                } else if (type.equals("increment")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", 2);
                    if (values != null) {
                        return Velocity.increment(values[0], values[1]);
                    }
                } else if (type.equals("randomCircle")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", null);
                    if (values != null) {
                        if (values.length == 2) {
                            return Velocity.randomCircle(ParticleView.RANDOMS, values[0], values[1]);
                        } else if (values.length == 1) {
                            return Velocity.randomCircle(ParticleView.RANDOMS, values[0]);
                        }
                    }
                } else if (type.equals("randomNormal")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", null);
                    if (values != null) {
                        if (values.length == 4) {
                            return Velocity.randomNormal(ParticleView.RANDOMS, values[0], values[1], values[2], values[3]);
                        } else if (values.length == 2) {
                            return Velocity.randomNormal(ParticleView.RANDOMS, values[0], values[1]);
                        }
                    }
                } else if (type.equals("randomSquare")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", null);
                    if (values != null) {
                        if (values.length == 4) {
                            return Velocity.randomSquare(ParticleView.RANDOMS, values[0], values[1], values[2], values[3]);
                        } else if (values.length == 2) {
                            return Velocity.randomSquare(ParticleView.RANDOMS, values[0], values[1]);
                        }
                    }
                }
                throw new Exception(StringUtility.format("Invalid transform value for type '%s'", type));
            }
            throw new Exception(StringUtility.format("Invalid transform type '%s'", type));
        } catch (Exception ex) {
            this.logger.warn("ParticleInitializersConverter | getTransformInitializer | An error occurred", ex);
            return null;
        }
    }*/

    /**
     * Gets a transform initializer.
     * @param element transform xml element
     * @return transform initializer
     */
    /*private Initializer getTransformInitializer(XmlObject element) {
        String type = element.getAttribute("type");
        try {
            if (type != null) {
                if (type.equals("identity")) {
                    return Transform.identity();
                } else if (type.equals("constant")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", null);
                    if (values != null) {
                        if (values.length == 4) {
                            return Transform.constant(values[0], values[1], values[2], values[3]);
                        } else if (values.length == 2) {
                            return Transform.constant(values[0], values[1]);
                        }
                    }
                } else if (type.equals("randomOffset")) {
                    float offset = element.getFloatAttribute("value", 0);
                    return (offset != 0) ? Transform.randomOffset(ParticleView.RANDOMS, offset) : null;
                } else if (type.equals("randomPosition")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", 4);
                    if (values != null) {
                        return Transform.randomPos(ParticleView.RANDOMS, values[0], values[1], values[2], values[3]);
                    }
                } else if (type.equals("randomScale")) {
                    Float[] values = this.getAttributeAsFloatArray(element, "value", 2);
                    if (values != null) {
                        return Transform.randomScale(ParticleView.RANDOMS, values[0], values[1]);
                    }
                } else if (type.equals("scale")) {
                    float scale = element.getFloatAttribute("value", 1);
                    return (scale != 1) ? Transform.scale(scale) : null;
                }
                throw new Exception(StringUtility.format("Invalid transform value for type '%s'", type));
            }
            throw new Exception(StringUtility.format("Invalid transform type '%s'", type));
        } catch (Exception ex) {
            this.logger.warn("ParticleInitializersConverter | getTransformInitializer | '%s'", ex.getMessage());
            return null;
        }
    }*/

    /**
     * Gets a color initializer.
     * @param element color xml element
     * @return color initializer
     */
    /*private Initializer getColorInitializer(XmlObject element) {
        String colorStr = element.getAttribute("value");
        Integer color = (Integer) this.hexColorConverter.convertFrom(colorStr, null);
        if (color == null) {
            color = ParticleView.DEFAULT_COLOR;
        }
        return Color.constant(color);
    }*/

    /**
     * Gets a lifespan initializer.
     * @param element lifespan xml element
     * @return lifespan initializer
     */
    /*private Initializer getLifespanInitializer(XmlObject element) {
        String type = element.getAttribute("type", "constant");

        if (type.equals("constant")) {
            float lifespan = element.getFloatAttribute("value", ParticleView.DEFAULT_LIFESPAN);
            return Lifespan.constant(lifespan);
        } else if (type.equals("random")) {
            Float[] values = this.getAttributeAsFloatArray(element, "value", 2);
            if (values != null) {
                return Lifespan.random(ParticleView.RANDOMS, values[0], values[1]);
            } else {
                this.logger.warn("ParticleInitializersConverter | getLifespanInitializer | Invalid lifespan value.");
                return null;
            }
        } else {
            this.logger.warn("ParticleInitializersConverter | getLifespanInitializer | Invalid lifespan type '%s'", type);
            return null;
        }
    }*/

    /**
     * Adds an initializer to the initializerList if it is not null.
     * @param initializer initializer to add
     * @param initializerList list the initializer should be added to
     */
    /*private void addInitializerToList(Initializer initializer, List<Initializer> initializerList) {
        if (initializer != null) {
            initializerList.add(initializer);
        }
    }*/

    /**
     * Gets a comma separated attribute value as a float array.
     * @param element       element to process
     * @param attributeName attribute name to fetch
     * @param exactAmount   expected the exect amount of floats, put null if you want an array of any length
     * @return a float array
     */
    @SuppressWarnings("unchecked")
    private Float[] getAttributeAsFloatArray(XmlObject element, String attributeName, Integer exactAmount) {
        String rawValue = element.getAttribute(attributeName);
        List<String> values = (List<String>) csvConverter.convertFrom(rawValue, null);
        if (exactAmount != null && values != null && values.size() != exactAmount) {
            return null;
        }
        if (values != null) {
            Float[] floats = new Float[exactAmount != null ? exactAmount : values.size()];
            int i = 0;
            for (String val : values) {
                floats[i++] = Float.parseFloat(val);
            }
            return floats;
        }
        return null;
    }
}
