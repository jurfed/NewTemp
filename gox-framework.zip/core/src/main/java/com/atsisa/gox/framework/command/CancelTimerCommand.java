package com.atsisa.gox.framework.command;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * A command which result in canceling existing Timer component.
 */
@Reflect_Mini
public class CancelTimerCommand {

    /**
     * The timer name.
     */
    private final String timerName;

    /**
     * Initializes a new instance of the {@link CancelTimerCommand} class.
     * @param timerName The timer name.
     */
    public CancelTimerCommand(String timerName) {
        this.timerName = timerName;
    }

    /**
     * Gets the name of the timer.
     * @return the timer name.
     */
    public String getTimerName() {
        return timerName;
    }
}
