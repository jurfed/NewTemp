package com.atsisa.gox.framework.infrastructure;

import java.util.Collection;
import java.util.List;

import com.atsisa.gox.framework.model.ILayout;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;

/**
 * View manager interface exposes methods for multiple views handling.
 */
public interface IViewManager {

    /**
     * Gets the view builder used for adding layouts.
     * @return a view builder implementation
     */
    IViewBuilder getViewBuilder();

    /**
     * Gets skin manager implementation used for managing skins.
     * @return skin manager implementation
     */
    ISkinManager getSkinManager();

    /**
     * Initializes the view manager by registering all the layouts from the resources.
     */
    void registerLayoutsFromResources();

    /**
     * Gets the layout object from the cache using given layout identifier.
     * @param layoutId layout identifier
     * @return matched layout
     */
    ILayout getLayout(String layoutId);

    /**
     * Gets a collection of all layouts.
     * @return a collection of all layouts
     */
    Collection<ILayout> getAllLayouts();

    /**
     * Registers the layout by associating the layout identifier with its corresponding text resource.
     * @param layoutId    layout identifier
     * @param xmlResource corresponding xml resource
     * @return true if operation succeeded, false otherwise
     */
    boolean registerLayout(String layoutId, XmlResource xmlResource);

    /**
     * Registers the layout by associating the layout identifier with its corresponding root view.
     * @param layoutId layout identifier
     * @param rootView corresponding root view
     * @return true if operation succeeded, false otherwise
     */
    boolean registerLayout(String layoutId, View rootView);

    /**
     * Unregisters the layout by deleting the association between the layout identifier and its resource.
     * It also removes built layout from the cache if it was created.
     * @param layoutId layout identifier
     * @return true if operation succeeded, false otherwise
     */
    boolean unregisterLayout(String layoutId);

    /**
     * Builds a layout a puts it in a view manager cache. This setMethod uses the view builder to create
     * views hierarchy from a text resource. Once the layout has been build
     * it can be added to the stage using addLayout setMethod
     * @param layoutId layout identifier
     * @return true if operation succeeded, false otherwise
     */
    boolean buildLayout(String layoutId);

    /**
     * Builds all registered layouts.
     */
    void buildAllLayouts();

    /**
     * Removes a layout from a view manager cache. This setMethod reverts the buildLayout setMethod.
     * @param layoutId layout identifier
     * @return true if operation succeeded, false otherwise
     */
    boolean destroyLayout(String layoutId);

    /**
     * Adds a layout to the main stage view. This setMethod uses buildLayout setMethod if the layout has not
     * been built yet. Once the layout has been added it is stored and accessible via findViewById methods
     * until removeLayout, destroyLayout or unregisterLayout is called.
     * @param layoutId layout identifier
     * @return true if operation succeeded, false otherwise
     */
    boolean addLayout(String layoutId);

    /**
     * Checks if a particular layout has been added to the stage.
     * @param layoutId layout identifier to check
     * @return true it the layout is on stage, false otherwise
     */
    boolean isLayoutOnStage(String layoutId);

    /**
     * Removes a layout from view manager cache. This setMethod cleans up views hierarchy created by the view builder.
     * @param layoutId layout identifier to clean
     * @return true if operation succeeded, false otherwise
     */
    boolean removeLayout(String layoutId);

    /**
     * Finds all views within every built layout matching given view identifier.
     * @param viewId view identifier to match
     * @param <T>    type of interface
     * @return a list of all views that match given view identifier
     */
    <T extends View> List<T> findViewById(String viewId);

    /**
     * Finds the first view that matches given view identifier within selected layout.
     * @param layoutId layout identifier to check
     * @param viewId   view identifier to match
     * @param <T>      type of interface
     * @return firstly found view within given layout that matches the viewId
     */
    <T extends View> T findViewById(String layoutId, String viewId);

    /**
     * Finds the first view that matches given view identifier within selected view.
     * @param rootView root view to check
     * @param viewId   view identifier to match
     * @param <T>      type of interface
     * @return firstly found view within given  root view that matches the viewId
     */
    <T extends View> T findViewById(View rootView, String viewId);

    /**
     * Finds all views within every built layout matching given view type.
     * @param viewType view type to match
     * @param <T>      type of interface
     * @return a list of all views that match given view type
     */
    <T extends View> List<T> findViewByType(Class<T> viewType);

    /**
     * Finds all views that matches given view type within selected layout.
     * @param layoutId layout identifier to check
     * @param viewType view type to match
     * @param <T>      type of interface
     * @return a list of all views within given layout that match the viewType
     */
    <T extends View> List<T> findViewByType(String layoutId, Class<T> viewType);

    /**
     * Finds all views that matches given view type within selected view.
     * @param rootView root view to check
     * @param viewType view type to match
     * @param <T>      type of interface
     * @return a list of all views within given root view that match the viewType
     */
    <T extends View> List<T> findViewByType(View rootView, Class<T> viewType);

    /**
     * Finds all views inheriting from given type within selected view.
     * @param layoutId layout identifier to check
     * @param viewType view type to match
     * @return list of all views inheriting from given type
     */
    List<? extends View> findViewInheritingType(String layoutId, Class<? extends View> viewType);

    /**
     * Finds all views inheriting from given type within selected view.
     * @param rootView - root view to check
     * @param viewType - view type to match
     * @return list of all views inheriting from given type
     */
    List<? extends View> findViewInheritingType(View rootView, Class<? extends View> viewType);

    /**
     * Finds all views inheriting from given type.
     * @param viewType - view type to match
     * @return list of all views inheriting from given type
     */
    List<? extends View> findViewInheritingType(Class<? extends View> viewType);

    /**
     * Finds all views implementing given type.
     * @param rootView      The root view to check
     * @param interfaceType The interface type to look up to
     * @param <T>           type of interface
     * @return list of all views implementing given type
     */
    <T> List<T> findViewImplementingType(View rootView, Class<T> interfaceType);

    /**
     * Finds all views implementing given type.
     * @param interfaceType The interface type to look up to
     * @param <T>           type of interface
     * @return A list of all views implementing given type
     */
    <T> List<T> findViewImplementingType(Class<T> interfaceType);

    /**
     * Gets the layout which holds the instance of given view.
     * @param view view reference
     * @return a layout reference or null if the view does not belong to any layout.
     */
    ILayout findLayoutByView(View view);

    /**
     * Redraws all displayed objects.
     */
    void redrawAll();

    /**
     * Gets the main stage view.
     * @return the main stage view
     */
    ViewGroup getStage();

    /**
     * Initializes the layoutResourceMap, buildViewMap fields and main stage.
     * @param renderer renderer instance that will be used during stage initialization.
     */
    void init(IRenderer renderer);

    /**
     * Unregisters a game screen.
     * @param id - string
     * @return boolean
     */
    boolean unregisterScreen(String id);

    /**
     * Gets a game screen by its id. The screen identifier is the same as layout inside it.
     * @param id screen identifier
     * @return a game screen
     */
    Screen getScreenById(String id);

    /**
     * Gets a list of all registered screens.
     * @return a list of screens
     */
    List<Screen> getAllScreens();

    /**
     * Registers a game screen.
     * @param screen game screen to register
     */
    void registerScreen(Screen screen);

    /**
     * Gets the screen by its type.
     * @param screenType screen type
     * @param <T>        type of the screen
     * @return a list of screen references of given type
     */
    <T extends Screen> List<T> getScreenByType(Class<T> screenType);
}
