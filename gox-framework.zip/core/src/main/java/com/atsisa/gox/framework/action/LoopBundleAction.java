package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Loop bundle action.
 */
public class LoopBundleAction extends BundleAction {

    /**
     * Repeat count value.
     */
    private int repeatCount;

    /**
     * Current repeat count.
     */
    private int currentRepeatCount;

    /**
     * Initializes a new instance of the LoopBundleAction class.
     */
    public LoopBundleAction() {
    }

    /**
     * Initializes a new instance of the LoopBundleAction class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public LoopBundleAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    /**
     * Gets action data type for this action.
     * @return action data type for this action
     */
    @Override
    public Class<? extends LoopBundleActionData> getActionDataType() {
        return LoopBundleActionData.class;
    }

    @Override
    protected void grabData() {
        super.grabData();
        if (actionData != null && ((LoopBundleActionData) actionData).getRepeatCount() > 0) {
            repeatCount = ((LoopBundleActionData) actionData).getRepeatCount();
        }
    }

    @Override
    public void reset() {
        super.reset();
        repeatCount = 0;
        currentRepeatCount = 0;
    }

    /**
     * Sets repeat count.
     * @param repeatCount - int
     */
    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
    }

    /**
     * Gets repeat count.
     * @return repeat count
     */
    public int getRepeatCount() {
        return repeatCount;
    }

    /**
     * Gets currently repeat count.
     * @return currently repeat count
     */
    public int getCurrentRepeatCount() {
        return currentRepeatCount;
    }

    @Override
    protected void processNextAction() {
        int nextIndex = getCurrentActiveAction().getQueueIndex() + 1;
        if (nextIndex < getActions().length) {
            super.processNextAction();
        } else {
            super.resetBundleActions();
            if (repeatCount <= 0 || currentRepeatCount < repeatCount - 1) {
                currentRepeatCount++;
                execute();
            } else {
                onLoopFinished();
                finish();
            }
        }
    }

    /**
     * Happens when the loop is finished.
     */
    protected void onLoopFinished() {
    }
}
