package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Action responsible for either showing the screen if it is hidden or hiding it if it is visible.
 */
@Reflect_Full
public class ToggleViewVisibilityAction extends ViewAction {

    /**
     * Initializes a new instance of the ToggleViewVisibilityAction class.
     */
    public ToggleViewVisibilityAction() {
    }

    /**
     * Initializes a new instance of the ToggleViewVisibilityAction class.
     * @param logger      a logger reference
     * @param eventBus    an eventBus reference
     * @param viewManager a viewManager reference
     */
    public ToggleViewVisibilityAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus, viewManager);
    }

    @Override
    protected void execute() {
        targetView.setVisible(!targetView.isVisible());
        finish();
    }
}
