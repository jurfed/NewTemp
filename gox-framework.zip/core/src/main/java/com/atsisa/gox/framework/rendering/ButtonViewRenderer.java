package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.IButtonLayer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.view.ButtonView;
import com.atsisa.gox.framework.view.InteractiveView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Button view rendering.
 */
public class ButtonViewRenderer extends InteractiveViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * The font registry.
     */
    private final IFontRegistry fontRegistry;

    /**
     * Initializes a new instance of the ButtonViewRenderer class using custom rendering.
     * @param renderer     {@link IRenderer}
     * @param fontRegistry {@link IFontRegistry}
     */
    public ButtonViewRenderer(IRenderer renderer, IFontRegistry fontRegistry) {
        super(renderer);
        this.fontRegistry = fontRegistry;
        lv = new LocalVariables();
    }

    /**
     * Creates and returns new button layer.
     * @param view View
     * @return IButtonLayer
     */
    @Override
    protected IButtonLayer createLayer(View view) {
        return getLayerFactory().createButtonLayer();
    }

    @Override
    public Class<?> getType() {
        return ButtonView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = changes;
        if (viewType == ViewType.INTERACTIVE_VIEW) {
            if (BitUtility.isSet(lv.leftChanges, InteractiveView.ViewPropertyName.STATE)) {
                lv.buttonStateResource = ((ButtonView) view).getCurrentStateResource();
                if (lv.buttonStateResource != null) {
                    ((IButtonLayer) getViewLayer(view)).setImage(lv.buttonStateResource.getImageWrapperObject());
                }
                updateLabelFormat((IButtonLayer) getViewLayer(view), ((ButtonView) view).getCurrentLabelFormat());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, InteractiveView.ViewPropertyName.STATE);
            }
        } else if (viewType == ViewType.BUTTON_VIEW) {
            if (BitUtility.isSet(lv.leftChanges, ButtonView.ViewPropertyName.LABEL)) {
                ((IButtonLayer) getViewLayer(view)).setLabel(((ButtonView) view).getLabel());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ButtonView.ViewPropertyName.LABEL);
            }
            if (BitUtility.isSet(lv.leftChanges, ButtonView.ViewPropertyName.LABEL_FORMAT)) {
                updateLabelFormat((IButtonLayer) getViewLayer(view), ((ButtonView) view).getCurrentLabelFormat());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ButtonView.ViewPropertyName.LABEL_FORMAT);
            }
        }
        return super.render(view, viewType, lv.leftChanges);
    }

    /**
     * Updates label format in button layer.
     * @param buttonLayer {@link IButtonLayer}
     * @param labelFormat {@link ButtonView.LabelFormat}
     */
    private void updateLabelFormat(IButtonLayer buttonLayer, ButtonView.LabelFormat labelFormat) {
        buttonLayer.setLabelFormat(labelFormat);
        IFontReference fontReference = fontRegistry.getFont(labelFormat.getFontName());
        buttonLayer.setLabelFontReference(fontReference);
    }

    /**
     * Holder for instances of local variables used in the {@link ButtonViewRenderer} render method.
     */
    private class LocalVariables {

        private IImageReference buttonStateResource;

        private int leftChanges;
    }
}
