package com.atsisa.gox.framework.view;

/**
 * Movie complete listener.
 */
@FunctionalInterface
public interface IMovieCompleteListener {

    /**
     * Called when movie will complete.
     */
    void onComplete();

}
