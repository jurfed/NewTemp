package com.atsisa.gox.framework.model;

/**
 * Represents layout lifecycle events.
 */
public enum LayoutEventType {
    /**
     * Describes a state in which layout is about to be added to the stage.
     */
    BEFORE_ADDED,
    /**
     * Describes a state in which layout has been added to the stage.
     */
    AFTER_ADDED,
    /**
     * Describes a state in which layout is about to be removed from the stage.
     */
    BEFORE_HIDDEN,
    /**
     * Describes a state in which layout has been removed from the stage.
     */
    AFTER_HIDDEN,
    /**
     * Describes a state in which layout is about to be removed from the stage and destroyed from cache.
     */
    BEFORE_DESTROYED,
    /**
     * Describes a state in which layout has been removed from the stage and destroyed from cache.
     */
    AFTER_DESTROYED
}
