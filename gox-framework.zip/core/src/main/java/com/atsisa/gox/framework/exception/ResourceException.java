package com.atsisa.gox.framework.exception;

/**
 * Indicates resource loading error.
 */
public class ResourceException extends GameException {

    /**
     * Game message.
     */
    public static final String LANG_ERROR_CANNOT_PROCESS_GAME = "LangErrorCannotProcessGame";

    /**
     * Initializes a new instance of the ResourceException using specific message.
     * @param message error message
     */
    public ResourceException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the ResourceException using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public ResourceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the ResourceException using specific cause.
     * @param cause internal cause of error
     */
    public ResourceException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getLocalizableMessage() {
        return LANG_ERROR_CANNOT_PROCESS_GAME;
    }
}
