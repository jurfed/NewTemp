package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Pause action. Used to stop action queue for a while, default is set for 1 second.
 */
@Reflect_Mini
public class PauseAction extends Action<PauseActionData> {

    /**
     * Default time.
     */
    private static final int DEFAULT_TIME = 1000;

    /**
     * Pause time, default is 1000 milliseconds (1 second).
     */
    private int pauseTime = DEFAULT_TIME;

    /**
     * Timeout.
     */
    private Timeout timeout;

    /**
     * Initializes a new instance of the PauseAction class.
     */
    public PauseAction() {
    }

    /**
     * Initializes a new instance of the PauseAction class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public PauseAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    /**
     * Gets action data type for this action.
     * @return action data type for this action
     */
    @Override
    public Class<PauseActionData> getActionDataType() {
        return PauseActionData.class;
    }

    @Override
    protected void grabData() {
        if (actionData != null) {
            pauseTime = actionData.getPauseTime();
        }
    }

    @Override
    protected void execute() {
        logger.debug("PauseAction | execute");
        timeout = new Timeout(pauseTime, new TimeoutCallback() {

            @Override
            public void onTimeout() {
                finish();
            }
        }, true);
    }

    @Override
    protected void terminate() {
        if (!isFinished()) {
            super.terminate();
            if (timeout != null && !timeout.isCleaned()) {
                timeout.clear();
            }
        }
    }

}
