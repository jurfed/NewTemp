package com.atsisa.gox.framework.serialization.converter;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.Skin;

/**
 * Converts xml file to list of skins.
 */
public class SkinListConverter implements IValueConverter {

    /**
     * Reference to logger.
     */
    private ILogger logger;

    /**
     * Default constructor. Reference to skin builder is taken from the game engine.
     */
    public SkinListConverter() {
        this(GameEngine.current().getLogger());
    }

    /**
     * Constructs SkinListConverter with ISkinBuilder passed as parameter.
     * @param logger - reference to logger
     */
    public SkinListConverter(ILogger logger) {
        this.logger = logger;
    }

    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    /**
     * Throws {@link UnsupportedOperationException}.
     * @param objToConvert a Java object instance
     * @return UnsupportedOperationException
     */
    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException("Not implemented!");
    }

    /**
     * Returns deserialized skin list.
     * @param serializedMessage a string representation of a Java object
     * @param parsedObject      - IParsedObject
     * @return skin list
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (StringUtility.isNullOrEmpty(serializedMessage)) {
            logger.debug("Skin list is empty");
            return null;
        }

        XmlObject xmlObject;
        if (parsedObject instanceof XmlObjectDocument) {
            xmlObject = ((XmlObjectDocument) parsedObject).getDocumentElement();
        } else if (parsedObject instanceof XmlObject) {
            xmlObject = (XmlObject) parsedObject;
        } else {
            throw new ConversionException("Object to parse is wrong type");
        }

        List<XmlObject> skinListObject = xmlObject.getChildren();
        List<Skin> parsedSkinList = new ArrayList<>();

        for (XmlObject skinObject : skinListObject) {
            if (skinObject.getName().equals("Skin")) {
                Skin parsedSkin = new Skin(skinObject.getAttribute("name"));
                parsedSkin.setSkinDefinition(skinObject.getChildren(0));
                parsedSkinList.add(parsedSkin);
            }
        }

        return parsedSkinList;
    }
}
