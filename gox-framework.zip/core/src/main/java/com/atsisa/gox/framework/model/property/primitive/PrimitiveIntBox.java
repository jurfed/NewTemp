package com.atsisa.gox.framework.model.property.primitive;

/**
 * Mutable boxing type of int primitive.
 */
public class PrimitiveIntBox {

    /**
     * The boxed value.
     */
    private int value;

    /**
     * Initializes a new instance of the PrimitiveIntBox class.
     * @param value boxed value
     */
    public PrimitiveIntBox(int value) {
        this.value = value;
    }

    /**
     * Gets boxed value.
     * @return int
     */
    public int getValue() {
        return value;
    }

    /**
     * Sets boxed value.
     * @param value int
     */
    public void setValue(int value) {
        this.value = value;
    }
}
