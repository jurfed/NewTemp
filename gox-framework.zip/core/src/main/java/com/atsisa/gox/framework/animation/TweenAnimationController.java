package com.atsisa.gox.framework.animation;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.rendering.IGameLoopListener;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.google.inject.Inject;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;

/**
 * A controller for {@link TweenViewAnimation}s.
 */
public class TweenAnimationController implements IGameLoopListener, IAnimationController<TweenAnimation> {

    /**
     * Interval multiplier in from milliseconds to microseconds.
     */
    private static final int MILLISECOND_IN_MICROSECONDS = 1000;

    /**
     * A maximal number of tween waypoints.
     */
    private static final int TWEEN_WAYPOINTS_LIMIT = 16;

    /**
     * The tween manager instance.
     */
    private final TweenManager tweenManager;

    /**
     * IPlatform reference.
     */
    private IPlatform platform;

    /**
     * Initializes a new instance of the {@link TweenAnimationController} class.
     * @param tweenManager The tween manager handling TweenViewAnimations' cross-cutting concerns.
     * @param renderer     The renderer.
     * @param platform     a platform reference.
     */
    @Inject
    public TweenAnimationController(TweenManager tweenManager, IRenderer renderer, IPlatform platform) {
        this.tweenManager = tweenManager;
        this.platform = platform;
        Tween.registerAccessor(View.class, new TweenViewAnimationAccessor());
        Tween.setCombinedAttributesLimit(TweenViewAnimationAccessor.TWEEN_ATTRIBUTES_LIMIT);
        Tween.setWaypointsLimit(TWEEN_WAYPOINTS_LIMIT);

        // TODO: hook it up outside this class.
        renderer.addGameLoopListener(this);
    }

    @Override
    public void onUpdate(float intervalMicroseconds) {
        tweenManager.update(intervalMicroseconds * MILLISECOND_IN_MICROSECONDS);
    }

    @Override
    public void play(final TweenAnimation animation) {
        final BaseTween<Tween> tween = animation.getTween();
        platform.invokeLaterRendering(new Runnable() {

            @Override
            public void run() {
                tween.start(tweenManager);
            }
        });
    }

    @Override
    public void pause(TweenAnimation animation) {
        animation.getTween().pause();
    }

    @Override
    public void resume(TweenAnimation animation) {
        animation.getTween().resume();
    }

    @Override
    public void stop(TweenAnimation animation) {
        animation.getTween().kill();
    }
}
