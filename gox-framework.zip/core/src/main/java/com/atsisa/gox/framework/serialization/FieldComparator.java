package com.atsisa.gox.framework.serialization;

import java.util.Comparator;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.utility.reflection.Field;

/**
 * Compares fields depending on XML attribute. If field has not attribute, then field is moved to end.
 */
public class FieldComparator implements Comparator<Field> {

    /**
     * Compares fields. Returns a negative integer,
     * zero, or a positive integer as the first argument is less than, equal
     * to, or greater than the second.
     * @param field1 first field to compare
     * @param field2 second field to compare
     * @return result of comparison, 1, 0 or -1
     */
    @Override
    public int compare(Field field1, Field field2) {
        XmlAttribute attr1 = field1.getAnnotation(XmlAttribute.class);
        XmlAttribute attr2 = field2.getAnnotation(XmlAttribute.class);
        if (attr1 == null) {
            return 1;
        } else if (attr2 == null) {
            return -1;
        } else if (attr1.order() < attr2.order()) {
            return -1;
        } else if (attr1.order() > attr2.order()) {
            return 1;
        } else {
            return attr1.name().compareToIgnoreCase(attr2.name());
        }
    }
}
