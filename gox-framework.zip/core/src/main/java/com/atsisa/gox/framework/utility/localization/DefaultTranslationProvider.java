package com.atsisa.gox.framework.utility.localization;

import java.util.HashMap;
import java.util.Map;

import rx.Observable;

/**
 * Represents a default translation provider.
 */
public class DefaultTranslationProvider implements ITranslationProvider {

    @Override
    public Observable<Map<String, String>> getTranslation(String languageCode) {
        return Observable.just(new HashMap<>());
    }
}
