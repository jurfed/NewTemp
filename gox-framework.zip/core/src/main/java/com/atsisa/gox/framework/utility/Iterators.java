package com.atsisa.gox.framework.utility;

import java.util.Iterator;

/**
 * A utility class for {@link Iterator}.
 */
public final class Iterators {

    /**
     * Prevents from creating instances of this class.
     */
    private Iterators() {
    }

    /**
     * Returns the number of elements remaining in {@code iterator}. The iterator will be left exhausted: its {@code hasNext()} method will return {@code
     * false}.
     * @param iterator iterator
     * @return the number of elements remaining in {@code iterator}
     */
    public static int size(Iterator<?> iterator) {
        int count = 0;
        while (iterator.hasNext()) {
            iterator.next();
            count++;
        }
        return count;
    }

}
