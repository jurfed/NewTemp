package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.view.spi.IViewActivator;

/**
 * A default implementation of {@link IViewActivator}
 * relying on {@link View}'s visibility.
 */
public class DefaultViewActivator implements IViewActivator {

    /**
     * Makes given view visible.
     * @param view The view to alter.
     */
    @Override
    public void activate(View view) {
        view.setVisible(true);
    }

    /**
     * Makes given view invisible.
     * @param view The view to alter.
     */
    @Override
    public void deactivate(View view) {
        view.setVisible(false);
    }
}
