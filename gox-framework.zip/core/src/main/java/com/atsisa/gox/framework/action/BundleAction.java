package com.atsisa.gox.framework.action;

import java.util.List;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Bundle action, which is used to group several actions as one.
 */
@Reflect_Mini
public class BundleAction<T extends BundleActionData> extends Action<T> {

    /**
     * Bundle action list.
     */
    private List<Action> actions;

    /**
     * Current active action.
     */
    private Action currentActiveAction;

    /**
     * Action listener.
     */
    private IStateListener<ActionState> actionListener;

    /**
     * Initializes a new instance of the BundleAction class.
     */
    public BundleAction() {
    }

    /**
     * Initializes a new instance of the BundleAction class.
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public BundleAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    /**
     * Gets action data type for this action.
     * @return action data type for this action
     */
    @Override
    public Class<? extends BundleActionData> getActionDataType() {
        return BundleActionData.class;
    }

    @Override
    void doReset() {
        resetBundleActions();
        super.doReset();
    }

    /**
     * Gets action list.
     * @return List if IAction
     */
    public IAction[] getActions() {
        return actions.toArray(new IAction[actions.size()]);
    }

    @Override
    public void terminate() {
        if (!isFinished()) {
            super.terminate();
            if (currentActiveAction != null) {
                currentActiveAction.doTerminate();
            }
        }
    }

    /**
     * Resets the action by removing state listener in all children.
     */
    protected void resetBundleActions() {
        if (actions != null) {
            for (Action action : actions) {
                action.removeStateListener(actionListener);
                action.doReset();
            }
        }
        currentActiveAction = null;
    }

    @Override
    protected void grabData() {
        if (actionData != null) {
            actions = actionData.getActions();
        }
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null) {
            throw new ValidationException("Bundle action data can not be null.");
        }
        if (actions == null || actions.isEmpty()) {
            throw new ValidationException("Bundle action data can not return null or empty action list.");
        }
    }

    @Override
    protected void execute() {
        int index = 0;
        actionListener = (source, state) -> {
            if (isFinished()) {
                return;
            }
            Action action = (Action) source;
            if (action.isFinished() && action.getState() != ActionState.TERMINATED) {
                processNextAction();
            }
        };

        for (Action action : actions) {
            action.setParentBundleAction(this);
            action.setParentQueue(getParentQueue());
            action.setQueueIndex(index);
            action.addStateListener(actionListener);
            index++;
        }

        currentActiveAction = actions.get(0);
        currentActiveAction.doExecute();
    }

    /**
     * Gets current active action.
     * @return IAction
     */
    protected IAction getCurrentActiveAction() {
        return currentActiveAction;
    }

    /**
     * Called when current active action will finished.
     */
    protected void processNextAction() {
        int nextIndex = currentActiveAction.getQueueIndex() + 1;
        if (nextIndex < actions.size()) {
            currentActiveAction = actions.get(nextIndex);
            currentActiveAction.doExecute();
        } else {
            finish();
        }
    }
}
