package com.atsisa.gox.framework.utility;

/**
 * Contain definition of common static values that are used code-wide.
 */
public class Statics {

    public static final int MILLIS_IN_SECOND = 1000;

    public static final float FPS_60 = 1 / 60f;

    public static final float FPS_30 = 1 / 30f;
}
