package com.atsisa.gox.framework.model;

/**
 * Exposes an abstraction for pause object.
 */
public interface IPauseable {

    /**
     * Pauses object.
     */
    void pause();
}
