package com.atsisa.gox.framework.model.property.primitive;

/**
 * Mutable boxing type of float primitive.
 */
public class PrimitiveFloatBox {

    /**
     * The boxed value.
     */
    private float value;

    /**
     * Initializes a new instance of the PrimitiveIntBox class.
     * @param value boxed value
     */
    public PrimitiveFloatBox(float value) {
        this.value = value;
    }

    /**
     * Gets boxed value.
     * @return float
     */
    public float getValue() {
        return value;
    }

    /**
     * Sets boxed value.
     * @param value float
     */
    public void setValue(float value) {
        this.value = value;
    }
}
