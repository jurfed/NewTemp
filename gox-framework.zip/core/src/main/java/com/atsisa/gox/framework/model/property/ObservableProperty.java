package com.atsisa.gox.framework.model.property;

/**
 * Observable property class.
 * @param <T> type of the property's value
 */
public class ObservableProperty<T> extends ObservablePropertyContainer implements IObservableProperty<T> {

    /**
     * Default value.
     */
    private T defaultValue;

    /**
     * Property's value type.
     */
    private final Class<T> type;

    /**
     * The value.
     */
    private T value;

    /**
     * The oldValue.
     */
    private T oldValue;

    /**
     * Initializes a new instance of the ObservableProperty class.
     * @param type property's value type
     */
    public ObservableProperty(Class<T> type) {
        this.type = type;
        defaultValue = null;
    }

    /**
     * Initializes a new instance of the ObservableProperty class.
     * @param type         property's value type
     * @param defaultValue default value
     */
    public ObservableProperty(Class<T> type, T defaultValue) {
        this.type = type;
        this.defaultValue = defaultValue;
    }

    @Override
    public Class<T> getType() {
        return type;
    }

    @Override
    public T get() {
        if (value != null) {
            return value;
        }
        return defaultValue;
    }

    /**
     * Sets the default value of the property.
     */
    public void setDefaultValue() {
        set(defaultValue);
    }

    @Override
    public T getDefaultValue() {
        return defaultValue;
    }

    @Override
    public void setDefaultValue(T defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * Sets the property value and notifies listeners about changes. Notification will only be triggered if the actual
     * value has changed
     * @param newValue new property value
     * @return true if a new value differs from the current value, false otherwise
     */
    @Override
    public boolean set(T newValue) {
        oldValue = value;
        if (value == null) {
            if (newValue != null) {
                value = newValue.equals(defaultValue) ? null : newValue;
                notifyPropertyChanged(this, oldValue, get());
                return true;
            }
        } else if (!value.equals(newValue)) {
            value = newValue;
            if (newValue == null || newValue.equals(defaultValue)) {
                value = null;
            }
            notifyPropertyChanged(this, oldValue, get());
            return true;
        }
        return false;
    }

    @Override
    public boolean hasDefaultValue() {
        return value == null || value.equals(defaultValue);
    }

    @Override
    public String toString() {
        return "ObservableProperty{" + "type=" + type + ", value=" + value + '}';
    }
}
