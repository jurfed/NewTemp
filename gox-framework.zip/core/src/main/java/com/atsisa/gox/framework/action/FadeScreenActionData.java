package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Provides data determining which screen to fade and how.
 */
@XmlElement
@Reflect_Full
public class FadeScreenActionData extends ScreenActionData {

    /**
     * Default time span for fade animation.
     */
    public static final int DEFAULT_TIME_SPAN = 1000;

    /**
     * Screen fade time span.
     */
    @XmlAttribute
    private Integer timeSpan;

    /**
     * Gets the screen fade time span.
     * @return String the screen fade time span
     */
    public Integer getTimeSpan() {
        return timeSpan;
    }

    /**
     * Sets the screen fade time span.
     * @param timeSpan the screen fade time span
     */
    public void setTimeSpan(Integer timeSpan) {
        this.timeSpan = timeSpan;
    }
}
