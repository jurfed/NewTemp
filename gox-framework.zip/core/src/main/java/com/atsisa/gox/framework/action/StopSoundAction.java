package com.atsisa.gox.framework.action;

/**
 * Stops sound with given id.
 */
public class StopSoundAction extends SoundAction {

    @Override
    protected void execute() {
        soundManager.stop(getData().getSoundId());
    }
}
