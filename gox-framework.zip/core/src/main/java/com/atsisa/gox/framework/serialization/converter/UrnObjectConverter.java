package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlSerializer;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Creates objects from xml namespaces in URN JAVA notation.
 */
public class UrnObjectConverter implements IValueConverter {

    /**
     * The URN Java prefix.
     */
    private static final String URN_JAVA_PREFIX = "urn:java:";

    /**
     * XML serializer instance used during unmarshalling of objects.
     */
    private final IXmlSerializer serializer;

    /**
     * Initializes a new instance of {@link UrnObjectConverter} class.
     */
    public UrnObjectConverter() {
        serializer = GameEngine.current().getUtility().getSerialization().getSerializer(SerializationFormat.XML);
    }

    /**
     * Initializes a new instance of {@link UrnObjectConverter} class
     * using given serializer.
     * @param serializer The serializer.
     */
    public UrnObjectConverter(XmlSerializer serializer) {
        this.serializer = serializer;
    }

    @Override
    public Class<?> getValueType() {
        return Object.class;
    }

    @Override
    public String convertTo(Object objToConvert) throws ConversionException {
        throw new ConversionException("The operation is not supported");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (serializedMessage == null || parsedObject == null) {
            return null;
        }

        XmlObject xmlObject = (XmlObject) parsedObject;
        if (xmlObject.getChildren().size() != 1) {
            return null;
        }

        XmlObject firstChild = xmlObject.getChildren(0);
        if (firstChild.getNamespace() != null && firstChild.getNamespace().startsWith(URN_JAVA_PREFIX)) {
            String packageName = firstChild.getNamespace().substring(URN_JAVA_PREFIX.length());
            String className = StringUtility.format("%s.%s", packageName, firstChild.getName());
            try {
                return serializer.deserialize(firstChild, className);
            } catch (SerializationException e) {
                throw new ConversionException("Unable to deserialize class: " + className, e);
            }
        }

        return null;
    }
}
