package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Action event listener. Listens for any event and causes execution of particular action queue via ActionManager.
 */
public class ActionQueueEventListener implements IEventListener {

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * An Action manager reference.
     */
    private final IActionManager actionManager;

    /**
     * The name of the action queue.
     */
    private final String actionQueueName;

    /**
     * Initializes a new instance of the ActionEventListener class.
     * @param actionQueueName the name of the action queue which should be executed in callback
     */
    public ActionQueueEventListener(String actionQueueName) {
        this(actionQueueName, GameEngine.current().getActionManager(), GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of the ActionEventListener class.
     * @param actionQueueName the name of the action queue which should be executed in callback
     * @param actionManager   action manager reference
     * @param logger          logger reference
     */
    public ActionQueueEventListener(String actionQueueName, IActionManager actionManager, ILogger logger) {
        this.actionQueueName = actionQueueName;
        this.actionManager = actionManager;
        this.logger = logger;
    }

    @Override
    public void onEvent(IEvent event) {
        long idQueue = actionManager.processQueue(actionQueueName);
        if (idQueue == -1) {
            logger.error(StringUtility.format("Could not process queue '%s'", actionQueueName));
        }
    }

    /**
     * Gets the name of the action queue which should be executed in callback.
     * @return the name of the action queue
     */
    public String getActionQueueName() {
        return actionQueueName;
    }
}
