package com.atsisa.gox.framework.eventbus;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.logger.NoLogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;

import rx.Observable;
import rx.Observer;
import rx.subjects.BehaviorSubject;
import rx.subjects.PublishSubject;
import rx.subjects.ReplaySubject;
import rx.subjects.Subject;

/**
 * Generic reactive-like implementation of RxEventBus compliant with {@link Observer} pattern.
 * @param <T> type of the events that are processed by the bus.
 */
class RxEventBus<T> {

    /**
     * Instance of event bus implementation realized in accordance with reactive principles. The most common
     * implementations are: {@link PublishSubject}, {@link ReplaySubject} and {@link BehaviorSubject}.
     */
    private final Subject<T, T> subject;

    /**
     * Instance of dead event queue.
     */
    private final Subject<DeadEvent, DeadEvent> deadEventSubject;

    private final IReflection reflection;

    /**
     * The logger.
     */
    private final ILogger logger;

    /**
     * @param subject underlying logic of the bus.
     */
    public RxEventBus(Subject<T, T> subject, IReflection reflection, final ILogger logger) {
        this.subject = subject;
        this.subject.doOnError(throwable -> logger.error("An error occurred during handling an event.", throwable));
        deadEventSubject = PublishSubject.create();
        this.reflection = reflection;
        this.logger = logger;
    }

    /**
     * Generic method to post event of any type to the bus. In case there are no subscribers then the event is forwarder to internal instance of bus.
     * @param event event to be published into the bus.
     * @param <E>   type complaint with the event bus instance.
     */
    public <E extends T> void post(E event) {
        if (subject.hasObservers()) {
            subject.onNext(event);
        } else {
            deadEventSubject.onNext(new DeadEvent(event));
        }
    }

    /**
     * Gets a representation of observable events.
     * @return Events represented as an observables.
     */
    public Observable<T> observe() {
        return subject;
    }

    /**
     * Gets a representation of observable events with a basic class type filter.
     * @return Events represented as an observables that matches the <code>eventClass</code>.
     */
    public <E extends T> Observable<E> observeEvents(final Class<E> eventClass) {
        return subject.filter(t -> reflection.isInstance(eventClass, t)).cast(eventClass);
    }

    /**
     * Gets a representation of observable dead events.
     * @return Dead events represented as an observables that wraps undelivered events of type <code>T</code>.
     */
    public Observable<DeadEvent> observeDeadEvents() {
        return deadEventSubject;
    }

    private enum EventBusStrategy {
        /**
         * Represents publish subscribe model of the event bus {@link PublishSubject}.
         */
        PUBLISH_SUBSCRIBE,

        /**
         * Represents publish subscribe model with global durable subscription propagation for all events.
         * {@link ReplaySubject}
         */
        REPLAY,

        /**
         * Represents publish subscribe model with last matched event propagation {@link BehaviorSubject}.
         */
        BEHAVIOUR
    }

    /**
     * Builder for event bus.
     */
    public static class Builder<T> {

        /**
         * Instance of event bus metadata.
         */
        private final EventBusMetadata eventBusMetadata;

        /**
         * Default constructor.
         */
        public Builder() {
            eventBusMetadata = new EventBusMetadata();
        }

        /**
         * Configures the builder to construct basic publish subscribe bus.
         * @return this builder instance.
         */
        public Builder asPublishSubscribeBus() {
            eventBusMetadata.setEventBusStrategy(EventBusStrategy.PUBLISH_SUBSCRIBE);
            eventBusMetadata.properties.clear();
            return this;
        }

        /**
         * Configures the builder to construct replay bus.
         * @param numberOfEventsToRepeat - number of events that has to be replayed to a newly subscribed entities.
         * @return this builder instance.
         */
        public Builder asReplayBus(int numberOfEventsToRepeat) {
            eventBusMetadata.setEventBusStrategy(EventBusStrategy.REPLAY);
            eventBusMetadata.setProperty(EventBusMetadata.REPLAY_SUBJECT_NUMBER_OF_EVENTS, numberOfEventsToRepeat);
            return this;
        }

        /**
         * Configures the builder to construct behaviour bus, which replays last matched event to newly subscribed entities.
         * @return this builder instance.
         */
        public Builder asBehaviourBus() {
            eventBusMetadata.setEventBusStrategy(EventBusStrategy.BEHAVIOUR);
            return this;
        }

        public Builder withReflection(IReflection reflection) {
            eventBusMetadata.setProperty(EventBusMetadata.REFLECTION_INSTANCE, reflection);
            return this;
        }

        /**
         * Adds a logger to the event bus.
         * @param logger The logger.
         * @return The builder.
         */
        public Builder withLogger(ILogger logger) {
            eventBusMetadata.setProperty(EventBusMetadata.LOGGER_INSTANCE, logger);
            return this;
        }

        /**
         * Creates the instance of event bus that was configured by the builder.
         * @return instance of {@link RxEventBus} .
         */
        public RxEventBus<T> build() {
            IReflection reflection = (IReflection) eventBusMetadata.properties.get(EventBusMetadata.REFLECTION_INSTANCE);
            if (reflection == null) {
                throw new UnsupportedOperationException("Builder has to be provided with reflection instance ['withReflection' method] which is not null");
            }

            ILogger logger = (ILogger) eventBusMetadata.properties.get(EventBusMetadata.LOGGER_INSTANCE);
            if (logger == null) {
                logger = new NoLogger();
            }
            switch (eventBusMetadata.eventBusStrategy) {
                case PUBLISH_SUBSCRIBE:
                    return new RxEventBus<>(PublishSubject.<T>create(), reflection, logger);
                case REPLAY:
                    int replayCount = (int) eventBusMetadata.properties.get(EventBusMetadata.REPLAY_SUBJECT_NUMBER_OF_EVENTS);
                    return new RxEventBus<>(ReplaySubject.<T>createWithSize(replayCount), reflection, logger);
                case BEHAVIOUR:
                    return new RxEventBus<>(BehaviorSubject.<T>create(), reflection, logger);
                default:
                    throw new UnsupportedOperationException("Unsupported event bus strategy: " + eventBusMetadata.eventBusStrategy);
            }
        }
    }

    /**
     * Contains metadata necessary for constructing proper type of event bus.
     */
    private static class EventBusMetadata {

        /**
         * Key used upon creation of replay bus type.
         */
        private static final String REPLAY_SUBJECT_NUMBER_OF_EVENTS = "numberOfEventsToRepeat";

        /**
         * Key used upon creation of replay bus type.
         */
        private static final String REFLECTION_INSTANCE = "reflectionInstance";

        /**
         * Logger instance.
         */
        public static final String LOGGER_INSTANCE = "loggerInstance";

        /**
         * Properties map used during bus initialization.
         */
        private final Map<String, Object> properties;

        /**
         * Instance of event bus strategy.
         */
        private EventBusStrategy eventBusStrategy;

        /**
         * Private constructor to prevent external instantiation.
         */
        private EventBusMetadata() {
            properties = new HashMap<>();
            eventBusStrategy = EventBusStrategy.PUBLISH_SUBSCRIBE;
        }

        /**
         * Sets event bus strategy creation.
         * @param eventBusStrategy determines the internal logic and behaviour of the event bus
         */
        public void setEventBusStrategy(EventBusStrategy eventBusStrategy) {
            this.eventBusStrategy = eventBusStrategy;
        }

        /**
         * Sets custom property of the event bus metadata which may be used during bus initialization.
         * @param key   property key
         * @param value property value
         */
        public void setProperty(String key, Object value) {
            properties.put(key, value);
        }
    }

    /**
     * Event wrapping objects posted to event bus that could not be delivered due to the lack of active subscribers.
     */
    public class DeadEvent {

        /**
         * Source event instance.
         */
        private T sourceEvent;

        /**
         * Default constructor.
         * @param sourceEvent source event
         */
        DeadEvent(T sourceEvent) {
            this.sourceEvent = sourceEvent;
        }

        /**
         * Gets wrapped event.
         * @return wrapped event
         */
        public T getSourceEvent() {
            return sourceEvent;
        }
    }
}
