package com.atsisa.gox.framework.resource;

/**
 * Provider for {@link XmlResource} type.
 */
public class XmlResourceProvider implements IResourceProvider {

    @Override
    public boolean canCreate(ResourceType resourceType) {
        return resourceType == ResourceType.XML;
    }

    @Override
    public IResource createResource(ResourceDescription resourceDescription) {
        return new XmlResource(resourceDescription);
    }
}
