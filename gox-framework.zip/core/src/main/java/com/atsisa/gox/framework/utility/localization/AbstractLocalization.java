package com.atsisa.gox.framework.utility.localization;

/**
 * Abstract localization class.
 */
public abstract class AbstractLocalization implements ILocalization {

    /**
     * Default date format (ISO 8601).
     */
    public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
