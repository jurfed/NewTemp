package com.atsisa.gox.framework.exception;

/**
 * Indicates not enough funds.
 */
public class NotEnoughFundsException extends GameException {

    /**
     * Game message.
     */
    public static final String LANG_NOT_ENOUGH_FUNDS = "LangNotEnoughFunds";

    /**
     * Initializes a new instance of the NotEnoughFundsException using specific message.
     * @param message error message
     */
    public NotEnoughFundsException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the NotEnoughFundsException using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public NotEnoughFundsException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the NotEnoughFundsException using specific cause.
     * @param cause internal cause of error
     */
    public NotEnoughFundsException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getLocalizableMessage() {
        return LANG_NOT_ENOUGH_FUNDS;
    }
}
