package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import com.atsisa.gox.framework.resource.IResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.QueuesResource;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * Action Queue Manager.
 */
public class ActionManager implements IActionManager, IStateListener<ActionQueueState> {

    /**
     * List all using (active, pause) action queues.
     */
    private List<ActionQueue> queues = new ArrayList<>();

    /**
     * Current active queue.
     */
    private ActionQueue activeQueue;

    /**
     * Next available id for queue.
     */
    private long nextId = 1;

    /**
     * Action builder.
     */
    private IActionBuilder actionBuilder;

    /**
     * ILogger implementation.
     */
    private ILogger logger;

    /**
     * IResourceManager implementation.
     */
    private IResourceManager resourceManager;

    /**
     * IActionBinder implementation.
     */
    private IActionBinder actionBinder;

    /**
     * Registered action queues map.
     */
    private Map<String, QueueMetadata> registeredActionQueuesMap = new HashMap<>();

    /**
     * Initializes a new instance of the {@link ActionManager} class.
     * @param logger          {@link ILogger}
     * @param actionBuilder   {@link IActionBuilder}
     * @param resourceManager {@link IResourceManager}
     * @param actionBinder    {@link IActionBinder}
     */
    @Inject
    public ActionManager(ILogger logger, IActionBuilder actionBuilder, IResourceManager resourceManager, IActionBinder actionBinder) {
        this.logger = logger;
        this.actionBuilder = actionBuilder;
        this.resourceManager = resourceManager;
        this.actionBinder = actionBinder;
    }

    @Override
    public final IActionBuilder getActionBuilder() {
        return actionBuilder;
    }

    @Override
    public boolean destroyActionQueue(long id) {
        if (activeQueue != null && activeQueue.getId() == id) {
            activeQueue.destroy();
            processNextQueue();
            return true;
        } else {
            boolean found = false;
            Iterator<ActionQueue> actionQueueIterator = queues.iterator();
            while (actionQueueIterator.hasNext()) {
                ActionQueue queue = actionQueueIterator.next();
                if (queue.getId() == id) {
                    queue.destroy();
                    actionQueueIterator.remove();
                    resetActions(queue.getActions());
                    found = true;
                    break;
                }
            }
            return found;
        }
    }

    @Override
    public void terminateActiveAction() {
        if (activeQueue != null) {
            activeQueue.terminateCurrentAction();
        }
    }

    @Override
    public boolean destroyActiveQueue() {
        if (activeQueue != null) {
            activeQueue.destroy();
            processNextQueue();
            return true;
        }
        return false;
    }

    @Override
    public boolean destroyPausedQueues() {
        boolean atLeastOne = queues.size() > 1;
        Iterator<ActionQueue> actionQueueIterator = queues.iterator();
        while (actionQueueIterator.hasNext()) {
            ActionQueue queue = actionQueueIterator.next();
            if (queue != activeQueue) {
                queue.destroy();
                actionQueueIterator.remove();
                resetActions(queue.getActions());
            }
        }
        return atLeastOne;
    }

    @Override
    public boolean destroyAllQueues() {
        return destroyActiveQueue() || destroyPausedQueues();
    }

    @Override
    public long processAction(Action action) {
        return processAction(action, null);
    }

    @Override
    public long processAction(Action action, IStateListener<ActionQueueState> listener) {
        List<Action> actionList = new ArrayList<>();
        actionList.add(action);
        return processQueue(actionList, null, listener, false, false);
    }

    @Override
    public long processQueue(String queueName) {
        return processQueue(queueName, false);
    }

    @Override
    public long processQueue(String queueName, boolean asNext) {
        return processQueue(queueName, null, asNext);
    }

    @Override
    public long processQueue(String queueName, IStateListener<ActionQueueState> listener, boolean asNext) {
        QueueMetadata queueMetadata = registeredActionQueuesMap.get(queueName);
        if (queueMetadata == null) {
            queueMetadata = actionBuilder.getQueue(queueName);
            if (queueMetadata == null) {
                throw new IllegalArgumentException(StringUtility.format("Queue name '%s' was not defined.", queueName));
            }
            registerQueue(queueName, queueMetadata);
        }
        return processQueue(queueMetadata.getActions(), queueName, listener, asNext, queueMetadata.isForced());
    }

    @Override
    public long processQueue(String queueName, IStateListener<ActionQueueState> listener) {
        return processQueue(queueName, listener, false);
    }

    @Override
    public long processQueue(List<Action> actionList) {
        return processQueue(actionList, null, null, false, false);
    }

    @Override
    public long processQueue(List<Action> actionList, IStateListener<ActionQueueState> listener) {
        return processQueue(actionList, null, listener, false, false);
    }

    @Override
    public IActionQueue getActionQueueById(long id) {
        for (IActionQueue actionQueue : queues) {
            if (actionQueue.getId() == id) {
                return actionQueue;
            }
        }
        return null;
    }

    /**
     * Gets all action queues which are now pause or active.
     * @return list of IActionQueue
     */
    @Override
    public List<IActionQueue> getActionQueues() {
        return Arrays.asList(queues.toArray(new IActionQueue[queues.size()]));
    }

    /**
     * Returns current active queue.
     * @return IActionQueue
     */
    @Override
    public final IActionQueue getActiveQueue() {
        return activeQueue;
    }

    /**
     * Gets all action queues which are now pause.
     * @return list of IActionQueue
     */
    @Override
    public final List<IActionQueue> getPausedActionQueues() {
        List<IActionQueue> listToReturn = new ArrayList<>();
        for (IActionQueue queue : queues) {
            if (queue.getState() == ActionQueueState.PAUSED) {
                listToReturn.add(queue);
            }
        }
        return listToReturn;
    }

    @Override
    public void registerActionResource(String resourceId) {
        QueuesResource queuesResource = (QueuesResource) resourceManager.getResource(resourceId, ResourceType.QUEUES);
        try {
            actionBuilder.addQueues(queuesResource);
        } catch (ParseException e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void registerActionQueuesFromResources() {
        List<IResource> queuesResources = resourceManager.getAllResources(ResourceType.QUEUES);
        for (IResource queuesResource : queuesResources) {
            try {
                actionBuilder.addQueues((QueuesResource) queuesResource);
            } catch (ParseException e) {
                logger.error(e.getMessage());
            }
        }
    }

    @Override
    public boolean registerQueue(String name, QueueMetadata queueMetadata) {
        return registerQueue(name, queueMetadata, false);
    }

    @Override
    public boolean isRegistered(String queueName) {
        // TODO analyse whether we need lazy loading of queues
        boolean alreadyRegistered = registeredActionQueuesMap.containsKey(queueName);
        boolean retrievable = null != actionBuilder.getQueue(queueName);
        return alreadyRegistered || retrievable;
    }

    @Override
    public boolean registerQueue(String name, QueueMetadata queueMetadata, boolean override) {
        if (override || !registeredActionQueuesMap.containsKey(name)) {
            registeredActionQueuesMap.put(name, queueMetadata);
            return true;
        } else {
            logger.warn("Can not register queue: %s, because queue with that name has already been registered.", name);
        }
        return false;
    }

    @Override
    public String[] getRegisteredQueueNames() {
        Set<String> queueNames = registeredActionQueuesMap.keySet();
        return queueNames.toArray(new String[queueNames.size()]);
    }

    @Override
    public IActionBinder getActionBinder() {
        return actionBinder;
    }

    /**
     * Called when current active queue is finished.
     */
    protected void processNextQueue() {
        if (activeQueue != null && isFinishedOrDestroyed(activeQueue)) {
            if (!queues.remove(activeQueue)) {
                logger.warn("Queue %s not exist in queue manager list.", activeQueue.getId());
            }
            activeQueue = null;
            int queueSize = queues.size();
            if (queueSize > 0) {
                activeQueue = queues.get(queueSize - 1);
                if (activeQueue.getState() == ActionQueueState.PENDING) {
                    resetActions(activeQueue.getActions());
                }
                activeQueue.process();
            }
        }
    }

    /**
     * Checks whether an action queue has been either finished or destroyed.
     * @param actionQueue action queue to check
     * @return a value indicating that the queue has been either finished or destroyed
     */
    private boolean isFinishedOrDestroyed(ActionQueue actionQueue) {
        return actionQueue.getState() == ActionQueueState.FINISHED || actionQueue.getState() == ActionQueueState.DESTROYED;
    }

    /**
     * Creates and runs new action queue.
     * @param actionList          list action to process
     * @param name                name of action queue
     * @param listener            action queue state listener
     * @param asNext              a boolean value that indicates whether this queue should be process as the next or not
     * @param forceQueueExecution a boolean value that indicates whether this queue should be forced
     * @return unique id of queue, return "-1" if queue can not be created
     */
    private long processQueue(List<Action> actionList, String name, IStateListener<ActionQueueState> listener, boolean asNext, boolean forceQueueExecution) {
        if (hasActionWithSameName(name) && !asNext) {
            logger.warn("Can not process queue: %s, because it is currently processed", name);
            return -1;
        }
        assert actionList != null;
        assert actionBuilder != null;
        int length = actionList.size();
        ActionQueue newQueue;
        Action[] actions = new Action[length];
        Action action;
        for (int i = 0; i < actions.length; ++i) {
            action = actionList.get(i);
            if (action != null) {
                actions[i] = action;
            } else {
                throw new IllegalArgumentException("Cannot process queue, because action to process can not be null");
            }
        }
        newQueue = new ActionQueue(actions, nextId, logger, name);
        newQueue.addStateListener(this);
        if (listener != null) {
            newQueue.addStateListener(listener);
        }
        queues.add(newQueue);
        nextId = nextId % Long.MAX_VALUE + 1;
        if (forceQueueExecution && activeQueue != null) {
            activeQueue.destroy();
        } else if (!asNext || activeQueue == null) {
            if (activeQueue != null) {
                activeQueue.pause();
            }
            activeQueue = newQueue;
            if (activeQueue.getState() == ActionQueueState.PENDING) {
                resetActions(activeQueue.getActions());
            }
            activeQueue.process();
        }
        return newQueue.getId();
    }

    /**
     * Checks if an action with the very same name has already been provided in the action list.
     * @param name action name to check
     * @return a value indicating whether the very same name has already been provided in the action list
     */
    private boolean hasActionWithSameName(String name) {
        if (name != null) {
            String queueName;
            for (IActionQueue actionQueue : queues) {
                queueName = actionQueue.getName();
                if (Objects.equals(queueName, name)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Reset actions.
     * @param actions list of IAction
     */
    private void resetActions(IAction[] actions) {
        for (IAction action : actions) {
            ((Action) action).doReset();
        }
    }

    @Override
    public void stateChanged(Object source, ActionQueueState state) {
        if (isFinishedOrDestroyed((ActionQueue) source)) {
            processNextQueue();
        }
    }
}
