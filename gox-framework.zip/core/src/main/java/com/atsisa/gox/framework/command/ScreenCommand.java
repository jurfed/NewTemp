package com.atsisa.gox.framework.command;

/**
 * A command used to interact with screens.
 */
public abstract class ScreenCommand extends UserInteractionCommand {

    /**
     * Id of the screen.
     */
    private String screenId;

    /**
     * Initializes a new instance of the {@link ScreenCommand} class.
     * @param screenId the id of the screen
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public ScreenCommand(String screenId, boolean triggeredByUser) {
        super(triggeredByUser);
        this.screenId = screenId;
    }

    /**
     * Initializes a new instance of the {@link ScreenCommand} class.
     * @param screenId the id of the screen
     */
    public ScreenCommand(String screenId) {
        this(screenId, false);
    }

    /**
     * Gets the id of the screen.
     * @return the id of the screen
     */
    public String getScreenId() {
        return screenId;
    }

}
