package com.atsisa.gox.framework.eventbus;

import rx.Observer;

/**
 * An abstract observer which has its onError
 * and onCompleted methods implemented.
 */
public abstract class NextObserver<T> implements Observer<T> {

    /**
     * Does nothing.
     * @param error Occurred error.
     */
    @Override
    public void onError(Throwable error) {
        error.printStackTrace();
    }

    /**
     * Does nothing.
     */
    @Override
    public void onCompleted() {
    }
}
