package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Class used for storing data about skins for views.
 */
public class Skin {

    /**
     * View builder reference.
     */
    private final IViewBuilder viewBuilder;

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Name of the skin.
     */
    private String name;

    /**
     * Reference to the view.
     */
    private View view;

    /**
     * Skin definition.
     */
    private IParsableObject skinDefinition;

    /**
     * Initializes a new instance of {@link Skin} class.
     */
    public Skin() {
        this(null);
    }

    /**
     * Initializes a new instance of {@link Skin} class.
     * @param name name of the skin
     */
    public Skin(String name) {
        this(name, GameEngine.current().getViewManager().getViewBuilder(), GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of {@link Skin} class.
     * @param name        name of the skin
     * @param viewBuilder {@link IViewBuilder}
     * @param logger      {@link ILogger}
     */
    public Skin(String name, IViewBuilder viewBuilder, ILogger logger) {
        this.name = name;
        this.viewBuilder = viewBuilder;
        this.logger = logger;
    }

    /**
     * Gets skin name.
     * @return skin name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the skin view.
     * @return skin view reference
     */
    public View getView() {
        if (!isBuilt()) {
            try {
                build();
            } catch (Exception e) {
                logger.error("Could not build '" + name + "' skin.", e);
            }
        }
        return view;
    }

    /**
     * Returns class object of stored view.
     * @return class object of view class or subclass
     */
    public Class<? extends View> getViewType() {
        if (view == null) {
            throw new IllegalArgumentException("Skin " + name + " not instantiated");
        }
        return view.getClass();
    }

    /**
     * Sets the skin definition.
     * @param skinDefinition {@link IParsableObject}
     */
    public void setSkinDefinition(IParsableObject skinDefinition) {
        view = null;
        this.skinDefinition = skinDefinition;
    }

    /**
     * Checks if the skin has been build.
     * @return checks if the skin has been build before.
     */
    public boolean isBuilt() {
        return view != null;
    }

    /**
     * Builds the current skin definition.
     * @throws ParseException         if something went wrong with parsing
     * @throws SerializationException if something went wrong with deserializing the view.
     */
    public void build() throws ParseException, SerializationException {
        if (skinDefinition == null) {
            throw new IllegalStateException(StringUtility.format("%s skin definition has not been set", name));
        }
        view = viewBuilder.createView((XmlObject) skinDefinition, false);
    }
}
