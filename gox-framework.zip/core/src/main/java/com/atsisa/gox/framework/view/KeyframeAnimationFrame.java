package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.resource.IImageObjectWrapper;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.atsisa.gox.framework.utility.ICloneable;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Describes single keyframe animation frame.
 */
@Reflect_Full
@XmlElement
public class KeyframeAnimationFrame<TImgWrapper extends IImageObjectWrapper> implements ICloneable<KeyframeAnimationFrame> {

    /**
     * The image reference.
     */
    @XmlAttribute(name = "src", converters = ResourceRefConverter.class)
    private IImageReference<TImgWrapper> image;

    /**
     * Position x frame.
     */
    @XmlAttribute
    private float x = 0f;

    /**
     * Position y frame.
     */
    @XmlAttribute
    private float y = 0f;

    /**
     * Width frame.
     */
    @XmlAttribute
    private float width;

    /**
     * Height frame.
     */
    @XmlAttribute
    private float height;

    /**
     * Initializes a new instance of the {@link KeyframeAnimationFrame} class.
     */
    public KeyframeAnimationFrame() {
    }

    /**
     * Initializes a new instance of the {@link KeyframeAnimationFrame} class.
     * @param image  The underlying image.
     * @param width  The frame width.
     * @param height The frame height.
     */
    public KeyframeAnimationFrame(IImageReference image, float width, float height) {
        this.image = image;
        this.width = width;
        this.height = height;
    }

    /**
     * Sets x frame position.
     * @param value - float
     */
    public void setX(float value) {
        x = value;
    }

    /**
     * Gets x frame position.
     * @return float.
     */
    public float getX() {
        return x;
    }

    /**
     * Sets y frame position.
     * @param value - float
     */
    public void setY(float value) {
        y = value;
    }

    /**
     * Gets y frame position.
     * @return float.
     */
    public float getY() {
        return y;
    }

    /**
     * Gets width frame.
     * @return int
     */
    public float getWidth() {
        return width;
    }

    /**
     * Sets width frame.
     * @param width - int
     */
    public void setWidth(float width) {
        this.width = width;
    }

    /**
     * Gets height frame.
     * @return int
     */
    public float getHeight() {
        return height;
    }

    /**
     * Sets height frame.
     * @param height - int
     */
    public void setHeight(float height) {
        this.height = height;
    }

    /**
     * Gets the image.
     * @return The image.
     */
    public IImageReference<TImgWrapper> getImage() {
        return image;
    }

    /**
     * Sets the image.
     * @param image The image.
     */
    public void setImage(IImageReference<TImgWrapper> image) {
        this.image = image;
    }

    @Override
    public KeyframeAnimationFrame<TImgWrapper> clone() {
        KeyframeAnimationFrame<TImgWrapper> frame = new KeyframeAnimationFrame<>();
        frame.image = image;
        frame.x = x;
        frame.y = y;
        frame.width = width;
        frame.height = height;
        return frame;
    }
}
