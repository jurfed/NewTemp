package com.atsisa.gox.framework.configuration;

import java.util.List;
import java.util.Map;

/**
 * Exposes common game configuration properties.
 */
public interface IGameConfiguration {

    /**
     * Game configuration properties.
     * @return map with properties and values for them.
     */
    Map<String, Object> getProperties();

    /**
     * Gets the frame rate.
     * @return frame rate
     */
    int getFPS();

    /**
     * Gets window height.
     * @return window height
     */
    int getHeight();

    /**
     * Gets window width.
     * @return window width
     */
    int getWidth();

    /**
     * Gets the resource description file path.
     * @return resource description file path
     */
    String getResourceDescriptionFile();

    /**
     * Gets the resource path (valid for HTML platform).
     * @return resource path
     */
    String getResourcePath();

    /**
     * Gets list with available resources formats.
     * @return formats list
     */
    List<String> getResourceFormats();

    /**
     * Gets the value indicating whether or not the game should start in fullscreen mode.
     * This setting has meaning only for native java version.
     * @return true if fullscreen mode should be engaged, false otherwise
     */
    boolean getFullscreen();

    /**
     * Gets the value that indicating whether window should be decorated or not.
     * This settings has meaning only for native java version.
     * @return true if window should not be decorated, false otherwise
     */
    boolean isWindowDecorated();

    /**
     * Gets the value indicating whether canvas auto scaling should be enabled.
     * @return the value indicating whether canvas auto scaling should be enabled
     */
    boolean isAutoScale();

    /**
     * Gets the dedicated amount of screens.
     * @return dedicated amount of screens
     */
    int getNumberOfScreens();

    /**
     * Gets the single screen height.
     * @return single screen height
     */
    int getSingleScreenHeight();

    /**
     * Returns id of the div on html page where game should be run.
     * @return id of the div on html page.
     */
    String getGameDivId();

    /**
     * Gets the name of the game.
     * @return the name of the game
     */
    String getGameName();
}
