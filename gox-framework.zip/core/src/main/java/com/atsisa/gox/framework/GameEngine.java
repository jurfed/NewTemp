package com.atsisa.gox.framework;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * Abstract game engine class.
 */
public class GameEngine implements IGameEngine {

    /**
     * Game engine instance reference.
     */
    private static IGameEngine instance;

    /**
     * Game engine components.
     */
    private final GameEngineComponents components;

    /**
     * A value indicating whether the game has been started.
     */
    private boolean gameStarted;

    /**
     * Initializes a new instance of the GameEngine class.
     * @param components game engine components
     */
    @Inject
    public GameEngine(GameEngineComponents components) {
        components.getLogger().trace("GameEngine | ctor");
        GameEngine.instance = this;
        this.components = components;
        this.components.freeze();
    }

    /**
     * Retrieves the currently used game engine implementation.
     * @return the game engine object implementing {@link IGameEngine} interface
     */
    public static IGameEngine current() {
        return instance;
    }

    @Override
    public final IPlatform getPlatform() {
        return components.getPlatform();
    }

    @Override
    public IResourceManager getResourceManager() {
        return components.getResourceManager();
    }

    @Override
    public ISoundManager getSoundManager() {
        return components.getSoundManager();
    }

    @Override
    public IActionManager getActionManager() {
        return components.getActionManager();
    }

    @Override
    public IRenderer getRenderer() {
        return components.getRenderer();
    }

    @Override
    public IViewManager getViewManager() {
        return components.getViewManager();
    }

    @Override
    public IEventBus getEventBus() {
        return components.getEventBus();
    }

    @Override
    public IAnimationFactory getAnimationFactory() {
        return components.getAnimationFactory();
    }

    @Override
    public void startGame(final AbstractGame gameInstance, IGameConfiguration gameConfig) {
        validateGame(gameInstance, gameConfig);
        gameStarted = true;
        getRenderer().onCreate(() -> {
            getRenderer().setRootView(getViewManager().getStage());
            gameInstance.executeOnCreate();
        });
    }

    @Override
    public IGame getGame() {
        return components.getGame();
    }

    @Override
    public ILogger getLogger() {
        return components.getLogger();
    }

    @Override
    public IGameConfiguration getGameConfiguration() {
        return components.getGameConfiguration();
    }

    @Override
    public IConfigurationProvider getConfigurationProvider() {
        return components.getConfigurationProvider();
    }

    @Override
    public Iterable<Screen> getStartScreens() {
        return components.getStartScreens();
    }

    @Override
    public IUtility getUtility() {
        return components.getUtility();
    }

    @Override
    public INetwork getNetwork() {
        return components.getNetwork();
    }

    @Override
    public void dispose() {
        instance = null;
    }

    /**
     * Validates current game and its configuration.
     * @param gameInstance game reference
     * @param gameConfig   game configuration reference
     */
    private void validateGame(IGame gameInstance, IGameConfiguration gameConfig) {
        if (gameInstance == null) {
            throw new IllegalArgumentException("Game cannot be null");
        }
        if (gameConfig == null) {
            throw new IllegalArgumentException("Game configuration cannot be null");
        }
        if (gameStarted) {
            throw new IllegalArgumentException("The game has already been started.");
        }
        if (gameConfig.getWidth() <= 0 || gameConfig.getHeight() <= 0) {
            throw new IllegalArgumentException("Invalid game dimensions.");
        }
    }
}
