package com.atsisa.gox.framework.action;

import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data container for Actions process.
 */
@Reflect_Full
public abstract class ActionData {

}
