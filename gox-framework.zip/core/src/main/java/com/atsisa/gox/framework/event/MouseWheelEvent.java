package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.view.View;

/**
 * Represents mouse wheel event.
 */
public class MouseWheelEvent extends InputEvent {

    /**
     * The amount the mouse was scrolled.
     */
    private int amount;

    /**
     * Initializes a new instance of the MouseWheelEvent class.
     * @param type   input event type
     * @param source source of the event
     * @param amount amount the mouse was scrolled
     */
    public MouseWheelEvent(InputEventType type, View source, int amount) {
        super(type, source);
        this.amount = amount;
    }

    /**
     * Returns amount the mouse was scrolled.
     * @return int
     */
    public int getScrollAmount() {
        return amount;
    }
}
