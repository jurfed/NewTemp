package com.atsisa.gox.framework.view;

import java.util.Comparator;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.IPropertyChangedListener;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectArrays;

/**
 * The ViewGroup class is the base class for all objects that can server as view containers on the stage.
 */
@XmlElement
@Reflect_Full
public class ViewGroupBase extends InteractiveView {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Views comparator.
     */
    private final ViewComparator comparator = new ViewComparator();

    /**
     * Contains all children.
     */
    private ObjectArrayList<View> children;

    /**
     * Listener that listens if child interactive state has been changed.
     */
    private IPropertyChangedListener<Boolean> childInteractiveChangedListener;

    /**
     * Contains amount of total number of interactive children in this group.
     */
    private int numberOfInteractiveChildren;

    /**
     * Initializes a new instance of the ViewGroup class.
     */
    public ViewGroupBase() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link ViewGroupBase} class.
     * @param renderer {@link IRenderer}
     */
    public ViewGroupBase(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
        children = new ObjectArrayList<>(32);
        numberOfInteractiveChildren = 0;
        childInteractiveChangedListener = (source, oldValue, newValue) -> updateNumberOfInteractiveChildren();
    }

    /**
     * Returns the list of children of this ViewGroup.
     * @return the list of children of this ViewGroup
     */
    public Iterable<View> getChildren() {
        return children;
    }

    /**
     * Returns the list of children not casted to particular list type.
     * @return the list of children not casted to particular list type
     */
    public ObjectArrayList<View> getChildrenRaw() {
        return children;
    }

    /**
     * Reorders underlying children in accordance with depth parameter in a memory optimized way (without allocating new objects).
     */
    public void reorder() {
        if (!children.isEmpty()) {
            lv.childrenBackingArray = children.elements();
            ObjectArrays.quickSort(lv.childrenBackingArray, 0, children.size(), comparator);
        }
    }

    /**
     * Returns the number of children of this ViewGroup.
     * @return int
     */
    public int getChildCount() {
        return children.size();
    }

    /**
     * Adds a view to ViewGroup list.
     * @param view {@link View}
     */
    protected void addChild(View view) {
        children.remove(view);

        if (view.getParent() != null && !view.getParent().equals(this)) {
            view.getParent().removeChild(view);
        }
        children.add(view);
        addedInteractiveChild(view);
        view.setParent(this);
        view.redraw();
        reorderChild();
    }

    /**
     * Removes specific View from ViewGroup list.
     * @param view {@link View}
     * @return boolean "false" if view does not belong to this ViewGroup
     */
    protected boolean removeChild(View view) {
        return removeChild(view, true);
    }

    /**
     * Removes from interactive view interactive listener.
     * @param view {@link View}
     */
    private void removedInteractiveChild(View view) {
        if (isChildInteractive(view)) {
            lv.interactiveView = (InteractiveView) view;
            lv.interactiveView.interactive().removePropertyChangedListener(childInteractiveChangedListener);
            if (lv.interactiveView.isInteractive()) {
                numberOfInteractiveChildren--;
                updateInteractiveState();
            }
        }
    }

    /**
     * Adds to interactive view listener, to listen for interactive state changes.
     * @param view {@link View}
     */
    private void addedInteractiveChild(View view) {
        if (isChildInteractive(view)) {
            lv.interactiveView = (InteractiveView) view;
            if (lv.interactiveView.isInteractive()) {
                numberOfInteractiveChildren++;
                updateInteractiveState();
            }
            lv.interactiveView.interactive().addPropertyChangedListener(childInteractiveChangedListener);
        }
    }

    /**
     * Checks if specific child is interactive view.
     * @param view child to check
     * @return boolean value that indicates whether child is interactive view or not.
     */
    private boolean isChildInteractive(View view) {
        return view instanceof InteractiveView;
    }

    /**
     * Updates information about total interactive children in this group.
     */
    private void updateNumberOfInteractiveChildren() {
        numberOfInteractiveChildren = 0;
        children.stream().filter(view -> isChildInteractive(view) && ((InteractiveView) view).isInteractive()).forEach(view -> {
            numberOfInteractiveChildren++;
        });
        updateInteractiveState();
    }

    /**
     * Updates interactive state.
     */
    private void updateInteractiveState() {
        if (numberOfInteractiveChildren > 0 || hasEventListeners()) {
            setInteractive(true);
        } else {
            setInteractive(false);
        }
    }

    /**
     * Removes specific View from ViewGroup list.
     * @param view    {@link View}
     * @param clear boolean indicating whether child view should be cleared
     * @return boolean "false" if view does not belong to this ViewGroup
     */
    protected boolean removeChild(View view, boolean clear) {
        try {
            if (children.remove(view)) {
                view.setParent(null);
                removedInteractiveChild(view);
                if (clear) {
                    view.clear();
                }
                reorderChild();
            } else {
                return false;
            }
        } catch (UnsupportedOperationException e) {
            return false;
        }
        return true;
    }

    /**
     * Removes all view from ViewGroup list.
     */
    protected void removeAll() {
        lv.childrenSize = children.size();
        for (lv.childrenIndex = 0; lv.childrenIndex < lv.childrenSize; lv.childrenIndex++) {
            lv.child = children.get(lv.childrenIndex);
            lv.child.setParent(null);
            removedInteractiveChild(lv.child);
            lv.child.clear();
        }
        children.clear();
        reorderChild();
    }

    /**
     * Draws current view and its children views using rendering.
     */
    @Override
    public void redraw() {
        lv.childrenSize = children.size();
        for (lv.childrenIndex = 0; lv.childrenIndex < lv.childrenSize; lv.childrenIndex++) {
            children.get(lv.childrenIndex).redraw();
        }
        super.redraw();
        reorderChild();
    }

    @Override
    public float getOffsetWidth() {
        float minX = 0;
        float maxX = 0;
        for (View child : getChildren()) {
            float childStartX = child.getX() + child.getOriginX();
            if (childStartX < minX) {
                minX = childStartX;
            }
            float childEndX = childStartX + child.getWidth();
            if (childEndX > maxX) {
                maxX = childEndX;
            }
        }
        return maxX - minX;
    }

    @Override
    public float getOffsetHeight() {
        float minY = 0;
        float maxY = 0;
        for (View child : getChildren()) {
            float childStartY = child.getY() + child.getOriginY();
            if (childStartY < minY) {
                minY = childStartY;
            }
            float childEndY = childStartY + child.getHeight();
            if (childEndY > maxY) {
                maxY = childEndY;
            }
        }
        return maxY - minY;
    }

    /**
     * Disposes all children.
     */
    @Override
    public void dispose() {
        for (View view: children) {
            view.dispose();
        }
        children.clear();
        super.dispose();
    }

    @Override
    public void clear(){
        lv.childrenSize = children.size();
        for (lv.childrenIndex = 0; lv.childrenIndex < lv.childrenSize; lv.childrenIndex++) {
            children.get(lv.childrenIndex).clear();
        }
    }

    /**
     * Triggers event related to ViewGroup child property change.
     */
    public void reorderChild() {
        propertyChanged(ViewType.VIEW_GROUP, ViewPropertyName.CHILD);
    }

    /**
     * View group property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents changes in children collection.
         */
        public static final int CHILD = 1;
    }

    /**
     * View comparator, which compares views based on their depth and time when they were added to the view group base.
     */
    class ViewComparator implements Comparator<Object> {

        int res;

        @Override
        public int compare(Object view1, Object view2) {
            res = Integer.compare(((View) view1).getDepth(), ((View) view2).getDepth());
            return res;
        }
    }

    /**
     * Gets comparator instance used to sort underlying children
     * @return Comparator comparator object for the underlying children.
     */
    protected ViewComparator getComparator() {
        return comparator;
    }

    /**
     * Holder for instances of local variables used in the {@link View} methods.
     */
    class LocalVariables {

        private View child;

        private int childrenIndex;

        private int childrenSize;

        private Object[] childrenBackingArray;

        private InteractiveView interactiveView;
    }

}
