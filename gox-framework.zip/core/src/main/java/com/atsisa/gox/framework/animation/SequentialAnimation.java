package com.atsisa.gox.framework.animation;

import java.util.Arrays;
import java.util.List;

import rx.functions.Action1;

/**
 * Implementation of IAnimation interface, which plays given list of animations one after another.
 */
public class SequentialAnimation extends AbstractAnimation {

    /**
     * List of given animations.
     */
    private final List<IAnimation> animations;

    /**
     * Index of current animation.
     */
    private int currentAnimationPosition;

    /**
     * Constructor receiving list of animations.
     * @param animations given list of animations
     */
    public SequentialAnimation(List<IAnimation> animations) {
        this.animations = animations;
        currentAnimationPosition = 0;
        observeAllAnimations();
    }

    /**
     * Constructor receiving array of animations.
     * @param animations given list of animations
     */
    public SequentialAnimation(IAnimation... animations) {
        this.animations = Arrays.asList(animations);
        currentAnimationPosition = 0;
        observeAllAnimations();
    }

    /**
     * Sets an Observer for all animations on the animations list.
     */
    private void observeAllAnimations() {
        for (IAnimation animation : animations) {
            observeCurrentAnimation(animation);
        }
    }

    /**
     * Sets an Observer, which plays next animation when current one ends.
     * @param animation animation to observe
     */
    private void observeCurrentAnimation(IAnimation animation) {
        animation.getAnimationStateObservable().subscribe(new Action1<AnimationState>() {

            @Override
            public void call(AnimationState animationState) {
                if (animationState == AnimationState.STOPPED) {
                    if (!isStopped()) {
                        playNextAnimation();
                    }
                }
            }
        });
    }

    /**
     * Plays next animation if there is one.
     */
    private void playNextAnimation() {
        if (isCurrentAnimationLastOneTheList()) {
            stop();
            return;
        }

        currentAnimationPosition++;
        animations.get(currentAnimationPosition).play();
    }

    /**
     * Checks if current animation is last on the animations list.
     * @return true if current animation is last on the list, false otherwise
     */
    private boolean isCurrentAnimationLastOneTheList() {
        return currentAnimationPosition >= animations.size() - 1;
    }

    @Override
    public synchronized void play() {
        if (isPlaying()) {
            return;
        }

        setAnimationState(AnimationState.PLAYING);
        animations.get(currentAnimationPosition).play();
    }

    @Override
    public synchronized void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        setAnimationState(AnimationState.PAUSED);
        animations.get(currentAnimationPosition).pause();
    }

    @Override
    public synchronized void stop() {
        if (isStopped()) {
            return;
        }

        setAnimationState(AnimationState.STOPPED);
        animations.get(currentAnimationPosition).stop();
        currentAnimationPosition = 0;
    }
}
