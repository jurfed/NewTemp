package com.atsisa.gox.framework.exception;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * GameException class describes all kinds of game errors.
 */
@Reflect_Mini
public abstract class GameException extends RuntimeException implements ILocalizableException {

    /**
     * Initializes a new instance of the GameException using specific message.
     * @param message error message
     */
    public GameException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the GameException using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public GameException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the GameException using specific cause.
     * @param cause internal cause of error
     */
    public GameException(Throwable cause) {
        super(cause);
    }
}
