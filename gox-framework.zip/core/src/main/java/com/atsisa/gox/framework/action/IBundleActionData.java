package com.atsisa.gox.framework.action;

import java.util.List;

import com.gwtent.reflection.client.Reflectable;

/**
 * Represents an action data which can contain inner actions.
 */
@Reflectable
public interface IBundleActionData {

    /**
     * Sets the inner actions.
     * @param actions The actions
     */
    void setActions(List<Action> actions);

    /**
     * Gets the inner actions.
     * @return Inner actions
     */
    List<Action> getActions();
}
