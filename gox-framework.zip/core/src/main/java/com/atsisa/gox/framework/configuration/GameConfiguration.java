package com.atsisa.gox.framework.configuration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * A representation of game configuration properties.
 */
public class GameConfiguration implements IGameConfiguration {

    /**
     * Default resource file path.
     */
    public static final String DEFAULT_RESOURCE_FILE = "resources.xml";

    /**
     * Game configuration properties.
     */
    private final Map<String, Object> properties;

    /**
     * Frame per seconds.
     */
    private int fps;

    /**
     * Window width.
     */
    private int width;

    /**
     * Window height.
     */
    private int height;

    /**
     * Resource path.
     */
    private String resourcePath;

    /**
     * Resource description file.
     */
    private String resourceDescriptionFile;

    /**
     * Resource formats.
     */
    private List<String> resourceFormats;

    /**
     * Fullscreen flag.
     */
    private boolean fullscreen;

    /**
     * Auto scale flag.
     */
    private boolean autoScale;

    /**
     * A dedicated amount of screens.
     */
    private int numberOfScreens;

    /**
     * A boolean value that indicates whether game window should be decorated or not.
     */
    private boolean windowDecorated;

    /**
     * Id of the div on html page, where game should be run.
     */
    private String gameDivId;

    /**
     * The name of the game.
     */
    private String gameName = StringUtility.EMPTY;

    /**
     * Initializes a new instance of the {@link GameConfiguration} class.
     */
    public GameConfiguration() {
        fps = 60;
        width = 800;
        height = 600;
        numberOfScreens = 1;
        autoScale = true;
        resourceDescriptionFile = GameConfiguration.DEFAULT_RESOURCE_FILE;
        properties = new HashMap<>();
        gameDivId = "game-root";
    }

    /**
     * Initializes a new instance of the {@link GameConfiguration} class.
     * @param width  window width
     * @param height window height
     */
    public GameConfiguration(int width, int height) {
        this();
        this.width = width;
        this.height = height;
    }

    @Override
    public Map<String, Object> getProperties() {
        return properties;
    }

    @Override
    public int getFPS() {
        return fps;
    }

    /**
     * Sets the frame rate.
     * @param frameRate frame rate
     */
    public final void setFPS(int frameRate) {
        fps = frameRate;
    }

    @Override
    public int getWidth() {
        return width;
    }

    /**
     * Sets the window width.
     * @param width window width
     */
    public final void setWidth(int width) {
        this.width = width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    /**
     * Sets the window height.
     * @param height window height
     */
    public final void setHeight(int height) {
        this.height = height;
    }

    @Override
    public String getResourcePath() {
        return resourcePath;
    }

    /**
     * Sets the resource path (valid for HTML platform).
     * @param resourcePath resource path
     */
    public final void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    @Override
    public String getResourceDescriptionFile() {
        return resourceDescriptionFile;
    }

    /**
     * Sets the resource description file path.
     * @param resourceDescriptionFile resource description file path
     */
    public final void setResourceDescriptionFile(String resourceDescriptionFile) {
        this.resourceDescriptionFile = resourceDescriptionFile;
    }

    @Override
    public List<String> getResourceFormats() {
        return resourceFormats;
    }

    /**
     * Sets the supported resource formats.
     * @param resourceFormats list with formats
     */
    public final void setResourceFormats(List<String> resourceFormats) {
        this.resourceFormats = resourceFormats;
    }

    @Override
    public boolean getFullscreen() {
        return fullscreen;
    }

    @Override
    public boolean isWindowDecorated() {
        return windowDecorated;
    }

    /**
     * Sets the value indicating whether or not game window should be decorated or not.
     * @param windowDecorated window decorated flag
     */
    public void setWindowDecorated(boolean windowDecorated) {
        this.windowDecorated = windowDecorated;
    }

    /**
     * Sets the value indicating whether or not the game should start in fullscreen mode.
     * @param fullscreen fullscreen flag
     */
    public final void setFullscreen(boolean fullscreen) {
        this.fullscreen = fullscreen;
    }

    @Override
    public boolean isAutoScale() {
        return autoScale;
    }

    /**
     * Sets the value indicating whether canvas auto scaling should be enabled.
     * @param shouldAutoScale the value indicating whether canvas auto scaling should be enabled
     */
    public final void setAutoScale(boolean shouldAutoScale) {
        autoScale = shouldAutoScale;
    }

    /**
     * Sets the dedicated amount of screens used by the game. The default value is one.
     * @param numberOfScreens number of screens
     */
    public final void setNumberOfScreens(int numberOfScreens) {
        this.numberOfScreens = numberOfScreens;
    }

    @Override
    public int getNumberOfScreens() {
        return numberOfScreens;
    }

    @Override
    public int getSingleScreenHeight() {
        return height / numberOfScreens;
    }

    @Override
    public String getGameDivId() {
        return gameDivId;
    }

    @Override
    public String getGameName() {
        return gameName;
    }

    /**
     * Sets the name of the game.
     * @param gameName {@link String}
     */
    public final void setGameName(String gameName) {
        this.gameName = gameName;
    }

    /**
     * Sets id of the div on html page, where game should be run.
     * @param gameDivId id of the div
     */
    public final void setGameDivId(String gameDivId) {
        this.gameDivId = gameDivId;
    }

}
