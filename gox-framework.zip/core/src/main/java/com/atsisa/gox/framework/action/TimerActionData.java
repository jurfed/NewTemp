package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Common data for timer-related actions.
 */
@XmlElement
public class TimerActionData extends ActionData {

    /**
     * The timer name.
     */
    @XmlAttribute
    private String timerName;

    /**
     * Gets the timer name.
     * @return the timer name
     */
    public String getTimerName() {
        return timerName;
    }

    /**
     * Sets the timer name.
     * @param timerName the timer name
     */
    public void setTimerName(String timerName) {
        this.timerName = timerName;
    }
}
