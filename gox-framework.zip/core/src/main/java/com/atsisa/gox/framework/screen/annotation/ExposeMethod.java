package com.atsisa.gox.framework.screen.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.model.property.EventListenerProperty;

/**
 * View binding annotation for screens.
 * <p>
 * Methods decorated with {@link ExposeMethod} annotation can be invoked from XML binding in the following cases.
 * </p>
 * 1. Using the UpdateScreen action in the action queue descriptor, for example:
 * <p>
 * <code> &lt;UpdateScreen screenId="myScreen" methodName="exposedMethod" /&gt; </code>
 * </p>
 * <p>
 * For this type exposed setMethod must be parameterless.
 * </p>
 * 2. Using screen setMethod notation (#exposedMethod) in {@link EventListenerProperty} view properties, for example:
 * <p>
 * <code> &lt;ButtonView onRelease="#exposedMethod" /&gt; </code>
 * </p>
 * For this type exposed setMethod can be either parameterless or have exactly one {@link InputEvent} parameter.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ExposeMethod {

}
