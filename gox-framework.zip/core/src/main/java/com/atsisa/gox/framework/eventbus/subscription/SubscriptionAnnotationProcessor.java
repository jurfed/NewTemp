package com.atsisa.gox.framework.eventbus.subscription;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.gwtent.reflection.client.Reflectable;

/**
 * Basic annotation processor evaluating @Subscribe marked methods.
 */
@Reflectable
public class SubscriptionAnnotationProcessor {

    /**
     * Platform-dependant reflection reference.
     */
    private IReflection reflection;

    /**
     * Default constructor.
     * @param reflection reflection reference
     */
    public SubscriptionAnnotationProcessor(IReflection reflection) {
        this.reflection = reflection;
    }

    /**
     * Returns the metadata list for annotated ({@link Subscribe}) methods from specific object.
     * @param object the object from which metadata will be taken
     * @return the metadata list
     * @throws ReflectionException throws when error with reflection will occur
     */
    public List<AnnotatedSubscriptionMetadata> extractAnnotatedMethods(Object object) throws ReflectionException {
        List<AnnotatedSubscriptionMetadata> annotatedMethods = new ArrayList<>();
        Class<?> classReference = object.getClass();
        while (classReference != null) {
            for (Method method : reflection.getMethods(classReference)) {
                if (method.getAnnotation(Subscribe.class) != null && isSubscribeMethodValid(method)) {
                    annotatedMethods.add(new AnnotatedSubscriptionMetadata(object, method, extractSubscriptionMethodParameterType(method)));
                }
            }
            classReference = reflection.getSuperClass(classReference);
        }
        return annotatedMethods;
    }

    /**
     * Evaluates whether @Subscribe was used on proper method.
     * @param method @Subscribe annotated method
     * @return true if method has valid definition, false otherwise.
     */
    private boolean isSubscribeMethodValid(Method method) {
        if (method.getParameterTypes().length != 1) {
            return false;
        }
        if (!method.isPublic()) {
            return false;
        }
        if (method.isAbstract() || method.isStatic()) {
            return false;
        }
        if (!method.getReturnType().equals(Void.TYPE.getName())) {
            return false;
        }
        return true;
    }

    /**
     * Extracts type of events that has to be matched in the bus.
     * @param method @Subscribe annotated method
     * @return argument class type in a full package string representation
     */
    private Class extractSubscriptionMethodParameterType(Method method) throws ReflectionException {
        return reflection.getClassForName(method.getParameterTypes()[0]);
    }
}
