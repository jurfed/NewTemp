package com.atsisa.gox.framework.rendering;

/**
 * Abstract shape view rendering.
 */
public abstract class AbstractShapeRenderer extends InteractiveViewRenderer {

    /**
     * Initializes a new instance of the AbstractShapeRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public AbstractShapeRenderer(IRenderer renderer) {
        super(renderer);
    }

}
