package com.atsisa.gox.framework.view;

/**
 * Property change listener interface,
 * handles property changes.
 */
@FunctionalInterface
public interface IViewPropertyChangedListener {

    /**
     * Called when a property changes its value in particular view.
     * @param view     - View
     * @param viewType - ViewType
     * @param property - int
     */
    void propertyChanged(View view, ViewType viewType, int property);

}
