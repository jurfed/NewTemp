package com.atsisa.gox.framework.view.spi;

import com.atsisa.gox.framework.view.View;

/**
 * Provides methods for visual activation and deactivation
 * of {@link View}s.
 */
public interface IViewActivator {

    /**
     * Alters given view so that it
     * becomes visually active.
     * @param view A view to activate.
     */
    void activate(View view);

    /**
     * Alters given view so that
     * it becomes visually inactive.
     * @param view A view to deactivate.
     */
    void deactivate(View view);
}
