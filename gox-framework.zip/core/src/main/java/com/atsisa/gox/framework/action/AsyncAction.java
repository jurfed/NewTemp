package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * An Asynchronous action that will be automatically finished at the end of execution setMethod.
 * @param <T> the type extends ActionData
 */
public abstract class AsyncAction<T extends ActionData> extends Action<T> {

    /**
     * Platform reference.
     */
    private final IPlatform platform;

    /**
     * Initializes a new instance of the {@link AsyncAction} class.
     */
    public AsyncAction() {
        platform = GameEngine.current().getPlatform();
    }

    /**
     * Initializes a new instance of the {@link AsyncAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     * @param platform {@link IPlatform}
     */
    public AsyncAction(ILogger logger, IEventBus eventBus, IPlatform platform) {
        super(logger, eventBus);
        this.platform = platform;
    }

    @Override
    void doExecute() {
        platform.invokeLater(AsyncAction.super::doExecute);
    }
}
