package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;

/**
 * Action binding event listener. Registers a list of action bindings for particular interactive view. Listens for input events from that view and delegate
 * particular event type to an event listener defined in ActionBinding object.
 */
public class ActionBindingEventListener implements IEventListener<InputEvent> {

    /**
     * Action binding map. Maps input event types to lists of action bindings.
     */
    private Map<InputEventType, List<ActionBinding>> bindingMap;

    /**
     * Initializes a new instance of the ActionBindingEventListener class.
     * @param bindingList a list of action bindings for particular interactive view
     */
    public ActionBindingEventListener(List<ActionBinding> bindingList) {
        bindingMap = new HashMap<>();
        for (ActionBinding binding : bindingList) {
            if (!bindingMap.containsKey(binding.getEventType())) {
                bindingMap.put(binding.getEventType(), new ArrayList<>());
            }
            bindingMap.get(binding.getEventType()).add(binding);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onEvent(InputEvent event) {
        List<ActionBinding> bindingList = bindingMap.get(event.getType());
        if (bindingList != null) {
            for (ActionBinding binding : bindingList) {
                binding.getEventListener().onEvent(event);
            }
        }
    }
}
