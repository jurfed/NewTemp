package com.atsisa.gox.framework.view;

/**
 * Describe possible interactive view states.
 */
public enum InteractiveViewState {

    /**
     * Const normal state.
     */
    NORMAL_STATE,

    /**
     * Const over state.
     */
    OVER_STATE,

    /**
     * Const down state.
     */
    DOWN_STATE

}
