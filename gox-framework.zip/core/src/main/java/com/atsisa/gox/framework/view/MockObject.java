package com.atsisa.gox.framework.view;

/**
 * Mock object that will have to be removed after interfaces refactoring.
 */
public class MockObject implements Comparable<MockObject> {

    @Override
    public int compareTo(MockObject mockObject) {
        return 0;
    }
}
