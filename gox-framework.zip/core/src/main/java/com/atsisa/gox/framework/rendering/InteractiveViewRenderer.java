package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.InteractiveView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Abstraction interactive view rendering.
 */
public abstract class InteractiveViewRenderer extends LayerRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Map with touch input event delegates.
     */
    private final IInputEventDelegate touchInputEventDelegate;

    /**
     * Map with keyboard input event delegates.
     */
    private final IInputEventDelegate keyboardInputEventDelegate;

    /**
     * Initializes a new instance of the {@link InteractiveViewRenderer} class using custom rendering.
     * @param renderer rendering reference
     */
    public InteractiveViewRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
        touchInputEventDelegate = getRenderer().getTouchInputEventDelegate();
        keyboardInputEventDelegate = getRenderer().getKeyboardInputEventDelegate();
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        if (viewType == ViewType.INTERACTIVE_VIEW) {
            lv.leftChanges = changes;
            if (BitUtility.isSet(lv.leftChanges, InteractiveView.ViewPropertyName.STATE)) {
                lv.leftChanges = BitUtility.unset(lv.leftChanges, InteractiveView.ViewPropertyName.STATE);
            }
            if (BitUtility.isSet(lv.leftChanges, InteractiveView.ViewPropertyName.INTERACTIVE)) {
                updateInteractive((InteractiveView) view);
                lv.leftChanges = BitUtility.unset(lv.leftChanges, InteractiveView.ViewPropertyName.INTERACTIVE);
            }
            return lv.leftChanges;
        } else if (viewType == ViewType.VIEW && BitUtility.isSet(changes, View.ViewPropertyName.VISIBLE)) {
            updateInteractive((InteractiveView) view);
        }
        return super.render(view, viewType, changes);
    }

    /**
     * Called when in specific interactive view info about interactive was changed.
     * @param interactiveView interactive interactiveView
     */
    protected void updateInteractive(InteractiveView interactiveView) {
        if (interactiveView.isInteractive() && interactiveView.isVisible()) {
            touchInputEventDelegate.bind(interactiveView, getViewLayer(interactiveView));
        } else {
            touchInputEventDelegate.unbind(interactiveView);
        }
    }

    /**
     * Set to specific interactive view keyboard input event delegate.
     * @param interactiveView {@link InteractiveView}
     */
    void setKeyboardEventDelegate(InteractiveView interactiveView) {
        keyboardInputEventDelegate.bind(interactiveView, getViewLayer(interactiveView));
    }

    @Override
    public boolean dispose(View view) {
        touchInputEventDelegate.unbind((InteractiveView) view);
        keyboardInputEventDelegate.unbind((InteractiveView) view);
        return super.dispose(view);
    }

    /**
     * Holder for instances of local variables used in the {@link InteractiveViewRenderer} render method.
     */
    private class LocalVariables {

        private int leftChanges;

    }
}
