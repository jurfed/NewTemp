package com.atsisa.gox.framework;

import java.util.Set;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * Game engine components container.
 */
public class GameEngineComponents {

    /**
     * The main rendering.
     */
    private IRenderer renderer;

    /**
     * A resource manager.
     */
    private IResourceManager resourceManager;

    /**
     * A sound manager.
     */
    private ISoundManager soundManager;

    /**
     * A view manager.
     */
    private IViewManager viewManager;

    /**
     * An action manager.
     */
    private IActionManager actionManager;

    /**
     * A logger.
     */
    private ILogger logger;

    /**
     * An utility container object.
     */
    private IUtility utility;

    /**
     * A network utility object.
     */
    private INetwork network;

    /**
     * A configuration provider.
     */
    private IConfigurationProvider configurationProvider;

    /**
     * A game reference.
     */
    private IGame game;

    /**
     * A game configuration reference.
     */
    private IGameConfiguration gameConfiguration;

    /**
     * A game platform.
     */
    private IPlatform platform;

    /**
     * Instance of event bus.
     */
    private IEventBus eventBus;

    /**
     * The animation factory.
     */
    private IAnimationFactory animationFactory;

    /**
     * Start screens.
     */
    private Iterable<Screen> startScreens;

    /**
     * A value indicating whether it is no longer possible to use setters in this container.
     */
    private boolean frozen = false;

    /**
     * Gets start startScreens.
     * @return start screens
     */
    public Iterable<Screen> getStartScreens() {
        return startScreens;
    }

    /**
     * Sets start startScreens.
     * @param screens start screens
     */
    @Inject
    public void setStartScreens(Set<Screen> screens) {
        validateState();
        this.startScreens = screens;
    }

    /**
     * Gets the main rendering reference.
     * @return a rendering reference
     */
    public IRenderer getRenderer() {
        return renderer;
    }

    /**
     * Sets the main rendering reference.
     * @param renderer a rendering reference
     */
    @Inject
    public void setRenderer(IRenderer renderer) {
        validateState();
        this.renderer = renderer;
    }

    /**
     * Gets a resource manager.
     * @return a resource manager
     */
    IResourceManager getResourceManager() {
        return resourceManager;
    }

    /**
     * Sets a resource manager.
     * @param resourceManager a resource manager
     */
    @Inject
    public void setResourceManager(IResourceManager resourceManager) {
        validateState();
        this.resourceManager = resourceManager;
    }

    /**
     * Gets sound manager.
     * @return a sound manager
     */
    ISoundManager getSoundManager() {
        return soundManager;
    }

    /**
     * Sets a sound manager.
     * @param soundManager a sound manager
     */
    @Inject
    public void setSoundManager(ISoundManager soundManager) {
        validateState();
        this.soundManager = soundManager;
    }

    /**
     * Gets a view manager.
     * @return a view manager
     */
    IViewManager getViewManager() {
        return viewManager;
    }

    /**
     * Sets a view manager.
     * @param viewManager a view manager
     */
    @Inject
    public void setViewManager(IViewManager viewManager) {
        validateState();
        this.viewManager = viewManager;
    }

    /**
     * Gets an action manager.
     * @return an action manager
     */
    IActionManager getActionManager() {
        return actionManager;
    }

    /**
     * Sets an action manager.
     * @param actionManager an action manager
     */
    @Inject
    public void setActionManager(IActionManager actionManager) {
        validateState();
        this.actionManager = actionManager;
    }

    /**
     * Gets a platform implementation.
     * @return IPlatform.
     */
    IPlatform getPlatform() {
        return platform;
    }

    /**
     * Sets a platform.
     * @param platform a platform implementation
     */
    @Inject
    public void setPlatform(IPlatform platform) {
        validateState();
        this.platform = platform;
    }

    /**
     * Gets a logger.
     * @return a logger
     */
    ILogger getLogger() {
        return logger;
    }

    /**
     * Sets a logger.
     * @param logger a logger
     */
    @Inject
    public void setLogger(ILogger logger) {
        validateState();
        this.logger = logger;
    }

    /**
     * Gets a utility container.
     * @return a utility container
     */
    IUtility getUtility() {
        return utility;
    }

    /**
     * Sets a utility container.
     * @param utility a utility container
     */
    @Inject
    public void setUtility(IUtility utility) {
        validateState();
        this.utility = utility;
    }

    /**
     * Gets a network utility object.
     * @return a network utility object
     */
    INetwork getNetwork() {
        return network;
    }

    /**
     * Sets a network utility object.
     * @param network a network utility object
     */
    @Inject
    public void setNetwork(INetwork network) {
        validateState();
        this.network = network;
    }

    /**
     * Gets the game reference.
     * @return game reference
     */
    public IGame getGame() {
        return game;
    }

    /**
     * Sets the game reference.
     * @param game game reference
     */
    @Inject
    public void setGame(IGame game) {
        validateState();
        this.game = game;
    }

    /**
     * Gets the game configuration reference.
     * @return game configuration reference
     */
    public IGameConfiguration getGameConfiguration() {
        return gameConfiguration;
    }

    /**
     * Sets the game configuration reference.
     * @param gameConfiguration game configuration reference
     */
    @Inject
    public void setGameConfiguration(IGameConfiguration gameConfiguration) {
        validateState();
        this.gameConfiguration = gameConfiguration;
    }

    /**
     * Gets a configuration provider.
     * @return a configuration provider
     */
    IConfigurationProvider getConfigurationProvider() {
        return configurationProvider;
    }

    /**
     * Sets a configuration provider.
     * @param configurationProvider a configuration provider
     */
    @Inject
    public void setConfigurationProvider(IConfigurationProvider configurationProvider) {
        validateState();
        this.configurationProvider = configurationProvider;
    }

    /**
     * Gets the animation factory.
     * @return The animation factory.
     */
    public IAnimationFactory getAnimationFactory() {
        return animationFactory;
    }

    /**
     * Sets the animation factory.
     * @param animationFactory The animation factory.
     */
    @Inject
    public void setAnimationFactory(IAnimationFactory animationFactory) {
        validateState();
        this.animationFactory = animationFactory;
    }

    /**
     * Gets the event bus reference.
     * @return instance of event bus
     */
    public IEventBus getEventBus() {
        return eventBus;
    }

    /**
     * Sets the event bus reference.
     * @param eventBus event bus instance to set
     */
    @Inject
    public void setEventBus(IEventBus eventBus) {
        this.eventBus = eventBus;
    }

    /**
     * Freezes the components so that using setters will no longer be possible.
     */
    void freeze() {
        frozen = true;
    }

    /**
     * Validates if the current instance was frozen and throws an exception if it was.
     */
    private void validateState() {
        if (frozen) {
            throw new UnsupportedOperationException("Cannot modify a reference of the GameEngine component!");
        }
    }
}
