package com.atsisa.gox.framework.view;

import java.util.List;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ListViewProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.AbstractImageResource;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ParticleEffectorsConverter;
import com.atsisa.gox.framework.serialization.converter.ParticleInitializersConverter;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a particles on the stage.
 */
@Reflectable
@XmlElement
public class ParticleView extends View {

    /**
     * Max number of particles.
     */
    @XmlAttribute(type = Integer.class)
    private final ObservableProperty<Integer> maxParticles = new ObservableProperty<>(Integer.class, 0);

    /**
     * Number of particles generated per second.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> particlesPerSecond = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.PARTICLES_PER_SEC,
            0);

    /**
     * Particle image resource.
     */
    @XmlAttribute(type = AbstractImageResource.class, converters = ResourceRefConverter.class)
    private final ViewProperty<AbstractImageResource> imageResource = new ViewProperty<>(AbstractImageResource.class, this, ViewType.IMAGE_VIEW,
            ImageView.ViewPropertyName.IMAGE);

    /**
     * A list of initializers.
     */
    @XmlElement(type = List.class, converters = ParticleInitializersConverter.class)
    private final ListViewProperty<MockObject> initializers = new ListViewProperty<>(this, ViewType.PARTICLE_VIEW, ViewPropertyName.INITIALIZERS);

    /**
     * A list of effectors.
     */
    @XmlElement(type = List.class, converters = ParticleEffectorsConverter.class)
    private final ListViewProperty<MockObject> effectors = new ListViewProperty<>(this, ViewType.PARTICLE_VIEW, ViewPropertyName.EFFECTORS);

    /**
     * Initializes a new instance of the ParticleView class.
     */
    public ParticleView() {
        checkGL();
    }

    /**
     * Initializes a new instance of the ParticleView class.
     * @param renderer a rendering reference
     */
    public ParticleView(IRenderer renderer) {
        super(renderer);
        checkGL();
    }

    /**
     * Checks if the GL context is available.
     */
    private void checkGL() {
        if (!getRenderer().hasGL()) {
            throw new AssertionError("GL context is unavailable!");
        }
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (skin.getViewType() == ParticleView.class) {
            ParticleView skinView = (ParticleView) skin.getView();
            if (initializers.hasDefaultValue()) {
                // this.setInitializers(skinView.getInitializers());
            }
            if (effectors.hasDefaultValue()) {
                setEffectors(skinView.getEffectors());
            }
            if (particlesPerSecond.hasDefaultValue()) {
                setParticlesPerSecond(skinView.getParticlesPerSecond());
            }
            if (maxParticles.hasDefaultValue()) {
                setMaxParticles(skinView.getMaxParticles());
            }
            if (imageResource.hasDefaultValue()) {
                setImageResource(skinView.getImageResource());
            }
        }
    }

    /**
     * Sets the maximal amount of produced particles.
     * @param maxParticles maximal amount of produced particles
     */
    public void setMaxParticles(Integer maxParticles) {
        this.maxParticles.set(maxParticles);
    }

    /**
     * Gets the maximal amount of produced particles.
     * @return maximal amount of produced particles
     */
    public Integer getMaxParticles() {
        return maxParticles.get();
    }

    /**
     * Gets the max particles property.
     * @return the max particles property
     */
    public IObservableProperty<Integer> maxParticles() {
        return maxParticles;
    }

    /**
     * Sets the image resource for a single particle.
     * @param image image resource for a single particle
     */
    public void setImageResource(AbstractImageResource image) {
        imageResource.set(image);
    }

    /**
     * Gets the image resource for a single particle.
     * @return image resource for a single particle
     */
    public AbstractImageResource getImageResource() {
        return imageResource.get();
    }

    /**
     * Gets the image resource property.
     * @return the image resource property
     */
    public IObservableProperty<AbstractImageResource> imageResource() {
        return imageResource;
    }

    /**
     * Gets a list of particle initializers.
     * @return list of particle initializers
     */
    @SuppressWarnings("unchecked")
    public /* List<Initializer> */List<Object> getInitializers() {
        return initializers.get();
    }

    /**
     * Sets a list of particle initializers.
     * @param initializers list of particle initializers
     */
    public void setInitializers(/* List<Initializer> */List<Object> initializers) {
        this.initializers.set(initializers);
    }

    /**
     * Gets the initializers property.
     * @return the initializers property
     */
    public IObservableProperty<List> initializers() {
        return initializers;
    }

    /**
     * Gets a list of particle effectors.
     * @return list of particle effectors
     */
    @SuppressWarnings("unchecked")
    public /* List<Effector> */List<Object> getEffectors() {
        return effectors.get();
    }

    /**
     * Sets a list of particle effectors.
     * @param effectors list of particle effectors
     */
    public void setEffectors(/* List<Effector> */List<Object> effectors) {
        this.effectors.set(effectors);
    }

    /**
     * Gets the effectors property.
     * @return the effectors property
     */
    public IObservableProperty<List> effectors() {
        return effectors;
    }

    /**
     * Gets the amount of particles generated per second.
     * @return amount of particles generated per second
     */
    public Integer getParticlesPerSecond() {
        return particlesPerSecond.get();
    }

    /**
     * Sets the amount of particles generated per second.
     * @param particlesPerSecond amount of particles generated per second
     */
    public void setParticlesPerSecond(Integer particlesPerSecond) {
        this.particlesPerSecond.set(particlesPerSecond);
    }

    /**
     * Gets the particles per second property.
     * @return the particles per second property
     */
    public IObservableProperty<Integer> particlesPerSecond() {
        return particlesPerSecond;
    }

    /**
     * Updates the initializers.
     */
    public void updateInitializers() {
        propertyChanged(ViewType.PARTICLE_VIEW, ViewPropertyName.INITIALIZERS);
    }

    /**
     * Updates the effectors.
     */
    public void updateEffectors() {
        propertyChanged(ViewType.PARTICLE_VIEW, ViewPropertyName.EFFECTORS);
    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getParticlesPerSecond setMethod.
         */
        public static final int PARTICLES_PER_SEC = 1;

        /**
         * Represents a view property accessible via getInitializers setMethod.
         */
        public static final int INITIALIZERS = 1 << 1;

        /**
         * Represents a view property accessible via getEffectors setMethod.
         */
        public static final int EFFECTORS = 1 << 2;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }
}
