package com.atsisa.gox.framework.action;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the core action types which could be created declaratively using XML.
 */
@Reflect_Mini
public class CommonActionModule extends AbstractActionModule {

    /**
     * Core actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/framework/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerAction("Pause", PauseAction.class);
        registerAction("Bundle", BundleAction.class);
        registerAction("PlaySound", PlaySoundAction.class);
        registerAction("StopSound", StopSoundAction.class);
        registerAction("StopAllSounds", StopAllSoundsAction.class);
        registerAction("PauseSound", PauseSoundAction.class);
        registerAction("ShowScreen", ShowScreenAction.class);
        registerAction("HideScreen", HideScreenAction.class);
        registerAction("FadeInScreen", FadeInScreenAction.class);
        registerAction("FadeOutScreen", FadeOutScreenAction.class);
        registerAction("ToggleScreen", ToggleScreenAction.class);
        registerAction("UpdateScreen", UpdateScreenAction.class);
        registerAction("DestroyPausedQueues", DestroyPausedQueuesAction.class);
        registerAction("ExecuteNext", ExecuteNextAction.class);
        registerAction("ExecuteNow", ExecuteNowAction.class);
        registerAction("PlayMovie", PlayMovieAction.class);
        registerAction("StopMovie", StopMovieAction.class);
        registerAction("LoopBundle", LoopBundleAction.class);

        registerAction("StartTimer", StartTimerAction.class);
        registerAction("CancelTimer", CancelTimerAction.class);
        registerAction("WaitForTimer", WaitForTimerAction.class);

        registerAction("ToggleViewVisibility", ToggleViewVisibilityAction.class);
        registerAction("ParallelBundle", ParallelBundleAction.class);
        registerAction("ChangeViewVisibility", ChangeViewVisibilityAction.class);

    }

}
