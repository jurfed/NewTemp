package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Base class, which contains sound id and sound manager.
 */
public abstract class SoundAction extends SyncAction<SoundActionData> {

    /**
     * Data about sound.
     */
    private SoundActionData data;

    /**
     * Reference to sound manager.
     */
    protected final ISoundManager soundManager;

    /**
     * Constructs action with default sound manager.
     */
    public SoundAction() {
        soundManager = GameEngine.current().getSoundManager();
    }

    /**
     * Initializes a new instance of the PlaySoundAction class.
     * @param logger       a logger reference.
     * @param eventBus     an eventBus reference.
     * @param soundManager a soundManager reference.
     */
    public SoundAction(ILogger logger, IEventBus eventBus, ISoundManager soundManager) {
        super(logger, eventBus);
        this.soundManager = soundManager;
    }

    /**
     * Returns SoundActionData.
     * @return SoundActionData reference
     */
    SoundActionData getData() {
        return data;
    }

    @Override
    public Class<SoundActionData> getActionDataType() {
        return SoundActionData.class;
    }

    @Override
    protected void validate() throws ValidationException {
        if (data == null) {
            throw new ValidationException("Action data cannot be null.");
        }
    }

    @Override
    protected void grabData() {
        data = actionData;
        if (data.getSoundId() == null) {
            logger.warn("Sound id is not set.");
        }
    }

    @Override
    protected void reset() {
        data = null;
    }
}
