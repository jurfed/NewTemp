package com.atsisa.gox.framework.animation;

/**
 * An animation controller handling cross-cutting animation concerns.
 */
public interface IAnimationController<TAnim extends IAnimation> {

    /**
     * Starts to play the animation that is stopped.
     * @param animation The animation to play.
     */
    void play(TAnim animation);

    /**
     * Pauses the animation that is playing.
     * @param animation The animation to pause.
     */
    void pause(TAnim animation);

    /**
     * Resumes the animation that once has been paused.
     * @param animation The animation to resume.
     */
    void resume(TAnim animation);

    /**
     * Stops the animation that is paused or is playing.
     * @param animation The animation to stop.
     */
    void stop(TAnim animation);
}
