package com.atsisa.gox.framework.utility.timer;

import com.atsisa.gox.framework.event.TimerCanceledEvent;
import com.atsisa.gox.framework.event.TimerFinishedEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event bus based implementation of a reel spin timer.
 */
@Reflectable(fields = false)
class Timer implements ITimer {

    /**
     * EventBus reference.
     */
    private final IEventBus eventBus;

    /**
     * The name.
     */
    private final String name;

    /**
     * The renderer.
     */
    private final IRenderer renderer;

    /**
     * The logger.
     */
    private final ILogger logger;

    /**
     * The time span.
     */
    private int timeSpan;

    /**
     * A value indicating whether this timer has been canceled.
     */
    private boolean canceled;

    /**
     * A value indicating whether this timer is active.
     */
    private boolean active;

    /**
     * The timeout object.
     */
    private Timeout timeout;

    /**
     * Creates a {@link Timer} object.
     * @param name     The name of the timer.
     * @param timeSpan time span for invoke {@link TimerFinishedEvent} in milliseconds.
     * @param eventBus event bus reference.
     * @param renderer The renderer.
     * @param logger   The logger.
     */
    public Timer(String name, int timeSpan, IEventBus eventBus, IRenderer renderer, ILogger logger) {
        this.eventBus = eventBus;
        this.timeSpan = timeSpan;
        this.name = name;
        this.renderer = renderer;
        this.logger = logger;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getTimeSpan() {
        return timeSpan;
    }

    @Override
    public void setTimeSpan(int timeSpan) {
        if (timeSpan <= 0) {
            throw new IllegalArgumentException("The time span must be a positive integer.");
        }
        if (active) {
            throw new IllegalStateException("Cannot change the time span of an active timer.");
        }
        this.timeSpan = timeSpan;
    }

    @Override
    public boolean isCanceled() {
        return canceled;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public void start() {
        if (active) {
            return;
        }

        active = true;
        canceled = false;

        timeout = new Timeout(timeSpan, () -> {
            clearTimeout();
            eventBus.post(new TimerFinishedEvent(Timer.this));
        }, false, renderer, logger);
        timeout.start();
    }

    /**
     * Removes subscription.
     */
    private void clearTimeout() {
        if (timeout != null && !timeout.isCleaned()) {
            timeout.clear();
            timeout = null;
        }
        active = false;
    }

    @Override
    public void cancel() {
        if (!active || canceled) {
            return;
        }
        clearTimeout();
        canceled = true;
        eventBus.post(new TimerCanceledEvent(this));
    }
}
