package com.atsisa.gox.framework.configuration;

/**
 * Generic interface of a configuration repository.
 */
public interface IConfigurationRepository<T> {

    /**
     * Stored passed configuration in the repository.
     * @param configuration - configuration to save.
     */
    void save(T configuration);

    /**
     * Retrieves previously stored configuration.
     * @return stored configuration (if saved previously), otherwise null.
     */
    T fetch();
}
