package com.atsisa.gox.framework.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when a language needs to be changed.
 */
@Reflectable
public class ChangeLanguageCommand {

    /**
     * Lang code on what language should be changed.
     */
    private final String languageCode;

    /**
     * Initializes a new instance of the {@link ChangeLanguageCommand} class.
     * @param languageCode lang code on what language should be changed.
     */
    public ChangeLanguageCommand(String languageCode) {
        this.languageCode = languageCode;
    }

    /**
     * Gets a lang code on what language should be changed.
     * @return String
     */
    public String getLanguageCode() {
        return languageCode;
    }
}
