package com.atsisa.gox.framework.serialization;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * An abstraction layers for XML parsers. Hides XML namespaces management logic.
 */
public abstract class AbstractXmlParser implements IParser {

    @Override
    public SerializationFormat getFormat() {
        return SerializationFormat.XML;
    }

    /**
     * Parses the object from xml string.
     * @param xml serialized string
     * @return a parsed object
     * @throws ParseException when given string could not be successfully parsed
     */
    @Override
    public XmlObjectDocument parse(String xml) throws ParseException {
        if (xml == null) {
            throw new IllegalArgumentException("Cannot parse null value.");
        }
        try {
            XmlObjectDocument document = new XmlObjectDocument();
            XmlObject documentElement = createDocumentElement(xml, document);
            document.setDocumentElement(documentElement);
            return document;
        } catch (Throwable ex) {
            throw new ParseException(StringUtility.format("An error occurred during parsing '%s", xml), ex);
        }
    }

    /**
     * Creates the document's root element.
     * @param xml           xml to parse
     * @param ownerDocument owner document
     * @return the document's root element
     * @throws ParseException if document's root element could not be created
     */
    protected abstract XmlObject createDocumentElement(String xml, XmlObjectDocument ownerDocument) throws ParseException;

    /**
     * Separates the XmlObject name from its namespace.
     * @param xmlObject     XmlObject to handle
     * @param ownerDocument owner document
     * @throws ParseException if name and XML namespace could not be separated
     */
    protected static void extractXmlNamespace(XmlObject xmlObject, XmlObjectDocument ownerDocument) throws ParseException {
        if (xmlObject.getName().contains(":")) {
            String[] tokens = xmlObject.getName().split(":");
            if (tokens.length != 2) {
                throw new ParseException(StringUtility.format("Invalid qualified tag name '%s'", xmlObject.getName()));
            }

            String fullNs = ownerDocument.getNamespaceMap().get(tokens[0]);
            if (fullNs == null) {
                throw new ParseException(StringUtility.format("Unknown xml namespace abbreviation '%s'", tokens[0]));
            }

            xmlObject.setNamespace(fullNs, tokens[0]);
            xmlObject.setName(tokens[1]);
        }
    }

    /**
     * Injects XML attribute into XmlObject instance. The setMethod handles xml namespace attributes as well.
     * @param attributeName  attribute name
     * @param attributeValue attribute value.
     * @param xmlObject      XmlObject instance
     * @param ownerDocument  owner document
     * @throws ParseException if the XML namespaces mismatch
     */
    protected static void handleAttribute(String attributeName, String attributeValue, XmlObject xmlObject, XmlObjectDocument ownerDocument)
            throws ParseException {
        if (!attributeName.startsWith(XmlObject.NAMESPACE_TAG)) {
            xmlObject.addAttribute(attributeName, attributeValue);
        } else {
            if (attributeName.equals(XmlObject.NAMESPACE_TAG)) {
                if (xmlObject.getNamespace() == null || !xmlObject.getNamespace().equals(attributeValue)) {
                    xmlObject.setNamespace(attributeValue, "");
                }
                xmlObject.setClosestDefaultNamespace(attributeValue);
            } else {
                String namespaceAbbreviation = attributeName.substring(XmlObject.NAMESPACE_TAG.length() + 1);
                if (StringUtility.isNullOrEmpty(namespaceAbbreviation)) {
                    throw new ParseException("Invalid xml namespace");
                }
                if (ownerDocument.getNamespaceMap().containsKey(namespaceAbbreviation) && !ownerDocument.getNamespaceMap().get(namespaceAbbreviation)
                        .equals(attributeValue)) {
                    throw new ParseException(StringUtility
                            .format("Invalid xml namespace : the '%s' abbreviation value '%s' is different that already defined.", namespaceAbbreviation,
                                    attributeValue));
                }

                ownerDocument.getNamespaceMap().put(namespaceAbbreviation, attributeValue);
            }
        }
    }
}
