package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.command.CancelTimerCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Publishes a {@link CancelTimerCommand} which is a direct request for cancelling a timer of given name.
 */
public class CancelTimerAction extends SyncAction<TimerActionData> {

    /**
     * Initializes a new instance of the {@link CancelTimerAction} class.
     */
    public CancelTimerAction() {
    }

    /**
     * Initializes a new instance of the {@link CancelTimerAction} class.
     * @param logger   a logger reference.
     * @param eventBus an eventBus reference.
     */
    public CancelTimerAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new CancelTimerCommand(actionData.getTimerName()));
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || actionData.getTimerName() == null) {
            throw new ValidationException("The timer name cannot be null.");
        }
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return TimerActionData.class;
    }
}
