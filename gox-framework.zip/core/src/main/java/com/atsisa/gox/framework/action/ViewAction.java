package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;

/**
 * Action used as a base class for view-based actions.
 */
public abstract class ViewAction<T extends ViewActionData> extends Action<T> {

    /**
     * A view manager reference.
     */
    private final IViewManager viewManager;

    /**
     * Target view.
     */
    protected View targetView;

    /**
     * Initializes a new instance of the ViewAction class.
     */
    protected ViewAction() {
        viewManager = GameEngine.current().getViewManager();
    }

    /**
     * Initializes a new instance of the ViewAction class.
     * @param logger      a logger reference.
     * @param eventBus    an eventBus reference.
     * @param viewManager a viewManager reference.
     */
    protected ViewAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus);
        this.viewManager = viewManager;
    }

    @Override
    public Class<? extends ViewActionData> getActionDataType() {
        return ViewActionData.class;
    }

    @Override
    protected void grabData() {
        if (actionData != null) {
            targetView = viewManager.findViewById(actionData.getLayoutId(), actionData.getViewId());
        }
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null) {
            throw new ValidationException("Action data cannot be null");
        }
        if (targetView == null) {
            throw new ValidationException("Target view cannot be null");
        }
    }

    @Override
    protected void reset() {
        super.reset();
        targetView = null;
    }
}
