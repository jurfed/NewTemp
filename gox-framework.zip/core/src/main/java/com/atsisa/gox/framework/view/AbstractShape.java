package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.rendering.IRenderer;

/**
 * Abstract shape class.
 */
public abstract class AbstractShape extends InteractiveView {

    /**
     * Initializes a new instance of the AbstractShape class.
     */
    public AbstractShape() {
    }

    /**
     * Initializes a new instance of the AbstractShape class.
     * @param renderer {@link IRenderer}
     */
    public AbstractShape(IRenderer renderer) {
        super(renderer);
    }

}
