package com.atsisa.gox.framework;

/**
 * Game mockup class for testing GameEngine features without making a release.
 */
public class GameMockup extends AbstractGame {

    @Override
    public void onCreate() {
    }

}
