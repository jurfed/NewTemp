package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.InteractiveView;
import com.atsisa.gox.framework.view.View;
import com.google.inject.Inject;

/**
 * Exposes methods for binding and unbinding interactive views and actions.
 */
public class ActionBinder implements IActionBinder {

    /**
     * An event listener map. Maps view identifier to ViewBindingEventListener objects.
     */
    private final Map<String, IEventListener> eventListenerMap;

    /**
     * A configuration provider reference.
     */
    private final IConfigurationProvider configurationProvider;

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of the ActionBinder class.
     * @param configurationProvider configuration provider reference
     * @param logger                logger reference
     */
    @Inject
    public ActionBinder(IConfigurationProvider configurationProvider, ILogger logger) {
        logger.trace("ActionBinder | ctor");
        this.logger = logger;
        eventListenerMap = new HashMap<>();
        this.configurationProvider = configurationProvider;
    }

    @Override
    public List<ActionBinding> getBindings(String targetId) {
        logger.debug("ActionBinder | getBindings");
        IConfiguration config = configurationProvider.getConfiguration();
        List<ActionBinding> bindingList = config.getActionBindings();
        List<ActionBinding> filteredBindingList = new ArrayList<>();
        for (ActionBinding actionBinding : bindingList) {
            if (actionBinding.getTargetId().equals(targetId)) {
                filteredBindingList.add(actionBinding);
            }
        }
        return filteredBindingList;
    }

    @Override
    public void bind(View view) {
        if (meetsBindingRequirements(view)) {
            if (!eventListenerMap.containsKey(view.getId())) {
                logger.debug("ActionBinder | bind | viewId: '%s'", view.getId());
                List<ActionBinding> bindingList = getBindings(view.getId());
                if (bindingList != null && !bindingList.isEmpty()) {
                    ActionBindingEventListener eventListener = new ActionBindingEventListener(bindingList);
                    eventListenerMap.put(view.getId(), eventListener);
                    ((InteractiveView) view).addEventListener(eventListener);
                }
            } else {
                logger.warn("ActionBinder | bind | View '%s' was already bound in the ActionBinder.", view.getId());
            }
        }
    }

    @Override
    public void rebind(View view) {
        logger.debug("ActionBinder | rebind | viewId: '%s'", view.getId());
        unbind(view);
        bind(view);
    }

    @Override
    public void unbind(View view) {
        if (meetsBindingRequirements(view)) {
            logger.debug("ActionBinder | unbind | viewId: '%s'", view.getId());
            IEventListener eventListener = eventListenerMap.remove(view.getId());
            if (eventListener != null) {
                ((InteractiveView) view).removeEventListener(eventListener);
            }
        }
    }

    @Override
    public boolean isBound(View view) {
        return meetsBindingRequirements(view) && eventListenerMap.containsKey(view.getId());
    }

    /**
     * Checks if view identifier is not null and if view is an instance of the InteractiveView class.
     * @param view view to check
     * @return true if the view meets binding criteria, false otherwise
     */
    private static boolean meetsBindingRequirements(View view) {
        return !StringUtility.isNullOrEmpty(view.getId()) && view instanceof InteractiveView;
    }
}
