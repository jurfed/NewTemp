package com.atsisa.gox.framework.configuration;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.Reflectable;

/**
 * Configuration property class.
 */
@XmlElement
@Reflectable
public class ConfigurationProperty {

    private static final String BOOLEAN = "boolean";

    private static final String FLOAT = "float";

    private static final String INT = "int";

    /**
     * Property value.
     */
    private Object value;

    /**
     * Property name.
     */
    @XmlAttribute
    private String name;

    /**
     * Property type.
     */
    @XmlAttribute
    private String type;

    /**
     * Property raw value.
     */
    @XmlAttribute(name = "value")
    private String rawValue;

    /**
     * Gets the value of the property.
     * @return value of the property.
     */
    public Object getValue() {
        if (rawValue != null && value == null) {
            value = convertRawValue(rawValue, type);
        }
        return value;
    }

    /**
     * Converts the property's raw value to an instance of particular type.
     * @param rawVal    raw value to convert
     * @param valueType the property's value type.
     * @return converted raw value
     */
    private Object convertRawValue(String rawVal, String valueType) {
        String typeLower = valueType.toLowerCase();
        switch (typeLower) {
            case BOOLEAN:
                return Boolean.parseBoolean(rawVal);
            case INT:
                return Integer.parseInt(rawVal);
            case FLOAT:
                return Float.parseFloat(rawVal);
        }
        return rawVal;
    }

    /**
     * Gets the raw value of the property.
     * @return the raw value of the property
     */
    public String getRawValue() {
        return rawValue;
    }

    /**
     * Sets the raw value of the property.
     * @param rawValue the raw value of the property
     */
    public void setRawValue(String rawValue) {
        this.rawValue = rawValue;
        value = null;
    }

    /**
     * Gets the property's value type.
     * @return the property's value type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the property's value type.
     * @param type the property's value type.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the property name.
     * @return the property name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the property name.
     * @param name the property name
     */
    public void setName(String name) {
        this.name = name;
    }
}
