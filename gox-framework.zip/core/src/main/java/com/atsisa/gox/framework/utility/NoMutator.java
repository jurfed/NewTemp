package com.atsisa.gox.framework.utility;

/**
 * A null-object pattern for mutator interface.
 */
public final class NoMutator<T> implements IMutator<T> {

    /**
     * Passes through the given object without modification.
     * @param object An object to mutate.
     * @return Unmodified object.
     */
    @Override
    public T mutate(T object) {
        return object;
    }
}
