package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.google.inject.Inject;

/**
 * Registers font resources in the {@link IFontRegistry} after loading.
 */
public class FontResourceLoadingCallback extends ResourceLoadingCallbackAdapter {

    /**
     * The font registry.
     */
    private final IFontRegistry fontRegistry;

    /**
     * Initializes a new instance of the {@link FontResourceLoadingCallback} class.
     * @param fontRegistry The font registry loaded fonts should be registered into.
     */
    @Inject
    public FontResourceLoadingCallback(IFontRegistry fontRegistry) {
        this.fontRegistry = fontRegistry;
    }

    @Override
    public void onSuccess(IResource resource, int resIndex, int resCount) {
        if (resource instanceof IFontReference) {
            fontRegistry.registerFont((IFontReference) resource);
        }
    }
}
