package com.atsisa.gox.framework.utility;

/**
 * Changes the state of objects of given type.
 */
public interface IMutator<T> {

    /**
     * Changes the state of given object according to the policy
     * the mutator represents.
     * @param object An object to mutate.
     * @return A mutated object.
     */
    T mutate(T object);
}
