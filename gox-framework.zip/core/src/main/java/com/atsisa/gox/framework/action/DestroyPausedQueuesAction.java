package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Action class for destroying currently paused action queues.
 */
@Reflect_Mini
public class DestroyPausedQueuesAction extends SyncAction {

    /**
     * An action manager reference.
     */
    private final IActionManager actionManager;

    /**
     * Creates a new instance of the DestroyCurrentQueueAction class.
     */
    public DestroyPausedQueuesAction() {
        actionManager = GameEngine.current().getActionManager();
    }

    /**
     * Creates a new instance of the DestroyCurrentQueueAction class.
     * @param logger        a logger reference
     * @param eventBus      an eventBus reference
     * @param actionManager an actionManager reference
     */
    public DestroyPausedQueuesAction(ILogger logger, IEventBus eventBus, IActionManager actionManager) {
        super(logger, eventBus);
        this.actionManager = actionManager;
    }

    /**
     * Destroys currently paused action queues.
     */
    @Override
    protected void execute() {
        actionManager.destroyPausedQueues();
    }
}
