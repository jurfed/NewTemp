package com.atsisa.gox.framework.model;

/**
 * Exposes methods for retrieving property values.
 */
public interface IPropertyProvider {

    /**
     * Gets a property value using its name.
     * @param name property name
     * @return a property value
     */
    Object getProperty(String name);
}
