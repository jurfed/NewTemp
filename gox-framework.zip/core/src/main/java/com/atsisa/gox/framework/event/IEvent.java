package com.atsisa.gox.framework.event;

/**
 * Event recognition interface.
 */
public interface IEvent {

    /**
     * Gets the source of an event.
     * @return the source of an event
     */
    Object getSource();

    /**
     * Sets the source of an event.
     * @param source source of an event
     */
    void setSource(Object source);
}
