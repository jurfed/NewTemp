package com.atsisa.gox.framework.configuration;

/**
 * Describes display resolution types for reel games.
 */
public enum DisplayResolutionType {
    /**
     * 16:9 WVGA display type.
     */
    WVGA(800, 450),
    /**
     * 16:9 HD display resolution.
     */
    HD(1280, 720),
    /**
     * 5:4 SXGA display type.
     */
    SXGA(1280, 1024),
    /**
     * 16:9 Full HD display resolution.
     */
    FHD(1920, 1080);

    /**
     * Display width in pixels.
     */
    private final int width;

    /**
     * Display height in pixels.
     */
    private final int height;

    /**
     * Initializes a new instance of the {@link DisplayResolutionType} enum.
     * @param width  the display width in pixels
     * @param height the display height in pixels
     */
    DisplayResolutionType(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Gets display width in pixels.
     * @return the display width in pixels
     */
    public int getWidth() {
        return width;
    }

    /**
     * Gets display height in pixels.
     * @return the display height in pixels
     */
    public int getHeight() {
        return height;
    }
}
