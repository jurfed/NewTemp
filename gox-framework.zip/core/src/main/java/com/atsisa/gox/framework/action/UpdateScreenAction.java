package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * This action retrieves a game screen using the identifier given as action data parameter and fires a setMethod also
 * described in parameters. If there is no setMethod defined, the update setMethod will be fired.
 */
@Reflect_Mini
public class UpdateScreenAction extends Action<UpdateScreenActionData> {

    /**
     * A view manager reference.
     */
    private final IViewManager viewManager;

    /**
     * A reflection reference.
     */
    private final IReflection reflection;

    /**
     * Initializes a new instance of the UpdateScreenAction class.
     */
    public UpdateScreenAction() {
        viewManager = GameEngine.current().getViewManager();
        reflection = GameEngine.current().getUtility().getReflection();
    }

    /**
     * Initializes a new instance of the UpdateModelAction class.
     * @param logger      a logger reference
     * @param eventBus    an eventBus reference
     * @param viewManager a view manager reference
     * @param reflection  a reflection reference
     */
    public UpdateScreenAction(ILogger logger, IEventBus eventBus, IViewManager viewManager, IReflection reflection) {
        super(logger, eventBus);
        this.viewManager = viewManager;
        this.reflection = reflection;
    }

    @Override
    public Class<UpdateScreenActionData> getActionDataType() {
        return UpdateScreenActionData.class;
    }

    @Override
    protected void execute() {
        Screen screen = viewManager.getScreenById(actionData.getScreenId());
        if (screen != null) {
            if (actionData.getMethod() != null) {
                Object[] methodParameters = actionData.getMethodParameters();
                Class<?>[] paramTypes = new Class<?>[methodParameters.length];
                for (int i = 0; i < methodParameters.length; i++) {
                    paramTypes[i] = methodParameters[i].getClass();
                }
                Method method = getScreenObjectMethod(screen.getClass(), actionData.getMethod(), paramTypes);
                if (method != null && method.getAnnotation(ExposeMethod.class) != null) {
                    Object[] params = methodParameters.length > 0 ? methodParameters : new Object[0];
                    try {
                        method.invoke(screen, params);
                        finish();
                    } catch (ReflectionException e) {
                        fail(e);
                    }
                } else {
                    fail(new Exception(StringUtility
                            .format("Method '%s' in the '%s' object does not exist or has not been marked using @ExposeMethod annotation.",
                                    actionData.getMethod(), screen.getClass())));
                }
            } else {
                screen.update();
                finish();
            }
        } else {
            fail(new Exception(StringUtility.format("Could not find a game screen '%s'", actionData.getScreenId())));
        }
    }

    /**
     * Gets the setMethod by searching the whole type hierarchy.
     * @param type       type to check
     * @param methodName setMethod name to fetch
     * @return a setMethod object or null if the setMethod could not be found
     */
    private Method getScreenObjectMethod(Class<?> type, String methodName, Class<?>[] paramTypes) {
        Method method;
        Class<?> currentType = type;
        do {
            method = reflection.getMethod(currentType, methodName, paramTypes);
            currentType = reflection.getSuperClass(currentType);
        } while (method == null && currentType != Object.class);

        return method;
    }
}
