package com.atsisa.gox.framework.exception;

/**
 * Indicates general system failure.
 */
public class GeneralSystemException extends GameException {

    /**
     * Game message.
     */
    public static final String LANG_ERROR_GENERAL_SYSTEM_FAILURE = "LangErrorGeneralSystemFailure";

    /**
     * Initializes a new instance of the GeneralSystemException using specific message.
     * @param message error message
     */
    public GeneralSystemException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the GeneralSystemException using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public GeneralSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the GeneralSystemException using specific cause.
     * @param cause internal cause of error
     */
    public GeneralSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getLocalizableMessage() {
        return LANG_ERROR_GENERAL_SYSTEM_FAILURE;
    }
}
