package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.utility.StringUtility;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Dynamically convert xml element to instance of the specific class based on xml attribute named "<b>class</b>". Value of this attribute must have class name
 * with full namespace e.g. <i>com.atsisa.gox.framework.view.ViewGroup</i>.
 */
@Reflect_Mini
public class DynamicClassConverter implements IValueConverter {

    /**
     * Symbols definition attribute name specifying pool initialization strategy class.
     */
    private static final String CLASS_ATTRIBUTE_NAME = "class";

    /**
     * The serializer.
     */
    private final IXmlSerializer serializer;

    /**
     * Initializes a new instance of the {@link DynamicClassConverter} class.
     */
    public DynamicClassConverter() {
        serializer = GameEngine.current().getUtility().getSerialization().getSerializer(SerializationFormat.XML);
    }

    /**
     * This class does not supported serialize object to xml.
     * @return null
     */
    @Override
    public Class<?> getValueType() {
        return null;
    }

    @Override
    public String convertTo(Object objToConvert) throws ConversionException {
        throw new ConversionException("Converting resolver back to string is not supported");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (parsedObject == null) {
            return null;
        }
        String className = ((XmlObject) parsedObject).getAttribute(CLASS_ATTRIBUTE_NAME);
        try {
            return serializer.deserialize(parsedObject, className);
        } catch (SerializationException e) {
            throw new ConversionException(StringUtility.format("Unable to dynamically deserialize class with name: %s", className), e);
        }
    }

}
