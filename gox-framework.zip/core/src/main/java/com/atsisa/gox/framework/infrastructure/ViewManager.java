package com.atsisa.gox.framework.infrastructure;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.model.ILayout;
import com.atsisa.gox.framework.model.Layout;
import com.atsisa.gox.framework.model.LayoutEventType;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResource;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.screen.BasicScreen;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.inject.Inject;

/**
 * An implementation of view manager class. Exposes methods for building, caching and retrieving particular views.
 */
public class ViewManager implements IViewManager, IDisposable {

    /**
     * Reference to view manager components.
     */
    private final ViewManagerComponents component;

    /**
     * Reference to logger.
     */
    private final ILogger logger;

    /**
     * A layout resource map, maps layoutId to proper layout object.
     */
    private Map<String, ILayout> layoutMap;

    /**
     * a reference to a stage.
     */
    private ViewGroup stage;

    /**
     * A map of registered screens, maps screen identifier to Screen object.
     */
    private final Map<String, Screen> registeredScreenMap;

    /**
     * Initializes a new instance of {@link ViewManager} class.
     * @param component {@link ViewManagerComponents}
     * @param logger    {@link ILogger}
     */
    @Inject
    public ViewManager(ViewManagerComponents component, ILogger logger) {
        this.component = component;
        this.logger = logger;
        registeredScreenMap = new HashMap<>();

        component.freeze();
        logger.debug("ViewManager | ctor");
    }

    @Override
    public void registerScreen(Screen screen) {
        registeredScreenMap.put(screen.getLayoutId(), screen);
    }

    @Override
    public boolean unregisterScreen(String id) {
        if (registeredScreenMap.containsKey(id)) {
            registeredScreenMap.remove(id);
            return true;
        }
        return false;
    }

    @Override
    public Screen getScreenById(String id) {
        return registeredScreenMap.get(id);
    }

    @Override
    public void registerLayoutsFromResources() {
        List<IResource> allResources = component.getResourceManager().getAllResources(ResourceType.LAYOUT);
        if (allResources != null) {
            for (IResource resource : allResources) {
                registerLayout(resource.getId(), (XmlResource) resource);
            }
        }
    }

    /**
     * Adds instances of the BasicScreen class to the map of registered screens for layouts which have not been bound to any particular screen.
     */
    private void addMissingLayoutScreens() {
        Collection<ILayout> layoutCollection = getAllLayouts();
        for (ILayout layout : layoutCollection) {
            if (!registeredScreenMap.containsKey(layout.getId())) {
                BasicScreen basicScreen = new BasicScreen(layout.getId(), this);
                registeredScreenMap.put(layout.getId(), basicScreen);
                basicScreen.initialize();
            }
        }
    }

    @Override
    public <T extends Screen> List<T> getScreenByType(Class<T> screenType) {
        List<T> screenList = new ArrayList<>();
        for (Screen screen : registeredScreenMap.values()) {
            if (screen.getClass().equals(screenType)) {
                screenList.add((T) screen);
            }
        }
        return screenList;
    }

    @Override
    public List<Screen> getAllScreens() {
        return new ArrayList<>(registeredScreenMap.values());
    }

    @Override
    public IViewBuilder getViewBuilder() {
        return component.getViewBuilder();
    }

    @Override
    public ISkinManager getSkinManager() {
        return component.getSkinManager();
    }

    @Override
    public boolean registerLayout(String layoutId, XmlResource xmlResource) {
        logger.debug("ViewManager | registerLayout | layoutId: '%s'", layoutId);

        if (xmlResource == null) {
            throw new IllegalArgumentException("TextResource cannot be null");
        }
        if (layoutMap.containsKey(layoutId)) {
            getLayout(layoutId).update(xmlResource);
            return false;
        }
        layoutMap.put(layoutId, new Layout(layoutId, xmlResource, null, component.getViewBuilder()));
        return true;
    }

    @Override
    public boolean registerLayout(String layoutId, View rootView) {
        logger.debug("ViewManager | registerLayout | layoutId: '%s'", layoutId);
        if (rootView == null) {
            throw new IllegalArgumentException("rootView cannot be null");
        }
        if (layoutMap.containsKey(layoutId)) {
            return false;
        }
        layoutMap.put(layoutId, new Layout(layoutId, null, rootView, component.getViewBuilder()));
        return true;
    }

    @Override
    public boolean unregisterLayout(String layoutId) {
        logger.debug("ViewManager | unregisterLayout | layoutId: '%s'", layoutId);
        return layoutMap.remove(layoutId) != null;
    }

    @Override
    public boolean isLayoutOnStage(String layoutId) {
        ILayout layout = layoutMap.get(layoutId);
        return layout != null && layout.isOnStage();
    }

    @Override
    public ILayout getLayout(String layoutId) {
        logger.debug("ViewManager | getLayout | layoutId: '%s'", layoutId);
        return layoutMap.get(layoutId);
    }

    @Override
    public Collection<ILayout> getAllLayouts() {
        return layoutMap.values();
    }

    @Override
    public boolean buildLayout(String layoutId) {
        logger.debug("ViewManager | buildLayout | layoutId: '%s'", layoutId);

        Layout layout = (Layout) layoutMap.get(layoutId);
        if (layout != null && !layout.isBuilt()) {
            try {
                layout.build();
                return true;
            } catch (Exception ex) {
                ex.printStackTrace();
                logger.error("ViewManager | buildLayout | Could not build layout.", ex);
            }
        }
        return false;
    }

    @Override
    public void buildAllLayouts() {
        logger.debug("ViewManager | buildAllLayouts");

        addMissingLayoutScreens();
        for (String layoutId : layoutMap.keySet()) {
            buildLayout(layoutId);
        }
    }

    @Override
    public boolean destroyLayout(String layoutId) {
        logger.debug("ViewManager | destroyLayout | layoutId: '%s'", layoutId);
        Layout layout = (Layout) layoutMap.get(layoutId);
        if (layout != null && layout.isOnStage()) {
            layout.triggerEvent(LayoutEventType.BEFORE_DESTROYED);
            if (!removeLayout(layoutId)) {
                logger.warn("ViewManager | buildLayout | Could not remove layoutId '%s' from the stage.", layoutId);

                return false;
            }
            layout.dispose();
            layout.triggerEvent(LayoutEventType.AFTER_DESTROYED);
            return true;
        }
        return false;
    }

    @Override
    public boolean addLayout(String layoutId) {
        logger.debug("ViewManager | addLayout | layoutId: '%s'", layoutId);
        return addLayout((Layout) layoutMap.get(layoutId));
    }

    /**
     * Adds a layout to the main stage view.
     * @param layout layout identifier
     * @return true if operation succeeded, false otherwise
     */
    private boolean addLayout(Layout layout) {
        if (layout != null) {
            if (!layout.isBuilt()) {
                buildLayout(layout.getId());
            }

            if (layout.getRootView() != null) {
                if (!layout.isOnStage()) {
                    layout.triggerEvent(LayoutEventType.BEFORE_ADDED);
                    addToStage(layout.getRootView());
                }

                layout.getRootView().redraw();
                layout.triggerEvent(LayoutEventType.AFTER_ADDED);
                return true;
            } else {
                logger.error("ViewManager | addLayout | An error occurred during building '%s' layout.", layout.getId());
            }
        } else {
            logger.warn("ViewManager | addLayout | Unable to add layout. Please check if it has been registered first");
        }
        return false;
    }

    @Override
    public boolean removeLayout(String layoutId) {
        logger.debug("ViewManager | removeLayout | layoutId: '%s'", layoutId);

        Layout layout = (Layout) layoutMap.get(layoutId);
        if (layout != null && layout.isBuilt()) {
            layout.triggerEvent(LayoutEventType.BEFORE_HIDDEN);
            stage.removeChild(layout.getRootView());
            layout.triggerEvent(LayoutEventType.AFTER_HIDDEN);
            return true;
        }
        return false;
    }

    @Override
    public List<View> findViewById(String viewId) {
        logger.debug("ViewManager | findViewById | viewId: '%s'", viewId);

        List<View> foundViews = new ArrayList<>();
        for (ILayout layout : layoutMap.values()) {
            if (layout.isOnStage()) {
                View foundView = findViewById(layout.getRootView(), viewId);
                if (foundView != null) {
                    foundViews.add(foundView);
                }
            }
        }
        return foundViews;
    }

    @Override
    public List<? extends View> findViewInheritingType(String layoutId, Class<? extends View> viewType) {
        logger.debug("ViewManager | findViewInheritingType | layoutId: '%s', viewType: '%s'", layoutId, viewType);

        ILayout layout = layoutMap.get(layoutId);
        if (layout != null && layout.isBuilt()) {
            return findViewInheritingType(layout.getRootView(), viewType);
        }
        return null;
    }

    @Override
    public View findViewById(String layoutId, String viewId) {
        logger.debug("ViewManager | findViewById | viewId: '%s', layoutId: '%s'", viewId, layoutId);

        ILayout layout = layoutMap.get(layoutId);
        if (layout != null && layout.isBuilt()) {
            return findViewById(layout.getRootView(), viewId);
        }
        return null;
    }

    @Override
    public View findViewById(View currentView, String viewId) {
        if (currentView == null) {
            return null;
        }
        if (currentView.getId() != null && currentView.getId().equals(viewId)) {
            return currentView;
        }
        if (currentView instanceof ViewGroup) {
            Iterable<? extends View> children = ((ViewGroup) currentView).getChildren();
            for (View child : children) {
                View foundChild = findViewById(child, viewId);
                if (foundChild != null) {
                    return foundChild;
                }
            }
        }
        return null;
    }

    @Override
    public List<? extends View> findViewInheritingType(Class<? extends View> viewType) {
        logger.debug("ViewManager | findViewInheritingType | viewType: '%s'", viewType);

        List<View> foundViews = new ArrayList<>();
        for (ILayout layout : layoutMap.values()) {
            if (layout != null && layout.isBuilt()) {
                List<? extends View> foundLayoutViews = findViewInheritingType(layout.getRootView(), viewType);
                foundViews.addAll(foundLayoutViews);
            }
        }

        return foundViews;
    }

    @Override
    public <T> List<T> findViewImplementingType(View currentView, Class<T> interfaceType) {
        List<T> foundViews = new ArrayList<>();
        if (currentView == null) {
            return foundViews;
        }
        Class<?> reference = currentView.getClass();
        while (reference != View.class) {
            boolean found = false;
            Class<?>[] interfaces = component.getReflection().getInterfaces(reference);
            for (Class<?> iface : interfaces) {
                if (iface.equals(interfaceType)) {
                    found = true;
                    foundViews.add((T) currentView);
                    break;
                }
            }
            if (found) {
                break;
            }
            reference = component.getReflection().getSuperClass(reference);
        }
        if (currentView instanceof ViewGroup) {
            Iterable<? extends View> children = ((ViewGroup) currentView).getChildren();
            for (View child : children) {
                List<T> foundChildren = findViewImplementingType(child, interfaceType);
                foundViews.addAll(foundChildren);
            }
        }
        return foundViews;
    }

    @Override
    public <T> List<T> findViewImplementingType(Class<T> interfaceType) {
        logger.debug("ViewManager | findViewImplementingType | interfaceType: '%s'", interfaceType);

        List<T> foundViews = new ArrayList<>();
        for (ILayout layout : layoutMap.values()) {
            if (layout != null && layout.isBuilt()) {
                List<T> foundLayoutViews = findViewImplementingType(layout.getRootView(), interfaceType);
                foundViews.addAll(foundLayoutViews);
            }
        }

        return foundViews;
    }

    @Override
    public ILayout findLayoutByView(View view) {
        logger.debug("ViewManager | findLayoutByView | view: '%s'", view);

        assert view != null : "Cannot search for nulled view";
        View currentView = view;
        if (currentView == stage) {
            return null;
        }
        while (currentView.getParent() != null && currentView.getParent() != stage) {
            currentView = currentView.getParent();
        }
        for (ILayout layout : layoutMap.values()) {
            if (layout.getRootView() == currentView) {
                return layout;
            }
        }
        return null;
    }

    @Override
    public void redrawAll() {
        for (ILayout layout : layoutMap.values()) {
            if (layout != null && layout.isOnStage()) {
                layout.getRootView().redraw();
            }
        }
    }

    @Override
    public List<? extends View> findViewInheritingType(View currentView, Class<? extends View> viewType) {
        List<View> foundViews = new ArrayList<>();
        if (currentView != null) {
            Class<?> reference = currentView.getClass();
            while (reference != View.class) {
                if (reference.equals(viewType)) {
                    foundViews.add(currentView);
                    break;
                }
                reference = component.getReflection().getSuperClass(reference);
            }
            if (currentView instanceof ViewGroup) {
                Iterable<? extends View> children = ((ViewGroup) currentView).getChildren();
                for (View child : children) {
                    List<? extends View> foundChildren = findViewInheritingType(child, viewType);
                    foundViews.addAll(foundChildren);
                }
            }
        }
        return foundViews;
    }

    @Override
    public <T extends View> List<T> findViewByType(Class<T> viewType) {
        logger.debug("ViewManager | findViewByType | viewType: '%s'", viewType);

        List<T> foundViews = new ArrayList<>();
        for (ILayout layout : layoutMap.values()) {
            if (layout != null && layout.isBuilt()) {
                foundViews.addAll(findViewByType(layout.getRootView(), viewType));
            }
        }
        return foundViews;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends View> List<T> findViewByType(String layoutId, Class<T> viewType) {
        logger.debug("ViewManager | findViewByType | layoutId: '%s', viewType: '%s'", layoutId, viewType);

        ILayout layout = layoutMap.get(layoutId);
        if (layout != null && layout.isBuilt()) {
            return findViewByType(layout.getRootView(), viewType);
        }

        return null;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends View> List<T> findViewByType(View currentView, Class<T> viewType) {
        List<T> foundViews = new ArrayList<>();
        if (currentView != null) {
            if (currentView.getClass().equals(viewType)) {
                foundViews.add((T) currentView);
            }
            if (currentView instanceof ViewGroup) {
                Iterable<? extends View> children = ((ViewGroup) currentView).getChildren();
                for (View child : children) {
                    List<T> foundChildren = findViewByType(child, viewType);
                    foundViews.addAll(foundChildren);
                }
            }
        }
        return foundViews;
    }

    /**
     * Gets stage view group.
     * @return ViewGroup
     */
    @Override
    public ViewGroup getStage() {
        return stage;
    }

    @Override
    public void init(IRenderer renderer) {
        layoutMap = new HashMap<>();
        stage = new ViewGroup(renderer);
        IGameConfiguration gameConfiguration = component.getGameConfiguration();
        stage.setWidth(gameConfiguration.getWidth());
        stage.setHeight(gameConfiguration.getHeight());
        stage.redraw();
    }

    @Override
    public void dispose() {
        Iterator<ILayout> layoutIterator = layoutMap.values().iterator();
        while (layoutIterator.hasNext()){
            ILayout layout = layoutIterator.next();
            layout.dispose();
            layoutIterator.remove();
        }

        Iterator<Screen> screenIterator = registeredScreenMap.values().iterator();
        while (screenIterator.hasNext()){
            Screen screen = screenIterator.next();
            screen.getModel().clear();
            screenIterator.remove();
        }
        stage.dispose();
        registeredScreenMap.clear();
    }

    /**
     * Adds a particular view to the stage.
     * @param view view to add
     */
    private void addToStage(View view) {
        stage.addChild(view);
    }
}
