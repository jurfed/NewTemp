package com.atsisa.gox.framework.animation;

import com.gwtent.reflection.client.Reflectable;

import rx.Observable;

/**
 * Represents a generic animation.
 */
@Reflectable(methods = false)
public interface IAnimation {

    /**
     * Gets a value indicating whether this animation is playing.
     * @return True if the animation is playing, false otherwise.
     */
    boolean isPlaying();

    /**
     * Gets a value indicating whether this animation has been paused.
     * @return True if the animation is paused, false otherwise.
     */
    boolean isPaused();

    /**
     * Gets a value indicating whether this animation has been stopped.
     * @return True if the animation is stopped, false otherwise.
     */
    boolean isStopped();

    /**
     * Starts to play this animation.
     * <p>
     * This operation also resumes the animation in case it was paused before.
     * Does nothing in case the animation is already PLAYING.
     * </p>
     */
    void play();

    /**
     * Pauses this animation in its current state.
     * <p>
     * This operation does noting in case this animation is already STOPPED or PAUSED.
     * </p>
     */
    void pause();

    /**
     * Stops this animation.
     * <p>
     * Does nothing in case the animation is already STOPPED.
     * </p>
     */
    void stop();

    /**
     * Gets current animation state.
     * @return Current animation state.
     */
    AnimationState getAnimationState();

    /**
     * Gets an observable animation state.
     * <p>
     * An observable state allows users to keep track of animation state changes in time.
     * </p>
     * @return An observable animation state.
     */
    Observable<AnimationState> getAnimationStateObservable();
}
