package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.ISkinManager;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.Skin;

/**
 * Converter used for deserializing skin for views.
 */
public class SkinRefConverter implements IValueConverter {

    /**
     * Reference to skin manager.
     */
    private final ISkinManager skinManager;

    /**
     * Reference to logger.
     */
    private final ILogger logger;

    /**
     * Default constructor, where reference to skin manager is taken from game engine.
     */
    public SkinRefConverter() {
        this(GameEngine.current().getViewManager().getSkinManager(), GameEngine.current().getLogger());
    }

    /**
     * Constructs skin converter with parameter.
     * @param skinManager - reference to skin manager
     * @param logger      - reference to logger
     */
    public SkinRefConverter(ISkinManager skinManager, ILogger logger) {
        this.skinManager = skinManager;
        this.logger = logger;
    }

    /**
     * Returns class to which should be created.
     * @return Skin class
     */
    @Override
    public Class<?> getValueType() {
        return Skin.class;
    }

    /**
     * Throws {@link UnsupportedOperationException}.
     * @param objToConvert - a Java object instance
     * @return converted String
     */
    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException();
    }

    /**
     * Converts String message to Skin object. It throws {@link IllegalArgumentException} - if serialized message has improper content
     * @param serializedMessage a string representation of a Java object
     * @param parsedObject      - IParsedObject reference
     * @return Skin object
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (StringUtility.isNullOrEmpty(serializedMessage)) {
            return null;
        }

        String[] tokens;
        try {
            tokens = splitXmlLink(serializedMessage);
        } catch (IllegalArgumentException ex) {
            throw new ConversionException("Invalid resource link.", ex);
        }

        if (tokens == null || tokens.length != 2 || !tokens[0].equalsIgnoreCase("skin")) {
            throw new ConversionException(StringUtility.format("Invalid resource link '%s'", serializedMessage));
        }

        Skin skin = skinManager.getSkin(tokens[1]);

        if (skin == null) {
            logger.error("Invalid skin name | '%s'", tokens[1]);
        }

        return skin;
    }

    /**
     * Splits the XML link notation into tokens. For input '@image/id' it will return {'image','id'} array.
     * @param link link to parse
     * @return an array of link tokens
     */
    private static String[] splitXmlLink(String link) {
        if (StringUtility.isNullOrEmpty(link)) {
            return null;
        }
        if (!link.startsWith("@")) {
            throw new IllegalArgumentException(StringUtility.format("Invalid XML link '%s'", link));
        }
        String[] tokens = link.split("/");
        tokens[0] = tokens[0].substring(1);
        return tokens;
    }
}
