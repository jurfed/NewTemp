package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.atsisa.gox.framework.utility.StringUtility;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * A representation of the Progress bar view.
 */
@Reflect_Full
@XmlElement
public class ProgressBarView extends ImageView {

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getMinValue setMethod.
         */
        public static final int MIN_VALUE = 1;

        /**
         * Represents a view property accessible via getMaxValue setMethod.
         */
        public static final int MAX_VALUE = 1 << 1;

        /**
         * Represents a view property accessible via getValue setMethod.
         */
        public static final int VALUE = 1 << 2;

        /**
         * Represents a view property accessible via getColor setMethod.
         */
        public static final int COLOR = 1 << 3;
    }

    /**
     * Default maximal allowed value.
     */
    private static final float DEFAULT_MAX_VALUE = 100f;

    /**
     * A color.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> color = new ViewProperty<>(Integer.class, this, ViewType.PROGRESS_BAR_VIEW, ViewPropertyName.COLOR, 0xffffff);

    /**
     * Minimal progress bar value.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> minValue = new ViewProperty<>(Float.class, this, ViewType.PROGRESS_BAR_VIEW, ViewPropertyName.MIN_VALUE, 0f);

    /**
     * Maximal progress bar value.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> maxValue = new ViewProperty<>(Float.class, this, ViewType.PROGRESS_BAR_VIEW, ViewPropertyName.MAX_VALUE,
            DEFAULT_MAX_VALUE);

    /**
     * Current progress bar value.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> value = new ViewProperty<>(Float.class, this, ViewType.PROGRESS_BAR_VIEW, ViewPropertyName.VALUE, 0f);

    /**
     * Gets the minimal progress bar value.
     * @return minimal progress bar value
     */
    public float getMinValue() {
        return minValue.get();
    }

    /**
     * Sets the minimal progress bar value.
     * @param minValue minimal progress bar value
     */
    public void setMinValue(float minValue) {
        this.minValue.set(minValue);
    }

    /**
     * Gets the min value property.
     * @return the min value property
     */
    public IObservableProperty<Float> minValue() {
        return minValue;
    }

    /**
     * Gets the maximal progress bar value.
     * @return maximal progress bar value
     */
    public float getMaxValue() {
        return maxValue.get();
    }

    /**
     * Sets the maximal progress bar value.
     * @param maxValue the maximal progress bar value
     */
    public void setMaxValue(float maxValue) {
        this.maxValue.set(maxValue);
    }

    /**
     * Gets the max value property.
     * @return the max value property
     */
    public IObservableProperty<Float> maxValue() {
        return maxValue;
    }

    /**
     * Gets the current progress bar value.
     * @return current progress bar value
     */
    public float getValue() {
        return value.get();
    }

    /**
     * Sets the current progress bar value.
     * The value must be within [minValue, maxValue] range.
     * Otherwise an instance of UnsupportedOperationException will be thrown.
     * @param value current progress bar value
     */
    public void setValue(float value) {
        if (value < getMinValue() || value > getMaxValue()) {
            throw new UnsupportedOperationException(StringUtility.format("ProgressBar value must be within [%s,%s] range", getMinValue(), getMaxValue()));
        }
        this.value.set(value);
    }

    /**
     * Gets the value property.
     * @return the value property
     */
    public IObservableProperty<Float> value() {
        return value;
    }

    /**
     * Gets the ARGB progress bar color value.
     * @return ARGB progress bar color value.
     */
    public Integer getColor() {
        return color.get();
    }

    /**
     * Sets the ARGB progress bar color.
     * This property is valid only if the image resource has not been set.
     * @param color ARGB color value
     */
    public void setColor(Integer color) {
        this.color.set(color);
    }

    /**
     * Gets the color property.
     * @return the color property
     */
    public IObservableProperty<Integer> color() {
        return color;
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.PROGRESS_BAR_VIEW, ViewPropertyName.MAX_VALUE | ViewPropertyName.MIN_VALUE | ViewPropertyName.VALUE | ViewPropertyName.COLOR);
    }
}
