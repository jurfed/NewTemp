package com.atsisa.gox.framework.utility.logger;

/**
 * Mockup logger implementation.
 */
public class NoLogger implements ILogger {

    @Override
    public LogLevel getLevel() {
        return null;
    }

    @Override
    public void setLevel(LogLevel logLevel) {

    }

    @Override
    public void debug(String msg) {

    }

    @Override
    public void debug(String msg, Object... args) {

    }

    @Override
    public void debug(String msg, Throwable e) {

    }

    @Override
    public void info(String msg) {

    }

    @Override
    public void info(String msg, Throwable e) {

    }

    @Override
    public void info(String msg, Object... args) {

    }

    @Override
    public void warn(String msg) {

    }

    @Override
    public void warn(String msg, Throwable e) {

    }

    @Override
    public void warn(String msg, Object... args) {

    }

    @Override
    public void error(String msg) {

    }

    @Override
    public void error(String msg, Throwable e) {

    }

    @Override
    public void error(String msg, Object... args) {

    }

    @Override
    public void trace(String msg) {

    }

    @Override
    public void trace(String msg, Throwable e) {

    }

    @Override
    public void trace(String msg, Object... args) {

    }
}
