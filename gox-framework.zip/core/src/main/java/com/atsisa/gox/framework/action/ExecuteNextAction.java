package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ActionQueueStateException;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Waits until the currently active queue will either be destroyed or finished and then processes another action queue which name is defined in the
 * ExecuteQueueActionData structure.
 */
@Reflect_Mini
public class ExecuteNextAction extends Action<ExecuteQueueActionData> {

    /**
     * An action manager reference.
     */
    private final IActionManager actionManager;

    /**
     * Creates a new instance of the ExecuteNextAction class.
     */
    public ExecuteNextAction() {
        actionManager = GameEngine.current().getActionManager();
    }

    /**
     * Creates a new instance of the ExecuteNextAction class.
     * @param logger        a logger reference
     * @param eventBus      an eventBus reference
     * @param actionManager an actionManager reference
     */
    public ExecuteNextAction(ILogger logger, IEventBus eventBus, IActionManager actionManager) {
        super(logger, eventBus);
        this.actionManager = actionManager;
    }

    @Override
    public Class<ExecuteQueueActionData> getActionDataType() {
        return ExecuteQueueActionData.class;
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || StringUtility.isNullOrEmpty(actionData.getQueueName())) {
            throw new ValidationException("The queue name cannot be null or empty.");
        }
    }

    /**
     * Waits until active queue is finished.
     */
    @Override
    protected void execute() {
        final String queueName = actionData.getQueueName();
        IActionQueue activeQueue = actionManager.getActiveQueue();
        if (activeQueue != null) {
            actionManager.getActiveQueue().addStateListener(new IStateListener<ActionQueueState>() {

                @Override
                public void stateChanged(Object source, ActionQueueState state) {
                    if (state == ActionQueueState.DESTROYED || state == ActionQueueState.FINISHED) {
                        ((IActionQueue) source).removeStateListener(this);
                        actionManager.processQueue(queueName);
                    }
                }
            });
            finish();
        } else {
            fail(new ActionQueueStateException("There is no active queue to wait for!"));
        }
    }
}
