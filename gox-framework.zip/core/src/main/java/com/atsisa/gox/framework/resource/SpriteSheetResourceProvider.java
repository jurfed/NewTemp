package com.atsisa.gox.framework.resource;

/**
 * Provider for sprite sheet type.
 */
public abstract class SpriteSheetResourceProvider implements IResourceProvider {

    @Override
    public boolean canCreate(ResourceType resourceType) {
        return resourceType == ResourceType.SPRITE_SHEET;
    }
}
