package com.atsisa.gox.framework.rendering;

import java.util.List;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.rendering.layer.ILayerContainer;
import com.atsisa.gox.framework.view.View;

/**
 * Group layers rendering.
 */
public abstract class GroupLayerRenderer extends InteractiveViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the GroupLayerRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public GroupLayerRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    /**
     * Adds children to layers.
     * @param listToAdd List of ILayer
     * @param view      View
     */
    protected void addChildren(List<ILayer> listToAdd, View view) {
        lv.layerContainer = (ILayerContainer) getViewLayer(view);
        lv.layerContainer.removeLayers();
        lv.childrenSize = listToAdd.size();
        for (lv.childrenIndex = 0; lv.childrenIndex < lv.childrenSize; lv.childrenIndex++) {
            lv.layerContainer.addChild(listToAdd.get(lv.childrenIndex));
        }
    }

    /**
     * Removes all children from this group.
     * @param view view to remove
     */
    protected void removeChildren(View view) {
        ((ILayerContainer) getViewLayer(view)).removeLayers();
    }

    /**
     * Creates and returns ILayerContainer specific platform implementation.
     * @param view - View
     * @return ILayerContainer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected ILayerContainer createLayer(View view) {
        return getLayerFactory().createLayerContainer();
    }

    /**
     * Holder for instances of local variables used in the {@link GroupLayerRenderer} methods.
     */
    private class LocalVariables {

        private ILayerContainer layerContainer;

        private int childrenSize;

        private int childrenIndex;
    }
}
