package com.atsisa.gox.framework.animation;

import com.google.inject.Inject;

/**
 * A default animation factory.
 */
public class AnimationFactory implements IAnimationFactory {

    /**
     * Tween view animation controller.
     */
    private final TweenAnimationController tweenAnimationController;

    /**
     * Initializes a new instance of the animation factory.
     * @param tweenAnimationController The tween view animation controller.
     */
    @Inject
    public AnimationFactory(TweenAnimationController tweenAnimationController) {
        this.tweenAnimationController = tweenAnimationController;
    }

    @Override
    public <T extends IAnimation> T createAnimation(Class<T> animationType) {

        // TODO: refactor to use guice/gin container.

        if (animationType == TweenViewAnimation.class) {
            return (T) new TweenViewAnimation(tweenAnimationController);
        } else if (animationType == TweenAnimation.class) {
            return (T) new TweenAnimation(tweenAnimationController);
        }

        throw new IllegalArgumentException("Unknown animation type: " + animationType);
    }
}
