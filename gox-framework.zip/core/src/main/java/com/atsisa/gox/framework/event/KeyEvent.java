package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.view.View;

/**
 * Represents keyboard events regarding interactive views.
 */
public class KeyEvent extends InputEvent {

    /**
     * The key code of the key that was pressed.
     */
    private int keyCode;

    /**
     * Initializes a new instance of the InputEvent class.
     * @param type    input event type
     * @param source  source of the event
     * @param keyCode key code of the key that was pressed
     */
    public KeyEvent(InputEventType type, View source, int keyCode) {
        super(type, source);
        this.keyCode = keyCode;
    }

    /**
     * Returns the key code of the key that was pressed.
     * @return key code
     */
    public int getKeyCode() {
        return keyCode;
    }
}
