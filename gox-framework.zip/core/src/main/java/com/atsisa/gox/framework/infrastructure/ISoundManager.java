package com.atsisa.gox.framework.infrastructure;

/**
 * Interface for managing sounds.
 */
public interface ISoundManager {

    /**
     * Loads resources to sound manager.
     */
    void loadResourcesToManager();

    /**
     * Prepare all sounds in this sound manager.
     * Some platform require specific behaviour to initialize sounds before they can be played.
     * (e.g. mobile browsers require user interaction first)
     */
    void prepareSounds();

    /**
     * Returns a boolean which indicated whether sounds should be automatically prepared after
     * they are loaded to this sound manager.
     * Some platforms may need own custom further initialization.
     * @return boolean
     */
    boolean prepareSoundAfterLoad();

    /**
     * Checks whether sound is playing.
     * @param id - id of the sound
     * @return true if sound is playing
     */
    boolean isPlaying(String id);

    /**
     * Checks whether sound is paused.
     * @param id - id of the sound
     * @return true if sound is paued
     */
    boolean isPaused(String id);

    /**
     * Starts playing a sound from the beginning. If the audio system is certain that audio playback
     * failed, this setMethod will return false. However, a return value of true
     * does not guarantee that playback will in fact succeed.
     * @param id - id of the sound
     * @return boolean
     */
    boolean play(String id);

    /**
     * Resumes playback a specific sound, this will work only if that sound was already paused.
     * @param id - id of the sound.
     * @return boolean
     */
    boolean resume(String id);

    /**
     * Stop playback of the current audio stream as soon as possible, and reset the sound position to
     * its starting position, such that a subsequent call to play() will cause the audio file
     * to being playback from the beginning of the audio stream.
     * @param id - id of the sound
     */
    void stop(String id);

    /**
     * Pauses current audio stream as soon as possible, such that a subsequent call to play()
     * will cause the audio file to being playback from the last position of the audio stream.
     * @param id - id of the sound
     */
    void pause(String id);

    /**
     * Sets looping.
     * @param id      - id of the sound
     * @param looping - looping
     */
    void setLooping(String id, boolean looping);

    /**
     * Sets volume.
     * @param id     - id of the sound
     * @param volume - volume of the sound from the range from 0.0 to 1.0.
     */
    void setVolume(String id, float volume);

    /**
     * Gets volume of the sound.
     * @param id - id of the sound
     * @return volume of the sound from the range from 0.0 to 1.0
     */
    float getVolume(String id);

    /**
     * Gets sound length.
     * @param id - id of the sound
     * @return sound length
     */
    int length(String id);

    /**
     * Stops all currently playing sounds.
     */
    void stopAllSounds();

    /**
     * Pauses all currently playing sounds.
     */
    void pauseAllSounds();

    /**
     * Resumes all sounds that were previously paused by {@link #pauseAllSounds()} method.
     */
    void resumeAllSounds();
}
