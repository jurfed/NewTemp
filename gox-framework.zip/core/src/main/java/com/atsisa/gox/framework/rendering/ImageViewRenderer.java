package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.IImageLayer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Implementation of image view rendering.
 */
public class ImageViewRenderer extends InteractiveViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the ImageViewRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public ImageViewRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    @Override
    public Class<?> getType() {
        return ImageView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        if (viewType == ViewType.IMAGE_VIEW) {
            lv.layer = (IImageLayer) getViewLayer(view);
            lv.leftChanges = changes;
            if (BitUtility.isSet(lv.leftChanges, ImageView.ViewPropertyName.IMAGE)) {
                lv.image = ((ImageView) view).getImage();
                if (lv.image != null) {
                    lv.layer.setImage(lv.image.getImageWrapperObject());
                }
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ImageView.ViewPropertyName.IMAGE);
            }
            if (BitUtility.isSet(lv.leftChanges, ImageView.ViewPropertyName.SMOOTHING)) {
                lv.layer.setSmoothing(((ImageView) view).isSmoothing());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ImageView.ViewPropertyName.SMOOTHING);
            }
            if (BitUtility.isSet(lv.leftChanges, ImageView.ViewPropertyName.TRANSFORM)) {
                lv.layer.setTransform(((ImageView) view).getTransform());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, ImageView.ViewPropertyName.TRANSFORM);
            }
            return lv.leftChanges;
        }
        return super.render(view, viewType, changes);
    }

    /**
     * Creates and returns IImageLayer specific platform implementation.
     * @param view - View
     * @return IImageLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    public IImageLayer createLayer(View view) {
        return getLayerFactory().createImageLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link ImageViewRenderer} render method.
     */
    private class LocalVariables {

        private IImageLayer layer;

        private IImageReference image;

        private int leftChanges;
    }
}
