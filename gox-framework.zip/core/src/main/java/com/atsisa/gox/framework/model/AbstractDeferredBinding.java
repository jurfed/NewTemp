package com.atsisa.gox.framework.model;

import java.util.Optional;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Represents an abstract class for deferred binding.
 */
public abstract class AbstractDeferredBinding extends PropertyBinding {

    /**
     * Property value.
     */
    final String propertyValue;

    /**
     * Logger.
     */
    protected final ILogger logger;

    /**
     * Screen model.
     */
    protected ScreenModel model;

    /**
     * Initializes a new instance of the {@link AbstractDeferredBinding} class.
     * @param propertyValue  a property value
     * @param targetProperty a target property
     * @param logger         a logger
     */
    private AbstractDeferredBinding(String propertyValue, ObservableProperty targetProperty, ILogger logger) {
        super(targetProperty, logger);
        this.propertyValue = propertyValue;
        this.logger = logger;
    }

    /**
     * Initializes a new instance of the {@link AbstractDeferredBinding} class.
     * @param propertyValue  a property value
     * @param targetProperty a target property
     */
    AbstractDeferredBinding(String propertyValue, ObservableProperty targetProperty) {
        this(propertyValue, targetProperty, GameEngine.current().getLogger());
    }

    @Override
    public void update() {
        if (getSourceProperty() == null) {
            logger.warn("Unable to retrieve source property for binding {%s}", propertyValue);
        }
        super.update();
    }

    @Override
    protected Object getSourcePropertyValue() {
        IObservableProperty property = getSourceProperty();
        if (property != null) {
            return property.get();
        }
        return propertyValue;
    }

    /**
     * Sets the model and updates the source property reference.
     * @param model corresponding model
     */
    public void setModel(ScreenModel model) {
        this.model = model;
        if (this.model == null) {
            return;
        }

        Optional<IObservableProperty> optionalObservableProperty = obtainObservableProperty(model);
        if (optionalObservableProperty.isPresent()) {
            setSourceProperty(optionalObservableProperty.get());
        } else {
            logger.error("AbstractDeferredBinding | setModel | Cannot obtain the IObservableProperty object.");
        }
    }

    /**
     * Obtain an observable property according to specific deferred binding.
     * @param model a screen model
     * @return if successfully an optional has value, otherwise not
     */
    protected abstract Optional<IObservableProperty> obtainObservableProperty(ScreenModel model);
}
