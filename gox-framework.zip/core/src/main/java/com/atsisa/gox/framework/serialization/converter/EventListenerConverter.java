package com.atsisa.gox.framework.serialization.converter;

import com.atsisa.gox.framework.event.ActionQueueEventListener;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.ScreenMethodEventListener;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Converts event listener XML notation in following ways:
 * <p>
 * 1. action queue notation (like @queueName) into an instance of the ActionEventListener class which will process given queue in the callback.
 * </p>
 * <p>
 * 2. screen setMethod notation (like #methodName) into an instance of the ScreenMethodEventListener class which will invoke given setMethod signature
 * </p>
 */
public class EventListenerConverter implements IValueConverter {

    @Override
    public Class<?> getValueType() {
        return IEventListener.class;
    }

    @Override
    public String convertTo(Object objToConvert) {
        if (objToConvert instanceof ActionQueueEventListener) {
            return StringUtility.format("@%s", ((ActionQueueEventListener) objToConvert).getActionQueueName());
        } else if (objToConvert instanceof ScreenMethodEventListener) {
            return StringUtility.format("#%s", ((ScreenMethodEventListener) objToConvert).getMethodName());
        }
        return null;
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (StringUtility.isNullOrEmpty(serializedMessage)) {
            return null;
        }
        if (serializedMessage.startsWith("@")) {
            return new ActionQueueEventListener(serializedMessage.substring(1));
        } else if (serializedMessage.startsWith("#")) {
            int parametersIndicatorIndex = serializedMessage.indexOf('@');
            if (parametersIndicatorIndex == -1) {
                return new ScreenMethodEventListener(serializedMessage.substring(1), new String[0]);
            } else {
                //TODO parameters fixed as strings, extend for types and arrays
                String[] parameters = serializedMessage.substring(parametersIndicatorIndex + 1).split(",");
                return new ScreenMethodEventListener(serializedMessage.substring(1, parametersIndicatorIndex), parameters);
            }
        }
        throw new ConversionException(StringUtility.format("Invalid event listener link '%s'", serializedMessage));
    }
}
