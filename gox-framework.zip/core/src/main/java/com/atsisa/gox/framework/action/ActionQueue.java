package com.atsisa.gox.framework.action;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.exception.ActionQueueStateException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Group of actions that is executed sequential.
 */
public class ActionQueue implements IActionQueue {

    /**
     * Array actions.
     */
    private Action[] actions;

    /**
     * An unique id of queue.
     */
    private final long id;

    /**
     * Last active action.
     */
    private Action lastActiveAction;

    /**
     * Last action index.
     */
    private int lastActionIndex;

    /**
     * ILogger implementation.
     */
    private final ILogger logger;

    /**
     * Queue name.
     */
    private final String name;

    /**
     * Action queue state.
     */
    private ActionQueueState state = ActionQueueState.PENDING;

    /**
     * State listeners list.
     */
    private final List<IStateListener<ActionQueueState>> stateListeners;

    /**
     * Action state listener.
     */
    private IStateListener<ActionState> actionStateListener;

    /**
     * Initializes a new instance of the ActionQueue class.
     * @param actionsArray an array of actions
     * @param id           new identifier for the queue
     * @param logger       logger instance
     * @param name         the name of the action queue
     */
    ActionQueue(final Action[] actionsArray, final long id, ILogger logger, String name) {
        logger.trace("ActionQueue | ctor | %s", this);
        this.logger = logger;
        this.id = id;
        this.name = name;
        lastActionIndex = -1;
        stateListeners = new ArrayList<>();
        try {
            if (actionsArray == null) {
                throw new ActionQueueStateException("Action array cannot be empty");
            } else if (actionsArray.length == 0) {
                throw new ActionQueueStateException("Action array cannot have 0 elements");
            } else {
                for (Action action : actionsArray) {
                    if (action == null) {
                        throw new ActionQueueStateException("Action array cannot have empty elements");
                    }
                }
            }
        } catch (ActionQueueStateException e) {
            logger.error("ActionQueue | ctor | An error occurred", e);
            throw e;
        }
        actions = new Action[actionsArray.length];
        actionStateListener = createActionStateListener();
        for (int i = 0; i < actionsArray.length; ++i) {
            actions[i] = actionsArray[i];
            actions[i].setParentQueue(this);
            actions[i].setQueueIndex(i);
            actions[i].addStateListener(actionStateListener);
        }
    }

    /**
     * Constructor.
     * @param actionsArray IAction[]
     * @param newId        new id for queue
     * @param name         String
     */
    ActionQueue(final Action[] actionsArray, long newId, String name) {
        this(actionsArray, newId, GameEngine.current().getLogger(), name);
    }

    @Override
    public final IAction getLastActiveAction() {
        return lastActiveAction;
    }

    @Override
    public ActionQueueState getState() {
        return state;
    }

    @Override
    public final long getId() {
        return id;
    }

    @Override
    public final String[] getActionNames() {
        String[] list = new String[actions.length];
        for (int i = 0; i < list.length; ++i) {
            list[i] = actions[i].getName();
        }
        return list;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public final IAction[] getActions() {
        return actions;
    }

    @Override
    public final String[] getActionToStringList() {
        String[] list = new String[actions.length];
        for (int i = 0; i < list.length; ++i) {
            list[i] = actions[i].toString();
        }
        return list;
    }

    @Override
    public void addStateListener(IStateListener<ActionQueueState> listener) {
        stateListeners.add(listener);
    }

    @Override
    public void removeStateListener(IStateListener<ActionQueueState> listener) {
        stateListeners.remove(listener);
    }

    @Override
    public void clearStateListeners() {
        stateListeners.clear();
    }

    @Override
    public String toString() {
        if (!StringUtility.isNullOrEmpty(name)) {
            return StringUtility.format("%s (%s)", name, super.toString());
        }
        return super.toString();
    }

    /**
     * Terminates currently active action and sets the state to PAUSED.
     */
    void pause() {
        logger.debug("ActionQueue | pause | %s", this);
        if (state == ActionQueueState.ACTIVE) {
            setState(ActionQueueState.PAUSED);
            lastActiveAction.doTerminate();
        } else {
            raiseStateError();
        }
    }

    /**
     * Terminates currently active action and sets the state to DESTROYED. Unless the action queue is in the PENDING, PAUSED or ACTIVE state an
     * ActionQueueStateException will be thrown.
     */
    void destroy() {
        logger.debug("ActionQueue | destroy | %s", this);
        validateState(ActionQueueState.PENDING, ActionQueueState.PAUSED, ActionQueueState.ACTIVE);
        setState(ActionQueueState.DESTROYED);
        cleanUp();
        if (state != ActionQueueState.PAUSED) {
            for (Action action : (Action[]) getActions()) {
                action.doTerminate();
            }
        }
    }

    /**
     * Terminates currently active action.
     */
    void terminateCurrentAction() {
        if (state == ActionQueueState.ACTIVE && lastActiveAction != null) {
            lastActiveAction.doTerminate();
        }
    }

    /**
     * Unless the action queue is in the PENDING, PAUSED or ACTIVE state an ActionQueueStateException will be thrown.
     */
    void process() {
        logger.debug("ActionQueue | process | %s", this);
        validateState(ActionQueueState.PENDING, ActionQueueState.PAUSED, ActionQueueState.ACTIVE);
        if (lastActiveAction != null && !lastActiveAction.isFinished()) {
            throw new ActionQueueStateException(StringUtility
                    .format("Current action %s is still in progress. Cannot process more than one action in the same time.", lastActiveAction.toString()));
        }

        setState(ActionQueueState.ACTIVE);
        int nextIdx = lastActionIndex + 1;
        if (nextIdx >= actions.length || lastActiveAction != null && lastActiveAction.noFurtherProcessing()) { // NOPMD
            lastActiveAction = null;
            lastActionIndex = -1;
            finish();
        } else {
            lastActiveAction = actions[nextIdx];
            lastActionIndex = nextIdx;
            lastActiveAction.doExecute();
        }
    }

    /**
     * Finishes this action queue executing by removing all containing action state listeners and setting action queue state to FINISHED.
     */
    protected final void finish() {
        logger.debug("ActionQueue | finish | %s", this);
        validateState(ActionQueueState.PENDING, ActionQueueState.PAUSED, ActionQueueState.ACTIVE);
        for (Action action : actions) {
            action.removeStateListener(actionStateListener);
        }
        setState(ActionQueueState.FINISHED);
        cleanUp();
    }

    /**
     * Cleans up all action and queue listeners.
     */
    private void cleanUp() {
        stateListeners.clear();
        for (Action action : actions) {
            action.setParentQueue(null);
            action.removeStateListener(actionStateListener);
        }
        actionStateListener = null;
    }

    /**
     * Sets the action queue state and notifies all action queue listeners about changes.
     * @param state new action queue state
     */
    private void setState(ActionQueueState state) {
        if (this.state != state) {
            logger.trace("ActionQueue | setState | New '%s' action queue state: %s", this, state);
            this.state = state;
            List<IStateListener<ActionQueueState>> stateListenersCopy = new ArrayList<>(stateListeners);
            for (IStateListener<ActionQueueState> item : stateListenersCopy) {
                item.stateChanged(this, state);
            }
        }
    }

    /**
     * Validates if the current action queue is in one of the valid states. Throws ActionQueueStateException if validation failed.
     * @param validStates valid states to check
     */
    private void validateState(ActionQueueState... validStates) {
        for (ActionQueueState validState : validStates) {
            if (state == validState) {
                return;
            }
        }
        raiseStateError();
    }

    /**
     * Throws an ActionQueueStateException with invalid action queue state message.
     */
    private void raiseStateError() {
        throw new ActionQueueStateException(StringUtility.format("Invalid action queue state '%s'. %s", state, toString()));
    }

    /**
     * Creates a global action state listener for all inner actions.
     * @return a global action state listener
     */
    private IStateListener<ActionState> createActionStateListener() {
        return new IStateListener<ActionState>() {

            @Override
            public void stateChanged(Object source, ActionState actionState) {
                if (((Action) source).isFinished() && getState() == ActionQueueState.ACTIVE) {
                    process();
                }
            }
        };
    }
}
