package com.atsisa.gox.framework.utility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * A utility class for {@link Iterable}.
 */
public final class Iterables {

    /**
     * Prevents from creating instances of this class.
     */
    private Iterables() {
    }

    /**
     * Creates a new {@link ArrayList} from given collection.
     * @param items A collection of items.
     * @param <T>   The type of items.
     * @return A list of items.
     */
    public static <T> List<T> newArrayListFrom(Iterable<T> items) {
        List<T> list = new ArrayList<>();
        for (T item : items) {
            list.add(item);
        }

        return list;
    }

    /**
     * Converts a collection of items to a list.
     * @param items A collection of items.
     * @param <T>   The type of items.
     * @return A list of items.
     */
    public static <T> List<T> toList(Iterable<T> items) {
        if (items instanceof List) {
            return (List<T>) items;
        }
        return newArrayListFrom(items);
    }

    /**
     * Gets the first item in given collection.
     * @param items        A collection of items.
     * @param defaultValue The default value in case the collection is empty.
     * @param <T>          The type of items.
     * @return The first item in the collection.
     */
    public static <T> T getFirst(Iterable<T> items, T defaultValue) {
        Iterator<T> iterator = items.iterator();
        return iterator.hasNext() ? iterator.next() : defaultValue;
    }

    /**
     * Returns the number of elements in {@code iterable}.
     * @param iterable an {@code iterable}
     * @return the number of elements in {@code iterable}
     */
    public static int size(Iterable<?> iterable) {
        return iterable instanceof Collection ? ((Collection<?>) iterable).size() : Iterators.size(iterable.iterator());
    }

    /**
     * Gets the last item in given collection.
     * @param items        a collection of items
     * @param defaultValue the default value in case the collection is empty
     * @param <T>          the type of items
     * @return the last item in the collection
     */
    public static <T> T getLast(Iterable<T> items, T defaultValue) {
        Iterator<T> iterator = items.iterator();
        T lastItem = defaultValue;
        while (iterator.hasNext()) {
            lastItem = iterator.next();
        }

        return lastItem;
    }

    /**
     * Adds all items from given iterable to the collection.
     * @param collection A collection the items should added to.
     * @param items      A collection of items to be added.
     * @param <T>        Type of items.
     */
    public static <T> void addAll(Collection<T> collection, Iterable<T> items) {
        for (T item : items) {
            collection.add(item);
        }
    }

    /**
     * Check whether two collections have both same items.
     * @param first  The first collection.
     * @param second The second collection.
     * @param <T>    Type of items.
     * @return True if both collections have same items, false otherwise.
     */
    public static <T> boolean areEqual(Iterable<? extends T> first, Iterable<? extends T> second) {
        if (first == null || second == null) {
            return first == second;
        }
        Iterator<? extends T> firstIterator = first.iterator();
        Iterator<? extends T> secondIterator = second.iterator();
        while (firstIterator.hasNext() && secondIterator.hasNext()) {
            if (!firstIterator.next().equals(secondIterator.next())) {
                return false;
            }
        }
        return !(firstIterator.hasNext() ^ secondIterator.hasNext());
    }

    /**
     * Returns an empty iterable of given type.
     * @param <T>       The type of iterable.
     * @param itemClass The item class.
     * @return The empty iterable.
     */
    @SuppressWarnings("unchecked")
    public static <T> Iterable<T> empty(Class<T> itemClass) {
        return (Iterable<T>) Collections.emptyList();
    }

    /**
     * Returns an empty iterable of given type.
     * @param <T> The type of iterable.
     * @return The empty iterable.
     */
    @SuppressWarnings("unchecked")
    public static <T> Iterable<T> empty() {
        return (Iterable<T>) Collections.emptyList();
    }

    /**
     * Returns an empty list of given type.
     * @param <T>       The type of list.
     * @param itemClass The item class.
     * @return The empty list.
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> emptyList(Class<T> itemClass) {
        return (List<T>) Collections.emptyList();
    }

    /**
     * Returns an empty list of given type.
     * @param <T> The type of list.
     * @return The empty list.
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> emptyList() {
        return (List<T>) Collections.emptyList();
    }
}
