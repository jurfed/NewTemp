package com.atsisa.gox.framework.serialization.interceptor;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.serialization.ISetterInterceptor;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.Field;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;

/**
 * Property binding interceptor.
 * Intercepts ${propertyName} syntax and injects the proper from configuration provider.
 */
public class PropertyBindingInterceptor implements ISetterInterceptor {

    /**
     * Binding starting tag.
     */
    private static final String START_TAG = "${";

    /**
     * Binding ending tag.
     */
    private static final String END_TAG = "}";

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * A configuration provider reference.
     */
    private final IConfigurationProvider configurationProvider;

    /**
     * Initializes a new instance of the PropertyBindingInterceptor class.
     */
    public PropertyBindingInterceptor() {
        this(GameEngine.current().getLogger(), GameEngine.current().getConfigurationProvider());
    }

    /**
     * Initializes a new instance of the PropertyBindingInterceptor class using specific logger and configuration provider.
     * @param logger                a logger reference
     * @param configurationProvider a configuration provider reference
     */
    public PropertyBindingInterceptor(ILogger logger, IConfigurationProvider configurationProvider) {
        this.logger = logger;
        this.configurationProvider = configurationProvider;
    }

    @Override
    public boolean beforeSetterInvoked(Method setter, Field field, Object target, String rawValue) {
        if (rawValue != null && rawValue.startsWith(START_TAG) && rawValue.endsWith(END_TAG)) {
            int startIdxIncl = START_TAG.length();
            int endIdxExcl = rawValue.length() - END_TAG.length();
            String propertyName = rawValue.substring(startIdxIncl, endIdxExcl);

            IConfiguration configuration = configurationProvider.getConfiguration();

            Object propertyVal = configuration.getProperty(propertyName);
            if (propertyVal != null) {
                try {
                    setter.invoke(target, propertyVal);
                } catch (ReflectionException e) {
                    logger.warn("Could not inject configuration property " + rawValue, e);
                }
                return false;
            }
        }
        return true;
    }
}
