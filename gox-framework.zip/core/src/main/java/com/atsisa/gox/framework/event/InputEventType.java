package com.atsisa.gox.framework.event;

import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Interactive views input event types.
 */
@Reflect_Full
public enum InputEventType {

    /**
     * Triggered when mouse is up the source.
     */
    MOUSE_UP,

    /**
     * Triggered when mouse is down the source.
     */
    //MOUSE_DOWN,

    /**
     * Triggered when mouse is dragging the source.
     */
    //MOUSE_DRAG,

    /**
     * Triggered when mouse moves over the source.
     */
    MOUSE_MOVE,

    /**
     * Triggered when mouse is over the source.
     */
    MOUSE_OVER,

    /**
     * Triggered when mouse leaves source's bounding box.
     */
    MOUSE_OUT,

    /**
     * Triggered on mouse wheel scroll.
     */
    MOUSE_WHEEL_SCROLL,

    /**
     * Triggered when touch starts on the source.
     */
    TOUCH_START,

    /**
     * Triggered when touch moves on the source.
     */
    TOUCH_MOVE,

    /**
     * Triggered when touch ends on the source.
     */
    TOUCH_END,

    /**
     * Triggered when touch is cancelled.
     */
    //TOUCH_CANCEL,

    /**
     * Triggered when pointer starts to move.
     */
    //POINTER_START,

    /**
     * Triggered when pointer ends to move.
     */
    //POINTER_END,

    /**
     * Triggered when pointer drags.
     */
    //POINTER_DRAG,

    /**
     * Triggered when pointer was cancelled.
     */
    //POINTER_CANCEL,

    /**
     * Triggered when buttons are released (either by mouse or touch).
     */
    RELEASED,

    /**
     * Triggered when key was pressed.
     */
    KEY_DOWN,

    /**
         * Triggered when key was released.
     */
    KEY_UP
}
