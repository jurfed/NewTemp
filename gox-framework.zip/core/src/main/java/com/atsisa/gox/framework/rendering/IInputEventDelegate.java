package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.view.InteractiveView;

/**
 * Exposes methods for binding interactive view with an event delegate in order to propagate events to that view.
 * @param <T> extends {@link ILayer}
 */
public interface IInputEventDelegate<T extends ILayer> {

    /**
     * Binds given interactive view with current delegate to enable events propagation.
     * @param interactiveView interactive view
     * @param layer           T extends ILayer
     */
    void bind(InteractiveView interactiveView, T layer);

    /**
     * Unbinds previously associated interactive view with his layer to disable events propagation.
     * @param interactiveView interactive view
     */
    void unbind(InteractiveView interactiveView);

    /**
     * Pauses delegating input events.
     * @return true if delegating has been paused successfully
     */
    boolean pause();

    /**
     * Resumes delegating input events.
     * @return true if delegating has been resumed successfully
     */
    boolean resume();

    /**
     * Gets state of this input event delegate.
     * @return the input event delegate
     */
    InputEventDelegateState getState();

    /**
     * Clears all bindings.
     */
    void clear();
}
