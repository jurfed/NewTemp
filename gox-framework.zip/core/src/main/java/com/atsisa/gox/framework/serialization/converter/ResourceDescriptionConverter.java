package com.atsisa.gox.framework.serialization.converter;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.resource.ResourceDescription;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Converter used to convert xml objects to list of resources description.
 */
public class ResourceDescriptionConverter extends PatternConverter {

    /**
     * Name of the tag id.
     */
    private static final String ID = "id";

    /**
     * Name of the tag url.
     */
    private static final String URL = "url";

    /**
     * Name of the tag idPattern.
     */
    private static final String ID_PATTERN = "idPattern";

    /**
     * Name of the tag urlPattern.
     */
    private static final String URL_PATTERN = "urlPattern";

    /**
     * Name of the tag resource.
     */
    private static final String RESOURCE_NAME = "resource";

    /**
     * Name of the tag start.
     */
    private static final String START_TAG = "start";

    /**
     * Name of the tag end.
     */
    private static final String END_TAG = "end";

    private static final String BUILD_MODE_TAG = "{BUILD_MODE}";

    private static final String BUILD_MODE = "release";

    /**
     * Reference to serializer.
     */
    private IXmlSerializer serializer;

    /**
     * Reference to logger.
     */
    private ILogger logger;

    /**
     * Creates a new instance of the ResourceDescriptionConverter with default serializer and logger.
     */
    public ResourceDescriptionConverter() {
        this(GameEngine.current().getUtility().getSerialization().getSerializer(SerializationFormat.XML), GameEngine.current().getLogger());
    }

    /**
     * Creates a new instance of the ResourceDescriptionConverter.
     * @param serializer - reference to the serializer
     * @param logger     - reference to the logger
     */
    public ResourceDescriptionConverter(IXmlSerializer serializer, ILogger logger) {
        this.logger = logger;
        this.serializer = serializer;
    }

    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    /**
     * Not implemented.
     * @param objToConvert - not implemented
     * @return UnsupportedOperationException
     */
    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException("Not implemented!");
    }

    /**
     * Converts parsed object (not serialized message) to array list of resources description.
     * @param serializedMessage a string representation of a Java object. Contains string without main element.
     * @param parsedObject      - IParsedObject. Contains parsed whole structure with main element.
     * @return array list with resources description.
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        XmlObject xmlObject;
        if (parsedObject instanceof XmlObject) {
            xmlObject = (XmlObject) parsedObject;
        } else if (parsedObject instanceof XmlObjectDocument) {
            xmlObject = ((XmlObjectDocument) parsedObject).getDocumentElement();
        } else {
            throw new IllegalArgumentException("Failed to convert parsedObject");
        }

        List<XmlObject> xmlChildrenList = xmlObject.getChildren();
        List<ResourceDescription> resourceDescriptions = new ArrayList<>();
        for (XmlObject xmlChildren : xmlChildrenList) {
            String id = xmlChildren.getAttribute(ID);
            String url = xmlChildren.getAttribute(URL);
            if (url != null && url.contains(BUILD_MODE_TAG)) {
                url = url.replace(BUILD_MODE_TAG, BUILD_MODE);
                xmlChildren.addAttribute(URL, url);
            }
            String idPattern = xmlChildren.getAttribute(ID_PATTERN);
            String urlPattern = xmlChildren.getAttribute(URL_PATTERN);
            if (urlPattern != null && urlPattern.contains(BUILD_MODE_TAG)) {
                urlPattern = urlPattern.replace(BUILD_MODE_TAG, BUILD_MODE);
                xmlChildren.addAttribute(URL_PATTERN, urlPattern);
            }

            if (id != null && idPattern != null || url != null && urlPattern != null) {
                logger.warn("idPattern and id or urlPattern and url are defined for id: %s. Only one should be defined.", xmlChildren.getAttribute("id"));
            } else if (idPattern != null || urlPattern != null) {
                if (idPattern == null || urlPattern == null) {
                    logger.warn("Missing idPattern or urlPattern for id: %s", xmlChildren.getAttribute("name"));
                    continue;
                }
                resourceDescriptions.addAll(getResourceDescriptionsUsingPattern(xmlChildren, idPattern, urlPattern));
            } else {
                resourceDescriptions.add(getResourceDescriptionUsingItem(xmlChildren));
            }
        }
        return resourceDescriptions;
    }

    /**
     * Returns list of resource descriptions converted from xml object based on patterns.
     * @param resourceDescriptionObject - xml object to convert
     * @param idPattern                 - content of the idPattern attribute
     * @param urlPattern                - content of the urlPattern attribute
     * @return list of resource descriptions
     */
    @SuppressWarnings("unchecked")
    private List<ResourceDescription> getResourceDescriptionsUsingPattern(XmlObject resourceDescriptionObject, String idPattern, String urlPattern) {
        List<ResourceDescription> resourceDescriptions = new ArrayList<>();
        int start = Integer.parseInt(resourceDescriptionObject.getAttribute(START_TAG));
        int end = Integer.parseInt(resourceDescriptionObject.getAttribute(END_TAG));
        int[] idPatternSpan = getPatternSpan(idPattern);
        int[] urlPatternSpan = getPatternSpan(urlPattern);
        CsvConverter csvConverter = new CsvConverter();

        String resourceType = resourceDescriptionObject.getAttribute("type");
        String formatType = resourceDescriptionObject.getAttribute("format");
        boolean loadRuntime = false;
        if (resourceDescriptionObject.getAttribute("loadRuntime") != null) {
            loadRuntime = Boolean.valueOf(resourceDescriptionObject.getAttribute("loadRuntime"));
        }

        for (int i = start; i <= end; i++) {
            String idReference = getReference(idPattern, idPatternSpan, i);
            String urlReference = getReference(urlPattern, urlPatternSpan, i);
            List<String> formatList = (List<String>) csvConverter.convertFrom(formatType, null);
            ResourceDescription resourceDescription = new ResourceDescription(idReference, urlReference, ResourceType.fromString(resourceType), formatList);
            GameEngine.current().getResourceManager().setPathToResource(resourceDescription);
            resourceDescription.setLoadRuntime(loadRuntime);
            resourceDescriptions.add(resourceDescription);
        }
        return resourceDescriptions;
    }

    /**
     * Returns one resource description converted from xml object.
     * @param resourceDescriptionObject - xml object to convert
     * @return converted resource description
     * @throws SerializationException - if the serialization fails.
     */
    private ResourceDescription getResourceDescriptionUsingItem(XmlObject resourceDescriptionObject) throws ConversionException {
        if (resourceDescriptionObject.getName().equals(RESOURCE_NAME)) {
            try {
                return (ResourceDescription) serializer.deserialize(resourceDescriptionObject, ResourceDescription.class, null);
            } catch (SerializationException e) {
                throw new ConversionException("Could not deserialize resource description.", e);
            }
        }

        throw new ConversionException("Invalid name of element. Name of element should be - 'resource'");
    }
}
