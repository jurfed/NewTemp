package com.atsisa.gox.framework.model;

import java.util.Optional;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;

/**
 * Represents a deferred template binding.
 */
public class DeferredTemplateBinding extends AbstractDeferredBinding {

    /**
     * Initializes a new instance of the DeferredExternalBinding class.
     * @param propertyValue  property value
     * @param targetProperty target property object
     */
    public DeferredTemplateBinding(String propertyValue, ObservableProperty targetProperty) {
        super(propertyValue, targetProperty);
    }

    @Override
    protected Optional<IObservableProperty> obtainObservableProperty(ScreenModel model) {
        return Optional.of(model.getTemplate(propertyValue));
    }
}
