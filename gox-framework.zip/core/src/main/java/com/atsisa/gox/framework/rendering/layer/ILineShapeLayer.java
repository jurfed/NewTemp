package com.atsisa.gox.framework.rendering.layer;

import java.util.List;

import com.atsisa.gox.framework.utility.Point;

/**
 * Exposes methods for line layer.
 */
public interface ILineShapeLayer extends IShapeLayer {

    /**
     * Sets line thickness.
     * @param thickness - int
     */
    void setThickness(int thickness);

    /**
     * Sets the color layer.
     * @param color - int
     */
    void setColor(int color);

    /**
     * Draws lines using a list of points.
     * @param linePoints - List of Point
     */
    void drawLine(List<Point> linePoints);

}
