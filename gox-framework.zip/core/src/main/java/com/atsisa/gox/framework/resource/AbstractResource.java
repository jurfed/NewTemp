package com.atsisa.gox.framework.resource;

import java.util.Arrays;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.exception.ResourceUnavailableException;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Abstract class for resource type.
 */
public abstract class AbstractResource implements IResource {

    /**
     * Expected resource type for validation purposes.
     */
    private final ResourceType expectedType;

    /**
     * Resource manager reference.
     */
    private final IResourceManager resourceManager;

    /**
     * ILogger reference.
     */
    private final ILogger logger;

    /**
     * Current resource state.
     */
    private ResourceState currentState;

    /**
     * Resource description object.
     */
    private ResourceDescription description;

    /**
     * Resource loading callback reference.
     */
    private IResourceLoadingCallback resourceLoadingCallback;

    /**
     * Constructor with setters for resource description, expected resource type and assets handler.
     * @param description  resource description object
     * @param expectedType expected resource type
     */
    public AbstractResource(ResourceDescription description, ResourceType expectedType) {
        this.description = description;
        this.expectedType = expectedType;
        logger = GameEngine.current().getLogger();
        resourceManager = GameEngine.current().getResourceManager();
        currentState = ResourceState.READY_TO_LOAD;
    }

    /**
     * Constructor with setters for resource description, expected resource type, assets handler and logger.
     * @param description     - resource description object
     * @param expectedType    - expected resource type
     * @param logger          - logger reference.
     * @param resourceManager - resource manager reference
     */
    public AbstractResource(ResourceDescription description, ResourceType expectedType, ILogger logger, IResourceManager resourceManager) {
        this.description = description;
        this.expectedType = expectedType;
        this.logger = logger;
        this.resourceManager = resourceManager;
        currentState = ResourceState.READY_TO_LOAD;
    }

    @Override
    public String getId() {
        return description.getId();
    }

    @Override
    public ResourceType getResourceType() {
        return description.getResourceType();
    }

    @Override
    public boolean isLoaded() {
        return currentState == ResourceState.LOADED;
    }

    @Override
    public ResourceDescription getDescription() {
        return description;
    }

    /**
     * Sets resource description.
     * @param description resource description object
     */
    public void setDescription(ResourceDescription description) {
        this.description = description;
    }

    /**
     * Returns arrays containing supported extensions. Null - every extension is supported.
     * @return array of Strings
     */
    public String[] getSupportedExtensions() {
        return null;
    }

    @Override
    public void load(IResourceLoadingCallback callback) {
        resourceLoadingCallback = callback;

        try {
            if (currentState != ResourceState.READY_TO_LOAD) {
                logger.warn(StringUtility.format("AbstractResource | load | Load setMethod can not be called on this resource, because current state is: %s",
                        currentState.toString()));
                return;
            }
            validateDescription(description);
            validateExtension();
            currentState = ResourceState.LOADING;

            doLoad();
        } catch (Exception ex) {
            if (callback != null) {
                callback.onError(description, 0, 1, ex);
            } else {
                throw new RuntimeException(ex);
            }
        }
    }

    @Override
    public void unload() {
        currentState = ResourceState.READY_TO_LOAD;
    }

    @Override
    public ResourceState getState() {
        return currentState;
    }

    /**
     * Gets default path.
     * @return string with path
     */
    protected String getDefaultPath() {
        return description.getTargetPath();
    }

    /**
     * Returns resource full path.
     * @return String
     */
    protected String getFullResourcePath() {
        return resourceManager.getFullResourcePath(getDefaultPath());
    }

    /**
     * Sets current this resource state.
     * @param state - State.
     */
    protected void setState(ResourceState state) {
        currentState = state;
    }

    /**
     * Validates if resource description has proper values.
     * @param resourceDescription resource description object
     */
    protected void validateDescription(ResourceDescription resourceDescription) {
        // Check if resource description is not null
        if (resourceDescription == null) {
            throw new IllegalArgumentException("Resource description cannot be null");
        }
        // Check if resource description is proper type
        if (resourceDescription.getResourceType() == null || resourceDescription.getResourceType() != expectedType) {
            throw new IllegalArgumentException(StringUtility.format("Description for type '%s' is invalid", expectedType.toString()));
        }
    }

    /**
     * Validates extension of the file. If not supported then throws ResourceUnavailableException.
     * @throws ResourceUnavailableException - if resource has improper file format.
     */
    protected void validateExtension() throws ResourceUnavailableException {
        String url = getDefaultPath();
        String[] supportedExtensions = getSupportedExtensions();
        if (supportedExtensions != null) {
            for (String properExtension : supportedExtensions) {
                if (url.endsWith(properExtension)) {
                    return;
                }
            }
            throw new ResourceUnavailableException(StringUtility
                    .format("Unsupported file format for resource id '%s'. Expected: %s", description.getId(), Arrays.toString(supportedExtensions)));
        }
    }

    /**
     * Triggers the loading of resource.
     */
    protected abstract void doLoad();

    /**
     * Called when error will occur.
     * @param message - String
     */
    protected void onError(String message) {
        logger.error(message);

        currentState = ResourceState.ERROR_LOADING;
        ResourceUnavailableException ex = new ResourceUnavailableException(message);
        resourceLoadingCallback.onError(description, 0, 1, ex);
    }

    /**
     * Called when resource will be successfully initialized/loaded.
     */
    protected void onSuccess() {
        currentState = ResourceState.LOADED;
        resourceLoadingCallback.onSuccess(this, 0, 1);
    }

    @Override
    public String toString() {
        return ResourceReference.convertToString(this);
    }
}
