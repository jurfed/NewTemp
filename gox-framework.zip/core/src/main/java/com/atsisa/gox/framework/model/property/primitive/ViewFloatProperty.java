package com.atsisa.gox.framework.model.property.primitive;

import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * A container base class for float-based primitive properties. Exposes methods for hooking up property listeners
 */
public class ViewFloatProperty extends FloatObservableProperty implements IViewProperty {

    /**
     * View property name identifier.
     */
    private final int viewPropertyName;

    /**
     * View type identifier.
     */
    private final ViewType viewType;

    /**
     * Corresponding view.
     */
    private final View view;

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     */
    public ViewFloatProperty(View view, ViewType viewType, int viewPropertyName) {
        this.view = view;
        addPropertyChangedListener(view);
        this.viewType = viewType;
        this.viewPropertyName = viewPropertyName;
    }

    /**
     * Initializes a new instance of the ViewProperty class.
     * @param view             corresponding view
     * @param viewType         view type identifier
     * @param viewPropertyName view property name identifier
     * @param defaultValue     initial value of float property
     */
    public ViewFloatProperty(View view, ViewType viewType, int viewPropertyName, float defaultValue) {
        this.view = view;
        this.viewType = viewType;
        this.viewPropertyName = viewPropertyName;
        set(defaultValue, false);
        addPropertyChangedListener(view);
    }

    @Override
    public boolean set(float newValue) {
        if (super.set(newValue)) {
            view.propertyChanged(viewType, viewPropertyName);
            return true;
        }
        return false;
    }

    /**
     * Sets the property value and notifies listeners about changes. Notification will only be triggered if the actual value has changed.
     * @param newValue new property value
     * @param notify   when true, property change is notified, otherwise false
     * @return true if a new value differs from the current value, false otherwise
     */
    public boolean set(float newValue, boolean notify) {
        if (super.set(newValue)) {
            if (notify) {
                view.propertyChanged(viewType, viewPropertyName);
            }
            return true;
        }
        return false;
    }

    /**
     * Gets the view property name identifier.
     * @return view property name identifier
     */
    @Override
    public int getViewPropertyName() {
        return viewPropertyName;
    }

    /**
     * Gets the view type identifier.
     * @return the view type identifier
     */
    @Override
    public ViewType getViewType() {
        return viewType;
    }

    /**
     * Gets the corresponding view.
     * @return View
     */
    @Override
    public View getView() {
        return view;
    }
}
