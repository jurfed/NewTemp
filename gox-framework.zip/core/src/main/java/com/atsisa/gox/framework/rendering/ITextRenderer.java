package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.view.View;

/**
 * Text rendering interface, each of the text renderer (text view rendering, bitmap font view rendering) should it
 * implement.
 */
public interface ITextRenderer extends IViewRenderer {

    /**
     * Gets text width.
     * @param view - View
     * @return float
     */
    float getTextWidth(View view);

    /**
     * Gets text height.
     * @param view - View
     * @return float
     */
    float getTextHeight(View view);
}
