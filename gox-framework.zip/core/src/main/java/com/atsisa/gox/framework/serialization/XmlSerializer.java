package com.atsisa.gox.framework.serialization;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ConversionException;
import com.atsisa.gox.framework.serialization.converter.IValueConverter;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.model.ArrayListWithAttributes;
import com.atsisa.gox.framework.utility.reflection.Field;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.Method;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * The implementation of XML serializer. Exposes methods for serializing/de-serializing objects into/from XML strings
 */
@Reflectable(methods = false, fields = false)
public class XmlSerializer implements IXmlSerializer {

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * A XML parser reference.
     */
    private final IParser parser;

    /**
     * A reflection helper reference.
     */
    private final IReflection reflection;

    /**
     * A localization helper reference.
     */
    private final ILocalization localization;

    /**
     * A date format.
     */
    private String dateFormat;

    /**
     * A list of setter interceptors.
     */
    private List<ISetterInterceptor> setterInterceptors;

    /**
     * Initializes a new instance of the {@link XmlSerializer} class.
     * @param logger       {@link ILogger}
     * @param localization {@link ILocalization}
     * @param reflection   {@link IReflection}
     * @param parser       {@link IParser}
     */
    @Inject
    public XmlSerializer(ILogger logger, ILocalization localization, IReflection reflection, IParser parser) {
        logger.trace("XmlSerializer | ctor");

        this.logger = logger;
        this.parser = parser;
        this.reflection = reflection;
        this.localization = localization;

        setterInterceptors = new ArrayList<>();
    }

    @Override
    public SerializationFormat getFormat() {
        return SerializationFormat.XML;
    }

    @Override
    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    @Override
    public String getDateFormat() {
        return dateFormat;
    }

    /**
     * Serializes a java object into its XML string representation.
     * @param obj a java object to serialize
     * @return a XML string representation of given object
     * @throws SerializationException if serialization could not be performed
     */
    @Override
    public String serialize(Object obj) throws SerializationException {
        logger.debug("XmlSerializer | serialize");

        if (obj == null) {
            return null;
        }
        Class<?> objType = obj.getClass();
        String className = getSerializedClassName(objType);

        XmlObjectDocument document = new XmlObjectDocument();
        XmlObject xmlObject = document.createElement(className);
        document.setDocumentElement(xmlObject);
        serialize(obj, objType, xmlObject);
        return xmlObject.toXmlString();
    }

    /**
     * De-serializes a xml string representation of an object to its java instance.
     * @param serializedObj xml serialized object
     * @param objType       type of the expected deserialized object
     * @return deserialized java object
     * @throws SerializationException if deserialization could not be performed
     */
    @Override
    public Object deserialize(String serializedObj, Class<?> objType) throws SerializationException {
        logger.debug("XmlSerializer | deserialize");

        if (objType == null) {
            throw new SerializationException("Object type has not been set");
        }
        if (StringUtility.isNullOrEmpty(serializedObj)) {
            return null;
        }
        try {
            XmlObjectDocument xmlDocument = (XmlObjectDocument) parser.parse(serializedObj);
            XmlObject rootElement = xmlDocument.getDocumentElement();
            if (reflection.isArray(objType)) {
                return deserializeCollection(rootElement, objType, null);
            }
            return deserialize(rootElement, objType, null);
        } catch (Exception ex) {
            raiseException("XmlSerializer | deserialize", "An error occurred during deserializing an object", ex);
        }
        return null;
    }

    @Override
    public void addInterceptor(ISetterInterceptor setterInterceptor) {
        setterInterceptors.add(setterInterceptor);
    }

    @Override
    public void removeInterceptor(ISetterInterceptor setterInterceptor) {
        setterInterceptors.remove(setterInterceptor);
    }

    @Override
    public Object deserialize(Object object, String className) throws SerializationException {
        if (object instanceof XmlObject) {
            return deserialize((XmlObject) object, className);
        } else {
            throw new SerializationException("Provided object is not an instance of XmlObject");
        }
    }

    @Override
    public Object deserialize(XmlObject xmlElement, String className) throws SerializationException {
        Class clazz;

        try {
            clazz = reflection.getClassForName(className);
        } catch (ReflectionException e) {
            throw new SerializationException("Exception while de-serializing", e);
        }

        return deserialize(xmlElement, clazz, null);
    }

    @Override
    public Object deserialize(XmlObject xmlElement, Class<?> objectType, Class<?> parentType) throws SerializationException {
        if (objectType == null || xmlElement == null) {
            return null;
        }
        try {
            if (isPrimitive(objectType)) {
                return deserializePrimitive(xmlElement, objectType);
            } else if (isCollection(objectType)) {
                return deserializeCollection(xmlElement, objectType, parentType);
            } else {
                return deserializeObject(xmlElement, objectType);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            raiseException("XmlSerializer | deserialize", "An error occurred during deserialization. See inner exception for details", ex);
        }
        return null;
    }

    /**
     * De-serializes a generic object other than collections and primitives.
     * @param xmlElement XML element to deserialize
     * @param objectType generic object type to deserialize
     * @return a generic object instance
     * @throws SerializationException when a generic object cannot be deserialized from XML string
     */
    private Object deserializeObject(XmlObject xmlElement, Class<?> objectType) throws SerializationException {
        if (xmlElement == null) {
            return null;
        }
        validateXmlElementAnnotation(objectType);
        Object deserializedObj = null;
        try {
            deserializedObj = reflection.createInstance(objectType);
        } catch (ReflectionException ex) {
            raiseException("XmlSerializer | deserializeField", "An error occurred during creating a new instance of given class", ex);
        }
        List<Field> fieldList = getDeclaredFields(objectType);
        Collections.sort(fieldList, new FieldComparator());
        for (Field field : fieldList) {

            String serializedValue = getValueFromAttribute(xmlElement, field);
            XmlObject childObject = null;
            if (serializedValue == null) {
                childObject = getValueFromElement(xmlElement, field);
                if (childObject != null) {
                    serializedValue = childObject.getValue();
                }
            }

            Method setter;
            try {
                setter = reflection.fetchSetter(objectType, field);
            } catch (ReflectionException e) {
                throw new SerializationException("An error occurred during fetching setter", e);
            }
            boolean proceedInvocation = true;
            for (ISetterInterceptor interceptor : setterInterceptors) {
                if (!interceptor.beforeSetterInvoked(setter, field, deserializedObj, serializedValue)) {
                    proceedInvocation = false;
                    break;
                }
            }
            if (proceedInvocation) {
                Object deserializedChild = deserializeField(objectType, field, serializedValue, childObject);
                if (deserializedChild != null) {
                    try {
                        setter.invoke(deserializedObj, deserializedChild);
                    } catch (Exception ex) {
                        raiseException("XmlSerializer | deserializeField",
                                StringUtility.format("An error occurred during invoking setter for field '%s'.", field.getName()), ex);
                    }
                }
            }
        }
        return deserializedObj;
    }

    /**
     * Deserializes a generic object from XML string using its field definition.
     * @param objectType      generic object type to deserialize
     * @param field           a target field object
     * @param serializedValue raw, serialized value of the object
     * @param childObject     child XML object
     * @return a generic object instance
     * @throws SerializationException when a generic object cannot be deserialized from XML string
     */
    private Object deserializeField(Class<?> objectType, Field field, String serializedValue, XmlObject childObject) throws SerializationException {
        Object deserializedChild = null;
        IValueConverter[] converters = fetchConverters(field);
        if (converters != null && converters.length > 0) {
            deserializedChild = serializedValue;
            for (IValueConverter converter : converters) {
                try {
                    deserializedChild = converter.convertFrom((String) deserializedChild, childObject);
                } catch (ConversionException e) {
                    throw new SerializationException(StringUtility.format("Unable to deserialize child using %s converter.", converter), e);
                }
            }
        } else {
            Class<?> fieldType = fetchFieldType(field);
            if (childObject != null) {
                deserializedChild = deserialize(childObject, fieldType, objectType);
            } else if (serializedValue != null) {
                deserializedChild = deserializePrimitive(serializedValue, fieldType);
            }
        }
        return deserializedChild;
    }

    /**
     * Fetches field type modifications using XmlElement and XmlAttribute annotations.
     * @param field field to check
     * @return modified field type
     */
    private static Class<?> fetchFieldType(Field field) {
        XmlElement xmlElem = field.getAnnotation(XmlElement.class);
        if (xmlElem != null && xmlElem.type() != Void.class) {
            return xmlElem.type();
        }
        XmlAttribute xmlAttribute = field.getAnnotation(XmlAttribute.class);
        if (xmlAttribute != null && xmlAttribute.type() != Void.class) {
            return xmlAttribute.type();
        }
        XmlCollectionElement xmlCollectionElement = field.getAnnotation(XmlCollectionElement.class);
        if (xmlCollectionElement != null) {
            return List.class;
        }
        return field.getType();
    }

    /**
     * Gets the serialized value of a field from XML attribute. Might return null if there was no XmlAttribute
     * annotation defined.
     * @param xmlObject XmlObject to check
     * @param field     a target field object
     * @return the serialized value of a field from XML attribute.
     */
    private static String getValueFromAttribute(XmlObject xmlObject, Field field) {
        XmlAttribute xmlAttribute = field.getAnnotation(XmlAttribute.class);
        if (xmlAttribute != null) {
            String attributeName = !StringUtility.isNullOrEmpty(xmlAttribute.name()) ? xmlAttribute.name() : field.getName();
            return xmlObject.getAttributes().get(attributeName);
        }
        return null;
    }

    /**
     * Gets the serialized value of a field from XML element. Might return null if there was no XmlElement annotation
     * defined.
     * @param xmlObject XmlObject to check
     * @param field     a target field object
     * @return the serialized value of a field from XML element.
     */
    private static XmlObject getValueFromElement(XmlObject xmlObject, Field field) {
        XmlElement xmlElemAnnotation = field.getAnnotation(XmlElement.class);
        XmlCollectionElement xmlCollectionElement = field.getAnnotation(XmlCollectionElement.class);
        String elementName = field.getName();
        if (xmlElemAnnotation != null && !StringUtility.isNullOrEmpty(xmlElemAnnotation.name())) {
            elementName = xmlElemAnnotation.name();
        } else if (xmlCollectionElement != null && !StringUtility.isNullOrEmpty(xmlCollectionElement.name())) {
            elementName = xmlCollectionElement.name();
        }
        for (XmlObject child : xmlObject.getChildren()) {
            if (child.getName().equals(elementName)) {
                child.setCollectionElement(xmlCollectionElement);
                return child;
            }
        }

        return null;
    }

    /**
     * Deserializes primitive values from XML elements.
     * @param xmlObject  XML element to deserialized
     * @param objectType primitive type (according to isPrimitive method)
     * @return deserialized primitive value.
     */
    private Object deserializePrimitive(XmlObject xmlObject, Class<?> objectType) {
        if (xmlObject == null || objectType == null) {
            return null;
        }
        String elementValue = xmlObject.getValue();
        if (elementValue == null) {
            elementValue = "";
        }
        return deserializePrimitive(elementValue, objectType);
    }

    /**
     * Deserializes primitive values from string.
     * @param elementValue XML element value to deserialized
     * @param objectType   primitive type (according to isPrimitive method)
     * @return deserialized primitive value.
     */
    @SuppressWarnings("rawtypes")
    private Object deserializePrimitive(String elementValue, Class objectType) {
        if (elementValue.isEmpty() && objectType != String.class) {
            return null;
        }
        if (objectType == boolean.class || objectType == Boolean.class) {
            return Boolean.parseBoolean(elementValue);
        } else if (objectType == byte.class || objectType == Byte.class) {
            return Byte.parseByte(elementValue);
        } else if (objectType == short.class || objectType == Short.class) {
            return Short.parseShort(elementValue);
        } else if (objectType == int.class || objectType == Integer.class) {
            return Integer.parseInt(elementValue);
        } else if (objectType == long.class || objectType == Long.class) {
            return Long.parseLong(elementValue);
        } else if (objectType == float.class || objectType == Float.class) {
            return Float.parseFloat(elementValue);
        } else if (objectType == double.class || objectType == Double.class) {
            return Double.parseDouble(elementValue);
        } else if (objectType == char.class || objectType == Character.class) {
            if (!StringUtility.isNullOrEmpty(elementValue)) {
                return elementValue.charAt(0);
            }
            return '\0';
        } else if (objectType == String.class) {
            return elementValue;
        } else if (objectType == Date.class) {
            return localization.parseDate(elementValue, dateFormat);
        } else if (reflection.isEnum(objectType)) {
            // WORK_AROUND
            if (objectType == ResourceType.class) {
                return ResourceType.fromString(elementValue);
            }
            return Enum.valueOf(objectType, elementValue);
        }
        return null;
    }

    @Override
    public Object deserializeCollection(XmlObject xmlElement, Class<?> objType, Class<?> parentType) throws SerializationException {
        List<XmlObject> elemList = xmlElement.getChildren();

        XmlCollectionElement xmlCollectionElemAttr = xmlElement.getCollectionElement();
        if (xmlCollectionElemAttr == null && parentType == null) {
            xmlCollectionElemAttr = reflection.getAnnotation(objType, XmlCollectionElement.class);
        }

        Class<?> itemType = null;
        if (xmlCollectionElemAttr != null) {
            itemType = xmlCollectionElemAttr.itemType();
        } else if (reflection.isArray(objType)) {
            itemType = reflection.getArrayItemType(objType);
        }

        if (itemType != null) {
            ArrayListWithAttributes collection = new ArrayListWithAttributes();
            collection.setSerializationName(xmlElement.getName());
            Map<String, String> attributeMap = xmlElement.getAttributes();
            if (attributeMap != null) {
                for (Map.Entry<String, String> stringStringEntry : attributeMap.entrySet()) {
                    collection.addAttribute(stringStringEntry.getKey(), stringStringEntry.getValue());
                }
            }
            for (XmlObject childElem : elemList) {
                Object deserializedItem = deserialize(childElem, itemType, objType);
                collection.add(deserializedItem);
            }
            return collection;
        }
        return null;
    }

    /**
     * Serializes an object of given type into XmlObject object structure.
     * @param obj       object to serialize
     * @param objType   type of the serialized object
     * @param xmlObject a container which the object should be serialized into.
     * @throws SerializationException when an object cannot be serialized into XML string
     */
    private void serialize(Object obj, Class<?> objType, XmlObject xmlObject) throws SerializationException {
        try {
            if (isPrimitive(objType)) {
                xmlObject.setValue(serializePrimitive(obj, objType));
            } else if (isCollection(objType) || xmlObject.getCollectionElement() != null) {
                serializeCollection(obj, objType, xmlObject);
            } else {
                serializeObject(obj, objType, xmlObject);
            }
        } catch (Exception ex) {
            raiseException("XmlSerializer | serialize", "An error occurred during serialization. See inner exception for details", ex);
        }
    }

    /**
     * Serializes a generic object other than collections and primitives.
     * @param obj       object to serialize
     * @param objType   generic object type to serialize
     * @param xmlObject a container which the object should be serialized into.
     * @throws SerializationException when a generic object cannot be serialized into XML string
     */
    private void serializeObject(Object obj, Class<?> objType, XmlObject xmlObject) throws SerializationException {
        logger.debug("XmlSerializer | serializeObject | objType: %s", objType);

        validateXmlElementAnnotation(objType);
        List<Field> fieldList = getDeclaredFields(objType);
        Collections.sort(fieldList, new FieldComparator());
        for (Field field : fieldList) {
            Method getter;
            try {
                getter = reflection.fetchGetter(objType, field);
            } catch (ReflectionException e) {
                throw new SerializationException("An error occurred during fetching getter", e);
            }
            Object childObj = null;
            try {
                childObj = getter.invoke(obj);
            } catch (Exception ex) {
                raiseException("XmlSerializer | serializeObject", "An error occurred invoking getter for field '%s'.", field.getName());
            }
            if (childObj != null) {
                XmlObject innerObject = xmlObject.getOwnerDocument().createElement(null, xmlObject, null);
                innerObject.setCollectionElement(field.getAnnotation(XmlCollectionElement.class));

                if (!tryConvertToString(innerObject, childObj, field)) {
                    serialize(childObj, childObj.getClass(), innerObject);
                }
                if (!StringUtility.isNullOrEmpty(innerObject.getValue())) {
                    XmlAttribute xmlAttribute = field.getAnnotation(XmlAttribute.class);
                    if (xmlAttribute != null) {
                        if (!isPrimitive(childObj.getClass())) {
                            throw new SerializationException(StringUtility.format("Could not serialize '%s' type as an attribute.", childObj.getClass()));
                        }
                        String tagName = StringUtility.isNullOrEmpty(xmlAttribute.name()) ? field.getName() : xmlAttribute.name();
                        xmlObject.addAttribute(tagName, innerObject.getValue());
                    } else {
                        String tagName;
                        if (innerObject.getCollectionElement() != null && !StringUtility.isNullOrEmpty(innerObject.getCollectionElement().name())) {
                            tagName = innerObject.getCollectionElement().name();
                        } else {
                            tagName = getSerializedFieldName(field);
                        }
                        innerObject.setName(tagName);
                        xmlObject.addChild(innerObject);
                    }
                }
            }
        }
    }

    /**
     * Validates the presence of the XmlElement annotation over given type.
     * @param objType object type to check
     * @throws SerializationException if given type was not decorated with XmlElement annotation
     */
    private void validateXmlElementAnnotation(Class<?> objType) throws SerializationException {
        if (reflection.getAnnotation(objType, XmlElement.class) == null) {
            throw new SerializationException(StringUtility.format("XmlElement annotation over the '%s' type is missing.", objType));
        }
    }

    /**
     * Gets a serialized field name using XmlElement annotation. It the annotation does not exist, the simple field name
     * is used
     * @param field field to resolve
     * @return a serialized field
     */
    private static String getSerializedFieldName(Field field) {
        XmlElement xmlElemAnnotation = field.getAnnotation(XmlElement.class);
        if (xmlElemAnnotation != null && !StringUtility.isNullOrEmpty(xmlElemAnnotation.name())) {
            return xmlElemAnnotation.name();
        }
        return field.getName();
    }

    /**
     * Tries to convert xml element value using converter defined in XmlAttribute or XmlElement annotation.
     * @param innerObject xml object containing current node
     * @param childObj    deserialized child object which might be converted
     * @param field       field with either XmlElement or XmlAttribute annotation
     * @return true if conversion occurred, false otherwise
     * @throws SerializationException when object and converter type mismatch.
     */
    private boolean tryConvertToString(XmlObject innerObject, Object childObj, Field field) throws SerializationException {
        IValueConverter[] converters = fetchConverters(field);
        if (converters != null && converters.length > 0) {
            IValueConverter primaryConverter = converters[0];
            validateConverter(primaryConverter, childObj.getClass());
            try {
                String value = primaryConverter.convertTo(childObj);
                for (int i = 1; i < converters.length; i++) {
                    value = converters[i].convertTo(value);
                }

                innerObject.setValue(value);
            } catch (ConversionException e) {
                throw new SerializationException("Unable to serialize a child using a converter.", e);
            }

            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if converter and child object types match.
     * @param converter        converter to check
     * @param childObjectClass child object class to check
     * @throws SerializationException if there is a type mismatch between converter and child object
     */
    private void validateConverter(IValueConverter converter, Class<?> childObjectClass) throws SerializationException {
        if (converter.getValueType() != null && !childObjectClass.equals(converter.getValueType())) {
            raiseException("XmlSerializer | validateConverter", "Cannot convert value of type '%s' using converter for '%s'.", childObjectClass,
                    converter.getValueType());
        }
    }

    /**
     * Tries to instantiate the value converter defined in either XmlAttribute or XmlElement annotation.
     * @param field field to process
     * @return a value converter instance or null if no converter class has been defined.
     */
    private IValueConverter[] fetchConverters(Field field) {
        XmlAttribute xmlAttribute = field.getAnnotation(XmlAttribute.class);
        XmlElement xmlElement = field.getAnnotation(XmlElement.class);
        XmlCollectionElement xmlCollectionElement = field.getAnnotation(XmlCollectionElement.class);
        boolean xmlAttributeConverterExists = xmlAttribute != null && xmlAttribute.converters() != null && xmlAttribute.converters().length > 0;
        boolean xmlElementConverterExists = xmlElement != null && xmlElement.converters() != null && xmlElement.converters().length > 0;
        boolean xmlCollectionElementConverterExists =
                xmlCollectionElement != null && xmlCollectionElement.converters() != null && xmlCollectionElement.converters().length > 0;
        IValueConverter[] converters = null;
        Class<? extends IValueConverter>[] converterClasses = null;
        try {
            if (xmlAttributeConverterExists) {
                converterClasses = xmlAttribute.converters();
            } else if (xmlElementConverterExists) {
                converterClasses = xmlElement.converters();
            } else if (xmlCollectionElementConverterExists) {
                converterClasses = xmlCollectionElement.converters();
            }
            if (converterClasses != null) {
                converters = new IValueConverter[converterClasses.length];
                for (int i = 0; i < converterClasses.length; i++) {
                    converters[i] = reflection.createInstance(converterClasses[i]);
                }
            }
            return converters;
        } catch (ReflectionException ex) {
            logger.error("XmlSerializer | fetchConverter | Could not create instance of a converter", ex);
            return null;
        }
    }

    /**
     * Gets a list of declared fields across the inheritance hierarchy. It filters non-final, non-static fields
     * decorated with XmlElement, XmlAttribute or XmlCollectionElement annotations.
     * @param objType object type to check
     * @return a list of declared fields across the inheritance hierarchy
     */
    private List<Field> getDeclaredFields(Class<?> objType) {
        Field[] fieldArray = reflection.getFields(objType);
        List<Field> finalFields = new ArrayList<>();
        for (Field field : fieldArray) {
            if (isValidForSerialization(field)) {
                finalFields.add(field);
            }
        }
        Class<?> superClass = reflection.getSuperClass(objType);
        if (superClass != null && superClass != Object.class) {
            List<Field> baseTypeFields = getDeclaredFields(superClass);
            finalFields.addAll(baseTypeFields);
        }
        return finalFields;
    }

    /**
     * Checks if a field is non-final, non-static and decorated with XmlElement, XmlAttribute or XmlCollectionElement
     * annotations.
     * @param field field to check
     * @return true if all of the criteria were met, false otherwise.
     */
    private static boolean isValidForSerialization(Field field) {
        boolean hasProperAnnotation = field.getAnnotation(XmlElement.class) != null || field.getAnnotation(XmlCollectionElement.class) != null
                || field.getAnnotation(XmlAttribute.class) != null;
        boolean hasProperModifier = !field.isStatic();
        return hasProperAnnotation && hasProperModifier;
    }

    /**
     * Serializes a collection object.
     * @param obj       object to serialize
     * @param objType   collection type to serialize (based on isCollection method)
     * @param xmlObject a container which the object should be serialized into.
     * @throws SerializationException when a collection object cannot be serialized into XML string
     */
    private void serializeCollection(Object obj, Class<?> objType, XmlObject xmlObject) throws SerializationException {
        logger.debug("XmlSerializer | serializeCollection | objType: %s", objType);

        if (obj == null) {
            return;
        }

        if (objType == ArrayListWithAttributes.class) {
            ArrayListWithAttributes<?> collection = (ArrayListWithAttributes<?>) obj;
            if (!StringUtility.isNullOrEmpty(collection.getSerializationName())) {
                xmlObject.setName(collection.getSerializationName());
            }
            Map<String, String> attributes = collection.getAttributes();
            for (Map.Entry<String, String> stringStringEntry : attributes.entrySet()) {
                xmlObject.addAttribute(stringStringEntry.getKey(), stringStringEntry.getValue());
            }
        }
        List rawObjectList = (List) obj;
        Class<?> itemType = null;
        String tagName = null;
        for (Object item : rawObjectList) {
            if (itemType == null) {
                itemType = item.getClass();
                if (xmlObject.getCollectionElement() != null) {
                    tagName = xmlObject.getCollectionElement().itemName();
                }
                if (StringUtility.isNullOrEmpty(tagName)) {
                    tagName = getSerializedClassName(itemType);
                }
            }
            if (item != null) {
                XmlObject xmlListItem = xmlObject.getOwnerDocument().createElement(tagName, xmlObject, null);
                serialize(item, itemType, xmlListItem);
                xmlObject.addChild(xmlListItem);
            }
        }
    }

    /**
     * Checks if a given object type is a collection type.
     * @param objType object type to check
     * @return true if given type is a collection type, false otherwise
     */
    private boolean isCollection(Class<?> objType) {
        Class<?>[] listTypeArr = { List.class, ArrayListWithAttributes.class, ArrayList.class, LinkedList.class };
        for (Class<?> listType : listTypeArr) {
            if (objType.equals(listType)) {
                return true;
            }
        }
        boolean implementsList = false;
        Class<?>[] interfaceArr;
        try {
            interfaceArr = reflection.getInterfaces(objType);
        } catch (Exception ex) {
            return false;
        }
        for (Class<?> singleInterface : interfaceArr) {
            if (singleInterface == List.class) {
                implementsList = true;
                break;
            }
        }
        return implementsList;
    }

    /**
     * Serializes primitive values.
     * @param obj     object to serialize
     * @param objType primitive type (according to isPrimitive method)
     * @return serialized primitive value.
     */
    private String serializePrimitive(Object obj, Class<?> objType) {
        logger.debug("XmlSerializer | serializePrimitive | objType: %s", objType);

        if (obj != null) {
            if (objType == Date.class) {
                return localization.formatDate((Date) obj, dateFormat);
            }
            return obj.toString();
        }
        return null;
    }

    /**
     * Checks if a given object type is primitive. This method returns true not only for real primitive types but also
     * their wrappers, java.lang.String and java.util.Date classes.
     * @param objType object type to check
     * @return true if a given type is primitive, false otherwise.
     */
    private static boolean isPrimitive(Class<?> objType) {
        return objType.isPrimitive() || objType.isEnum() || objType == Boolean.class || objType == Byte.class || objType == Short.class
                || objType == Integer.class || objType == Long.class || objType == Float.class || objType == Double.class || objType == Character.class
                || objType == String.class || objType == Date.class;
    }

    /**
     * Gets a simple, serialized class name using XmlElement annotation, or class simple name.
     * @param objType type to fetch
     * @return serialized class name
     */
    private String getSerializedClassName(Class<?> objType) {
        XmlElement xmlElemAnnotation = reflection.getAnnotation(objType, XmlElement.class);
        if (xmlElemAnnotation != null && !StringUtility.isNullOrEmpty(xmlElemAnnotation.name())) {
            return xmlElemAnnotation.name();
        }

        return reflection.getSimpleName(objType);
    }

    /**
     * Logs the error and throws the exception given as parameter
     * @param tag           tag for logging purposes
     * @param messageFormat message format to log
     * @param args          message format arguments for StringUtility.format method.
     * @throws SerializationException exception to throw
     */
    private void raiseException(String tag, String messageFormat, Object... args) throws SerializationException {
        String message = StringUtility.format(messageFormat, args);

        logger.error(tag, message);

        throw new SerializationException(message);
    }

    /**
     * Logs the error and throws the exception given as parameter.
     * @param tag            tag for logging purposes
     * @param message        message to log
     * @param innerException inner exception to throw
     * @throws SerializationException exception to throw
     */
    private void raiseException(String tag, String message, Exception innerException) throws SerializationException {
        logger.error(tag, message);

        throw new SerializationException(message, innerException);
    }
}
