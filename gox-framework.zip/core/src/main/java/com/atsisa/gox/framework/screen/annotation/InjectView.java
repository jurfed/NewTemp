package com.atsisa.gox.framework.screen.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.atsisa.gox.framework.screen.Screen;

/**
 * View binding annotation for screens.
 * <p>
 * Fields annotated with {@link InjectView} which belong to classes extending {@link Screen} class will be automatically resolved and injected to the screen
 * objects at runtime, provided that field names and corresponding view identifier matches.
 * </p>
 * Field's name can only be changed if proper id annotation parameter is provided.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface InjectView {

    /**
     * View identifier.
     * @return view identifier
     */
    String id() default "";
}
