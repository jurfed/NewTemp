package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.IMovieCompleteListener;

/**
 * Plays specific movie.
 */
public class PlayMovieAction extends MovieAction {

    /**
     * A boolean value that indicates whether action should wait for finish listener from movie or not.
     */
    private boolean waitForComplete;

    /**
     * Movie complete listener.
     */
    private IMovieCompleteListener movieCompleteListener;

    /**
     * Creates a new instance of the PlayMovieAction class.
     */
    public PlayMovieAction() {
    }

    /**
     * Creates a new instance of the PlayMovieAction class.
     * @param logger      a logger reference
     * @param eventBus    an eventBus reference
     * @param viewManager a viewManager reference
     */
    public PlayMovieAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus, viewManager);
    }

    @Override
    public Class<? extends PlayMovieActionData> getActionDataType() {
        return PlayMovieActionData.class;
    }

    @Override
    public void reset() {
        clearListener();
        movieCompleteListener = null;
        super.reset();
    }

    @Override
    public void terminate() {
        clearListener();
    }

    /**
     * Clears listener.
     */
    private void clearListener() {
        if (movieCompleteListener != null && movieView != null) {
            movieView.unregisterMovieCompleteListener(movieCompleteListener);
        }
    }

    @Override
    protected void execute() {
        movieView.play();
        if (waitForComplete) {
            movieCompleteListener = new IMovieCompleteListener() {

                @Override
                public void onComplete() {
                    onFinish();
                }
            };
            movieView.registerMovieCompleteListener(movieCompleteListener);
        } else {
            onFinish();
        }
    }

}
