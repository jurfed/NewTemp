package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.event.IEvent;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.view.InteractiveView;

/**
 * Event listener property. Handles events triggered by InteractiveView objects and propagates event data to an event
 * listener which could be injected using set setMethod.
 */
public class EventListenerProperty extends ObservableProperty<IEventListener> implements IEventListener {

    /**
     * Interactive view reference.
     */
    private final InteractiveView view;

    /**
     * Event selector reference.
     */
    private final IEventSelector eventSelector;

    /**
     * Initializes a new instance of the EventListenerProperty view.
     * @param view an InteractiveView object which can trigger input events
     */
    public EventListenerProperty(InteractiveView view) {
        super(IEventListener.class);
        this.view = view;
        this.view.addEventListener(this);
        eventSelector = null;
    }

    /**
     * Initializes a new instance of the EventListenerProperty view.
     * @param view          an InteractiveView object which can trigger input events
     * @param eventSelector optional event selector
     */
    public EventListenerProperty(InteractiveView view, IEventSelector eventSelector) {
        super(IEventListener.class);
        this.view = view;
        this.eventSelector = eventSelector;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onEvent(IEvent event) {
        if (eventSelector != null && !eventSelector.eventMeetsCriteria(event)) {
            return;
        }
        if (get() != null) {
            get().onEvent(event);
        }
    }

    /**
     * Gets the corresponding InteractiveView object reference.
     * @return corresponding InteractiveView object reference
     */
    protected InteractiveView getView() {
        return view;
    }

    @Override
    public boolean set(IEventListener eventListener) {
        if (super.set(eventListener)) {
            if (eventListener == null) {
                view.removeEventListener(this);
            } else {
                view.addEventListener(this);
            }
            return true;
        }
        return false;
    }
}
