package com.atsisa.gox.framework.utility;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.TagConverter;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Point class, used to deserialize and serialize.
 */
@XmlElement
@Reflect_Full
public class Point implements ICloneable<Point>, Comparable<Point>, ITaggable {

    /**
     * The tag used for marking at which point
     * a pen drawing the line should be lowered.
     */
    public static final String POINT_ON_TAG = "on";

    /**
     * The tag used for marking at which point
     * a pen drawing the line should be uplifted.
     */
    public static final String POINT_OFF_TAG = "off";

    /**
     * Taggable.
     */
    private final ITaggable tagContainer;

    /**
     * Value x.
     */
    @XmlAttribute
    private float x;

    /**
     * Value y.
     */
    @XmlAttribute
    private float y;

    /**
     * The tags.
     */
    @XmlAttribute(converters = TagConverter.class)
    private Iterable<String> tags;

    /**
     * Initializes a new instance of the Point class.
     */
    public Point() {
        tagContainer = new TagContainer();
    }

    /**
     * Initializes a new instance of the Point class.
     * @param x - float
     * @param y - float
     */
    public Point(float x, float y) {
        this.x = x;
        this.y = y;
        tagContainer = new TagContainer();
    }

    /**
     * Gets value x.
     * @return float
     */
    public float getX() {
        return x;
    }

    /**
     * Sets value x.
     * @param x - float
     */
    public void setX(float x) {
        this.x = x;
    }

    /**
     * Gets value y.
     * @return float
     */
    public float getY() {
        return y;
    }

    /**
     * Sets value y.
     * @param y - float
     */
    public void setY(float y) {
        this.y = y;
    }

    /**
     * Creates and returns new clone point object.
     * @return Point
     */
    @Override
    public Point clone() {
        return new Point(x, y);
    }

    @Override
    public int compareTo(Point point) {
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Point) {
            Point otherPoint = (Point) obj;
            return x == otherPoint.x && y == otherPoint.y;
        }

        return false;
    }

    @Override
    public int hashCode() {
        int result = x != +0.0f ? Float.floatToIntBits(x) : 0;
        result = 31 * result + (y != +0.0f ? Float.floatToIntBits(y) : 0);
        return result;
    }

    @Override
    public void setTags(Iterable<String> classNames) {
        tagContainer.setTags(classNames);
    }

    @Override
    public Iterable<String> getTags() {
        return tagContainer.getTags();
    }

    @Override
    public boolean hasTag(String className) {
        return tagContainer.hasTag(className);
    }

    @Override
    public boolean hasTags() {
        return tagContainer.hasTags();
    }

    @Override
    public boolean addTag(String className) {
        return tagContainer.addTag(className);
    }

    @Override
    public boolean removeTag(String className) {
        return tagContainer.removeTag(className);
    }
}
