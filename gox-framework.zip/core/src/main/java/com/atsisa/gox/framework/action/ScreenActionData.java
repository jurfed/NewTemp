package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.Reflectable;

/**
 * Provides data determining which screen to show and how.
 */
@XmlElement
@Reflectable
public class ScreenActionData extends ActionData {

    /**
     * Screen id.
     */
    @XmlAttribute
    private String screenId;

    /**
     * Gets the screen identifier.
     * @return String the screen identifier
     */
    public String getScreenId() {
        return screenId;
    }

    /**
     * Sets the screen identifier.
     * @param screenId the screen identifier
     */
    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }
}
