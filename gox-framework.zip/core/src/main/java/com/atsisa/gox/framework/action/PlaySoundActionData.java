package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data about playing sound.
 */
@XmlElement
@Reflect_Full
public class PlaySoundActionData extends ActionData {

    /**
     * Id fo the sound.
     */
    @XmlAttribute
    private String soundId;

    /**
     * Determines whether sound should be looped.
     */
    @XmlAttribute
    private Boolean loop;

    /**
     * Volume of the sound.
     */
    @XmlAttribute
    private Float volume;

    /**
     * Determines whether action should be finished about playing sound.
     */
    @XmlAttribute
    private Boolean blocking;

    /**
     * Gets sound id.
     * @return sound id
     */
    public String getSoundId() {
        return soundId;
    }

    /**
     * Sets sound id.
     * @param soundId id of the sound
     */
    public void setSoundId(String soundId) {
        this.soundId = soundId;
    }

    /**
     * Gets looping value.
     * @return true if sound should be looped
     */
    public Boolean isLooping() {
        return loop;
    }

    /**
     * Sets looping.
     * @param loop looping value
     */
    public void setLoop(Boolean loop) {
        this.loop = loop;
    }

    /**
     * Gets volume of the sound.
     * @return volume of the sound
     */
    public Float getVolume() {
        return volume;
    }

    /**
     * Sets volume of the sound.
     * @param volume volume of the sound
     */
    public void setVolume(Float volume) {
        this.volume = volume;
    }

    /**
     * Determines whether action should be finished about playing sound.
     * @return true if action should be finished after playing sound
     */
    public Boolean isBlocking() {
        return blocking;
    }

    /**
     * Determines whether action should be finished about playing sound.
     * @param blocking true if action should be finished after playing sound
     */
    public void setBlocking(Boolean blocking) {
        this.blocking = blocking;
    }
}
