package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.IRectangleShapeLayer;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.RectangleShapeView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Rectangle shape view rendering.
 */
public class RectangleShapeViewRenderer extends AbstractShapeRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Initializes a new instance of the RectangleShapeViewRenderer class using custom rendering.
     * @param renderer rendering reference
     */
    public RectangleShapeViewRenderer(IRenderer renderer) {
        super(renderer);
        lv = new LocalVariables();
    }

    /**
     * Gets rectangle shape view class type.
     * @return RectangleShapeView.class
     */
    @Override
    public Class<?> getType() {
        return RectangleShapeView.class;
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = changes;
        lv.layer = (IRectangleShapeLayer) getViewLayer(view);
        if (viewType == ViewType.RECTANGLE_SHAPE_VIEW) {
            lv.mask = RectangleShapeView.ViewPropertyName.FILL_COLOR | RectangleShapeView.ViewPropertyName.FRAME_COLOR
                    | RectangleShapeView.ViewPropertyName.FILL_COLOR_ALPHA | RectangleShapeView.ViewPropertyName.FRAME_COLOR_ALPHA
                    | RectangleShapeView.ViewPropertyName.FRAME_THICKNESS | RectangleShapeView.ViewPropertyName.ROUND_RADIUS;
            if (BitUtility.isSet(lv.leftChanges, lv.mask)) {
                updateShape((RectangleShapeView) view, lv.layer);
                lv.leftChanges = BitUtility.unset(lv.leftChanges, lv.mask);
            }
        } else {
            if (viewType == ViewType.VIEW) {
                if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.WIDTH)) {
                    updateShape((RectangleShapeView) view, lv.layer);
                    lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.WIDTH);
                }
                if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.HEIGHT)) {
                    updateShape((RectangleShapeView) view, lv.layer);
                    lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.HEIGHT);
                }
            }
            lv.leftChanges = super.render(view, viewType, lv.leftChanges);
        }

        return lv.leftChanges;
    }

    /**
     * Updates rectangle shape.
     * @param view  - RectangleShapeView
     * @param layer - ImageLayer
     */
    private void updateShape(final RectangleShapeView view, final IRectangleShapeLayer layer) {
        lv.width = view.getWidth();
        lv.height = view.getHeight();
        lv.frameSize = view.getFrameThickness();

        layer.clear();

        if (lv.width + lv.frameSize <= 0 || lv.height + lv.frameSize <= 0) {
            return;
        }

        layer.lineStyle(lv.frameSize, view.getFrameColor(), view.getFrameColorAlpha());
        lv.fillColor = view.getFillColor();
        lv.roundRadius = view.getRoundRadius();

        if (lv.frameSize > 0) {
            layer.lineStyle(lv.frameSize, view.getFrameColor(), view.getFrameColorAlpha());
        }
        if (lv.fillColor != -1) {
            layer.beginFill(lv.fillColor, view.getFillColorAlpha());
        }

        if (lv.roundRadius == 0) {
            layer.drawRect(0, 0, lv.width, lv.height);
        } else {
            layer.drawRoundedRect(0, 0, lv.width, lv.height, lv.roundRadius);
        }
    }

    /**
     * Creates and returns a new shape layer.
     * @param view - View
     * @return IShapeLayer
     */
    @Override
    @SuppressWarnings("unchecked")
    protected IRectangleShapeLayer createLayer(View view) {
        return getLayerFactory().createRectangleShapeLayer();
    }

    /**
     * Holder for instances of local variables used in the {@link RectangleShapeViewRenderer} render method.
     */
    private class LocalVariables {

        private IRectangleShapeLayer layer;

        private int mask;

        private float width;

        private float height;

        private int frameSize;

        private int fillColor;

        private int roundRadius;

        private int leftChanges;
    }
}
