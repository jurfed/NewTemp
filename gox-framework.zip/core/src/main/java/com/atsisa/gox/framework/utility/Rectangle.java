package com.atsisa.gox.framework.utility;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Rectangle class, used to deserialize and serialize.
 */
@XmlElement
@Reflect_Full
public class Rectangle implements Comparable<Rectangle>, ICloneable<Rectangle> {

    /**
     * Value x.
     */
    @XmlAttribute
    private float x;

    /**
     * Value y.
     */
    @XmlAttribute
    private float y;

    /**
     * Value width.
     */
    @XmlAttribute
    private float width;

    /**
     * Value height.
     */
    @XmlAttribute
    private float height;

    /**
     * Initializes a new instance of the Rectangle class.
     */
    public Rectangle() {
    }

    /**
     * Initializes a new instance of the Point class.
     * @param x      - float
     * @param y      - float
     * @param width  - float
     * @param height - float
     */
    public Rectangle(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /**
     * Sets all rectagle source rectangle bounds.
     * @param x      source rectangle x
     * @param y      source rectangle y
     * @param width  source rectangle width
     * @param height source rectangle height
     * @return current instance of {@link Rectangle}
     */
    public Rectangle set(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        return this;
    }

    /**
     * Sets all rectagle bounds from source rectangle.
     * @param rectangle source rectangle
     * @return current instance of {@link Rectangle}
     */
    public Rectangle set(Rectangle rectangle) {
        this.x = rectangle.x;
        this.y = rectangle.y;
        this.width = rectangle.width;
        this.height = rectangle.height;
        return this;
    }

    /**
     * Gets width value.
     * @return float
     */
    public float getWidth() {
        return width;
    }

    /**
     * Sets width value.
     * @param width - float
     */
    public void setWidth(float width) {
        this.width = width;
    }

    /**
     * Gets height value.
     * @return float
     */
    public float getHeight() {
        return height;
    }

    /**
     * Sets height value.
     * @param height - float
     */
    public void setHeight(float height) {
        this.height = height;
    }

    /**
     * Gets value x.
     * @return float
     */
    public float getX() {
        return x;
    }

    /**
     * Sets value x.
     * @param x - float
     */
    public void setX(float x) {
        this.x = x;
    }

    /**
     * Gets value y.
     * @return float
     */
    public float getY() {
        return y;
    }

    /**
     * Sets value y.
     * @param y - float
     */
    public void setY(float y) {
        this.y = y;
    }

    /**
     * Creates and returns new clone rectangle object.
     * @return Rectangle
     */
    @Override
    public Rectangle clone() {
        return new Rectangle(x, y, width, height);
    }

    @Override
    public String toString() {
        return StringUtility.format("Rectangle (x: %s, y: %s, width: %s, height: %s)", x, y, width, height);
    }

    /**
     * Gets the points of this rectangle.
     * @return The points of this rectangle.
     */
    public List<Point> getPoints() {
        List<Point> points = new ArrayList<>(4);
        points.add(new Point(x, y));
        points.add(new Point(x, y + height));
        points.add(new Point(x + width, y + height));
        points.add(new Point(x + width, y));
        return points;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Rectangle) {
            Rectangle otherRectangle = (Rectangle) obj;
            return x == otherRectangle.x && y == otherRectangle.y && width == otherRectangle.width && height == otherRectangle.height;
        }

        return false;
    }

    @Override
    public int hashCode() {
        int result = x != +0.0f ? Float.floatToIntBits(x) : 0;
        result = 31 * result + (y != +0.0f ? Float.floatToIntBits(y) : 0);
        result = 31 * result + (width != +0.0f ? Float.floatToIntBits(width) : 0);
        result = 31 * result + (height != +0.0f ? Float.floatToIntBits(height) : 0);
        return result;
    }

    @Override
    public int compareTo(Rectangle rectangle) {
        return 0;
    }
}
