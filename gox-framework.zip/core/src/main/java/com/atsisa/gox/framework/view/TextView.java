package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.rendering.ITextRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.atsisa.gox.framework.utility.ICaption;
import com.atsisa.gox.framework.utility.ICloneable;
import com.atsisa.gox.framework.utility.StringUtility;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Text view class.
 * Represents all kinds of texts displayed on screen.
 */
@Reflect_Full
@XmlElement
public class TextView extends InteractiveView implements ICaption, ICloneable<TextView> {

    /**
     * Text attribute.
     */
    @XmlAttribute(type = String.class)
    private final ViewProperty<String> text = new ViewProperty<>(String.class, this, ViewType.TEXT_VIEW, ViewPropertyName.TEXT);

    /**
     * Font size.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> fontSize = new ViewProperty<>(Integer.class, this, ViewType.TEXT_VIEW, ViewPropertyName.FONT_SIZE,
            TextFormat.DEFAULT_FONT_SIZE);

    /**
     * Word wrap.
     */
    @XmlAttribute(type = Boolean.class)
    private final ViewProperty<Boolean> wordWrap = new ViewProperty<>(Boolean.class, this, ViewType.TEXT_VIEW, ViewPropertyName.WORD_WRAP, false);

    /**
     * Auto scale width.
     */
    @XmlAttribute(type = Boolean.class)
    private final ViewProperty<Boolean> scaleAutoWidth = new ViewProperty<>(Boolean.class, this, ViewType.TEXT_VIEW, ViewPropertyName.SCALE_AUTO_WIDTH, false);

    /**
     * Vertical alignment.
     */
    @XmlAttribute(type = VerticalAlign.class)
    private final ViewProperty<VerticalAlign> valign = new ViewProperty<>(VerticalAlign.class, this, ViewType.TEXT_VIEW, ViewPropertyName.VALIGN,
            VerticalAlign.TOP);

    /**
     * Horizontal alignment.
     */
    @XmlAttribute(type = HorizontalAlign.class)
    private final ViewProperty<HorizontalAlign> halign = new ViewProperty<>(HorizontalAlign.class, this, ViewType.TEXT_VIEW, ViewPropertyName.HALIGN,
            HorizontalAlign.LEFT);

    /**
     * Font name.
     */
    @XmlAttribute(type = String.class)
    private final ViewProperty<String> fontName = new ViewProperty<>(String.class, this, ViewType.TEXT_VIEW, ViewPropertyName.FONT_NAME,
            TextFormat.DEFAULT_FONT_NAME);

    /**
     * Text color.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> color = new ViewProperty<>(Integer.class, this, ViewType.TEXT_VIEW, ViewPropertyName.COLOR, TextFormat.DEFAULT_COLOR);

    /**
     * Initializes a new instance of the TextView class.
     */
    public TextView() {
        super();
    }

    /**
     * Initializes a new instance of the TextView class.
     * @param renderer {@link IRenderer}
     */
    public TextView(IRenderer renderer) {
        super(renderer);
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.TEXT_VIEW,
                ViewPropertyName.COLOR | ViewPropertyName.FONT_NAME | ViewPropertyName.FONT_SIZE | ViewPropertyName.HALIGN | ViewPropertyName.TEXT
                        | ViewPropertyName.VALIGN | ViewPropertyName.WORD_WRAP | ViewPropertyName.SCALE_AUTO_WIDTH);
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (skin.getView() instanceof TextView) {
            TextView skinItemView = (TextView) skin.getView();
            if (fontSize.hasDefaultValue()) {
                fontSize.set(skinItemView.getFontSize());
            }
            if (text.hasDefaultValue()) {
                text.set(skinItemView.getText());
            }
            if (valign.hasDefaultValue()) {
                valign.set(skinItemView.getValign());
            }
            if (halign.hasDefaultValue()) {
                halign.set(skinItemView.getHalign());
            }
            if (scaleAutoWidth.hasDefaultValue()) {
                scaleAutoWidth.set(skinItemView.getScaleAutoWidth());
            }
            if (wordWrap.hasDefaultValue()) {
                wordWrap.set(skinItemView.getWordWrap());
            }
            if (fontName.hasDefaultValue()) {
                fontName.set(skinItemView.getFontName());
            }
            if (color.hasDefaultValue()) {
                color.set(skinItemView.getColor());
            }
        }
    }

    /**
     * Gets the font name.
     * @return the font name.
     */
    public String getFontName() {
        return fontName.get();
    }

    /**
     * Sets the font name.
     * @param value the font name
     */
    public void setFontName(String value) {
        if (value == null) {
            throw new IllegalArgumentException("The fontName cannot be null.");
        }
        if (fontName.set(value)) {
            propertyChanged(ViewType.TEXT_VIEW, ViewPropertyName.FONT_NAME);
        }
    }

    /**
     * Gets the font name property.
     * @return the font name property
     */
    public IObservableProperty<String> fontName() {
        return fontName;
    }

    /**
     * Gets the color of the text. Default color is white (0xffffff).
     * @return the color of the text
     */
    public int getColor() {
        return color.get();
    }

    /**
     * Sets the color of the text.
     * Color must be in hex format (for example 0xffffff for white, which is the default color).
     * Alpha channel will not be distinguished.
     * @param color the color of the text.
     */
    public void setColor(int color) {
        if (color < 0) {
            throw new IllegalArgumentException("The color must be a non-negative integer.");
        }
        this.color.set(color);
    }

    /**
     * Gets the color property.
     * @return The color property.
     */
    public IObservableProperty<Integer> color() {
        return color;
    }

    /**
     * Gets the text field value.
     * @return the text field value
     */
    @Override
    public String getText() {
        return text.get();
    }

    /**
     * Sets the text field value.
     * @param value text field value
     */
    @Override
    public void setText(String value) {
        text.set(value);
    }

    /**
     * Gets the text property.
     * @return the text property
     */
    public IObservableProperty<String> text() {
        return text;
    }

    /**
     * Gets the font size. Default font size is 14.
     * @return the font size
     */
    public int getFontSize() {
        return fontSize.get();
    }

    /**
     * Sets the font size. Default font size is 0.
     * @param fontSize the font size
     */
    public void setFontSize(int fontSize) {
        this.fontSize.set(fontSize);
    }

    /**
     * Gets the font size property.
     * @return the font size property
     */
    public IObservableProperty<Integer> fontSize() {
        return fontSize;
    }

    /**
     * Sets a boolean value that indicates whether text will be automatically word wrap if textWidth is greater than  width.
     * It will be not working if scaleAutoWidth is set to true.
     * @param wordWrap - Boolean
     */
    public void setWordWrap(boolean wordWrap) {
        this.wordWrap.set(wordWrap);
    }

    /**
     * Gets a boolean value that indicates whether text is automatically word wrap if textWidth is greater than  width.
     * @return boolean
     */
    public boolean getWordWrap() {
        return wordWrap.get();
    }

    /**
     * Gets the word wrap property.
     * @return the word wrap property
     */
    public IObservableProperty<Boolean> wordWrap() {
        return wordWrap;
    }

    /**
     * Sets a boolean value that indicates whether text will be automatically scaled down if textWidth is greater than  width.
     * @param scaleAutoWidth - Boolean
     */
    public void setScaleAutoWidth(boolean scaleAutoWidth) {
        this.scaleAutoWidth.set(scaleAutoWidth);
    }

    /**
     * Gets a boolean value that indicates whether text is automatically scaled down if textWidth is greater than width.
     * @return boolean
     */
    public boolean getScaleAutoWidth() {
        return scaleAutoWidth.get();
    }

    /**
     * Gets the scale auto width property.
     * @return the scale auto width property
     */
    public IObservableProperty<Boolean> scaleAutoWidth() {
        return scaleAutoWidth;
    }

    /**
     * Gets the vertical alignment of the text.
     * @return the vertical alignment
     */
    public VerticalAlign getValign() {
        return valign.get();
    }

    /**
     * Sets the vertical alignment of the text.
     * @param valign the vertical alignment
     */
    public void setValign(VerticalAlign valign) {
        this.valign.set(valign);
    }

    /**
     * Gets the vertical alignment property.
     * @return the vertical alignment property
     */
    public IObservableProperty<VerticalAlign> valign() {
        return valign;
    }

    /**
     * Gets the horizontal alignment of the text.
     * @return the horizontal alignment of the text
     */
    public HorizontalAlign getHalign() {
        return halign.get();
    }

    /**
     * Sets the horizontal alignment of the text.
     * @param halign the horizontal alignment of the text
     */
    public void setHalign(HorizontalAlign halign) {
        this.halign.set(halign);
    }

    /**
     * Gets the horizontal alignment property.
     * @return the horizontal alignment property
     */
    public IObservableProperty<HorizontalAlign> halign() {
        return halign;
    }

    @Override
    public float getWidth() {
        float width = super.getWidth();
        if (width <= 0 && !StringUtility.isNullOrEmpty(getText())) {
            width = getTextWidth();
        }
        return width;
    }

    @Override
    public float getHeight() {
        float height = super.getHeight();
        if (height <= 0 && !StringUtility.isNullOrEmpty(getText())) {
            height = getTextHeight();
        }
        return height;
    }

    /**
     * Gets text width in pixels.
     * @return float
     */
    public float getTextWidth() {
        ITextRenderer textRenderer = (ITextRenderer) getRenderer().getViewRenderer(getClass());
        return textRenderer.getTextWidth(this);
    }

    /**
     * Gets text height in pixels.
     * @return float
     */
    public float getTextHeight() {
        ITextRenderer textRenderer = (ITextRenderer) getRenderer().getViewRenderer(getClass());
        return textRenderer.getTextHeight(this);
    }

    /**
     * Creates and returns new clone object.
     * @return TextView
     */
    @Override
    public TextView clone() {
        TextView textView = new TextView(getRenderer());
        textView.setFontName(getFontName());
        textView.setFontSize(getFontSize());
        textView.setScaleAutoWidth(getScaleAutoWidth());
        textView.setHalign(getHalign());
        textView.setValign(getValign());
        textView.setFontSize(getFontSize());
        textView.setWordWrap(getWordWrap());
        return textView;
    }

    /**
     * Gets text view text format.
     * @return TextFormat
     */
    public TextFormat getTextFormat() {
        TextFormat textFormat = new TextFormat();
        textFormat.setColor(getColor());
        textFormat.setFontName(getFontName());
        textFormat.setFontSize(getFontSize());
        textFormat.setHalign(getHalign());
        textFormat.setValign(getValign());
        textFormat.setWordWrap(getWordWrap());
        textFormat.setScaleAutoWidth(getScaleAutoWidth());
        return textFormat;
    }

    /**
     * Sets new text format.
     * @param textFormat {@link TextFormat}
     */
    public void setTextFormat(TextFormat textFormat) {
        if (textFormat.getColor() != 0) {
            setColor(textFormat.getColor());
        }
        if (textFormat.getFontName() != null) {
            setFontName(textFormat.getFontName());
        }
        if (textFormat.getFontSize() != 0) {
            setFontSize(textFormat.getFontSize());
        }
        if (textFormat.getHalign() != null) {
            setHalign(textFormat.getHalign());
        }
        if (textFormat.getValign() != null) {
            setValign(textFormat.getValign());
        }
        setWordWrap(textFormat.isWordWrap());
        setScaleAutoWidth(textFormat.isScaleAutoWidth());
    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getFontName setMethod.
         */
        public static final int FONT_NAME = 1;

        /**
         * Represents a view property accessible via getValign setMethod.
         */
        public static final int VALIGN = 1 << 1;

        /**
         * Represents a view property accessible via getHalign setMethod.
         */
        public static final int HALIGN = 1 << 2;

        /**
         * Represents a view property accessible via getWordWrap setMethod.
         */
        public static final int WORD_WRAP = 1 << 3;

        /**
         * Represents a view property accessible via getScaleAutoWidth setMethod.
         */
        public static final int SCALE_AUTO_WIDTH = 1 << 4;

        /**
         * Represents a view property accessible via getFontSize setMethod.
         */
        public static final int FONT_SIZE = 1 << 5;

        /**
         * Represents a view property accessible via getColor setMethod.
         */
        public static final int COLOR = 1 << 6;

        /**
         * Represents a view property accessible via getText setMethod.
         */
        public static final int TEXT = 1 << 7;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }
}
