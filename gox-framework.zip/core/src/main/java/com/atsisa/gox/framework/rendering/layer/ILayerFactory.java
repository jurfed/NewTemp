package com.atsisa.gox.framework.rendering.layer;

/**
 * Layer factory, used for creating new instances of an layers.
 */
public interface ILayerFactory {

    /**
     * Creates and returns layer container.
     * @param <T> extends ILayerContainer
     * @return ILayerContainer
     */
    <T extends ILayerContainer> T createLayerContainer();

    /**
     * Creates and returns new progress bar layer.
     * @param <T> extends IProgressBarLayer
     * @return IProgressBarLayer
     */
    <T extends IProgressBarLayer> T createProgressBarLayer();

    /**
     * Creates and returns new rectangle shape layer.
     * @param <T> extends IRectangleShapeLayer
     * @return IRectangleShapeLayer
     */
    <T extends IRectangleShapeLayer> T createRectangleShapeLayer();

    /**
     * Creates and returns new image layer.
     * @param <T> extends IImageLayer
     * @return IImageLayer
     */
    <T extends IImageLayer> T createImageLayer();

    /**
     * Creates and returns new text layer.
     * @param <T> extends ITextLayer
     * @return ITextLayer
     */
    <T extends ITextLayer> T createTextLayer();

    /**
     * Creates and returns new movie layer.
     * @param <T> extends IMovieLayer
     * @return IMovieLayer
     */
    <T extends IMovieLayer> T createMovieLayer();

    /**
     * Creates and returns new line layer.
     * @param <T> extends ILineShapeLayer
     * @return ILineShapeLayer
     */
    <T extends ILineShapeLayer> T createLineLayer();

    /**
     * Creates and returns new button layer.
     * @param <T> extends IButtonLayer
     * @return IButtonLayer
     */
    <T extends IButtonLayer> T createButtonLayer();
}
