package com.atsisa.gox.framework.model.property.primitive;

import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * A property container interface.
 */
public interface IViewProperty {

    /**
     * Gets the view property name identifier.
     * @return view property name identifier
     */
    int getViewPropertyName();

    /**
     * Gets the corresponding view type.
     * @return ViewType
     */
    ViewType getViewType();

    /**
     * Gets the corresponding view.
     * @return View
     */
    View getView();
}
