package com.atsisa.gox.framework.view;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.resource.AbstractImageResource;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Sprite sheet description.
 */
@Reflect_Full
@XmlElement(name = "TextureAtlas")
public class SpriteSheetDescription {

    /**
     * Sprite sheet image path.
     */
    @XmlAttribute
    private String imagePath;

    /**
     * Sprite sheet width.
     */
    @XmlAttribute
    private float width;

    /**
     * Sprite sheet height.
     */
    @XmlAttribute
    private float height;

    /**
     * List with sprites in sprite sheet.
     */
    @XmlCollectionElement(name = "sprites", itemName = "sprite", itemType = Sprite.class)
    private Map<String, Sprite> sprites = new HashMap<>();

    /**
     * Sprite sheet image resource.
     */
    private AbstractImageResource spriteSheetImageResource;

    /**
     * Gets sprite sheet image resource.
     * @return AbstractImageResource
     */
    public AbstractImageResource getSpriteSheetImageResource() {
        return spriteSheetImageResource;
    }

    /**
     * Sets sprite sheet image resource.
     * @param spriteSheetImageResource - AbstractImageResource
     */
    public void setSpriteSheetImageResource(AbstractImageResource spriteSheetImageResource) {
        this.spriteSheetImageResource = spriteSheetImageResource;
    }

    /**
     * Gets sprite sheet image path.
     * @return String
     */
    public String getImagePath() {
        return imagePath;
    }

    /**
     * Sets sprite sheet image path.
     * @param imagePath - String
     */
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    /**
     * Gets sprite sheet width.
     * @return int
     */
    public float getWidth() {
        return width;
    }

    /**
     * Sets sprite sheet width.
     * @param width - int
     */
    public void setWidth(float width) {
        this.width = width;
    }

    /**
     * Gets sprite sheet height.
     * @return int
     */
    public float getHeight() {
        return height;
    }

    /**
     * Sets sprite sheet height.
     * @param height - int
     */
    public void setHeight(float height) {
        this.height = height;
    }

    /**
     * Gets sprites collection.
     * @return sprites collection
     */
    public Collection<Sprite> getSprites() {
        return sprites.values();
    }

    /**
     * Sets sprite collection and fill underlying HashMap of sprites.
     * @param sprites sprite collection
     */
    public void setSprites(List<Sprite> sprites) {
        this.sprites.clear();
        for (int i = 0; i < sprites.size(); i++) {
            this.sprites.put(sprites.get(i).getName(), sprites.get(i));
        }
    }

    /**
     * Gets specific sprite.
     * @param name - String
     * @return Sprite
     */
    public Sprite getSprite(String name) {
        return sprites.get(name);
    }

    /**
     * Class which is representing description for one single sprite in sprite sheet.
     */
    @Reflect_Full
    @XmlElement(name = "sprite")
    public static class Sprite {

        /**
         * Frame name.
         */
        @XmlAttribute(name = "n")
        private String name;

        /**
         * Position x in sprite sheet.
         */
        @XmlAttribute
        private int x;

        /**
         * Position y in sprite sheet.
         */
        @XmlAttribute
        private int y;

        /**
         * Sprite width in sprite sheet.
         */
        @XmlAttribute(name = "w")
        private int width;

        /**
         * Sprite height in sprite sheet.
         */
        @XmlAttribute(name = "h")
        private int height;

        /**
         * Gets name.
         * @return String
         */
        public String getName() {
            return name;
        }

        /**
         * Sets name.
         * @param name - String
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * Gets frame x position in sprite sheet.
         * @return int
         */
        public int getX() {
            return x;
        }

        /**
         * Sets sprite x position.
         * @param x - int
         */
        public void setX(int x) {
            this.x = x;
        }

        /**
         * Gets frame y position in sprite sheet.
         * @return int
         */
        public int getY() {
            return y;
        }

        /**
         * Sets sprite y position.
         * @param y - int
         */
        public void setY(int y) {
            this.y = y;
        }

        /**
         * Gets sprite width.
         * @return int
         */
        public int getWidth() {
            return width;
        }

        /**
         * Sets sprite width.
         * @param width - int
         */
        public void setWidth(int width) {
            this.width = width;
        }

        /**
         * Gets sprite height.
         * @return int
         */
        public int getHeight() {
            return height;
        }

        /**
         * Sets sprite height.
         * @param height - int
         */
        public void setHeight(int height) {
            this.height = height;
        }
    }

}
