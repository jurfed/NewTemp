package com.atsisa.gox.framework.model;

import com.atsisa.gox.framework.model.property.IObservableProperty;

/**
 * Exposes methods for notifying that some object's property will be changed.
 * @param <T> type of the observable property
 */
public interface IPropertyChangingListener<T> {

    /**
     * Called when some object's property will be changed.
     * @param source       property container which contains the property
     * @param currentValue property's current value
     * @param newValue     property's new value
     */
    void propertyChanging(IObservableProperty<T> source, T currentValue, T newValue);

}
