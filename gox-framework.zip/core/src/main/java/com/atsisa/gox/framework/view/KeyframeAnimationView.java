package com.atsisa.gox.framework.view;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IKeyframeAnimation;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableListProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IGameLoopListener;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.KeyframeAnimationFrameConverter;
import com.atsisa.gox.framework.utility.ICloneable;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

import rx.Observable;
import rx.subjects.PublishSubject;

/**
 * Represents a keyframe animation.
 */
@XmlElement
@Reflectable(fields = false)
public class KeyframeAnimationView extends InteractiveView implements IKeyframeAnimation, IGameLoopListener, ICloneable<KeyframeAnimationView> {

    /**
     * Contains all the frames used in animation.
     */
    @XmlElement(name = "frames", type = List.class, converters = KeyframeAnimationFrameConverter.class)
    @HasReflect
    private final ObservableListProperty<KeyframeAnimationFrame> frames = new ObservableListProperty<>();

    /**
     * ILogger reference.
     */
    private final ILogger logger;

    /**
     * The key frame animation state subject.
     */
    private final PublishSubject stateSubject;

    /**
     * Key frame animation name.
     */
    @XmlAttribute(type = String.class)
    @HasReflect
    private final ObservableProperty<String> name = new ObservableProperty<>(String.class);

    /**
     * Frame number, from which animation will start after complete and loop need to be set to true.
     */
    @XmlAttribute(type = Integer.class)
    @HasReflect
    private final ObservableProperty<Integer> beginLoopFrameNumber = new ObservableProperty<>(Integer.class, 0);

    /**
     * Frame number, to which animation will finished and loop need to be set to true.
     */
    @XmlAttribute(type = Integer.class)
    @HasReflect
    private final ObservableProperty<Integer> endLoopFrameNumber = new ObservableProperty<>(Integer.class, 0);

    /**
     * Boolean value that indicates whether this animation will loop or not.
     */
    @XmlAttribute(type = Boolean.class)
    @HasReflect
    private final ObservableProperty<Boolean> loop = new ObservableProperty<>(Boolean.class, true);

    /**
     * A value that indicates whether this animation should start immediately after added to the stage.
     */
    @XmlAttribute(type = Boolean.class)
    @HasReflect
    private final ObservableProperty<Boolean> autoPlay = new ObservableProperty<>(Boolean.class, false);

    /**
     * Frame rate divider value.
     */
    @XmlAttribute(type = Integer.class)
    @HasReflect
    private final ObservableProperty<Integer> frameRateDivider = new ObservableProperty<>(Integer.class, 1);

    /**
     * Boolean value that indicates whether image frames should be smoothed or not.
     */
    @XmlAttribute(type = Boolean.class)
    @HasReflect
    private final ViewProperty<Boolean> smoothing = new ViewProperty<>(Boolean.class, this, ViewType.KEY_FRAME_ANIMATION,
            KeyframeAnimationView.ViewPropertyName.SMOOTHING, false);

    /**
     * Currently displayed frame.
     */
    private final ViewProperty<KeyframeAnimationFrame> currentFrame = new ViewProperty<>(KeyframeAnimationFrame.class, this, ViewType.KEY_FRAME_ANIMATION,
            KeyframeAnimationView.ViewPropertyName.FRAME);

    /**
     * Current animation frame index.
     */
    private int currentFrameIndex = 0;

    /**
     * Sequential number of updated frame.
     */
    private int sequentialNumberOfUpdatedFrame;

    /**
     * Play to specific frame.
     */
    private int playToFrameIndex = -1;

    /**
     * A boolean value that indicates whether play to frame should be forward or not.
     */
    private boolean backward;

    /**
     * Animation state.
     */
    private AnimationState animationState;

    /**
     * Initializes a new instance of the AbstractKeyframeAnimation class.
     */
    public KeyframeAnimationView() {
        super(GameEngine.current().getRenderer());
        logger = GameEngine.current().getLogger();

        stateSubject = PublishSubject.create();
        animationState = AnimationState.STOPPED;
    }

    /**
     * Initializes a new instance of the AbstractKeyframeAnimation class.
     * @param renderer - IRenderer
     * @param logger   - ILogger
     */
    public KeyframeAnimationView(IRenderer renderer, ILogger logger) {
        super(renderer);
        this.logger = logger;

        stateSubject = PublishSubject.create();
        animationState = AnimationState.STOPPED;
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.KEY_FRAME_ANIMATION, KeyframeAnimationView.ViewPropertyName.FRAME | KeyframeAnimationView.ViewPropertyName.SMOOTHING);
    }

    @Override
    public float getOffsetWidth() {
        float minX = 0;
        float maxX = 0;
        for (KeyframeAnimationFrame frame : getFrames()) {
            float frameStartX = frame.getX();
            if (frameStartX < minX) {
                minX = frameStartX;
            }
            float frameWidth = frame.getWidth();
            if (frameWidth == 0f) {
                frameWidth = frame.getImage().getImageWrapperObject().getWidth();
            }
            float frameEndX = frameStartX + frameWidth;
            if (frameEndX > maxX) {
                maxX = frameEndX;
            }
        }
        return maxX - minX;
    }

    @Override
    public float getOffsetHeight() {
        float minY = 0;
        float maxY = 0;
        for (KeyframeAnimationFrame frame : getFrames()) {
            float frameStartY = frame.getY();
            if (frameStartY < minY) {
                minY = frameStartY;
            }
            float frameHeight = frame.getHeight();
            if (frameHeight == 0f) {
                frameHeight = frame.getImage().getImageWrapperObject().getHeight();
            }
            float frameEndY = frameStartY + frameHeight;
            if (frameEndY > maxY) {
                maxY = frameEndY;
            }
        }
        return maxY - minY;
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (skin.getView() instanceof KeyframeAnimationView) {
            KeyframeAnimationView keyFrameAnimationView = (KeyframeAnimationView) skin.getView();
            if (name.hasDefaultValue()) {
                setName(keyFrameAnimationView.getName());
            }
            if (beginLoopFrameNumber.hasDefaultValue()) {
                setBeginLoopFrameNumber(keyFrameAnimationView.getBeginLoopFrameNumber());
            }
            if (endLoopFrameNumber.hasDefaultValue()) {
                setEndLoopFrameNumber(keyFrameAnimationView.getEndLoopFrameNumber());
            }
            if (loop.hasDefaultValue()) {
                setLoop(keyFrameAnimationView.isLoop());
            }
            if (autoPlay.hasDefaultValue()) {
                setAutoPlay(keyFrameAnimationView.isAutoPlay());
            }
            if (frameRateDivider.hasDefaultValue()) {
                setFrameRateDivider(keyFrameAnimationView.getFrameRateDivider());
            }
            if (smoothing.hasDefaultValue()) {
                setSmoothing(keyFrameAnimationView.isSmoothing());
            }
            if (frames.hasDefaultValue()) {
                setFrames(keyFrameAnimationView.getFrames());
            }
        }
    }

    @Override
    public void clear() {
        removeGameLoopListenerAndSetStoppedState(true);
        super.clear();
    }

    @Override
    public void dispose() {
        clear();
        super.dispose();
    }

    /**
     * Removes game loop listener from game loop and set state to stopped.
     * @param resetFramesIndex a boolean value that indicates whether current frame index should be reset to the first frame
     */
    private void removeGameLoopListenerAndSetStoppedState(boolean resetFramesIndex) {
        if (isPlaying()) {
            getRenderer().removeGameLoopListener(this);
        }

        sequentialNumberOfUpdatedFrame = 0;
        if (resetFramesIndex) {
            displayFrame(getFrames().get(0));
            currentFrameIndex = 0;
        }
        setAnimationState(AnimationState.STOPPED);
    }

    @Override
    public boolean isPlaying() {
        return animationState == AnimationState.PLAYING;
    }

    @Override
    public boolean isPaused() {
        return animationState == AnimationState.PAUSED;
    }

    @Override
    public boolean isStopped() {
        return animationState == AnimationState.STOPPED;
    }

    @Override
    public void play() {
        if (isPlaying()) {
            return;
        }

        playToFrameIndex = -1;
        if (currentFrameIndex == getTotalFrameCount() - 1) {
            currentFrameIndex = 0;
        }

        addGameLoopListenerAndSetPlayingState();
    }

    @Override
    public void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        removeGameLoopListenerAndSetPausedStateOnCurrentFrame();
    }

    /**
     * Remove game loop listener and set paused state.
     */
    private void removeGameLoopListenerAndSetPausedStateOnCurrentFrame() {
        getRenderer().removeGameLoopListener(this);
        displayFrame(getFrames().get(currentFrameIndex));

        setAnimationState(AnimationState.PAUSED);
    }

    @Override
    public void stop() {
        if (isStopped()) {
            return;
        }

        removeGameLoopListenerAndSetStoppedState(true);
    }

    @Override
    public AnimationState getAnimationState() {
        return animationState;
    }

    /**
     * Sets current animation state.
     * @param animationState The new animation state.
     */
    protected void setAnimationState(AnimationState animationState) {
        if (this.animationState == animationState) {
            return;
        }

        this.animationState = animationState;
        stateSubject.onNext(animationState);
    }

    @Override
    public Observable<AnimationState> getAnimationStateObservable() {
        return stateSubject;
    }

    @Override
    protected void init() {
        super.init();

        if (isAutoPlay()) {
            play();
        }
    }

    /**
     * Gets name for this keyframe animation.
     * @return String
     */
    public String getName() {
        return name.get();
    }

    /**
     * Sets name for this key frame animation.
     * @param value - String
     */
    public void setName(String value) {
        name.set(value);
    }

    /**
     * Gets begin loop frame. Which determines from what frame number animation will start after complete, and when loop
     * is set to true.
     * @return int
     */
    public int getBeginLoopFrameNumber() {
        return beginLoopFrameNumber.get();
    }

    @Override
    public void setBeginLoopFrameNumber(int frameNumber) {
        beginLoopFrameNumber.set(frameNumber);
    }

    /**
     * Gets end loop frame. Which determines to what frame number animation will play, and when loop is set to true.
     * @return int
     */
    public int getEndLoopFrameNumber() {
        return endLoopFrameNumber.get();
    }

    @Override
    public void setEndLoopFrameNumber(int frameNumber) {
        endLoopFrameNumber.set(frameNumber);
    }

    @Override
    public void gotoAndPlay(int frameNumber) {
        verifyFrameNumberRange(frameNumber);
        currentFrameIndex = frameNumber - 1;
        playToFrameIndex = -1;

        if (!isPlaying()) {
            addGameLoopListenerAndSetPlayingState();
        }
    }

    /**
     * Adds game lop listener and set playing state.
     */
    private void addGameLoopListenerAndSetPlayingState() {
        getRenderer().addGameLoopListener(this);
        setAnimationState(AnimationState.PLAYING);
    }

    /**
     * Verifies frame number and hold it in animation range.
     * @param frameNumber frame number starting from 1
     */
    private void verifyFrameNumberRange(int frameNumber) {
        if (frameNumber < 1 || frameNumber > getFrames().size()) {
            throw new IllegalArgumentException("Correct frame number expected.");
        }
    }

    @Override
    public void gotoAndPause(int frameNumber) {
        verifyFrameNumberRange(frameNumber);
        currentFrameIndex = frameNumber - 1;
        removeGameLoopListenerAndSetPausedStateOnCurrentFrame();
    }

    @Override
    public void playToAndPause(int frameNumber) {
        verifyFrameNumberRange(frameNumber);
        playToFrameIndex = frameNumber - 1;

        if (!isPlaying()) {
            addGameLoopListenerAndSetPlayingState();
        }
    }

    @Override
    public boolean isLoop() {
        return loop.get();
    }

    @Override
    public void setLoop(boolean loop) {
        this.loop.set(loop);
    }

    @Override
    public boolean isBackward() {
        return backward;
    }

    @Override
    public void setBackward(boolean backward) {
        this.backward = backward;
    }

    /**
     * Gets a value indicating whether the animation should start immediately after added to the stage.
     * @return A value that indicates whether this animation should start immediately after added to the stage.
     */
    public boolean isAutoPlay() {
        return autoPlay.get();
    }

    /**
     * Sets a value indicating whether the animation should start immediately after added to the stage.
     * @param autoPlay A value that indicates whether this animation should start immediately after added to the stage.
     */
    public void setAutoPlay(boolean autoPlay) {
        this.autoPlay.set(autoPlay);
    }

    /**
     * Gets the frame divider value.
     * @return the frame divider value
     */
    public int getFrameRateDivider() {
        return frameRateDivider.get();
    }

    /**
     * Sets the frame rate divider value (default is 1) The original frame rate will be divided by that number For
     * instance for initial frame rate = 60 and frame divider = 2 the animation will be updated only 30fps.
     * @param frameRateDivider the frame rate divider value
     */
    public void setFrameRateDivider(int frameRateDivider) {
        this.frameRateDivider.set(frameRateDivider);
    }

    /**
     * Gets a boolean value that indicates whether frames should be smoothed or not.
     * @return boolean
     */
    public boolean isSmoothing() {
        return smoothing.get();
    }

    /**
     * Sets a value that indicates whether frames should be smoothed or not.
     * @param smoothing - boolean
     */
    public void setSmoothing(boolean smoothing) {
        this.smoothing.set(smoothing);
    }

    /**
     * Gets key frame animation frames.
     * @return key frame animation frames
     */
    @SuppressWarnings("unchecked")
    public List<KeyframeAnimationFrame> getFrames() {
        return frames.get();
    }

    /**
     * Sets frames to the end sequence.
     * @param frames frames to the end sequence
     */
    public void setFrames(List<KeyframeAnimationFrame> frames) {
        if (frames == null) {
            throw new IllegalArgumentException("Frames collection cannot be null.");
        }
        getFrames().clear();
        for (KeyframeAnimationFrame frame : frames) {
            addFrame(frame);
        }
    }

    /**
     * Adds new frame to the end sequence.
     * @param frame - T extends KeyframeAnimationFrame
     */
    public void addFrame(KeyframeAnimationFrame frame) {
        if (frame == null) {
            throw new IllegalArgumentException("Frame cannot be null.");
        }
        getFrames().add(frame);
        if (getFrames().size() == 1) {
            displayFrame(getFrames().get(0));
        }
    }

    /**
     * Displays image for specific frame.
     * @param frame - KeyframeAnimationFrame
     */
    private void displayFrame(KeyframeAnimationFrame frame) {
        currentFrame.set(frame);
    }

    @Override
    public View getTargetView() {
        return this;
    }

    @Override
    public KeyframeAnimationView clone() {
        KeyframeAnimationView clone = new KeyframeAnimationView(getRenderer(), logger);
        populateClone(clone);
        return clone;
    }

    /**
     * Populates clone object.
     * @param cloneView - AbstractKeyframeAnimationView
     */
    private void populateClone(KeyframeAnimationView cloneView) {
        cloneView.init();
        for (KeyframeAnimationFrame frame : getFrames()) {
            cloneView.addFrame(frame.clone());
        }
        cloneView.setBeginLoopFrameNumber(getBeginLoopFrameNumber());
        cloneView.setEndLoopFrameNumber(getEndLoopFrameNumber());
        cloneView.setName(getName());
        cloneView.setFrameRateDivider(getFrameRateDivider());
    }

    @Override
    public void onUpdate(final float interval) {
        if (sequentialNumberOfUpdatedFrame % getFrameRateDivider() == 0) {
            if (playToFrameIndex == -1) {
                updateCurrentFrameIndex();
            } else {
                updateCurrentFrameIndexDependingPlayToFrameIndex();
            }
            displayFrame(getFrames().get(currentFrameIndex));
            sequentialNumberOfUpdatedFrame = 0;
        }
        sequentialNumberOfUpdatedFrame++;
    }

    /**
     * Update current frame index.
     */
    private void updateCurrentFrameIndex() {
        int endFrameIndex = getEndLoopFrameNumber() > 0 ? getEndLoopFrameNumber() - 1 : getFrames().size() - 1;
        if (isLoop()) {
            int beginFrameIndex = getBeginLoopFrameNumber() > 0 ? getBeginLoopFrameNumber() - 1 : 0;
            if (backward) {
                if (currentFrameIndex == beginFrameIndex) {
                    currentFrameIndex = endFrameIndex;
                } else {
                    decreaseCurrentFrameIndex();
                }
            } else {
                if (currentFrameIndex == endFrameIndex) {
                    currentFrameIndex = beginFrameIndex;
                } else {
                    increaseCurrentFrameIndex();
                }
            }
        } else {
            if (backward) {
                decreaseCurrentFrameIndex();
            } else {
                increaseCurrentFrameIndex();
            }
            if (currentFrameIndex == 0 || currentFrameIndex == endFrameIndex) {
                removeGameLoopListenerAndSetStoppedState(false);
            }
        }
    }

    /**
     * Increase current frame index.
     */
    private void increaseCurrentFrameIndex() {
        if (currentFrameIndex == getTotalFrameCount() - 1) {
            currentFrameIndex = 0;
        } else {
            currentFrameIndex++;
        }
    }

    /**
     * Decrease current frame index.
     */
    private void decreaseCurrentFrameIndex() {
        if (currentFrameIndex == 0) {
            currentFrameIndex = getTotalFrameCount() - 1;
        } else {
            currentFrameIndex--;
        }
    }

    /**
     * Update current frame index depending play to frame index.
     */
    private void updateCurrentFrameIndexDependingPlayToFrameIndex() {
        if (currentFrameIndex != playToFrameIndex) {
            if (backward) {
                decreaseCurrentFrameIndex();
            } else {
                increaseCurrentFrameIndex();
            }
        }

        if (currentFrameIndex == playToFrameIndex) {
            removeGameLoopListenerAndSetPausedStateOnCurrentFrame();
        }
    }

    /**
     * Adds new frame to the specific position in sequence.
     * @param frameNumber - int
     * @param frame       - T extends KeyframeAnimationFrame
     */
    public void addFrame(int frameNumber, KeyframeAnimationFrame frame) {
        verifyFrameNumberRange(frameNumber);

        if (frame == null) {
            throw new IllegalArgumentException("Frame cannot be null.");
        }
        int newFrameNumber = frameNumber - 1;
        if (newFrameNumber > getFrames().size()) {
            addFrame(frame);
        } else {
            getFrames().add(newFrameNumber, frame);
        }
    }

    /**
     * Gets frame position x.
     * @return float
     */
    public float getFrameX() {
        if (getCurrentFrame() != null) {
            return getCurrentFrame().getX();
        }

        return 0;
    }

    /**
     * Gets current displayed frame.
     * @return T extends KeyframeAnimationFrame
     */
    public KeyframeAnimationFrame getCurrentFrame() {
        return currentFrame.get();
    }

    /**
     * Gets frame position y.
     * @return float
     */
    public float getFrameY() {
        if (getCurrentFrame() != null) {
            return getCurrentFrame().getY();
        }

        return 0;
    }

    /**
     * Gets current frame index (starting from 0).
     * @return int
     */
    public int getCurrentFrameIndex() {
        return currentFrameIndex;
    }

    /**
     * Gets current frame number. (starting from 1).
     * @return int
     */
    public int getCurrentFrameNumber() {
        return currentFrameIndex + 1;
    }

    /**
     * Gets total frame count.
     * @return int
     */
    public int getTotalFrameCount() {
        return getFrames().size();
    }

    /**
     * Gets logger reference.
     * @return ILogger
     */
    protected ILogger getLogger() {
        return logger;
    }

    /**
     * Gets the name property.
     * @return the name property
     */
    public IObservableProperty<String> name() {
        return name;
    }

    /**
     * Gets the begin loop frame number property.
     * @return the begin loop frame number property
     */
    public IObservableProperty<Integer> beginLoopFrameNumber() {
        return beginLoopFrameNumber;
    }

    /**
     * Gets the end loop frame number property.
     * @return the end loop frame number property
     */
    public IObservableProperty<Integer> endLoopFrameNumber() {
        return endLoopFrameNumber;
    }

    /**
     * Gets the loop property.
     * @return the loop property
     */
    public IObservableProperty<Boolean> loop() {
        return loop;
    }

    /**
     * Gets the autoPlay property.
     * @return the autoPlay property
     */
    public IObservableProperty<Boolean> autoPlay() {
        return autoPlay;
    }

    /**
     * Gets the frame rate divider property.
     * @return the frame rate divider property
     */
    public IObservableProperty<Integer> frameRateDivider() {
        return frameRateDivider;
    }

    /**
     * Gets smoothing observable view property.
     * @return smoothing observable view property
     */
    public ViewProperty<Boolean> smoothing() {
        return smoothing;
    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getCurrentFrame setMethod.
         */
        public static final int FRAME = 1;

        /**
         * Represents a view property accessible via getSmoothing setMethod.
         */
        public static final int SMOOTHING = 1 << 1;

    }
}
