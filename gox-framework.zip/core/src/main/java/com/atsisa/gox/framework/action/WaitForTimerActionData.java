package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Action data for {@link WaitForTimerAction}.
 */
@XmlElement
public class WaitForTimerActionData extends TimerActionData {

    /**
     * Cancel on terminate.
     */
    @XmlAttribute
    private boolean cancelOnTerminate = true;

    /**
     * Gets a value indicating whether the timer cancellation should be performed once the {@link WaitForTimerAction} is being terminated.
     * @return The cancel on terminate flag.
     */
    public boolean isCancelOnTerminate() {
        return cancelOnTerminate;
    }

    /**
     * Sets a value indicating whether the timer cancellation should be performed once the {@link WaitForTimerAction} is being terminated.
     * @param cancelOnTerminate The cancel on terminate flag.
     */
    public void setCancelOnTerminate(boolean cancelOnTerminate) {
        this.cancelOnTerminate = cancelOnTerminate;
    }
}
