package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.Rectangle;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Class describes the rectangle shape.
 */
@XmlElement
@Reflect_Full
public class RectangleShapeView extends AbstractShape implements IBound {

    /**
     * RectangleShapeView property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a rectangle shape view property accessible via getFrameColor setMethod.
         */
        public static final int FRAME_COLOR = 1;

        /**
         * Represents a rectangle shape view property accessible via getFillColor setMethod.
         */
        public static final int FILL_COLOR = 1 << 1;

        /**
         * Represents a rectangle shape view property accessible via getFrameThickness setMethod.
         */
        public static final int FRAME_THICKNESS = 1 << 2;

        /**
         * Represents a rectangle shape view property accessible via getRoundRadius setMethod.
         */
        public static final int ROUND_RADIUS = 1 << 3;

        /**
         * Represents a rectangle shape view property accessible via getFrameColorAlpha setMethod.
         */
        public static final int FRAME_COLOR_ALPHA = 1 << 4;

        /**
         * Represents a rectangle shape view property accessible via getFillColorAlpha setMethod.
         */
        public static final int FILL_COLOR_ALPHA = 1 << 5;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

    /**
     * Rectangle round radius.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> roundRadius = new ViewProperty<>(Integer.class, this, ViewType.RECTANGLE_SHAPE_VIEW, ViewPropertyName.ROUND_RADIUS, 0);

    /**
     * Frame color.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> frameColor = new ViewProperty<>(Integer.class, this, ViewType.RECTANGLE_SHAPE_VIEW, ViewPropertyName.FRAME_COLOR,
            0x000000);

    /**
     * Frame color alpha.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> frameColorAlpha = new ViewProperty<>(Float.class, this, ViewType.RECTANGLE_SHAPE_VIEW, ViewPropertyName.FRAME_COLOR_ALPHA,
            1F);

    /**
     * Fill color.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> fillColor = new ViewProperty<>(Integer.class, this, ViewType.RECTANGLE_SHAPE_VIEW, ViewPropertyName.FILL_COLOR, -1);

    /**
     * Fill color alpha.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> fillColorAlpha = new ViewProperty<>(Float.class, this, ViewType.RECTANGLE_SHAPE_VIEW, ViewPropertyName.FILL_COLOR_ALPHA,
            1F);

    /**
     * Frame thickness.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> frameThickness = new ViewProperty<>(Integer.class, this, ViewType.RECTANGLE_SHAPE_VIEW,
            ViewPropertyName.FRAME_THICKNESS, 0);

    /**
     * Initializes a new instance of the RectangleShape class.
     */
    public RectangleShapeView() {
        super();
    }

    /**
     * Initializes a new instance of the RectangleShapeView class.
     * @param renderer {@link IRenderer}
     */
    public RectangleShapeView(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Gets rectangle round radius.
     * @return int
     */
    public int getRoundRadius() {
        return roundRadius.get();
    }

    /**
     * Sets rectangle round radius.
     * @param roundRadius - int
     */
    public void setRoundRadius(int roundRadius) {
        this.roundRadius.set(roundRadius);
    }

    /**
     * Gets frame color alpha.
     * @return float - value between 0-1
     */
    public float getFrameColorAlpha() {
        return frameColorAlpha.get();
    }

    /**
     * Sets frame color alpha.
     * @param frameColorAlpha - value should be between 0-1
     */
    public void setFrameColorAlpha(float frameColorAlpha) {
        this.frameColorAlpha.set(frameColorAlpha);
    }

    /**
     * Gets fill color alpha.
     * @return float - value between 0-1
     */
    public float getFillColorAlpha() {
        return fillColorAlpha.get();
    }

    /**
     * Sets fill color alpha.
     * @param fillColorAlpha - value should be between 0-1
     */
    public void setFillColorAlpha(float fillColorAlpha) {
        this.fillColorAlpha.set(fillColorAlpha);
    }

    /**
     * Gets frame thickness.
     * @return int
     */
    public int getFrameThickness() {
        return frameThickness.get();
    }

    /**
     * Sets frame thickness.
     * @param frameThickness - int
     */
    public void setFrameThickness(int frameThickness) {
        this.frameThickness.set(frameThickness);
    }

    /**
     * Gets frame color.
     * @return int
     */
    public int getFrameColor() {
        return frameColor.get();
    }

    /**
     * Sets frame color.
     * @param frameColor - int
     */
    public void setFrameColor(int frameColor) {
        this.frameColor.set(frameColor);
    }

    /**
     * Gets fill color.
     * @return int
     */
    public int getFillColor() {
        return fillColor.get();
    }

    /**
     * Sets fill color.
     * @param fillColor - int
     */
    public void setFillColor(int fillColor) {
        this.fillColor.set(fillColor);
    }

    /**
     * Gets the bounds of this rectangle view.
     * @return The bounds of this rectangle view.
     */
    @Override
    public Rectangle getBoundaries() {
        return new Rectangle(getX(), getY(), getWidth(), getHeight());
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (skin != null) {
            RectangleShapeView rectangleShapeView = (RectangleShapeView) skin.getView();
            if (fillColor.hasDefaultValue()) {
                setFillColor(rectangleShapeView.getFillColor());
            }
            if (fillColorAlpha.hasDefaultValue()) {
                setFillColorAlpha(rectangleShapeView.getFillColorAlpha());
            }
            if (frameThickness.hasDefaultValue()) {
                setFrameThickness(rectangleShapeView.getFrameThickness());
            }
            if (frameColor.hasDefaultValue()) {
                setFrameColor(rectangleShapeView.getFrameColor());
            }
            if (frameColorAlpha.hasDefaultValue()) {
                setFrameColorAlpha(rectangleShapeView.getFrameColorAlpha());
            }
            if (roundRadius.hasDefaultValue()) {
                setRoundRadius(rectangleShapeView.getRoundRadius());
            }
        }
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.RECTANGLE_SHAPE_VIEW,
                ViewPropertyName.FRAME_THICKNESS | ViewPropertyName.FILL_COLOR | ViewPropertyName.FILL_COLOR_ALPHA | ViewPropertyName.FRAME_COLOR
                        | ViewPropertyName.FRAME_COLOR_ALPHA | ViewPropertyName.FRAME_THICKNESS | ViewPropertyName.ROUND_RADIUS);
    }

}
