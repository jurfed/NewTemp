package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Action data for {@link ChangeViewVisibilityAction} class.
 */
@XmlElement
@Reflect_Full
public class ChangeViewVisibilityActionData extends ViewActionData {

    /**
     * A boolean value that indicates whether selected view should be visible of not.
     */
    @XmlAttribute
    private Boolean visible;

    /**
     * Returns a boolean value that indicates whether selected view should be visible of not.
     * @return boolean value
     */
    public Boolean isVisible() {
        return visible;
    }

    /**
     * Sets s boolean value that indicates whether selected view should be visible of not.
     * @param visible boolean value
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

}
