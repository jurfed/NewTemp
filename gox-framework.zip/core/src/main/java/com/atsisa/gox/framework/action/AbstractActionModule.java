package com.atsisa.gox.framework.action;

import java.util.HashMap;
import java.util.Map;

/**
 * Describes the actions which can be created declaratively using XML.
 */
public abstract class AbstractActionModule {

    /**
     * A action map, maps action names to their types.
     */
    private Map<String, Class<? extends Action>> actionMap;

    /**
     * Initializes a new instance of the AbstractActionModule class.
     */
    protected AbstractActionModule() {
        actionMap = new HashMap<>();
        register();
    }

    /**
     * Gets the type of the registered action. If there is no Action registered under actionName name, the null will be returned.
     * @param actionName the action name
     * @return the type of the action
     */
    public Class<? extends Action> getActionType(String actionName) {
        if (actionMap.containsKey(actionName)) {
            return actionMap.get(actionName);
        }
        return null;
    }

    /**
     * Gets the XML namespace of the current module.
     * @return the XML namespace
     */
    public abstract String getXmlNamespace();

    /**
     * Registers Action types to the current module. It will be called during module creation.
     * When overridden, it should call registerAction setMethod to register a particular Action types.
     */
    protected abstract void register();

    /**
     * Registers a particular action type. The name of the registered action will be the same as action class name.
     * @param actionType the action type
     */
    protected void registerAction(Class<? extends Action> actionType) {
        String name = actionType.toString();
        name = name.substring(name.lastIndexOf('.') + 1);
        if (actionMap.get(name) == null) {
            actionMap.put(name, actionType);
        }
    }

    /**
     * Registers a particular action type. The name of the registered action is passed as parameter.
     * @param name       the name of the action
     * @param actionType the action type
     */
    protected void registerAction(String name, Class<? extends Action> actionType) {
        actionMap.put(name, actionType);
    }
}
