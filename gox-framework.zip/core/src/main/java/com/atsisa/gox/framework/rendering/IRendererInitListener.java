package com.atsisa.gox.framework.rendering;

/**
 * Listens for asynchronous rendering initialization.
 */
public interface IRendererInitListener {

    /**
     * Invoked after the game loop was started.
     */
    void rendererInitialized();
}
