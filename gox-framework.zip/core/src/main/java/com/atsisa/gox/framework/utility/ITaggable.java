package com.atsisa.gox.framework.utility;

/**
 * Gives abilities to tag objects implementing this interface.
 */
public interface ITaggable {

    /**
     * Sets a collection of tags.
     * @param tags a collection of tags.
     */
    void setTags(Iterable<String> tags);

    /**
     * Gets a collection of tags.
     * @return The collection of tags.
     */
    Iterable<String> getTags();

    /**
     * Gets a value indicating whether given tag is defined.
     * @param tag The tag to check.
     * @return True if this object was tagged with given tag, false otherwise.
     */
    boolean hasTag(String tag);

    /**
     * Get a value indicating whether this objects has any tags defined.
     * @return True if the objects has at least one tag, false otherwise.
     */
    boolean hasTags();

    /**
     * Tags this object with a given tag.
     * @param tag The tag to add.
     * @return True if the tag was added, false if it already exists.
     */
    boolean addTag(String tag);

    /**
     * Removes a given tag from this object.
     * @param tag The tag to remove.
     * @return True if the tag was removed, false if it does not exist.
     */
    boolean removeTag(String tag);
}
