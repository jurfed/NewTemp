package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.event.IEvent;

/**
 * Event selector interface.
 * Objects implementing this interface decide
 * whether or not given event should be propagated
 */
public interface IEventSelector {

    /**
     * Checks if given event meets certain criteria.
     * @param event event to check
     * @return true if the event meets certain criteria, false otherwise
     */
    boolean eventMeetsCriteria(IEvent event);
}
