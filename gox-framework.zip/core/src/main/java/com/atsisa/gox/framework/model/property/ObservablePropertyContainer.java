package com.atsisa.gox.framework.model.property;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.model.IPropertyChangedListener;

/**
 * Observable property container. Exposes methods for registering for property changed events.
 */
@SuppressWarnings("unchecked")
public abstract class ObservablePropertyContainer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * A list of property changed listeners.
     */
    private final List<IPropertyChangedListener> propertyChangedListeners;

    /**
     * Initializes a new instance of the ObservablePropertyContainer.
     */
    public ObservablePropertyContainer() {
        propertyChangedListeners = new ArrayList<>();
        lv = new LocalVariables();
    }

    /**
     * Adds a property changed listener.
     * @param propertyChangedListener a property changed listener
     */
    public void addPropertyChangedListener(IPropertyChangedListener propertyChangedListener) {
        if (!propertyChangedListeners.contains(propertyChangedListener)) {
            propertyChangedListeners.add(propertyChangedListener);
        }
    }

    /**
     * Removes a property changed listener.
     * @param propertyChangedListener a property changed listener
     */
    public void removePropertyChangedListener(IPropertyChangedListener propertyChangedListener) {
        propertyChangedListeners.remove(propertyChangedListener);
    }

    /**
     * Notifies all listeners that a property has changed.
     * @param property observable property
     * @param oldValue old value
     * @param newValue new value
     */
    protected void notifyPropertyChanged(IObservableProperty property, Object oldValue, Object newValue) {
        lv.size = propertyChangedListeners.size();
        for (lv.index = 0; lv.index < lv.size; lv.index++) {
            propertyChangedListeners.get(lv.index).propertyChanged(property, oldValue, newValue);
        }
    }

    /**
     * Holder for instances of local variables used in the {@link ObservablePropertyContainer} render method.
     */
    private class LocalVariables {

        private int size;

        private int index;
    }
}
