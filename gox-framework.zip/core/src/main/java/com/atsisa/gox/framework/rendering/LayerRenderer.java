package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.rendering.layer.ILayerFactory;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;

/**
 * Implements basic layers rendering behaviour.
 */
public abstract class LayerRenderer extends AbstractViewRenderer {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Renderer reference.
     */
    private IRenderer renderer;

    /**
     * Layer factory reference.
     */
    private ILayerFactory layersFactory;

    /**
     * Initializes a new instance of the LayerRenderer class using custom rendering.
     * @param renderer - IRenderer
     */
    public LayerRenderer(IRenderer renderer) {
        this(renderer, renderer.getLayerFactory());
    }

    /**
     * Initializes a new instance of the LayerRenderer class using custom rendering and layer factory.
     * @param renderer     - IRenderer
     * @param layerFactory - ILayerFactory
     */
    public LayerRenderer(IRenderer renderer, ILayerFactory layerFactory) {
        this.renderer = renderer;
        layersFactory = layerFactory;
        lv = new LocalVariables();
    }

    @Override
    public int render(final View view, final ViewType viewType, final int changes) {
        lv.leftChanges = changes;
        if (viewType == ViewType.VIEW && lv.leftChanges != 0) {
            lv.layer = getViewLayer(view);

            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.X)) {
                lv.layer.setX(view.getX());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.X);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.Y)) {
                lv.layer.setY(view.getY());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.Y);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.WIDTH)) {
                lv.layer.setWidth(view.getWidth());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.WIDTH);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.HEIGHT)) {
                lv.layer.setHeight(view.getHeight());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.HEIGHT);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.ALPHA)) {
                lv.layer.setAlpha(view.getAlpha());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.ALPHA);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.SCALE_X)) {
                lv.layer.setScaleX(view.getScaleX());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.SCALE_X);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.SCALE_Y)) {
                lv.layer.setScaleY(view.getScaleY());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.SCALE_Y);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.ORIGIN_X | View.ViewPropertyName.ORIGIN_Y)) {
                lv.layer.setOrigin(view.getOriginX(), view.getOriginY());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.ORIGIN_X | View.ViewPropertyName.ORIGIN_Y);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.ROTATION)) {
                lv.layer.setRotation(view.getRotation());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.ROTATION);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.VISIBLE)) {
                lv.layer.setVisible(view.isVisible());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.VISIBLE);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.PARENT)) {
                /*
                 * if (view.getParent() == null && layers.parent() != null) { //layers.parent().remove(layers); }
                 */
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.PARENT);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.MASK)) {
                lv.layer.setMask(view.getMask());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.MASK);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.DEPTH)) {
                // TO CHECK
                // layers.setDepth(view.getDepth());
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.DEPTH);
            }
            if (BitUtility.isSet(lv.leftChanges, View.ViewPropertyName.BASIC)) {
                lv.leftChanges = BitUtility.unset(lv.leftChanges, View.ViewPropertyName.BASIC);
            }
        }
        return lv.leftChanges;
    }

    /**
     * Clears the width and height.
     * @param changes changes made to the view in binary format
     * @return changes left
     */
    protected int clearWidthAndHeight(final int changes) {
        return BitUtility.unset(changes, View.ViewPropertyName.WIDTH | View.ViewPropertyName.HEIGHT);
    }

    /**
     * Gets current rendering implementation.
     * @return IRenderer
     */
    protected IRenderer getRenderer() {
        return renderer;
    }

    /**
     * Gets current layer factory implementation.
     * @return ILayerFactory
     */
    protected ILayerFactory getLayerFactory() {
        return layersFactory;
    }

    /**
     * Holder for instances of local variables used in the {@link LayerRenderer} render method.
     */
    private class LocalVariables {

        private ILayer layer;

        private int leftChanges;
    }
}
