package com.atsisa.gox.framework.resource;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.ISerialization;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.view.BitmapFontDescription;

/**
 * A common implementation of the bitmap font resource.
 * @param <TFont> The type of platform-specific object representing the font.
 */
public abstract class AbstractBitmapFontResource<TFont> extends AbstractFontResource<TFont> implements IBitmapFontReference<TFont> {

    /**
     * Text resource which contains bitmap font description.
     */
    private AbstractTextResource textResource;

    /**
     * Image resource which contains bitmap font image.
     */
    private AbstractImageResource imageResource;

    /**
     * Bitmap font description.
     */
    private BitmapFontDescription bitmapFontDescription;

    /**
     * IXmlSerializer implementation.
     */
    private IXmlSerializer serializer;

    /**
     * IResourceFactory reference.
     */
    private IResourceFactory resourceFactory;

    /**
     * Constructor with setters for resource description, parser, logger, expected resource type and assets handler.
     * @param description     resource description object
     * @param newSerializer   IXmlSerializer implementation
     * @param resourceFactory IResourceFactory
     */
    public AbstractBitmapFontResource(ResourceDescription description, IXmlSerializer newSerializer, IResourceFactory resourceFactory) {
        super(description, ResourceType.BITMAP_FONT);
        serializer = newSerializer;
        this.resourceFactory = resourceFactory;
    }

    /**
     * Constructor with setter for resource description.
     * @param description resource description object
     */
    public AbstractBitmapFontResource(ResourceDescription description) {
        super(description, ResourceType.BITMAP_FONT);

        IUtility utility = GameEngine.current().getUtility();
        ISerialization serialization = utility.getSerialization();
        serializer = serialization.getSerializer(SerializationFormat.XML);
        resourceFactory = GameEngine.current().getResourceManager().getResourceFactory();
    }

    @Override
    protected void doLoad() {
        ResourceDescription originalDescription = getDescription();

        ResourceDescription textResourceDescription = originalDescription.clone();
        GameEngine.current().getResourceManager().setPathToResource(textResourceDescription);
        textResourceDescription.setResourceType(ResourceType.TEXT);

        textResource = (AbstractTextResource) resourceFactory.createResource(textResourceDescription);
        textResource.load(new BitmapFontAssetLoadedCallback());
    }

    @Override
    public void unload() {
        super.unload();
        if (textResource != null) {
            textResource.unload();
            textResource = null;
        }
        if (imageResource != null) {
            imageResource.unload();
            imageResource = null;
        }
        bitmapFontDescription = null;
    }

    /**
     * Gets bitmap font description.
     * @return BitmapFontDescription
     */
    public BitmapFontDescription getBitmapFontDescription() {
        return bitmapFontDescription;
    }

    @Override
    public int getDefaultFontSize() {
        return bitmapFontDescription.getDefaultFontSize();
    }

    /**
     * Called when the resource is loaded.
     */
    private void onLoadResource() {
        if (imageResource != null) {
            bitmapFontDescription.setPageImage(imageResource, 0);
            onSuccess();
        } else {
            try {
                bitmapFontDescription = (BitmapFontDescription) serializer.deserialize(textResource.getText(), BitmapFontDescription.class);
            } catch (SerializationException e) {
                onError(e.getMessage());
            }

            String pagePath = null;

            List<BitmapFontDescription.Page> bitmapFontPageList = bitmapFontDescription.getPageList();
            if (!bitmapFontPageList.isEmpty()) {
                pagePath = bitmapFontPageList.get(0).getFilePath();
            }

            if (pagePath != null) {
                ResourceDescription originalDescription = getDescription();
                String usedFormat = originalDescription.getUsedFormat();

                ResourceDescription imageResourceDescription = originalDescription.clone();
                GameEngine.current().getResourceManager().setPathToResource(imageResourceDescription);
                imageResourceDescription.setUrl(pagePath);
                imageResourceDescription.setPathToResource(usedFormat);
                imageResourceDescription.setResourceType(ResourceType.IMAGE);

                imageResource = (AbstractImageResource) resourceFactory.createResource(imageResourceDescription);
                imageResource.load(new BitmapFontAssetLoadedCallback());
            } else {
                onError("Can not load bitmap font, because path to image resources for pages was not set.");
            }
        }
    }

    /**
     * Resource loaded callback, handles the event about loaded resource for bitmap font.
     */
    private class BitmapFontAssetLoadedCallback extends ResourceLoadingCallbackAdapter {

        @Override
        public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
            AbstractBitmapFontResource.this.onError(cause.getMessage());
        }

        @Override
        public void onSuccess(IResource resource, int resIndex, int resCount) {
            onLoadResource();
        }
    }

}
