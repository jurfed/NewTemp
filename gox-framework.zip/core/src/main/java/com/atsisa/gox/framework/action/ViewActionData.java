package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Provides data determining which view will be managed by action.
 */
@XmlElement
public class ViewActionData extends ActionData {

    /**
     * Layout id.
     */
    @XmlAttribute
    private String layoutId;

    /**
     * View id.
     */
    @XmlAttribute
    private String viewId;

    /**
     * Gets the layout identifier.
     * @return String the layout identifier
     */
    public String getLayoutId() {
        return layoutId;
    }

    /**
     * Sets the layout identifier.
     * @param layoutId the layout identifier
     */
    public void setLayoutId(String layoutId) {
        this.layoutId = layoutId;
    }

    /**
     * Gets the view identifier.
     * @return String the view identifier
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * Sets the view identifier.
     * @param viewId the view identifier
     */
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

}
