package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.screen.event.ScreenHiddenEvent;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * Hides the screen by removing its layout from the stage with fade out animation.
 */
@Reflectable
public class FadeOutScreenAction extends ScreenAction<ScreenHiddenEvent> {

    /**
     * Time span for fade animation.
     */
    private Integer timeSpan;

    /**
     * Initializes a new instance of the {@link FadeOutScreenAction} class.
     */
    public FadeOutScreenAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link FadeOutScreenAction} class.
     * @param logger      {@link ILogger}
     * @param eventBus    {@link IEventBus}
     */
    public FadeOutScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected Class<ScreenHiddenEvent> getEventClass() {
        return ScreenHiddenEvent.class;
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return FadeScreenActionData.class;
    }

    @Override
    protected void grabData() {
        super.grabData();
        timeSpan = ((FadeScreenActionData) actionData).getTimeSpan();
    }

    @Override
    protected void execute() {
        super.execute();
        TweenViewAnimationData viewAnimationData = new TweenViewAnimationData();
        viewAnimationData.setDestinationAlpha(0F);
        viewAnimationData.setTimeSpan(timeSpan == null ? FadeScreenActionData.DEFAULT_TIME_SPAN : timeSpan);
        eventBus.post(new HideScreenCommand(getScreenId(), viewAnimationData));
    }

}
