package com.atsisa.gox.framework.utility;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.rendering.IGameLoopListener;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Implementation of setTimeout functionality.
 * Timeout is disposable, so it can not be reuse more than once.
 */
public class Timeout {

    /**
     * Callback which will be invoked when time runs out.
     */
    private TimeoutCallback callback;

    /**
     * Time after which this timeout will be activated.
     */
    private int time;

    /**
     * Current time, after start.
     */
    private int currentTime;

    /**
     * Main game engine rendering.
     */
    private IRenderer renderer;

    /**
     * Game loop listener reference.
     */
    private IGameLoopListener gameLoopListener;

    /**
     * A boolean value that indicates whatever this timeout is started or not.
     */
    private boolean started;

    /**
     * A boolean what indicate whatever this timeout is cleaned or not.
     */
    private boolean cleaned;

    /**
     * Logger used for logging exceptions.
     */
    private ILogger logger;

    /**
     * Initializes a new instance of the Timeout class.
     * In this constructor auto start is set to false.
     * @param time     - int, time in milliseconds
     * @param callback - TimeoutCallback
     */
    public Timeout(int time, TimeoutCallback callback) {
        this(time, callback, false);
    }

    /**
     * Initializes a new instance of the Timeout class.
     * @param time      - int, time in milliseconds
     * @param callback  - TimeoutCallback
     * @param autoStart - boolean
     */
    public Timeout(int time, TimeoutCallback callback, boolean autoStart) {
        this(time, callback, autoStart, GameEngine.current().getRenderer(), GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of the Timeout class.
     * @param time      - int, time in milliseconds
     * @param callback  - TimeoutCallback
     * @param autoStart - boolean
     * @param renderer  - IRenderer
     * @param logger    - logger
     */
    public Timeout(int time, TimeoutCallback callback, boolean autoStart, IRenderer renderer, ILogger logger) {
        this.logger = logger;
        if (callback != null) {
            this.time = time;
            this.callback = callback;
            if (renderer != null) {
                this.renderer = renderer;
                if (autoStart) {
                    start();
                }
            } else {
                logger.error("Can't start timeout, because rendering can not be null");
            }
        } else {
            logger.error("Can't start timeout, because callback can not be null");
        }
    }

    /**
     * Gets boolean value that indicate whether this timeout is cleaned or not.
     * @return boolean
     */
    public boolean isCleaned() {
        return cleaned;
    }

    /**
     * Starts timeout.
     */
    public void start() {
        if (!started) {
            if (!cleaned) {
                started = true;
                gameLoopListener = interval -> update(interval);
                renderer.addGameLoopListener(gameLoopListener);
            } else {
                logger.warn("This timeout can not start, because it was already cleared.");
            }
        } else {
            logger.warn("This timeout is already started");
        }
    }

    /**
     * Cancels timeout.
     */
    public void clear() {
        if (callback != null) {
            cleaned = true;
            if (gameLoopListener != null) {
                renderer.removeGameLoopListener(gameLoopListener);
            }
            callback = null;
            time = 0;
        } else {
            logger.warn("This timeout is already cleared, each Timeout cannot be cleared more than once.");
        }
    }

    /**
     * Executes timeout and cancel future activation.
     */
    public void activate() {
        if (callback != null) {
            TimeoutCallback tempCallback = callback;
            clear();
            tempCallback.onTimeout();
        } else {
            logger.warn("This timeout is already finished, each Timeout cannot be finished more than once.");
        }
    }

    /**
     * Updates current time in timeout.
     * @param delta - int
     */
    private void update(float delta) {
        currentTime += Math.round(delta * 1000);
        if (currentTime >= time && !cleaned) {
            activate();
        }
    }
}
