package com.atsisa.gox.framework.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Basic screen class.
 */
@Reflect_Mini
public class BasicScreen extends Screen<ScreenModel> {

    /**
     * Initializes a new instance of the basic screen.
     * @param layoutId layout identifier
     */
    public BasicScreen(String layoutId) {
        super(layoutId, new ScreenModel());
    }

    /**
     * Initializes a new instance of the basic screen.
     * @param layoutId    layout identifier
     * @param viewManager {@link IViewManager}
     */
    public BasicScreen(String layoutId, IViewManager viewManager) {
        super(layoutId, new ScreenModel(), viewManager);
    }

    /**
     * Initializes a new instance of the basic screen.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    public BasicScreen(String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger,
            IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }
}
