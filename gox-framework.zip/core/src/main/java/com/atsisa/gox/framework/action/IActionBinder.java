package com.atsisa.gox.framework.action;

import java.util.List;

import com.atsisa.gox.framework.view.View;

/**
 * Exposes methods for binding and unbinding interactive views and actions.
 */
public interface IActionBinder {

    /**
     * Gets a list of bindings that have been registered in the ConfigurationProvider using populate setMethod.
     * @param targetId interactive view identifier
     * @return a list of bindings
     */
    List<ActionBinding> getBindings(String targetId);

    /**
     * Binds all actions regarding specific view that have been registered before using the ConfigurationProvider. This setMethod is called each time redraw is
     * requested.
     * @param view view to bind
     */
    void bind(final View view);

    /**
     * Unbinds all actions regarding specific views. This setMethod is called each time dispose is requested.
     * @param view view to unbind
     */
    void unbind(final View view);

    /**
     * Unbinds old actions and binds new one regarding to the ConfigurationProvider.
     * @param view view to rebind
     */
    void rebind(View view);

    /**
     * Checks if given view has been bound to any action.
     * @param view view to check
     * @return true if the view has been bound to any action, false otherwise
     */
    boolean isBound(View view);
}
