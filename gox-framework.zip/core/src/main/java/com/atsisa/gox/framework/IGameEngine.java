package com.atsisa.gox.framework;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Provides a game engine abstraction layers.
 */
public interface IGameEngine extends IDisposable {

    /**
     * Gets a specific platform implementation.
     * @return a platform implementation
     */
    IPlatform getPlatform();

    /**
     * Gets platform specific resource manager.
     * @return an implementation of resource manager
     */
    IResourceManager getResourceManager();

    /**
     * Gets the sound manager instance.
     * @return instance of Sound Manager
     */
    ISoundManager getSoundManager();

    /**
     * Gets platform specific rendering.
     * @return IRenderer - instance of the rendering.
     */
    IRenderer getRenderer();

    /**
     * Gets the view manager instance responsible for managing views.
     * @return an implementation of view manager
     */
    IViewManager getViewManager();

    /**
     * Gets platform specific logger.
     * @return an instance of the platform logger
     */
    ILogger getLogger();

    /**
     * Gets network implementation.
     * @return network implementation
     */
    INetwork getNetwork();

    /**
     * Gets the action manager instance responsible for managing actions queues.
     * @return an implementation of action manager
     */
    IActionManager getActionManager();

    /**
     * Gets the currently running game. If there is no game started, null is returned.
     * @return a reference to the currently running game.
     */
    IGame getGame();

    /**
     * Gets the currently running game's configuration. If there is no game started, null is returned.
     * @return a reference to the currently running game's configuration.
     */
    IGameConfiguration getGameConfiguration();

    /**
     * Gets an instance of the configuration provider object.
     * @return an instance of the configuration provider object
     */
    IConfigurationProvider getConfigurationProvider();

    /**
     * Gets starts screens which needs to be registered at the beginning.
     * @return collection of screens
     */
    Iterable<Screen> getStartScreens();

    /**
     * Gets an instance of the event bus object.
     * @return an instance of the event bus object
     */
    IEventBus getEventBus();

    /**
     * Gets the animation factory.
     * @return The animation factory.
     */
    IAnimationFactory getAnimationFactory();

    /**
     * Starts the game using specific game configuration.
     * @param gameInstance game to start
     * @param gameConfig   game configuration
     */
    void startGame(AbstractGame gameInstance, IGameConfiguration gameConfig);

    /**
     * Gets an instance of utility class.
     * @return an instance of utility class.
     */
    IUtility getUtility();
}
