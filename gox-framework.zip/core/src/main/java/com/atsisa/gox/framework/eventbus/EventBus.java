package com.atsisa.gox.framework.eventbus;

import java.util.List;

import com.atsisa.gox.framework.eventbus.subscription.AnnotatedSubscriptionMetadata;
import com.atsisa.gox.framework.eventbus.subscription.CompositeSubscription;
import com.atsisa.gox.framework.eventbus.subscription.RxSubscriptionWrapper;
import com.atsisa.gox.framework.eventbus.subscription.SubscriptionAnnotationProcessor;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.google.inject.Inject;

import rx.Observable;
import rx.Observer;

/**
 * GOX-compliant event bus implementation.
 */
public class EventBus implements IEventBus {

    /**
     * The reflection reference.
     */
    private final IReflection reflection;

    /**
     * The logger reference.
     */
    private final ILogger logger;

    /**
     * Instance of event bus implementation.
     */
    private final RxEventBus rxEventBus;

    /**
     * Instance of subscription annotation processor.
     */
    private final SubscriptionAnnotationProcessor subscriptionAnnotationProcessor;

    /**
     * Initializes a new instance of {@link EventBus}.
     * @param reflection {@link IReflection}
     * @param logger     {@link ILogger}
     */
    @Inject
    public EventBus(IReflection reflection, ILogger logger) {
        this.reflection = reflection;
        this.logger = logger;
        subscriptionAnnotationProcessor = new SubscriptionAnnotationProcessor(reflection);
        rxEventBus = new RxEventBus.Builder<>().asPublishSubscribeBus().withReflection(reflection).withLogger(logger).build();
    }

    @Override
    public void post(Object event) {
        rxEventBus.post(event);
    }

    @Override
    public Subscription register(Observer observer) {
        Observable observable = rxEventBus.observe();
        return new RxSubscriptionWrapper(observable.subscribe(observer));
    }

    @Override
    public Subscription register(Observer observer, Class eventClass) {
        Observable observable = rxEventBus.observeEvents(eventClass);
        return new RxSubscriptionWrapper(observable.subscribe(observer));
    }

    @Override
    public Subscription register(Observer observer, String clazzName) throws ReflectionException {
        Observable observable = rxEventBus.observeEvents(reflection.getClassForName(clazzName));
        return new RxSubscriptionWrapper(observable.subscribe(observer));
    }

    @Override
    public Subscription register(Object annotatedObserver) throws ReflectionException {
        List<AnnotatedSubscriptionMetadata> annotatedSubscriptionMetadatas = subscriptionAnnotationProcessor.extractAnnotatedMethods(annotatedObserver);
        CompositeSubscription subscription = new CompositeSubscription(logger, this, annotatedSubscriptionMetadatas);
        subscription.subscribe();
        return subscription;
    }
}
