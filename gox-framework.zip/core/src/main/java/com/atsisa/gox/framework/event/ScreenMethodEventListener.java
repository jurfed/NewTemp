package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.UpdateScreenAction;
import com.atsisa.gox.framework.action.UpdateScreenActionData;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.ILayout;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.InteractiveView;
import com.atsisa.gox.framework.view.View;

/**
 * Screen setMethod event listener.
 * <p>
 * When an event occurs, this listener executes the {@link UpdateScreenAction}
 * which subsequently invokes the setMethod given as 'methodName' constructor's parameter.
 * </p>
 * The target object is an instance of the {@link Screen} class which contains the {@link InteractiveView}.
 */
public class ScreenMethodEventListener implements IEventListener<InputEvent> {

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Screen setMethod name.
     */
    private final String methodName;

    /**
     * Screen setMethod methodParameters.
     */
    private final Object[] methodParameters;

    /**
     * View manager reference.
     */
    private final IViewManager viewManager;

    /**
     * Initializes a new instance of the ActionEventListener class.
     * @param methodName       screen setMethod name
     * @param methodParameters screen setMethod parameters
     */
    public ScreenMethodEventListener(String methodName, Object[] methodParameters) {
        this(methodName, GameEngine.current().getLogger(), GameEngine.current().getViewManager(), methodParameters);
    }

    /**
     * Initializes a new instance of the ActionEventListener class.
     * @param methodName       screen setMethod name
     * @param logger           logger reference
     * @param viewManager      view manager reference
     * @param methodParameters screen setMethod parameters
     */
    public ScreenMethodEventListener(String methodName, ILogger logger, IViewManager viewManager, Object[] methodParameters) {
        this.methodName = methodName;
        this.viewManager = viewManager;
        this.logger = logger;
        this.methodParameters = methodParameters;
    }

    @Override
    public void onEvent(InputEvent event) {
        String screenId = getViewScreenIdentifier(event.getSource());
        if (screenId == null) {
            logger.warn("Could not process UpdateScreenAction. The view has not a part of any layout.");
            return;
        }
        UpdateScreenActionData actionData = new UpdateScreenActionData(screenId, methodName, methodParameters);
        UpdateScreenAction action = new UpdateScreenAction();
        action.setActionData(actionData);
        action.executeStandalone();
    }

    /**
     * Gets the screen setMethod name.
     * @return screen setMethod name
     */
    public String getMethodName() {
        return methodName;
    }

    /**
     * Gets the screen setMethod parameters.
     * @return screen setMethod parameters
     */
    public Object[] getMethodParameters() {
        return methodParameters;
    }

    /**
     * Gets the screen identifier based on view which it belongs to.
     * @param viewToSearch view to search
     * @return screen identifier based on view which it belongs to
     */
    private String getViewScreenIdentifier(View viewToSearch) {
        ILayout layout = viewManager.findLayoutByView(viewToSearch);
        return layout != null ? layout.getId() : null;
    }
}
