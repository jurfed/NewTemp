package com.atsisa.gox.framework.exception;

/**
 * Action validation exception.
 */
public class ValidationException extends Exception {

    public ValidationException(String message) {
        super(message);
    }
}
