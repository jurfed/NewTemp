package com.atsisa.gox.framework.utility;

/**
 * Contains definition of common static values that are used to fetch and/or process configuration.
 */
public final class ConfigurationStatics {

    /**
     * Default resource name for reel game configuration.
     */
    public static final String REEL_GAME_CONFIGURATION_ENTRY_NAME = "reelGameConfiguration";

    /**
     * Default name for resource with presentations/queues.
     */
    public static final String REEL_GAME_PRESENTATION_QUEUES_NAME = "presentations";

    /**
     * Prevents instantiation of this class.
     */
    private ConfigurationStatics() {
    }

}
