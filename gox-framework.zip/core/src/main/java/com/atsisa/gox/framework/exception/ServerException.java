package com.atsisa.gox.framework.exception;

/**
 * Class for the exceptions related to the server.
 */
public class ServerException extends Exception {

    public ServerException(String message) {
        super(message);
    }
}
