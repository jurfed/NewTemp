package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.EventListenerConverter;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Action binding model class. Describes connection between views and actions. Serializable to and from XML.
 */
@Reflect_Full
@XmlElement
public class ActionBinding {

    /**
     * Target view identifier.
     */
    @XmlAttribute
    private String targetId;

    /**
     * Target view event type.
     */
    @XmlAttribute(name = "event")
    private InputEventType eventType;

    /**
     * A listener which should be called when an event occurs.
     */
    @XmlAttribute(name = "action", converters = EventListenerConverter.class)
    private IEventListener eventListener;

    /**
     * Gets a target view identifier.
     * @return a target view identifier
     */
    public String getTargetId() {
        return targetId;
    }

    /**
     * Sets a target view identifier.
     * @param targetId a target view identifier
     */
    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    /**
     * Gets an event type.
     * @return event type
     */
    public InputEventType getEventType() {
        return eventType;
    }

    /**
     * Sets an event type.
     * @param eventType an event type
     */
    public void setEventType(InputEventType eventType) {
        this.eventType = eventType;
    }

    /**
     * Gets a listener which should be called when an event occurs.
     * This object contains a name of the action queue which will be processed accessible via getActionQueueName setMethod.
     * @return an event listener
     */
    public IEventListener getEventListener() {
        return eventListener;
    }

    /**
     * Setsa listener which should be called when an event occurs.
     * @param eventListener event listener
     */
    public void setEventListener(IEventListener eventListener) {
        this.eventListener = eventListener;
    }
}
