package com.atsisa.gox.framework.screen.event;

import com.atsisa.gox.framework.screen.Screen;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when the screen was hidden.
 */
@Reflectable
public class ScreenHiddenEvent extends ScreenEvent {

    /**
     * Initializes a new instance of the {@link ScreenHiddenEvent} class.
     * @param screen {@link Screen}
     */
    public ScreenHiddenEvent(Screen screen) {
        super(screen);
    }
}
