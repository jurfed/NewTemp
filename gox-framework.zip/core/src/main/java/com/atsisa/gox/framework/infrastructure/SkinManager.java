package com.atsisa.gox.framework.infrastructure;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.Skin;
import com.google.inject.Inject;

/**
 * Manages skins. Gets skins from configuration and returns proper skin.
 */
public class SkinManager implements ISkinManager {

    /**
     * A configuration provider reference.
     */
    private final IConfigurationProvider configurationProvider;

    private Map<String, Skin> skins;

    /**
     * A logger reference.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of {@link SkinManager} class.
     */
    public SkinManager() {
        this(GameEngine.current().getConfigurationProvider(), GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of {@link SkinManager} class.
     * @param configurationProvider {@link IConfigurationProvider}
     * @param logger                {@link ILogger}
     */
    @Inject
    public SkinManager(IConfigurationProvider configurationProvider, ILogger logger) {
        logger.debug("SkinManager | ctor");

        this.configurationProvider = configurationProvider;
        this.logger = logger;

    }

    @Override
    public Skin getSkin(String name) {
        logger.debug("SkinManager | getSkin | '%s'", name);

        if (skins == null) {
            skins = new HashMap<>();
            List<Skin> skinList = configurationProvider.getConfiguration().getSkinList();
            for (Skin skin : skinList) {
                skins.put(skin.getName().toLowerCase(), skin);
            }
        }

        return skins.get(name.toLowerCase());
    }
}
