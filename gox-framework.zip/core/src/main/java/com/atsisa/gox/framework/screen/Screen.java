package com.atsisa.gox.framework.screen;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.command.ScreenCommand;
import com.atsisa.gox.framework.command.ShowScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.ILayout;
import com.atsisa.gox.framework.model.ILayoutListener;
import com.atsisa.gox.framework.model.Layout;
import com.atsisa.gox.framework.model.LayoutEventType;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.screen.event.ScreenEvent;
import com.atsisa.gox.framework.screen.event.ScreenHiddenEvent;
import com.atsisa.gox.framework.screen.event.ScreenHidingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.Field;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;

import rx.Subscription;

/**
 * An abstraction layers for model-driven screen.
 * @param <T> type of the model object
 */
public abstract class Screen<T extends ScreenModel> implements ILayoutListener {

    /**
     * Singleton instance of emtpy view animation.
     */
    private static final TweenViewAnimationData NULL_TWEEN_VIEW_ANIMATION_DATA = new TweenViewAnimationData();

    /**
     * Delegate reference realizing screen shown event propagation.
     */
    private final ScreenShownFinishCallbackDelegate screenShownFinishCallbackDelegate = new ScreenShownFinishCallbackDelegate();

    /**
     * Delegate reference realizing remove layout.
     */
    private final RemoveLayoutFinishCallbackDelegate removeLayoutFinishCallbackDelegate = new RemoveLayoutFinishCallbackDelegate();

    /**
     * View manager reference.
     */
    private final IViewManager viewManager;

    /**
     * The animation factory.
     */
    private final IAnimationFactory animationFactory;

    /**
     * A screen layout object.
     */
    private ILayout layout;

    /**
     * A view bindings map.
     */
    private final Map<String, Field> viewBindingMap;

    /**
     * Model data object.
     */
    private T model;

    /**
     * Current animation.
     */
    private IViewAnimation currentAnimation;

    /**
     * Current animation subscription.
     */
    private Subscription currentAnimationSubscription;

    /**
     * A value indicating whether the view bindings have been bound.
     */
    private boolean viewsBound;

    /**
     * Reference to the renderer.
     */
    private IRenderer renderer;

    /**
     * Event bus reference.
     */
    private IEventBus eventBus;

    /**
     * Logger reference.
     */
    private ILogger logger;

    /**
     * Layout identifier.
     */
    private String layoutId;

    /**
     * A boolean value that indicates whether this screen is initialzied or not.
     */
    private final AtomicBoolean initialized;

    /**
     * Initializes a new instance of the {@link Screen} class.
     * @param layoutId screen layout identifier
     */
    protected Screen(String layoutId) {
        this(layoutId, null, GameEngine.current().getRenderer(), GameEngine.current().getViewManager(), GameEngine.current().getAnimationFactory(),
                GameEngine.current().getLogger(), GameEngine.current().getEventBus());
    }

    /**
     * Initializes a new instance of the {@link Screen} class.
     * @param layoutId    screen layout identifier
     * @param model       model data object.
     * @param viewManager {@link IViewManager}
     */
    protected Screen(String layoutId, T model, IViewManager viewManager) {
        this(layoutId, model, GameEngine.current().getRenderer(), viewManager, GameEngine.current().getAnimationFactory(), GameEngine.current().getLogger(),
                GameEngine.current().getEventBus());
    }

    /**
     * Initializes a new instance of the {@link Screen} class.
     * @param layoutId screen layout identifier.
     * @param model    model data object.
     */
    protected Screen(String layoutId, T model) {
        this(layoutId, model, GameEngine.current().getRenderer(), GameEngine.current().getViewManager(), GameEngine.current().getAnimationFactory(),
                GameEngine.current().getLogger(), GameEngine.current().getEventBus());
    }

    /**
     * Initializes a new instance of the {@link Screen} class.
     * @param layoutId         layout id
     * @param model            screen model
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    protected Screen(String layoutId, T model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger,
            IEventBus eventBus) {
        this.layoutId = layoutId;
        this.model = model;
        this.eventBus = eventBus;
        this.logger = logger;
        this.renderer = renderer;
        this.viewManager = viewManager;
        this.animationFactory = animationFactory;
        viewBindingMap = new HashMap<>();
        initialized = new AtomicBoolean(false);
    }

    /**
     * Gets screen layout identifier.
     * @return layout identifier
     */
    public String getLayoutId() {
        return layoutId;
    }

    /**
     * Initializes screen.
     */
    public final void initialize() {
        if (!initialized.getAndSet(true)) {
            doInitialize();
        }
    }

    /**
     * Gets the screen layout.
     * @return screen layout
     */
    public ILayout getLayout() {
        return layout;
    }

    /**
     * Gets the screen model object.
     * @return screen model object
     */
    public T getModel() {
        return model;
    }

    /**
     * Sets the model.
     * @param model layout model
     */
    public final void setModel(T model) {
        this.model = model;
        layout.setScreenModel(model);
    }

    /**
     * Checks if the screen is currently active on stage.
     * @return true if the screen layout is on the stage, false otherwise
     */
    public boolean isActive() {
        return layout != null && layout.isOnStage();
    }

    /**
     * Finds a view by its identifier.
     * @param viewId view identifier to find
     * @param <T>    type of the view
     * @return found view matching the identifier or null if there was no such view.
     */
    @SuppressWarnings("unchecked")
    public <T extends View> T findViewById(String viewId) {
        return (T) viewManager.findViewById(layout.getId(), viewId);
    }

    /**
     * Finds a views by its type.
     * @param viewType view type to match
     * @param <T>      type of the view
     * @return a list of found views matching the viewType or an empty list if there was no such view.
     */
    public <T extends View> List<T> findViewByType(Class<T> viewType) {
        return viewManager.findViewByType(layout.getId(), viewType);
    }

    /**
     * Finds a views inheriting from given type in layout.
     * @param viewType view type to match
     * @return a list of found views inheriting the viewType or an empty list if there was no such view.
     */
    public List<? extends View> findViewInheritingType(Class<? extends View> viewType) {
        return viewManager.findViewInheritingType(layout.getId(), viewType);
    }

    /**
     * Finds all views implementing given type.
     * @param interfaceType The type to implement.
     * @param <T>           The type of the interface.
     * @return All views implementing given type or an empty list if there was no such view.
     */
    public <T> List<T> findViewImplementingType(Class<T> interfaceType) {
        return viewManager.findViewImplementingType(layout.getRootView(), interfaceType);
    }

    /**
     * Adds the screen layout to the main stage.
     */
    @ExposeMethod
    public void show() {
        show(null, null);
    }

    /**
     * Adds the screen layout to the main stage using specified effect.
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param finishCallback    {@link IFinishCallback}
     */
    public void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback) {
        show(viewAnimationData, finishCallback, null);
    }

    /**
     * Cancels current animation.
     */
    public void cancelCurrentAnimation() {
        if (currentAnimation != null) {
            currentAnimation.stop();
            clearCurrentAnimation();
        }
    }

    /**
     * Handles the screen command.
     * @param screenCommand {@link ScreenCommand}
     */
    public void handleScreenCommand(ScreenCommand screenCommand) {
        if (screenCommand.getScreenId().equals(getLayoutId())) {
            processScreenCommand(screenCommand);
        }
    }

    /**
     * Removes the screen layout from the main stage.
     */
    @ExposeMethod
    public void hide() {
        hide(null, null);
    }

    /**
     * Removes the screen layout from the main stage using specified effect.
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param callback          {@link IFinishCallback}
     */
    public void hide(TweenViewAnimationData viewAnimationData, final IFinishCallback callback) {
        this.hide(viewAnimationData, callback, null);
    }

    /**
     * Updates the layout.
     */
    @ExposeMethod
    public void update() {
        if (layout == null) {
            return;
        }
        layout.refresh();
        if (model != null) {
            model.update();
        }
    }

    @Override
    public void onLayoutEvent(Layout currentLayout, LayoutEventType eventType) {
        switch (eventType) {
            case BEFORE_ADDED:
                beforeActivated();
                break;
            case AFTER_ADDED:
                if (!viewsBound) {
                    bindViews();
                    viewsBound = true;
                }
                afterActivated();
                break;
            case BEFORE_HIDDEN:
                beforeDeactivated();
                break;
            case BEFORE_DESTROYED:
                beforeDeactivated();
                unbindViews();
                viewsBound = false;
                break;
            case AFTER_DESTROYED:
            case AFTER_HIDDEN:
                afterDeactivated();
                break;
            default:
                getLogger().warn("Undefined layout event type: %s", eventType);
                break;
        }
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        getEventBus().register(new ScreenCommandObserver(), ScreenCommand.class);
    }

    /**
     * Internal method to handle initialization screen part.
     */
    protected void doInitialize() {
        registerEvents();
        layout = createLayout(layoutId);
        if (model != null) {
            layout.setScreenModel(model);
        }
        layout.addLayoutListener(this);
    }

    /**
     * Processes the command for this screen.
     * @param screenCommand {@link ScreenCommand}
     */
    protected void processScreenCommand(ScreenCommand screenCommand) {
        if (screenCommand instanceof ShowScreenCommand) {
            show(((ShowScreenCommand) screenCommand).getShowViewAnimationData(), null, screenCommand);
        } else if (screenCommand instanceof HideScreenCommand) {
            hide(((HideScreenCommand) screenCommand).getHideViewAnimationData(), null, screenCommand);
        }
    }

    /**
     * Removes the screen layout from the main stage using specified effect.
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param callback          {@link IFinishCallback}
     * @param triggeredEvent    the event that triggered this method
     */
    protected void hide(TweenViewAnimationData viewAnimationData, final IFinishCallback callback, Object triggeredEvent) {
        removeLayoutFinishCallbackDelegate.setTriggeredEvent(triggeredEvent);
        removeLayoutFinishCallbackDelegate.setFinishCallback(callback);

        if (isActive()) {
            removeLayoutFinishCallbackDelegate.setLayoutId(layout.getId());
            notifyScreenHiding(triggeredEvent);
            if (viewAnimationData == null) {
                viewAnimationData = NULL_TWEEN_VIEW_ANIMATION_DATA;
            }
            startScreenAnimation(viewAnimationData, removeLayoutFinishCallbackDelegate);
        } else {
            removeLayoutFinishCallbackDelegate.onFinish();
        }
    }

    /**
     * Adds the screen layout to the main stage using specified effect.
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param finishCallback    {@link IFinishCallback}
     * @param triggeredEvent    the event that triggered this method
     */
    protected void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback, Object triggeredEvent) {
        screenShownFinishCallbackDelegate.setTriggeredEvent(triggeredEvent);
        screenShownFinishCallbackDelegate.setFinishCallback(finishCallback);

        if (!isActive()) {
            notifyScreenShowing(triggeredEvent);
            viewManager.addLayout(layout.getId());
            update();
            if (viewAnimationData == null) {
                viewAnimationData = NULL_TWEEN_VIEW_ANIMATION_DATA;
            }
            startScreenAnimation(viewAnimationData, screenShownFinishCallbackDelegate);
        } else {
            screenShownFinishCallbackDelegate.onFinish();
        }
    }

    /**
     * Sets a model property.
     * @param name  {@link String}
     * @param value {@link Boolean}
     */
    protected void setModelProperty(String name, Boolean value) {
        getModel().setProperty(name, value);
    }

    /**
     * Gets a reference to the view manager.
     * @return a reference to the view manager
     */
    protected IViewManager getViewManager() {
        return viewManager;
    }

    /**
     * Called when the layout is about to be added to the stage.
     */
    protected void beforeActivated() {
    }

    /**
     * Called when the layout has been added to the stage.
     */
    protected void afterActivated() {
    }

    /**
     * Called when the layout is about to be destroyed.
     */
    protected void beforeDeactivated() {
    }

    /**
     * Called when the layout has been destroyed.
     */
    protected void afterDeactivated() {
    }

    /**
     * Creates a root view of the layout. This method by default creates an empty view group.
     * @return a root view of the layout.
     */
    protected View createLayout() {
        return new ViewGroup();
    }

    /**
     * Notifies regarding the showing screen.
     * @param sourceEvent {@link Object}
     */
    protected void notifyScreenShowing(Object sourceEvent) {
        postScreenEvent(new ScreenShowingEvent(this), sourceEvent);
    }

    /**
     * Notifies regarding the shown screen.
     * @param sourceEvent {@link Object}
     */
    protected void notifyScreenShown(Object sourceEvent) {
        postScreenEvent(new ScreenShownEvent(this), sourceEvent);
    }

    /**
     * Notifies regarding the screen is hiding.
     * @param sourceEvent {@link Object}
     */
    protected void notifyScreenHiding(Object sourceEvent) {
        postScreenEvent(new ScreenHidingEvent(this), sourceEvent);
    }

    /**
     * Notifies regarding the screen was hidden.
     * @param sourceEvent {@link Object}
     */
    protected void notifyScreenHidden(Object sourceEvent) {
        postScreenEvent(new ScreenHiddenEvent(this), sourceEvent);
    }

    /**
     * Posts the specific event to event bus.
     * @param screenEvent {@link ScreenEvent}
     * @param sourceEvent {@link Object}
     */
    protected void postScreenEvent(ScreenEvent screenEvent, Object sourceEvent) {
        screenEvent.setSourceEvent(sourceEvent);
        eventBus.post(screenEvent);
    }

    /**
     * Gets the property value from the screen model.
     * @param propertyName {@link String}
     * @return value from screen model
     */
    protected Object getProperty(String propertyName) {
        NamedProperty namedProperty = getModel().getProperty(propertyName);
        if (namedProperty != null) {
            return namedProperty.get();
        }
        return null;
    }

    /**
     * Gets reference to the renderer.
     * @return renderer reference
     */
    protected IRenderer getRenderer() {
        return renderer;
    }

    /**
     * Gets reference to the event bus.
     * @return event bus reference
     */
    protected IEventBus getEventBus() {
        return eventBus;
    }

    /**
     * Gets reference to the logger.
     * @return renderer logger
     */
    protected ILogger getLogger() {
        return logger;
    }

    /**
     * Gets the previously registered layout from the view manager. If there is no layout registered, createLayout setMethod is fired.
     * @param layoutId {@link String}
     * @return a layout object
     */
    private ILayout createLayout(String layoutId) {
        ILayout createdLayout = viewManager.getLayout(layoutId);
        if (createdLayout == null) {
            logger.warn("Unable to find '%s' layout descriptor in resources. The layout will be created in code.", layoutId);
            View rootView = createLayout();
            viewManager.registerLayout(layoutId, rootView);
            createdLayout = viewManager.getLayout(layoutId);
        }
        return createdLayout;
    }

    /**
     * Clears current layout animation.
     */
    private void clearCurrentAnimation() {
        if (currentAnimationSubscription != null) {
            currentAnimationSubscription.unsubscribe();
            currentAnimationSubscription = null;
        }
        currentAnimation = null;
    }

    /**
     * Starts the screen animation.
     * @param viewAnimationData view animation data
     * @param finishCallback    animation callback
     */
    private void startScreenAnimation(TweenViewAnimationData viewAnimationData, final IFinishCallback finishCallback) {
        TweenViewAnimation tweenViewAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(layout.getRootView());
        tweenViewAnimation.setViewAnimationData(viewAnimationData);
        currentAnimation = tweenViewAnimation;
        currentAnimationSubscription = currentAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState != AnimationState.STOPPED) {
                return;
            }
            clearCurrentAnimation();
            finishCallback.onFinish();
        });
        currentAnimation.play();
    }

    /**
     * Binds the views defined as class fields.
     */
    private void bindViews() {
        if (viewBindingMap.isEmpty()) {
            IReflection reflection = GameEngine.current().getUtility().getReflection();
            Class<?> classReference = getClass();
            while (classReference != null) {
                Field[] fieldArray = reflection.getFields(classReference);
                for (Field field : fieldArray) {
                    InjectView viewBinding = field.getAnnotation(InjectView.class);
                    if (viewBinding != null) {
                        String viewId = viewBinding.id();
                        if (viewId.isEmpty()) {
                            viewId = field.getName();
                        }
                        setFieldValue(viewId, field);
                    }
                }
                classReference = reflection.getSuperClass(classReference);
            }
        } else {
            for (Map.Entry<String, Field> entry : viewBindingMap.entrySet()) {
                setFieldValue(entry.getKey(), viewBindingMap.get(entry.getKey()));
            }
        }
    }

    /**
     * Unbinds the views defined in class fields.
     */
    private void unbindViews() {
        for (Map.Entry<String, Field> entry : viewBindingMap.entrySet()) {
            setFieldValue(null, entry.getValue());
        }
    }

    /**
     * Sets the view binding field value to a particular view.
     * @param viewId view identifier to find
     * @param field  field to set
     */
    private void setFieldValue(String viewId, Field field) {
        View view;
        if (viewId == null) {
            view = null;
        } else {
            view = findViewById(viewId);
        }
        try {
            field.setValue(this, view);
        } catch (ReflectionException e) {
            getLogger().error(StringUtility.format("Could not bind view '%s' to a field!", viewId), e);
        }
    }

    /**
     * Gets the animation factory.
     * @return The animation factory.
     */
    protected IAnimationFactory getAnimationFactory() {
        return animationFactory;
    }

    private class ScreenCommandObserver extends NextObserver<ScreenCommand> {

        @Override
        public void onNext(final ScreenCommand screenCommand) {
            handleScreenCommand(screenCommand);
        }
    }

    /**
     * Delegate used to notify screen shown events as an animation finish callback.
     */
    class ScreenShownFinishCallbackDelegate implements IFinishCallback {

        /**
         * Delegated finish callback reference.
         */
        private IFinishCallback finishCallback;

        /**
         * An event that triggered screen to show up.
         */
        private Object triggeredEvent;

        @Override
        public void onFinish() {
            if (finishCallback != null) {
                finishCallback.onFinish();
            }
            notifyScreenShown(triggeredEvent);
        }

        /**
         * Sets an event that triggered screen to show up.
         * @param triggeredEvent {@link Object}
         */
        public void setTriggeredEvent(Object triggeredEvent) {
            this.triggeredEvent = triggeredEvent;
        }

        /**
         * Sets reference of {@link IFinishCallback} that will invoked.
         * @param finishCallback IFinishCallback
         */
        public void setFinishCallback(IFinishCallback finishCallback) {
            this.finishCallback = finishCallback;
        }
    }

    /**
     * Delegate used to remove layout as an animation finish callback.
     */
    class RemoveLayoutFinishCallbackDelegate implements IFinishCallback {

        /**
         * Delegated finish callback reference.
         */
        private IFinishCallback finishCallback;

        /**
         * An event that triggered screen to hide.
         */
        private Object triggeredEvent;

        /**
         * ID of a layout that should be removed.
         */
        private String layoutId;

        @Override
        public void onFinish() {
            if (!StringUtility.isNullOrEmpty(layoutId)) {
                viewManager.removeLayout(layoutId);
            }
            if (finishCallback != null) {
                finishCallback.onFinish();
            }
            notifyScreenHidden(triggeredEvent);
        }

        /**
         * Sets an event that triggered screen to hide.
         * @param triggeredEvent {@link Object}
         */
        public void setTriggeredEvent(Object triggeredEvent) {
            this.triggeredEvent = triggeredEvent;
        }

        /**
         * Sets reference of {@link IFinishCallback} that will invoked.
         * @param finishCallback IFinishCallback
         */
        public void setFinishCallback(IFinishCallback finishCallback) {
            this.finishCallback = finishCallback;
        }

        /**
         * Sets layout id of a view that will be removed from the stage.
         * @param layoutId String
         */
        public void setLayoutId(String layoutId) {
            this.layoutId = layoutId;
        }
    }
}
