package com.atsisa.gox.framework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.action.AbstractActionModule;
import com.atsisa.gox.framework.action.IActionBuilder;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.event.GameInitializedEvent;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.exception.ResourceException;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.resource.IResource;
import com.atsisa.gox.framework.resource.IResourceLoadingCallback;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.ResourceDescription;
import com.atsisa.gox.framework.screen.PreloaderScreen;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.interceptor.PropertyBindingInterceptor;
import com.atsisa.gox.framework.utility.IForceInitializable;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.logger.LogLevel;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.framework.view.AbstractViewModule;

/**
 * Game abstraction class. Inherit this class if you want to deploy your own game.
 */
public abstract class AbstractGame implements IGame {

    /**
     * Log level.
     */
    private static final String LOG_LEVEL = "logLevel";

    /**
     * A list which contains objects which will be initialized after special behaviour.
     */
    private final List<IForceInitializable> forceInitializables;

    /**
     * Resource loading callback.
     */
    private IResourceLoadingCallback resourceLoadingCallback;

    /**
     * Game engine reference.
     */
    protected IGameEngine gameEngine;

    /**
     * Initializes a lifecycle listener.
     */
    protected AbstractGame() {
        forceInitializables = new ArrayList<>();
    }

    @Override
    public void onCreate() {
    }

    @Override
    public void onStart(){
        gameEngine.getEventBus().post(new GameInitializedEvent());
    }

    /**
     * Gets a map with loading handlers with their weights. This handlers will be used to presents progress bar at start.
     * @return a map with loading handlers with their weights
     */
    protected Map<ILoadingHandler, Integer> getLoadingHandlers() {
        Map<ILoadingHandler, Integer> loadingHandlers = new HashMap<>();
        IResourceManager resourceManager = gameEngine.getResourceManager();
        loadingHandlers.put(resourceManager, 20);
        return loadingHandlers;
    }

    @Override
    public boolean registerForceInitializable(IForceInitializable forceInitializable) {
        if (forceInitializables.contains(forceInitializable)) {
            return false;
        }
        forceInitializables.add(forceInitializable);
        return true;
    }

    @Override
    public boolean unregisterForceInitializable(IForceInitializable forceInitializable) {
        return forceInitializables.remove(forceInitializable);
    }

    @Override
    public void invokeForceInitializableObjects() {
        List<IForceInitializable> forceInitializables = new ArrayList<>(this.forceInitializables);
        for (IForceInitializable forceInitializable : forceInitializables) {
            forceInitializable.forceInitialize();
        }
    }

    @Override
    public void onReady() {
    }

    /**
     * Gets the game engine reference.
     * @return game engine reference
     */
    protected final IGameEngine getEngine() {
        return gameEngine;
    }

    /**
     * Loads the resources using the resource description file. Once the resources are loaded the onReady
     */
    protected void loadResources() {
        loadResources(null);
    }

    /**
     * Initialize preloader.
     */
    private void initializePreloader() {
        PreloaderScreen preloaderScreen = findStartScreen(PreloaderScreen.class);
        if (preloaderScreen != null) {
            getEngine().getViewManager().registerScreen(preloaderScreen);
            Map<ILoadingHandler, Integer> handlersMap = getLoadingHandlers();
            for (Map.Entry<ILoadingHandler, Integer> entry : handlersMap.entrySet()) {
                preloaderScreen.addLoadingHandler(entry.getKey(), entry.getValue());
            }
            preloaderScreen.initialize();
            preloaderScreen.show();
        }
    }

    /**
     * Finds and returns specific screen in start screens.
     * @param screenType screen type to find
     * @param <T> screen class type
     * @return instance of the screen
     */
    protected <T extends Screen> T findStartScreen(Class<T> screenType) {
        Iterable<Screen> startScreens = getEngine().getStartScreens();
        for (Screen screen : startScreens) {
            if (screen.getClass().equals(screenType)) {
                return (T) screen;
            }
        }
        return null;
    }

    /**
     * Loads the resources and calls executeOnReady when the loader is ready. Otherwise onError setMethod is called.
     */
    void executeOnCreate() {
        gameEngine = GameEngine.current();
        try {
            onCreate();
            initializePreloader();
            loadResources();
        } catch (Exception e) {
            e.printStackTrace();
            gameEngine.getEventBus().post(new ErrorOccurredEvent(new GeneralSystemException(e)));
        }
    }

    /**
     * Called when resources are loaded.
     */
    protected void executeOnReady() {
        try {
            IReflection reflection = gameEngine.getUtility().getReflection();
            IViewManager viewManager = gameEngine.getViewManager();
            IActionManager actionManager = gameEngine.getActionManager();
            IConfigurationProvider configurationProvider = gameEngine.getConfigurationProvider();
            IXmlSerializer serializer = gameEngine.getUtility().getSerialization().getSerializer(SerializationFormat.XML);
            ILogger logger = gameEngine.getLogger();

            serializer.addInterceptor(new PropertyBindingInterceptor(logger, configurationProvider));
            serializer.addInterceptor(viewManager.getViewBuilder().getPropertyBindingInterceptor());

            IConfiguration configuration = configurationProvider.getConfiguration();
            Iterable<Screen> screens = gameEngine.getStartScreens();

            Object logLevelObject = configuration.getProperty(LOG_LEVEL);
            if (logLevelObject != null) {
                LogLevel logLevel = LogLevel.valueOf(logLevelObject.toString());
                gameEngine.getLogger().setLevel(logLevel);
            }

            viewManager.registerLayoutsFromResources();
            actionManager.registerActionQueuesFromResources();
            if (screens != null) {
                screens.forEach(screen -> {
                    viewManager.registerScreen(screen);
                    screen.initialize();
                });
            }
            registerModules(reflection, configuration);
            viewManager.buildAllLayouts();
            onReady();
            executeOnStart();
        } catch (Exception e) {
            gameEngine.getEventBus().post(new ErrorOccurredEvent(new GeneralSystemException(e)));
        }
    }

    /**
     * Called as the last step of executeOnReady setMethod.
     */
    protected void executeOnStart() {
        onStart();
    }

    /**
     * Gets the game configuration.
     * @return game configuration
     */
    protected IGameConfiguration getGameConfiguration() {
        return gameEngine.getGameConfiguration();
    }

    /**
     * Loads the resources using the resource description file. Once the resources are loaded the onReady
     * @param resourceDescriptionList a list of resource descriptions
     */
    protected void loadResources(List<ResourceDescription> resourceDescriptionList) {
        IResourceManager resourceManager = gameEngine.getResourceManager();
        resourceManager.setResourceFormats(gameEngine.getGameConfiguration().getResourceFormats());
        resourceLoadingCallback = createResourceLoadingCallback(this);

        resourceManager.addResourceLoadingCallback(resourceLoadingCallback);
        if (resourceDescriptionList == null) {
            String resourceFileName = gameEngine.getGameConfiguration().getResourceDescriptionFile();
            resourceManager.load(resourceFileName);
        } else {
            resourceManager.load(resourceDescriptionList);
        }
    }

    /**
     * Registers view and action modules from configuration.
     * @param reflection    reflection reference
     * @param configuration configuration reference
     * @throws ReflectionException when some modules could not be instantiated
     */
    private void registerModules(IReflection reflection, IConfiguration configuration) throws ReflectionException {
        IViewBuilder viewBuilder = gameEngine.getViewManager().getViewBuilder();
        for (String moduleClassName : configuration.getViewModules()) {
            AbstractViewModule module = (AbstractViewModule) reflection.createInstance(moduleClassName);
            viewBuilder.registerModule(module);
        }
        IActionBuilder actionBuilder = gameEngine.getActionManager().getActionBuilder();
        for (String moduleClassName : configuration.getActionModules()) {
            AbstractActionModule module = (AbstractActionModule) reflection.createInstance(moduleClassName);
            actionBuilder.registerModule(module);
        }
    }

    /**
     * Creates a resource loading callback object.
     * @param game a game reference
     * @return a resource loading callback object
     */
    private IResourceLoadingCallback createResourceLoadingCallback(final AbstractGame game) {
        return new IResourceLoadingCallback() {

            @Override
            public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
                gameEngine.getLogger().error(getResourceInfoText("(%s / %s) Failed to load '%s' as '%s'", description, resIndex, resCount), cause);
                gameEngine.getEventBus().post(new ErrorOccurredEvent(new ResourceException(cause)));
            }

            @Override
            public void onSuccess(IResource resource, int resIndex, int resCount) {
                gameEngine.getLogger().debug(getResourceInfoText("(%s/%s) Resource '%s' loaded as '%s'", resource.getDescription(), resIndex, resCount));
            }

            @Override
            public void resourcesLoaded() {
                if (resourceLoadingCallback != null) {
                    gameEngine.getResourceManager().removeResourceLoadingCallback(resourceLoadingCallback);
                    resourceLoadingCallback = null;
                }
                gameEngine.getLogger().debug("All resources loaded successfully.");
                gameEngine.getSoundManager().loadResourcesToManager();
                game.executeOnReady();
            }

            private String getResourceInfoText(String infoFormat, ResourceDescription description, int resIndex, int resCount) {
                return StringUtility.format(infoFormat, resIndex + 1, resCount, description.getTargetPath(), description.getId());
            }
        };
    }
}
