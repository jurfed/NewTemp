package com.atsisa.gox.framework.action;

/**
 * Pauses sound with given id.
 */
public class PauseSoundAction extends SoundAction {

    @Override
    protected void execute() {
        soundManager.pause(getData().getSoundId());
    }
}
