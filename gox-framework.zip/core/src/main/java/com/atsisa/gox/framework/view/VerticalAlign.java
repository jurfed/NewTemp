package com.atsisa.gox.framework.view;

/**
 * Describes possible text vertical alignments.
 */
public enum VerticalAlign {
    TOP,
    MIDDLE,
    BOTTOM
}
