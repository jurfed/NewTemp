package com.atsisa.gox.framework.screen.event;

import com.atsisa.gox.framework.screen.Screen;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when the screen showed up.
 */
@Reflectable
public class ScreenShownEvent extends ScreenEvent {

    /**
     * Initializes a new instance of the {@link ScreenShownEvent} class.
     * @param screen {@link Screen}
     */
    public ScreenShownEvent(Screen screen) {
        super(screen);
    }
}
