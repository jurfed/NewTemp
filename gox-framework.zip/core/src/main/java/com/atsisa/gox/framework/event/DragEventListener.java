package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.view.InteractiveView;

/**
 * Drag event listener.
 */
public class DragEventListener implements IEventListener<InputEvent> {

    /**
     * Interactive view which drag should regard.
     */
    private InteractiveView interactiveView;

    /**
     * Offset vector.
     */
    //private Vector offsetVec;

    /**
     * Initializes a new instance of the DragEventListener.
     * @param interactiveView Interactive view which drag should regard
     */
    public DragEventListener(InteractiveView interactiveView) {
        this.interactiveView = interactiveView;
    }

    @Override
    public void onEvent(InputEvent event) {
        /*if (event.getType() == InputEventType.POINTER_DRAG
                || event.getType() == InputEventType.POINTER_START) {
            Pointer.Event pointerEvent = ((Pointer.Event) event.getInput());
            View eventSource = event.getSource();
            if (event.getType() == InputEventType.POINTER_START) {
                if (this.interactiveView.isSnapToCenter()) {
                    this.offsetVec = new Vector(eventSource.getOffsetWidth() / 2,
                                                eventSource.getOffsetHeight() / 2);
                } else {
                    this.offsetVec = new Vector(pointerEvent.x() - eventSource.getAbsoluteX(),
                                                pointerEvent.y() - eventSource.getAbsoluteY());
                }
            }
            float posX = -eventSource.getParent().getAbsoluteX() + pointerEvent.x() - this.offsetVec.x();
            float posY = -eventSource.getParent().getAbsoluteY() + pointerEvent.y() - this.offsetVec.y();
            eventSource.setX(posX);
            eventSource.setY(posY);
        } else if (event.getType() == InputEventType.POINTER_END) {
            this.offsetVec = null;
        }*/
    }
}
