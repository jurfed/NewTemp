package com.atsisa.gox.framework.eventbus;

import rx.Observer;

/**
 * An abstract observer which has its onError and onNext methods implemented.
 * @param <T> observable type
 */
public abstract class CompletedObserver<T> implements Observer<T> {

    /**
     * Does nothing.
     * @param error Occurred error.
     */
    @Override
    public void onError(Throwable error) {
        error.printStackTrace();
    }

    /**
     * Does nothing.
     * @param t observable type
     */
    @Override
    public void onNext(T t) {
    }
}
