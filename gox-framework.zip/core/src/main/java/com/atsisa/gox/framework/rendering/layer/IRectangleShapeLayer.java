package com.atsisa.gox.framework.rendering.layer;

/**
 * Exposes methods for rectangle shape layer.
 */
public interface IRectangleShapeLayer extends IShapeLayer {

    /**
     * Sets line (thickness) style.
     * @param lineWidth - float
     * @param color     - int
     * @param alpha     - int
     */
    void lineStyle(int lineWidth, int color, float alpha);

    /**
     * Begins fill.
     * @param color - float
     * @param alpha - float
     */
    void beginFill(int color, float alpha);

    /**
     * Draws rectangle.
     * @param x      - float
     * @param y      - float
     * @param width  - float
     * @param height - float
     */
    void drawRect(float x, float y, float width, float height);

    /**
     * Draws rounded rectangle.
     * @param x      - float
     * @param y      - float
     * @param width  - float
     * @param height - float
     * @param radius - float
     */
    void drawRoundedRect(float x, float y, float width, float height, float radius);

}
