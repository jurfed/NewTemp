package com.atsisa.gox.framework.view.spi;

import com.atsisa.gox.framework.view.View;

/**
 * The view filter.
 */
public interface IViewFilter {

    /**
     * Checks whether given view is valid.
     * @param view The view to check.
     * @return True if the view should be accepted by the filter, false otherwise.
     */
    boolean isValid(View view);
}
