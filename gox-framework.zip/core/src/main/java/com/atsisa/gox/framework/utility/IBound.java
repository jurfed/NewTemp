package com.atsisa.gox.framework.utility;

/**
 * Represents objects which are bound within
 * a rectangle shape.
 */
public interface IBound {

    /**
     * Gets boundaries of this object.
     * @return The boundaries of this object.
     */
    Rectangle getBoundaries();
}
