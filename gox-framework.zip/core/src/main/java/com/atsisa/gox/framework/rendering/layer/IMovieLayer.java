package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.resource.AbstractMovieResource;
import com.atsisa.gox.framework.view.IMovieCompleteListener;

/**
 * Exposes methods for movie layer.
 */
public interface IMovieLayer extends ILayer {

    /**
     * Returns original video width.
     * @return int
     */
    int getVideoWidth();

    /**
     * Returns original video height.
     * @return int
     */
    int getVideoHeight();

    /**
     * Removes on movie complete listener.
     * @return boolean
     */
    boolean removeOnCompleteListener();

    /**
     * Sets on movie complete listener.
     * @param movieCompleteListener - IMovieCompleteListener
     */
    void setOnCompletionListener(IMovieCompleteListener movieCompleteListener);

    /**
     * Plays video.
     */
    void play();

    /**
     * Stops playing video.
     */
    void stop();

    /**
     * Plays video.
     */
    void pause();

    /**
     * Sets volume value.
     * @param volume - float
     */
    void setVolume(float volume);

    /**
     * Sets loop value.
     * @param loop - boolean
     */
    void setLoop(boolean loop);

    /**
     * Sets movie resource.
     * @param movieResource - AbstractMovieResource
     */
    void setMovieFile(AbstractMovieResource movieResource);
}
