package com.atsisa.gox.framework.utility.logger;

import java.util.Date;

import com.atsisa.gox.framework.utility.StringUtility;
import com.google.inject.Inject;

/**
 * An abstract logger layers implementation on specific platform.
 */
public abstract class AbstractLogger implements ILogger {

    /**
     * Used when user didn't set logging level.
     */
    private static final LogLevel DEFAULT_LOG_LEVEL = LogLevel.TRACE;

    /**
     * Minimum logger level in hierarchy.
     */
    private LogLevel minLogLevel;

    /**
     * Default constructor which creates new platform logger instance and sets current logging level.
     */
    @Inject
    public AbstractLogger() {
        minLogLevel = DEFAULT_LOG_LEVEL;
    }

    @Override
    public LogLevel getLevel() {
        return minLogLevel;
    }

    @Override
    public void setLevel(LogLevel logLevel) {
        minLogLevel = logLevel;
    }

    /**
     * Returns logger message with formatting.
     * @param msg      message to display
     * @param logLevel message's logger logLevel
     * @return string formatted message
     */
    protected String format(String msg, LogLevel logLevel) {
        return StringUtility.format("%s|%s| - %s", new Date(), logLevel, msg);
    }

    /**
     * Checks if message could be displayed on given logging level.
     * @param desiredLogLevel logging level
     * @return true when level match to hierarchy
     */
    protected boolean isOnAllowedLevel(LogLevel desiredLogLevel) {
        return desiredLogLevel.ordinal() >= minLogLevel.ordinal();
    }
}
