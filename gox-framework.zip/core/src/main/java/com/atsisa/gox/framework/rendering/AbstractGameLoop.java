package com.atsisa.gox.framework.rendering;

/**
 * Abstract game loop, implements the basic behaviour of the game loop.
 */
public abstract class AbstractGameLoop implements IGameLoop {

    @Override
    public final void update() {
        updateModel();
        render();
    }

    /**
     * Updates game model.
     */
    protected abstract void updateModel();

    /**
     * Updates game renderer.
     */
    protected abstract void render();
}
