package com.atsisa.gox.framework.utility;

import java.util.List;

/**
 * Represents a line.
 */
public final class Line implements IPointsHolder {

    /**
     * Points.
     */
    private List<Point> points;

    /**
     * Initializes a new instance of {@link Line} class.
     * @param points A list of points.
     */
    public Line(List<Point> points) {
        setPoints(points);
    }

    @Override
    public Iterable<Point> getPoints() {
        return points;
    }

    @Override
    public void setPoints(List<Point> points) {
        if (points == null || points.size() < 2) {
            throw new IllegalArgumentException("Line must have at least two points");
        }
        this.points = points;
    }
}
