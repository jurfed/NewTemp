package com.atsisa.gox.framework.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Wraps the functionality of multiple {@link IMutator}
 * objects into one.
 */
public class MutatorSet {

    /**
     * A map of mutators.
     */
    private final Map<Class, List<IMutator>> mutators = new HashMap<>();

    /**
     * Adds a new mutator to the set.
     * @param mutator    The mutator to add
     * @param objectType The type of objects the mutator can handle.
     * @param <T>        The type of objects the mutator can handle.
     */
    public <T> void addMutator(IMutator<T> mutator, Class<T> objectType) {
        List<IMutator> mutatorsForType = mutators.get(objectType);
        if (mutatorsForType == null) {
            mutatorsForType = new ArrayList<>();
            mutators.put(objectType, mutatorsForType);
        }

        mutatorsForType.add(mutator);
    }

    /**
     * Mutates given object by applying a set of registered mutators.
     * @param object The object to mutate.
     * @param <T>    The type of object being mutated.
     * @return An object after a series of mutations.
     */
    public <T> T mutate(T object) {
        if (object == null) {
            return null;
        }

        T mutatedObject = object;
        List<IMutator> mutatorsForType = mutators.get(object.getClass());
        if (mutatorsForType != null) {
            for (IMutator mutator : mutatorsForType) {
                mutatedObject = (T) mutator.mutate(mutatedObject);
            }
        }

        return mutatedObject;
    }
}
