package com.atsisa.gox.framework.model;

import com.atsisa.gox.framework.model.property.IObservableProperty;

/**
 * Exposes methods for notifying that some object's property has changed.
 * @param <T> type of the observable property
 */
public interface IPropertyChangedListener<T> {

    /**
     * Called when some object's property has changed.
     * @param source   property container which contains the property
     * @param oldValue property's old value
     * @param newValue property's new value
     */
    void propertyChanged(IObservableProperty<T> source, T oldValue, T newValue);
}
