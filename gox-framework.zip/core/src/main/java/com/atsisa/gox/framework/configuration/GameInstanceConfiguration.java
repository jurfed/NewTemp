package com.atsisa.gox.framework.configuration;

import java.util.Map;
import java.util.Set;

/**
 * Preliminary version of GOXGameConfiguration model part.
 * Taken from old platform implementation.
 */
public class GameInstanceConfiguration {

    /**
     * Game instance identifier key.
     */
    public static final String PARAM_GAME_INSTANCE_ID = "gameInstanceId";

    /**
     * Game server address key.
     */
    public static final String PARAM_GAME_SERVER_ADDR = "gameServerAddress";

    /**
     * Parameter map.
     */
    private Map<String, String> params;

    /**
     * Initializes a new instance of the GetInitialParametersResponse class.
     * @param params parameters map
     */
    public GameInstanceConfiguration(Map<String, String> params) {
        this.params = params;
    }

    /**
     * Gets a particular parameter value.
     * @param paramName parameter name
     * @return parameter value, null if the parameter could not be found.
     */
    public String getParameter(String paramName) {
        return params.get(paramName);
    }

    /**
     * Gets a set of available parameter names.
     * @return a set of available parameter names
     */
    public Set<String> getParameterNames() {
        return params.keySet();
    }

    /**
     * Gets the game instance identifier.
     * @return the game instance identifier
     */
    public String getGameInstanceId() {
        return getParameter(PARAM_GAME_INSTANCE_ID);
    }

    /**
     * Gets the game server address.
     * @return the game server address
     */
    public String getGameServerAddress() {
        return getParameter(PARAM_GAME_SERVER_ADDR);
    }
}
