package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.MovieView;

/**
 * Base movie action class.
 */
public abstract class MovieAction extends Action<MovieActionData> {

    /**
     * View manager reference.
     */
    private final IViewManager viewManager;

    /**
     * Movie view.
     */
    protected MovieView movieView;

    /**
     * Creates a new instance of the MovieAction class.
     */
    public MovieAction() {
        viewManager = GameEngine.current().getViewManager();
    }

    /**
     * Creates a new instance of the MovieAction class.
     * @param logger      a logger reference
     * @param eventBus    an eventBus reference
     * @param viewManager a viewManager reference
     */
    public MovieAction(ILogger logger, IEventBus eventBus, IViewManager viewManager) {
        super(logger, eventBus);
        this.viewManager = viewManager;
    }

    @Override
    public Class<? extends MovieActionData> getActionDataType() {
        return MovieActionData.class;
    }

    @Override
    protected void grabData() {
        if (actionData != null) {
            String layoutId = actionData.getLayoutId();
            String movieId = actionData.getMovieId();
            movieView = viewManager.findViewById(layoutId, movieId);
        }
    }

    @Override
    protected void validate() throws ValidationException {
        if (movieView == null) {
            throw new ValidationException("MovieAction | validate | Can not find movie.");
        }
    }

    @Override
    public void reset() {
        movieView = null;
        super.reset();
    }
}
