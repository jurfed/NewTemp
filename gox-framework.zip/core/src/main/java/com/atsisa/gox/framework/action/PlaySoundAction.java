package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Plays sound with given id and parameters.
 */
public class PlaySoundAction extends Action<PlaySoundActionData> {

    /**
     * Reference to data about sound.
     */
    private PlaySoundActionData data;

    /**
     * Instance of sound manager.
     */
    private ISoundManager soundManager;

    /**
     * Reference to timeout used during blocking action.
     */
    private Timeout timeout;

    /**
     * Construct action with default sound manager.
     */
    public PlaySoundAction() {
        soundManager = GameEngine.current().getSoundManager();
    }

    /**
     * Initializes a new instance of the PlaySoundAction class.
     * @param logger       a logger reference
     * @param eventBus     an eventBus reference
     * @param soundManager a soundManager reference
     */
    public PlaySoundAction(ILogger logger, IEventBus eventBus, ISoundManager soundManager) {
        super(logger, eventBus);
        this.soundManager = soundManager;
    }

    @Override
    public Class<PlaySoundActionData> getActionDataType() {
        return PlaySoundActionData.class;
    }

    @Override
    protected void validate() throws ValidationException {
        if (data == null) {
            throw new ValidationException("Action data cannot be null.");
        }
    }

    @Override
    protected void grabData() {
        data = actionData;
        if (data.getSoundId() == null) {
            logger.warn("Sound id is not set.");
        }
    }

    @Override
    protected void execute() {
        if (data.isBlocking() != null && data.isBlocking()) {
            configureAndPlaySound(data.getSoundId());
            if (data.isLooping() != null && data.isLooping()) {
                logger.warn("Action is in blocking mode and sound is in loop!");
            } else {
                timeout = new Timeout(soundManager.length(data.getSoundId()), new TimeoutCallback() {

                    @Override
                    public void onTimeout() {
                        finish();
                    }
                });
                timeout.start();
            }
        } else {
            configureAndPlaySound(data.getSoundId());
            finish();
        }
    }

    @Override
    protected void terminate() {
        if (data != null) {
            soundManager.stop(data.getSoundId());
        }
        if (timeout != null) {
            timeout.clear();
        }
    }

    @Override
    protected void reset() {
        data = null;
    }

    /**
     * Configures and plays sound.
     * @param soundId id of the sound
     */
    private void configureAndPlaySound(String soundId) {
        Float volume = data.getVolume();
        if (volume != null) {
            soundManager.setVolume(soundId, volume);
        }
        Boolean looping = data.isLooping();
        if (looping != null) {
            soundManager.setLooping(soundId, looping);
        }
        if (!soundManager.resume(soundId)) {
            soundManager.play(soundId);
        }
    }
}
