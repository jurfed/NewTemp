package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.Reflectable;

/**
 * Provides data determining which screen to show and how.
 */
@XmlElement
@Reflectable
public class AnimationScreenActionData extends ScreenActionData {

    /**
     * View animation data, which describes how the view should be shown.
     */
    @XmlElement(name = "animation", type = TweenViewAnimationData.class)
    private TweenViewAnimationData viewAnimationData;

    /**
     * Gets view animation data, which describes how the view should be shown.
     * @return ViewAnimationData
     */
    public TweenViewAnimationData getViewAnimationData() {
        return viewAnimationData;
    }

    /**
     * Sets view animation data, which describes how the view should be shown.
     * @param viewAnimationData ViewAnimationData
     */
    public void setViewAnimationData(TweenViewAnimationData viewAnimationData) {
        this.viewAnimationData = viewAnimationData;
    }

}
