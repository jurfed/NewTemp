package com.atsisa.gox.framework.utility;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.utility.font.IFontRegistry;
import com.atsisa.gox.framework.utility.font.IFontRegistryFallback;
import com.google.inject.Inject;

/**
 * The font registry. Keeps track of the registered fonts.
 */
public class FontRegistry implements IFontRegistry {

    /**
     * The font registry fallback.
     */
    private final IFontRegistryFallback fontRegistryFallback;

    /**
     * Font resource map, maps the font ids to font resource objects.
     */
    private Map<String, IFontReference> fontResourceMap;

    /**
     * Initializes a new instance of the FontRegistry class.
     * @param fontRegistryFallback The font registry fallback.
     */
    @Inject
    public FontRegistry(IFontRegistryFallback fontRegistryFallback) {
        fontResourceMap = new HashMap<>();
        this.fontRegistryFallback = fontRegistryFallback;
    }

    @Override
    public IFontReference getFont(String fontName) {
        IFontReference fontReference = fontResourceMap.get(fontName);
        if (fontReference == null) {
            fontReference = fontRegistryFallback.getMissingFont(fontName);
            registerFont(fontReference);
        }
        return fontReference;
    }

    @Override
    public boolean registerFont(IFontReference font) {
        if (font == null) {
            return false;
        }
        if (!fontResourceMap.containsKey(font.getFontName())) {
            fontResourceMap.put(font.getFontName(), font);
            return true;
        }
        return false;
    }
}
