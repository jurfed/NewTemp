package com.atsisa.gox.framework.resource;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.event.ErrorEvent;
import com.atsisa.gox.framework.event.LoaderEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.AmbiguousConfigurationException;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.converter.ConversionException;
import com.atsisa.gox.framework.serialization.converter.ResourceDescriptionConverter;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.google.inject.Inject;

/**
 * Manager for resources. Loads list of resources from description list or XML, and manages them.
 */
public abstract class AbstractResourceManager implements IResourceManager, IResourceLoadingCallback {

    /**
     * List with loaded resources.
     */
    private final Map<String, IResource> loadedResources;

    /**
     * Resource description identifier for xml description files for resources.
     */
    public static final String RESOURCE_DESCRIPTION_FILE_ID = "_resources";

    /**
     * List of resources to load.
     */
    private List<IResource> toLoadResources;

    /**
     * Determines if we break loading when error occurs.
     */
    private boolean resumeOnError;

    /**
     * Reference to resource factory.
     */
    private IResourceFactory resourceFactory;

    /**
     * Supported resources formats types like html_hi.
     */
    private List<String> resourceFormats;

    /**
     * Parser reference.
     */
    private IParser parser;

    /**
     * Logger reference.
     */
    private ILogger logger;

    /**
     * Success counter.
     */
    private int successCount;

    /**
     * Resource loaded listeners list.
     */
    private Set<IResourceLoadingCallback> resourceLoadingCallbacks;

    /**
     * Resource description converter reference.
     */
    private ResourceDescriptionConverter resourceDescriptionConverter;

    /**
     * Event bus reference.
     */
    private IEventBus eventBus;

    /**
     * The resource resolver.
     */
    private ResourceReferenceResolver resourceReferenceResolver;

    /**
     * Initializes a new instance of the ResourceManager class using custom logger and resource factory.
     * @param resourceFactory          {@link IResourceFactory}
     * @param parser                   {@link IParser}
     * @param serializer               {@link IXmlSerializer}
     * @param logger                   {@link ILogger}
     * @param eventBus                 {@link IEventBus}
     * @param resourceLoadingCallbacks collection of a resource loading callbacks
     */
    @Inject
    public AbstractResourceManager(IResourceFactory resourceFactory, IParser parser, IXmlSerializer serializer, ILogger logger, IEventBus eventBus,
            Set<IResourceLoadingCallback> resourceLoadingCallbacks) {
        this(resourceFactory, parser, logger, new ResourceDescriptionConverter(serializer, logger), eventBus, resourceLoadingCallbacks);
    }

    /**
     * Initializes a new instance of the ResourceManager class using custom parameters.
     * @param resourceFactory              {@link IResourceFactory}
     * @param parser                       {@link IParser}
     * @param logger                       {@link ILogger}
     * @param resourceDescriptionConverter {@link ResourceDescriptionConverter}
     * @param eventBus                     {@link IEventBus}
     * @param resourceLoadingCallbacks     collection of a resource loading callbacks
     */
    public AbstractResourceManager(IResourceFactory resourceFactory, IParser parser, ILogger logger, ResourceDescriptionConverter resourceDescriptionConverter,
            IEventBus eventBus, Set<IResourceLoadingCallback> resourceLoadingCallbacks) {
        logger.trace("ResourceManager | ctor");
        resumeOnError = false;
        this.resourceFactory = resourceFactory;
        this.parser = parser;
        this.logger = logger;
        this.eventBus = eventBus;
        this.resourceDescriptionConverter = resourceDescriptionConverter;
        this.resourceLoadingCallbacks = new HashSet<>(resourceLoadingCallbacks);
        loadedResources = new LinkedHashMap<>();
        toLoadResources = new ArrayList<>();
        resourceFormats = new ArrayList<>();
        resourceReferenceResolver = new ResourceReferenceResolver(loadedResources);
        init();
    }

    @Override
    public <T extends IResourceReference> T find(String resourceReference) {
        return resourceReferenceResolver.resolve(resourceReference);
    }

    @Override
    @SuppressWarnings("unchecked")
    public IResource getResource(String resourceId) {
        return loadedResources.get(resourceId);
    }

    @Override
    public List<IResource> getAllResources(ResourceType resourceType) {
        List<IResource> foundResources = new ArrayList<>();
        for (IResource resource : loadedResources.values()) {
            if (resource.getResourceType() == resourceType) {
                foundResources.add(resource);
            }
        }
        return foundResources;
    }

    @Override
    public IResource getResource(String resourceId, ResourceType resourceType) {
        IResource resource = loadedResources.get(resourceId);
        if (resource != null && resource.getResourceType() == resourceType) {
            return resource;
        }
        return null;
    }

    @Override
    public List<String> getResourceFormats() {
        return resourceFormats;
    }

    @Override
    public void setResourceFormats(List<String> resourceFormats) {
        this.resourceFormats = resourceFormats;
    }

    @Override
    public void load(String resourceDescriptionPath) {
        logger.debug("ResourceManager | load | resourceDescription: %s", resourceDescriptionPath);
        successCount = 0;
        ResourceDescription resourceDescription = new ResourceDescription(RESOURCE_DESCRIPTION_FILE_ID, ResourceType.TEXT, resourceDescriptionPath);

        AbstractTextResource xmlResource = (AbstractTextResource) resourceFactory.createResource(resourceDescription);
        toLoadResources.add(xmlResource);

        xmlResource.load(new IResourceLoadingCallback() {

            @Override
            public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
                AbstractResourceManager.this.onError(description, 0, 1, cause);
            }

            @Override
            public void onSuccess(IResource resource, int resIndex, int resCount) {
                try {
                    List<ResourceDescription> resourceDescriptionList = deserializeResourceXmlFile((AbstractTextResource) resource);
                    validateResourcesFormats(resourceDescriptionList);
                    int amountOfResources = resourceDescriptionList.size() + 1;
                    for (ResourceDescription resourceDescription : resourceDescriptionList) {
                        if (resourceDescription.getLoadRuntime()) {
                            amountOfResources--;
                        }
                    }
                    AbstractResourceManager.this.onSuccess(resource, 0, amountOfResources);
                    successCount++;
                    load(resourceDescriptionList, 1, false);
                } catch (ParseException e) {
                    AbstractResourceManager.this.onError(resource.getDescription(), 0, 1, e);
                }
            }

            @Override
            public void resourcesLoaded() {
                AbstractResourceManager.this.resourcesLoaded();
            }
        });
    }

    @Override
    public void load(List<ResourceDescription> resourceDescriptionList) {
        load(resourceDescriptionList, true);
    }

    @Override
    public void load(List<ResourceDescription> resourceDescriptionList, boolean loadMarkedAsRuntime) {
        successCount = 0;
        load(resourceDescriptionList, 0, loadMarkedAsRuntime);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ResourceDescription> deserializeResourceXmlFile(IResource resource) throws ParseException {
        IParsableObject parsableObject = parser.parse(((AbstractTextResource) resource).getText());
        try {
            return (List<ResourceDescription>) resourceDescriptionConverter.convertFrom(null, parsableObject);
        } catch (ConversionException e) {
            throw new ParseException("Unable to parse resource description.", e);
        }
    }

    /**
     * Removes resources, which are unused, and checks whether configuration do not double.
     * @param resourceDescriptionList List of resources to validate
     */
    public void validateResourcesFormats(List<ResourceDescription> resourceDescriptionList) {
        Iterator iterator = resourceDescriptionList.iterator();
        ResourceDescription resourceDescription;
        while (iterator.hasNext()) {
            resourceDescription = (ResourceDescription) iterator.next();
            if (!setPathToResource(resourceDescription)) {
                iterator.remove();
            }
        }
    }

    /**
     * Sets proper path to resource.
     * @param resourceDescription resource for which the path should be specified
     * @return true if path is set correctly
     * @throws AmbiguousConfigurationException when fails
     */
    @Override
    public boolean setPathToResource(ResourceDescription resourceDescription) {
        List<String> resourceFormatList = resourceDescription.getFormatList();
        /* Common elements are left */
        if (resourceFormats != null) {
            resourceFormatList.retainAll(resourceFormats);
        }
        if (resourceFormatList.size() >= 2) {
            throw new AmbiguousConfigurationException(
                    StringUtility.format("Ambiguous configuration for %s. Two configurations match.", resourceDescription.getId()));
        } else if (resourceFormatList.isEmpty() && (resourceDescription.getFormatList() == null || resourceDescription.getFormatList().isEmpty()
                || resourceDescription.getFormatList().contains("default"))) {
            resourceDescription.setPathToResource("default");
            return true;
        } else if (resourceFormatList.size() == 1) {
            resourceDescription.setPathToResource(resourceFormatList.get(0));
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isResumeOnError() {
        return resumeOnError;
    }

    @Override
    public void setResumeOnError(boolean resumeOnError) {
        this.resumeOnError = resumeOnError;
    }

    @Override
    public int getItemsTotal() {
        return toLoadResources.size();
    }

    @Override
    public int getItemsLoaded() {
        return successCount;
    }

    @Override
    public void unload(String resourceId) {
        unload(resourceId, true);
    }

    @Override
    public void unload(String resourceId, boolean removeFromManager) {
        logger.debug("ResourceManager | unload | resourceId: %s", resourceId);
        IResource resource = loadedResources.remove(resourceId);
        if (resource != null) {
            try {
                resource.unload();
            } catch (Exception ex) {
                logger.error("Could not unload resource", ex);
                throw ex;
            }
        }
    }

    @Override
    public void unloadAll() {
        logger.debug("ResourceManager | unloadAll");
        for (IResource resource : loadedResources.values()) {
            resource.unload();
        }
        loadedResources.clear();
    }

    @Override
    public void dispose() {
        unloadAll();
    }

    @Override
    public void addResourceLoadingCallback(IResourceLoadingCallback resourcesLoadedListener) {
        if (!resourceLoadingCallbacks.contains(resourcesLoadedListener)) {
            resourceLoadingCallbacks.add(resourcesLoadedListener);
        }
    }

    @Override
    public void removeResourceLoadingCallback(IResourceLoadingCallback resourcesLoadedListener) {
        if (resourceLoadingCallbacks.contains(resourcesLoadedListener)) {
            resourceLoadingCallbacks.remove(resourcesLoadedListener);
        }
    }

    /**
     * Initialize necessary variables.
     */
    protected void init() {
    }

    /**
     * Adds specific resource to list.
     * @param resource - IResource
     * @return true if the resource was added, false otherwise.
     */
    protected boolean addResource(IResource resource) {
        IResource existingResource = loadedResources.put(resource.getId(), resource);
        if (existingResource != null) {
            logger.warn("Duplicated resource entry: " + resource.getId());
            loadedResources.put(resource.getId(), resource);
            return false;
        }
        return true;
    }

    @Override
    public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
        List<IResourceLoadingCallback> callbackList = new ArrayList<>(resourceLoadingCallbacks);
        for (IResourceLoadingCallback callback : callbackList) {
            callback.onError(description, resIndex, resCount, cause);
        }
        ErrorEvent errorEvent = new ErrorEvent(cause);
        eventBus.post(errorEvent);
    }

    @Override
    public void onSuccess(IResource resource, int resIndex, int resCount) {
        List<IResourceLoadingCallback> callbackList = new ArrayList<>(resourceLoadingCallbacks);
        for (IResourceLoadingCallback callback : callbackList) {
            callback.onSuccess(resource, resIndex, resCount);
        }
        LoaderEvent loaderEvent = new LoaderEvent("Loading Assets", this);
        eventBus.post(loaderEvent);
    }

    @Override
    public void resourcesLoaded() {
        List<IResourceLoadingCallback> callbacks = new ArrayList<>(resourceLoadingCallbacks);
        for (IResourceLoadingCallback callback : callbacks) {
            callback.resourcesLoaded();
        }
    }

    /**
     * Gets resource description converter.
     * @return resource description converter
     */
    public ResourceDescriptionConverter getResourceDescriptionConverter() {
        return resourceDescriptionConverter;
    }

    /**
     * Sets resource description converter.
     * @param resourceDescriptionConverter - resource description converter
     */
    public void setResourceDescriptionConverter(ResourceDescriptionConverter resourceDescriptionConverter) {
        this.resourceDescriptionConverter = resourceDescriptionConverter;
    }

    /**
     * Returns resource factory.
     * @return IResourceFactory specific for each platform.
     */
    @Override
    public IResourceFactory getResourceFactory() {
        return resourceFactory;
    }

    /**
     * Returns logger reference.
     * @return ILogger
     */
    protected ILogger getLogger() {
        return logger;
    }

    /**
     * Loads the resources using resource description list. It loads at the beginning first resource, next resources are
     * loaded, when actual one is processed.
     * @param resourceDescriptionList resource description list
     * @param offset                  resource offset
     * @param loadMarkedAsRuntime     - a boolean value that indicates whether resources marked as load runtime should be also loaded
     */
    protected void load(List<ResourceDescription> resourceDescriptionList, int offset, boolean loadMarkedAsRuntime) {
        for (ResourceDescription resourceDescription : resourceDescriptionList) {
            try {
                IResource loadedResource = resourceFactory.createResource(resourceDescription);
                if (!resourceDescription.getLoadRuntime() || loadMarkedAsRuntime) {
                    toLoadResources.add(loadedResource);
                } else {
                    addResource(loadedResource);
                }
            } catch (Exception e) {
                logger.error(StringUtility.format("Resource %s is unavailable", resourceDescription.getId()), e);
                return;
            }
        }

        /* New callback is created, which manages loading resources sequentially */
        AbstractResourceManager.ResourceCallback innerCallback = createResourceCallback(offset, toLoadResources.size());
        for (int i = offset; i < toLoadResources.size(); i++) {
            toLoadResources.get(i).load(innerCallback);
        }
    }

    /**
     * Creates resource callback.
     * @param offset    - int
     * @param queueSize - int
     * @return ResourceCallback
     */
    protected ResourceCallback createResourceCallback(int offset, int queueSize) {
        return new ResourceCallback(offset, queueSize);
    }

    /**
     * Resources are loaded sequentially, every next resource is loaded after invoking OnSuccess or OnError methods.
     */
    protected class ResourceCallback implements IResourceLoadingCallback {

        /**
         * Resource counter.
         */
        private int resourceCounter;

        /**
         * Size of the queue.
         */
        private int resourceQueueSize;

        /**
         * Callback class for every loaded resource.
         * @param listOffset        - list offset
         * @param resourceQueueSize - size fo the resource queue
         */
        ResourceCallback(int listOffset, int resourceQueueSize) {
            resourceCounter = listOffset;
            this.resourceQueueSize = resourceQueueSize;
        }

        @Override
        public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
            AbstractResourceManager.this.onError(description, resourceCounter, resourceQueueSize, cause);
            resourceCounter++;
        }

        @Override
        public void onSuccess(IResource resource, int resIndex, int resCount) {
            addResource(resource);
            AbstractResourceManager.this.onSuccess(resource, resourceCounter, resourceQueueSize);
            successCount++;
            resourceCounter++;
            if (resourceQueueSize == successCount) {
                resourcesLoaded();
            }
        }

        @Override
        public void resourcesLoaded() {
            AbstractResourceManager.this.resourcesLoaded();
        }
    }
}
