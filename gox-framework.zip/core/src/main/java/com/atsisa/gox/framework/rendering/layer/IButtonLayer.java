package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.utility.font.IFontReference;
import com.atsisa.gox.framework.view.ButtonView;

/**
 * Exposes methods for button layer.
 */
public interface IButtonLayer<T> extends IImageLayer {

    /**
     * Sets label text.
     * @param label {@link String}
     */
    void setLabel(String label);

    /**
     * Sets label format.
     * @param labelFormat {@link ButtonView.LabelFormat}
     */
    void setLabelFormat(ButtonView.LabelFormat labelFormat);

    /**
     * Sets font reference for button label.
     * @param fontReference {@link IFontReference}
     */
    void setLabelFontReference(IFontReference<T> fontReference);
}
