package com.atsisa.gox.framework;

/**
 * Generic platform interface. New platforms are defined as implementations of this interface.
 */
public interface IPlatform {

    /**
     * Platform type.
     */
    enum Type {

        /**
         * Java platform.
         */
        JAVA,

        /**
         * HTML platform.
         */
        HTML,

        /**
         * Android platform.
         */
        ANDROID,

        /**
         * iOS platform.
         */
        IOS
    }

    /**
     * Gets platform specific type.
     * @return Type
     */
    Type getType();

    /**
     * Invokes specific runnable. Due to technical aspects not all platform implementation (i.e. HtmlPlatform)
     * may support asynchronous execution. In such case either exception should be raised or the action may be
     * executed in a synchronous manner.
     * @param runnable runnable
     */
    void invokeLater(Runnable runnable);

    /**
     * Invokes specific runnable in a rendering thread. Due to technical aspects not all platform implementation (i.e. HtmlPlatform)
     * may support asynchronous execution. In such case either exception should be raised or the action may be
     * executed in a synchronous manner.
     * @param runnable runnable
     */
    void invokeLaterRendering(Runnable runnable);

}
