package com.atsisa.gox.framework.view;

import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the core view types which could be created declaratively using XML.
 */
@Reflect_Mini
public class CoreViewModule extends AbstractViewModule {

    /**
     * Core views module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/framework/view";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerView(View.class);
        registerView(ViewGroup.class);
        registerView(ImageView.class);
        registerView(ButtonView.class);
        registerView(KeyframeAnimationView.class);
        registerView(ProgressBarView.class);
        registerView(TextView.class);
        registerView(RectangleShapeView.class);
        registerView(LineShapeView.class);
        registerView(ParticleView.class);
        registerView(MovieView.class);
    }
}
