package com.atsisa.gox.framework.eventbus;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IPlatform;

import rx.Observable;
import rx.Subscriber;

/**
 * Decorator for Observable.OnSubscribe to run notifications on them in main rendering thread.
 * @param <T> type of OnSubscribe
 */
public class UIDispatcherOnSubscribe<T> implements Observable.OnSubscribe<T> {

    /**
     * {@link Subscriber} instance.
     */
    private final Observable.OnSubscribe<T> onSubscribe;

    /**
     * {@link IPlatform} reference.
     */
    private final IPlatform platform;

    /**
     * Initializes a new instance of the {@link UIDispatcherOnSubscribe} class.
     * @param onSubscribe {@link Observable.OnSubscribe}
     */
    public UIDispatcherOnSubscribe(Observable.OnSubscribe<T> onSubscribe) {
        this.onSubscribe = onSubscribe;
        platform = GameEngine.current().getPlatform();
    }

    @Override
    public void call(Subscriber<? super T> subscriber) {
        platform.invokeLaterRendering(() -> this.onSubscribe.call(subscriber));
    }
}
