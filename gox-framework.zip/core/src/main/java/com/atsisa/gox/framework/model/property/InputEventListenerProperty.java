package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.view.InteractiveView;

/**
 * <p>
 * Input event listener property. Handles events triggered by InteractiveView objects and propagates event data to an
 * event listener which could be injected using set setMethod.
 * </p>
 * The difference between {@link EventListenerProperty} and {@link InputEventListenerProperty} is that
 * {@link InputEventListenerProperty} object propagates only subset of event types given as constructor's parameter
 * 'eventTypes'.
 */
public class InputEventListenerProperty extends EventListenerProperty {

    /**
     * Initializes a new instance of the {@link InputEventListenerProperty}.
     * @param view       corresponding interactive view object reference
     * @param eventTypes event types which should be propagated to inner listener
     */
    public InputEventListenerProperty(InteractiveView view, InputEventType... eventTypes) {
        super(view, new InputEventSelector(eventTypes));
    }
}
