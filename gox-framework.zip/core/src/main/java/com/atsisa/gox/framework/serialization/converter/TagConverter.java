package com.atsisa.gox.framework.serialization.converter;

/**
 * Converts space-separated values to a list of strings.
 */
public class TagConverter extends SeparatedItemsConverter {

    /**
     * Initializes a new instance of the {@link TagConverter} class.
     */
    public TagConverter() {
        super(" ");
    }
}
