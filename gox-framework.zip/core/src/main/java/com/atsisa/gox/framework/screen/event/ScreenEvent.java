package com.atsisa.gox.framework.screen.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.framework.screen.Screen;
import com.gwtent.reflection.client.Reflectable;

/**
 * Used as base class for events associated with screens.
 */
@Reflectable
public abstract class ScreenEvent extends AbstractEvent {

    /**
     * Screen reference.
     */
    private Screen screen;

    /**
     * Initializes a new instance of the ScreenEvent class.
     * @param screen {@link Screen}
     */
    public ScreenEvent(Screen screen) {
        this.screen = screen;
    }

    /**
     * Gets the screen.
     * @return the screen
     */
    public Screen getScreen() {
        return screen;
    }
}
