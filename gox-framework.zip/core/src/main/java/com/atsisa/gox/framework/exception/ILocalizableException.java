package com.atsisa.gox.framework.exception;

/**
 * Define localizable exception with message for translalation.
 */
public interface ILocalizableException {

    /**
     * Gets localizable message for translalation.
     * @return localizable message for translalation.
     */
    String getLocalizableMessage();
}
