package com.atsisa.gox.framework.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Aggregates multiple {@code Throwable}s that may be thrown in the process of a task's execution.
 */
public class AggregateException extends Exception {

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * The default message.
     */
    private static final String DEFAULT_MESSAGE = "There were multiple errors.";

    /**
     * The inner throwables.
     */
    private List<Throwable> innerThrowables;

    /**
     * Constructs a new {@code AggregateException} with the current stack trace, the specified detail
     * message and with references to the inner throwables that are the cause of this exception.
     * @param detailMessage   The detail message for this exception.
     * @param innerThrowables The exceptions that are the cause of the current exception.
     */
    public AggregateException(String detailMessage, Throwable[] innerThrowables) {
        this(detailMessage, Arrays.asList(innerThrowables));
    }

    /**
     * Constructs a new {@code AggregateException} with the current stack trace, the specified detail
     * message and with references to the inner throwables that are the cause of this exception.
     * @param detailMessage   The detail message for this exception.
     * @param innerThrowables The exceptions that are the cause of the current exception.
     */
    public AggregateException(String detailMessage, List<? extends Throwable> innerThrowables) {
        super(detailMessage, innerThrowables != null && !innerThrowables.isEmpty() ? innerThrowables.get(0) : null);
        if (innerThrowables != null) {
            this.innerThrowables = new ArrayList<>(innerThrowables);
        }
    }

    /**
     * Constructs a new {@code AggregateException} with the current stack trace and with references to
     * the inner throwables that are the cause of this exception.
     * @param innerThrowables The exceptions that are the cause of the current exception.
     */
    public AggregateException(List<? extends Throwable> innerThrowables) {
        this(DEFAULT_MESSAGE, innerThrowables);
    }

    /**
     * Gets a read-only {@link List} of the {@link Throwable} instances that caused the current exception.
     * @return a read-only {@link List} of the {@link Throwable} instances that caused the current exception
     */
    public List<Throwable> getInnerThrowables() {
        return innerThrowables;
    }
}
