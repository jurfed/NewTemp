package com.atsisa.gox.framework.model.property.primitive;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservablePropertyContainer;

/**
 * A container class for primitive explicitly typed properties.
 */
public class FloatObservableProperty extends ObservablePropertyContainer implements IObservableProperty {

    /**
     * Mutable boxing type for float primitive holding old value.
     */
    private PrimitiveFloatBox oldValueBox = new PrimitiveFloatBox(0f);

    /**
     * Mutable boxing type for float primitive holding current value.
     */
    private PrimitiveFloatBox newValueBox = new PrimitiveFloatBox(0f);

    /**
     * The value.
     */
    private float value;

    /**
     * The oldValue.
     */
    private float oldValue = Float.MIN_VALUE;

    /**
     * Default value.
     */
    private float defaultValue;

    @Override
    public boolean hasDefaultValue() {
        return value == defaultValue;
    }

    @Override
    public Object getDefaultValue() {
        return defaultValue;
    }

    @Override
    public Class getType() {
        return float.class;
    }

    @Override
    public Object get() {
        return value;
    }

    @Override
    public boolean set(Object value) {
        return set((float) value);
    }

    public float getPrimitive() {
        return value;
    }

    @Override
    public void setDefaultValue(Object defaultValue) {
        this.defaultValue = (float) defaultValue;
    }

    /**
     * Sets the property value and notifies listeners about changes. Notification will only be triggered if the actual
     * value has changed
     * @param newValue new property value
     * @return true if a new value differs from the current value, false otherwise
     */
    public boolean set(float newValue) {
        if (value != newValue) {
            oldValue = value;
            oldValueBox.setValue(oldValue);
            value = newValue;
            newValueBox.setValue(value);
            notifyPropertyChanged(this, oldValueBox, newValueBox);
            return true;
        }
        return false;
    }

}
