package com.atsisa.gox.framework.utility.localization;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.atsisa.gox.framework.event.RegisterTranslationCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;

import rx.Observable;

/**
 * Represents factory of cached languages.
 */
public class CachedTranslationProvider implements ITranslationProvider {

    /**
     * Factory of non-cached languages.
     */
    private final ITranslationProvider translationProvider;

    /**
     * Key-Value cache.
     */
    private final ConcurrentHashMap<String, Observable<Map<String, String>>> cache;

    /**
     * Initializes a new instance of the {@link CachedTranslationProvider} class.
     * @param translationProvider {@link ITranslationProvider}
     * @param eventBus            {@link IEventBus}
     */
    public CachedTranslationProvider(ITranslationProvider translationProvider, IEventBus eventBus) {
        this.translationProvider = translationProvider;
        cache = new ConcurrentHashMap<>();
        eventBus.register(new RegisterTranslationCommandObserver(), RegisterTranslationCommand.class);
    }

    @Override
    public Observable<Map<String, String>> getTranslation(String languageCode) {
        Observable<Map<String, String>> observable = cache.computeIfAbsent(languageCode, key -> translationProvider.getTranslation(key).cache());
        observable.subscribe(success -> {
        }, error -> cache.remove(languageCode));
        return observable;
    }

    private class RegisterTranslationCommandObserver extends NextObserver<RegisterTranslationCommand> {

        @Override
        public void onNext(RegisterTranslationCommand registerTranslationCommand) {
            cache.put(registerTranslationCommand.getLanguageCode(), Observable.just(registerTranslationCommand.getTranslation()).cache());
        }
    }
}
