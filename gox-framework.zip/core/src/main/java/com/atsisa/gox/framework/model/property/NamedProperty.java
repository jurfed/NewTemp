package com.atsisa.gox.framework.model.property;

/**
 * Named property class.
 * @param <T> type of the property's value
 */
public class NamedProperty<T> extends ObservableProperty<T> {

    /**
     * The name of the property.
     */
    private String name;

    /**
     * Initializes a new instance of the NamedProperty class.
     * @param type property's value type
     * @param name the name of the property
     */
    public NamedProperty(Class<T> type, String name) {
        super(type);
        assert name != null;
        this.name = name;
    }

    /**
     * Initializes a new instance of the NamedProperty class.
     * @param type         property's value type
     * @param name         the name of the property
     * @param defaultValue property's default value
     */
    public NamedProperty(Class<T> type, String name, T defaultValue) {
        super(type, defaultValue);
        assert name != null;
        this.name = name;
    }

    /**
     * Gets the name of the property.
     * @return the name of the property
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the property.
     * @param name a property name
     */
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "NamedProperty{" + "name='" + name + '\'' + ", type='" + getType() + '\'' + '}';
    }
}
