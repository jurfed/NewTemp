package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * An abstract class which is a helper action for any other actions which are needs information about the state.
 */
public abstract class StateAction extends SyncAction<StateActionData> {

    /**
     * Initializes a new instance of the {@link StateAction} class.
     */
    public StateAction() {
    }

    /**
     * Initializes a new instance of the {@link StateAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public StateAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void validate() throws IllegalStateException {
        if (actionData == null || StringUtility.isNullOrEmpty(actionData.getState())) {
            throw new IllegalStateException("The state property must be set");
        }
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return StateActionData.class;
    }
}
