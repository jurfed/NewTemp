package com.atsisa.gox.framework.resource;

/**
 * Provider for {@link ConfigResource} type.
 */
public class ConfigResourceProvider implements IResourceProvider {

    @Override
    public boolean canCreate(ResourceType resourceType) {
        return resourceType == ResourceType.CONFIG;
    }

    @Override
    public IResource createResource(ResourceDescription resourceDescription) {
        return new ConfigResource(resourceDescription);
    }
}
