package com.atsisa.gox.framework.model;

/**
 * Gives abilities to reset a component to its initial state.
 */
public interface IResetable {

    /**
     * Resets this instance to its original state.
     */
    void reset();
}
