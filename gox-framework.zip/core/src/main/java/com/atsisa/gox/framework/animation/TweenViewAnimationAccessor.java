package com.atsisa.gox.framework.animation;

import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.framework.view.View;

import aurelienribon.tweenengine.TweenAccessor;

/**
 * Defines how to access view object properties for animation purposes.
 */
public class TweenViewAnimationAccessor implements TweenAccessor<View> {

    /**
     * Class level instances of local variables.
     */
    private final LocalVariables lv = new LocalVariables();

    /**
     * How much attributes we can pass to Tween.target()
     */
    public static final int TWEEN_ATTRIBUTES_LIMIT = 8;

    /**
     * Gets initial values from target view.
     * @param target       - view object to move
     * @param tweenType    - defines which view property will be used
     * @param returnValues - array with target object starting values
     * @return number of view properties to change
     */
    @Override
    public int getValues(View target, int tweenType, float[] returnValues) {
        lv.retGetValues = 1;
        lv.posGetValues = 0;
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.X)) {
            returnValues[lv.posGetValues++] = target.getX();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.Y)) {
            returnValues[lv.posGetValues++] = target.getY();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.WIDTH)) {
            returnValues[lv.posGetValues++] = target.getWidth();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.HEIGHT)) {
            returnValues[lv.posGetValues++] = target.getHeight();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_X)) {
            returnValues[lv.posGetValues++] = target.getScaleX();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_Y)) {
            returnValues[lv.posGetValues++] = target.getScaleY();
            lv.retGetValues++;
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.ALPHA)) {
            returnValues[lv.posGetValues++] = target.getAlpha();
            lv.retGetValues++;
        }
        return lv.retGetValues;
    }

    /**
     * Sets target view properties. Invoked in every animations frame
     * @param target    - view object to move
     * @param tweenType - defines which view property will be used
     * @param newValues - array with new target properties values
     */
    @Override
    public void setValues(View target, int tweenType, float[] newValues) {
        lv.posSetValues = 0;
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.X)) {
            target.setX(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.Y)) {
            target.setY(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.WIDTH)) {
            target.setWidth(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.HEIGHT)) {
            target.setHeight(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_X)) {
            target.setScaleX(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.SCALE_Y)) {
            target.setScaleY(newValues[lv.posSetValues++]);
        }
        if (BitUtility.isSet(tweenType, View.ViewPropertyName.ALPHA)) {
            target.setAlpha(newValues[lv.posSetValues++]);
        }
    }

    /**
     * Holder for instances of local variables used in the {@link TweenViewAnimationAccessor} methods.
     */
    private class LocalVariables {

        private int retGetValues;

        private int posGetValues;

        private int posSetValues;
    }
}
