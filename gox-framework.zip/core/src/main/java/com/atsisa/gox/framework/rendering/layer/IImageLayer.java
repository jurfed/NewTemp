package com.atsisa.gox.framework.rendering.layer;

import com.atsisa.gox.framework.resource.IImageObjectWrapper;
import com.atsisa.gox.framework.view.spi.ITransform;

/**
 * Exposes methods for image layer.
 */
public interface IImageLayer extends ILayer {

    /**
     * Sets image.
     * @param imageObjectWrapper - IImageObjectWrapper
     */
    void setImage(IImageObjectWrapper imageObjectWrapper);

    /**
     * Sets a boolean value that indicates whether this image will be smoothed or not.
     * @param smoothing - boolean
     */
    void setSmoothing(boolean smoothing);

    /**
     * Sets a transform information about modifiers for vertices.
     * @param transform {@link ITransform}
     */
    void setTransform(ITransform transform);

}
