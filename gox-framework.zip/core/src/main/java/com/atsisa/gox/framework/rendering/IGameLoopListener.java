package com.atsisa.gox.framework.rendering;

/**
 * Game loop listener.
 */
public interface IGameLoopListener {

    /**
     * Called each time in game loop.
     * @param intervalMicroseconds - interval in microseconds
     */
    void onUpdate(float intervalMicroseconds);

}
