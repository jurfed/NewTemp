package com.atsisa.gox.framework.model.property;

import com.atsisa.gox.framework.event.IEvent;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;

/**
 * Input event selector class.
 * Filters only selected subset of input event types.
 */
public class InputEventSelector implements IEventSelector {

    /**
     * An array of event types which should be propagated.
     */
    private final InputEventType[] eventTypes;

    /**
     * Initializes a new instance of the input event selector.
     * @param eventTypes type of events which should be considered
     */
    public InputEventSelector(InputEventType... eventTypes) {
        this.eventTypes = eventTypes;
    }

    /**
     * Checks if the event given as parameter is an instance of the {@link InputEvent} class
     * and if its type matches the filter passed in the eventTypes constructor parameter.
     * @param event event to check
     * @return true if the event meets described requirements, false otherwise
     */
    @Override
    public boolean eventMeetsCriteria(IEvent event) {
        if (event instanceof InputEvent) {
            InputEventType currentEventType = ((InputEvent) event).getType();
            if (eventTypes != null && eventTypes.length > 0) {
                for (InputEventType eventType : eventTypes) {
                    if (eventType == currentEventType) {
                        return true;
                    }
                }
                return false;
            }
            return true;
        }
        return false;
    }
}
