package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.screen.event.ScreenEvent;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Action used as a base class to interact with screens using commands/events.
 */
public abstract class ScreenAction<T extends ScreenEvent> extends WaitForEventAction<T> {

    /**
     * The screen id.
     */
    private String screenId;

    /**
     * Initializes a new instance of the {@link ShowScreenAction} class.
     */
    protected ScreenAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowScreenAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    protected ScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return ScreenActionData.class;
    }

    @Override
    protected void grabData() {
        screenId = ((ScreenActionData) actionData).getScreenId();
    }

    @Override
    protected void validate() throws ValidationException {
        if (StringUtility.isNullOrEmpty(screenId)) {
            throw new ValidationException("Screen id cannot be null.");
        }
    }

    @Override
    protected void handleEvent(T event) {
        if (screenId.equals(event.getScreen().getLayoutId())) {
            super.handleEvent(event);
        }
    }

    @Override
    protected void reset() {
        super.reset();
        screenId = null;
    }

    /**
     * Gets the screen id.
     * @return the screen id
     */
    public String getScreenId() {
        return screenId;
    }
}
