package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Stops all sounds action.
 */
public class StopAllSoundsAction extends SyncAction {

    /**
     * Reference to sound manager.
     */
    private final ISoundManager soundManager;

    /**
     * Constructs action with default sound manager.
     */
    public StopAllSoundsAction() {
        soundManager = GameEngine.current().getSoundManager();
    }

    /**
     * Constructs action with sound manager passed as parameter.
     * @param logger       a logger reference.
     * @param eventBus     an eventBus reference.
     * @param soundManager a soundManager reference.
     */
    public StopAllSoundsAction(ILogger logger, IEventBus eventBus, ISoundManager soundManager) {
        super(logger, eventBus);
        this.soundManager = soundManager;
    }

    @Override
    protected void execute() {
        soundManager.stopAllSounds();
    }

}
