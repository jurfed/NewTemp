package com.atsisa.gox.framework.infrastructure;

import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.resource.ConfigResource;

/**
 * Exposes methods for creating and reading a merged configuration from text resources.
 */
public interface IConfigurationProvider {

    /**
     * Populates current configuration with data from given text.
     * @param text - text to deserialize
     * @return true if operation succeeded, false otherwise
     */
    boolean populate(String text);

    /**
     * Populates current configuration with data contained in given config resource.
     * @param configResource - text resource to deserialize
     * @return true if operation succeeded, false otherwise
     */
    boolean populate(ConfigResource configResource);

    /**
     * Gets the current configuration object.
     * @return current configuration object
     */
    IConfiguration getConfiguration();
}
