package com.atsisa.gox.framework.utility;

/**
 * Represents an object which can be captioned.
 */
public interface ICaption {

    /**
     * Sets the text.
     * @param text The text.
     */
    void setText(String text);

    /**
     * Gets the text.
     * @return The text.
     */
    String getText();
}
