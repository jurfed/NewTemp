package com.atsisa.gox.framework.rendering;

/**
 * Game loop interfaces. Exposes methods for game loop.
 */
public interface IGameLoop {

    /**
     * Called when this game loop should be updated.
     */
    void update();

    /**
     * Returns current FPS counter.
     * @return int
     */
    int getFPS();

}
