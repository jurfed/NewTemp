package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.ShowScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

/**
 * Shows the screen by adding its layout to the stage with fade in animation.
 */
@Reflectable
public class FadeInScreenAction extends ScreenAction<ScreenShownEvent> {

    /**
     * Time span for fade animation.
     */
    private Integer timeSpan;

    /**
     * Initializes a new instance of the {@link FadeInScreenAction} class.
     */
    public FadeInScreenAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link FadeInScreenAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public FadeInScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return FadeScreenActionData.class;
    }

    @Override
    protected Class<ScreenShownEvent> getEventClass() {
        return ScreenShownEvent.class;
    }

    @Override
    protected void grabData() {
        super.grabData();
        timeSpan = ((FadeScreenActionData) actionData).getTimeSpan();
    }

    @Override
    protected void execute() {
        super.execute();
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setDestinationAlpha(1f);
        animationData.setTimeSpan(timeSpan == null ? FadeScreenActionData.DEFAULT_TIME_SPAN : timeSpan);
        eventBus.post(new ShowScreenCommand(getScreenId(), animationData));
    }

}
