package com.atsisa.gox.framework.rendering;

/**
 * Game loop delegate.
 */
public class GameLoopDelegate implements IGameLoop {

    /**
     * Current game loop reference.
     */
    private IGameLoop currentGameLoop;

    /**
     * Initializes a new instance of the GameLoopDelegate class.
     * @param gameLoop - IGameLoop
     */
    public GameLoopDelegate(IGameLoop gameLoop) {
        currentGameLoop = gameLoop;
    }

    /**
     * Sets current game loop.
     * @param currentGameLoop - IGameLoop
     */
    public void setCurrentGameLoop(IGameLoop currentGameLoop) {
        this.currentGameLoop = currentGameLoop;
    }

    /**
     * Delegates update to current game loop.
     */
    @Override
    public void update() {
        currentGameLoop.update();
    }

    @Override
    public int getFPS() {
        return currentGameLoop.getFPS();
    }

}
