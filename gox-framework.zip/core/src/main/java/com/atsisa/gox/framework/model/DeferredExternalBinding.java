package com.atsisa.gox.framework.model;

import java.util.Optional;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;

/**
 * Deferred property binding.
 * Resolves binding only on layout model updates
 */
public class DeferredExternalBinding extends AbstractDeferredBinding {

    /**
     * Initializes a new instance of the {@link DeferredExternalBinding} class.
     * @param propertyValue  property value
     * @param targetProperty target property object
     */
    public DeferredExternalBinding(String propertyValue, ObservableProperty targetProperty) {
        super(propertyValue, targetProperty);
    }

    @Override
    protected Optional<IObservableProperty> obtainObservableProperty(ScreenModel model) {
        return Optional.of(model.getProperty(propertyValue.substring(1)));
    }
}
