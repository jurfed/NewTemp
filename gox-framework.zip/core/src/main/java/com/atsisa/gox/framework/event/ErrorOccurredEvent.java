package com.atsisa.gox.framework.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * A generic event triggered when some internal error has occurred.
 */
@Reflectable
public class ErrorOccurredEvent {

    /**
     * The throwable.
     */
    private final Throwable throwable;

    /**
     * Initializes a new instance of the {@link ErrorOccurredEvent}
     * with given throwable as the error cause.
     * @param throwable The error cause.
     */
    public ErrorOccurredEvent(Throwable throwable) {
        this.throwable = throwable;
    }

    /**
     * Gets a {@link Throwable} which is a direct cause
     * of this error event.
     * @return The cause of this event.
     */
    public Throwable getCause() {
        return throwable;
    }
}
