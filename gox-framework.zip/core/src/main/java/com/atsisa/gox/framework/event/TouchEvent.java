package com.atsisa.gox.framework.event;

import com.atsisa.gox.framework.view.View;

/**
 * Represents touch, mouse events regarding interactive views.
 */
public class TouchEvent extends InputEvent {

    /**
     * The stage x coordinate where the event occurred.
     */
    private float stageX;

    /**
     * The stage y coordinate where the event occurred.
     */
    private float stageY;

    /**
     * Initializes a new instance of the TouchEvent class.
     * @param type   input event type
     * @param source source of the event
     * @param stageX x coordinate where the event occurred.
     * @param stageY y coordinate where the event occurred.
     */
    public TouchEvent(InputEventType type, View source, float stageX, float stageY) {
        super(type, source);
        this.stageX = stageX;
        this.stageY = stageY;
    }

    /**
     * Returns stage x coordinate where the event occurred.
     * @return float.
     */
    public float getStageX() {
        return stageX;
    }

    /**
     * Returns stage y coordinate where the event occurred.
     * @return float.
     */
    public float getStageY() {
        return stageY;
    }

    /**
     * Sets stage x coordinate where the event occurred.
     * @param stageX x coordinate.
     */
    public void setStageX(float stageX) {
        this.stageX = stageX;
    }

    /**
     * Sets stage y coordinate where the event occurred.
     * @param stageY y coordinate.
     */
    public void setStageY(float stageY) {
        this.stageY = stageY;
    }

}
