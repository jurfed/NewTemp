package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.utility.font.IFontReference;

/**
 * A common implementation of the font resource.
 * @param <TFont> The type of platform-specific object representing the font.
 */
public abstract class AbstractFontResource<TFont> extends AbstractResource implements IFontReference<TFont> {

    /**
     * Creates resource object with given description using specific rendering.
     * @param description resource description object
     */
    protected AbstractFontResource(ResourceDescription description) {
        super(description, ResourceType.FONT);
    }

    /**
     * Creates resource object with given description using specific rendering
     * @param description  resource description object
     * @param resourceType The resource type.
     */
    protected AbstractFontResource(ResourceDescription description, ResourceType resourceType) {
        super(description, resourceType);
    }

    @Override
    public String getFontName() {
        return getId();
    }
}
