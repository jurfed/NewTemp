package com.atsisa.gox.framework.rendering.layer;

/**
 * Exposes methods for shape layers.
 */
public interface IShapeLayer extends ILayer {

    /**
     * Clears shape.
     */
    void clear();

}
