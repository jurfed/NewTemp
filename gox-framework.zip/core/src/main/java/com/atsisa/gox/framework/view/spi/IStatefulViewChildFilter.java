package com.atsisa.gox.framework.view.spi;

import com.atsisa.gox.framework.view.View;

/**
 * Exposes methods for view child filter classes, which are based on view state.
 * @param <T> type of state
 */
public interface IStatefulViewChildFilter<T> {

    /**
     * Checks if view is correct for specific state.
     * @param childView - View
     * @param viewState - T
     * @return boolean
     */
    boolean isValid(View childView, T viewState);

}
