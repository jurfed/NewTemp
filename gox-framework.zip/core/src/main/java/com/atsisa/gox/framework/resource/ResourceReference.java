package com.atsisa.gox.framework.resource;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * An object representing an identifiable resource.
 */
public final class ResourceReference implements IResourceReference {

    /**
     * The reference error message.
     */
    private static final String REFERENCE_ERROR_MESSAGE = "The resource reference must be in @ResourceType/ResourceName format. ";

    /**
     * The identifier.
     */
    private final String id;

    /**
     * The resource type.
     */
    private final ResourceType resourceType;

    /**
     * Initializes a new instance of the {@link ResourceReference} class.
     * @param id           The identifier.
     * @param resourceType The resource type.
     */
    private ResourceReference(String id, ResourceType resourceType) {
        this.id = id;
        this.resourceType = resourceType;
    }

    /**
     * Gets a new instance of the {@link ResourceReference} from given resource reference string.
     * @param resourceReference The resource reference string.
     * @return A resource name.
     * @throws IllegalArgumentException The resource reference cannot be parsed.
     */
    public static ResourceReference fromString(String resourceReference) {
        if (StringUtility.isNullOrEmpty(resourceReference)) {
            throw new IllegalArgumentException("The resourceReference cannot be null nor empty.");
        }
        if (!resourceReference.startsWith("@")) {
            throw new IllegalArgumentException(REFERENCE_ERROR_MESSAGE + "Missing '@' in " + resourceReference);
        }
        int slashIndex = resourceReference.indexOf('/');
        if (slashIndex == -1) {
            throw new IllegalArgumentException(REFERENCE_ERROR_MESSAGE + "Missing '/' in " + resourceReference);
        }
        try {
            String resourceTypeString = StringUtility.toUpperFirst(resourceReference.substring(1, slashIndex));
            ResourceType resourceType = ResourceType.fromString(resourceTypeString);
            if (resourceType == null) {
                throw new IllegalArgumentException(REFERENCE_ERROR_MESSAGE + "Unknown resource type: null");
            }
            String resourceId = resourceReference.substring(slashIndex + 1);
            if (StringUtility.isNullOrEmpty(resourceId)) {
                throw new IllegalArgumentException(REFERENCE_ERROR_MESSAGE + "Missing resource name in " + resourceReference);
            }
            return new ResourceReference(resourceId, resourceType);
        } catch (IndexOutOfBoundsException ex) {
            throw new IllegalArgumentException(REFERENCE_ERROR_MESSAGE + "Missing resource name in " + resourceReference);
        }
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public ResourceType getResourceType() {
        return resourceType;
    }

    @Override
    public String toString() {
        return convertToString(this);
    }

    /**
     * Converts given resource reference to its string representation.
     * @param resourceReference The resource reference.
     * @return The String representation of given resource reference.
     */
    public static String convertToString(IResourceReference resourceReference) {
        return '@' + resourceReference.getResourceType().toString().toLowerCase() + '/' + resourceReference.getId();
    }
}
