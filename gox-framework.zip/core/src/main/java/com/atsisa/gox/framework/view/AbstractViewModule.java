package com.atsisa.gox.framework.view;

import java.util.HashMap;
import java.util.Map;

/**
 * Describes the views which can be created declaratively using XML. When derived, it should tell the GameEngine which View classes will be placed in a
 * particular xml namespace.
 */
public abstract class AbstractViewModule {

    /**
     * A view map, maps view names to their types.
     */
    private Map<String, Class<? extends View>> viewMap;

    /**
     * Initializes a new instance of the AbstractViewModule class.
     */
    public AbstractViewModule() {
        viewMap = new HashMap<>();
        register();
    }

    /**
     * Gets the type of the registered view. If there is no View registered under viewName name, the null will be returned.
     * @param viewName the view name
     * @return the type of the view
     */
    public Class<? extends View> getViewType(String viewName) {
        if (viewMap.containsKey(viewName)) {
            return viewMap.get(viewName);
        }
        return null;
    }

    /**
     * Gets the XML namespace of the current module.
     * @return the XML namespace
     */
    public abstract String getXmlNamespace();

    /**
     * Registers View types to the current module. It will be called during module creation.
     * When overridden, it should call registerView setMethod to register a particular View types.
     */
    protected abstract void register();

    /**
     * Registers a particular view type. The name of the registered view will be the same as view class name.
     * @param viewType the view type
     */
    protected void registerView(Class<? extends View> viewType) {
        String name = viewType.toString();
        name = name.substring(name.lastIndexOf('.') + 1);
        if (viewMap.get(name) == null) {
            viewMap.put(name, viewType);
        }
    }

    /**
     * Registers a particular view type. The name of the registered view is passed as parameter.
     * @param name     the name of the view
     * @param viewType the view type
     */
    protected void registerView(String name, Class<? extends View> viewType) {
        viewMap.put(name, viewType);
    }

    @Override
    public String toString() {
        return "AbstractViewModule{xmlns = " + getXmlNamespace() + '}';
    }
}
