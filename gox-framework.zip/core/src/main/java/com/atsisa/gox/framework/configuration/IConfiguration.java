package com.atsisa.gox.framework.configuration;

import java.util.List;

import com.atsisa.gox.framework.action.ActionBinding;
import com.atsisa.gox.framework.view.Skin;

/**
 * Configuration interface. Exposes methods for getting all important configurations in the game.
 */
public interface IConfiguration {

    /**
     * Gets a list of action bindings.
     * @return a list of action bindings
     */
    List<ActionBinding> getActionBindings();

    /**
     * Gets a list of skins.
     * @return a list of skins
     */
    List<Skin> getSkinList();

    /**
     * Gets a list of properties.
     * @return a list of properties
     */
    List<ConfigurationProperty> getProperties();

    /**
     * Gets the property value based on name.
     * @param name property name to search
     * @return property value.
     */
    Object getProperty(String name);

    /**
     * Gets a list of action modules class names.
     * @return a list of action module class names
     */
    List<String> getActionModules();

    /**
     * Gets a list of view modules class names.
     * @return a list of view modules class names
     */
    List<String> getViewModules();

    /**
     * Gets a list of screens class names.
     * @return a list of screens class names
     */
    List<String> getScreens();

    /**
     * Merges the current configuration with the other.
     * At the end, all information from otherConfig will be merged with current object.
     * The otherConfig object remains intact.
     * @param otherConfig other configuration to merge
     */
    void merge(final IConfiguration otherConfig);
}
