package com.atsisa.gox.framework.action;

import com.atsisa.gox.framework.command.StartTimerCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Publishes an {@link StartTimerCommand} which is a direct
 * request for starting a timer of given name.
 */
public class StartTimerAction extends SyncAction<StartTimerActionData> {

    /**
     * Initializes a new instance of the {@link StartTimerAction} class.
     */
    public StartTimerAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link StartTimerAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public StartTimerAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new StartTimerCommand(actionData.getTimerName(), actionData.getDuration()));
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || actionData.getTimerName() == null) {
            throw new ValidationException("The timer name cannot be null.");
        }

        if (actionData.getDuration() <= 0) {
            throw new ValidationException("The duration of timer must be a positive integer.");
        }
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return StartTimerActionData.class;
    }
}
