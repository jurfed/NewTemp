package com.atsisa.gox.framework.model;

import java.util.List;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.resource.XmlResource;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.view.View;

/**
 * Exposes an abstraction layers lying behind the layout model.
 */
public interface ILayout extends IDisposable {

    /**
     * Gets the layout identifier.
     * @return the layout identifier
     */
    String getId();

    /**
     * Gets the layout text resource.
     * @return the layout xml resource to set
     */
    XmlResource getXmlResource();

    /**
     * Gets the layout root view.
     * @return root view
     */
    View getRootView();

    /**
     * Checks if the layout has been built (has root view assigned).
     * @return true if the layout has been build, false otherwise
     */
    boolean isBuilt();

    /**
     * Checks if the layout has been added to the main stage.
     * @return true if it has been added, false otherwise
     */
    boolean isOnStage();

    /**
     * Gets a list of models bindings.
     * @return a list of models bindings
     */
    List<PropertyBinding> getPropertyBindings();

    /**
     * Gets the data models object.
     * @return data models object
     */
    ScreenModel getScreenModel();

    /**
     * Sets the data models object.
     * @param screenModel data models object
     */
    void setScreenModel(ScreenModel screenModel);

    /**
     * Builds the layout from either text resource or using predefined view.
     * @throws ParseException when something went wrong with building layout
     */
    void build() throws ParseException;

    /**
     * Refreshes the layout according to model.
     */
    void refresh();

    /**
     * Updates the layout with new xml resource.
     * @param xmlResource xml resource.
     */
    void update(XmlResource xmlResource);

    /**
     * Adds a layout listener.
     * @param layoutListener layout listener
     */
    void addLayoutListener(ILayoutListener layoutListener);

    /**
     * Removes a layout listener.
     * @param layoutListener layout listener
     */
    void removeLayoutListener(ILayoutListener layoutListener);

    /**
     * Returns a value indicating whether or not the layout is destroyable.
     * @return a value indicating whether or not the layout is destroyable
     */
    boolean isDisposable();
}
