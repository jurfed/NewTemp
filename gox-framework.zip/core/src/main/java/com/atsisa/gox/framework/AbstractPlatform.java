package com.atsisa.gox.framework;

import com.atsisa.gox.framework.event.LifecycleEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;

/**
 * Abstract platform class implements common IPlatform interface.
 */
public abstract class AbstractPlatform implements IPlatform {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * Initializes a new instance of the {@link AbstractPlatform} class.
     * @param eventBus {@link IEventBus}
     */
    public AbstractPlatform(IEventBus eventBus) {
        this.eventBus = eventBus;
    }

    /**
     * Sends notification to all listeners about exit.
     */
    void notifyExit() {
        eventBus.post(new LifecycleEvent(LifecycleEventType.EXIT));
    }
}
