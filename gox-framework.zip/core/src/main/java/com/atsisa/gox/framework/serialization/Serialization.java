package com.atsisa.gox.framework.serialization;

import com.google.inject.Inject;

/**
 * A partial implementation of the serialization helper.
 */
public class Serialization implements ISerialization {

    /**
     * A serializer reference.
     */
    private IXmlSerializer serializer;

    /**
     * A parser reference.
     */
    private IParser parser;

    /**
     * Initializes a new instance of the Serialization class.
     * @param serializer serializer
     * @param parser     parser
     */
    @Inject
    public Serialization(IXmlSerializer serializer, IParser parser) {
        this.serializer = serializer;
        this.parser = parser;
    }

    @Override
    public IXmlSerializer getSerializer(SerializationFormat serializerType) {
        if (serializer.getFormat() == serializerType) {
            return serializer;
        }
        return null;
    }

    @Override
    public IParser getParser(SerializationFormat serializerType) {
        if (parser.getFormat() == serializerType) {
            return parser;
        }
        return null;
    }
}
