package com.atsisa.gox.framework.animation;

/**
 * Represents a key frame animation.
 */
public interface IKeyframeAnimation extends IViewAnimation {

    /**
     * Determines whether the animation plays in loop.
     * @return {true} if loop is set {false} if unset
     */
    boolean isLoop();

    /**
     * Gets a boolean value that indicates whether this animation will loop or not.
     * @param loop a boolean value that indicates whether this animation will loop or not.
     */
    void setLoop(boolean loop);

    /**
     * Determines whether the animation plays backwards or forwards.
     * @return {true} if backward playing is set {false} if unset
     */
    boolean isBackward();

    /**
     * Sets the animation plays backwards or forwards.
     * @param backward {true} if backward playing is set {false} if unset
     */
    void setBackward(boolean backward);

    /**
     * Sets begin loop frame. When animation will finish, and loop is set to true, animation will not start from the
     * beginning but from this frame number.
     * @param frameNumber frame number starting from 1
     */
    void setBeginLoopFrameNumber(int frameNumber);

    /**
     * Sets end loop frame. When animation will finish, and loop is set to true, animation will not start from the
     * beginning but from this frame number.
     * @param frameNumber frame number starting from 1
     */
    void setEndLoopFrameNumber(int frameNumber);

    /**
     * Goes to frame and plays animation from given frame.
     * @param frameNumber frame number starting from 1
     */
    void gotoAndPlay(int frameNumber);

    /**
     * Pause Animation on given frame.
     * @param frameNumber frame number starting from 1
     */
    void gotoAndPause(int frameNumber);

    /**
     * Plays animation and pauses on given frame.
     * @param frameNumber frame number starting from 1
     */
    void playToAndPause(int frameNumber);
}
