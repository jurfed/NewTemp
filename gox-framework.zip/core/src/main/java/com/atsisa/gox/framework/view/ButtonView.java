package com.atsisa.gox.framework.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.event.IEvent;
import com.atsisa.gox.framework.model.IPropertyChangedListener;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.google.gwt.resources.client.ImageResource;
import com.gwtent.reflection.client.Reflectable;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Basic button view.
 */
@Reflect_Full
@XmlElement
public class ButtonView extends InteractiveView {

    /**
     * Button over state image resource.
     */
    @XmlAttribute(name = "overState", type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ObservableProperty<IImageReference> overStateResource = new ObservableProperty<>(IImageReference.class);

    /**
     * Button normal state image resource.
     */
    @XmlAttribute(name = "normalState", type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ObservableProperty<IImageReference> normalStateResource = new ObservableProperty<>(IImageReference.class);

    /**
     * Button down state image resource.
     */
    @XmlAttribute(name = "downState", type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ObservableProperty<IImageReference> downStateResource = new ObservableProperty<>(IImageReference.class);

    /**
     * Button disable state image resource.
     */
    @XmlAttribute(name = "disableState", type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ObservableProperty<IImageReference> disableStateResource = new ObservableProperty<>(IImageReference.class);

    /**
     * Boolean value that indicates whether this button is enabled or not.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> enabled = new ObservableProperty<>(Boolean.class, Boolean.TRUE);

    /**
     * Label attribute.
     */
    @XmlAttribute(type = String.class)
    private final ViewProperty<String> label = new ViewProperty<>(String.class, this, ViewType.BUTTON_VIEW, ViewPropertyName.LABEL);

    /**
     * Text format for label in over state.
     */
    @XmlElement(name = "OverLabelFormat", type = ButtonView.LabelFormat.class)
    private final LabelFormat overLabelFormat = new LabelFormat();

    /**
     * Text format for label in normal/default state.
     */
    @XmlElement(name = "NormalLabelFormat", type = ButtonView.LabelFormat.class)
    private final LabelFormat normalLabelFormat = new LabelFormat();

    /**
     * Text format for label in down state.
     */
    @XmlElement(name = "DownLabelFormat", type = ButtonView.LabelFormat.class)
    private final LabelFormat downLabelFormat = new LabelFormat();

    /**
     * Text format for label in disable state.
     */
    @XmlElement(name = "DisableLabelFormat", type = ButtonView.LabelFormat.class)
    private final LabelFormat disableLabelFormat = new LabelFormat();

    /**
     * Listener to listen for changes in enable property.
     */
    private final IPropertyChangedListener<Boolean> enableChangedListener;

    /**
     * Listener to listen for changes in label format objects.
     */
    private final IPropertyChangedListener<Object> labelFormatChangedListener;

    /**
     * Initializes a new instance of the {@link ButtonView} class.
     */
    public ButtonView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link ButtonView} class.
     * @param renderer {@link IRenderer}
     */
    public ButtonView(IRenderer renderer) {
        super(renderer);
        enableChangedListener = (source, oldValue, newValue) -> enableValueChanged(oldValue, newValue);
        labelFormatChangedListener = (source, oldValue, newValue) -> labelFormatChanged();
    }

    /**
     * Called when enable value is changed.
     * @param oldValue previous enable value.
     * @param newValue current enable value.
     */
    private void enableValueChanged(Boolean oldValue, Boolean newValue) {
        if (oldValue != null && !oldValue && newValue) {
            setCurrentState(InteractiveViewState.NORMAL_STATE);
        }
        updateInteractiveState();
    }

    /**
     * Gets a boolean value that indicates whether this button is enabled or not.
     * @return boolean
     */
    public boolean isEnabled() {
        return enabled.get();
    }

    /**
     * Sets a boolean value that.
     * @param enabled - boolean
     */
    public void setEnabled(boolean enabled) {
        this.enabled.set(enabled);
    }

    /**
     * Gets the enabled property.
     * @return the enabled property
     */
    public IObservableProperty<Boolean> enabled() {
        return enabled;
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        View view = skin.getView();
        if (view instanceof ButtonView) {
            ButtonView buttonView = (ButtonView) view;
            if (overStateResource.hasDefaultValue()) {
                overStateResource.set(buttonView.getOverStateResource());
            }
            if (normalStateResource.hasDefaultValue()) {
                overStateResource.set(buttonView.getNormalStateResource());
            }
            if (downStateResource.hasDefaultValue()) {
                overStateResource.set(buttonView.getDownStateResource());
            }
            if (disableStateResource.hasDefaultValue()) {
                overStateResource.set(buttonView.getDisableStateResource());
            }
            if (normalLabelFormat.hasDefaultValues()) {
                populateLabelFormat(normalLabelFormat, buttonView.getNormalLabelFormat());
            }
            if (overLabelFormat.hasDefaultValues()) {
                populateLabelFormat(overLabelFormat, buttonView.getOverLabelFormat());
            }
            if (downLabelFormat.hasDefaultValues()) {
                populateLabelFormat(downLabelFormat, buttonView.getDownLabelFormat());
            }
            if (disableLabelFormat.hasDefaultValues()) {
                populateLabelFormat(disableLabelFormat, buttonView.getDisableLabelFormat());
            }
        }
    }

    /**
     * Initializes the button to keep track of its activity.
     */
    @Override
    protected void init() {
        super.init();
        enabled.addPropertyChangedListener(enableChangedListener);
        normalLabelFormat.setPropertyChangedListener(labelFormatChangedListener);
        overLabelFormat.setPropertyChangedListener(labelFormatChangedListener);
        downLabelFormat.setPropertyChangedListener(labelFormatChangedListener);
        disableLabelFormat.setPropertyChangedListener(labelFormatChangedListener);
    }

    /**
     * Gets button normal state image resource.
     * @return image resource
     */
    public IImageReference getNormalStateResource() {
        return normalStateResource.get();
    }

    /**
     * Sets button normal state image resource.
     * @param imageResource - ImageResource
     */
    public void setNormalStateResource(IImageReference imageResource) {
        if (normalStateResource.set(imageResource)) {
            if (width().hasDefaultValue()) {
                setWidth(imageResource.getImageWrapperObject().getWidth());
            }
            if (height().hasDefaultValue()) {
                setHeight(imageResource.getImageWrapperObject().getHeight());
            }
            updateInteractiveState();
        }
    }

    /**
     * Gets the normal state resource property.
     * @return normal state resource property
     */
    public IObservableProperty<IImageReference> normalStateResource() {
        return normalStateResource;
    }

    /**
     * Gets button over state image resource.
     * @return image resource
     */
    public IImageReference getOverStateResource() {
        return overStateResource.get();
    }

    /**
     * Sets button over state image resource.
     * @param imageResource - ImageResource
     */
    public void setOverStateResource(IImageReference imageResource) {
        if (overStateResource.set(imageResource)) {
            updateInteractiveState();
        }
    }

    /**
     * Sets new text value for label.
     * @param text new text value
     */
    public void setLabel(String text) {
        label.set(text);
    }

    /**
     * Gets text value for button label.
     * @return text value
     */
    public String getLabel() {
        return label.get();
    }

    /**
     * Gets the label property.
     * @return observable label property.
     */
    public IObservableProperty<String> label() {
        return label;
    }

    /**
     * Gets label format for over state.
     * @return label format for over state
     */
    public LabelFormat getOverLabelFormat() {
        return overLabelFormat;
    }

    /**
     * Gets label format for normal state.
     * @return label format for normal state.
     */
    public LabelFormat getNormalLabelFormat() {
        return normalLabelFormat;
    }

    /**
     * Gets label format for down state.
     * @return label format for down state
     */
    public LabelFormat getDownLabelFormat() {
        return downLabelFormat;
    }

    /**
     * Gets label format for disable state.
     * @return label format for disable state.
     */
    public LabelFormat getDisableLabelFormat() {
        return disableLabelFormat;
    }

    /**
     * Sets format for label in normal state.
     * @param labelFormat label format to set
     */
    public void setNormalLabelFormat(LabelFormat labelFormat) {
        populateLabelFormat(normalLabelFormat, labelFormat);
    }

    /**
     * Sets format for label in over state.
     * @param labelFormat label format to set
     */
    public void setOverLabelFormat(LabelFormat labelFormat) {
        populateLabelFormat(overLabelFormat, labelFormat);
    }

    /**
     * Sets format for label in disable state.
     * @param labelFormat label format to set
     */
    public void setDisableLabelFormat(LabelFormat labelFormat) {
        populateLabelFormat(disableLabelFormat, labelFormat);
    }

    /**
     * Sets format for label in down state.
     * @param labelFormat label format to set
     */
    public void setDownLabelFormat(LabelFormat labelFormat) {
        populateLabelFormat(downLabelFormat, labelFormat);
    }

    /**
     * Updates specific label format settings.
     * @param currentFormat label format to update
     * @param newFormat     label format from which settings will be taken
     */
    private void populateLabelFormat(LabelFormat currentFormat, LabelFormat newFormat) {
        currentFormat.populate(newFormat);
        labelFormatChanged();
    }

    /**
     * Called when label format for any state will be changed.
     */
    private void labelFormatChanged() {
        propertyChanged(ViewType.BUTTON_VIEW, ViewPropertyName.LABEL_FORMAT);
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.BUTTON_VIEW, ViewPropertyName.LABEL_FORMAT | ViewPropertyName.LABEL);
    }

    /**
     * Gets the over state resource property.
     * @return over state resource property
     */
    public IObservableProperty<IImageReference> overStateResource() {
        return overStateResource;
    }

    /**
     * Gets button down state image resource.
     * @return image resource
     */
    public IImageReference getDownStateResource() {
        return downStateResource.get();
    }

    /**
     * Sets button down state image resource.
     * @param imageResource {@link ImageResource}
     */
    public void setDownStateResource(IImageReference imageResource) {
        if (downStateResource.set(imageResource)) {
            updateInteractiveState();
        }
    }

    /**
     * Gets the down state resource property.
     * @return down state resource property
     */
    public IObservableProperty<IImageReference> downStateResource() {
        return downStateResource;
    }

    /**
     * Gets button disable state image resource.
     * @return ImageResource
     */
    public IImageReference getDisableStateResource() {
        return disableStateResource.get();
    }

    /**
     * Sets button disable state image resource.
     * @param imageResource {@link ImageResource}
     */
    public void setDisableStateResource(IImageReference imageResource) {
        if (disableStateResource.set(imageResource)) {
            updateInteractiveState();
        }
    }

    /**
     * Updates interactive state.
     */
    private void updateInteractiveState() {
        if (!isEnabled()) {
            setInteractive(false);
        } else if (hasEventListeners() || (normalStateResource.get() != null && (downStateResource.get() != null || overStateResource.get() != null))) {
            setInteractive(true);
        }
        propertyChanged(ViewType.INTERACTIVE_VIEW, InteractiveView.ViewPropertyName.STATE);
    }

    /**
     * Gets the disable state resource property.
     * @return disable state resource property
     */
    public IObservableProperty<IImageReference> disableStateResource() {
        return disableStateResource;
    }

    /**
     * Gets current state image resource.
     * @return ImageResource
     */
    public IImageReference getCurrentStateResource() {
        if (!isEnabled() && getDisableStateResource() != null) {
            return disableStateResource.get();
        } else if (getCurrentState() == InteractiveViewState.DOWN_STATE && getDownStateResource() != null) {
            return downStateResource.get();
        } else if (getCurrentState() == InteractiveViewState.OVER_STATE && getOverStateResource() != null) {
            return overStateResource.get();
        }
        return normalStateResource.get();
    }

    /**
     * Gets label format for current state.
     * @return LabelFormat
     */
    public LabelFormat getCurrentLabelFormat() {
        if (!isEnabled()) {
            return disableLabelFormat;
        } else if (getCurrentState() == InteractiveViewState.DOWN_STATE) {
            return downLabelFormat;
        } else if (getCurrentState() == InteractiveViewState.OVER_STATE) {
            return overLabelFormat;
        }
        return normalLabelFormat;
    }

    @Override
    public void triggerEvent(IEvent event) {
        if (isEnabled()) {
            super.triggerEvent(event);
        }
    }

    /**
     * Button label format.
     */
    @Reflectable
    @XmlElement
    public static final class LabelFormat extends TextFormat {

        /**
         * Relative position x of the label text field inside button.
         */
        @XmlAttribute(type = Float.class)
        private final ObservableProperty<Float> x = new ObservableProperty<>(Float.class, 0F);

        /**
         * Relative position y of the label text field inside button.
         */
        @XmlAttribute(type = Float.class)
        private final ObservableProperty<Float> y = new ObservableProperty<>(Float.class, 0F);

        /**
         * Sets property changed listener who will listen to changes in properties.
         * @param listener {@link IPropertyChangedListener}
         */
        private void setPropertyChangedListener(IPropertyChangedListener<Object> listener) {
            x().addPropertyChangedListener(listener);
            y().addPropertyChangedListener(listener);
            color().addPropertyChangedListener(listener);
            fontName().addPropertyChangedListener(listener);
            fontSize().addPropertyChangedListener(listener);
            wordWrap().addPropertyChangedListener(listener);
            scaleAutoWidth().addPropertyChangedListener(listener);
            haling().addPropertyChangedListener(listener);
            valing().addPropertyChangedListener(listener);
        }

        /**
         * Gets a boolean value that indicates whether this label format has the same default values.
         * @return boolean
         */
        public boolean hasDefaultValues() {
            return x().hasDefaultValue() && y().hasDefaultValue() && color().hasDefaultValue() && fontName().hasDefaultValue() && fontSize().hasDefaultValue()
                    && wordWrap().hasDefaultValue() && scaleAutoWidth().hasDefaultValue() && haling().hasDefaultValue() && valing().hasDefaultValue();
        }

        /**
         * Gets relative position x of the label text field inside button.
         * @return position x.
         */
        public float getX() {
            return x.get();
        }

        /**
         * Set relative position x of the label text field inside button.
         * @param x relative position x.
         */
        public void setX(float x) {
            this.x.set(x);
        }

        /**
         * Gets relative position y of the label text field inside button.
         * @return position y.
         */
        public float getY() {
            return y.get();
        }

        /**
         * Set relative position y of the label text field inside button.
         * @param y relative position y.
         */
        public void setY(float y) {
            this.y.set(y);
        }

        /**
         * Gets the x property.
         * @return x property.
         */
        public ObservableProperty<Float> x() {
            return x;
        }

        /**
         * Gets the y property.
         * @return y property.
         */
        public ObservableProperty<Float> y() {
            return y;
        }

        /**
         * Populates this label format using different one, all values will be override.
         * @param labelFormat label format from which settings should be get.
         */
        private void populate(LabelFormat labelFormat) {
            setFontName(labelFormat.getFontName());
            setX(labelFormat.getX());
            setY(labelFormat.getY());
            setColor(labelFormat.getColor());
            setHalign(labelFormat.getHalign());
            setValign(labelFormat.getValign());
            setFontSize(labelFormat.getFontSize());
            setScaleAutoWidth(labelFormat.isScaleAutoWidth());
            setWordWrap(labelFormat.isWordWrap());
        }
    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via getLabel.
         */
        public static final int LABEL = 1;

        /**
         * Represents a view property accessible via getCurrentLabelFormat.
         */
        public static final int LABEL_FORMAT = 1;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }

}
