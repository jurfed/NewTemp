package com.atsisa.gox.framework;

import com.atsisa.gox.framework.utility.IForceInitializable;

/**
 * Exposes methods for controlling game lifecycle.
 */
public interface IGame {

    /**
     * Called when the game rendering has been initialized.
     */
    void onCreate();

    /**
     * Called when all resources are successfully loaded.
     */
    void onReady();

    /**
     * Called when the game play is active.
     */
    void onStart();

    /**
     * Registers object which needs to be initializable after specific behaviour. (e.g. on mobile browser after user interaction).
     * @param forceInitializable IForceInitializable
     * @return boolean
     */
    boolean registerForceInitializable(IForceInitializable forceInitializable);

    /**
     * Unregisters object which needs to be initializable after specific behaviour.
     * @param forceInitializable IForceInitializable
     * @return boolean
     */
    boolean unregisterForceInitializable(IForceInitializable forceInitializable);

    /**
     * Invokes all force initializable objects which are registered for special behaviour.
     */
    void invokeForceInitializableObjects();
}
