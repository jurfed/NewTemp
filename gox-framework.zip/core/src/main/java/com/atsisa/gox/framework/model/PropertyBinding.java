package com.atsisa.gox.framework.model;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Property binding class.
 * Exposes a possibility to bind two observable property objects.
 */
@SuppressWarnings("unchecked")
public class PropertyBinding implements IPropertyChangedListener {

    /**
     * Source property.
     */
    private IObservableProperty sourceProperty;

    /**
     * Target property.
     */
    private IObservableProperty targetProperty;

    /**
     * A logger reference.
     */
    private ILogger logger;

    /**
     * Initializes a new instance of the PropertyBinding class.
     * @param sourceProperty source property which will trigger target updates
     * @param targetProperty target property which will be populated from source
     * @param logger         logger reference
     */
    public PropertyBinding(IObservableProperty sourceProperty, IObservableProperty targetProperty, ILogger logger) {
        this.logger = logger;
        this.sourceProperty = sourceProperty;
        this.sourceProperty.addPropertyChangedListener(this);
        this.targetProperty = targetProperty;
    }

    /**
     * Initializes a new instance of the PropertyBinding class.
     * @param sourceProperty source property which will trigger target updates
     * @param targetProperty target property which will be populated from source
     */
    public PropertyBinding(IObservableProperty sourceProperty, IObservableProperty targetProperty) {
        this(sourceProperty, targetProperty, GameEngine.current().getLogger());
    }

    /**
     * Initializes a new instance of the PropertyBinding class.
     * Once this constructor is used, it is possible to implement deferred source property
     * binding.
     * @param targetProperty target property which will be populated from source
     * @param logger         logger reference
     */
    protected PropertyBinding(ObservableProperty targetProperty, ILogger logger) {
        this.logger = logger;
        this.targetProperty = targetProperty;
    }

    /**
     * Initializes a new instance of the PropertyBinding class.
     * Once this constructor is used, it is possible to implement deferred source property
     * binding.
     * @param targetProperty target property which will be populated from source
     */
    protected PropertyBinding(ObservableProperty targetProperty) {
        this(targetProperty, GameEngine.current().getLogger());
    }

    @Override
    public void propertyChanged(IObservableProperty source, Object oldValue, Object newValue) {
        update();
    }

    /**
     * Requests the target property update.
     */
    public void update() {
        logger.debug("PropertyBinding | update | %s", this);
        assert targetProperty != null : "Target property is not defined";
        Object sourcePropertyValue = getSourcePropertyValue();
        if (sourceProperty == null || !sourceProperty.getType().equals(targetProperty.getType())) {
            if (targetProperty.getType() == String.class) {
                sourcePropertyValue = sourcePropertyValue != null ? sourcePropertyValue.toString() : null;
            } else if (sourceProperty != null && sourceProperty.getType() != Object.class) {
                throw new ClassCastException(StringUtility.format("Could not convert '%s' to '%s'!", sourceProperty.getType(), targetProperty.getType()));
            }
        }

        targetProperty.set(sourcePropertyValue);
    }

    /**
     * Gets the source property value.
     * @return the source property value.
     */
    protected Object getSourcePropertyValue() {
        assert sourceProperty != null : "Source property is not defined";
        return sourceProperty.get();
    }

    /**
     * Destroys the binding by unplugging the property changed listeners from source property.
     */
    public void destroy() {
        logger.debug("PropertyBinding | destroy | %s", this);
        if (sourceProperty != null) {
            sourceProperty.removePropertyChangedListener(this);
        }
    }

    /**
     * Gets the source property object.
     * @return source property object
     */
    public IObservableProperty getSourceProperty() {
        return sourceProperty;
    }

    /**
     * Gets the target property object.
     * @return target property object
     */
    public IObservableProperty getTargetProperty() {
        return targetProperty;
    }

    /**
     * Sets a new source property object.
     * This setMethod should be used in deferred bindings
     * @param sourceProperty new source property object
     */
    protected void setSourceProperty(IObservableProperty sourceProperty) {
        logger.debug("PropertyBinding | setSourceProperty | sourceProperty: %s", sourceProperty);
        if (this.sourceProperty != null) {
            this.sourceProperty.removePropertyChangedListener(this);
        }
        this.sourceProperty = sourceProperty;
        if (this.sourceProperty != null) {
            this.sourceProperty.addPropertyChangedListener(this);
        }
        update();
    }

    @Override
    public String toString() {
        return "PropertyBinding{source=" + sourceProperty + ", target=" + targetProperty + '}';
    }
}
