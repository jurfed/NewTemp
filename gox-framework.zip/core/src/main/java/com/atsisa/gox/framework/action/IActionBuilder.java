package com.atsisa.gox.framework.action;

import java.util.List;

import com.atsisa.gox.framework.resource.QueuesResource;
import com.atsisa.gox.framework.serialization.ParseException;

/**
 * Exposes methods for registering action modules and build particular actions using theirs XML description.
 */
public interface IActionBuilder {

    /**
     * Registers a action module in the builder to use it later for mapping xml namespaces to particular action classes.
     * @param actionModule {@link AbstractActionModule}
     */
    void registerModule(AbstractActionModule actionModule);

    /**
     * Unregister a specific module.
     * @param actionModule {@link AbstractActionModule}
     * @return boolean
     */
    boolean unregisterModule(AbstractActionModule actionModule);

    /**
     * Unregister module with a specific namespace.
     * @param namespace specific namespace
     * @return true if successful
     */
    boolean unregisterModule(String namespace);

    /**
     * Gets a boolean value that indicates whether contains specific queue description or not.
     * @param queueName queue name
     * @return true if exists otherwise false
     */
    boolean containsQueue(String queueName);

    /**
     * Gets a list of registered action modules.
     * @return a list of registered action modules
     */
    List<AbstractActionModule> getModules();

    /**
     * Adds queues using text resource containing xml description.
     * @param resource xml text resource to use during the build
     * @throws ParseException if given text resource could not be parsed
     */
    void addQueues(QueuesResource resource) throws ParseException;

    /**
     * Adds queues using xml description given as parameter.
     * @param serializedQueues the xml string describing the queues
     * @throws ParseException if given text resource could not be parsed
     */
    void addQueues(String serializedQueues) throws ParseException;

    /**
     * Gets queue metadata for a specific name.
     * @param queueName queue name
     * @return QueueMedatada
     */
    QueueMetadata getQueue(String queueName);

    /**
     * Gets action with a specific name, in a specific namespace.
     * @param actionName string
     * @param namespace  string
     * @return IAction
     */
    Action getAction(String actionName, String namespace);

}
