package com.atsisa.gox.framework.action.model;

import com.atsisa.gox.framework.action.ActionQueueState;

/**
 * Blocking state listener mock class. This listener block the current thread until a particular action queue state occurs.
 */
public class BlockingStateListenerMock extends StateListenerMock<ActionQueueState> {

    /**
     * Variable used for storing time of timeout.
     */
    private int timeout;

    /**
     * It stores information whether timeout has finished.
     */
    private boolean ready;

    private ActionQueueState continueState;

    /**
     * Initializes a new instance of the ResourceLoadingCallbackMock.
     */
    public BlockingStateListenerMock() {
        this.timeout = 500;
    }

    /**
     * Waits for callback with a given timeout.
     */
    public synchronized void waitForListener(ActionQueueState continueState) {
        this.continueState = continueState;
        while (!ready) {
            try {
                this.wait(timeout);
                ready = true;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void stateChanged(Object source, ActionQueueState state) {
        super.stateChanged(source, state);
        if (continueState == state) {
            synchronized (this) {
                ready = true;
                this.notifyAll();
            }
        }
    }
}
