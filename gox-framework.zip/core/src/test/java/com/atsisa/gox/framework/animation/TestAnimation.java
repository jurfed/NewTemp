package com.atsisa.gox.framework.animation;

public class TestAnimation extends AbstractAnimation {

    @Override
    public void play() {
        setAnimationState(AnimationState.PLAYING);
    }

    @Override
    public void pause() {
        setAnimationState(AnimationState.PAUSED);
    }

    @Override
    public void stop() {
        setAnimationState(AnimationState.STOPPED);
    }

    @Override
    public synchronized void setAnimationState(AnimationState animationState) {
        super.setAnimationState(animationState);
    }
}
