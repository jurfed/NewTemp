package com.atsisa.gox.framework.action.bindings;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;

import com.atsisa.gox.framework.action.ActionBinder;
import com.atsisa.gox.framework.action.ActionBinding;
import com.atsisa.gox.framework.action.bindings.model.InputEventListenerMock;
import com.atsisa.gox.framework.configuration.Configuration;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.ButtonView;

/**
 * Action binder tests.
 */
public class ActionBinderTests {

    /**
     * Logger mock.
     */
    private ILogger logger;

    /**
     * Configuration provider mock.
     */
    private IConfigurationProvider configProvider;

    /**
     * Configuration mock.
     */
    private Configuration configuration;

    /**
     * Subject of tests.
     */
    private ActionBinder actionBinder;

    /**
     * View mock.
     */
    private ButtonView view;

    /**
     * Sets up the configuration provider dependencies.
     * @throws SerializationException when something went wrong with setting up the serializer
     */
    @Before
    public void setUp() throws SerializationException {
        configuration = new Configuration();
        logger = mock(ILogger.class);
        configProvider = mock(IConfigurationProvider.class);
        when(configProvider.getConfiguration()).thenReturn(configuration);

        actionBinder = new ActionBinder(configProvider, logger);
        view = new ButtonView(mock(IRenderer.class));
        view.setId("view");
    }

    /**
     * Tests if binding to view with no identifier will count.
     */
    @Test
    public void triggeringEvent_afterBindingViewWithNoId_doesNotFireCallback() {
        view.setId(null);
        InputEvent inputEvent = new InputEvent(InputEventType.RELEASED, view);
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        ActionBinding binding = new ActionBinding();
        binding.setEventType(InputEventType.RELEASED);
        binding.setTargetId("view");
        binding.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding);

        actionBinder.bind(view);
        view.triggerEvent(inputEvent);

        assertFalse(actionBinder.isBound(view));
        assertEquals(0, listenerMock.getEvents().size());
    }

    /**
     * Tests if binding to view with other identifier than expected will count.
     */
    @Test
    public void triggeringEvent_afterBindingNoAction_doesNotFireCallback() {
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        InputEvent inputEvent = new InputEvent(InputEventType.RELEASED, view);
        ActionBinding binding = new ActionBinding();
        binding.setEventType(InputEventType.RELEASED);
        binding.setTargetId("not-existing-view");
        binding.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding);

        actionBinder.bind(view);
        view.triggerEvent(inputEvent);

        assertFalse(actionBinder.isBound(view));
        assertEquals(0, listenerMock.getEvents().size());
    }

    /**
     * Tests if binding to view with proper identifier will fire event callback.
     */
    @Test
    public void triggeringEvent_afterBindingSingleAction_firesProperCallback() {
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        InputEvent inputEvent = new InputEvent(InputEventType.RELEASED, view);
        ActionBinding binding = new ActionBinding();
        binding.setEventType(InputEventType.RELEASED);
        binding.setTargetId("view");
        binding.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding);

        actionBinder.bind(view);
        view.triggerEvent(inputEvent);

        assertTrue(actionBinder.isBound(view));
        assertEquals(1, listenerMock.getEvents().size());
        assertEquals(inputEvent, listenerMock.getEvents().get(0));
    }

    /**
     * Tests if multiple view bindings will fire event callback multiple times.
     */
    @Test
    public void triggerEvent_afterBindingMultipleActions_firesCallbacksMultipleTimes() {
        InputEvent inputEvent1 = new InputEvent(InputEventType.RELEASED, view);
        InputEvent inputEvent2 = new InputEvent(InputEventType.MOUSE_OUT, view);
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        ActionBinding binding1 = new ActionBinding();
        binding1.setEventType(InputEventType.RELEASED);
        binding1.setTargetId("view");
        binding1.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding1);
        ActionBinding binding2 = new ActionBinding();
        binding2.setEventType(InputEventType.MOUSE_OUT);
        binding2.setTargetId("view");
        binding2.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding2);

        actionBinder.bind(view);
        view.triggerEvent(inputEvent1);
        view.triggerEvent(inputEvent2);

        assertTrue(actionBinder.isBound(view));
        assertEquals(2, listenerMock.getEvents().size());
        assertEquals(inputEvent1, listenerMock.getEvents().get(0));
        assertEquals(inputEvent2, listenerMock.getEvents().get(1));
    }

    /**
     * Tests if unbinding works.
     */
    @Test
    public void triggeringEvent_afterUnbindingViewWithBindings_doesNotFireCallback() {
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        InputEvent inputEvent = new InputEvent(InputEventType.RELEASED, view);
        ActionBinding binding = new ActionBinding();
        binding.setEventType(InputEventType.RELEASED);
        binding.setTargetId("view");
        binding.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding);

        actionBinder.bind(view);
        actionBinder.unbind(view);
        view.triggerEvent(inputEvent);

        assertFalse(actionBinder.isBound(view));
        assertEquals(0, listenerMock.getEvents().size());
    }

    /**
     * Tests if rebinding works.
     */
    @Test
    public void triggeringEvent_afterRebindingViewWithBindings_firesCallback() {
        InputEventListenerMock listenerMock = new InputEventListenerMock();
        InputEvent inputEvent1 = new InputEvent(InputEventType.RELEASED, view);
        InputEvent inputEvent2 = new InputEvent(InputEventType.MOUSE_OUT, view);
        ActionBinding binding1 = new ActionBinding();
        binding1.setEventType(InputEventType.RELEASED);
        binding1.setTargetId("view");
        binding1.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding1);

        actionBinder.bind(view);

        configuration.getActionBindings().clear();
        ActionBinding binding2 = new ActionBinding();
        binding2.setEventType(InputEventType.MOUSE_OUT);
        binding2.setTargetId("view");
        binding2.setEventListener(listenerMock);
        configuration.getActionBindings().add(binding2);

        actionBinder.rebind(view);
        view.triggerEvent(inputEvent1);
        view.triggerEvent(inputEvent2);

        assertTrue(actionBinder.isBound(view));
        assertEquals(1, listenerMock.getEvents().size());
        assertEquals(inputEvent2, listenerMock.getEvents().get(0));
    }
}
