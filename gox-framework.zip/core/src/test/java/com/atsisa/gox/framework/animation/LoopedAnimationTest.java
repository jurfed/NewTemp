package com.atsisa.gox.framework.animation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Tests for {@link LoopedAnimation} class.
 */
public class LoopedAnimationTest {

    /**
     * Tested LoopedAnimation class object.
     */
    private LoopedAnimation loopedAnimation;

    /**
     * Test animation for looped animation tests.
     */
    private TestAnimation testAnimation;

    /**
     * Tests whether looped animation is stopped after creation.
     */
    @Test
    public void shouldBeStoppedAfterCreation() {
        // GIVEN
        testAnimation = new TestAnimation();

        // WHEN
        loopedAnimation = new LoopedAnimation(testAnimation);

        // THEN
        assertEquals(AnimationState.STOPPED, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation.getAnimationState());
    }

    /**
     * Tests whether looped animation is playing correctly.
     */
    @Test
    public void shouldBePlayingAfterPlay() {
        // GIVEN
        testAnimation = new TestAnimation();
        loopedAnimation = new LoopedAnimation(testAnimation);

        // WHEN
        loopedAnimation.play();

        // THEN
        assertEquals(AnimationState.PLAYING, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation.getAnimationState());
    }

    /**
     * Tests whether looped animation is playing in loop.
     */
    @Test
    public void shouldBePlayingInLoop() {
        // GIVEN
        testAnimation = new TestAnimation();
        loopedAnimation = new LoopedAnimation(testAnimation, 5);
        loopedAnimation.play();

        // WHEN
        testAnimation.stop();
        testAnimation.stop();
        testAnimation.stop();
        testAnimation.stop();

        // THEN
        assertEquals(AnimationState.PLAYING, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation.getAnimationState());
    }

    /**
     * Tests whether looped animation is stopping after given number of repetitions.
     */
    @Test
    public void shouldBeStoppedAfterGivenRepetitions() {
        // GIVEN
        testAnimation = new TestAnimation();
        loopedAnimation = new LoopedAnimation(testAnimation, 3);
        loopedAnimation.play();

        testAnimation.stop();
        testAnimation.stop();

        // WHEN
        testAnimation.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation.getAnimationState());
    }

    /**
     * Tests whether looped animation is pausing correctly.
     */
    @Test
    public void shouldBePausedAfterPause() {
        // GIVEN
        testAnimation = new TestAnimation();
        loopedAnimation = new LoopedAnimation(testAnimation, 3);
        loopedAnimation.play();

        // WHEN
        loopedAnimation.pause();

        // THEN
        assertEquals(AnimationState.PAUSED, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.PAUSED, testAnimation.getAnimationState());
    }

    /**
     * Tests whether looped animation is stopping correctly.
     */
    @Test
    public void shouldBeStoppedAfterStop() {
        // GIVEN
        testAnimation = new TestAnimation();
        loopedAnimation = new LoopedAnimation(testAnimation, 3);

        loopedAnimation.play();

        // WHEN
        loopedAnimation.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, loopedAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation.getAnimationState());
    }
}
