package com.atsisa.gox.framework.action.bindings.model;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;

/**
 * Input event listener mock.
 * Saves all the events for future reference
 */
public class InputEventListenerMock implements IEventListener<InputEvent> {

    /**
     * A list of saved events.
     */
    private List<InputEvent> events = new ArrayList<>();

    @Override
    public void onEvent(InputEvent event) {
        events.add(event);
    }

    /**
     * Gets a list of saved events.
     * @return a list of saved events
     */
    public List<InputEvent> getEvents() {
        return events;
    }
}
