package com.atsisa.gox.framework.animation;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link ParallelAnimation} class.
 */
public class ParallelAnimationTest {

    /**
     * Tested ParallelAnimation class object.
     */
    private ParallelAnimation parallelAnimation;

    /**
     * List of animations for parallel animation.
     */
    private List<IAnimation> animations;

    /**
     * TestAnimation objects for animations list.
     */
    private TestAnimation testAnimation1;

    private TestAnimation testAnimation2;

    private TestAnimation testAnimation3;

    private TestAnimation testAnimation4;

    @Before
    public void setUp() {
        animations = new ArrayList<>();

        testAnimation1 = new TestAnimation();
        testAnimation2 = new TestAnimation();
        testAnimation3 = new TestAnimation();
        testAnimation4 = new TestAnimation();

        animations.add(testAnimation1);
        animations.add(testAnimation2);
        animations.add(testAnimation3);
        animations.add(testAnimation4);
    }

    /**
     * Tests whether parallel animation is stopped after creation.
     */
    @Test
    public void shouldBeStoppedAfterCreation() {
        // GIVEN

        // WHEN
        parallelAnimation = new ParallelAnimation(animations);

        // THEN
        assertEquals(AnimationState.STOPPED, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is playing correctly.
     */
    @Test
    public void shouldBePlayingAfterPlay() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);

        // WHEN
        parallelAnimation.play();

        // THEN
        assertEquals(AnimationState.PLAYING, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is stopping correctly.
     */
    @Test
    public void shouldBeStoppedAfterStopping() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);
        parallelAnimation.play();

        // WHEN
        parallelAnimation.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is playing all animations correctly.
     */
    @Test
    public void shouldBePlayingAllAnimationsAfterPlay() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);

        // WHEN
        parallelAnimation.play();

        // THEN
        assertEquals(AnimationState.PLAYING, testAnimation1.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation2.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation3.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation4.getAnimationState());
    }

    /**
     * Tests whether parallel animation is stopping after stopping all animations.
     */
    @Test
    public void shouldBeStoppedAfterStoppingAllAnimations() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);
        parallelAnimation.play();

        testAnimation1.stop();
        testAnimation2.stop();
        testAnimation3.stop();

        // WHEN
        testAnimation4.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is playing until all animations are stopped.
     */
    @Test
    public void shouldBePlayingUntilLastAnimationIsStopped() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);
        parallelAnimation.play();

        testAnimation1.stop();
        testAnimation2.stop();

        // WHEN
        testAnimation3.stop();

        // THEN
        assertEquals(AnimationState.PLAYING, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is pausing correctly.
     */
    @Test
    public void shouldBePausedAfterPausing() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);
        parallelAnimation.play();

        // WHEN
        parallelAnimation.pause();

        // THEN
        assertEquals(AnimationState.PAUSED, testAnimation1.getAnimationState());
        assertEquals(AnimationState.PAUSED, testAnimation2.getAnimationState());
        assertEquals(AnimationState.PAUSED, testAnimation3.getAnimationState());
        assertEquals(AnimationState.PAUSED, testAnimation4.getAnimationState());
        assertEquals(AnimationState.PAUSED, parallelAnimation.getAnimationState());
    }

    /**
     * Tests whether parallel animation is not pausing if stopped.
     */
    @Test
    public void shouldNotPauseIfStopped() {
        // GIVEN
        parallelAnimation = new ParallelAnimation(animations);

        parallelAnimation.play();
        parallelAnimation.stop();

        // WHEN
        parallelAnimation.pause();

        // THEN
        assertEquals(AnimationState.STOPPED, testAnimation1.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation2.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation3.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation4.getAnimationState());
        assertEquals(AnimationState.STOPPED, parallelAnimation.getAnimationState());
    }
}
