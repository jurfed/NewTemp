package com.atsisa.gox.framework.action.model;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Synchronous action mock class. Mocks the validation and execution.
 */
public class SyncActionMock extends SyncAction {

    /**
     * A value indicating that the action should fail on validation.
     */
    private final boolean failValidation;

    /**
     * A value indicating that the action should fail on execution.
     */
    private final boolean failExecution;

    /**
     * Memorizes if terminate setMethod was called.
     */
    private boolean terminateCalled;

    /**
     * Initializes a new instance of the SyncActionMock.
     * @param logger         a logger reference.
     * @param eventBus       an eventBus reference.
     * @param failValidation a value indicating that the action should fail on validation
     * @param failExecution  a value indicating that the action should fail on execution
     */
    public SyncActionMock(ILogger logger, IEventBus eventBus, boolean failValidation, boolean failExecution) {
        super(logger, eventBus);
        this.failValidation = failValidation;
        this.failExecution = failExecution;
    }

    /**
     * Checks if the terminate setMethod was called.
     * @return true if terminate was called, false otherwise
     */
    public boolean isTerminateCalled() {
        return terminateCalled;
    }

    @Override
    protected void execute() {
        if (failExecution) {
            throw new UnsupportedOperationException("Execution failed!");
        }
    }

    @Override
    protected void validate() throws ValidationException {
        if (failValidation) {
            throw new ValidationException("Validation failed!");
        }
    }

    @Override
    protected void terminate() {
        terminateCalled = true;
    }
}
