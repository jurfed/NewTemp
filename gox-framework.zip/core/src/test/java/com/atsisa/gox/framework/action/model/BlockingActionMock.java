package com.atsisa.gox.framework.action.model;

import java.util.concurrent.ExecutorService;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Blocking action mock class Executes in a new thread. The action hangs until either terminate or endAction setMethod is called.
 */
public class BlockingActionMock extends Action {

    /**
     * Executor service reference.
     */
    private final ExecutorService executorService;

    /**
     * Execution monitor for synchronization purposes.
     */
    private final Object monitor = new Object();

    /**
     * Monitor readiness flag.
     */
    private boolean ready = false;

    /**
     * A value indicating usage of the terminate setMethod.
     */
    private boolean terminated = false;

    /**
     * Initializes a new instance of the BlockingActionMock class.
     * @param logger          a logger reference
     * @param eventBus        an eventBus reference
     * @param executorService thread executor service
     */
    public BlockingActionMock(ILogger logger, IEventBus eventBus, ExecutorService executorService) {
        super(logger, eventBus);
        this.executorService = executorService;
    }

    @Override
    protected void execute() {
        executorService.execute(new Runnable() {

            @Override
            public void run() {
                try {
                    while (!ready) {
                        synchronized (monitor) {
                            System.out.println(BlockingActionMock.this.toString() + " running...");
                            monitor.wait();
                            ready = true;
                        }
                    }
                    System.out.println(BlockingActionMock.this.toString() + " finishing...");
                    if (!terminated) {
                        finish();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void terminate() {
        System.out.println(this.toString() + " terminating...");
        this.terminated = true;
        synchronized (monitor) {
            ready = true;
            monitor.notifyAll();
        }
    }

    /**
     * Stops the waiting and ends the whole action.
     */
    public void endAction() {
        System.out.println(this.toString() + " Action ending requested in tests");
        synchronized (monitor) {
            ready = true;
            monitor.notifyAll();
        }
    }
}
