package com.atsisa.gox.framework.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.resource.model.ResourceManagerMock;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.converter.ResourceDescriptionConverter;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Resource manager test suite.
 */
@SuppressWarnings("unchecked")
public class ResourceManagerTests {

    /**
     * Reference to loggerMockup.
     */
    private ILogger loggerMockup;

    private IResourceFactory resourceFactory;

    private AbstractResourceManager abstractResourceManager;

    /**
     * Method invoked before each test.
     */
    @Before
    public void setUp() {
        resourceFactory = mock(IResourceFactory.class);
        IParser parser = mock(IParser.class);
        ILogger logger = mock(ILogger.class);
        IEventBus eventBus = mock(IEventBus.class);
        ResourceDescriptionConverter resourceDescriptionConverter = mock(ResourceDescriptionConverter.class);

        abstractResourceManager = new ResourceManagerMock(resourceFactory, parser, logger, resourceDescriptionConverter, eventBus);
    }

    @Test
    public void getResourceFormats_whenFormatListGiven_ReturnsFormats() {
        List<String> formatsList = new ArrayList<>();
        formatsList.add("low");
        formatsList.add("hi");
        abstractResourceManager.setResourceFormats(formatsList);

        List<String> returnFormatList = abstractResourceManager.getResourceFormats();

        assertEquals(formatsList, returnFormatList);
    }

    @Test
    public void load_whenValidResourceId_returnsIResource() {
        String resourceId = "testID";
        final AbstractImageResource abstractImageResource = mock(AbstractImageResource.class);
        when(abstractImageResource.getId()).thenReturn(resourceId);
        when(abstractImageResource.getResourceType()).thenReturn(ResourceType.IMAGE);
        List<ResourceDescription> resourceDescriptionList = new ArrayList<>();
        ResourceDescription resourceDescription = mock(ResourceDescription.class);
        resourceDescriptionList.add(resourceDescription);
        when(resourceFactory.createResource(resourceDescription)).thenReturn(abstractImageResource);
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                ((IResourceLoadingCallback) invocationOnMock.getArguments()[0]).onSuccess(abstractImageResource, 0, 1);
                return null;
            }
        }).when(abstractImageResource).load(any(IResourceLoadingCallback.class));

        abstractResourceManager.load(resourceDescriptionList);

        assertNotNull(abstractResourceManager.getResource(resourceId));
        assertNull(abstractResourceManager.getResource(resourceId, ResourceType.TEXT));
        assertNotNull(abstractResourceManager.getResource(resourceId, ResourceType.IMAGE));
    }

    @Test
    public void load_whenTwoResLoadedAndOneInvalid_loadsProperNumberOfResources() {
        List<ResourceDescription> resourceDescriptionList = new ArrayList<>();
        final AbstractTextResource validResource = mock(AbstractTextResource.class);
        ResourceDescription validResourceDescription = mock(ResourceDescription.class);
        when(resourceFactory.createResource(validResourceDescription)).thenReturn(validResource);
        AbstractTextResource invalidResource = mock(AbstractTextResource.class);
        final ResourceDescription invalidResourceDescription = mock(ResourceDescription.class);
        when(resourceFactory.createResource(invalidResourceDescription)).thenReturn(invalidResource);
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                ((IResourceLoadingCallback) invocationOnMock.getArguments()[0]).onSuccess(validResource, 0, 2);
                return null;
            }
        }).when(validResource).load(any(IResourceLoadingCallback.class));
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                ((IResourceLoadingCallback) invocationOnMock.getArguments()[0]).onError(invalidResourceDescription, 1, 2, new Throwable());
                return null;
            }
        }).when(invalidResource).load(any(IResourceLoadingCallback.class));
        resourceDescriptionList.add(validResourceDescription);
        resourceDescriptionList.add(invalidResourceDescription);
        ResourceLoadingCallbackMock resourceLoadingCallbackMock = new ResourceLoadingCallbackMock();
        abstractResourceManager.addResourceLoadingCallback(resourceLoadingCallbackMock);

        abstractResourceManager.load(resourceDescriptionList);

        assertTrue(resourceLoadingCallbackMock.isSuccess());
        assertNotNull(resourceLoadingCallbackMock.getSuccessResource());
        assertEquals(1, resourceLoadingCallbackMock.getSuccessCount());
        assertEquals(1, resourceLoadingCallbackMock.getErrorsCount());
        assertEquals(1, resourceLoadingCallbackMock.getErrorResIndex());
    }

    @Test
    public void load_whenTwoProperTextAreGiven_loadsTheBothResources() {
        List<ResourceDescription> resourceDescriptionList = new ArrayList<>();
        final AbstractMovieResource validResource = mock(AbstractMovieResource.class);
        ResourceDescription validResourceDescriptionFirst = mock(ResourceDescription.class);
        when(resourceFactory.createResource(validResourceDescriptionFirst)).thenReturn(validResource);
        ResourceDescription validResourceDescriptionSecond = mock(ResourceDescription.class);
        when(resourceFactory.createResource(validResourceDescriptionSecond)).thenReturn(validResource);
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                ((IResourceLoadingCallback) invocationOnMock.getArguments()[0]).onSuccess(validResource, 0, 1);
                return null;
            }
        }).when(validResource).load(any(IResourceLoadingCallback.class));
        resourceDescriptionList.add(validResourceDescriptionFirst);
        resourceDescriptionList.add(validResourceDescriptionSecond);
        ResourceLoadingCallbackMock resourceLoadingCallbackMock = new ResourceLoadingCallbackMock();
        abstractResourceManager.addResourceLoadingCallback(resourceLoadingCallbackMock);

        abstractResourceManager.load(resourceDescriptionList);

        assertTrue(resourceLoadingCallbackMock.isSuccess());
        assertNotNull(resourceLoadingCallbackMock.getSuccessResource());
        assertEquals(2, resourceLoadingCallbackMock.getSuccessResCount());
    }

    @Test
    public void unload_whenUnloadSpecificResource_returnsNullAfterAttemptingToGetThisResource() {
        String resourceId = "testId";
        final AbstractSoundResource resource = mock(AbstractSoundResource.class);
        when(resource.getId()).thenReturn(resourceId);
        ResourceDescription resourceDescription = mock(ResourceDescription.class);
        final List<ResourceDescription> resourceDescriptionList = new ArrayList<>();
        resourceDescriptionList.add(resourceDescription);
        when(resourceFactory.createResource(resourceDescription)).thenReturn(resource);
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                ((IResourceLoadingCallback) invocationOnMock.getArguments()[0]).onSuccess(resource, 0, 1);
                return null;
            }
        }).when(resource).load(any(IResourceLoadingCallback.class));
        ResourceLoadingCallbackMock resourceLoadingCallbackMock = new ResourceLoadingCallbackMock();
        abstractResourceManager.addResourceLoadingCallback(resourceLoadingCallbackMock);

        abstractResourceManager.load(resourceDescriptionList);
        abstractResourceManager.unload(resourceId);

        assertTrue(resourceLoadingCallbackMock.isSuccess());
        assertNotNull(resourceLoadingCallbackMock.getSuccessResource());
        assertEquals(1, resourceLoadingCallbackMock.getSuccessCount());
        assertNull(abstractResourceManager.getResource(resourceId));
    }

}
