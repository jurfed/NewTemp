package com.atsisa.gox.framework.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.action.model.BlockingActionMock;
import com.atsisa.gox.framework.action.model.BlockingStateListenerMock;
import com.atsisa.gox.framework.action.model.StateListenerMock;
import com.atsisa.gox.framework.action.model.SyncActionMock;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.QueuesResource;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.utility.IStateListener;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Tests for {@link ActionManager} class.
 */
public class ActionManagerTests {

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * EventBus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Resource manager mock.
     */
    @Mock
    private IResourceManager resourceManagerMock;

    /**
     * Action builder mock.
     */
    @Mock
    private IActionBuilder actionBuilderMock;

    /**
     * Action binder mock.
     */
    @Mock
    private IActionBinder actionBinderMock;

    /**
     * The subject of tests.
     */
    private IActionManager actionManager;

    /**
     * Executor service.
     */
    private ExecutorService executorService;

    /**
     * Blocking action mock.
     */
    private BlockingActionMock blockingAction;

    /**
     * Predefined action list with blocking action mock.
     */
    private List<Action> predefinedActions;

    private QueueMetadata predefinedQueueMetadata;

    private static final String NOT_REGISTERED_QUEUE_NAME = "NOT_REGISTERED";

    /**
     * Set up test subject and its dependencies.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        executorService = Executors.newCachedThreadPool();
        blockingAction = new BlockingActionMock(loggerMock, eventBusMock, executorService);
        predefinedActions = new ArrayList<>();
        predefinedActions.add(blockingAction);
        predefinedQueueMetadata = new QueueMetadata("anyQueue", false);
        predefinedQueueMetadata.setActions(predefinedActions);

        when(actionBuilderMock.getQueue(anyString())).thenReturn(predefinedQueueMetadata);
        when(actionBuilderMock.getQueue(NOT_REGISTERED_QUEUE_NAME)).thenReturn(null);

        actionManager = new ActionManager(loggerMock, actionBuilderMock, resourceManagerMock, actionBinderMock);
    }

    /**
     * Tests if processing an action without state listener creates proper queue structure.
     */
    @Test
    public void actionManager_whenProcessActionWithoutListener_returnsProperActionQueueId() {
        final BlockingStateListenerMock listenerMock = new BlockingStateListenerMock();

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processAction(blockingAction);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActiveQueue();
        actionQueue.addStateListener(listenerMock);
        assertEquals(thread.getQueueId(), actionQueue.getId());
        assertNotNull(actionQueue.getActions());
        assertEquals(blockingAction, actionQueue.getActions()[0]);
        assertEquals(ActionQueueState.ACTIVE, actionQueue.getState());
        blockingAction.endAction();
        listenerMock.waitForListener(ActionQueueState.FINISHED);
        assertEquals(ActionQueueState.FINISHED, actionQueue.getState());
        assertEquals(ActionState.SUCCEEDED, blockingAction.getState());
    }

    /**
     * Tests if processing an action with state listener ends with listener notifications.
     */
    @Test
    public void actionManager_whenProcessActionWithListener_returnsProperActionQueueIdAndNotifiesListener() {
        final StateListenerMock<ActionQueueState> listenerMock = new StateListenerMock<>();
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processAction(blockingAction, listenerMock);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActionQueueById(thread.getQueueId());
        actionQueue.addStateListener(blockingListener);
        assertEquals(1, listenerMock.getStates().size());
        assertEquals(ActionQueueState.ACTIVE, listenerMock.getStates().get(0));
        blockingAction.endAction();
        blockingListener.waitForListener(ActionQueueState.FINISHED);
        assertEquals(2, listenerMock.getStates().size());
        assertEquals(ActionQueueState.FINISHED, listenerMock.getStates().get(1));
    }

    /**
     * Tests if processing an action queue without state listener creates proper queue structure.
     */
    @Test
    public void actionManager_whenProcessQueueWithoutListener_returnsProperActionQueueId() {
        final List<Action> actionList = new ArrayList<>();
        actionList.add(blockingAction);
        final BlockingStateListenerMock listenerMock = new BlockingStateListenerMock();

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processQueue(actionList);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActiveQueue();
        actionQueue.addStateListener(listenerMock);
        assertNotNull(actionQueue.getActions());
        assertEquals(actionList.size(), actionQueue.getActions().length);
        assertEquals(ActionQueueState.ACTIVE, actionQueue.getState());
        blockingAction.endAction();
        listenerMock.waitForListener(ActionQueueState.FINISHED);
        assertEquals(ActionQueueState.FINISHED, actionQueue.getState());
        for (Action doneAction : actionList) {
            assertEquals(ActionState.SUCCEEDED, doneAction.getState());
        }
    }

    /**
     * Tests if processing an action queue with state listener ends with listener notifications.
     */
    @Test
    public void actionManager_whenProcessQueueWithListener_returnsProperActionQueueIdAndNotifiesListener() {
        final StateListenerMock<ActionQueueState> listenerMock = new StateListenerMock<>();
        final List<Action> actionList = new ArrayList<>();
        actionList.add(new SyncActionMock(loggerMock, eventBusMock, true, true));
        actionList.add(new SyncActionMock(loggerMock, eventBusMock, false, true));
        actionList.add(new SyncActionMock(loggerMock, eventBusMock, true, true));
        actionList.add(blockingAction);
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processQueue(actionList, listenerMock);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActionQueueById(thread.getQueueId());
        actionQueue.addStateListener(blockingListener);
        assertEquals(1, listenerMock.getStates().size());
        assertEquals(ActionQueueState.ACTIVE, listenerMock.getStates().get(0));
        blockingAction.endAction();
        blockingListener.waitForListener(ActionQueueState.FINISHED);
        assertEquals(2, listenerMock.getStates().size());
        assertEquals(ActionQueueState.FINISHED, listenerMock.getStates().get(1));
    }

    /**
     * Tests if processing an action queue from resources creates proper queue structure.
     */
    @Test
    public void actionManager_whenProcessQueueFromResources_returnsProperActionQueue() {
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();
        final String anyQueueName = "anyQueue";

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processQueue(anyQueueName, new IStateListener<ActionQueueState>() {

                    @Override
                    public void stateChanged(Object source, ActionQueueState state) {
                        switch (state) {
                            case ACTIVE:
                                for (IAction resetedAction : ((ActionQueue) source).getActions()) {
                                    assertEquals(ActionState.PENDING, resetedAction.getState());
                                }
                                break;
                            case FINISHED:
                                for (IAction resetedAction : ((ActionQueue) source).getActions()) {
                                    assertEquals(ActionState.SUCCEEDED, resetedAction.getState());
                                }
                                break;
                        }

                    }
                });
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActiveQueue();
        actionQueue.addStateListener(blockingListener);
        assertNotNull(actionQueue.getActions());
        assertEquals(1, actionQueue.getActions().length);
        assertEquals(this.blockingAction, actionQueue.getActions()[0]);
        verify(this.actionBuilderMock).getQueue(anyQueueName);
        blockingAction.endAction();
        blockingListener.waitForListener(ActionQueueState.FINISHED);
        assertEquals(ActionQueueState.FINISHED, actionQueue.getState());
        for (IAction doneAction : actionQueue.getActions()) {
            assertEquals(ActionState.SUCCEEDED, doneAction.getState());
        }
    }

    /**
     * Tests if processing an action queue from the same resource twice caches the queue.
     */
    @Test
    public void actionManager_whenProcessQueueFromResourcesTwice_cachesFirstQueueRequest() {
        final StateListenerMock<ActionQueueState> listenerMock = new StateListenerMock<>();
        final String anyQueueName = "anyQueue";

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processQueue(anyQueueName, listenerMock);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        this.actionManager.getActiveQueue();
        verify(this.actionBuilderMock, times(1)).getQueue(anyQueueName);
        blockingAction.endAction();

        executorService.execute(thread);
        await();
        this.actionManager.getActiveQueue();
        verify(this.actionBuilderMock, times(1)).getQueue(anyQueueName);
        blockingAction.endAction();
    }

    /**
     * Tests if processing an action queue from resource with listener ends with listener notifications.
     */
    @Test
    public void actionManager_whenProcessQueueFromResourcesWithCallback_returnsProperActionQueue() {
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();
        final StateListenerMock<ActionQueueState> listenerMock = new StateListenerMock<>();
        final String anyQueueName = "anyQueue";

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                long id = actionManager.processQueue(anyQueueName, listenerMock);
                setQueueId(id);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        IActionQueue actionQueue = this.actionManager.getActiveQueue();
        actionQueue.addStateListener(blockingListener);
        blockingAction.endAction();
        blockingListener.waitForListener(ActionQueueState.FINISHED);
        assertEquals(2, listenerMock.getStates().size());
        assertEquals(ActionQueueState.ACTIVE, listenerMock.getStates().get(0));
        assertEquals(ActionQueueState.FINISHED, listenerMock.getStates().get(1));
    }

    /**
     * Tests if registering the queue properly returns queue register status.
     */
    @Test
    public void actionManager_whenRegisterIsNotCalled_isRegister_returnsFalse() {
        boolean failure = actionManager.isRegistered(NOT_REGISTERED_QUEUE_NAME);

        assertFalse(failure);
    }

    /**
     * Tests if registering the queue properly returns queue register status.
     */
    @Test
    public void actionManager_whenRegisterIsCalled_isRegister_returnsTrue() {
        String queueName = "myQueue";
        QueueMetadata queueMetadata = new QueueMetadata(queueName, false);
        queueMetadata.setActions(predefinedActions);

        actionManager.registerQueue(queueName, queueMetadata);

        assertTrue(actionManager.isRegistered(queueName));
    }

    /**
     * Tests if registering the queue twice with the same name causes an error.
     */
    @Test
    public void actionManager_whenRegisterQueueCalledTwiceWithoutOverride_returnsFalse() {
        String queueName = "myQueue";
        QueueMetadata queueMetadata = new QueueMetadata(queueName, false);
        queueMetadata.setActions(predefinedActions);

        boolean success = actionManager.registerQueue(queueName, queueMetadata);
        boolean failure = actionManager.registerQueue(queueName, queueMetadata);

        assertTrue(success);
        assertFalse(failure);
    }

    /**
     * Tests if registering a single queue will be memorized.
     */
    @Test
    public void actionManager_whenRegisterQueueWithoutOverride_returnsTrue() {
        String queueName = "myQueue";
        QueueMetadata queueMetadata = new QueueMetadata(queueName, false);
        queueMetadata.setActions(predefinedActions);

        boolean success = actionManager.registerQueue(queueName, queueMetadata);

        assertTrue(success);
        String[] queueNames = actionManager.getRegisteredQueueNames();
        assertNotNull(queueNames);
        assertEquals(1, queueNames.length);
        assertEquals(queueName, queueNames[0]);
    }

    /**
     * Tests if registering the queue twice with the same name an override option turned on causes no errors.
     */
    @Test
    public void actionManager_whenRegisterQueueTwiceWithOverride_returnsTrue() {
        String queueName = "myQueue";
        QueueMetadata queueMetadata = new QueueMetadata(queueName, false);
        queueMetadata.setActions(predefinedActions);

        boolean success = actionManager.registerQueue(queueName, queueMetadata);
        boolean twice = actionManager.registerQueue(queueName, queueMetadata, true);

        assertTrue(success);
        assertTrue(twice);
    }

    /**
     * Tests if registering an action resource calls the resource manager and the action builder.
     * @throws ParseException
     */
    @Test
    public void actionManager_whenRegisterActionResourceIsCalled_callsResourceManagerAndActionBuilder() throws ParseException {
        String resourceName = "myResource";
        QueuesResource resource = mock(QueuesResource.class);
        when(this.resourceManagerMock.getResource(resourceName, ResourceType.QUEUES)).thenReturn(resource);

        this.actionManager.registerActionResource(resourceName);

        verify(this.resourceManagerMock).getResource(resourceName, ResourceType.QUEUES);
        verify(this.actionBuilderMock).addQueues(resource);
    }

    /**
     * Tests if processing multiple queues ends with pausing the first queue.
     */
    @Test
    public void actionManager_whenMultipleQueuesAreExecuted_pausesFirstAddedQueue() {
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();
        BlockingActionMock firstAction = new BlockingActionMock(loggerMock, eventBusMock, executorService);
        firstAction.setName("first");
        final List<Action> firstList = new ArrayList<>();
        firstList.add(firstAction);
        firstList.add(new SyncActionMock(loggerMock, eventBusMock, false, false));
        BlockingActionMock secondAction = new BlockingActionMock(loggerMock, eventBusMock, executorService);
        secondAction.setName("second");
        final List<Action> secondList = new ArrayList<>();
        secondList.add(secondAction);

        Thread thread = new Thread() {

            @Override
            public void run() {
                actionManager.processQueue(firstList);
                actionManager.processQueue(secondList);
                awake();
            }
        };
        executorService.execute(thread);

        await();
        assertEquals(2, actionManager.getActionQueues().size());
        assertEquals(1, actionManager.getActiveQueue().getActions().length);
        List<IActionQueue> paused = actionManager.getPausedActionQueues();
        assertEquals(1, paused.size());
        paused.get(0).addStateListener(blockingListener);
        assertEquals(2, paused.get(0).getActions().length);
        assertEquals(ActionState.TERMINATED, paused.get(0).getActions()[0].getState());
        assertEquals(ActionState.PENDING, paused.get(0).getActions()[1].getState());
        secondAction.endAction();
        blockingListener.waitForListener(ActionQueueState.FINISHED);
    }

    /**
     * Tests if destroying an active queue works.
     */
    @Test
    public void actionManager_whenDestroyQueueIsExecutedOnActiveQueue_destroysQueue() {
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();
        BlockingActionMock firstAction = new BlockingActionMock(loggerMock, eventBusMock, executorService);
        firstAction.setName("first");
        final List<Action> firstList = new ArrayList<>();
        firstList.add(firstAction);
        firstList.add(new SyncActionMock(loggerMock, eventBusMock, false, false));

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                setQueueId(actionManager.processQueue(firstList));
                awake();
            }
        };
        executorService.execute(thread);
        await();
        IActionQueue actionQueue = actionManager.getActiveQueue();
        actionQueue.addStateListener(blockingListener);
        actionManager.destroyActionQueue(actionQueue.getId());
        blockingListener.waitForListener(ActionQueueState.DESTROYED);

        assertEquals(ActionQueueState.DESTROYED, actionQueue.getState());
        for (Action action : firstList) {
            assertEquals(ActionState.TERMINATED, action.getState());
        }
    }

    /**
     * Tests if destroying a paused queue works.
     */
    @Test
    public void actionManager_whenDestroyQueueIsExecutedOnPausedQueue_destroysQueue() {
        final BlockingStateListenerMock blockingListener = new BlockingStateListenerMock();
        BlockingActionMock firstAction = new BlockingActionMock(loggerMock, eventBusMock, executorService);
        firstAction.setName("first");
        final List<Action> firstList = new ArrayList<>();
        firstList.add(firstAction);
        firstList.add(new SyncActionMock(loggerMock, eventBusMock, false, false));

        ActionManagerThread thread = new ActionManagerThread() {

            @Override
            public void run() {
                setQueueId(actionManager.processQueue(firstList));
                actionManager.processQueue("anyQueue");
                awake();
            }
        };
        executorService.execute(thread);
        await();
        IActionQueue actionQueue = actionManager.getActionQueueById(thread.getQueueId());
        actionQueue.addStateListener(blockingListener);
        assertEquals(ActionState.TERMINATED, firstList.get(0).getState());
        assertEquals(ActionState.PENDING, firstList.get(1).getState());
        actionManager.destroyActionQueue(actionQueue.getId());
        blockingListener.waitForListener(ActionQueueState.DESTROYED);
        assertEquals(ActionQueueState.DESTROYED, actionQueue.getState());
        blockingAction.endAction();
    }

    /**
     * Action manager thread. Can save queue identifier during execution.
     */
    private abstract static class ActionManagerThread extends Thread {

        private long queueId;

        public long getQueueId() {
            return queueId;
        }

        public void setQueueId(long queueId) {
            this.queueId = queueId;
        }
    }

    /**
     * Makes test wait for 'awake' setMethod call from another thread.
     */
    private void await() {
        synchronized (this) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * When called from another thread, continues the test execution path.
     */
    private void awake() {
        synchronized (this) {
            this.notify();
        }
    }
}
