package com.atsisa.gox.framework.animation;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link SequentialAnimation} class.
 */
public class SequentialAnimationTest {

    /**
     * Tested SequentialAnimation class object.
     */
    private SequentialAnimation sequentialAnimation;

    /**
     * List of animations for sequential animation.
     */
    private List<IAnimation> animations;

    /**
     * TestAnimation objects for animations list.
     */
    private TestAnimation testAnimation1;

    private TestAnimation testAnimation2;

    private TestAnimation testAnimation3;

    @Before
    public void setUp() {
        animations = new ArrayList<>();

        testAnimation1 = new TestAnimation();
        testAnimation2 = new TestAnimation();
        testAnimation3 = new TestAnimation();

        animations.add(testAnimation1);
        animations.add(testAnimation2);
        animations.add(testAnimation3);
    }

    /**
     * Tests whether animation is stopped after creation.
     */
    @Test
    public void shouldBeStoppedAfterCreation() {
        // GIVEN

        // WHEN
        sequentialAnimation = new SequentialAnimation(animations);

        // THEN
        assertEquals(AnimationState.STOPPED, sequentialAnimation.getAnimationState());
    }

    /**
     * Tests whether sequential animation and test animations are started correctly.
     */
    @Test
    public void shouldBePlayingAfterPlay() {
        // GIVEN
        sequentialAnimation = new SequentialAnimation(animations);

        // WHEN
        sequentialAnimation.play();

        // THEN
        assertEquals(AnimationState.PLAYING, sequentialAnimation.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation1.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation2.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation3.getAnimationState());
    }

    /**
     * Tests whether sequential animation and test animations are stopped correctly.
     */
    @Test
    public void shouldBeStoppedAfterStopping() {
        // GIVEN
        sequentialAnimation = new SequentialAnimation(animations);
        sequentialAnimation.play();

        // WHEN
        sequentialAnimation.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, sequentialAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation1.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation2.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation3.getAnimationState());
    }

    /**
     * Tests whether sequential animation is playing animations in right order.
     */
    @Test
    public void shouldBePlayingNextAnimationWhenOneEnds() {
        // GIVEN
        sequentialAnimation = new SequentialAnimation(animations);
        sequentialAnimation.play();

        // WHEN
        testAnimation1.stop();

        // THEN
        assertEquals(AnimationState.PLAYING, sequentialAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation1.getAnimationState());
        assertEquals(AnimationState.PLAYING, testAnimation2.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation3.getAnimationState());
    }

    /**
     * Tests whether sequential animation is stopping after stopping of last animation.
     */
    @Test
    public void shouldBeStoppedAfterEndOfLastAnimation() {
        // GIVEN
        sequentialAnimation = new SequentialAnimation(animations);
        sequentialAnimation.play();

        testAnimation1.stop();
        testAnimation2.stop();

        // WHEN
        testAnimation3.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, sequentialAnimation.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation1.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation2.getAnimationState());
        assertEquals(AnimationState.STOPPED, testAnimation3.getAnimationState());
    }
}
