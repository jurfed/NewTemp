package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.rendering.layer.ILayerFactory;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.atsisa.gox.framework.view.View;
import com.google.inject.Inject;

/**
 * A test renderer.
 */
public class TestRenderer extends AbstractRenderer {

    /**
     * Interval multiplier in from milliseconds to microseconds.
     */
    public static final int MILLISECOND_IN_MICROSECONDS = 1000;

    /**
     * The root view.
     */
    private View rootView;

    /**
     * Initializes a new instance of the AbstractRenderer class.
     * @param reflection        reflection helper reference
     * @param logger            logger reference
     * @param layerFactory      layer factory reference
     * @param gameConfiguration the game configuration.
     */
    @Inject
    public TestRenderer(IReflection reflection, ILogger logger, ILayerFactory layerFactory, IGameConfiguration gameConfiguration, IViewManager viewManager) {
        super(reflection, logger, layerFactory, gameConfiguration, viewManager);
    }

    @Override
    public int getFPS() {
        return 0;
    }

    @Override
    public void initializeViewRenderers() {
    }

    @Override
    public void setRootView(View view) {
        rootView = view;
    }

    @Override
    public boolean hasGL() {
        return true;
    }

    @Override
    public <T extends ILayer> IInputEventDelegate<T> getTouchInputEventDelegate() {
        return TestInputDelegate.SINGLETON;
    }

    @Override
    public <T extends ILayer> IInputEventDelegate<T> getKeyboardInputEventDelegate() {
        return TestInputDelegate.SINGLETON;
    }

    /**
     * Advances the renderer in time by given number of milliseconds.
     * @param milliseconds The number of milliseconds to advance.
     */
    public void advanceTimeBy(final float milliseconds) {
        notifyGameLoopStep(milliseconds / MILLISECOND_IN_MICROSECONDS);
    }

}
