package com.atsisa.gox.framework.resource;

/**
 * Resource loading callback mockup.
 * Counts the number of successes and errors and registers the last parameters
 * for error/success callback.
 */
public class ResourceLoadingCallbackMock extends ResourceLoadingCallbackAdapter {

    /**
     * It checks whether onError was invoked.
     */
    private boolean error;

    /**
     * The resource description reference for error callback.
     */
    private ResourceDescription errorResourceDescription;

    /**
     * Index of unsuccessfully loaded resource.
     */
    private int errorResIndex;

    /**
     * Number of resources.
     */
    private int errorResCount;

    /**
     * It checks whether onSuccess was invoked.
     */
    private boolean success;

    /**
     * Reference to loaded resource.
     */
    private IResource successResource;

    /**
     * Index of successfully loaded resource.
     */
    private int successResIndex;

    /**
     * Number of resources.
     */
    private int successResCount;

    /**
     * Number of unsuccessful resource counts.
     */
    private int errorsCount;

    /**
     * Number of successful resource counts.
     */
    private int successCount;

    /**
     * It checks whether the order is correct.
     */
    private boolean isCorrectOrder;

    /**
     * It checks whether all resources was loaded.
     */
    private int notifyAllAfter;

    /**
     * Variable used for storing time of timeout.
     */
    private int timeout;

    /**
     * It stores information whether timeout has finished.
     */
    private boolean ready;

    /**
     * Initializes a new instance of the ResourceLoadingCallbackMock.
     */
    public ResourceLoadingCallbackMock() {
        this.successResIndex = -1;
        this.errorResIndex = -1;
        this.isCorrectOrder = true;
        this.notifyAllAfter = 1;
        this.timeout = 500;
    }

    /**
     * Initializes a new instance of the ResourceLoadingCallbackMock
     * @param notifyAllAfter The number of success or error callbacks after which the test should be waken up.
     * @param timeout        The timeout of resource callback.
     */
    public ResourceLoadingCallbackMock(int notifyAllAfter, int timeout) {
        this.notifyAllAfter = notifyAllAfter;
        this.timeout = timeout;
    }

    @Override
    public void onError(ResourceDescription description, int resIndex, int resCount, Throwable cause) {
        this.errorsCount++;
        error = true;
        errorResourceDescription = description;
        if (resIndex != errorResIndex + 1) {
            isCorrectOrder = false;
        }
        errorResIndex = resIndex;
        errorResCount = resCount;
        if (resIndex == this.notifyAllAfter - 1) {
            synchronized (this) {
                this.notifyAll();
            }
        }
    }

    @Override
    public void onSuccess(IResource resource, int resIndex, int resCount) {
        this.successCount++;
        success = true;
        successResource = resource;
        if (resIndex != successResIndex + 1) {
            isCorrectOrder = false;
        }
        successResIndex = resIndex;
        successResCount = resCount;

        if (resIndex == this.notifyAllAfter - 1) {
            synchronized (this) {
                ready = true;
                this.notifyAll();
            }
        }
    }

    /**
     * Gets the flag indicating error occurrence.
     * @return true if an error occurred, false otherwise.
     */
    public boolean isError() {
        return error;
    }

    /**
     * Gets the resource description reference for error callback.
     * @return the resource description reference for error callback
     */
    public ResourceDescription getErrorResourceDescription() {
        return errorResourceDescription;
    }

    /**
     * Gets the resource index of the last error callback.
     * @return the resource index of the last error callback.
     */
    public int getErrorResIndex() {
        return errorResIndex;
    }

    /**
     * Gets the resource count on error callback.
     * @return the resource count on error callback.
     */
    public int getErrorResCount() {
        return errorResCount;
    }

    /**
     * Gets the flag indicating success occurrence.
     * @return true if no error occurred, false otherwise.
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Gets the resource reference of the last success callback.
     * @return the resource reference of the last success callback.
     */
    public IResource getSuccessResource() {
        return successResource;
    }

    /**
     * Gets the resource index of the last success callback.
     * @return the resource index of the last success callback.
     */
    public int getSuccessResIndex() {
        return successResIndex;
    }

    /**
     * Gets the resource count on success callback.
     * @return the resource count on success callback.
     */
    public int getSuccessResCount() {
        return successResCount;
    }

    /**
     * Gets the number of error callbacks.
     * @return the number of error callbacks
     */
    public int getErrorsCount() {
        return errorsCount;
    }

    /**
     * Gets the number of success callbacks.
     * @return the number of success callbacks
     */
    public int getSuccessCount() {
        return successCount;
    }

    public boolean isCorrectOrder() {
        return isCorrectOrder;
    }

}
