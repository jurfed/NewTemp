package com.atsisa.gox.framework.resource.model;

import java.util.HashSet;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.resource.AbstractResourceManager;
import com.atsisa.gox.framework.resource.IResourceFactory;
import com.atsisa.gox.framework.resource.IResourceLoadingCallback;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.converter.ResourceDescriptionConverter;
import com.atsisa.gox.framework.utility.logger.ILogger;

public class ResourceManagerMock extends AbstractResourceManager {

    public ResourceManagerMock(IResourceFactory resourceFactory, IParser parser, ILogger logger, ResourceDescriptionConverter resourceDescriptionConverter,
            IEventBus eventBus) {
        super(resourceFactory, parser, logger, resourceDescriptionConverter, eventBus, new HashSet<>());
    }

    @Override
    public String getFullResourcePath(String resourceTargetPath) {
        return null;
    }
}
