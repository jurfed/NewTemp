package com.atsisa.gox.framework.rendering;

import com.atsisa.gox.framework.rendering.layer.ILayer;
import com.atsisa.gox.framework.view.InteractiveView;

public class TestInputDelegate<T extends ILayer> implements IInputEventDelegate<T> {

    public final static IInputEventDelegate SINGLETON = new TestInputDelegate<>();

    @Override
    public void bind(InteractiveView interactiveView, T layer) {

    }

    @Override
    public void unbind(InteractiveView interactiveView) {

    }

    @Override
    public boolean pause() {
        return true;
    }

    @Override
    public boolean resume() {
        return true;
    }

    @Override
    public InputEventDelegateState getState() {
        return InputEventDelegateState.ACTIVE;
    }

    @Override
    public void clear() {

    }
}