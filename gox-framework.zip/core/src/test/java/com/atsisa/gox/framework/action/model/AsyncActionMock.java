package com.atsisa.gox.framework.action.model;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Asynchronous action mock.
 */
public class AsyncActionMock extends Action {

    /**
     * A value indicating that the action should fail on execution.
     */
    private final boolean failExecution;

    /**
     * Initializes a new instance of the AsyncActionMock class.
     * @param logger        a logger reference.
     * @param eventBus      an eventBus reference.
     * @param failExecution a value indicating that the action should fail on execution
     */
    public AsyncActionMock(ILogger logger, IEventBus eventBus, boolean failExecution) {
        super(logger, eventBus);
        this.failExecution = failExecution;
    }

    @Override
    protected void execute() {
        if (failExecution) {
            fail(new Exception("Execution fail"));
        } else {
            finish();
        }
    }
}
