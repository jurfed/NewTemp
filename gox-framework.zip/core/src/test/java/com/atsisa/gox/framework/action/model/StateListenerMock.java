package com.atsisa.gox.framework.action.model;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.utility.IStateListener;

/**
 * State listener mock class.
 * Memorizes all transitions between states in form of list.
 */
public class StateListenerMock<T extends Enum> implements IStateListener<T> {

    /**
     * A list of states.
     */
    private List<T> states;

    /**
     * Initializes a new instance of the StateListenerMock.
     */
    public StateListenerMock() {
        this.states = new ArrayList<>();
    }

    @Override
    public void stateChanged(Object source, T state) {
        this.states.add(state);
    }

    /**
     * Gets a list of memorized state transitions.
     * @return a list of memorized state transitions
     */
    public List<T> getStates() {
        return states;
    }

    /**
     * Clears the list of state transitions.
     */
    public void clear() {
        this.states.clear();
    }
}
