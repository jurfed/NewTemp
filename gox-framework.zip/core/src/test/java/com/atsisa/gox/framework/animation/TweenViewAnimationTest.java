package com.atsisa.gox.framework.animation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.view.View;

import aurelienribon.tweenengine.Tween;

/**
 * Tests for {@link TweenViewAnimation} class.
 */
public class TweenViewAnimationTest {

    /**
     * Tween attributes limit.
     */
    private static final int TWEEN_ATTRIBUTES_LIMIT = 8;

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Animation controller mock.
     */
    @Mock
    private IAnimationController<TweenAnimation> controllerMock;

    /**
     * Animation target mock.
     */
    @Mock
    private View animationTargetMock;

    /**
     * Sets up tests.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        Tween.setCombinedAttributesLimit(TWEEN_ATTRIBUTES_LIMIT);
    }

    /**
     * Tests whether the animation reacts when there is no view to animate.
     */
    @Test
    public void shouldNotPlayWhenTargetViewNotSet() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);

        // WHEN
        exception.expect(IllegalStateException.class);
        tweenViewAnimation.play();
    }

    /**
     * Tests whether the animation is paused properly.
     */
    @Test
    public void shouldPauseWhenPlayingAndPauseRequest() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);
        tweenViewAnimation.play();

        // WHEN
        tweenViewAnimation.pause();

        // THEN
        assertEquals(AnimationState.PAUSED, tweenViewAnimation.getAnimationState());
        verify(controllerMock, times(1)).pause(tweenViewAnimation);
    }

    /**
     * Tests whether the animation is resumed properly.
     */
    @Test
    public void shouldContinuePlayingWhenPlayAfterPause() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);
        tweenViewAnimation.play();
        tweenViewAnimation.pause();

        // WHEN
        tweenViewAnimation.play();

        // THEN
        assertEquals(AnimationState.PLAYING, tweenViewAnimation.getAnimationState());
        verify(controllerMock, times(1)).resume(tweenViewAnimation);
    }

    /**
     * Tests whether the animation is stopped properly.
     */
    @Test
    public void shouldStopWhenPlaying() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);
        tweenViewAnimation.play();

        // WHEN
        tweenViewAnimation.stop();

        // THEN
        assertEquals(AnimationState.STOPPED, tweenViewAnimation.getAnimationState());
        verify(controllerMock, times(1)).stop(tweenViewAnimation);
    }

    /**
     * Tests whether the controller does not play already playing animation.
     */
    @Test
    public void shouldNotPlayWhenAlreadyPlaying() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);
        tweenViewAnimation.play();

        // WHEN
        tweenViewAnimation.play();

        // THEN
        verify(controllerMock, times(1)).play(tweenViewAnimation);
    }

    /**
     * Tests whether the controller does not stop already stopped animation.
     */
    @Test
    public void shouldNotStopWhenAlreadyStopped() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);

        // WHEN
        tweenViewAnimation.stop();

        // THEN
        verify(controllerMock, never()).stop(tweenViewAnimation);
    }

    /**
     * Tests whether the controller does not pause already paused animation.
     */
    @Test
    public void shouldNotPauseWhenAlreadyPaused() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);
        tweenViewAnimation.play();
        tweenViewAnimation.pause();

        // WHEN
        tweenViewAnimation.pause();

        // THEN
        verify(controllerMock, times(1)).pause(tweenViewAnimation);
    }

    /**
     * Tests whether the controller does not pause stopped animation.
     */
    @Test
    public void shouldNotPauseWhenStopped() {
        // GIVEN
        TweenViewAnimation tweenViewAnimation = new TweenViewAnimation(controllerMock);
        tweenViewAnimation.setTargetView(animationTargetMock);

        // WHEN
        tweenViewAnimation.pause();

        // THEN
        verify(controllerMock, never()).pause(tweenViewAnimation);
    }
}
