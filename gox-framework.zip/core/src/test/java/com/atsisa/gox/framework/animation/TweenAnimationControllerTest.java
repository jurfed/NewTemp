package com.atsisa.gox.framework.animation;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.rendering.IRenderer;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;

/**
 * Tests for {@link TweenAnimationController} class.
 */
public class TweenAnimationControllerTest {

    /**
     * Tween manager mock.
     */
    @Mock
    private TweenManager tweenManagerMock;

    /**
     * Tween manager mock.
     */
    @Mock
    private BaseTween<Tween> tweenMock;

    /**
     * Renderer mock.
     */
    @Mock
    private IRenderer rendererMock;

    /**
     * Platform mock.
     */
    @Mock
    private IPlatform platformMock;

    /**
     * EventBus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Tween view animation.
     */
    @Mock
    private TweenViewAnimation tweenViewAnimationMock;

    /**
     * Sets up the tween.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(tweenViewAnimationMock.getTween()).thenReturn(tweenMock);
    }

    /**
     * Tests whether controller is registered as game loop listener when constructed.
     */
    @Test
    public void shouldRegisterWithinRendererWhenConstructed() {
        // WHEN
        TweenAnimationController controller = getTweenAnimationController();

        // THEN
        verify(rendererMock).addGameLoopListener(eq(controller));
    }

    /**
     * Tests whether the tween is started properly.
     */
    @Test
    public void shouldStartTweenWhenPlayRequested() {
        // GIVEN
        TweenAnimationController controller = getTweenAnimationController();
        doAnswer(new Answer() {

            @Override
            public Object answer(InvocationOnMock invocationOnMock) throws Throwable {
                tweenMock.start(tweenManagerMock);
                return null;
            }
        }).when(platformMock).invokeLaterRendering(any(Runnable.class));

        // WHEN
        controller.play(tweenViewAnimationMock);

        // THEN
        verify(tweenMock, times(1)).start(eq(tweenManagerMock));
    }

    /**
     * Tests whether the tween is paused properly.
     */
    @Test
    public void shouldPauseTweenWhenPauseRequested() {
        // GIVEN
        TweenAnimationController controller = getTweenAnimationController();

        // WHEN
        controller.pause(tweenViewAnimationMock);

        // THEN
        verify(tweenMock, times(1)).pause();
    }

    /**
     * Tests whether the tween is resumed properly.
     */
    @Test
    public void shouldResumeTweenWhenResumeRequested() {
        // GIVEN
        TweenAnimationController controller = getTweenAnimationController();

        // WHEN
        controller.resume(tweenViewAnimationMock);

        // THEN
        verify(tweenMock, times(1)).resume();
    }

    /**
     * Tests whether the tween is stopped properly.
     */
    @Test
    public void shouldKillTweenWhenStopRequested() {
        // GIVEN
        TweenAnimationController controller = getTweenAnimationController();

        // WHEN
        controller.stop(tweenViewAnimationMock);

        // THEN
        verify(tweenMock, times(1)).kill();
    }

    /**
     * Tests whether the tween manager is updated with proper pace.
     */
    @Test
    public void shouldUpdateTweenManagerWithProperPaceWhenUpdated() {
        // GIVEN
        TweenAnimationController controller = getTweenAnimationController();

        // WHEN
        controller.onUpdate(1);

        // THEN
        verify(tweenManagerMock, times(1)).update(1000);
    }

    /**
     * Gets a Tween animation controller instance.
     * @return a Tween animation controller instance.
     */
    private TweenAnimationController getTweenAnimationController() {
        return new TweenAnimationController(tweenManagerMock, rendererMock, platformMock);
    }
}
