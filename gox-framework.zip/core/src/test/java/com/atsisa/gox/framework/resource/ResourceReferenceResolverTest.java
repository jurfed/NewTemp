package com.atsisa.gox.framework.resource;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the {@link ResourceReferenceResolver class}.
 */
public class ResourceReferenceResolverTest {

    /**
     * The root resource.
     */
    private IResource root;

    /**
     * The child resource.
     */
    private ICompositeResourceReference child;

    /**
     * The grandchild resource.
     */
    private IResourceReference grandchild;

    /**
     * A map of available resources.
     */
    private HashMap<String, IResource> availableResources;

    /**
     * Sets up the resources.
     */
    @Before
    public void setUp() {
        ICompositeResourceReference root = mock(ICompositeResourceReference.class, withSettings().extraInterfaces(IResource.class));
        when(root.getId()).thenReturn("root");
        when(root.getResourceType()).thenReturn(ResourceType.SPRITE_SHEET);
        child = mock(ICompositeResourceReference.class);
        when(child.getId()).thenReturn("root.child");
        grandchild = mock(IResourceReference.class);
        when(grandchild.getId()).thenReturn("root.child.grandchild");
        when(root.getChildResource(eq("child"))).thenReturn(child);
        when(child.getChildResource(eq("grandchild"))).thenReturn(grandchild);
        this.root = (IResource) root;
        availableResources = new HashMap<>();
        availableResources.put("root", this.root);

    }

    /**
     * Tests whether a resource without children is resolved properly.
     */
    @Test
    public void shouldResolveResourceWithoutChild() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);

        // WHEN
        IResourceReference resourceName = resolver.resolve("@SpriteSheet/root");

        // THEN
        assertNotNull(resourceName);
        assertEquals(root, resourceName);
    }

    /**
     * Tests whether the composite resource is resolved properly.
     */
    @Test
    public void shouldResolveResourceFromItsComposite() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);

        // WHEN
        IResourceReference resourceName = resolver.resolve("@SpriteSheet/root/child/grandchild");

        // THEN
        assertNotNull(resourceName);
        assertEquals(grandchild, resourceName);
    }

    /**
     * Tests whether the composite resource discards missing sub-resources.
     */
    @Test
    public void shouldNotFoundResourceWhenSubPathIsInvalid() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);

        // WHEN
        IResourceReference resourceName = resolver.resolve("@SpriteSheet/root/missing");

        // THEN
        assertNull(resourceName);
    }

    /**
     * Tests whether the composite resource type is considered during resolution.
     */
    @Test
    public void shouldNotFoundResourceWhenResourceTypeMismatches() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);

        // WHEN
        IResourceReference resourceName = resolver.resolve("@Image/root/child/grandchild");

        // THEN
        assertNull(resourceName);
    }

    /**
     * Tests whether resolver discards null references.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shouldDiscardNullReference() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);
        String reference = null;

        // WHEN
        resolver.resolve(reference);
    }

    /**
     * Tests whether resolver discards references without at sign.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shouldDiscardReferenceWithoutAtSign() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);
        String reference = "SpriteSheet/spriteName";

        // WHEN
        resolver.resolve(reference);
    }

    /**
     * Tests whether resolver discards references without slashes.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shouldDiscardReferenceWithoutSlashes() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);
        String reference = "@SpriteSheet.spriteName";

        // WHEN
        resolver.resolve(reference);
    }

    /**
     * Tests whether resolver discards references with empty identifier.
     */
    @Test(expected = IllegalArgumentException.class)
    public void shouldDiscardReferenceWithEmptyId() {
        // GIVEN
        ResourceReferenceResolver resolver = new ResourceReferenceResolver(availableResources);
        String reference = "@SpriteSheet/";

        // WHEN
        resolver.resolve(reference);
    }
}
