package com.atsisa.gox.framework.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.action.model.AsyncActionMock;
import com.atsisa.gox.framework.action.model.StateListenerMock;
import com.atsisa.gox.framework.action.model.SyncActionMock;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Tests for Action class.
 */
public class ActionTests {

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * EventBus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Sets up dependencies.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Tests if getQualifiedName returns proper name without parent bundle.
     */
    @Test
    public void action_whenGetQualifiedNameWithoutParentBundleAction_returnsProperQN() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, false, false);
        action.setQueueIndex(5);

        String qn = action.getQualifiedName();

        assertEquals("5", qn);
        assertFalse(action.isFinished());
        assertEquals(ActionState.PENDING, action.getState());
    }

    /**
     * Tests if getQualifiedName returns proper name with parent bundle.
     */
    @Test
    public void action_whenGetQualifiedNameWithParentBundleAction_returnsProperQN() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, false, false);
        action.setQueueIndex(5);
        BundleAction bundleAction = new BundleAction(loggerMock, eventBusMock);
        bundleAction.setQueueIndex(1);
        BundleActionData bundleActionData = new BundleActionData();
        bundleActionData.setActions(Arrays.asList(action));
        bundleAction.setActionData(bundleActionData);
        action.setParentBundleAction(bundleAction);

        String qn = action.getQualifiedName();

        assertEquals("1.BundleAction[5]", qn);
        assertFalse(action.isFinished());
        assertEquals(ActionState.PENDING, action.getState());
    }

    /**
     * Tests if execution of invalid action will fail.
     */
    @Test
    public void syncAction_whenValidationFails_notifiesListenerAboutErrors() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, true, true);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        action.doExecute();

        List<ActionState> stateList = listener.getStates();
        assertEquals(1, stateList.size());
        assertEquals(ActionState.FAILED, stateList.get(0));
        assertEquals(ActionState.FAILED, action.getState());
        assertTrue(action.isFinished());
        assertNotNull(action.getError());
    }

    /**
     * Tests if execution of action that throws an exception will fail.
     */
    @Test
    public void syncAction_whenExecutionFails_notifiesListenerAboutErrors() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, false, true);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        action.doExecute();

        List<ActionState> stateList = listener.getStates();
        assertEquals(3, stateList.size());
        assertEquals(ActionState.VALIDATED, stateList.get(0));
        assertEquals(ActionState.ACTIVE, stateList.get(1));
        assertEquals(ActionState.FAILED, stateList.get(2));
        assertEquals(ActionState.FAILED, action.getState());
        assertTrue(action.isFinished());
        assertNotNull(action.getError());
    }

    /**
     * Tests if execution of a valid action will end with a success.
     */
    @Test
    public void syncAction_whenExecutionSucceeds_notifiesListenerAboutSuccess() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, false, false);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        action.doExecute();

        List<ActionState> stateList = listener.getStates();
        assertEquals(3, stateList.size());
        assertEquals(ActionState.VALIDATED, stateList.get(0));
        assertEquals(ActionState.ACTIVE, stateList.get(1));
        assertEquals(ActionState.SUCCEEDED, stateList.get(2));
        assertEquals(ActionState.SUCCEEDED, action.getState());
        assertTrue(action.isFinished());
        assertNull(action.getError());
    }

    /**
     * Tests if action termination works properly.
     */
    @Test
    public void syncAction_whenTerminated_notifiesListenerAboutTermination() {
        SyncActionMock action = new SyncActionMock(loggerMock, eventBusMock, false, false);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        ((Action) action).doTerminate();

        List<ActionState> stateList = listener.getStates();
        assertEquals(1, stateList.size());
        assertEquals(ActionState.TERMINATED, stateList.get(0));
        assertEquals(ActionState.TERMINATED, action.getState());
        assertTrue(action.isFinished());
        assertTrue(action.isTerminateCalled());
        assertNull(action.getError());
    }

    /**
     * Tests if resetting an action causes clearing the state and error messages.
     */
    @Test
    public void syncAction_whenReset_clearsErrorAndSetStateToPending() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, true, true);

        action.doExecute();
        action.doReset();

        assertNull(action.getError());
        assertEquals(ActionState.PENDING, action.getState());
    }

    /**
     * Tests if asynchronous action can gracefully fail.
     */
    @Test
    public void asyncAction_whenExecutionFails_notifiesListenerAboutErrors() {
        Action action = new AsyncActionMock(loggerMock, eventBusMock, true);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        action.doExecute();

        List<ActionState> stateList = listener.getStates();
        assertEquals(3, stateList.size());
        assertEquals(ActionState.VALIDATED, stateList.get(0));
        assertEquals(ActionState.ACTIVE, stateList.get(1));
        assertEquals(ActionState.FAILED, stateList.get(2));
        assertEquals(ActionState.FAILED, action.getState());
        assertNotNull(action.getError());
    }

    /**
     * Tests if asynchronous action can end with a success.
     */
    @Test
    public void asyncAction_whenExecutionSucceeds_notifiesListenerAboutSuccess() {
        Action action = new AsyncActionMock(loggerMock, eventBusMock, false);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);

        action.doExecute();

        List<ActionState> stateList = listener.getStates();
        assertEquals(3, stateList.size());
        assertEquals(ActionState.VALIDATED, stateList.get(0));
        assertEquals(ActionState.ACTIVE, stateList.get(1));
        assertEquals(ActionState.SUCCEEDED, stateList.get(2));
        assertEquals(ActionState.SUCCEEDED, action.getState());
        assertNull(action.getError());
    }

    /**
     * Tests if listener can be propertly removed.
     */
    @Test
    public void syncAction_whenListenerRemoved_doesNotNotifyAnymore() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, true, true);
        StateListenerMock<ActionState> listener = new StateListenerMock<>();
        action.addStateListener(listener);
        assertTrue(action.hasStateListeners());
        action.doExecute();
        listener.clear();

        action.removeStateListener(listener);

        assertEquals(0, listener.getStates().size());
        assertFalse(action.hasStateListeners());
    }

    /**
     * Tests if toString setMethod produces proper action description.
     */
    @Test
    public void syncAction_whenToString_usesEitherNameOrClass() {
        Action action = new SyncActionMock(loggerMock, eventBusMock, true, true);

        String str = action.toString();
        assertTrue(str.contains("com.atsisa.gox.framework.action"));
        action.setName("aaa");
        str = action.toString();
        assertTrue(str.startsWith("aaa"));
    }
}
