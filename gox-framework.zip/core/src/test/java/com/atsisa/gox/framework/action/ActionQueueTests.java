package com.atsisa.gox.framework.action;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.action.model.StateListenerMock;
import com.atsisa.gox.framework.action.model.SyncActionMock;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ActionQueueStateException;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Tests for ActionQueue class.
 */
public class ActionQueueTests {

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * EventBus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Sets up dependencies.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Tests if action queue on null action array throws an exception.
     */
    @Test(expected = ActionQueueStateException.class)
    public void actionQueue_whenPassingNullActionArray_throwsActionQueueStateException() {
        Action[] actions = null;

        new ActionQueue(actions, 1L, loggerMock, "myQueue");
    }

    /**
     * Tests if action queue on empty action array throws an exception.
     */
    @Test(expected = ActionQueueStateException.class)
    public void actionQueue_whenPassingEmptyActionArray_throwsActionQueueStateException() {
        Action[] actions = new Action[0];

        new ActionQueue(actions, 1L, loggerMock, "myQueue");
    }

    /**
     * Tests if action queue on action array with nulls throws an exception.
     */
    @Test(expected = ActionQueueStateException.class)
    public void actionQueue_whenPassingArrayWithNullElements_throwsActionQueueStateException() {
        Action[] actions = new Action[5];
        actions[0] = new BundleAction(loggerMock, eventBusMock);

        new ActionQueue(actions, 1L, loggerMock, "myQueue");
    }

    /**
     * Tests if getting action names works.
     */
    @Test
    public void actionQueue_whenGetActionNamesIsCalled_returnsArrayWithActionNames() {
        Action[] actions = new Action[1];
        actions[0] = new SyncActionMock(loggerMock, eventBusMock, false, false);
        actions[0].setName("Act");
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");

        String[] actionNames = queue.getActionNames();

        assertEquals(ActionQueueState.PENDING, queue.getState());
        assertNotNull(actionNames);
        assertEquals(1, actionNames.length);
        assertEquals("Act", actionNames[0]);
    }

    /**
     * Tests if getting action as strings works.
     */
    @Test
    public void actionQueue_whenGetActionToStringListIsCalled_returnsArrayWithActionNames() {
        Action[] actions = new Action[1];
        actions[0] = new SyncActionMock(loggerMock, eventBusMock, false, false);
        actions[0].setName("Act");
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");

        String[] actionNames = queue.getActionToStringList();

        assertEquals(ActionQueueState.PENDING, queue.getState());
        assertNotNull(actionNames);
        assertEquals(1, actionNames.length);
        assertTrue(actionNames[0].startsWith("Act"));
        assertTrue(actionNames[0].contains("com.atsisa.gox.framework.action"));
    }

    /**
     * Tests if sample queue processing works.
     */
    @Test
    public void actionQueue_whenProcessMethodCalled_executesAllActionsAndCallsListener() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false),
                new SyncActionMock(loggerMock, eventBusMock, false, false) };
        StateListenerMock<ActionQueueState> listener = new StateListenerMock<>();
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");
        queue.addStateListener(listener);

        queue.process();

        assertNotNull(queue.getActions());
        assertEquals(2, queue.getActions().length);
        for (IAction action : queue.getActions()) {
            assertEquals(ActionState.SUCCEEDED, action.getState());
        }
        List<ActionQueueState> states = listener.getStates();
        assertEquals(2, states.size());
        assertEquals(ActionQueueState.ACTIVE, states.get(0));
        assertEquals(ActionQueueState.FINISHED, states.get(1));
    }

    /**
     * Tests if pausing on not active queue causes an error.
     */
    @Test(expected = ActionQueueStateException.class)
    public void actionQueue_whenPausedAndInPendingState_throwsActionQueueStateException() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false) };
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");

        queue.pause();
    }

    /**
     * Tests if multiple processing of the same queue causes an error.
     */
    @Test(expected = ActionQueueStateException.class)
    public void actionQueue_whenProcessMethodCalledTwice_throwsActionQueueStateException() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false) };
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");

        queue.process();
        queue.process();
    }

    /**
     * Tests if destroying a queue works.
     */
    @Test
    public void actionQueue_whenDestroyIsCalled_throwsActionQueueStateException() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false) };
        StateListenerMock<ActionQueueState> listener = new StateListenerMock<>();
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");
        queue.addStateListener(listener);

        queue.destroy();

        assertEquals(ActionQueueState.DESTROYED, queue.getState());
    }

    /**
     * Tests toString setMethod on an action queue.
     */
    @Test
    public void actionQueue_whenToString_usesEitherNameOrClass() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false) };
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");

        String str = queue.toString();
        assertTrue(str.contains("com.atsisa.gox.framework.action"));
        assertTrue(str.startsWith("myQueue"));
    }

    /**
     * Tests if stopping further processing works.
     */
    @Test
    public void actionQueue_whenStopFurtherProcessingIsCalledOnAction_skipsRemainingActions() {
        Action[] actions = new Action[] { new SyncActionMock(loggerMock, eventBusMock, false, false),
                new SyncActionMock(loggerMock, eventBusMock, false, false) };
        actions[0].cancelFurtherProcessing();
        StateListenerMock<ActionQueueState> listener = new StateListenerMock<>();
        ActionQueue queue = new ActionQueue(actions, 1L, loggerMock, "myQueue");
        queue.addStateListener(listener);

        queue.process();

        List<ActionQueueState> states = listener.getStates();
        assertEquals(2, states.size());
        assertEquals(ActionQueueState.ACTIVE, states.get(0));
        assertEquals(ActionQueueState.FINISHED, states.get(1));
        assertEquals(ActionState.SUCCEEDED, actions[0].getState());
        assertEquals(ActionState.PENDING, actions[1].getState());
    }
}
