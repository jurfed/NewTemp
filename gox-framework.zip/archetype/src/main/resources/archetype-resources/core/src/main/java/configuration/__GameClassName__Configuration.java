#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.configuration;

import com.atsisa.gox.framework.configuration.GameConfiguration;

public class ${GameClassName}Configuration extends GameConfiguration {

    public ${GameClassName}Configuration() {
        setResourcePath("${GameClassName}/");
        setWidth(800);
        setHeight(600);
        setWindowDecorated(true);
        setGameName("${GameName}");
    }
}
