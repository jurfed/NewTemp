package ${package};

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.inject.AbstractModule;
import ${package}.configuration.${GameClassName}Configuration;
import ${package}.screen.MainScreen;

/**
 * Represents an IoC module configuration.
 */
public class ${GameClassName}CoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(${GameClassName}.class).asEagerSingleton();
        bind(IGame.class).to(${GameClassName}.class).asEagerSingleton();
        bind(AbstractGame.class).to(${GameClassName}.class).asEagerSingleton();
        bind(IGameConfiguration.class).to(${GameClassName}Configuration.class).asEagerSingleton();

        bindConstant().named(MainScreen.LAYOUT_ID).to("mainscreen");

        bind(Screen.class).to(MainScreen.class).asEagerSingleton();
    }
}
