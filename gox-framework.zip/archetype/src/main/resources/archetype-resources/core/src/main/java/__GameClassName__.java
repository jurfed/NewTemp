#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import com.atsisa.gox.framework.AbstractGame;

public class ${GameClassName} extends AbstractGame {

    @Override
    public void onStart() {
        getEngine().getViewManager().getScreenById("mainscreen").show();
    }
}
