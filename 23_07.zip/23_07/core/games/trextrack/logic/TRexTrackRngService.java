package com.atsisa.gox.games.trextrack.logic;
import java.util.Random;

import com.atsisa.gox.rng.IRngService;
import com.atsisa.gox.rng.RngServiceException;

public class TRexTrackRngService implements IRngService {

    private Random rng;

    public TRexTrackRngService(){
        this.rng = new Random();
    }

    @Override
    public int getRandomNumber() throws RngServiceException {
        return rng.nextInt();
    }

    @Override
    public int[] getRandomNumberArray(int count) throws RngServiceException {
        int[] randomNumberArray = new int[count];
        for (int i = 0; i < count; i++) {
            randomNumberArray[i] = getRandomNumber();
        }
        return randomNumberArray;
    }

    @Override
    public int getRangedRandomNumber(int range) throws RngServiceException {
        return rng.nextInt(range);
    }

    @Override
    public int[] getRangedRandomNumberArray(int range, int count) throws RngServiceException {
        int[] randomNumberArray = new int[count];
        for (int i = 0; i < count; i++) {
            randomNumberArray[i] = getRangedRandomNumber(range);
        }
        return randomNumberArray;
    }

    @Override
    public int[] getRangedRandomNumberArray(int[] rangeArray) throws RngServiceException {
        int[] randomNumberArray = new int[rangeArray.length];
        for (int i = 0; i < rangeArray.length; i++) {
            randomNumberArray[i] = getRangedRandomNumber(rangeArray[i]);
        }
        return randomNumberArray;
    }
}