package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.games.trextrack.logic.GameConfigurationAdapter;
import com.atsisa.gox.games.trextrack.logic.TRexTrackDebugLogic;
import com.atsisa.gox.games.trextrack.logic.TRexTrackRngService;
import com.atsisa.gox.logic.*;
import com.atsisa.gox.logic.calculator.*;
import com.atsisa.gox.logic.handler.DebugDrawStopSymbols;
import com.atsisa.gox.logic.messaging.*;
import com.atsisa.gox.logic.messaging.conditional.GambleWinDetector;
import com.atsisa.gox.logic.messaging.conditional.ScatterWinDetector;
import com.atsisa.gox.logic.messaging.conditional.SpinWinDetector;
import com.atsisa.gox.logic.messaging.handler.*;
import com.atsisa.gox.logic.provider.AnimationProvider;
import com.atsisa.gox.logic.provider.ExtendedSymbolConfigurationProvider;
import com.atsisa.gox.logic.provider.ExtendedSymbolPayTableProvider;
import com.atsisa.gox.logic.provider.FreeGamePayTableProvider;
import com.atsisa.gox.logic.provider.FreeGamesConfigurationProvider;
import com.atsisa.gox.logic.provider.IAnimationProvider;
import com.atsisa.gox.logic.provider.IExtendedSymbolConfigurationProvider;
import com.atsisa.gox.logic.provider.IExtendedSymbolPayTableProvider;
import com.atsisa.gox.logic.provider.IFreeGamePayTableProvider;
import com.atsisa.gox.logic.provider.IFreeGamesConfigurationProvider;
import com.atsisa.gox.logic.provider.ILinesModelProvider;
import com.atsisa.gox.logic.provider.IPayTableProvider;
import com.atsisa.gox.logic.provider.IReelsDescriptorProvider;
import com.atsisa.gox.logic.provider.IReelsGameConfigurationProvider;
import com.atsisa.gox.logic.provider.IScatterConfigurationProvider;
import com.atsisa.gox.logic.provider.ISoundProvider;
import com.atsisa.gox.logic.provider.IStopSymbolsProvider;
import com.atsisa.gox.logic.provider.LinesModelProvider;
import com.atsisa.gox.logic.provider.PayTableProvider;
import com.atsisa.gox.logic.provider.ReelsDescriptorProvider;
import com.atsisa.gox.logic.provider.ReelsGameConfigurationProvider;
import com.atsisa.gox.logic.provider.SoundProvider;
import com.atsisa.gox.logic.provider.StopSymbolsProvider;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.rng.IRngService;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.ClassKey;
import dagger.multibindings.IntoMap;
import dagger.multibindings.IntoSet;
import dagger.multibindings.StringKey;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.Map;

/**
 * Represents an IoC game logic configuration module.
 */
@Module (includes = {TRexTrackFreeGamesModule.class})
@SuppressWarnings("unused")
public abstract class TRexTrackGameLogicModule {




    // Services
    public static ServiceResolver serviceResolver;

    @Singleton
    @Provides
    static IServiceResolver bindServiceResolver(@Named(GamelogicServicesType.ALL_SERVICES) Map<Class<?>, Object> gamelogicServices ) {
        if (serviceResolver == null){
            serviceResolver = new ServiceResolver(gamelogicServices);
        }
        return serviceResolver;
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IGameLogicStateRepository.class)
    public static Object provideGameLogicStateRepository() {
        return new GameLogicStateRepository();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IHistoryCardsProvider.class)
    public static Object provideHistoryCardsProvider() {
        return new HistoryCardsProvider();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IRngService.class)
    public static Object provideRngService() {
        return new TRexTrackRngService();
//        RngService();
    }


    @IntoSet
    @Binds
    abstract ILogicInitializable payTableProviderInitializable(PayTableProvider payTableProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesPayTableProvider(FreeGamePayTableProvider freeGamePayTableProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IBalance.class)
    abstract Object provideBalance(IBalance balance);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAccount.class)
    abstract Object provideAccount(IAccount account);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ISoundProvider.class)
    abstract Object provideSoundProvider(ISoundProvider soundProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAnimationProvider.class)
    abstract Object provideAnimationProvider(IAnimationProvider animationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IStopSymbolsProvider.class)
    abstract Object provideStopSymbolProvider(IStopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsDescriptorProvider.class)
    abstract Object provideReelsDescriptorProvider(IReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ILinesCalculator.class)
    abstract Object provideLinesCalculator(LinesCalculator linesCalculator);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IPayTableProvider.class)
    abstract Object providePayTableProvider(IPayTableProvider IGameLogicStateRepository);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsGameConfigurationProvider.class)
    abstract Object provideReelsGameConfigurationProvider(IReelsGameConfigurationProvider reelsGameConfigurationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IFreeGamesConfigurationProvider.class)
    abstract Object provideFreeGamesConfigurationProvider(IFreeGamesConfigurationProvider freeGamesConfigurationProvider);

    @Singleton
    @Provides
    @Named(FreeGamesConfigurationProvider.FREE_GAMES_CONFIGURATION_RESOURCE_NAME)
    static String freeGamesConfiguratioFilePath() {
        return "freeGameConfiguration";
    }

    @Binds
    @Singleton
    abstract IFreeGamesConfigurationProvider freeGamesConfigurationProviderBind(FreeGamesConfigurationProvider configurationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IFreeGamePayTableProvider.class)
    abstract Object provideFreeGamesPayTableProvider(IFreeGamePayTableProvider freeGamePayTableProvider);

    @Singleton
    @Provides
    @Named(FreeGamePayTableProvider.PAYTABLE_FILE_RESOURCE_NAME)
    static String freeGamesPayTableFilePath() {
        return "freeGamePayTable";
    }

    @Binds
    @Singleton
    abstract IFreeGamePayTableProvider freeGamePayTableProviderBind(FreeGamePayTableProvider freeGamePayTableProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolLogic extendedSymbolLogic(ExtendedSymbolLogic extendedSymbolLogic);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolPayTableProvider.class)
    abstract Object provideExtendedSymbolPayTableProvider(IExtendedSymbolPayTableProvider extendedSymbolPayTableProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolCalculator.class)
    abstract Object provideExtendedSymbolCalculatorProvider(IExtendedSymbolCalculator extendedSymbolCalculator);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolConfigurationProvider.class)
    abstract Object provideExtendedSymbolConfigurationProvider(IExtendedSymbolConfigurationProvider extendedSymbolConfigurationProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolConfigurationProvider extendedSymbolConfigurationProviderBind(
            ExtendedSymbolConfigurationProvider extendedSymbolConfigurationProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolPayTableProvider extendedSymbolPayTableProviderBind(ExtendedSymbolPayTableProvider extendedSymbolPayTableProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolCalculator extendedSymbolCalculatorBind(ExtendedSymbolCalculator extendedSymbolCalculator);

    @Singleton
    @Provides
    @Named(ExtendedSymbolConfigurationProvider.EXTENDED_SYMBOL_DESCRIPTOR_FILE_RESOURCE_NAME)
    static String extendedSymbolConfigurationFilePath() {
        return "extendedSymbolConfiguration";
    }

    @Singleton
    @Provides
    @Named(ExtendedSymbolPayTableProvider.EXTENDED_SYMBOL_PAYTBABLE_RESOURCE_NAME)
    static String extendedSymbolPayTableFilePath() {
        return "extendedSymbolPayTable";
    }

    @IntoSet
    @Provides
    @Singleton
    public static IExtendedSymbolHitChecker extendedSymbolHitChecker() {
        return new ExtendedSymbolHitChecker();
    }

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IScatterCalculator.class)
    abstract Object provideScatterCalculator(IScatterCalculator scatterCalculator);

    @Singleton
    @Provides
    @Named(ReelsDescriptorProvider.REELS_DESCRIPTOR_FILE_RESOURCE_NAME)
    static String reelsDescriptorFilePath() {
        return "reelstrips";
    }

    @Singleton
    @Provides
    @Named(ReelsGameConfigurationProvider.REELS_GAME_CONFIGURATION_FILE_RESOURCE_NAME)
    static String reelsGameConfigurationFilePath() {
        return "reelsGameConfiguration";
    }

    @Singleton
    @Provides
    @Named(PayTableProvider.PAYTABLE_FILE_RESOURCE_NAME)
    static String payTableConfigurationFilePath() {
        return "payTable";
    }

    @Singleton
    @Provides
    @Named(SoundProvider.SOUNDS_FILE_RESOURCE_NAME)
    static String soundsFilePath() {
        return "sounds";
    }

    @Singleton
    @Provides
    @Named(LinesModelProvider.LINES_FILE_RESOURCE_NAME)
    static String linesPathConfigurationFilePath() {
        return "lines";
    }

    @Singleton
    @Provides
    @Named(AnimationProvider.ANIMATION_FILE_RESOURCE_NAME)
    static String animationsFilePath() {
        return "animations";
    }

    @IntoSet
    @Binds
    abstract ILogicInitializable animationProviderInitializableBind(AnimationProvider animationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable soundsProviderInitializableBind(SoundProvider soundsProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelsGameConfigurationInitializableBind(ReelsGameConfigurationProvider reelsGameConfigurationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable paytTableProviderInitializable(PayTableProvider payTableProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelDescriptorProviderInitializable(ReelsDescriptorProvider reelsDescriptorProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelLogicInitializableBind(ReelsLogic reelsLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable gamblerLogicInitializableBind(GamblerLogic gamblerLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable linesModelProviderInitializable(LinesModelProvider linesModelProvider);

    @Binds
    @Singleton
    abstract ILinesCalculator linesCalculatorBind(LinesCalculator linesCalculator);

    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker symbolHitChecker() {
        return new SymbolHitChecker();
    }

    @Binds
    @Singleton
    abstract IReelsGameConfigurationProvider reelsGameConfigurationProviderBind(ReelsGameConfigurationProvider reelGameConfigurationProvider);

    @Binds
    @Singleton
    abstract IReelsDescriptorProvider reelsDescriptorProviderBind(ReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    abstract IStopSymbolsProvider stopSymbolsProviderBind(StopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    abstract ISoundProvider soundsProviderBind(SoundProvider soundProvider);

    @Binds
    @Singleton
    abstract IAnimationProvider animationProviderBind(AnimationProvider animationProvider);

    @Binds
    @Singleton
    abstract IPayTableProvider payTableProviderBind(PayTableProvider payTableProvider);

    @Binds
    @Singleton
    abstract ILinesModelProvider linesProvider(LinesModelProvider linesProvider);

    @Binds
    @Singleton
    abstract IReelsLogic reelsLogicBind(ReelsLogic reelsLogic);

    @Binds
    @Singleton
    abstract IReelGameLogic reelGameLogicBind(TRexTrackDebugLogic logic);

    @Binds
    @Singleton
    abstract IDebugReelGameLogic debugReelGameLogic(TRexTrackDebugLogic logic);

    @Binds
    @Singleton
    abstract IGamblerLogic gamblerLogicBind(GamblerLogic reelsLogic);

    @Singleton
    @Provides
    public static IGameLogicStateRepository gameLogicStateRepository() {
        return new GameLogicStateRepository();
    }

    @Singleton
    public abstract IntegrationFlowFactory integrationFlowFactory();

    @Singleton
    public abstract GameConfigurationAdapter gameConfigurationAdapter();

    @IntoMap
    @StringKey(CoreConditions.POSITIVE_CONDITION)
    @Singleton
    @Provides
    public static IConditionalMessage positiveCondition() {
        return new PositiveConditionalMessage();
    }

    @IntoMap
    @StringKey(ReelsConditions.SPIN_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage spinWinDetectorCondition() {
        return new SpinWinDetector();
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyWinLimitsHandler() {
        return new ApplyWinLimits();
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createLoseResponseHandler(IServiceResolver resolver) {
        return new CreateLoseResponse(resolver);
    }



    @IntoMap
    @StringKey(ReelsHandlers.CREATE_TAKE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createTakeWinResponseHandler(IServiceResolver resolver) {
        return new CreateTakeWinResponse(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createWinResponseHandler(IServiceResolver resolver) {
        return new CreateWinResponse(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.DRAW_STOP_SYMBOLS)
    @Singleton
    @Provides
    public static IMessageHandler drawStopSymbolsHandler(IServiceResolver resolver) {
        return new DebugDrawStopSymbols(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.REEL_DEPOSIT_WIN)
    @Singleton
    @Provides
    public static IMessageHandler reelDepositWinHandler(IServiceResolver resolver) {
        return new ReelDepositWin(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinArgumentValidatorHandler(IServiceResolver resolver) {
        return new SpinArgumentValidator(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_BALANCE_VERIFIER)
    @Singleton
    @Provides
    public static IMessageHandler spinBalanceVerifierHandler(IServiceResolver resolver) {
        return new SpinBalanceVerifier(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinStateValidatorHandler(IGameLogicStateRepository stateRepository) {
        return new com.atsisa.gox.games.trextrack.logic.handler.SpinStateValidator(stateRepository);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_WITHDRAW_MONEY)
    @Singleton
    @Provides
    public static IMessageHandler spinWithdrawMoney(IServiceResolver resolver) {
        return new SpinWithdrawMoney(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.TAKE_WIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler takeWinStateValidatorHandler(IServiceResolver resolver) {
        return new TakeWinStateValidator(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.WIN_LINES_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler winLinesCalculatorHandler(IServiceResolver resolver) {
        return new WinLinesCalculator(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_REELSTRIPS_STOP_SOUNDS)
    @Singleton
    @Provides
    public static IMessageHandler applyReelStripsStopSoundsBind(IServiceResolver resolver) {
        return new ApplyReelStripsStopSounds(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_WIN_ANIMATIONS)
    @Singleton
    @Provides
    public static IMessageHandler addWinAnimationsBind(IServiceResolver resolver) {
        return new ApplyWinAnimations(resolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_WIN_SOUNDS)
    @Singleton
    @Provides
    public static IMessageHandler addWinSoundsBind(IServiceResolver resolver) {
        return new ApplyWinSounds(resolver);
    }

    @Provides
    @Singleton
    static IHistoryCardsProvider historyCardsProviderBind() {
        return new HistoryCardsProvider();
    }

    @IntoMap
    @StringKey(GamblerHandlers.ENTER_GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler enterGamblerStateValidator(IServiceResolver resolver) {
        return new EnterGamblerStateValidator(resolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_ENTER_GAMBLER_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createEnterGamblerResponse(IServiceResolver resolver) {
        return new CreateEnterGamblerResponse(resolver);
    }

    @IntoMap
    @StringKey(GamblerConditions.GAMBLE_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage gambleWinDetector() {
        return new GambleWinDetector();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerArgumentValidator() {
        return new GamblerArgumentValidator();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerStateValidator(IServiceResolver resolver) {
        return new GamblerStateValidator(resolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleWinResponse(IServiceResolver resolver) {
        return new CreateGambleWinResponse(resolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleLoseResponse(IServiceResolver resolver) {
        return new CreateGambleLoseResponse(resolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.DRAW_GAMBLE_CARD)
    @Singleton
    @Provides
    public static IMessageHandler drawGambleCard(IServiceResolver resolver) {
        return new DrawGambleCard(resolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.APPLY_GAMBLER_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyGamblerLimits(IGameLogicStateRepository gameLogicStateRepository) {
        return new ApplyGamblerLimits();
    }


    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker wildSymbolHitChecker() {
        return new TRexTrackWildHitChecker();
    }

    @Binds
    @Singleton
    abstract IScatterLogic bindScatterLogic(ScatterLogic scatterLogic);

    @Binds
    @Singleton
    abstract IFreeGamesLogic bindFreeGamesLogic(FreeGamesLogic freeGamesLogic);


    @IntoSet
    @Binds
    abstract ILogicInitializable scatterLogicInitializableBind(ScatterLogic scatterLogic);

    // Scatter
    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterArgumentValidator() {
        return new ScatterArgumentValidator();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterStateValidatorHandler(IServiceResolver serviceResolver) {
        return new ScatterStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_WIN_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterWinCalculatorHandler(IServiceResolver serviceResolver) {
        return new ScatterWinCalculator(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.APPLY_SCATTER_STOP_SOUNDS)
    @Singleton
    @Provides
    public static IMessageHandler applyScatterStopSoundsHandler(IServiceResolver serviceResolver) {
        return new ApplyStopSoundsForStripsWithScatter(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterConditions.SCATTER_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage scatterWinDetectorCondition() {
        return new ScatterWinDetector();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler scatterApplyWinLimitsHandler() {
        return new ScatterApplyWinLimits();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.CREATE_SCATTER_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createScatterWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateScatterWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.APPLY_SCATTER_WIN_ANIMATIONS)
    @Singleton
    @Provides
    public static IMessageHandler applyScatterWinAnimations(IServiceResolver serviceResolver) {
        return new ApplyScatterWinAnimations(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.APPLY_SCATTER_WIN_SOUNDS)
    @Singleton
    @Provides
    public static IMessageHandler applyScatterWinSounds(IServiceResolver serviceResolver) {
        return new ApplyScatterWinSounds(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.CREATE_SCATTER_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createScatterLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateScatterLoseResponse(serviceResolver);
    }


    @Binds

    @Singleton

    abstract IScatterCalculator bindIScatterCalculator(ScatterCalculator calculator);


    @Binds

    @Singleton

    abstract IScatterConfigurationProvider bindScatterConfigurationProvider(ScatterConfigurationProvider scatterConfigurationProvider);


    @Binds

    @IntoSet

    abstract ILogicInitializable initializeScatterConfigurationProvider(ScatterConfigurationProvider scatterConfigurationProvider);


    @Provides

    @Singleton

    @Named("scatterConfigurationId")

    static String bindScatterConfigurationId() {

        return "scatterPayTable";

    }


}
