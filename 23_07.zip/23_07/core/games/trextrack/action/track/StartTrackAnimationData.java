package com.atsisa.gox.games.trextrack.action.track;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class StartTrackAnimationData extends ActionData {

    @XmlAttribute
    private boolean win;

    public boolean getWin() {
        return win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }
}
