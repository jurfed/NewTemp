package com.atsisa.gox.games.trextrack.action.lineshow;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.HideWinLinesEvent;

public class HideWinLinesAction extends Action{
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new HideWinLinesEvent());
        finish();
    }
}
