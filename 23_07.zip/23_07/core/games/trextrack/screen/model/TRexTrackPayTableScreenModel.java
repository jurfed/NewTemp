package com.atsisa.gox.games.trextrack.screen.model;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.games.octavian.reels.screen.model.OPayTableScreenModel;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.model.IValueFormatter;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TRexTrackPayTableScreenModel extends OPayTableScreenModel {

//    @Inject
//    public TRexTrackPayTableScreenModel(ITranslator translator, IConfigurationProvider configurationProvider, ICreditsFormatter creditsFormatter) {
//        super(translator, configurationProvider, creditsFormatter);
//    }

    private static Map<String, List<Integer>> symbolsWinCounts;

    @Inject
    public TRexTrackPayTableScreenModel(ITranslator translator, IConfigurationProvider configurationProvider, IValueFormatter creditsFormatter, IEventBus eventBus, IPayTableModelProvider payTableModelProvider) {
        super(translator, configurationProvider, creditsFormatter, eventBus, payTableModelProvider);
    }

    public Map<String, List<Integer>> getSymbolsWinCounts() {
        return this.symbolsWinCounts;
    }

    public void setSymbolsWinCounts(Map<String, List<Integer>> symbolsWinCounts) {
        this.symbolsWinCounts = symbolsWinCounts;
    }

    private final static Map<String, String> SymbolsAndPayTableView = new HashMap() {{
        put("Green", "GreenBoard");
        put("Yellow", "YellowBoard");
        put("Blue", "BlueBoard");
        put("Violet", "VioletBoard");
        put("Pink", "PinkBoard");
        put("SymbolA", "AKBoard");
        put("SymbolK", "AKBoard");
        put("SymbolQ", "QJ10Board");
        put("SymbolJ", "QJ10Board");
        put("Symbol10", "QJ10Board");
        put("Scatter", "ScatterBoard");
        put("Wild", "WildBoard");
    }};

}
