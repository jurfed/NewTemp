package com.atsisa.gox.games.trextrack.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.games.trextrack.event.PayTableAnimation;
import com.atsisa.gox.games.trextrack.screen.model.TRexTrackPayTableScreenModel;
//import com.atsisa.gox.games.trextrack.view.paytable.PayTableWinAnimationView;
import com.atsisa.gox.games.octavian.core.view.paytable.animation.PayTableWinAnimationView;
import com.atsisa.gox.reels.screen.PayTableScreen;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;


public class TRexTrackPayTableScreen extends PayTableScreen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String TREX_TRACK_PAYTABLE_LAYOUT_ID_PROPERTY = "TRexTrackPayTableScreen";

    @Inject
    public TRexTrackPayTableScreen(@Named(TREX_TRACK_PAYTABLE_LAYOUT_ID_PROPERTY) String layoutId, TRexTrackPayTableScreenModel model,
                                   IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        eventBus.register(new PayTableAnimationtObserver(), PayTableAnimation.class);
    }

/*    @Inject
    PayTableWinAnimationController payTableWinAnimationController;*/

    @Override
    protected void afterActivated() {
        new Timeout(1000, new TempTimeOut(), true);

/*        new Timeout(2000, new TimeoutCallback() {
            @Override
            public void onTimeout() {
                ((PayTableWinAnimationView) findViewById("winGroup3")).playAnimation(new ArrayList() {{
                    add(3);
                    add(4);
                    add(7);
                    add(9);
                }});

                ((PayTableWinAnimationView) findViewById("winGroup1")).playAnimation(new ArrayList() {{
                    add(3);
                    add(7);
                    add(9);
                }});

                ((PayTableWinAnimationView) findViewById("winGroup2")).playAnimation(new ArrayList() {{
                    add(5);
                    add(6);
                    add(10);
                }});
                ((PayTableWinAnimationView) findViewById("winGroup4")).playAnimation(new ArrayList() {{
                    add(5);
                    add(6);
                    add(8);
                }});
                ((PayTableWinAnimationView) findViewById("winGroup5")).playAnimation(new ArrayList() {{
                    add(5);
                    add(6);
                    add(8);
                }});
                ((PayTableWinAnimationView) findViewById("winGroup8")).playAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup6up")).playAnimation(new ArrayList() {{
                    add(3);
                    add(5);
                }}, new ArrayList() {{
                    add(1);
                    add(2);
                    add(3);
                }}, new ArrayList<>());

                ((PayTableWinAnimationView) findViewById("winGroup7")).playAnimation(new ArrayList() {{
                    add(3);
                    add(5);
                }}, new ArrayList() {{
                    add(0);
                    add(1);
                }}, new ArrayList() {{
                    add(0);
                    add(1);
                }});
            }
        }, true);


        new Timeout(5000, new TimeoutCallback() {
            @Override
            public void onTimeout() {
                ((PayTableWinAnimationView) findViewById("winGroup3")).stopAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup7")).stopAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup8")).stopAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup2")).stopAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup6up")).stopAnimation();
                ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).playAnimation(new ArrayList() {{
                    add(3);
                    add(5);
                }}, new ArrayList() {{
                    add(0);
                    add(1);
                    add(3);
                }});
            }
        }, true);


        new Timeout(7000, new TimeoutCallback() {
            @Override
            public void onTimeout() {
                ((PayTableWinAnimationView) findViewById("winGroup3")).playAnimation(new ArrayList() {{
                    add(3);
                    add(4);
                    add(7);
                    add(9);
                    add(10);
                }});
                ((PayTableWinAnimationView) findViewById("winGroup7")).playAnimation(new ArrayList() {{
                    add(3);
                    add(5);
                }}, new ArrayList() {{
                    add(0);
                    add(1);
                }},new ArrayList() {{
                    add(0);
                    add(1);
                }});
                ((PayTableWinAnimationView) findViewById("winGroup2")).playAnimation(new ArrayList() {{
                    add(2);
                    add(3);
                    add(4);
                    add(5);
                    add(7);
                }});

                ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).stopAnimation();

                new Timeout(100, new TTemp(), true);
            }
        }, true);

        new Timeout(10000, new TimeoutCallback() {
            @Override
            public void onTimeout() {
            }
        });

        new Timeout(10000, new TimeoutCallback() {
            @Override
            public void onTimeout() {
                ((PayTableWinAnimationView) findViewById("winGroup6up")).playAnimation(new ArrayList() {{
                    add(4);
                }}, new ArrayList() {{
                    add(0);
                    add(2);
                    add(3);
                }});

                ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).playAnimation(new ArrayList() {{
                    add(3);
                }}, new ArrayList() {{
                    add(2);
                }});
            }
        }, true);*/

    }
    static Map<String, Set<Integer>> mapAKQJ10;

    class TempTimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {
//            PayTableWinAnimationView payTableWinAnimationView = findViewById("winGroup3");
            //payTableWinAnimationView.initStaticIndicators();
//            System.out.println();
            new Timeout(1000, new TempTimeOut(), true);
        }
    }

    private class PayTableAnimationtObserver extends NextObserver<PayTableAnimation> {

        @Override
        public void onNext(PayTableAnimation payTableAnimation) {
            List<String> simpleSymbols = new ArrayList() {{
                add("Green");
                add("Yellow");
                add("Pink");
                add("Blue");
                add("Violet");
                add("Scatter");
            }};


            if (payTableAnimation.getSymbolsWinCounts() != null && payTableAnimation.getStart()) {
                animateAKQJ10(payTableAnimation);
                payTableAnimation.getSymbolsWinCounts().forEach((symbol, symbolCounts) -> {
                    simpleSymbols.stream().forEach(simpl -> {
                        if (simpl.equals(symbol.toString())) {

/*                            if(symbol.toString().equals("Yellow")){
                                Set<Integer> tempset = new HashSet<>();
                                for(Integer t:(Set<Integer>) payTableAnimation.getSymbolsWinCounts().get("Yellow2")){
                                    tempset.add(t*2);
                                }

                                ((Set)symbolCounts).addAll(tempset);

                                ((PayTableWinAnimationView) findViewById(symbol.toString())).playAnimation((Set) symbolCounts);
                            }*/

                            ((PayTableWinAnimationView) findViewById(symbol.toString())).playAnimation((Set) symbolCounts);
                        }
                    });
                    if (symbol.toString().equals("Wild"))
                        ((PayTableWinAnimationView) findViewById(symbol.toString())).playAnimation();
                });


            } else if (payTableAnimation.getSymbolsWinCounts() != null) {
                stopAnimateAKQJ10();
                payTableAnimation.getSymbolsWinCounts().forEach((symbol, symbolCount) -> {
                    simpleSymbols.stream().forEach(simpl -> {
                        if (simpl.equals(symbol.toString())) {
                            ((PayTableWinAnimationView) findViewById(symbol.toString())).stopAnimation();
                        }
                    });
                    if (symbol.toString().equals("Wild"))
                        ((PayTableWinAnimationView) findViewById(symbol.toString())).stopAnimation();
                });
            }

        }

        private void animateAKQJ10(PayTableAnimation payTableAnimation) {


            mapAKQJ10 = new HashMap();

            mapAKQJ10.put("SymbolA", new HashSet<>());
            mapAKQJ10.put("SymbolK", new HashSet<>());
            mapAKQJ10.put("SymbolQ", new HashSet<>());
            mapAKQJ10.put("SymbolJ", new HashSet<>());
            mapAKQJ10.put("Symbol", new HashSet<>());

            payTableAnimation.getSymbolsWinCounts().forEach((symbol, symbolCounts) -> {
                        mapAKQJ10.forEach((symbolName, indexes) -> {
                            if (symbolName.equals(symbol.toString())) {
                                mapAKQJ10.put((String) symbol, (Set<Integer>) symbolCounts);
                            }
                        });
                    }
            );

            Set<Integer> AK = new HashSet<>();
            AK.addAll(mapAKQJ10.get("SymbolA"));
            AK.addAll(mapAKQJ10.get("SymbolK"));

            Set<Integer> QJ10 = new HashSet<>();
            QJ10.addAll(mapAKQJ10.get("SymbolQ"));
            QJ10.addAll(mapAKQJ10.get("SymbolJ"));
            QJ10.addAll(mapAKQJ10.get("Symbol"));

            Set<Integer> AKKeyFrameSet = new HashSet<>();
            Set<Integer> AKInvisibleSet = new HashSet<>();

            Set<Integer> QJ10KeyFrameSet = new HashSet<>();


            if (((Set<Integer>) mapAKQJ10.get("SymbolA")).size() > 0) {
                AKKeyFrameSet.add(2);
            }
            if (((Set<Integer>) mapAKQJ10.get("SymbolK")).size() > 0) {
                AKKeyFrameSet.add(3);
            }
            if (((Set<Integer>) mapAKQJ10.get("SymbolQ")).size() > 0) {
                QJ10KeyFrameSet.add(1);
            }
            if (((Set<Integer>) mapAKQJ10.get("SymbolJ")).size() > 0) {
                QJ10KeyFrameSet.add(2);
            }
            if (((Set<Integer>) mapAKQJ10.get("Symbol")).size() > 0) {
                QJ10KeyFrameSet.add(3);
            }

            if (QJ10.size() == 0 && AK.size() != 0) {
                AKKeyFrameSet.add(1);
                ((PayTableWinAnimationView) findViewById("winGroup6up")).playAnimation(AK, AKKeyFrameSet, AKInvisibleSet);
            }else if(QJ10.size() != 0 && AK.size() == 0){
                QJ10KeyFrameSet.add(0);
                ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).playAnimation(QJ10, QJ10KeyFrameSet);
            }else if(QJ10.size() != 0 && AK.size()!=0){
                AKKeyFrameSet.add(0);
                AKKeyFrameSet.remove(1);
                ((PayTableWinAnimationView) findViewById("winGroup6up")).playAnimation(AK, AKKeyFrameSet);
                QJ10KeyFrameSet.remove(0);
                ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).playAnimation(QJ10, QJ10KeyFrameSet);
            }

        }

        private void stopAnimateAKQJ10() {
            ((PayTableWinAnimationView) findViewById("winGroup6up")).stopAnimation();
            ((PayTableWinAnimationView) findViewById("winGroup6Bottom")).stopAnimation();
        }

    }


}
