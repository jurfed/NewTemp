package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.logic.*;
import com.atsisa.gox.logic.messaging.IConditionalMessage;
import com.atsisa.gox.logic.messaging.IMessageHandler;
import com.atsisa.gox.logic.messaging.conditional.FreeGameSpinWinDetector;
import com.atsisa.gox.logic.messaging.conditional.FreeGamesDetector;
import com.atsisa.gox.logic.messaging.handler.*;
import com.atsisa.gox.logic.provider.AnimationProvider;
import com.atsisa.gox.logic.provider.FreeGamesConfigurationProvider;
import com.atsisa.gox.logic.provider.IFreeGamesConfigurationProvider;
import com.atsisa.gox.reels.logic.vocs.ExtendedSymbolPresentationName;
import com.atsisa.gox.reels.logic.vocs.FreeGamesPresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.response.*;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoMap;
import dagger.multibindings.IntoSet;
import dagger.multibindings.StringKey;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.HashSet;
import java.util.Set;

@Module
public abstract class TRexTrackFreeGamesModule {



    //!!!!!!!!!!!!!!!!

    @Singleton
    @Provides
    @Named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS)
    static Set<String> extendedSymbolWinSerializationStrategyBind() {
        HashSet<String> freeGamesPresentations = new HashSet<>(FreeGamesPresentationName.AvailableNames);
        freeGamesPresentations.remove(FreeGamesPresentationName.ENTER_FREE_GAMES);
        return freeGamesPresentations;
    }

    @Singleton
    @Provides
    @Named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS)
    static Set<String> extendedSymbolSerializationStrategyBind() {
        HashSet<String> freeGamesPresentations = new HashSet<>(FreeGamesPresentationName.AvailableNames);
        freeGamesPresentations.remove(FreeGamesPresentationName.ENTER_FREE_GAMES);
        return freeGamesPresentations;
    }

    @Singleton
    @Provides
    @Named(CommonSerializationStrategy.COMMON_PRESENTATIONS)
    static Set<String> commonSerializationStrategyBind() {
        return new HashSet<String>() {{
            addAll(FreeGamesPresentationName.AvailableNames);
            addAll(ExtendedSymbolPresentationName.AvailableNames);
        }};
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesWinSerializationStrategy.FREE_GAMES_WIN_PRESENTATIONS)
    static String freeGamesWinSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesSerializationStrategy.FREE_GAMES_PRESENTATIONS)
    static String freeGamesSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesInfoSerializationStrategy.FREE_GAMES_INFO_PRESENTATIONS)
    static String freeGamesInfoSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }



    //!!!!!!!!!!!!!!!!


    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesLogicInitializableBind(FreeGamesLogic freeGamesLogic);
    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesConfigurationProviderInitializableBind(FreeGamesConfigurationProvider freeGamesConfigurationProvider);

    //Free games
    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES_REQUEST_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesRequestValidatorHandler() {
        return new CalculateFreeGamesRequestValidator();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesStateValidatorHandler(IServiceResolver serviceResolver) {
        return new CalculateFreeGamesStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesHandler(IServiceResolver serviceResolver) {
        return new CalculateFreeGamesAmount(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicConditions.FREE_GAMES_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage freeGamesDetector() {
        return new FreeGamesDetector();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAMES_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGamesWinResponse(IServiceResolver serviceResolver) {
        return new CreateFreeGamesWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_NO_FREE_GAMES_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createNoFreeGamesResponse(IServiceResolver serviceResolver) {
        return new CreateNoFreeGamesResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.SPIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesSpinStateValidator(IServiceResolver serviceResolver) {
        return new FreeGameSpinStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.FREE_GAMES_AMOUNT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesAmountValidatorHandler(IServiceResolver serviceResolver) {
        return new FreeGamesSpinAmountValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.DRAW_STOP_SYMBOLS)
    @Singleton
    @Provides
    public static IMessageHandler drawStopSymbolsInFreeGamesHandler(IServiceResolver serviceResolver) {
        return new FreeGameDrawStopSymbols(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.WIN_LINES_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesWinLinesCalculatorHandler(IServiceResolver serviceResolver) {
        return new FreeGamesWinCalculator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.INCREMENT_FREE_GAME_SPIN_AMOUNT)
    @Singleton
    @Provides
    public static IMessageHandler incrementFreeGameSpinAmountHandler(IServiceResolver serviceResolver) {
        return new IncrementFreeGameSpinAmount(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicConditions.FREE_GAME_SPIN_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage freeGameSpinWinDetectorHandler() {
        return new FreeGameSpinWinDetector();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAME_SPIN_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGameSpinWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateFreeGameSpinWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAME_SPIN_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGameSpinLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateFreeGameSpinLoseResponse(serviceResolver);
    }
}
