package com.atsisa.gox.games.trextrack.action.hitchecker;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.TRexTrackWildHitChecker;

import java.util.Random;

public class ResetPreviousCheckerSymbolId extends Action {
    Random randomSymbolId;

    @Override
    protected void execute() {
        randomSymbolId = new Random();
        TRexTrackWildHitChecker.setWinTrackSymbol(-1);
        finish();
    }
}
