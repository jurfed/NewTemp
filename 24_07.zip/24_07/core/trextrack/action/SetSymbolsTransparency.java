package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.SymbolsTransparency;

public class SetSymbolsTransparency extends Action<SetSymbolsTransparencyData> {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new SymbolsTransparency(this.actionData.getTransparency()));


        finish();
    }

    @Override
    public Class<SetSymbolsTransparencyData> getActionDataType() {
        return SetSymbolsTransparencyData.class;
    }
}
