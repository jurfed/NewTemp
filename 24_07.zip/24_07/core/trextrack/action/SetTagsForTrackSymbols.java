package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.FixTrackSymbolsAfterWin;
import com.atsisa.gox.reels.view.AbstractReel;
import com.atsisa.gox.reels.view.ReelGroupView;

/**
 * for
 */
public class SetTagsForTrackSymbols extends Action {
    ReelGroupView reelGroupView = (ReelGroupView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");

    @Override
    protected void execute() {

            GameEngine.current().getEventBus().post(new FixTrackSymbolsAfterWin());

        finish();
    }
}
