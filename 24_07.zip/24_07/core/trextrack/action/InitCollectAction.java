package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.StartControlPanelWinCollectCommand;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;

public class InitCollectAction extends Action {
    @Override
    protected void execute() {
        int lineSize = 0;
        AbstractReelGame game = (AbstractReelGame) GameEngine.current().getGame();
        long totalWinAmount = game.getLinesModelProvider().getTotalWinAmount();

        Iterable<? extends IWinLineInfo> lines = game.getLinesModelProvider().getLinesModel().getWinningLines();
        for (IWinLineInfo line : lines) {
            lineSize++;
        }

        eventBus.post(new StartControlPanelWinCollectCommand(lineSize*300+2000, totalWinAmount));
        finish();
    }
}
