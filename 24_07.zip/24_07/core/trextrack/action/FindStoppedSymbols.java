package com.atsisa.gox.games.trextrack.action;


import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.FormStoppedSymbols;

public class FindStoppedSymbols extends Action {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new FormStoppedSymbols());
        finish();
    }
}
