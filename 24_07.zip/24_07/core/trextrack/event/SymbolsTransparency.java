package com.atsisa.gox.games.trextrack.event;

public class SymbolsTransparency {

    private boolean transparency;

    public SymbolsTransparency(boolean transparency) {
        this.transparency = transparency;
    }

    public void setTransparency(boolean transparency) {
        this.transparency = transparency;
    }

    public boolean getTransparency() {
        return transparency;
    }
}
