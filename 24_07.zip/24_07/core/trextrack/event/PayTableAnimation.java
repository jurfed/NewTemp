package com.atsisa.gox.games.trextrack.event;

import java.util.Map;

public class PayTableAnimation {
    private final Map symbolsWinCounts;
    private boolean start;

    public PayTableAnimation(Map symbolsWinCounts, boolean start) {
        this.symbolsWinCounts = symbolsWinCounts;
        this.start = start;
    }

    public Map getSymbolsWinCounts() {
        return symbolsWinCounts;
    }

    public boolean getStart(){
        return this.start;
    }
}
