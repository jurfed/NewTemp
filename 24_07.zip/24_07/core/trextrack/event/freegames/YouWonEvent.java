package com.atsisa.gox.games.trextrack.event.freegames;

public class YouWonEvent {
    String textType;

    public YouWonEvent(String textType) {
        this.textType = textType;
    }

    public String getTextType() {
        return textType;
    }

    public void setTextType(String textType) {
        this.textType = textType;
    }
}
