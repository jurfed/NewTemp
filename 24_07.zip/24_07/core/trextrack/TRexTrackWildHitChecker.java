package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.logic.calculator.HitCheckResult;
import com.atsisa.gox.logic.calculator.IHitChecker;
import com.atsisa.gox.logic.model.Symbol;

import java.util.*;

public class TRexTrackWildHitChecker implements IHitChecker {
    /**
     * Wild symbol.
     */
    private static final String WILD_SYMBOL = "WildSymbol";
    private boolean hitCheck = false;
    private Symbol sequenceSymbol;
    private Symbol stopSymbol;
    private Random rn;
    private static boolean freeGame = false;

    public static boolean getFreeGame() {
        return freeGame;
    }

    public static void setFreeGame(boolean freeGame) {
        TRexTrackWildHitChecker.freeGame = freeGame;
    }

    /**
     * id for random generated symbol under the Track symbol
     */
    private static int winTrackSymbol = -1;
    private String trackSymbol;

    private final static Map<String, Boolean> trackSymbolsMap = new LinkedHashMap() {{
        put("Violet", false);//1
        put("Blue", false);//2
        put("Green", false);//3
        put("Yellow", false);//4
        put("Pink", false);//5
        put("SymbolA", false);//6
        put("SymbolK", false);//7
        put("SymbolQ", false);//8
        put("SymbolJ", false);//9
        put("Symbol10", false);//10
        put("Green2", false);//11
        put("Yellow2", false);//12
        put("Pink2", false);//13
        put("Blue2", false);//14
        put("Violet2", false);//15
    }};


    private final static List<String> trackSymbolsList = new ArrayList() {{
        add("Violet");
        add("Blue");
        add("Green");
        add("Yellow");
        add("Pink");
        add("SymbolA");
        add("SymbolK");
        add("SymbolQ");
        add("SymbolJ");
        add("Symbol10");
        add("Green2");
        add("Yellow2");
        add("Pink2");
        add("Blue2");
        add("Violet2");
    }};

    final static List<Integer> array = new ArrayList() {{
        add(1);
        add(2);
        add(3);
        add(4);
        add(5);
        add(11);
        add(12);
        add(13);
        add(14);
        add(15);
    }};

    public static List<String> getTrackSymbolsList() {
        return trackSymbolsList;
    }

    public static void setWinTrackSymbol(int winTrackSymbol) {
        TRexTrackWildHitChecker.winTrackSymbol = winTrackSymbol;
    }

    public static int getWinTrackSymbol() {
        return winTrackSymbol;
    }

    @Override
    public HitCheckResult check(Symbol sequenceSymbol, Symbol stopSymbol) {

        this.sequenceSymbol = sequenceSymbol;
        this.stopSymbol = stopSymbol;
        //generate symbol id
        if (winTrackSymbol == -1) {
            resetTrackSymbol();
        }

        hitCheck = wildCheck()
                || dinoCheck("Blue")
                || dinoCheck("Green")
                || dinoCheck("Violet")
                || dinoCheck("Pink")
                || dinoCheck("Yellow")
                || trackCheck();
        return new HitCheckResult(false, hitCheck && !sequenceSymbol.getType().equals("ScatterSymbol"));
    }

    private boolean wildCheck() {
        return stopSymbol.getType().equals(WILD_SYMBOL);
    }

    private boolean dinoCheck(String dinoName) {
/*        return (sequenceSymbol.getName().equalsIgnoreCase(dinoName + "2") && stopSymbol.getName().equalsIgnoreCase(dinoName) ||
                sequenceSymbol.getName().equalsIgnoreCase(dinoName) && stopSymbol.getName().equalsIgnoreCase(dinoName + "2"));*/
        return false;
    }

    private boolean trackCheck() {
        return (sequenceSymbol.getName().equalsIgnoreCase("Track") && stopSymbol.getName().equalsIgnoreCase("TrackR")
                || sequenceSymbol.getName().equalsIgnoreCase("TrackR") && stopSymbol.getName().equalsIgnoreCase("Track")
                || sequenceSymbol.getName().equalsIgnoreCase("TrackR") && stopSymbol.getName().equalsIgnoreCase("TrackR")
                || sequenceSymbol.getName().equalsIgnoreCase("Track") && stopSymbol.getName().equalsIgnoreCase("Track")

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Violet") || stopSymbol.getName().equalsIgnoreCase("Violet2")) &&
                (trackSymbolsMap.get("Violet") || trackSymbolsMap.get("Violet2"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Violet") || sequenceSymbol.getName().equalsIgnoreCase("Violet2")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Violet") || trackSymbolsMap.get("Violet2"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Blue") || stopSymbol.getName().equalsIgnoreCase("Blue2")) &&
                (trackSymbolsMap.get("Blue") || trackSymbolsMap.get("Blue2"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Blue") || sequenceSymbol.getName().equalsIgnoreCase("Blue2")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Blue") || trackSymbolsMap.get("Blue2"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Green") || stopSymbol.getName().equalsIgnoreCase("Green2")) &&
                (trackSymbolsMap.get("Green") || trackSymbolsMap.get("Green2"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Green") || sequenceSymbol.getName().equalsIgnoreCase("Green2")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Green") || trackSymbolsMap.get("Green2"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Yellow") || stopSymbol.getName().equalsIgnoreCase("Yellow2")) &&
                (trackSymbolsMap.get("Yellow") || trackSymbolsMap.get("Yellow2"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Yellow") || sequenceSymbol.getName().equalsIgnoreCase("Yellow2")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Yellow") || trackSymbolsMap.get("Yellow2"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Pink") || stopSymbol.getName().equalsIgnoreCase("Pink2")) &&
                (trackSymbolsMap.get("Pink") || trackSymbolsMap.get("Pink2"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Pink") || sequenceSymbol.getName().equalsIgnoreCase("Pink2")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Pink") || trackSymbolsMap.get("Pink2"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("SymbolA")) &&
                (trackSymbolsMap.get("SymbolA"))
                || (sequenceSymbol.getName().equalsIgnoreCase("SymbolA")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("SymbolA"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("SymbolK")) &&
                (trackSymbolsMap.get("SymbolK"))
                || (sequenceSymbol.getName().equalsIgnoreCase("SymbolK")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("SymbolK"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("SymbolQ")) &&
                (trackSymbolsMap.get("SymbolQ"))
                || (sequenceSymbol.getName().equalsIgnoreCase("SymbolQ")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("SymbolQ"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("SymbolJ")) &&
                (trackSymbolsMap.get("SymbolJ"))
                || (sequenceSymbol.getName().equalsIgnoreCase("SymbolJ")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("SymbolJ"))

                || (sequenceSymbol.getName().equalsIgnoreCase("Track") || sequenceSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (stopSymbol.getName().equalsIgnoreCase("Symbol10")) &&
                (trackSymbolsMap.get("Symbol10"))
                || (sequenceSymbol.getName().equalsIgnoreCase("Symbol10")) &&
                (stopSymbol.getName().equalsIgnoreCase("Track") || stopSymbol.getName().equalsIgnoreCase("TrackR")) &&
                (trackSymbolsMap.get("Symbol10"))
        );

    }

    private void resetTrackSymbol() {

        if (!freeGame) {
            rn = new Random();
            winTrackSymbol = rn.nextInt(15) + 1;
//        winTrackSymbol = rn.nextInt(1) + 1;

            trackSymbolsMap.forEach((key, value) -> {

                if (key.equals(trackSymbolsList.get(winTrackSymbol - 1))) {
                    trackSymbolsMap.put(key, true);
                } else {
                    trackSymbolsMap.put(key, false);
                }
            });
        } else {
            rn = new Random();
            winTrackSymbol = rn.nextInt(10);
            winTrackSymbol = array.get(winTrackSymbol);
            trackSymbolsMap.forEach((key, value) -> {

                if (key.equals(trackSymbolsList.get(winTrackSymbol - 1))) {
                    trackSymbolsMap.put(key, true);
                } else {
                    trackSymbolsMap.put(key, false);
                }
            });
        }

    }
}
