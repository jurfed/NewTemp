package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the info about current extended symbol should be reset.
 */
@Reflectable
public class ResetExtendedSymbolCommand {

}
