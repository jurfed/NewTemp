package com.atsisa.gox.reels;

/**
 * Contains all available presentation states in game with extended symbol.
 */
public class ExtendedSymbolPresentationStates implements IReelsPresentationStates {

    /**
     * The selecting extended symbol state.
     */
    public static final String SELECTING_EXTENDED_SYMBOL = "SelectingExtendedSymbol";

    /**
     * The selected extended symbol state.
     */
    public static final String SELECTED_EXTENDED_SYMBOL = "SelectedExtendedSymbol";

    /**
     * An array of available reels states.
     */
    private static final String[] AvailableStates = { SELECTING_EXTENDED_SYMBOL, SELECTED_EXTENDED_SYMBOL };

    @Override
    public String[] getAvailableStates() {
        return AvailableStates;
    }
}
