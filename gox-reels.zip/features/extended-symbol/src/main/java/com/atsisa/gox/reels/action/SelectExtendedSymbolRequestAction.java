package com.atsisa.gox.reels.action;

import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.logic.IExtendedSymbolGameLogic;
import com.gwtent.reflection.client.Reflectable;

/**
 * Used to sends request for a select extended symbol.
 */
@Reflectable
public class SelectExtendedSymbolRequestAction extends AbstractSendRequestAction {

    /**
     * Initializes a new instance of the {@link SelectExtendedSymbolRequestAction} class.
     */
    public SelectExtendedSymbolRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link SelectExtendedSymbolRequestAction} class.
     * @param game {@link AbstractReelGame}
     */
    public SelectExtendedSymbolRequestAction(AbstractReelGame game) {
        super(game);
    }

    @Override
    protected void execute() {
        subscribeForResult(((IExtendedSymbolGameLogic) getGameLogic()).selectExtendedSymbol());
    }

}
