package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when extended symbol model has changed.
 */
@Reflectable
public class ExtendedSymbolModelChangedEvent extends AbstractEvent {

    /**
     * The {@link IExtendedSymbolModel} reference.
     */
    private final IExtendedSymbolModel extendedSymbolModel;

    /**
     * Initializes a new instance of the {@link ExtendedSymbolModelChangedEvent} class.
     * @param extendedSymbolModel {@link IExtendedSymbolModel}
     */
    public ExtendedSymbolModelChangedEvent(IExtendedSymbolModel extendedSymbolModel) {
        this.extendedSymbolModel = extendedSymbolModel;
    }

    /**
     * Gets an object representing all information about current extended symbol.
     * @return the extended symbol model
     */
    public IExtendedSymbolModel getExtendedSymbolModel() {
        return extendedSymbolModel;
    }
}
