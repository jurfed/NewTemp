package com.atsisa.gox.reels.logic.request;

import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a select extended symbol request.
 */
@Reflectable
public class SelectExtendedSymbolRequest {

}
