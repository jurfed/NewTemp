package com.atsisa.gox.reels.logic;

import java.util.List;

import com.atsisa.gox.reels.logic.model.ExtendedSymbolWinLineInfo;

/**
 * Represents the extended symbol win result.
 */
public class ExtendedSymbolWinResult {

    /**
     * The winning lines.
     */
    private final List<ExtendedSymbolWinLineInfo> winningLines;

    /**
     * Initializes a new instance of the {@link ExtendedSymbolWinResult} class.
     * @param winningLines the winning lines
     */
    public ExtendedSymbolWinResult(List<ExtendedSymbolWinLineInfo> winningLines) {
        this.winningLines = winningLines;
    }

    /**
     * Gets a winning lines.
     * @return a winning lines
     */
    public List<ExtendedSymbolWinLineInfo> getWinningLines() {
        return winningLines;
    }

}
