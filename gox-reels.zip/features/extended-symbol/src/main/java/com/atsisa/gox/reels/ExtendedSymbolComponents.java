package com.atsisa.gox.reels;

import javax.inject.Inject;

import com.atsisa.gox.reels.model.IExtendedSymbolModelProvider;
import com.gwtent.reflection.client.Reflectable;

/**
 * The container for the extended symbol components.
 */
@Reflectable
public class ExtendedSymbolComponents extends AbstractReelGameComponents {

    /**
     * An extended symbol model provider.
     */
    private IExtendedSymbolModelProvider extendedSymbolModelProvider;

    /**
     * Sets an extended symbol model provider.
     * @param extendedSymbolModelProvider {@link IExtendedSymbolModelProvider}
     */
    @Inject
    public void setExtendedSymbolModelProvider(IExtendedSymbolModelProvider extendedSymbolModelProvider) {
        validateState();
        this.extendedSymbolModelProvider = extendedSymbolModelProvider;
    }

    /**
     * Gets an extended symbol model provider.
     * @return an extended symbol model provider
     */
    public IExtendedSymbolModelProvider getExtendedSymbolModelProvider() {
        return extendedSymbolModelProvider;
    }

}
