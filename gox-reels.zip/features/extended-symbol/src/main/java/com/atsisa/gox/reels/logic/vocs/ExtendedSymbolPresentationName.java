package com.atsisa.gox.reels.logic.vocs;

/**
 * List of available presentation names which are connected with extended symbol.
 */
public class ExtendedSymbolPresentationName {

    /**
     * Private constructor, prevents the creation of an instance of this class.
     */
    private ExtendedSymbolPresentationName() {
    }

    /**
     * Name of the presentation for special scatter.
     */
    public static final String SPECIAL_SCATTER = "SpecialScatter";

}
