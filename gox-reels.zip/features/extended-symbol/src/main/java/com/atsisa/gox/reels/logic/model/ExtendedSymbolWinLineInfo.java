package com.atsisa.gox.reels.logic.model;

import java.math.BigDecimal;
import java.util.List;

import com.atsisa.gox.reels.view.ExtendedSymbolStateName;

import com.atsisa.gox.reels.IWinLineInfo;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a winning line with extended symbol.
 */
@Reflectable
public class ExtendedSymbolWinLineInfo extends WinLineInfo {

    /**
     * Name of the extended symbol.
     */
    private String extendedSymbolName;

    /**
     * Initializes a new instance of the {@link IWinLineInfo} class.
     * @param lineNumber         a line number
     * @param soundName          a name of sound
     * @param extendedSymbolName a name of extended symbol
     * @param score              a score of win
     * @param positions          a positions of winning line
     */
    public ExtendedSymbolWinLineInfo(int lineNumber, String soundName, String extendedSymbolName, BigDecimal score, List<Integer> positions) {
        super(lineNumber, soundName, ExtendedSymbolStateName.EXTENDED_SYMBOL_ANIMATION_NAME, score, positions);
        this.extendedSymbolName = extendedSymbolName;
    }

    /**
     * Gets the name of the extended symbol.
     * @return the name of the extended symbol
     */
    public String getExtendedSymbolName() {
        return extendedSymbolName;
    }
}
