package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.SwitchWinLinesCommand;

/**
 * Sends a request to switch between common and extended symbol winning lines.
 */
public class SwitchWinLinesAction extends SyncAction {

    /**
     * Initialize a new instance of the {@link SwitchWinLinesAction} class.
     */
    public SwitchWinLinesAction() {
        super();
    }

    /**
     * Initialize a new instance of the {@link SwitchWinLinesAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public SwitchWinLinesAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new SwitchWinLinesCommand());
    }
}
