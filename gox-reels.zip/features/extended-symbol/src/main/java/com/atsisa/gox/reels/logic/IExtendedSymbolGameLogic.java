package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.presentation.LogicPresentation;

import rx.Observable;

/**
 * Represents a logic for the extended symbol.
 */
public interface IExtendedSymbolGameLogic {

    /**
     * Handles the request to select extended symbol.
     * @return the observable result
     */
    Observable<LogicPresentation> selectExtendedSymbol();

}
