package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.AbstractActionModule;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents the actions related to the extended symbol feature, which could be created declaratively using XML.
 */
@Reflectable
public class ExtendedSymbolActionModule extends AbstractActionModule {

    /**
     * Extended symbol actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/reels/extended/symbol/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerAction("ResetExtendedSymbol", ResetExtendedSymbolAction.class);
        registerAction("SwitchWinLines", SwitchWinLinesAction.class);
        registerAction("SelectExtendedSymbolRequest", SelectExtendedSymbolRequestAction.class);
    }
}
