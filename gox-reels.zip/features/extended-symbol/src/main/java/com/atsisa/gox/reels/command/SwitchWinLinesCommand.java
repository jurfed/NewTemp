package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the group of winning lines should be switched between common and extended symbol.
 */
@Reflectable
public class SwitchWinLinesCommand {

}
