package com.atsisa.gox.reels.logic;

import java.util.List;

import com.atsisa.gox.reels.logic.model.PayTableItem;

/**
 * Represents the info about extended symbol result.
 */
public class ExtendedSymbolResult {

    /**
     * Name of the extended symbol.
     */
    private String symbolName;

    /**
     * Pay table items for the extended symbol.
     */
    private List<PayTableItem> payTableItems;

    /**
     * Initializes new instance of the {@link ExtendedSymbolResult} class.
     * @param symbolName the extended symbol name
     * @param payTableItems the pay table items for the extended symbol.
     */
    public ExtendedSymbolResult(String symbolName, List<PayTableItem> payTableItems) {
        this.symbolName = symbolName;
        this.payTableItems = payTableItems;
    }

    /**
     * Gets the name of the extended symbol.
     * @return the name of the extended symbol
     */
    public String getSymbolName() {
        return symbolName;
    }

    /**
     * Gets the pay table items for the extended symbol.
     * @return the pay table items for the extended symbol
     */
    public List<PayTableItem> getPayTableItems() {
        return payTableItems;
    }
}
