package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ResetExtendedSymbolCommand;

/**
 * Sends a request to reset info about current extended symbol.
 */
public class ResetExtendedSymbolAction extends SyncAction {

    /**
     * Initialize a new instance of the {@link ResetExtendedSymbolAction} class.
     */
    public ResetExtendedSymbolAction() {
        super();
    }

    /**
     * Initialize a new instance of the {@link ResetExtendedSymbolAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public ResetExtendedSymbolAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new ResetExtendedSymbolCommand());
    }
}
