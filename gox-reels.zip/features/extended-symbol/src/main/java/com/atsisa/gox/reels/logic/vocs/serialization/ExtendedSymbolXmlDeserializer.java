package com.atsisa.gox.reels.logic.vocs.serialization;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.reels.logic.model.ExtendedSymbolWinLineInfo;

/**
 * Used to deserialize free games presentations.
 */
public class ExtendedSymbolXmlDeserializer {

    /**
     * Private constructor, prevents the creation of an instance of this class.
     */
    private ExtendedSymbolXmlDeserializer() {
    }

    /**
     * Deserializes the name of the extended symbol from the given xml object.
     * @param xmlObject xml object with info about extended symbol name
     * @return name of the extended symbol
     */
    public static String deserializeNameExtendedSymbol(XmlObject xmlObject) {
        return xmlObject.findOne("//rsp/p/ss/s").getValue();
    }

    /**
     * Deserializes the list of pay table items for extended symbol.
     * @param xmlObject xml object with pay table items for extended symbol
     * @return list with pay table items for the extended symbol
     */
    public static List<PayTableItem> deserializeExtendedSymbolPayTable(XmlObject xmlObject) {
        return XmlDeserializer.deserializePayTable(xmlObject.findOne("//rsp/p/ss"));
    }

    /**
     * Returns a boolean value that indicates whether this xml object contains winning lines for extended symbol or not.
     * @param xmlObject xml object with possible winning lines for extended symbol
     * @return boolean
     */
    public static boolean hasExtendedSymbolWinLines(XmlObject xmlObject) {
        return xmlObject.findOne("//rsp/p/swa/l") != null;
    }

    /**
     * Deserializes the list of the win lines with extended symbol.
     * @param xmlObject xml object with extended symbol win lines
     * @return the list of the win lines with extended symbol
     */
    public static List<ExtendedSymbolWinLineInfo> deserializeExtendedSymbolWinLines(XmlObject xmlObject) {
        List<XmlObject> winningLineElements = xmlObject.find("//rsp/p/swa/l");
        List<ExtendedSymbolWinLineInfo> winningLines = new ArrayList<>(winningLineElements.size());
        String soundName = xmlObject.findOne("//rsp/p/swa").getAttribute("sd");
        String extendedSymbolName = deserializeNameExtendedSymbol(xmlObject);
        for (XmlObject winningLineElem : winningLineElements) {
            Map<String, String> attributes = winningLineElem.getAttributes();

            // VOCS lines numbers starts from 0
            int lineNumber = Integer.parseInt(attributes.get("id")) + 1;
            BigDecimal score = new BigDecimal(attributes.get("sc"));

            List<XmlObject> positionElemList = winningLineElem.find("//p");
            List<Integer> positions = new ArrayList<>(positionElemList.size());

            if (!StringUtility.isNullOrEmpty(attributes.get("sd"))) {
                soundName = attributes.get("sd");
            }

            positions.addAll(positionElemList.stream().map(positionElem -> Integer.parseInt(positionElem.getValue())).collect(Collectors.toList()));
            winningLines.add(new ExtendedSymbolWinLineInfo(lineNumber, soundName, extendedSymbolName, score, positions));

        }
        return winningLines;
    }

}
