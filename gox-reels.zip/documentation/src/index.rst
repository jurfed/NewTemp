====================================
Welcome to GOX's Reels documentation
====================================

GOX's Reels is a library that expands the GOX game development framework, adding to it all the basic functionality associated with the reel games.

.. toctree::
   :caption: Table of Contents
   :name: mastertoc
   
   site/getting-started
   site/screens
   site/reel-game-logic
   site/reel-game-state-holder
   site/actions
   site/providers
   site/reel-components
   site/events-commands
   site/features
