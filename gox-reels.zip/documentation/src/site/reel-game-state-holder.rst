======================
Reel Game State Holder
======================
This interface `IReelGameStateHolder <../apidocs/com/atsisa/gox/reels/fsm/IReelGameStateHolder.html>`_ is used to control common base game flow. Implementation of this interface should handle all the basic events, objects sent using IEventBus and react to them. Should also keep the basic state of the game.

Initialize custom implementation
********************************
Custom implementation of this interface can be set in IoC container:

    .. code-block:: java

        bind(IReelGameStateHolder.class).to(CustomReelGameStateHolder.class).asEagerSingleton();

Good practice will be add *addEagerSingleton* to binding, because many classes will need access to it and without this, each of that class will get a new instance.

Default implementation
**********************
The reel library contains one default implementation of this interface: `ReelGameStateHolder <../apidocs/com/atsisa/gox/reels/fsm/ReelGameStateHolder.html>`_ and it is initialized by default in IoC container.

Requirements
------------
The default implementation requires the game to have:

#. Action queues.

    The game flow must be based on action queues, which are initialized by him, in response to events occurring in the game.

    List of required action queues with names:

    - *SpinReels*: is triggered after receiving the `SpinCommand <../apidocs/com/atsisa/gox/reels/command/SpinCommand.html>`_ from the event bus.
    - *TakeWin*: is triggered after receiving the `TakeWinCommand <../apidocs/com/atsisa/gox/reels/command/TakeWinCommand.html>`_ from the event bus.
    - *ResetGame*: is triggered after receiving the `ResetGameCommand <../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_ from the event bus.
    - *OnError*: is triggered after receiving the `GameErrorCommand <../apidocs/com/atsisa/gox/reels/command/GameErrorCommand.html>`_ from the event bus.
    - *SelectedGamblerRedCard*: is triggered after receiving the `GamblerCardSelectedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_ from the event bus and selected color was red.
    - *SelectedGamblerBlackCard*: is triggered after receiving the `GamblerCardSelectedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_ from the event bus and selected color was black.
    - *EnterHistory*: is triggered after receiving the `EnterHistoryCommand <../apidocs/com/atsisa/gox/reels/command/EnterHistoryCommand.html>`_ from the event bus.
    - *ExitHistory*: is triggered after receiving the `ExitHistoryCommand <../apidocs/com/atsisa/gox/reels/command/ExitHistoryCommand.html>`_ from the event bus.
    - *ShowNextHistoryPage*: is triggered after receiving the `ShowNextHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowNextHistoryPageCommand.html>`_ from the event bus.
    - *ShowPreviousHistoryPage*: is triggered after receiving the `ShowPreviousHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowPreviousHistoryPageCommand.html>`_ from the event bus.
    - *ShowNextInfoScreen*: is triggered after receiving the `NextInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/NextInfoScreenCommand.html>`_ from the event bus.
    - *EnteringGambler*:  is triggered after receiving the `EnterGamblerCommand <../apidocs/com/atsisa/gox/reels/command/EnterGamblerCommand.html>`_ from the event bus.

    It is also subscribed to presentations that come from the logic and based on their names, the corresponding action queue is triggered with the same name.

    **For example:**
     When presentation with name: **"BaseGameWin"** will be received, then queue with exactly the same name, will be triggered:

    .. code-block:: java

         actionManager.processQueue("BaseGameWin", true);

    .. note::

        Each action queues are triggered with *asNext* parameter set to true. Thanks to that current queue will be not paused/terminated.

#. Logic presentations.

    He expects that he will receive presentations from the logic, using event bus. On the basis of which it determines its state.

Incoming events/commands
------------------------
List of events/commands handled by default implementation:

    - `ReelGamePresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/ReelGamePresentation.html>`_: sets state based on data from it and trigger action queue with name from this presentation
    - `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: sets state based on data from this object
    - `SpinCommand <../apidocs/com/atsisa/gox/reels/command/SpinCommand.html>`_: triggers queue with name: "SpinReels"
    - `TakeWinCommand <../apidocs/com/atsisa/gox/reels/command/TakeWinCommand.html>`_: triggers queue with name: "TakeWin"
    - `ResetGameCommand <../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_: triggers queue with name: "ResetGame"
    - `GameErrorCommand <../apidocs/com/atsisa/gox/reels/command/GameErrorCommand.html>`_: triggers queue with name: "OnError"
    - `GamblerCardSelectedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_: triggers queue with name: "SelectedGamblerRedCard" or "SelectedGamblerBlackCard", based on selected card color
    - `EnterHistoryCommand <../apidocs/com/atsisa/gox/reels/command/EnterHistoryCommand.html>`_: triggers queue with name: "EnterHistory"
    - `ExitHistoryCommand <../apidocs/com/atsisa/gox/reels/command/ExitHistoryCommand.html>`_: triggers queue with name: "ExitHistory"
    - `ShowNextHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowNextHistoryPageCommand.html>`_: triggers queue with name: "ShowNextHistoryPage"
    - `ShowPreviousHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowPreviousHistoryPageCommand.html>`_: triggers queue with name: "ShowPreviousHistoryPage"
    - `StartAutoPlayCommand <../apidocs/com/atsisa/gox/reels/command/StartAutoPlayCommand.html>`_: sets an auto play flag to true and triggers queue with name: "SpinReels"
    - `StopAutoPlayCommand <../apidocs/com/atsisa/gox/reels/command/StopAutoPlayCommand.html>`_: sets an auto play flag to false
    - `SkipCommand <../apidocs/com/atsisa/gox/reels/command/SkipCommand.html>`_: terminates currently active action
    - `EnterGamblerCommand <../apidocs/com/atsisa/gox/reels/command/EnterGamblerCommand.html>`_: triggers queue with name: "EnteringGambler"
    - `NextInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/NextInfoScreenCommand.html>`_: triggers queue with name: "ShowNextInfoScreen"

Outgoing events/commands
------------------------
List of events/commnds reported by default implementation:

    - `EnteredHistoryEvent <../apidocs/com/atsisa/gox/reels/event/EnteredHistoryEvent.html>`_: triggered when presentation entered into history mode
    - `HistoryCloseEvent <../apidocs/com/atsisa/gox/reels/event/HistoryCloseEvent.html>`_: triggered when presentation was left the history mode
    - `AutoPlayStartedEvent <../apidocs/com/atsisa/gox/reels/event/AutoPlayStartedEvent.html>`_: triggered when presentation was entered into auto play mode
    - `AutoPlayStoppedEvent <../apidocs/com/atsisa/gox/reels/event/AutoPlayStoppedEvent.html>`_: triggered when presentation was left the auto play mode
    - RegisterTranslationCommand: triggered when new translation should be registered