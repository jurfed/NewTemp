=======
Actions
=======
The reels library contains a list of actions dedicated only for reel games.

Module
******
All actions for reels are registered in: `ReelGamesActionModule <../apidocs/com/atsisa/gox/reels/action/ReelGamesActionModule.html>`_, whose xml namespace is: http://www.atsisa.com/gox/reels/action

Namespace
*********
All actions are under the namespace:

 .. code-block:: java

    import com.atsisa.gox.reels.action.*;

Full information about actions is available in Framework documentation.