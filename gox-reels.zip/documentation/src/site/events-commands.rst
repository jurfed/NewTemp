===================
Events and Commands
===================
The reel library contains dedicated events and commands for basic reel games.

Events
******

- `AutoPlayStartedEvent <../apidocs/com/atsisa/gox/reels/event/AutoPlayStartedEvent.html>`_: triggered when auto play was started.
- `AutoPlayStoppedEvent <../apidocs/com/atsisa/gox/reels/event/AutoPlayStoppedEvent.html>`_: triggered when auto play was stopped.
- `BalanceChangedEvent <../apidocs/com/atsisa/gox/reels/event/BalanceChangedEvent.html>`_: triggered when a IAccount's balance changes.
- `BetModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/BetModelChangedEvent.html>`_: triggered when either bet value has changed.
- `EnteredHistoryEvent <../apidocs/com/atsisa/gox/reels/event/EnteredHistoryEvent.html>`_: triggered when game has entered into history mode.
- `ErrorModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/ErrorModelChangedEvent.html>`_: triggered when error model value has changed.
- `GamblerCardSelectedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_: triggered when gambler card was selected.
- `GamblerModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerModelChangedEvent.html>`_: triggered when gambler model has changed.
- `GameMessageChangedEvent <../apidocs/com/atsisa/gox/reels/event/GameMessageChangedEvent.html>`_: triggered when particular game message has changed.
- `HistoryCloseEvent <../apidocs/com/atsisa/gox/reels/event/HistoryCloseEvent.html>`_: triggered when history was closed.
- `HistoryGamblerCardsUpdatedEvent <../apidocs/com/atsisa/gox/reels/event/HistoryGamblerCardsUpdatedEvent.html>`_: triggered when gambler history cards have been updated.
- `HistoryModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/HistoryModelChangedEvent.html>`_: triggered when history model has changed.
- `LinesModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: triggered when either available line numbers or the number of lines user plays on has changed.
- `PayTableModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/PayTableModelChangedEvent.html>`_: triggered when pay table model has changed.
- `PresentationStateChangedEvent <../apidocs/com/atsisa/gox/reels/event/PresentationStateChangedEvent.html>`_: triggered when presentation has changed.
- `ReelsStoppedEvent <../apidocs/com/atsisa/gox/reels/event/ReelsStoppedEvent.html>`_: triggered when reels have stopped spinning.
- `ReelStoppingEvent <../apidocs/com/atsisa/gox/reels/event/ReelStoppingEvent.html>`_: triggered when specific reel began stopping.
- `SelectedGamblerCardHiddenEvent <../apidocs/com/atsisa/gox/reels/event/SelectedGamblerCardHiddenEvent.html>`_: triggered when selected gambler card was hidden.
- `SelectedGamblerCardShownEvent <../apidocs/com/atsisa/gox/reels/event/SelectedGamblerCardShownEvent.html>`_: triggered when selected gambler card was shown.
- `WinningLineShownEvent <../apidocs/com/atsisa/gox/reels/event/WinningLineShownEvent.html>`_: reports that a winning line has been shown.
- `ReelsStopShowingSymbolAnimationsEvent <../apidocs/com/atsisa/gox/reels/event/ReelsStopShowingSymbolAnimationsEvent.html>`_: reports when reels stopped showing symbol animations.
- `ReelsShowingSymbolAnimationsEvent <../apidocs/com/atsisa/gox/reels/event/ReelsShowingSymbolAnimationsEvent.html>`_: reports when reels was started showing symbol animations.

Commands
********

- `ChangeGameMessageCommand <../apidocs/com/atsisa/gox/reels/command/ChangeGameMessageCommand.html>`_: triggered when a game message needs to be changed.
- `DecreaseBetCommand <../apidocs/com/atsisa/gox/reels/command/DecreaseBetCommand.html>`_: a request for decreasing current bet value.
- `DecreaseLinesCommand <../apidocs/com/atsisa/gox/reels/command/DecreaseLinesCommand.html>`_: a request for decreasing current number of lines the user plays on.
- `DisplayStoppedSymbolsCommand <../apidocs/com/atsisa/gox/reels/command/DisplayStoppedSymbolsCommand.html>`_: a request for display stopped symbols on reels.
- `EnterGamblerCommand <../apidocs/com/atsisa/gox/reels/command/EnterGamblerCommand.html>`_: a request for enter to gambler.
- `EnterHistoryCommand <../apidocs/com/atsisa/gox/reels/command/EnterHistoryCommand.html>`_: a request for enter to history.
- `ExitHistoryCommand <../apidocs/com/atsisa/gox/reels/command/ExitHistoryCommand.html>`_: a request for exit from history.
- `GameErrorCommand <../apidocs/com/atsisa/gox/reels/command/GameErrorCommand.html>`_: a request to handle game error.
- `HideSelectedGamblerCardCommand <../apidocs/com/atsisa/gox/reels/command/HideSelectedGamblerCardCommand.html>`_: a command triggered when the last gambler selected card should be hidden.
- `HideWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/HideWinningLinesCommand.html>`_: a request for hiding all winning lines.
- `IncreaseBetCommand <../apidocs/com/atsisa/gox/reels/command/IncreaseBetCommand.html>`_: a request for increasing bet value.
- `IncreaseLinesCommand <../apidocs/com/atsisa/gox/reels/command/IncreaseLinesCommand.html>`_: a request for increasing current number of lines the user plays on.
- `NextBetCommand <../apidocs/com/atsisa/gox/reels/command/NextBetCommand.html>`_: a request for increasing bet to next bet step. When current bet is max bet value, then bet is set to minimum value.
- `NextLinesCommand <../apidocs/com/atsisa/gox/reels/command/NextBetCommand.html>`_: a request for increasing selected lines value. When current lines valued is max lines value, then lines is set to minimum value.
- `PreviousBetCommand <../apidocs/com/atsisa/gox/reels/command/PreviousBetCommand.html>`_: a request for decreasing bet to previous bet step. When current bet is minimum bet value, then bet is set to maximium value.
- `PreviousLinesCommand <../apidocs/com/atsisa/gox/reels/command/PreviousLinesCommand.html>`_: a request for decreasing lines value. When current lines value is minimum lines value, then lines is set to maximium value.
- `NextInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/NextInfoScreenCommand.html>`_: a request for showing next infor screen.
- `ResetGameCommand <../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_: a request for reset game.
- `ResetWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/ResetWinningLinesCommand.html>`_: a request for reset info about current winning line.
- `SetMaxBetCommand <../apidocs/com/atsisa/gox/reels/command/SetMaxBetCommand.html>`_: a request for increasing bet to max value.
- `SetMinBetCommand <../apidocs/com/atsisa/gox/reels/command/SetMinBetCommand.html>`_: a request for decreasing bet to minimum value.
- `ShowNextHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowNextHistoryPageCommand.html>`_: a request to show next page in history.
- `ShowNextWinningLineCommand <../apidocs/com/atsisa/gox/reels/command/ShowNextWinningLineCommand.html>`_: a request for showing the next winning line.
- `ShowPreviousHistoryPageCommand <../apidocs/com/atsisa/gox/reels/command/ShowPreviousHistoryPageCommand.html>`_: a request to show previous page in history.
- `ShowSelectedGamblerCardCommand <../apidocs/com/atsisa/gox/reels/command/ShowSelectedGamblerCardCommand.html>`_: a command triggered when the last gambler selected card should be displayed.
- `SkipCommand <../apidocs/com/atsisa/gox/reels/command/SkipCommand.html>`_: an event triggered when skip button has been clicked.
- `SpinCommand <../apidocs/com/atsisa/gox/reels/command/SpinCommand.html>`_: an event triggered when spin button has been clicked.
- `StartAnimationWinningSymbolsCommand <../apidocs/com/atsisa/gox/reels/command/StartAnimationWinningSymbolsCommand.html>`_: a request for show winning symbols on reels.
- `StartAutoPlayCommand <../apidocs/com/atsisa/gox/reels/command/StartAutoPlayCommand.html>`_: a request to start auto play.
- `StopAnimationWinningSymbolsCommand <../apidocs/com/atsisa/gox/reels/command/StopAnimationWinningSymbolsCommand.html>`_: a request for stop showing animations of winning symbols on reels.
- `StopAutoPlayCommand <../apidocs/com/atsisa/gox/reels/command/StopAutoPlayCommand.html>`_: a request to stop auto play.
- `StopReelsCommand <../apidocs/com/atsisa/gox/reels/command/StopReelsCommand.html>`_: a request to stop the reels on particular positions.
- `TakeWinCommand <../apidocs/com/atsisa/gox/reels/command/TakeWinCommand.html>`_: used to send request to take win.
- `TransferCreditsCommand <../apidocs/com/atsisa/gox/reels/command/TransferCreditsCommand.html>`_: a request for transferring credits to player's IAccount.
- `UpdateGamblerHistoryCardsCommand <../apidocs/com/atsisa/gox/reels/command/UpdateGamblerHistoryCardsCommand.html>`_: a command triggered when the gambler cards history should be updated.
- `UpdateGamblerScreenCommand <../apidocs/com/atsisa/gox/reels/command/UpdateGamblerScreenCommand.html>`_: a command triggered when the gambler screen state change has been requested.
- `TerminateStartsShowingWinningSymbolsCommand <../apidocs/com/atsisa/gox/reels/command/TerminateStartsShowingWinningSymbolsCommand.html>`_: used to terminate process of starting showing animation of winning symbols
- `ShowInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/ShowInfoScreenCommand.html>`_: used to show info screen
- `CleanWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/CleanWinningLinesCommand.html>`_: used for cleans info about current winning lines.
