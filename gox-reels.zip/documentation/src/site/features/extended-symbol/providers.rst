=========================
Extended symbol providers
=========================
The extended symbol feature, provide additional providers related to this feature.

List of interfaces
******************
List of available interfaces related with the feature:

IExtendedSymbolModelProvider
----------------------------
    Responsibility of the `IExtendedSymbolModelProvider <../../../apidocs/com/atsisa/gox/reels/model/IExtendedSymbolModelProvider.html>`_ is to keep information about current extended symbol in game. Implementation of this interface should report he `ExtendedSymbolModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/ExtendedSymbolModelChangedEvent.html>`_, when there is any change with that symbol.

Requirements
------------
The default implementations, are based on the objects from the extended symbol logic. Because all of them are set their initial and current state based on them.

List of default implementations
*******************************
List of default provider implementations in library:

ExtendedSymbolModelProvider
---------------------------
Technical documentation: `ExtendedSymbolModelProvider <../../../apidocs/com/atsisa/gox/reels/model/ExtendedSymbolModelProvider.html>`_

Model: `ExtendedSymbolModel <../../../apidocs/com/atsisa/gox/reels/model/ExtendedSymbolModel.html>`_.

Listens on:

- `ResetExtendedSymbolCommand <../../../apidocs/com/atsisa/gox/reels/command/ResetExtendedSymbolCommand.html>`_: resets/cleans info about current extended symbol
- `ExtendedSymbolResult <../../../apidocs/com/atsisa/gox/reels/logic/ExtendedSymbolResult.html>`_: sets all info about current extended symbol (name, pay table)

Sends:

- `ExtendedSymbolModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/ExtendedSymbolModelChangedEvent.html>`_: after any change in info about current extended symbol

ExtendedSymbolLinesModelProvider
--------------------------------
This class extends the `LinesModelProvider <../../../apidocs/com/atsisa/gox/reels/model/LinesModelProvider.html>`_, by adding new functionality to support new group of winning lines for the extended symbol.

Technical documentation: `ExtendedSymbolLinesModelProvider <../../../apidocs/com/atsisa/gox/reels/model/ExtendedSymbolLinesModelProvider.html>`_

Model: `LinesModel <../../../apidocs/com/atsisa/gox/reels/model/LinesModel.html>`_.

Listens on:

- `ExtendedSymbolWinResult <../../../apidocs/com/atsisa/gox/reels/logic/ExtendedSymbolWinResult.html>`_: updates info about winning lines for extended symbols
- `SwitchWinLinesCommand <../../../apidocs/com/atsisa/gox/reels/command/SwitchWinLinesCommand.html>`_: switches group of winning lines, between normal and extended symbol