=======================
Extended symbol actions
=======================
The are new action module and actions related to the extended symbol feature.

Action module
*************
New action module:

- `ExtendedSymbolActionModule  <../../../apidocs/com/atsisa/gox/reels/action/ExtendedSymbolActionModule.html>`_

Its xml namespace is:

    .. code-block:: xml

        http://www.atsisa.com/gox/reels/extended/symbol/action

Actions
*******
List of new actions related to extended symbol feature:

- `ResetExtendedSymbolAction  <../../../apidocs/com/atsisa/gox/reels/action/ResetExtendedSymbolAction.html>`_: sends a `ResetExtendedSymbolCommand  <../../../apidocs/com/atsisa/gox/reels/command/ResetExtendedSymbolCommand.html>`_ to reset info about current extended symbol in game.
- `SwitchWinLinesAction  <../../../apidocs/com/atsisa/gox/reels/action/SwitchWinLinesAction.html>`_: sends a `SwitchWinLinesCommand  <../../../apidocs/com/atsisa/gox/reels/command/SwitchWinLinesCommand.html>`_ to switch between common and extended winning lines.
- `SelectExtendedSymbolRequestAction  <../../../apidocs/com/atsisa/gox/reels/action/SelectExtendedSymbolRequestAction.html>`_: makes a request on the `IExtendedSymbolGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IExtendedSymbolGameLogic.html>`_ to select extended symbol.

