===============
Reel Game Logic
===============
This feature requires the reel game logic (`IReelGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IReelGameLogic.html>`_) implementation to return additional objects with information about the occurrence of the extended symbol and the winning lines. Additionally the logic of the game should implement an interface: `IExtendedSymbolGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IExtendedSymbolGameLogic.html>`_, which allows to make a request for the extended symbol.

Objects
*******
List of objects which should be returned:

- `ExtendedSymbolResult <../../../apidocs/com/atsisa/gox/reels/logic/ExtendedSymbolResult.html>`_: when extended symbol will appear in the game, should contain information about name and pay table for him.
- `ExtendedSymbolWinResult <../../../apidocs/com/atsisa/gox/reels/logic/ExtendedSymbolWinResult.html>`_: should be dispatched, when winning lines for extended symbol will occur. Contain a list of lines (`ExtendedSymbolWinLine <../../../apidocs/com/atsisa/gox/reels/logic/model/ExtendedSymbolWinLine.html>`_) that describe winning lines for the extended symbol.
