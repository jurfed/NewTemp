=======================
Extended Symbol Feature
=======================

The GOX reels library supports "Extended Symbol" feature, which occurs in games like: **Book Of Ra** or **Lord Of The Ocean**.

Configuration
*************
There are a few things, that needs to be done before, if the game should work with that feature:

#. Dependency

    Add to core project dependencies (in **pom.xml** file):

    .. code-block:: xml

        <dependency>
            <groupId>com.atsisa.gox</groupId>
            <artifactId>gox-reels-feature-extended-symbol</artifactId>
            <version>{version}</version>
        </dependency>

#. IoC

    There a few new interfaces that needs to be registered in the IoC container:

    .. code-block:: java

        bind(IExtendedSymbolModelProvider.class).to(ExtendedSymbolModelProvider.class).asEagerSingleton();
        bind(ILinesModelProvider.class).to(ExtendedSymbolLinesModelProvider.class).asEagerSingleton();

    This is an example with default implementations of that interfaces. The difference for the interface: `ILinesModelProvider  <../../../apidocs/com/atsisa/gox/reels/model/ILinesModelProvider.html>`_, is that we need to provide support for additional winning lines for extended symbol. Class `ExtendedSymbolLinesModelProvider  <../../../apidocs/com/atsisa/gox/reels/model/ExtendedSymbolLinesModelProvider.html>`_ in the library handles it.

#. Actions

    If the action queues are used in the project, then additional action module: `ExtendedSymbolActionModule  <../../../apidocs/com/atsisa/gox/reels/action/ExtendedSymbolActionModule.html>`_ should be registered.

    In xml:

    .. code-block:: xml

        <ActionModules>
            ...
            <ActionModule>com.atsisa.gox.reels.action.ExtendedSymbolActionModule</ActionModule>
            ...
        </ActionModules>

    Code:

    .. code-block:: java

        actionBuilder.registerModule(new ExtendedSymbolActionModule());

Extended symbol idle state
**************************
Name of the state which should be supported by symbol is: **ExtendedState**, to this state symbol will be set, during showing extended state.

Extended symbol animation
*************************
To describe the winning line with extended symbol is used: `ExtendedSymbolWinLine <../../../apidocs/com/atsisa/gox/reels/logic/model/ExtendedSymbolWinLine.html>`_, whose winning animation name is always called: "**ExtendedAnimation**".

Strategies for the Reel Group
*****************************
This library contains two strategies for reel group. These strategies contains functionality, responsible for showing extended symbols on reels and hiding them:

- `ShowExtendedSymbolAnimationsStrategy <../../../apidocs/com/atsisa/gox/reels/view/ShowExtendedSymbolAnimationsStrategy.html>`_: strategy responsible for showing winning symbols on reels (normal and extended) with their animations
- `HideExtendedSymbolAnimationsStrategy <../../../apidocs/com/atsisa/gox/reels/view/HideExtendedSymbolAnimationsStrategy.html>`_: strategy responsible for hiding animations of winning symbols on reels (normal and extended)

Additional components
*********************
List of additional components, which are related to the extended symbol feature:

    .. toctree::
        :titlesonly:

        events-commands
        actions
        providers
        logic