===================================
Extended symbol events and commands
===================================
The are new events and commands related to the extended symbol feature:

Events
******

- `ExtendedSymbolModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/ExtendedSymbolModelChangedEvent.html>`_: triggered when extended symbol model was changed.

Commands
********

- `ResetExtendedSymbolCommand <../../../apidocs/com/atsisa/gox/reels/command/ResetExtendedSymbolCommand.html>`_: should be triggered when the info about current extended symbol should be reset.
- `SwitchWinLinesCommand <../../../apidocs/com/atsisa/gox/reels/command/SwitchWinLinesCommand.html>`_: should be triggered when the group of winning lines should be switched between common and extended symbol.
