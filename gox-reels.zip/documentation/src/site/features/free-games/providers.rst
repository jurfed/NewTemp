====================
Free games providers
====================
Additional provider added by the free games feature.

List of interfaces
******************
List of available interfaces related to the feature:

IFreeGamesModelProvider
-----------------------
Responsibility of the `IFreeGamesModelProvider <../../../apidocs/com/atsisa/gox/reels/model/IFreeGamesModelProvider.html>`_ is to keep information about current free games in game. Implementation of this interface should report the `FreeGamesModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/FreeGamesModelChangedEvent.html>`_, when there is any change related to free games.

Requirements
------------
The default implementations, are based on the objects from logic, which are described here: `Free games logic <./logic.html>`_. Because they are set initial and current state of free games.

List of default implementations
*******************************
List of default provider implementations in library:

FreeGamesModelProvider
----------------------
Technical documentation: `FreeGamesModelProvider <../../../apidocs/com/atsisa/gox/reels/model/FreeGamesModelProvider.html>`_

Model: `FreeGamesModel <../../../apidocs/com/atsisa/gox/reels/model/FreeGamesModel.html>`_.

Listens on:

- `ResetFreeGamesCommand <../../../apidocs/com/atsisa/gox/reels/command/ResetFreeGamesCommand.html>`_: resets/cleans info about current free games
- `FreeGamesProgressResult <../../../apidocs/com/atsisa/gox/reels/logic/FreeGamesProgressResult.html>`_: sets info about total number of free games and current number of free game
- `FreeGamesInfoResult <../../../apidocs/com/atsisa/gox/reels/logic/FreeGamesInfoResult.html>`_: sets info about current state of free games (they have been won, retriggered or end)

Sends:

- `FreeGamesModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/FreeGamesModelChangedEvent.html>`_: after any change in info about free games
