==============================
Free games events and commands
==============================
The are new events and commands related to the free games feature:

Events
******

- `FreeGamesModelChangedEvent <../../../apidocs/com/atsisa/gox/reels/event/FreeGamesModelChangedEvent.html>`_: triggered when free games model was changed.

Commands
********

- `ResetFreeGamesCommand <../../../apidocs/com/atsisa/gox/reels/command/ResetFreeGamesCommand.html>`_: should be triggered when the info about current free games should be reset (e.g. when free games ends).

