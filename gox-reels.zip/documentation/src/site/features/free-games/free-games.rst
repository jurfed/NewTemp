==================
Free Games Feature
==================

The GOX reels library supports "Free Games" feature, which occurs in games like: **Book Of Ra** or **Dolphins Pearl**.

Configuration
*************
There are a few things, that needs to be done before, if the game should work with that feature:

#. Dependency

    Add to core project dependencies (in **pom.xml** file):

    .. code-block:: xml

        <dependency>
            <groupId>com.atsisa.gox</groupId>
            <artifactId>gox-reels-feature-free-games</artifactId>
            <version>{version}</version>
        </dependency>

#. IoC

    There a few new interfaces that needs to be registered in the IoC container:

    .. code-block:: java

        bind(IFreeGamesModelProvider.class).to(FreeGamesModelProvider.class).asEagerSingleton();

    This is an example with default implementations of that interfaces.

#. Actions

    If the action queues are used in the project, then additional action module: `FreeGamesActionModule  <../../../apidocs/com/atsisa/gox/reels/action/FreeGamesActionModule.html>`_ should be registered.

    In xml:

    .. code-block:: xml

        <ActionModules>
            ...
            <ActionModule>com.atsisa.gox.reels.action.FreeGamesActionModule</ActionModule>
            ...
        </ActionModules>

    Code:

    .. code-block:: java

        actionBuilder.registerModule(new FreeGamesActionModule());


Additional components
*********************
List of additional components, which are related to the free games feature:

    .. toctree::
        :titlesonly:

        events-commands
        actions
        providers
        logic