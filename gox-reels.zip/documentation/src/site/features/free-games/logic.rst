===============
Reel Game Logic
===============
This feature requires the reel game logic (`IReelGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IReelGameLogic.html>`_) implementation to return additional objects with information about the free games. Additionally the logic of the game should implement an interface: `IFreeGamesGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IFreeGamesGameLogic.html>`_, which allows to make a request for the next free game.

Objects
*******
List of objects which should be returned:

- `FreeGamesInfoResult <../../../apidocs/com/atsisa/gox/reels/logic/FreeGamesInfoResult.html>`_: should be dispatched, when info about current free games state has changed. This refers to the states when free games are won, they will be retriggered during free games or they will end. To describe the states of free games, the class is used: `FreeGamesInfoType <../../../apidocs/com/atsisa/gox/reels/logic/FreeGamesInfoType.html>`_
- `FreeGamesProgressResult <../../../apidocs/com/atsisa/gox/reels/logic/FreeGamesProgressResult.html>`_: should be dispatched, if there is a change related with total number of free games and the current number of free game.


