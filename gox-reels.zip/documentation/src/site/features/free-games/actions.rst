==================
Free games actions
==================
Free games action module and actions related to the free games feature.

Action module
*************
There is a action module which represents the actions related to the free games feature:

- `FreeGamesActionModule  <../../../apidocs/com/atsisa/gox/reels/action/FreeGamesActionModule.html>`_

Its xml namespace is:

    .. code-block:: xml

        http://www.atsisa.com/gox/reels/free/games/action

Actions
*******
List of actions related to free games feature:

- `ResetFreeGamesAction  <../../../apidocs/com/atsisa/gox/reels/action/ResetFreeGamesAction.html>`_: sends a `ResetFreeGamesCommand  <../../../apidocs/com/atsisa/gox/reels/command/ResetFreeGamesCommand.html>`_ to reset info about current free games in game.
- `SendNextFreeGameRequestAction  <../../../apidocs/com/atsisa/gox/reels/action/SendNextFreeGameRequestAction.html>`_: makes a request on the `IFreeGamesGameLogic <../../../apidocs/com/atsisa/gox/reels/logic/IFreeGamesGameLogic.html>`_ for the next free game.

