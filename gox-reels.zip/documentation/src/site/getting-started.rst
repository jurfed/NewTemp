===============
Getting started
===============

GOX's Reels is a library that expands the GOX game development framework, adding to it all the basic functionality associated with the reel games.

Prerequisites
-------------

To be able to run the game on HTML and Desktop platform you will need the following:

- Eclipse / IntelliJ IDE
- <http://maven.apache.org/download.cgi] Apache Maven 3.1.1+
- <http://www.gwtproject.org/versions.html>`_ GWT 2.8.x

Setting up
----------

Configure Maven settings
************************

To inform the Maven about GameEngine repositories you must add some configuration information to your *~/.m2/settings.xml* file. This file is located at *C:\Documents and Settings\USERNAME\.m2\settings.xml* on Windows XP and *C:\Users\USERNAME\.m2\settings.xml* on Vista and later. If you have no *settings.xml* file, then simply use the below XML to create one, otherwise merge the information from the below file into your existing file:

.. code-block:: xml

  <settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0
                        http://maven.apache.org/xsd/settings-1.0.0.xsd">
    <profiles>
      <profile>
        <id>atsisa</id>
        <activation>
          <activeByDefault>true</activeByDefault>
        </activation>
        <repositories>
          <repository>
            <snapshots>
              <enabled>false</enabled>
            </snapshots>
            <releases>
              <enabled>true</enabled>
            </releases>
            <id>gox-releases</id>
            <url>https://nexus.atsisa.com/repository/gox-releases/</url>
          </repository>
          <repository>
            <id>gox-snapshots</id>
            <url>https://nexus.atsisa.com/repository/gox-snapshots/</url>
            <snapshots>
              <enabled>true</enabled>
            </snapshots>
            <releases>
              <enabled>false</enabled>
            </releases>
          </repository>
          <repository>
            <snapshots>
              <enabled>false</enabled>
            </snapshots>
            <releases>
              <enabled>true</enabled>
            </releases>
            <id>ibg_releases</id>
            <url>https://nexus.atsisa.com/repository/ibg_releases/</url>
          </repository>
          <repository>
            <id>ibg_snapshots</id>
            <url>https://nexus.atsisa.com/repository/ibg_snapshots/</url>
            <snapshots>
              <enabled>true</enabled>
            </snapshots>
            <releases>
              <enabled>false</enabled>
            </releases>
          </repository>
        </repositories>
      </profile>
    </profiles>
    <servers>
      <server>
        <id>atsisa-nexus</id>
        <username>octavian</username>
        <password>xDfBy4nz</password>
      </server>
    </servers>
  </settings>

Generating skeleton project for gox reels
*****************************************

Once we are set up, a maven archetype can be used to generate a reels gox framework project. Open command line and type the following:

::

   mvn archetype:generate -DarchetypeGroupId=com.atsisa.gox -DarchetypeArtifactId=gox-reels-archetype -DarchetypeVersion=CURRENT_VERSION

*CURRENT_VERSION* must be replaced with the newest version of the archetype on the server.

If we want generate project with configured unit tests, static code analysis and sonar, then we need to do this in first step:

::

  mvn archetype:generate -DarchetypeGroupId=com.atsisa.gox -DarchetypeArtifactId=gox-reels-archetype -DarchetypeVersion=CURRENT_VERSION -DaddUnitTests=true -DaddStaticCodeAnalysis=true -DaddSonar=true

*addUnitTests*, *addStaticCodeAnalysis* and *addSonar* This parameters are optional, but if we want to have project with configured unit tests, static code analysis (pmd, cpd, find bugs) and sonar, then we need to set this properties to: "true", "y" or "yes", from default they are set to "false".

The user will be asked to provide some metadata regarding a new game project.

- *groupId* - This should be a reverse domain that identifies your project.
- *artifactId* - This should be an all lowercase identifier that identifies your game.
- *version* - This defines the version used when naming your jar files. You can press enter to use the default: 1.0\-SNAPSHOT, or if you don't plan on using Maven to deploy snapshot versions of your game to a Maven repository, you can specify whatever version you prefer.
- *package* - This defines the Java package in which your game files will be placed. The default will be the value you provided for groupId, which is often also a good package name. However, you can use whatever package you like.
- *GameClassName* - This defines the name used for your game when naming various Java classes. As such it should follow Java class naming conventions and start with an upper\-case letter.
- *GameName* - This defines the name of the game.
- *bomVersion* - This defines the version of the bom, which is the parent pom for the project.
- *resolution* - This defines the resolution of the game, possible values are: **FHD** (generated game will be: 1920x1080) and **UXGA** (generated game will be: 1600x1200)

Sample values are provided below.

::

  Define value for property 'groupId': : com.atsisa.gox
  Define value for property 'artifactId': : mygame
  Define value for property 'version':  1.0-SNAPSHOT :
  Define value for property 'package':  com.atsisa.gox : com.atsisa.gox.mygame
  Define value for property 'GameClassName': : MyGame
  Define value for property 'GameName': : My Game
  Define value for property 'bomVersion': : 1.0.0
  Define value for property 'resolution': : fhd


Once you have provided these properties, you will be asked to confirm that they are correct.

::

  groupId: com.atsisa.gox
  artifactId: mygame
  version: 1.0-SNAPSHOT
  package: com.atsisa.gox.mygame
  GameClassName: MyGame
  GameName: My Game
  addSonar: true
  addStaticCodeAnalysis: true
  addUnitTests: true
  twoMonitors: false
  bomVersion: 1.0.0
  resolution: fhd
   Y: :

Generated new project is complex simple game, which contains: reels (5 reels with 3 symbols on it), bottom panel with basic behaviour, win lines, basic gambler, pay table, info screens (game rules, gambler and info about RTP) and mockup game logic, so project is ready to start.

Two monitors version
--------------------
There is a possibility to generate version for two monitors (this will be one window with resolution: 1920x2160 for **fhd** and: 1600x2400 for **uxga**), it is possible by adding an additional parameter during creation:

::

 mvn archetype:generate -DarchetypeGroupId=com.atsisa.gox -DarchetypeArtifactId=gox-reels-archetype -DarchetypeVersion=CURRENT_VERSION -DtwoMonitors=true

The difference between version for one monitor and version for two monitors is:
- in one monitor, pay table is one of the info screens and in two monitors is a separate screen.
- in one monitor, info screens cover the reels screen (when they are shown) and in two monitors they are on top of the window (reels screen are on the bottom of the window). Thanks to that, they do not overlap and pay table screen is all the time visible.

Importing project into Eclipse
******************************

At this point you could import the newly created game directory into Eclipse by using import wizard (*File | Import... | Existing Maven projects*) Select all the modules and click *Import*.

Importing project into IntelliJ
*******************************

You have to create new Project from existing sources (*File | New | Project from Existing Sources...*) as Maven Project.

Game Structure
--------------

Whole game project is divided into logical modules. Modules are described below using sample files.

mygame-core
***********

Core module is a plain java project which defines common game classes. Classes from core are shared between all platforms.

Generated project contains:

- *MyGame* - common game class
- *MyGameConfiguration* - common game configuration, which can be overridden in platform-specific modules
- *MyGameLogicMockup* - mockup reel game logic
- *MyGameBottomPanelScreen*, *MyGameGamblerScreen*, *MyGameInfoScreen* - basic reel game screens
- *MyGameCoreModule* - contains all IoC configuration for the game

.. figure:: resources/images/struct/struct-core.png

  Exemplary core module structure

mygame-assets
*************

Assets module contains game resources and configuration files. Generated archetype contains mockup configuration, graphics and sounds. Details regarding this module are described in the gox framework documentation of the user guide.

.. figure:: resources/images/struct/struct-assets.png

  Exemplary assets module structure

mygame-web
***********

Html module is a GWT project which implements specific game features for HTML platform. It defines a GWT module *MyGame* and the entry point *MyGameWebEntryPoint* for HTML environment.

.. figure:: resources/images/struct/struct-web.png

  Exemplary HTML module structure

mygame-desktop
***********

Desktop module is a plain java project which implements specific game features for Desktop platform. It defines the *MyGameDesktopEntryPoint* class as the entry point for Desktop environment.

.. figure:: resources/images/struct/struct-desktop.png

  Exemplary Java module structure

To avoid code duplication, everything what can be shared between platforms, should be placed in "core" module. Platform directories contains only a specific code for the platform. All game assets are placed in only one directory.

Running the game in Intellij
----------------

Running Desktop module
**********************

To run a desktop version of the game, select *Run | Edit Configuration | Add New Configuration | Application* from the main menu. In application window fill the fields:
::

  Main Class: com.atsisa.gox.mygame.MyGameDesktopEntryPoint
  Working Directory: global path to the project root
  Use classpath of module: mygame-desktop
  JRE: in minimum version of java 8

Running HTML module
*******************

SuperDevMode only works with the CrossSiteIFrameLinker so in currently there is no possible to run HTML version directly from the Intellij.

Creating releases using Maven
-----------------------------

By running maven installation/package task you are able to create release versions for each module. The example below creates releases for Desktop platform and HTML.

::

  mvn package

Released modules can be found in target directories of each module, for Desktop this will be generated one *.jar file with all dependencies in it and for HTML it will be directory with all files where is index.html which will be a entry point for the game.