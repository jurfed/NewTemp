=========
Providers
=========
The overall presentation state of the game and its management is divided between smaller components, between providers and their models. They decide whether something is possible or not (e.g. is it possible to increase the value of the bet or not).

Initialization
**************
All the providers must be set in IoC container. The default implementations are bind in `ReelsCoreModule <../apidocs/com/atsisa/gox/reels/ReelsCoreModule.html>`_ class, which can be overwritten in custom IoC module configuration.

List of interfaces
******************
List of available interfaces in the library:

IAccount
--------
    `IAccount <../apidocs/com/atsisa/gox/reels/model/IAccount.html>`_ is responsible for keeping information about player financial account. Implementation of this interface should report the `BalanceChangedEvent <../apidocs/com/atsisa/gox/reels/event/BalanceChangedEvent.html>`_, when there is a change in user financial.

IBetModelProvider
-----------------
    `IBetModelProvider <../apidocs/com/atsisa/gox/reels/model/IBetModelProvider.html>`_ is responsible for updating and controlling bet configuration. It has its own implementation of `IBetModel <../apidocs/com/atsisa/gox/reels/IBetModel.html>`_ interface. It should report `BetModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/BetModelChangedEvent.html>`_, when there is any change in its bet model.

IErrorModelProvider
-------------------
    Responsibility of the `IErrorModelProvider <../apidocs/com/atsisa/gox/reels/model/IErrorModelProvider.html>`_ is to control the errors in the game. Has its own implementation of `IErrorModel <../apidocs/com/atsisa/gox/reels/model/IErrorModel.html>`_ interface. It should report `GameErrorCommand <../apidocs/com/atsisa/gox/reels/command/GameErrorCommand.html>`_, when an error occurs.

IGamblerModelProvider
---------------------
    Responsibility of the `IGamblerModelProvider <../apidocs/com/atsisa/gox/reels/model/IGamblerModelProvider.html>`_ is to updating and control gambler configuration. Has its own implementation of `IGamblerModel <../apidocs/com/atsisa/gox/reels/model/IGamblerModel.html>`_ interface. Should report `GamblerModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerModelChangedEvent.html>`_, when there is any change in the model.

IHistoryModelProvider
---------------------
    Responsibility of the `IHistoryModelProvider <../apidocs/com/atsisa/gox/reels/model/IHistoryModelProvider.html>`_ is to updating and control player history. Has its own implementation of `IHistoryModel <../apidocs/com/atsisa/gox/reels/model/IHistoryModel.html>`_ interface. Should report `HistoryModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/HistoryModelChangedEvent.html>`_, when there is any change in the model.

ILinesModelProvider:
    `ILinesModelProvider <../apidocs/com/atsisa/gox/reels/model/ILinesModelProvider.html>`_ is responsible for updating and controlling lines configuration. It has its own implementation of `ILinesModel <../apidocs/com/atsisa/gox/reels/model/ILinesModel.html>`_ interface. It should report `LinesModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_, when there is any change in the lines model.

IPayTableModelProvider
----------------------
    Responsibility of the `IPayTableModelProvider <../apidocs/com/atsisa/gox/reels/model/IPayTableModelProvider.html>`_ is to updating and control pay table configuration. Has its own implementation of `IPayTableModel <../apidocs/com/atsisa/gox/reels/model/IPayTableModel.html>`_ interface. Should report `PayTableModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/PayTableModelChangedEvent.html>`_, when there is any change in the model.

All interfaces are available under:

    .. code-block:: java

        import com.atsisa.gox.reels.model.*;

Default implementations
***********************
The reels library has default implementations of providers with models, under:

    .. code-block:: java

        import com.atsisa.gox.reels.model.*;

Requirements
------------
The default implementations are based on the presentations from the logic. Because they all set their initial and current state based on them.

List of default implementations
*******************************
List of default provider implementations in library:

Account
-------
Keeps the history of the last 5 transactions.

Technical documentation: <Account <../apidocs/com/atsisa/gox/reels/model/Account.html>`_

Listens on:

- `TransferCreditsCommand <../apidocs/com/atsisa/gox/reels/command/TransferCreditsCommand.html>`_: updates user balance
- `ReelGamePresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/ReelGamePresentation.html>`_: updates user balance
- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: updates user balance and currency code

Sends:

- `BalanceChangedEvent <../apidocs/com/atsisa/gox/reels/event/BalanceChangedEvent.html>`_: after any change in user balance

BetModelProvider
----------------
Technical documentation: `BetModelProvider <../apidocs/com/atsisa/gox/reels/model/BetModelProvider.html>`_

Model: `BetModel <../apidocs/com/atsisa/gox/reels/model/BetModel.html>`_.

Listens on:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: updates bet steps, current bet and total bet
- `ReelGamePresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/ReelGamePresentation.html>`_: updates current bet when presentation changes
- `IncreaseBetCommand <../apidocs/com/atsisa/gox/reels/command/IncreaseBetCommand.html>`_: increases bet value if possible
- `DecreaseBetCommand <../apidocs/com/atsisa/gox/reels/command/DecreaseBetCommand.html>`_: decreases bet value if possible
- `SetBetCommand <../apidocs/com/atsisa/gox/reels/command/SetBetCommand.html>`_: sets given bet value
- `SetMinBetCommand <../apidocs/com/atsisa/gox/reels/command/SetMinBetCommand.html>`_: sets min bet value
- `SetMaxBetCommand <../apidocs/com/atsisa/gox/reels/command/SetMaxBetCommand.html>`_: sets max bet value
- `LinesModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: when number of active lines changes, total bet needs to be updated

Sends:

- `IBetModel <../apidocs/com/atsisa/gox/reels/model/IBetModel.html>`_: after any change in model

ErrorModelProvider
------------------
Technical documentation: `ErrorModelProvider <../apidocs/com/atsisa/gox/reels/model/ErrorModelProvider.html>`_

Model: `ErrorModel <../apidocs/com/atsisa/gox/reels/model/ErrorModel.html>`_.

Listens on:

- `ResetGameCommand <../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_: resets model
- ErrorOccurredEvent: sends a request to handle the error
- `GameMessageChangedEvent <../apidocs/com/atsisa/gox/reels/event/GameMessageChangedEvent.html>`_: if message type is an error, then updates the model

Sends:

- `ErrorModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/ErrorModelChangedEvent.html>`_: after any change in model
- `GameErrorCommand <../apidocs/com/atsisa/gox/reels/command/GameErrorCommand.html>`_: sends when error should be handled
- `ChangeGameMessageCommand <../apidocs/com/atsisa/gox/reels/command/ChangeGameMessageCommand.html>`_: when game message needs to be changed

GamblerModelProvider
--------------------
Technical documentation: `GamblerModelProvider <../apidocs/com/atsisa/gox/reels/model/GamblerModelProvider.html>`_

Model: `GamblerModel <../apidocs/com/atsisa/gox/reels/model/GamblerModel.html>`_.

Listens on:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: updates play limit and win limit for gambler
- `GamblerPresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/GamblerPresentation.html>`_: updates gamble amount, history and history size in gambler

Sends:

- `GamblerModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/GamblerModelChangedEvent.html>`_: after any change in model

HistoryModelProvider
--------------------
Technical documentation: `HistoryModelProvider <../apidocs/com/atsisa/gox/reels/model/HistoryModelProvider.html>`_

Model: `HistoryModel <../apidocs/com/atsisa/gox/reels/model/HistoryModel.html>`_.

Listens on:

- `HistoryCloseEvent <../apidocs/com/atsisa/gox/reels/event/HistoryCloseEvent.html>`_: clears model
- `HistoryResult <../apidocs/com/atsisa/gox/reels/logic/HistoryResult.html>`_: updates total number of pages in history, current page date and number

Sends:

- `HistoryModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/HistoryModelChangedEvent.html>`_: after any change in model

LinesModelProvider
------------------
Technical documentation: `LinesModelProvider <../apidocs/com/atsisa/gox/reels/model/LinesModelProvider.html>`_

Model: `LinesModel <../apidocs/com/atsisa/gox/reels/model/LinesModel.html>`_.

Listens on:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: updates info about available lines and selected lines
- `WinningPresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/WinningPresentation.html>`_: updates info about winning lines
- `ShowNextWinningLineCommand <../apidocs/com/atsisa/gox/reels/command/ShowNextWinningLineCommand.html>`_: changes currently showing winning lines to next (only then if there is a win)
- `ResetWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/ResetWinningLinesCommand.html>`_: resets currently showing winning lines (only then if there is a win)
- `HideWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/HideWinningLinesCommand.html>`_: hides winning lines (only then if there is a win)
- `IncreaseLinesCommand <../apidocs/com/atsisa/gox/reels/command/IncreaseLinesCommand.html>`_: increases amount of selected lines
- `DecreaseLinesCommand <../apidocs/com/atsisa/gox/reels/command/DecreaseLinesCommand.html>`_: decreases amount of selected lines
- `ReelGamePresentation <../apidocs/com/atsisa/gox/reels/logic/ReelGamePresentation.html>`_: changes number of lines according to presentation
- `CleanWinningLinesCommand <../apidocs/com/atsisa/gox/reels/command/CleanWinningLinesCommand.html>`_: cleans showing winning lines

Sends:

- `LinesModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: after any change in model

PayTableModelProvider
---------------------
Technical documentation: `PayTableModelProvider <../apidocs/com/atsisa/gox/reels/model/PayTableModelProvider.html>`_

Model: `PayTableModel <../apidocs/com/atsisa/gox/reels/model/PayTableModel.html>`_.

Listens on:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: updates pay table base values
- `LinesModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: based on current line, updates pay table values
- `BetModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/BetModelChangedEvent.html>`_: clears model: based on current bet, updates pay table values

Sends:

- `PayTableModelChangedEvent <../apidocs/com/atsisa/gox/reels/event/PayTableModelChangedEvent.html>`_: after any change in model