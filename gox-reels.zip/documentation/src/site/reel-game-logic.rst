===============
Reel Game Logic
===============

This interface (`IReelGameLogic <../apidocs/com/atsisa/gox/reels/logic/IReelGameLogic.html>`_) is used to communicate with logic of the reel game. All requests that affect the game flow are addressed to it (make bet, take win, etc.) and based on its response, data in reel game models are set.

Custom implementation
*********************
We can provide custom implementation of that interface, by adding it to the IoC configuration.

    .. code-block:: java

        bind(IReelGameLogic.class).to(CustomReelGameLogic.class).asEagerSingleton();

Good practice will be add *asEagerSingleton* to binding, because many classes will need access to it and without this, each of that class will get a new instance.

Accessibility
-------------
The reel game logic interface is accessible in two ways:

#. Using static access:

     .. code-block:: java

        IReelGameLogic reelGameLogic = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameLogic();


#. During class initialization via IoC:

    .. code-block:: java

        //constructor
        @Inject
        public ClassConstructor(IReelGameLogic reelGameLogic);

        //or setter
        @Inject
        public void setReelGameLogic(IReelGameLogic reelGameLogic);


Game Logic Mockup
*****************
The reels library, currently provides an abstract implementation of logic mockup `AbstractGameLogicMockup <../apidocs/com/atsisa/gox/reels/logic/AbstractGameLogicMockup.html>`_. If the game is made from the archetype, then there is an example implementation, which extends this mockup. It is in *logic* namespace in game and adds game-specific behaviour/configuration (number of lines, bet steps, mockup win and lose).

Game Logic Implementation
*************************
Game Logic Mockup is a temporary solution, and Game Logic should be provided in a separate module and loaded by terminal. 
To create Game Logic module, create new module *MyGameLogic* with package *com.atsisa.gox.logic.mygame*, including files:

- MyGameLogic.java

.. code-block:: java

        public class MyGameLogic extends ReelsGameLogic {
		
- MyGameLogicModule.java

.. code-block:: java

		public class MyGameLogicModule extends AbstractModule {
			@Override
			protected void configure() {
				bind(IRngService.class).to(RngService.class).in(Singleton.class);
				bind(IReelsGameLogic.class).to(MyGameLogic.class).in(Singleton.class);
			}
		}
		
- MyGameReelsGame.java (assume we want to make a game with dice multiplier feature)

.. code-block:: java

		public class MyGameReelsGame extends ReelsGame {	
			private int dice;
			public MyGameReelsGame(Collection<Reel> reels, Collection<WinLine> winningLines, int dice) {
				super(reels, winningLines);
				this.dice = dice;
			}
		}

Requests
********
This interface allow us to make requests on game logic for:

- *init*: makes init on the game logic, should be called before calling any other request.
- *bet*: should be called when user wants to make bet.
- *takeWin*: should be called when user wants to take win, for example: during offer gambler.
- *gamble*: should be called when user selected card in gambler.
- *enterGambler*: should be called when user wants to enter the gambler.

After making a request, implementation should return observable object, to which we can subscribe for results.

Request types
-------------
To make a request, we can use specific objects to more specify it:

- `InitRequest <../apidocs/com/atsisa/gox/reels/logic/request/InitRequest.html>`_: is used during initialization logic, with this object we can determine in what language and what identifier has a game that we want to initialize.
- `BetRequest <../apidocs/com/atsisa/gox/reels/logic/request/BetRequest.html>`_: is used to determine bet and lines amount during make a bet request.
- `EnterGamblerRequest <../apidocs/com/atsisa/gox/reels/logic/request/EnterGamblerRequest.html>`_: is used to during request to enter gambler, we need to pass info about current bet and lines amount.
- `GambleRequest <../apidocs/com/atsisa/gox/reels/logic/request/GambleRequest.html>`_: is used to determine the selection in the gambler.

Response
********
After we made a request, we can subscribe for the response:

    .. code-block:: java

        reelGameLogic.takeWin().subscribe(new Action1<Object>() {

            @Override
            public void call(Object returnObject) {
                //called when logic is returns object
            }
        }, new Action1<Throwable>() {

            @Override
            public void call(Throwable throwable) {
                //called when logic is thrown exception
            }
        }, new Action0() {

            @Override
            public void call() {
                //called when logic stopped returning objects and the request is completed
            }
        }

Returned objects
----------------
After subscribing, logic can return several objects, depending on the request. However, some of the objects returned should be of a certain type. For the example when we make a bet and we won, then logic should return: **ReelGamePresentation** and **WinningPresentation** objects. The basic types that logic should return are:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: after game logic was initialized.
- `ReelGamePresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/ReelGamePresentation.html>`_: contains information about common game state (symbols on reels, presentation name, current game play properties)
- `WinningPresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/WinningPresentation.html>`_: when it is won in the game.
- `GamblerPresentation <../apidocs/com/atsisa/gox/reels/logic/presentation/GamblerPresentation.html>`_: during a presentations related to the gambler (win, lose, enter).

Custom implementation should return these types of objects, because many providers, models etc. are registered in event bus to listen for them.
