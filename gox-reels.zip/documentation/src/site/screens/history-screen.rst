==============
History Screen
==============

The history screen `HistoryScreen <../../apidocs/com/atsisa/gox/reels/screen/HistoryScreen.html>`_ contains an implementation that supports a layout for session-based history. Shows history pages with winning animations, lines and prizes. Shows navigation for browsing through pages. Resolves visibility of navigation buttons.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        HistoryScreen screen = new HistoryScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus, localization);


#. IoC:

    .. code-block:: java

        bindConstant().named(HistoryScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(Screen.class).to(HistoryScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.


Incoming events/commands
************************
List of events/commands handled by this screen:

- `HistoryModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/HistoryModelChangedEvent.html>`_: updates navigation, shows current page number and/or date (depends on configuration).


Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *exitHistoryClicked*: sends `ExitHistoryCommand <../../apidocs/com/atsisa/gox/reels/command/ExitHistoryCommand.html>`_
- *showPreviousHistoryPageClicked*: sends `ShowPreviousHistoryPageCommand <../../apidocs/com/atsisa/gox/reels/command/ShowPreviousHistoryPageCommand.html>`_
- *showNextHistoryPageClicked*: sends `ShowNextHistoryPageCommand <../../apidocs/com/atsisa/gox/reels/command/ShowNextHistoryPageCommand.html>`_

Model
*****
`HistoryScreenModel <../../apidocs/com/atsisa/gox/reels/screen/model/HistoryScreenModel.html>`_ contains all properties required to render a history screen.

Supports variables:

- currentHistoryPageNumber - currently shown history page.
- totalNumberHistoryPages - number of total pages in history.
- currentHistoryPageDate - date for current history page.

Date can be configured in configuration xml file as one of the properties. Possible formats are:

- *yyyy.MM.dd G 'at' HH:mm:ss vvvv* - 2017.07.10 AD at 15:08:56 Poland/Warsaw
- *EEE, MMM d, ''yy* - Wed, July 10, '17
- *h:mm a* - 12:08 PM
- *hh 'o''clock' a, zzzz* - 12 o'clock PM, Pacific Daylight Time
- *K:mm a, vvvv* - 0:00 PM, Poland/Warsaw
- *yyyyy.MMMMM.dd GGG hh:mm aaa* - 02017.July.10 AD 12:08 PM


Example below shows history date format entry in configuration xml file:

    .. code-block:: xml

        <Configuration xmlns="http://www.atsisa.com/gox/framework/configuration"> 
            ...
            <Properties>
                ...
                <Property name="historyDateFormat" type="string" value="MM/dd/yyyy HH:mm:ss"/>
                ...
            </Properties>
            ...
        </Configuration>


