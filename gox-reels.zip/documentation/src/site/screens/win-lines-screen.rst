================
Win Lines Screen
================
The win lines screen `WinLinesScreen <../../apidocs/com/atsisa/gox/reels/screen/WinLinesScreen.html>`_ manages the layout containing lines in the game and shows / hides them in response to incoming events connected with lines. Prizes on winning lines are displayed with currency. Winning lines must implement `IWinLine <../../apidocs/com/atsisa/gox/reels/view/spi/IWinLine.html>`_ to be able to find the lines.


Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        WinLinesScreen screen = new WinLinesScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus, creditsFormatter, linesModelMutator);


#. IoC:

    .. code-block:: java

        bindConstant().named(WinLinesScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(Screen.class).to(WinLinesScreen.class);

    It is important to bind constant with value, under which id is the layout for this screen.


Incoming events/commands
************************
List of events/commands handled by this screen:

- `LinesModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: shows available lines layout or winning lines if there is a win.

- `BetModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/BetModelChangedEvent.html>`_: switches visibility of available active lines.

- `SpinReelsCommand <../../apidocs/com/atsisa/gox/reels/command/SpinReelsCommand.html>`_: hides available active lines.


Outgoing events/commands
************************
List of events/commands reported by this screen:

- `WinningLineShownEvent <../../apidocs/com/atsisa/gox/reels/event/WinningLineShownEvent.html>`_: reports that a winning line has been shown.


Expose Methods
**************
- reset: hides winning lines.


Lines Model Mutator
*******************
Translates data from logic to model to properly show winning lines.