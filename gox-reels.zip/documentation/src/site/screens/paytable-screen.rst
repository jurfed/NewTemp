================
Pay Table Screen
================

The pay table screen `PayTableScreen <../../apidocs/com/atsisa/gox/reels/screen/PayTableScreen.html>`_ contains an implementation that supports a layout for pay table. Shows prizes for symbols according to specified bet. Shows information about scatter symbol, substitute symbols and short info about game's feature.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        PayTableScreen screen = new PayTableScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus);


#. IoC:

    .. code-block:: java

        bindConstant().named(PayTableScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(Screen.class).to(PayTableScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.


Incoming events/commands
************************
List of events/commands handled by this screen:

- `PayTableModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/PayTableModelChangedEvent.html>`_: updates paytable values.


Model
*****
`PayTableScreenModel <../../apidocs/com/atsisa/gox/reels/screen/model/PayTableScreenModel.html>`_ contains all data for pay table screen. Supports formatting currency code for prize .

Example below shows configuration xml file with added *displayCurrencyOnPayTable* variable which allows switching visibility of currency code:

    .. code-block:: xml

        <Configuration>
            ...
            <Properties>
                ...
                <Property name="displayCurrencyOnPayTable" type="boolean" value="true" />
                ...
            </Properties>
            ...
        </Configuration>

PayTableScreenModel uses `PayTableModelItem <../../apidocs/com/atsisa/gox/reels/model/PayTableModelItem.html>`_ to store and access (by comparing PayTableModelItem's name) data about symbols's prizes. Next example shows how paytable value is accessed in pay table's layout:

    .. code-block:: xml
    
        <ViewGroup>
            <children>
                ...
                <ViewGroup x="415" y="202">
                    ...
                    <children>
                        <TextView text="{#DIAMOND_X_4}" width="180" skin="@skin/payTableItemText"/>
                        <TextView text="{#DIAMOND_X_3}" y="84" width="180" skin="@skin/payTableItemText"/>
                    </children> 
                    ...
                </ViewGroup>
                ...
            </children>
        </ViewGroup>

Where *DIAMOND_X_4* and *DIAMOND_X_3* are names of PayTableModelItems with stored values.