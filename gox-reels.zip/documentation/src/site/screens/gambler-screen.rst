==============
Gambler Screen
==============
The Gambler Screen `GamblerScreen <../../apidocs/com/atsisa/gox/reels/screen/GamblerScreen.html>`_ contains an implementation for showing Gambler Screen layout.
This screen is designed for simple gambler feature, with possibility to double win by choosing red or black card. The layout supports the history cards.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        GamblerScreen screen = new GamblerScreen("layoutId", model, renderer, viewManager, animationFactory,
                                                        logger, eventBus, resourceManager, creditsFormatter);


#. IoC:

    .. code-block:: java

        bindConstant().named(GamblerScreen.LAYOUT_ID_PROPERTY).to("layoutId");

        bindConstant().named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/red_small_card.png");
        bindConstant().named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@image/small_clubs_card");
        bindConstant().named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/small_diamond_card.png");
        bindConstant().named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/small_heart_card.png");
        bindConstant().named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/small_spade_card.png");
        bindConstant().named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/spade_card.png");
        bindConstant().named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/clubs_card.png");
        bindConstant().named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/heart_card.png");
        bindConstant().named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/diamond_card.png");
        bindConstant().named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/exampleAtlas/blue_card.png");

        bind(Screen.class).to(GamblerScreen.class);
        bind(GamblerScreenModel.class);


Please keep in mind, that during IoC initialization it is necessary to provide all bindings to all card properties. The graphic resource can be either
image reference to a picture or into spritesheet.


Incoming events/commands
************************
List of events/commands handled by this screen:

- `GamblerModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/GamblerModelChangedEvent.html>`_: updates a gamble amount value according to recent gambler model changes.
- `UpdateGamblerScreenCommand <../../apidocs/com/atsisa/gox/reels/command/UpdateGamblerScreenCommand.html>`_: updates a gambler screen state.


Outgoing events/commands
************************
List of events/commands reported by this screen:

- GamblerCardSelectedEvent `GamblerCardSelectedEvent <../../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_: triggered when gambler card was selected.


Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *selectBlack*: sends a command to select black card in gambler.
- *selectRed*: sends a command to select red card in gambler.
- *reset*: reset gambler main card and history cards.
- *pause*: pause gambler main card and history cards.

Gambler Screen Model
********************

List of variables that are available for the template from model `GamblerScreenModel <../../apidocs/com/atsisa/gox/reels/screen/model/GamblerScreenModel.html>`_.

- *gambleAmount*: contains  current gamble amount.
- *gambleToWin*: contains current gamble to win amount.

Layout
******
The layout that is supported by this screen must have:

- child with id: mainCard, which extends the `AbstractGamblerCard <../../apidocs/com/atsisa/gox/reels/view/AbstractGamblerCard.html>`_ class.

If layout should support history cards, then history cards (views) should contain "history" tag, order of history cards is the same as order declaration in layout