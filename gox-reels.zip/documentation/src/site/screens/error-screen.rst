============
Error Screen
============

The error screen `ErrorScreen <../../apidocs/com/atsisa/gox/reels/screen/ErrorScreen.html>`_ contains an implementation responsible for correctly displaying information about the current error in game. Default layout contains "Retry" button.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        ErrorScreen screen = new ErrorScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus, gameConfiguration);


#. IoC:

    .. code-block:: java

        //optional
        bindConstant().named(ErrorScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        //required
        bind(Screen.class).to(ErrorScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.

    Binding layout is optional. If no layout will be provided then default one will be generated.

Incoming events/commands
************************
List of events/commands handled by this screen:

- `ErrorModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/ErrorModelChangedEvent.html>`_: handles displaying error info.

Outgoing events/commands
************************
List of events/commands reported by this screen:

- `ResetGameCommand <../../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_: triggered when retry button is pressed.

Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *retryButtonClicked*: sends `ResetGameCommand <../../apidocs/com/atsisa/gox/reels/command/ResetGameCommand.html>`_.

Layout
******
The layout is not obligatory. If none will be added then default one will be generated.