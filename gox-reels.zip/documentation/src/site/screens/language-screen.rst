===============
Language Screen
===============

The language screen `LanguageScreen <../../apidocs/com/atsisa/gox/reels/screen/LanguageScreen.html>`_ provides an implementation for changing languages.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        LanguageScreen screen = new LanguageScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus);


#. IoC:

    .. code-block:: java

        bindConstant().named(BaseGameScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(Screen.class).to(BaseGameScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.


Outgoing events/commands
************************
List of events/commands reported by this screen:

- ChangeLanguageCommand: triggered when language should be changed.

Layout
******

If we want to change language layout must contain interactive views with attribute "tags" and value "langButton:XX" where XX is previously registered language code.


Example below shows part of the layout with buttons that change the language after clicking.

.. code-block:: xml

        <ViewGroup y="89" x="194" tags="langButton:EN">
            <children>
                <RectangleShapeView width="371" height="45" fillColor="#041126"/>
                <TextView text="English" color="#ffffff" fontSize="22" width="371" height="45" halign="CENTER" valign="MIDDLE"/>
            </children>
        </ViewGroup>

        <ViewGroup y="163" x="194" tags="langButton:DE">
            <children>
                <RectangleShapeView width="371" height="45" fillColor="#041126"/>
                <TextView text="German" color="#ffffff" fontSize="22" width="371" height="45" halign="CENTER" valign="MIDDLE"/>
            </children>
        </ViewGroup>

        <ViewGroup y="237" x="194" tags="langButton:CS">
            <children>
                <RectangleShapeView width="371" height="45" fillColor="#041126"/>
                <TextView text="Czech" color="#ffffff" fontSize="22" width="371" height="45" halign="CENTER" valign="MIDDLE"/>
            </children>
        </ViewGroup>
