===========
Info Screen
===========

The info screen `InfoScreen <../apidocs/com/atsisa/gox/reels/screen/InfoScreen.html>`_ contains an implementation that supports the info screens and transitions between them.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        InfoScreen screen = new InfoScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);

#. IoC:

    .. code-block:: java

        bindConstant().named(InfoScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(InfoScreenTransition.class).to(TopDownInfoScreenTransition.class);

    It is important to bind constant with value, under what id is the layout for this screen.

Incoming events/commands
************************
List of events/commands handled by this screen:

- `InitResult <../apidocs/com/atsisa/gox/reels/logic/InitResult.html>`_: The RTP value is set based on init response.
- `ShowInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/ShowInfoScreenCommand.html>`_: This command is used to show info screen or to switch between views


Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *pause*: pause current view animation.
- *reset*: stops current view animation and hides screen.

Adding screens
**************
To add another screen it is necessary to create view as a child (each view can be treated as "info screen") in layout file, which is responsible for displaying each view. Please find below example of 2-screen layout.


    .. code-block:: java

        <ViewGroup xmlns="http://www.atsisa.com/gox/framework/view" y="-1080" height="1080">
            <children>

                <ViewGroup id="infoScreen1" visible="false" height="1080">
                    <children>
                        <ImageView x="-240" src="@image/infoScreenBackground2"/>
                        <TextView text="{#LangRules}" fontName="lobster-120" fontSize="120" x="20" y="110" width="1880"
                                  halign="CENTER"/>
                        <TextView text="{#LangRulesDescription}" fontName="castlet-bold-40" fontSize="40" x="20" y="270"
                                  width="1880" halign="CENTER"/>
                        <TextView text="{#LangWinCombinations}" fontName="lobster-120" fontSize="120" x="20" y="630"
                                  width="1880" halign="CENTER"/>
                    </children>
                </ViewGroup>

                <ViewGroup id="infoScreen2" visible="false" height="1080">
                    <children>
                        <ImageView x="-240" src="@image/infoScreenBackground3"/>
                        <TextView text="{#LangGamblerFeature}" fontName="lobster-120" fontSize="120" x="20" y="110"
                                  width="1880" halign="CENTER"/>
                        <TextView text="{#LangGamblerFeatureDescription}" fontName="castlet-bold-40" fontSize="40" x="20"
                                  y="270" width="1880" halign="CENTER" wordWrap="true"/>
                    </children>
                </ViewGroup>

             </children>
        </ViewGroup>

Showing
*******
This screen display functionality works a little differently than in normal screens. First call of show using screen API or command, will show first view declared in layout.xml, every next request to show again this screen will display next view from layout using info screen transition (view animation data will be ignored). After the last view will be shown, then the next show request will hide this screen. There is a possibility to show screen at specific view or to switch between them to show that view, using command: `ShowInfoScreenCommand <../apidocs/com/atsisa/gox/reels/command/ShowInfoScreenCommand.html>`_.

Transitions
***********
The way of how info screens switch between themselves, depends on the implementation of `InfoScreenTransition <../apidocs/com/atsisa/gox/reels/screen/transition/InfoScreenTransition.html>`_. In reels library the two implementations of `InfoScreenTransition <../apidocs/com/atsisa/gox/reels/screen/transition/InfoScreenTransition.html>`_ are available by default:

- *TopDownInfoScreenTransition*: Represents a transition in which the next screen goes down and hides the previous screen.
- *BottomUpInfoScreenTransition*: Represents a transition in which the previous screen goes up and reveals the next screen.

The InfoScreenTransition should be passed in the constructor or bind it in IoC configuration.