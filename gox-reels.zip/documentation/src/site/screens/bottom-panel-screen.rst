===================
Bottom Panel Screen
===================

The bottom panel screen `BottomPanelScreen <../../apidocs/com/atsisa/gox/reels/screen/BottomPanelScreen.html>`_ is a class responsible for handling all buttons.
If the user wants to control the states of buttons, the following steps must be proceed :

- Extend `BottomPanelScreen <../../apidocs/com/atsisa/gox/reels/screen/BottomPanelScreen.html>`_ class.
- Overwrite *stateChanged* method and add there responsible logic.

Initialization
**************
This panel can be initialized in two ways:

#. Code:

    .. code-block:: java

        BottomPanelScreen screen = new BottomPanelScreen("layoutId", bottomPanelScreenModel, renderer,
        viewManager, animationFactory, logger, eventBus, account, linesModelMutator);


#. IoC:

    .. code-block:: java

        bindConstant().named(BottomPanelScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(BottomPanelScreenModel.class);
        bind(Screen.class).to(BottomPanelScreen.class);


Incoming events/commands
************************
List of events/commands handled by this screen:

- `BalanceChangedEvent <../../apidocs/com/atsisa/gox/reels/event/BalanceChangedEvent.html>`_: updates remaining credits according to the balance events
- `GamblerModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/GamblerModelChangedEvent.html>`_: updates a win value according to recent gambler model changes.
- `BetModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/BetModelChangedEvent.html>`_: updates a bet value according to recent bet model changes.
- `LinesModelChangedEvent <../../apidocs/com/atsisa/gox/reels/event/LinesModelChangedEvent.html>`_: updates a number of active lines according to recent lines model changes.
- `GameMessageChangedEvent <../../apidocs/com/atsisa/gox/reels/event/GameMessageChangedEvent.html>`_: updates a bottom panel message according to recently published value.
- `UpdateBottomPanelCommand <../../apidocs/com/atsisa/gox/reels/command/UpdateBottomPanelCommand.html>`_: handles bottom panel state changes.

Outgoing events/commands
************************
List of events/commands reported by this screen:

- `IncreaseLinesCommand <../../apidocs/com/atsisa/gox/reels/command/IncreaseLinesCommand.html>`_: triggered when current number of lines should be increased.
- `DecreaseLinesCommand <../../apidocs/com/atsisa/gox/reels/command/DecreaseLinesCommand.html>`_: triggered when current number of lines should be decreased.
- `IncreaseBetCommand <../../apidocs/com/atsisa/gox/reels/command/IncreaseBetCommand.html>`_: triggered when bet value should be increased.
- `DecreaseBetCommand <../../apidocs/com/atsisa/gox/reels/command/DecreaseBetCommand.html>`_: triggered when bet value should be decreased.
- `SetMaxBetCommand <../../apidocs/com/atsisa/gox/reels/command/SetMaxBetCommand.html>`_: triggered when max bet value should be increased.
- `SetMinBetCommand <../../apidocs/com/atsisa/gox/reels/command/SetMinBetCommand.html>`_: triggered when max bet value should be decreased.
- `SpinCommand <../../apidocs/com/atsisa/gox/reels/command/SpinCommand.html>`_: triggered when spin button has been clicked.
- `SkipCommand <../../apidocs/com/atsisa/gox/reels/command/SkipCommand.html>`_: triggered when skip button has been clicked.
- `TakeWinCommand <../../apidocs/com/atsisa/gox/reels/command/TakeWinCommand.html>`_: command used to send request about take win.
- `StartAutoPlayCommand <../../apidocs/com/atsisa/gox/reels/command/StartAutoPlayCommand.html>`_: command used to start auto start.
- `StopAutoPlayCommand <../../apidocs/com/atsisa/gox/reels/command/StopAutoPlayCommand.html>`_: a request to stop auto start
- `GamblerCardSelectedEvent <../../apidocs/com/atsisa/gox/reels/event/GamblerCardSelectedEvent.html>`_: triggered when gambler card was selected.
- `EnterHistoryCommand <../../apidocs/com/atsisa/gox/reels/command/EnterHistoryCommand.html>`_: request to enter history

Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *increaseLines*: sends a command to increase the number of lines
- *decreaseLines*: sends a command to decrease the number of lines
- *increaseBet*: sends a command to increase the bet value
- *decreaseBet*: sends a command to increase the bet value
- *setMaxBet*: sends a command to increase bet to max value
- *setMinBet*: sends a command to increase bet to min value
- *spin*:  sends a command to spin the reels
- *skip*:  sends a command to skip the reels spinning
- *takeWin*:  sends a command to add win amount to credit area
- *startAutoPlay*: sends a command to start auto play
- *stopAutoPlay*:  sends a command to stop auto play
- *gamblerBlackSelected*:  sends a command to choose black card in gambler mode
- *gamblerRedSelected*:  sends a command to choose red card in gambler mode
- *enterHistory*:  sends a command to enter to game history


Bottom Panel Screen Model
*************************

Bottom Panel Screen Model is a class, which contains helper methods used in BottomPanel.
"List of variables that are available for the template from model `BottomPanelScreenModel <../../apidocs/com/atsisa/gox/reels/screen/model/BottomPanelScreenModel.html>`_:

- bet: contains current bet value
- totalBet: contains current  total bet value
- line: contains current line value
- credits: contains current credits value
- win: contains current win value
- message: contains current message area value

