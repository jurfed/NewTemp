================
Base Game Screen
================
The base game screen `BaseGameScreen <../../apidocs/com/atsisa/gox/reels/screen/BaseGameScreen.html>`_ contains an implementation that supports a layout with reels.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        BaseGameScreen screen = new BaseGameScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus);


#. IoC:

    .. code-block:: java

        bindConstant().named(BaseGameScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        bind(Screen.class).to(BaseGameScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.


Incoming events/commands
************************
List of events/commands handled by this screen:

- `SpinReelsCommand <../../apidocs/com/atsisa/gox/reels/command/SpinReelsCommand.html>`_: starts spinning the reels.
- `DisplayStoppedSymbolsCommand <../../apidocs/com/atsisa/gox/reels/command/DisplayStoppedSymbolsCommand.html>`_: updates the symbols that are displayed on the reels.
- `StopReelsCommand <../../apidocs/com/atsisa/gox/reels/command/StopReelsCommand.html>`_: starts stopping the reels.
- `StopAnimationWinningSymbolsCommand <../../apidocs/com/atsisa/gox/reels/command/StopAnimationWinningSymbolsCommand.html>`_: stops showing animations of winning symbols on reels.
- `StartAnimationWinningSymbolsCommand <../../apidocs/com/atsisa/gox/reels/command/StartAnimationWinningSymbolsCommand.html>`_: shows winning symbols on reels.

Outgoing events/commands
************************
List of events/commands reported by this screen:

- `ReelsStoppedEvent <../../apidocs/com/atsisa/gox/reels/event/ReelsStoppedEvent.html>`_: triggered when all reels have stopped spinning.
- `ReelStoppingEvent <../../apidocs/com/atsisa/gox/reels/event/ReelStoppingEvent.html>`_: triggered when specific reel began stopping.

Expose methods
**************
List of methods which are annotated with @ExposeMethod:

- *pause*: stops symbol animations on reels and pause reels animations if reel group is in spinning mode.
- *reset*: resets the reels.

Layout
******
The layout that is supported by this screen must have:

- child with id: reelGroupView, which extends the `AbstractReelGroup <../../apidocs/com/atsisa/gox/reels/view/AbstractReelGroup.html>`_ class.