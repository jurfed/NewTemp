===========
Fade Screen
===========
The fade screen `FadeScreen <../../apidocs/com/atsisa/gox/reels/screen/FadeScreen.html>`_ contains an implementation for FadeScreen layout. FadeScreen is used when we want cover something, where in the background something is happening and we do not want to show it, before it is ready.

Initialization
**************
This screen can be initialized in two ways:

#. Code:

    .. code-block:: java

        FadeScreen screen = new FadeScreen("layoutId", model, renderer, viewManager, animationFactory, logger, eventBus, gameConfiguration);


#. IoC:

    .. code-block:: java

        //optional
        bindConstant().named(FadeScreen.LAYOUT_ID_PROPERTY).to("layoutId");
        //required
        bind(Screen.class).to(FadeScreen.class);

    It is important to bind constant with value, under what id is the layout for this screen.

    Binding layout is optional. If no layout will be provided then default one will be generated.

Layout
******
The layout is not obligatory. If none will be added then default one will be generated.