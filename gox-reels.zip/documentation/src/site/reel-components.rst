===============
Reel Components
===============
The gox library contains basic components used in the reel games:

.. toctree::
    :titlesonly:

    views/reel-group
    views/reel
    views/symbol
    views/win-line
    views/gambler-card

Each of that component consists of: interface and its default implementation.

ReelGamesViewModule
*******************
All default components are views and are registered in `ReelGamesViewModule <../apidocs/com/atsisa/gox/reels/view/ReelGamesViewModule.html>`_.
