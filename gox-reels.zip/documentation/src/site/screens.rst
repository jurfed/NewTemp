============
Reel Screens
============
The GOX reels library contains several dedicated screen implementations, to support the most basic behavior in slot games.

.. toctree::
    :titlesonly:

    screens/base-game-screen
    screens/fade-screen
    screens/bottom-panel-screen
    screens/gambler-screen
    screens/info-screen
    screens/error-screen
    screens/history-screen
    screens/language-screen
    screens/paytable-screen
    screens/win-lines-screen