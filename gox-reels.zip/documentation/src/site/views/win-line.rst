========
Win Line
========
This component it represents a single line, with all the elements that are associated with it (line shape, indicators, winning symbol frames).

Interface
*********
The interface that describes this component is: `IWinLine <../../apidocs/com/atsisa/gox/reels/view/IWinLine.html>`_.

Line number
-----------
Line numbering should begin with the number 1, the exception of this is a scatter line whose number must be 0. The line number is used as a reference to specific line.

States
------
To visualize the current state of the line, the *setState* method is used. The possible states that line can take are:

- WinLineState.INACTIVE: the state in which neither line indicators or the line itself is visible. This state typically occurs when either the line was disabled by a configuration or the player has chosen not to play on this line.
- WinLineState.ACTIVE: the state in which line indicators are visible but the line itself isn't. This state is the default line state indicating the player has chosen to play on this line.
- WinLineState.SHOWN: the state in which both line indicators and the line itself is visible. This state happens when line or bet amount is changed during a game play.
- WinLineState.SHOWN_WINNING: The state in which both line indicators and the line itself is visible as well as rectangles surrounding the winning symbols. This state happens when the player has won the latest game play.

Control over the state of the line should be done externally, regardless of the specific line implementation.

Show win
--------
Showing win is done using the *showWin* method, to which the object of the `IWinLineInfo <../../apidocs/com/atsisa/gox/reels/IWinLineInfo.html>`_ is passed, this object contains all information about win for this line. Updating information about win on the line is done by the *updateWinScore* method.

Hide win
--------
Hiding the win done using the *hideWin* method.

Abstract win line
*****************
The library contains an abstraction declaration of the symbol: `AbstractWinLineView <../../apidocs/com/atsisa/gox/reels/view/AbstractWinLineView.html>`_. This class extends the interface functionality, adding:

- winning frames for symbols and win score field
- observables for basic properties (line number, current state)
- extends the view group
- all properties, frame shapes and score field can be configured in xml

Winning frames and score field
------------------------------
The abstraction has the functionality of managing the frames and score fields that are displayed above the winning symbols. These elements, however, must be provided from the outside, declared in layout.xml or added using code (single element can be added using *addChild* method). Each of them should be an instance of the view class and its tag should contains specific values:

- each frame should contains "frame" value in tag
- each score field should contains "score" value in tag

Views with that tags can be nested (e.g. they can be inside other view group), because they are searched in a recursive way. Thanks to the value of these tags, line knows whether the view is a frame or is a score field.

Default implementation
**********************
The library has two default implementations of the winning line, one for classic lines and the other for line with scatters.

Classic line
------------
The default implementation for classic lines in library is: `WinLineView <../../apidocs/com/atsisa/gox/reels/view/WinLineView.html>`_. This implementation expands the abstract win line class by adding to it:

#. Line indicators

Each of this element must be an instance of the view class and implements the ICapture interface. Also their tag should contains the: "indicator" value. It is possible to nest elements inside others (in view group), because they are searched in a recursive way.

#. Line shape

Each of this element must be an instance of the view class and implements the IPointsHolder interface. Also their tag should contains the: "line" value. It is possible to nest elements inside others (in view group), because they are searched in a recursive way. During the win, where the winning frames and lines are presented at the same time, line fragments are hidden at places where they overlap each other.

.. note::
    Frames in this view can not overlap each other, because hiding part of the line during showing win will not work properly.

An example of a declared line in a layout.xml:

    .. code-block:: xml

        <r:WinLineView lineNumber="1" y="482">
            <c:children>
                <c:LineShapeView tags="line" color="#549bf4" skin="@skin/lineStraight"/>
                <c:RectangleShapeView frameColor="#549bf4" skin="@skin/frame" x="88" y="-74"/>
                <c:RectangleShapeView frameColor="#549bf4" skin="@skin/frame" x="312" y="-74"/>
                <c:RectangleShapeView frameColor="#549bf4" skin="@skin/frame" x="536" y="-74"/>
                <c:RectangleShapeView frameColor="#549bf4" skin="@skin/frame" x="760" y="-74"/>
                <c:RectangleShapeView frameColor="#549bf4" skin="@skin/frame" x="984" y="-74"/>
                <c:ViewGroup tags="score">
                    <c:children>
                        <c:RectangleShapeView skin="@skin/scoreBox" frameColor="#549bf4"/>
                        <c:TextView skin="@skin/scoreText"/>
                    </c:children>
                </c:ViewGroup>
                <c:ViewGroup tags="indicator" skin="@skin/indicatorGroupLeft" y="5">
                    <c:children>
                        <c:RectangleShapeView fillColor="#549bf4" skin="@skin/square"/>
                        <c:TextView text="1" color="#000000" skin="@skin/indicatorText"/>
                    </c:children>
                </c:ViewGroup>
                <c:ViewGroup tags="indicator" skin="@skin/indicatorGroupRight" y="5">
                    <c:children>
                        <c:RectangleShapeView fillColor="#549bf4" skin="@skin/square"/>
                        <c:TextView text="1" color="#000000" skin="@skin/indicatorText"/>
                    </c:children>
                </c:ViewGroup>
            </c:children>
        </r:WinLineView>

The number of frames should be the same as the maximum number of winning symbols on the line. Also each of them should be declared in the same place where may be the winning symbols for this line.

Scatter line
------------
The default implementation for a classic scatter line in library is: `WinLineView <../../apidocs/com/atsisa/gox/reels/view/WinLineView.html>`_. This class only supports frames and score fields from the abstract class.

An example of a declared line in a layout.xml:

 .. code-block:: java

	 <r:ScatterWinLineView lineNumber="0" x="100" y="200">
		<c:children>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="0" y="-74"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="224" y="-74"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="448" y="-74"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="672" y="-74"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="896" y="-74"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="0" y="134"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="224" y="134"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="448" y="134"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="672" y="134"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="896" y="134"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="0" y="342"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="224" y="342"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="448" y="342"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="672" y="342"/>
			<c:RectangleShapeView frameColor="#ffff00" skin="@skin/frame" x="896" y="342"/>
			<c:ViewGroup tags="score">
				<c:children>
					<c:RectangleShapeView skin="@skin/scoreBox" frameColor="#ffff00"/>
					<c:TextView skin="@skin/scoreText"/>
				</c:children>
			</c:ViewGroup>
		</c:children>
	 </r:ScatterWinLineView>

In the provided example below the view consists of rectangle shape views positioned in places where scatter symbol may be shown. For game consisting of 5 reels and 3 rows there are 15 shapes for all possible winning symbols positions. The order of the shapes is important and row oriented, it means for example that a fifth rectangle shape view belongs to the first row and fifth reel.
