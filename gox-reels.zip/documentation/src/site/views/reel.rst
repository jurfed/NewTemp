====
Reel
====
This component allows to manage a single reel in a game. Its basic tasks are:

- start/stop spinning symbols
- displaying symbols

Interface
*********
The interface that describes this component is: `IReel <../../apidocs/com/atsisa/gox/reels/view/IReel.html>`_.

Configuration
-------------
The reel should be configured using the `ISymbolsConfiguration <../../apidocs/com/atsisa/gox/reels/configuration/ISymbolsConfiguration.html>`_ object. This object has basic elements such as:

- information about height for the single symbol
- the symbol pool (`ISymbolPool <../../apidocs/com/atsisa/gox/reels/view/spi/ISymbolPool.html>`_) used to manage symbol instances
- information about how many symbols are in row
- the symbol appending strategy (`ISymbolAppendingStrategy <../../apidocs/com/atsisa/gox/reels/view/spi/ISymbolAppendingStrategy.html>`_) which changes the reel stopping behaviour by determining how stopped symbols should be joined with the existing reel strip in order to prevent showing combinations confusing to players

Showing symbols
---------------
The *stopOnSymbols* or *forceStopOnSymbols* methods are used to display symbols on the reel, but only when the component is in **ReelState.IDLE** state. A collection of reel symbol names must be passed to these methods. The symbol names must mach the same names, which are in the `ISymbolPool <../../apidocs/com/atsisa/gox/reels/view.spi/ISymbolPool.html>`_.

Spinning
--------
To trigger spin, reel must be in the **ReelState.IDLE** state and must be configured. If these conditions are met, then: *spin* method will change state of reel to: **ReelState.SPINNING** and spinning starts.

Stopping
--------
Stopping is done by using: *stopOnSymbols* method. If this method will be called during spin, then the stopping phase will start.

It is possible to immediately stop the spinning reel, by using: *forceStopOnSymbols* method. In that way all symbols will be immediately stopped.

Animation
---------
The `IReelAnimation <../../apidocs/com/atsisa/gox/reels/animation/IReelAnimation.html>`_ is used to visualize each of the spin phase: start, spinning, stopping. Specific implementation of this animation can be set using the *setReelAnimation* method.

Reel strips
-----------
The reel strips are used to determine in what order the symbols will be displayed during the spinning animation. All possible reel strips, should be provided during reel initialization along with the reel strip definition provider (`IReelStripDefinitionProvider <../../apidocs/com/atsisa/gox/reels/model/IReelStripDefinitionProvider.html>`_). The *setReelStripType* method is used to determine which reel strips are currently used.

Abstract reel
*************
The library contains an abstraction declaration of the reel: `AbstractReel <../../apidocs/com/atsisa/gox/reels/view/AbstractReel.html>`_. This class implements a few interfaces: IGamblerCard, IResetable, IPauseable and extend the ViewGroupBase, but does not contain any functionality.

Default implementation
**********************
The default implementation for this component in library is: `ReelView <../../apidocs/com/atsisa/gox/reels/view/ReelView.html>`_. This implementation is a view, so it can be declared in a layout:

 .. code-block:: xml

        <r:ReelView width="208">
                <r:symbolsConfiguration>
                    <r:rowCount>3</r:rowCount>
                    <r:symbolHeight>208</r:symbolHeight>
                    <r:symbols>
                        <r:poolDefinition poolInitializationStrategyClass="com.atsisa.gox.reels.view.FixedSymbolPoolStrategy" >
                            <r:fixedSymbolCount>5</r:fixedSymbolCount>
                        </r:poolDefinition>
                        <r:symbolsDefinition>
                            <r:SymbolView name="Melon" defaultState="IDLE">
                            </r:SymbolView>
                            ...
                        </r:symbolsDefinition>
                    </r:symbols>
                </r:symbolsConfiguration>
        </r:ReelView>

There are two default symbol pool strategies in library:

- `FixedSymbolPoolStrategy <../../apidocs/com/atsisa/gox/reels/view/FixedSymbolPoolStrategy.html>`_: uses predefined symbol quantities instantiated when the symbol pool is created
- `DynamicSymbolPoolStrategy <../../apidocs/com/atsisa/gox/reels/view/DynamicSymbolPoolStrategy.html>`_: dynamically instantiates missing symbols as we go using the symbol factory up to given limits per symbol name