==========
Reel Group
==========
This component is for management group of reels in a game. Its basic tasks are:

- start/stop spinning reels
- displaying symbols on reels
- show/hide winning symbols

Interface
*********
The interface that describes this component is: `IReelGroup <../../apidocs/com/atsisa/gox/reels/view/IReelGroup.html>`_.

Showing symbols
---------------
The *stopOnSymbols* or *forceStopOnSymbols* methods are used to display symbols on the reels, but only when the component is in **ReelGroupState.IDLE** state. A collection of symbol names for each reel in group must be pass to these methods. The symbol names must mach the names in the `ISymbolPool <../../apidocs/com/atsisa/gox/reels/view.spi/ISymbolPool.html>`_, that is directly in the specific single reel configuration.

Spinning
--------
To trigger spin on reels, reel group must be in the **ReelGroupState.IDLE** state and reels must be configured. If these conditions are met, then: *spin* method will change state of the group to: **ReelGroupState.SPINNING** and then the spin sequence provider (`IReelSequenceProvider <../../apidocs/com/atsisa/gox/reels/view/spi/IReelSequenceProvider.html>`_) will starts spinning the individual reels in the component.

Stopping
--------
Stopping is done by using: *stopOnSymbols* method. If this method will be called during spin, then the stop on symbols sequence provider (`IReelSequenceProvider <../../apidocs/com/atsisa/gox/reels/view/spi/IReelSequenceProvider.html>`_) will determine how this will happen.

It is possible to immediately stop the spinning reels, by using: *forceStopOnSymbols* method. In that way the reels will be immediately stopped, then the force stop on symbols sequence provider (`IReelSequenceProvider <../../apidocs/com/atsisa/gox/reels/view/spi/IReelSequenceProvider.html>`_) will determines how this will happen.

Show winning symbols
--------------------
Showing winning symbols is done by: *showWinningSymbols* method but the strategy:

- `IShowSymbolAnimationsStrategy <../../apidocs/com/atsisa/gox/reels/view/spi/IShowSymbolAnimationsStrategy.html>`_

Which defines how it should be done. Once this strategy is started, reel group should change his state to: **ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS** and when all the winning symbols show up, state should be change to: **ReelGroupState.SHOWING_WINNING_SYMBOLS**. There is a possibility to speed up the process of showing winning symbols by using: *terminateStartsShowingWinningSymbols* method on component.

Hide winning symbols
--------------------
Hiding winning symbols is done by: *stopSymbolAnimations* method but the strategy:

- `IHideSymbolAnimationsStrategy <../../apidocs/com/atsisa/gox/reels/view/spi/IHideSymbolAnimationsStrategy.html>`_

Which defines how it should be done. After the: *stopSymbolAnimations* method is invoked, then reel group should change its state to: **ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS** and when all the winning symbols are hidden, state should be change to: **ReelGroupState.IDLE**. There is a possibility to speed up the process of hiding winning symbols by using: *forceStopSymbolAnimations* method on component.

Default implementation
**********************
The default implementation for this component in library is: `ReelGroupView <../../apidocs/com/atsisa/gox/reels/view/ReelGroupView.html>`_. This implementation is a view, so it can be declared in a layout:

.. code-block:: xml

	<ReelGroupView>
		<spinSequenceProvider class="com.atsisa.gox.reels.view.ReelInstantSequenceProvider"/>
		<forceStopOnSymbolsSequenceProvider class="com.atsisa.gox.reels.view.ReelInstantSequenceProvider"/>
		<stopOnSymbolsSequenceProvider class="com.atsisa.gox.reels.view.ReelDelayedSequenceProvider"/>
		<stopOnSymbolsSequenceProvider class="com.atsisa.gox.reels.view.ReelDelayedSequenceProvider"/>
		<showSymbolAnimationsStrategy class="com.atsisa.gox.reels.view.StateShowSymbolAnimationsStrategy"/>
		<hideSymbolAnimationsStrategy class="com.atsisa.gox.reels.view.StateHideSymbolAnimationsStrategy"/>
		<reels/>
	</ReelGroupView>

The default implementation contains already configured default providers and strategies, which are the same as it is shown in this example, so their declaration is unnecessary here. This example shows only how custom implementations can be configured in layout.xml.