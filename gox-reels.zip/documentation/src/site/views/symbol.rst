======
Symbol
======
This component is used to visualize a single symbol on reel.

Interface
*********
The interface that describes this component is: `ISymbol <../../apidocs/com/atsisa/gox/reels/view/ISymbol.html>`_.

Naming
------
Naming symbols is very important, because they are searched (e.g. in symbol pool) after their names (the *getName* method is used for this).

State
-----
The *setState* method on the interface is used to visualize a specific state of the symbol (idle, win or any other depending on requirements and implementation). Each individual symbol implementation should be prepared for naming convention used in game logic (e.g. "Short" symbol state used in mockup base archetype).

Abstract symbol
***************
The library contains an abstraction declaration of the symbol: `AbstractSymbol <../../apidocs/com/atsisa/gox/reels/view/AbstractSymbol.html>`_. This class extends the interface functionality, adding:

- definition of the default state
- states resolver
- observables for basic properties (state, name and default state)
- extends the view group
- all properties can be configured in xml

Symbol state resolver
---------------------
When the symbol must change its state from present to another, then symbol state resolver (`ISymbolStateResolver <../../apidocs/com/atsisa/gox/reels/view/spi/ISymbolStateResolver.html>`_) in abstraction class it is used to check if it is possible.

Default implementation
**********************
The default implementation for this component in library is: `SymbolView <../../apidocs/com/atsisa/gox/reels/view/SymbolView.html>`_. This implementation extends the abstract symbol, so it can be declared in a layout with all properties:

.. code-block:: java

	<r:SymbolView name="Grapes" defaultState="IDLE">
		<r:SymbolStateResolver class="com.atsisa.gox.reels.view.LongShortSymbolStateResolver" />
		<c:children>
			<c:ImageView src="@spriteSheet/mainScreenAtlas/grapes_1.png" tags="IDLE"/>
			<c:KeyframeAnimationView skin="@skin/symbolGrapesWinShortAnimation" tags="Short" frameRateDivider="5" beginLoopFrameNumber="5" endLoopFrameNumber="14" loop="true"/>
			<c:KeyframeAnimationView skin="@skin/symbolGrapesWinLongAnimation" tags="Long" frameRateDivider="5" beginLoopFrameNumber="5" endLoopFrameNumber="14" loop="true"/>
		</c:children>
	</r:SymbolView>

The default implementation solves the problem which child should be visible in what state by basing on their tags (tag must have the same value as the state name). This can be easily changed by settings a custom implementation of: IStatefulViewChildFilter interface in the symbol, by default, the instance of the class: TagBasedViewChildFilter is set.
