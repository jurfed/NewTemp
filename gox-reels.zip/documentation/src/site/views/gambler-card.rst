============
Gambler Card
============
This component is used to visualize a single card in card type gambler.

Interface
*********
The interface that describes this component is: `IGamblerCard <../../apidocs/com/atsisa/gox/reels/view/IGamblerCard.html>`_. This interface can be used to define a main card or a single card in history.

States
------
Gambler card can only be in one state at the same time. There are two states: when card is showing the upright side or when card is showing the reversed side. Each of these sides can be specified using the following methods: *setUprightCard* and *setReversedCard*, where in the parameter must be aview that will represent a specific side. It can be changed in two ways, one of them is an immediate change using methods: *showUprightCard* and *showReversedCard* with the help of which it is possible to show specific side. Additionally flip methods can be used to flip the card from the present side to the opposite.

Abstract card
*************
The library contains an abstraction declaration of the gambler card: `AbstractGamblerCard <../../apidocs/com/atsisa/gox/reels/view/AbstractGamblerCard.html>`_. This class implements a few interfaces: IGamblerCard, IResetable, IPauseable and extend the ViewGroupBase, but does not contain any functionality.

Default implementation
**********************
The default implementation for this component in library is: `GamblerCardView <../../apidocs/com/atsisa/gox/reels/view/GamblerCardView.html>`_. This implementation extends the abstract gambler card and adds the ability to define a flip animation of the card. Instance of this class can be created in code or defined in layout.xml with all his properties and animations:

 .. code-block:: xml
 
	<r:GamblerCardView x="400" y="300">
		<r:flipHideAnimation>
			<timeSpan>250</timeSpan>
			<destinationScaleX>0</destinationScaleX>
			<destinationX>512</destinationX>
		</r:flipHideAnimation>
		<r:flipShowAnimation>
			<timeSpan>250</timeSpan>
			<destinationScaleX>1</destinationScaleX>
			<destinationX>406</destinationX>
		</r:flipShowAnimation>
	</r:GamblerCardView>
