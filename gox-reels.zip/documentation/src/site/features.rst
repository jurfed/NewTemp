========
Features
========

The GOX reels library, supports the special features that can be found in reel games.

List of the available features:

.. toctree::
    :titlesonly:

    features/extended-symbol/extended-symbol
    features/free-games/free-games