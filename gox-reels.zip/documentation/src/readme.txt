== Documentation source files

- Documentation should be written exclusively in .rst format and compiled with sphinx
  (see: http://www.sphinx-doc.org/en/1.4.9/)

== Building the documentation

- Documentation build process requires Python 3.x
  Make sure that <Python_installation_folder> path is added to PATH (there is python.exe there)
  Put <Python_installation_folder>\Scripts\ to PATH as well to allow access to pip tool
- Run 'pip install -r requirements.txt' to install all dependencies  

In order to build the documentation locally from sources type 'make html'

== Integration with Confluence

The following plugins provide seamless integration with confluence
- https://github.com/Arello-Mobile/sphinx-confluence
- https://github.com/marooou/confluence-publisher
Please read the manuals to get the gist.

To put the content on confluence:
- Modify conf.py by uncommenting the following line
  extensions = ['sphinx_confluence']
- Run 'make json'
- Run 'conf_publisher confluence.yml --auth XXXXXjpwYXNzdXXXXX==' where the auth value is base64 encoded JIRA's 'user:password' string.
  Make sure the right confluence document structure exists BEFORE the conf_publisher is launched.
  That means correcting pages' ids in the confluence.yml file.