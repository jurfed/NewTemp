#!/bin/bash
PYENV_HOME=$WORKSPACE/docs/.pyenv/

CONF_BASIC_AUTH=$(echo -n "$CONF_USER:$CONF_PASS" | base64)

if [ -d $PYENV_HOME ]; then
    rm -rf $PYENV_HOME
else
    mkdir $PYENV_HOME
fi

virtualenv --no-site-packages $PYENV_HOME
. $PYENV_HOME/bin/activate
pip install -r requirements.txt
make html
make confluence
conf_publisher --force -a $CONF_BASIC_AUTH -ac confluence.yml
