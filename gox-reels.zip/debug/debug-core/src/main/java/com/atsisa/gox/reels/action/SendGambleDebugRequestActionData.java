package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Represents a gamble debug request action.
 */
@XmlElement
public class SendGambleDebugRequestActionData extends ActionData {

    /**
     * Selection name.
     */
    @XmlAttribute
    private String selectionName;

    /**
     * Value indicating whether gambler is winning.
     */
    @XmlAttribute
    private boolean win;

    /**
     * Sets a winning indicator.
     * @param win is win
     */
    public void setWin(boolean win) {
        this.win = win;
    }

    /**
     * Value indicating whether gambler is winning.
     * @return is win
     */
    public boolean isWin() {
        return win;
    }

    /**
     * Gets selection gamble name.
     * @return selection name
     */
    public String getSelectionName() {
        return selectionName;
    }

    /**
     * Sets selection gamble name.
     * @param selectionName selection name
     */
    public void setSelectionName(String selectionName) {
        this.selectionName = selectionName;
    }
}
