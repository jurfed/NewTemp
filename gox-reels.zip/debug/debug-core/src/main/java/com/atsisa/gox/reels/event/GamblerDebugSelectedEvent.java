package com.atsisa.gox.reels.event;

import com.atsisa.gox.reels.CardType;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when debug gambler was selected.
 */
@Reflectable
public final class GamblerDebugSelectedEvent {

    /**
     * Selected card type.
     */
    private CardType cardType;

    /**
     * Value indicating whether gambler is winning.
     */
    private boolean win;

    /**
     * Initializes a new instance of the {@link GamblerDebugSelectedEvent} class.
     * @param cardType selected card type.
     * @param win      value indicating whether gambler is winning.
     */
    public GamblerDebugSelectedEvent(CardType cardType, boolean win) {
        this.cardType = cardType;
        this.win = win;
    }

    /**
     * Gets selected card type.
     * @return card type
     */
    public CardType getCardType() {
        return cardType;
    }

    /**
     * Gets value indicating whether gambler is winning.
     * @return is win
     */
    public boolean isWin() {
        return win;
    }
}
