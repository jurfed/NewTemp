package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when unlock positions button in debug panel was clicked.
 */
@Reflectable
public class DebugPositionsUnlockCommand {

}
