package com.atsisa.gox.reels.logic.vocs;

import java.util.Set;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.request.DebugBetRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.DebugGambleRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;
import com.google.inject.Inject;

import rx.Observable;

/**
 * Represents a debug part of Vocs services.
 */
public class DebugGameLogic extends GameLogic implements IDebugReelGameLogic {

    /**
     * Initializes a new instance of the {@link DebugGameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configurationProvider   {@link IConfigurationProvider}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    @Inject
    public DebugGameLogic(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
            Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
        super(xmlParser, network, configurationProvider, presentationSerializers, platform);
        registerDefaultRequestSerializers();
    }

    /**
     * Registers the default request serializers.
     */
    protected void registerDefaultRequestSerializers() {
        registerRequestSerializer(DebugBetRequest.class, new DebugBetRequestSerializer());
        registerRequestSerializer(DebugGambleRequest.class, new DebugGambleRequestSerializer());
    }

    @Override
    public Observable<LogicPresentation> debugBet(DebugBetRequest debugBetRequest) {
        return sendLogicRequest(debugBetRequest, getProcessGameUri(debugBetRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> debugGamble(DebugGambleRequest debugGambleRequest) {
        return sendLogicRequest(debugGambleRequest, getProcessGameUri(debugGambleRequest), HttpMethod.POST, headers);
    }
}
