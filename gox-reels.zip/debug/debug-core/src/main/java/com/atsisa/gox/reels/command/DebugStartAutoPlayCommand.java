package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request to debug start auto play.
 */
@Reflectable
public final class DebugStartAutoPlayCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link DebugStartAutoPlayCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public DebugStartAutoPlayCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
