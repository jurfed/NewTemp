package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.AbstractActionModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * A representation of debug reel game configuration properties.
 */
@Reflect_Mini
public class DebugReelGamesActionModule extends AbstractActionModule {

    /**
     * Core actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/reels-debug/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerAction("SendGambleDebugRequest", SendGambleDebugRequestAction.class);
        registerAction("SendBetDebugRequest", SendBetDebugRequestAction.class);
    }
}
