package com.atsisa.gox.reels.logic.vocs.serialization.request;

import java.math.BigDecimal;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Uses to serialize debug bet request.
 */
public class DebugBetRequestSerializer implements ISerializer<DebugBetRequest, XmlObject> {

    @Override
    public XmlObject serialize(DebugBetRequest request) {
        XmlBuilder xmlBuilder = new XmlBuilder();

        xmlBuilder.startElement("nrgs").startElement("req").startElement("a").writeValue("Bet").endElement().startElement("b")
                .writeValue(request.getBetAmount().multiply(new BigDecimal(request.getLinesAmount()))).endElement().startElement("ls")
                .writeValue(request.getLinesAmount()).endElement().startElement("debug").writeAttribute("type", "StopPosition").startElement("stoppos");

        for (Integer integer : request.getStopPositions()) {
            xmlBuilder.startElement("reelpos").writeValue(integer).endElement();
        }

        xmlBuilder.endElement().endElement().endElement().endElement().toXmlObject();
        return xmlBuilder.toXmlObject();
    }

}
