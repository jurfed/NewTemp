package com.atsisa.gox.reels.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the configuration of reel game debug.
 */
public class DebugDataModel implements IDebugDataModel {

    /**
     * Debug stop positions.
     */
    private final List<Integer> stopPositions;

    /**
     * Indicates that debug stop positions are locked or not.
     */
    private boolean stopPositionsLocked;

    /**
     * Initializes a new instance of the {@link DebugDataModel} class.
     */
    public DebugDataModel() {
        stopPositions = new ArrayList<>();
    }

    @Override
    public Iterable<Integer> getStopPositions() {
        return stopPositions;
    }

    /**
     * Sets debug stop positions.
     * @param stopPositions debug stop positions
     */
    void setStopPositions(List<Integer> stopPositions) {
        this.stopPositions.clear();
        this.stopPositions.addAll(stopPositions);
    }

    boolean isStopPositionsLocked() {
        return stopPositionsLocked;
    }

    /**
     * Sets debug stop positions are locked.
     * @param stopPositionsLocked boolean debug stop positions are locked
     */
    void setStopPositionsLocked(boolean stopPositionsLocked) {
        this.stopPositionsLocked = stopPositionsLocked;
    }

    void clearStopPositions() {
        stopPositions.clear();
    }

    boolean hasStopPositions() {
        return !stopPositions.isEmpty();
    }
}
