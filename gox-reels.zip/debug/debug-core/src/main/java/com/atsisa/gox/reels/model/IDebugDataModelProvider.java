package com.atsisa.gox.reels.model;

/**
 * Exposes the most recent reel game debug data model.
 */
public interface IDebugDataModelProvider {

    /**
     * Gets the most recent reel game debug data model.
     * @return IDebugDataModel
     */
    IDebugDataModel getDebugDataModel();

    /**
     * Indicates that debug data model is locked or not.
     * @return {@code true} when debug data model is locked or {@code false} when not
     */
    boolean isDebugDataModelLocked();

    /**
     * Clears debug data model.
     */
    void clearDebugDataModel();

    /**
     * Checks that debug data model is valid.
     * @return {@code true} then debug data model is valid {@code false} when not
     */
    boolean isDebugDataModelValid();
}
