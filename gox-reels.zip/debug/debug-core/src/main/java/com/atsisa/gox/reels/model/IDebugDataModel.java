package com.atsisa.gox.reels.model;

/**
 * Represents the configuration of reel game debug.
 */
public interface IDebugDataModel {

    /**
     * Gets debug stop positions.
     * @return debug stop positions
     */
    Iterable<Integer> getStopPositions();
}
