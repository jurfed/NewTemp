package com.atsisa.gox.reels.logic.vocs;

import java.util.Set;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;

import rx.Observable;

/**
 * Represents a debug part of Novoprime services.
 */
public class DebugNovoGameLogic extends NovoGameLogic implements IDebugReelGameLogic {

    /**
     * Initializes a new instance of the {@link DebugNovoGameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configurationProvider   {@link IConfigurationProvider}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    public DebugNovoGameLogic(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
            Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
        super(xmlParser, network, configurationProvider, presentationSerializers, platform);
    }

    @Override
    public Observable<LogicPresentation> debugBet(DebugBetRequest debugBetRequest) {
        return sendLogicRequest(debugBetRequest, getGameplayUri(), HttpMethod.PUT, headers);
    }

    @Override
    public Observable<LogicPresentation> debugGamble(DebugGambleRequest debugGambleRequest) {
        return sendLogicRequest(debugGambleRequest, getGameplayUri(), HttpMethod.PUT, headers);
    }
}
