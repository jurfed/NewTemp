package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;

import rx.Observable;

/**
 * Represents an extended debug logic of reel game.
 */
public interface IDebugReelGameLogic extends IReelGameLogic {

    /**
     * Handles a debug bet request.
     * @param debugBetRequest a debug bet request
     * @return the observable result
     */
    Observable<LogicPresentation> debugBet(DebugBetRequest debugBetRequest);

    /**
     * Handles a debug gamble request.
     * @param debugGambleRequest a debug gamble request.
     * @return the observable result
     */
    Observable<LogicPresentation> debugGamble(DebugGambleRequest debugGambleRequest);
}
