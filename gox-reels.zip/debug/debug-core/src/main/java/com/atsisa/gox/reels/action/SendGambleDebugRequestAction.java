package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Sends gamble debug request during gambler.
 */
@Reflect_Mini
public class SendGambleDebugRequestAction extends AbstractSendRequestAction<SendGambleDebugRequestActionData> {

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return SendGambleDebugRequestActionData.class;
    }

    /**
     * Sends red bet request.
     */
    @Override
    protected void execute() {
        subscribeForResult(((IDebugReelGameLogic) getGameLogic()).debugGamble(new DebugGambleRequest(actionData.isWin(), actionData.getSelectionName())));
    }

}
