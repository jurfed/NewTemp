package com.atsisa.gox.reels.command;

import java.util.List;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when debug positions in debug panel was changed.
 */
@Reflectable
public class DebugPositionsChangeCommand {

    /**
     * Debug stop positions.
     */
    private final List<Integer> stopPositions;

    /**
     * Initializes a new instance of the {@link DebugPositionsChangeCommand} class.
     * @param stopPositions debug stop positions
     */
    public DebugPositionsChangeCommand(List<Integer> stopPositions) {
        this.stopPositions = stopPositions;
    }

    /**
     * Gets debug stop positions.
     * @return debug stop positions
     */
    public List<Integer> getStopPositions() {
        return stopPositions;
    }
}
