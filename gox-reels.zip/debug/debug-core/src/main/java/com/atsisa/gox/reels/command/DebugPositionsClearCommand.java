package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when debug positions in debug panel was cleared.
 */
@Reflectable
public class DebugPositionsClearCommand {

}
