package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Uses to serialize debug gamble request.
 */
public class DebugGambleRequestSerializer implements ISerializer<DebugGambleRequest, XmlObject> {

    @Override
    public XmlObject serialize(DebugGambleRequest request) {
        return new XmlBuilder().startElement("nrgs").startElement("req").startElement("a").writeValue(request.getSelectionName()).endElement()
                .startElement("debug").writeAttribute("type", request.isWin() ? "Win" : "Lose").endElement().endElement().endElement().toXmlObject();
    }
}
