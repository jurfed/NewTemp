package com.atsisa.gox.reels;

import com.atsisa.gox.reels.model.IDebugDataModelProvider;
import com.google.inject.Inject;

/**
 * Debug reel game components container.
 */
public class DebugBaseReelGameComponents extends AbstractReelGameComponents {

        /**
     * Debug data provider.
     */
    private IDebugDataModelProvider debugDataModelProvider;

    /**
     * Sets debug data model provider.
     * @param debugDataModelProvider {@link IDebugDataModelProvider}
     */
    @Inject
    public void setDebugDataModelProvider(IDebugDataModelProvider debugDataModelProvider) {
        validateState();
        this.debugDataModelProvider = debugDataModelProvider;
    }

    /**
     * Gets debug data provider.
     * @return debug data provider
     */
    public IDebugDataModelProvider getDebugDataModelProvider() {
        return debugDataModelProvider;
    }

}
