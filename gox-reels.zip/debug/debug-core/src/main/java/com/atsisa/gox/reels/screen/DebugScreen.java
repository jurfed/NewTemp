package com.atsisa.gox.reels.screen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.DebugPositionsChangeCommand;
import com.atsisa.gox.reels.command.DebugPositionsClearCommand;
import com.atsisa.gox.reels.command.DebugPositionsLockCommand;
import com.atsisa.gox.reels.command.DebugPositionsUnlockCommand;
import com.atsisa.gox.reels.command.DebugSpinCommand;
import com.atsisa.gox.reels.command.DebugStartAutoPlayCommand;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;
import com.atsisa.gox.reels.model.IReelStripDefinitionProvider;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

/**
 * A class representing the reel debug screen.
 */
@Reflectable(fields = false)
public class DebugScreen extends Screen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "DebugScreenLayoutId";

    /**
     * Stop position message.
     */
    private static final String STOP_POSITIONS_MESSAGE = "stopPositionsMessage";

    /**
     * Stop position separator for message.
     */
    private static final String STOP_POSITION_SEPARATOR = ",";

    /**
     * Name of the properties which is responsible if debug button is visible or not.
     */
    private static final String DEBUG_BUTTON_VISIBLE = "debugButtonVisible";

    /**
     * Name of the properties which is responsible if debug screen is visible or not.
     */
    private static final String DEBUG_PANEL_VISIBLE = "debugPanelVisible";

    /**
     * Lock button visible.
     */
    private static final String LOCK_BUTTON_VISIBLE = "lockButtonVisible";

    /**
     * Unlock button visible.
     */
    private static final String UNLOCK_BUTTON_VISIBLE = "unlockButtonVisible";

    /**
     * Reelstrip definition provider.
     */
    private IReelStripDefinitionProvider reelStripDefinitionProvider;

    /**
     * Reelstrip symbols context.
     */
    private final List<ReelStripSymbolsContext> reelStripSymbolsContexts;

    /**
     * The reel group view.
     */
    @InjectView
    @HasReflect
    public ReelGroupView reelGroupView;

    /**
     * Initializes a new instance of the {@link DebugScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public DebugScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        reelStripSymbolsContexts = new ArrayList<>();
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        reelStripDefinitionProvider = ((AbstractReelGame) GameEngine.current().getGame()).getReelStripDefinitionProvider();
        setModelDefaultStates();
    }

    /**
     * Sets model defaults.
     */
    private void setModelDefaultStates() {
        setModelBooleanProperty(LOCK_BUTTON_VISIBLE, Boolean.TRUE);
        setModelBooleanProperty(UNLOCK_BUTTON_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(DEBUG_PANEL_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);
    }

    /**
     * Sets a boolean model property.
     * @param name  the name of the property
     * @param value the value of the property
     */
    private void setModelBooleanProperty(String name, Boolean value) {
        getModel().setProperty(name, value);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        try {
            getEventBus().register(this);
        } catch (ReflectionException e) {
            getEventBus().post(new GeneralSystemException(e));
            getLogger().error(e.getMessage(), e);
        }
    }

    /**
     * Reacts to finish the info screen transition.
     * @param screenShownEvent screen shown event
     */
    @Subscribe
    public void handleScreenShownEvent(ScreenShownEvent screenShownEvent) {
        if (screenShownEvent.getScreen() instanceof InfoScreen) {
            setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);
        }
    }

    /**
     * Reacts to start the info screen transition.
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (screenShowingEvent.getScreen() instanceof InfoScreen) {
            setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);
        }
    }

    /**
     * Handles bottom panel state changes.
     * @param presentationStateChangedEvent the bottom panel state change request.
     */
    @Subscribe
    public void handlePresentationStateChangedEvent(PresentationStateChangedEvent presentationStateChangedEvent) {
        String state = presentationStateChangedEvent.getStateName();
        if (state == null || state.isEmpty()) {
            return;
        }

        if (state.equals(ReelsPresentationStates.IDLE)) {
            setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);
        } else {
            setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);
        }
    }

    /**
     * Called when auto play should be invoked.
     */
    @ExposeMethod
    public void autoPlayButtonClicked() {
        setModelBooleanProperty(DEBUG_PANEL_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);

        getEventBus().post(new DebugPositionsChangeCommand(getReelsPositions()));
        getEventBus().post(new DebugStartAutoPlayCommand(true));
    }

    /**
     * Gets reels positions.
     * @return reels positions
     */
    private List<Integer> getReelsPositions() {
        return reelStripSymbolsContexts.stream().map(ReelStripSymbolsContext::getCurrentPosition).collect(Collectors.toList());
    }

    /**
     * Called when spin should be invoked.
     */
    @ExposeMethod
    public void spinButtonClicked() {
        setModelBooleanProperty(DEBUG_PANEL_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);

        getEventBus().post(new DebugPositionsChangeCommand(getReelsPositions()));
        getEventBus().post(new DebugSpinCommand());
    }

    /**
     * Called when cancel should be invoked.
     */
    @ExposeMethod
    public void closeButtonClicked() {
        setModelBooleanProperty(DEBUG_PANEL_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);

        getEventBus().post(new DebugPositionsClearCommand());
    }

    /**
     * Called when specific reel down clicked.
     * @param reelNumberAsString reel number
     */
    @ExposeMethod
    public void moveReelDown(String reelNumberAsString) {
        int reelNumber = Integer.parseInt(reelNumberAsString);
        moveReel(reelStripSymbolsContexts.get(reelNumber).moveToPreviousPosition(), reelNumber);
    }

    private void moveReel(int stopPosition, int reelNumber) {
        List<String> symbols = retrieveSymbolsForsReel(stopPosition, reelNumber);
        reelGroupView.getReel(reelNumber).forceStopOnSymbols(symbols);

        updateMessage(getReelsPositions());
    }

    private List<String> retrieveSymbolsForsReel(int stopPosition, int reelNumber) {
        ReelStripSymbolsContext reelStripSymbolsContext = reelStripSymbolsContexts.get(reelNumber);
        int rowCount = reelGroupView.getReel(reelNumber).getDisplayedSymbols().size();
        List<String> symbols = new ArrayList<>(rowCount);
        for (int i = 0; i < rowCount; i++) {
            symbols.add(reelStripSymbolsContext.getSymbolNameAt(stopPosition + i - 1));
        }
        return symbols;
    }

    /**
     * Updates stop positions message.
     * @param stopPositions stop positions
     */
    private void updateMessage(List<Integer> stopPositions) {
        getModel().setProperty(STOP_POSITIONS_MESSAGE,
                StringUtility.join(STOP_POSITION_SEPARATOR, stopPositions.stream().map(Object::toString).collect(Collectors.toList())));
    }

    /**
     * Called when specific reel up clicked.
     * @param reelNumberAsString reel number
     */
    @ExposeMethod
    public void moveReelUp(String reelNumberAsString) {
        int reelNumber = Integer.parseInt(reelNumberAsString);
        moveReel(reelStripSymbolsContexts.get(reelNumber).moveToNextPosition(), reelNumber);
    }

    /**
     * Called when specific win combination clicked in 4 reels game.
     * @param reel0Position reel 0 position
     * @param reel1Position reel 1 position
     * @param reel2Position reel 2 position
     * @param reel3Position reel 3 position
     */
    @ExposeMethod
    public void updateStopPositions(String reel0Position, String reel1Position, String reel2Position, String reel3Position) {
        updateStopPositions(Arrays.asList(Integer.parseInt(reel0Position), Integer.parseInt(reel1Position), Integer.parseInt(reel2Position),
                Integer.parseInt(reel3Position)));
    }

    /**
     * Called when specific win combination clicked in 5 reels game.
     * @param reel0Position reel 0 position 
     * @param reel1Position reel 1 position
     * @param reel2Position reel 2 position
     * @param reel3Position reel 3 position
     * @param reel4Position reel 4 position
     */
    @ExposeMethod
    public void updateStopPositions(String reel0Position, String reel1Position, String reel2Position, String reel3Position, String reel4Position) {
        updateStopPositions(Arrays.asList(Integer.parseInt(reel0Position), Integer.parseInt(reel1Position), Integer.parseInt(reel2Position),
                Integer.parseInt(reel3Position), Integer.parseInt(reel4Position)));
    }

    /**
     * Updates stop positions.
     * @param stopPositions stop positions
     */
    private void updateStopPositions(List<Integer> stopPositions) {
        int reelNumber = 0;
        for (Integer stopPosition : stopPositions) {
            moveReel(reelStripSymbolsContexts.get(reelNumber).moveToPosition(stopPosition), reelNumber);
            reelNumber++;
        }
        updateMessage(getReelsPositions());
    }

    /**
     * Called when lock positions button clicked.
     */
    @ExposeMethod
    public void lockPositions() {
        setModelBooleanProperty(LOCK_BUTTON_VISIBLE, Boolean.FALSE);
        setModelBooleanProperty(UNLOCK_BUTTON_VISIBLE, Boolean.TRUE);

        getEventBus().post(new DebugPositionsLockCommand());
    }

    /**
     * Called when unlock positions button clicked.
     */
    @ExposeMethod
    public void unlockPositions() {
        setModelBooleanProperty(LOCK_BUTTON_VISIBLE, Boolean.TRUE);
        setModelBooleanProperty(UNLOCK_BUTTON_VISIBLE, Boolean.FALSE);

        getEventBus().post(new DebugPositionsUnlockCommand());
    }

    /**
     * Called when debug button clicked.
     */
    @ExposeMethod
    public void showDebugPanel() {
        setModelBooleanProperty(DEBUG_PANEL_VISIBLE, Boolean.TRUE);
        setModelBooleanProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);
    }

    @Override
    protected void afterActivated() {
        initializeReelStripSymbolsContexts();
        updateStopPositions(getReelsPositions());
    }

    /**
     * Initializes reel strip symbols contexts.
     */
    private void initializeReelStripSymbolsContexts() {
        reelGroupView.getReels().forEach(abstractReel -> reelStripSymbolsContexts.add(new ReelStripSymbolsContext(
                reelStripDefinitionProvider.getReelStripDefinition(abstractReel.getReelStripType(), abstractReel.getIndex()).getSymbols())));
    }

    /**
     * A context containing symbol names as defined in currently active reel strip.
     */
    private class ReelStripSymbolsContext {

        /**
         * A reel strip symbol names.
         */
        private final List<String> reelStrip;

        /**
         * The reel strip current position.
         */
        private int currentPosition;

        /**
         * Initializes a new instance of the {@link ReelStripSymbolsContext}
         * using given reel strip definition.
         * @param reelStrip The reel strip definition.
         */
        public ReelStripSymbolsContext(Iterable<String> reelStrip) {
            this.reelStrip = Iterables.toList(reelStrip);
            if (this.reelStrip.isEmpty()) {
                throw new IllegalArgumentException("The reel strip must have at least one symbol defined");
            }
        }

        /**
         * Gets the current position of this reel strip.
         * @return The current position of this reel strip.
         */
        public int getCurrentPosition() {
            return currentPosition;
        }

        /**
         * Adjust the context by moving its pointer to a certain position (zero-based).
         * @return current position after move to previous position
         */
        public int moveToPreviousPosition() {
            currentPosition = sanitizePosition(currentPosition - 1);
            return currentPosition;
        }

        /**
         * Sanitizes the position by limiting it to a reel strip range.
         * @param position The position in the context.
         * @return A position within the rage of this reel strip context.
         */
        private int sanitizePosition(int position) {
            int count = reelStrip.size();
            if (position >= 0) {
                return position % count;
            } else {
                return count - position % count - 2;
            }
        }

        /**
         * Adjust the context by moving its pointer to a certain position (zero-based).
         * @return current position after move to next position
         */
        public int moveToNextPosition() {
            currentPosition = sanitizePosition(currentPosition + 1);
            return currentPosition;
        }

        /**
         * Peeks the name of the symbol at given position.
         * @param position The position in the context.
         * @return The name of the symbol at given position.
         */
        public String getSymbolNameAt(int position) {
            int index = sanitizePosition(position);
            return reelStrip.get(index);
        }

        /**
         * Adjust the context by moving its pointer to a certain position (zero-based).
         * @param position position in the context
         * @return current position after move to position
         */
        public int moveToPosition(int position) {
            currentPosition = sanitizePosition(position);
            return currentPosition;
        }
    }
}
