package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when lock positions button in debug panel was clicked.
 */
@Reflectable
public class DebugPositionsLockCommand {

}
