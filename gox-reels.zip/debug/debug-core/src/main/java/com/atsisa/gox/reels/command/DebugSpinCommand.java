package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when debug spin button has been clicked.
 */
@Reflectable
public final class DebugSpinCommand {

}
