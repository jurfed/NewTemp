package com.atsisa.gox.reels.logic.vocs;

import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.reels.logic.AbstractGameLogicMockup;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.presentation.GamblerPresentation;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;
import com.google.inject.Inject;

import rx.Observable;

/**
 * Represents a debug part of game logic mockup.
 */
public abstract class DebugGameLogicMockup extends AbstractGameLogicMockup implements IDebugReelGameLogic {

    /**
     * Initializes a new instance of the {@link DebugGameLogicMockup} class.
     * @param localization {@link ILocalization}
     */
    @Inject
    public DebugGameLogicMockup(ILocalization localization) {
        super(localization);
    }

    @Override
    public Observable<LogicPresentation> debugBet(DebugBetRequest debugBetRequest) {
        return bet(debugBetRequest);
    }

    @Override
    public Observable<LogicPresentation> debugGamble(DebugGambleRequest debugGambleRequest) {
        return gamble(debugGambleRequest);
    }
}
