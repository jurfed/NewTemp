package com.atsisa.gox.reels;

import com.atsisa.gox.reels.model.IDebugDataModelProvider;
import com.google.inject.Inject;

/**
 * Debug reel game abstraction class.
 */
public abstract class DebugAbstractReelGame extends AbstractReelGame {

    /**
     * Initializes a new instance of the {@link DebugAbstractReelGame} class.
     * @param baseReelGameComponents {@link BaseReelGameComponents}
     */
    @Inject
    public DebugAbstractReelGame(BaseReelGameComponents baseReelGameComponents) {
        super(baseReelGameComponents);
    }

    /**
     * Gets the debug data model provider.
     * @return the debug data model provider
     */
    public IDebugDataModelProvider getDebugDataModelProvider() {
        DebugBaseReelGameComponents debugBaseReelGameComponents = findReelGameComponent(DebugBaseReelGameComponents.class);
        return debugBaseReelGameComponents.getDebugDataModelProvider();
    }
}
