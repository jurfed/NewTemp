package com.atsisa.gox.reels;

import com.atsisa.gox.inject.AbstractModule;
import com.atsisa.gox.reels.fsm.DebugReelGameStateHolder;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.model.DebugDataModelProvider;
import com.atsisa.gox.reels.model.IDebugDataModelProvider;

/**
 * Represents an IoC module which defines debug reels core dependencies.
 */
public class DebugReelsCoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(DebugBaseReelGameComponents.class).asEagerSingleton();
        bind(IDebugDataModelProvider.class).to(DebugDataModelProvider.class).asEagerSingleton();
        bind(IReelGameStateHolder.class).to(DebugReelGameStateHolder.class).asEagerSingleton();
    }

}
