package com.atsisa.gox.reels.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.GamblerDebugSelectedEvent;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Represents the debug gambler screen.
 */
public class DebugGamblerScreen extends GamblerScreen {

    /**
     * Initializes a new instance of the {@link DebugGamblerScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link GamblerScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     * @param resourceManager  {@link IResourceManager}
     * @param creditsFormatter {@link ICreditsFormatter}
     */
    @Inject
    public DebugGamblerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, GamblerScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IResourceManager resourceManager, ICreditsFormatter creditsFormatter) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, resourceManager, creditsFormatter);
    }

    /**
     * Called when black should win.
     */
    @ExposeMethod
    public void blackWin() {
        getEventBus().post(new GamblerDebugSelectedEvent(CardType.BLACK, true));
    }

    /**
     * Called when red should win.
     */
    @ExposeMethod
    public void redWin() {
        getEventBus().post(new GamblerDebugSelectedEvent(CardType.RED, true));
    }

    /**
     * Called when black should lose.
     */
    @ExposeMethod
    public void blackLose() {
        getEventBus().post(new GamblerDebugSelectedEvent(CardType.BLACK, false));
    }

    /**
     * Called when red should lose.
     */
    @ExposeMethod
    public void redLose() {
        getEventBus().post(new GamblerDebugSelectedEvent(CardType.RED, false));
    }

}
