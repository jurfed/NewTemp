package com.atsisa.gox.reels.model;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.reels.command.DebugPositionsChangeCommand;
import com.atsisa.gox.reels.command.DebugPositionsClearCommand;
import com.atsisa.gox.reels.command.DebugPositionsLockCommand;
import com.atsisa.gox.reels.command.DebugPositionsUnlockCommand;
import com.google.inject.Inject;

/**
 * Handles all aspect of reel game debug stop positions configuration.
 */
public class DebugDataModelProvider implements IDebugDataModelProvider {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * Debug data model.
     */
    private final DebugDataModel debugDataModel;

    /**
     * Initializes a new instance of the {@link DebugDataModelProvider} class.
     * @param eventBus {@link IEventBus}
     */
    @Inject
    public DebugDataModelProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        debugDataModel = new DebugDataModel();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new DebugPositionsChangeCommandObserver(), DebugPositionsChangeCommand.class);
        eventBus.register(new DebugPositionsClearCommandObserver(), DebugPositionsClearCommand.class);
        eventBus.register(new DebugPositionsLockCommandObserver(), DebugPositionsLockCommand.class);
        eventBus.register(new DebugPositionsUnlockCommandObserver(), DebugPositionsUnlockCommand.class);
    }

    /**
     * Handles {@link DebugPositionsChangeCommand}
     * @param debugPositionsChangeCommand {@link DebugPositionsChangeCommand}
     */
    @Subscribe
    public void handleDebugPositionsChangeCommand(DebugPositionsChangeCommand debugPositionsChangeCommand) {
        debugDataModel.setStopPositions(debugPositionsChangeCommand.getStopPositions());
    }

    /**
     * Handles {@link DebugPositionsClearCommand}
     * @param debugPositionsClearCommand {@link DebugPositionsClearCommand}
     */
    @Subscribe
    public void handleDebugPositionsClearCommand(DebugPositionsClearCommand debugPositionsClearCommand) {
        debugDataModel.clearStopPositions();
    }

    /**
     * Handles {@link DebugPositionsLockCommand}
     * @param positionLockCommand {@link DebugPositionsLockCommand}
     */
    @Subscribe
    public void handleDebugPositionsLockCommand(DebugPositionsLockCommand positionLockCommand) {
        debugDataModel.setStopPositionsLocked(true);
    }

    /**
     * Handles {@link DebugPositionsUnlockCommand}
     * @param debugPositionsUnlockCommand {@link DebugPositionsUnlockCommand}
     */
    @Subscribe
    public void handleDebugPositionsUnlockCommand(DebugPositionsUnlockCommand debugPositionsUnlockCommand) {
        debugDataModel.setStopPositionsLocked(false);
    }

    @Override
    public IDebugDataModel getDebugDataModel() {
        return debugDataModel;
    }

    @Override
    public boolean isDebugDataModelLocked() {
        return debugDataModel.isStopPositionsLocked();
    }

    @Override
    public void clearDebugDataModel() {
        debugDataModel.clearStopPositions();
    }

    @Override
    public boolean isDebugDataModelValid() {
        return debugDataModel.hasStopPositions();
    }

    private class DebugPositionsChangeCommandObserver extends NextObserver<DebugPositionsChangeCommand> {

        @Override
        public void onNext(DebugPositionsChangeCommand debugPositionsChangeCommand) {
            handleDebugPositionsChangeCommand(debugPositionsChangeCommand);
        }
    }

    private class DebugPositionsClearCommandObserver extends NextObserver<DebugPositionsClearCommand> {

        @Override
        public void onNext(DebugPositionsClearCommand debugPositionsClearCommand) {
            handleDebugPositionsClearCommand(debugPositionsClearCommand);
        }
    }

    private class DebugPositionsLockCommandObserver extends NextObserver<DebugPositionsLockCommand> {

        @Override
        public void onNext(DebugPositionsLockCommand debugPositionsLockCommand) {
            handleDebugPositionsLockCommand(debugPositionsLockCommand);
        }
    }

    private class DebugPositionsUnlockCommandObserver extends NextObserver<DebugPositionsUnlockCommand> {

        @Override
        public void onNext(DebugPositionsUnlockCommand debugPositionsUnlockCommand) {
            handleDebugPositionsUnlockCommand(debugPositionsUnlockCommand);
        }
    }
}
