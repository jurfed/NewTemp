package com.atsisa.gox.reels.fsm;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.command.DebugSpinCommand;
import com.atsisa.gox.reels.command.DebugStartAutoPlayCommand;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.GamblerDebugSelectedEvent;
import com.google.inject.Inject;

/**
 * Handles all aspects related to the debug reel game state.
 */
public class DebugReelGameStateHolder extends ReelGameStateHolder {

    /**
     * Debug spin reels queue name.
     */
    private static final String DEBUG_SPIN_REELS_QUEUE_NAME = "DebugSpinReels";

    /**
     * Selected gambler black card queue name.
     */
    private static final String SELECTED_GAMBLER_RED_LOSE_QUEUE_NAME = "SelectedGamblerRedLose";

    /**
     * Selected gambler black card queue name.
     */
    private static final String SELECTED_GAMBLER_RED_WIN_QUEUE_NAME = "SelectedGamblerRedWin";

    /**
     * Selected gambler black card queue name.
     */
    private static final String SELECTED_GAMBLER_BLACK_LOSE_QUEUE_NAME = "SelectedGamblerBlackLose";

    /**
     * Selected gambler black card queue name.
     */
    private static final String SELECTED_GAMBLER_BLACK_WIN_QUEUE_NAME = "SelectedGamblerBlackWin";

    /**
     * Initializes new instance of ReelGameStateHolder.
     * @param eventBus      {@link IEventBus}
     * @param actionManager {@link IActionManager}
     * @param viewManager   {@link IViewManager}
     */
    @Inject
    public DebugReelGameStateHolder(IEventBus eventBus, IActionManager actionManager, IViewManager viewManager) {
        super(eventBus, actionManager, viewManager);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        eventBus.register(new DebugSpinButtonClickedObserver(), DebugSpinCommand.class);
        eventBus.register(new DebugStartAutoPlayObserver(), DebugStartAutoPlayCommand.class);
        eventBus.register(new GamblerDebugSelectedEventObserver(), GamblerDebugSelectedEvent.class);
    }

    /**
     * Handles debug spin button click events received from the bus.
     * @param debugSpinCommand event representing debug spin button click.
     */
    @Subscribe
    public void handleDebugSpinCommand(final DebugSpinCommand debugSpinCommand) {
        processActionQueue(DEBUG_SPIN_REELS_QUEUE_NAME);
    }

    /**
     * Handles request to debug start auto play.
     * @param debugStartAutoPlayCommand {@link DebugStartAutoPlayCommand}
     */
    private void handleDebugStartAutoPlayCommand(DebugStartAutoPlayCommand debugStartAutoPlayCommand) {
        processAutoPlaySpinQueue(DEBUG_SPIN_REELS_QUEUE_NAME, debugStartAutoPlayCommand);
    }

    /**
     * Handles a debug gambler selected events.
     * @param gamblerDebugSelectedEvent event representing debug gambler selected.
     */
    @Subscribe
    private void handleGamblerDebugSelectedEvent(GamblerDebugSelectedEvent gamblerDebugSelectedEvent) {
        boolean win = gamblerDebugSelectedEvent.isWin();
        boolean black = gamblerDebugSelectedEvent.getCardType() == CardType.BLACK;
        if (win) {
            if (black) {
                processActionQueue(SELECTED_GAMBLER_BLACK_WIN_QUEUE_NAME);
            } else {
                processActionQueue(SELECTED_GAMBLER_RED_WIN_QUEUE_NAME);
            }
        } else if (black) {
            processActionQueue(SELECTED_GAMBLER_BLACK_LOSE_QUEUE_NAME);
        } else {
            processActionQueue(SELECTED_GAMBLER_RED_LOSE_QUEUE_NAME);
        }
    }

    private class DebugStartAutoPlayObserver extends NextObserver<DebugStartAutoPlayCommand> {

        @Override
        public void onNext(final DebugStartAutoPlayCommand debugStartAutoPlayCommand) {
            handleDebugStartAutoPlayCommand(debugStartAutoPlayCommand);
        }
    }

    private class DebugSpinButtonClickedObserver extends NextObserver<DebugSpinCommand> {

        @Override
        public void onNext(final DebugSpinCommand debugSpinCommand) {
            handleDebugSpinCommand(debugSpinCommand);
        }
    }

    private class GamblerDebugSelectedEventObserver extends NextObserver<GamblerDebugSelectedEvent> {

        @Override
        public void onNext(GamblerDebugSelectedEvent gamblerDebugSelectedEvent) {
            handleGamblerDebugSelectedEvent(gamblerDebugSelectedEvent);
        }
    }
}
