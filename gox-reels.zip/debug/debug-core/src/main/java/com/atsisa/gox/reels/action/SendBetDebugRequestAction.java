package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.reels.DebugAbstractReelGame;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.model.IDebugDataModelProvider;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

import rx.Observable;

/**
 * Send bet debug request to the server.
 */
@Reflect_Mini
public class SendBetDebugRequestAction extends SendBetRequestAction {

    /**
     * Debug data model.
     */
    private final IDebugDataModelProvider debugDataModelProvider;

    /**
     * Initializes a new instance of the {@link SendBetDebugRequestAction} class.
     */
    public SendBetDebugRequestAction() {
        debugDataModelProvider = ((DebugAbstractReelGame) getGame()).getDebugDataModelProvider();
    }

    @Override
    protected BetRequest createRequest() {
        if (debugDataModelProvider.isDebugDataModelValid()) {
            return new DebugBetRequest(getBetModelProvider().getBetModel().getBetPerLine(), getLinesModelProvider().getLinesModel().getSelectedLines(),
                    debugDataModelProvider.getDebugDataModel().getStopPositions());
        }
        return super.createRequest();
    }

    @Override
    protected Observable<LogicPresentation> getResponse(BetRequest betRequest) {
        if (debugDataModelProvider.isDebugDataModelValid()) {
            return ((IDebugReelGameLogic) getGameLogic()).debugBet((DebugBetRequest) betRequest);
        }
        return super.getResponse(betRequest);
    }

    @Override
    protected void validate() throws ValidationException {
        super.validate();
        if (debugDataModelProvider.getDebugDataModel() == null) {
            throw new ValidationException("The debug data model cannot be null.");
        }
    }

    @Override
    protected void finish() {
        if (!debugDataModelProvider.isDebugDataModelLocked()) {
            debugDataModelProvider.clearDebugDataModel();
        }
        super.finish();
    }
}
