package com.atsisa.gox.reels;

/**
 * Represents a listener of changing state.
 */
public interface IAutoStartListener {

    /**
     * Called when the state was changed.
     *
     * @param state the state of automatic start
     */
    void stateChanged(AutoStartState state);
}
