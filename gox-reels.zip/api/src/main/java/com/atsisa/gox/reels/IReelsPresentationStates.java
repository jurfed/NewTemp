package com.atsisa.gox.reels;

/**
 * Exposes methods for objects which contains collection of the states which are available in the reel game.
 */
public interface IReelsPresentationStates {

    /**
     * Returns a collection of the available states in reel game.
     * @return a collection of the available states
     */
    String[] getAvailableStates();

}
