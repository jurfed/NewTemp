package com.atsisa.gox.reels;

/**
 * Represents a listener of changing model.
 */
public interface ILinesModelListener {

    /**
     * Called when the model was changed.
     *
     * @param model the lines model
     */
    void modelChanged(ILinesModel model);
}
