package com.atsisa.gox.reels;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Represents a controller for gambler.
 */
public interface IGamblerController {

    /**
     * Selects the gambler card.
     * @param cardType card type
     */
    void select(CardType cardType);

    /**
     * Returns selected card type.
     * @return cardType card type, optional is empty if card not selected.
     */
    Optional<CardType> getSelectedCard();

    /**
     * Gets gambler bid amount
     * @return {@link BigDecimal}
     */
    BigDecimal getBidAmount();

    /**
     * Gets gambler won amount (e.g. zero after gambler lose)
     * @return {@link BigDecimal}}
     */
    BigDecimal getWonAmount();

    /**
     * Enters to gambler.
     */
    void enter();

    /**
     * Adds a listener to listen for card selects.
     * @param listener the auto start listener
     * @return {@link ClosableListening}
     */
    ClosableListening addGamblerListener(IGamblerListener listener);
}
