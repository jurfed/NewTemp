package com.atsisa.gox.reels;

import java.util.Optional;

/**
 * Represents the model of lines adjuster.
 */
public interface ILinesModel {

    /**
     * Gets a number of active lines the user currently plays on.
     * @return the current number of active lines
     */
    int getSelectedLines();

    /**
     * Gets a collection of available line numbers to choose from.
     * @return a collection of line numbers
     */
    Iterable<Integer> getAvailableLines();

    /**
     * Gets the maximal number of lines the user can possibly play on.
     * @return the last number from the available lines collection
     */
    int getMaxLines();

    /**
     * Gets the minimal number of lines the user can possibly play on.
     * @return the first number from the available lines collection
     */
    int getMinLines();

    /**
     * Gets the currently winning lines.
     * <p>
     * This method returns an empty collection in case
     * there are no current winning lines.
     * </p>
     * @return A collection of winning lines.
     */
    Iterable<? extends IWinLineInfo> getWinningLines();

    /**
     * Gets the currently win line info.
     * <p>
     * The returned {@link Optional} has no value if there are no win line info to show.
     * </p>
     * @return {@link IWinLineInfo}
     */
    Optional<IWinLineInfo> getCurrentWinningLine();
}
