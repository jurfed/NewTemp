package com.atsisa.gox.reels;

/**
 * Represents a controller for info screens.
 */
public interface IInfoScreenController {

    /**
     * Triggers the next info screen.
     */
    void nextScreen();
}
