package com.atsisa.gox.reels;

/**
 * Represents a controller of line adjuster.
 */
public interface ILinesController {

    /**
     * Gets model of lines adjuster.
     *
     * @return {@link ILinesModel}
     */
    ILinesModel getModel();

    /**
     * Sets the specified lines amount.
     *
     * @param linesAmount the lines amount
     * @throws IllegalArgumentException the specified lines amount not exist
     */
    void setLines(int linesAmount) throws IllegalArgumentException;

    /**
     * Sets the next lines amount.
     */
    void nextLines();

    /**
     * Sets the previous lines amount.
     */
    void previousLines();

    /**
     * Adds a listener to listen for model changes.
     *
     * @param listener the lines model listener
     * @return {@link ClosableListening}
     */
    ClosableListening addModelListener(ILinesModelListener listener);
}
