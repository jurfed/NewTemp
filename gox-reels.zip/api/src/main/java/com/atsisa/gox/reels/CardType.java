package com.atsisa.gox.reels;

/**
 * Represents type of gambler card.
 */
public enum CardType {

    /**
     * Red card.
     */
    RED,

    /**
     * Black card.
     */
    BLACK
}