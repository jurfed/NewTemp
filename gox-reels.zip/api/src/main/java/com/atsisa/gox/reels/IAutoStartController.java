package com.atsisa.gox.reels;

/**
 * Represents a controller for automatic start.
 */
public interface IAutoStartController {

    /**
     * Gets the state of automatic start.
     *
     * @return {@link AutoStartState}
     */
    AutoStartState getState();

    /**
     * Turns the automatic start on.
     */
    void turnOn();

    /**
     * Turns the automatic start off.
     */
    void turnOff();

    /**
     * Adds a listener to listen for state changes.
     *
     * @param listener the auto start listener
     * @return {@link ClosableListening}
     */
    ClosableListening addStateListener(IAutoStartListener listener);
}
