package com.atsisa.gox.reels;

/**
 * Represents state of automatic start.
 */
public enum AutoStartState {

    /**
     * The automatic start is turned off.
     */
    OFF,

    /**
     * The automatic start is turned on.
     */
    ON
}
