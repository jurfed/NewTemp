package com.atsisa.gox.reels;

/**
 * Represents a closable listening.
 * This interface is responsible for closing listening using the {@link #close()} method.
 */
public interface ClosableListening extends AutoCloseable {

    /**
     * Closes listening.
     */
    void close();
}