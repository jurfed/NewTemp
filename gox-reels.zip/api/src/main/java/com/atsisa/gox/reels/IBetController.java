package com.atsisa.gox.reels;

import java.math.BigDecimal;

/**
 * Represents a controller for the bet adjuster.
 */
public interface IBetController {

    /**
     * Gets model of the bet adjuster.
     *
     * @return {@link IBetModel}
     */
    IBetModel getModel();

    /**
     * Sets the specified bet value.
     *
     * @param bet the bet to set
     * @throws IllegalArgumentException the specified bet not exist
     */
    void setBet(BigDecimal bet) throws IllegalArgumentException;

    /**
     * Sets the next bet step.
     */
    void nextBet();

    /**
     * Sets the previous bet step.
     */
    void previousBet();

    /**
     * Adds a listener to listen for model changes.
     *
     * @param listener the bet model listener
     * @return {@link ClosableListening}
     */
    ClosableListening addModelListener(IBetModelListener listener);
}
