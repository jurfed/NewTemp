package com.atsisa.gox.reels;

import java.math.BigDecimal;

/**
 * Represents the winning line.
 */
public interface IWinLineInfo {

    /**
     * Gets the number of line.
     * @return a line number
     */
    int getLineNumber();

    /**
     * Gets the name of sound.
     * @return the name of sound
     */
    String getSoundName();

    /**
     * Gets the name of animation.
     * @return the name of animation
     */
    String getAnimationName();

    /**
     * Gets the score of win.
     * @return the score of win
     */
    BigDecimal getScore();

    /**
     * Gets the positions of winning line.
     * @return the positions of winning line
     */
    Iterable<Integer> getPositions();

    /**
     * Gets the winning sequence.
     * @return the winning sequence
     */
    Iterable<Boolean> getWinningSequence();
}
