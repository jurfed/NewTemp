package com.atsisa.gox.reels;

/**
 * Represents a listener of selecting card.
 */
public interface IGamblerListener {

    /**
     * Called when card was selected.
     *
     * @param cardType card type
     */
    void cardSelected(CardType cardType);
}
