package com.atsisa.gox.reels;

import java.math.BigDecimal;

/**
 * Represents the model of bet adjuster.
 */
public interface IBetModel {

    /**
     * Gets a currently selected bet per line value.
     * @return the bet value
     */
    BigDecimal getBetPerLine();

    /**
     * Gets the total bet value.
     * Its a value of current bet multiplied by a number of lines user currently plays on.
     * @return the total bet value
     */
    BigDecimal getTotalBet();

    /**
     * Gets a collection of available bet steps.
     * @return a collection of available bet steps
     */
    Iterable<BigDecimal> getBetSteps();

    /**
     * Gets the minimal value of bet per line
     * the user can possibly set.
     * @return the first number from the available bet steps
     */
    BigDecimal getMinBet();

    /**
     * Gets the maximal value of bet per line
     * the user can possibly set.
     * @return the last number from the available bet steps
     */
    BigDecimal getMaxBet();
}
