package com.atsisa.gox.reels;

/**
 * Represents a listener of changing state.
 */
public interface IPresentationStateListener {

    /**
     * Called when the state was changed.
     *
     * @param stateName the state name
     */
    void stateChanged(String stateName);
}
