package com.atsisa.gox.reels;

/**
 * Represents a listener of changing model.
 */
public interface IBetModelListener {

    /**
     * Called when the model was changed.
     *
     * @param model the bet model
     */
    void modelChanged(IBetModel model);
}
