package com.atsisa.gox.reels;

/**
 * Represents states of reels presentation.
 */
public final class ReelsPresentationStates implements IReelsPresentationStates {

    /**
     * Empty state.
     */
    public static final String NONE = "None";

    /**
     * The game start state.
     */
    public static final String GAME_START = "GameStart";

    /**
     * The idle state.
     */
    public static final String IDLE = "Idle";

    /**
     * The running reels state.
     */
    public static final String RUNNING_REELS = "RunningReels";

    /**
     * The stopping reels state.
     */
    public static final String STOPPING_REELS = "StoppingReels";

    /**
     * The offer gambler state.
     */
    public static final String OFFER_GAMBLER = "OfferGambler";

    /**
     * The entering gambler state.
     */
    public static final String ENTERING_GAMBLER = "EnteringGambler";

    /**
     * The gambler state.
     */
    public static final String GAMBLER = "Gambler";

    /**
     * The gambler win state.
     */
    public static final String GAMBLER_WIN = "GamblerWin";

    /**
     * The gambler limit state.
     */
    public static final String GAMBLER_LIMIT = "GamblerLimit";

    /**
     * The gambler lose state.
     */
    public static final String GAMBLER_LOSE = "GamblerLose";

    /**
     * The win counting state.
     */
    public static final String WIN_COUNTING = "WinCounting";

    /**
     * The reels win animation state.
     */
    public static final String REELS_WIN_ANIMATION = "ReelsWinAnimation";

    /**
     * The game win state.
     */
    public static final String GAME_WIN = "GameWin";

    /**
     * The game lose state.
     */
    public static final String GAME_LOSE = "GameLose";

    /**
     * The game history state.
     */
    public static final String HISTORY = "History";

    /**
     * The game history win state.
     */
    public static final String HISTORY_WIN = "HistoryWin";

    /**
     * An array of available reels states.
     */
    private static final String[] AvailableStates = { NONE, GAME_START, IDLE, RUNNING_REELS, STOPPING_REELS, REELS_WIN_ANIMATION, GAME_WIN, GAME_LOSE,
            OFFER_GAMBLER, ENTERING_GAMBLER, GAMBLER, GAMBLER_WIN, GAMBLER_LOSE, WIN_COUNTING, HISTORY, HISTORY_WIN };

    @Override
    public String[] getAvailableStates() {
        return AvailableStates;
    }

}
