package com.atsisa.gox.reels;

/**
 * Represents the presentation controller.
 */
public interface IPresentationController {

    /**
     * Gets the name of current presentation state.
     *
     * @return the name of presentation state
     */
    String getState();

    /**
     * Triggers the next presentation.
     *
     * @throws IllegalStateException triggering the next presentation in the current state is not allowed
     */
    void next() throws IllegalStateException;

    /**
     * Adds a listener to listen for state changes.
     *
     * @param listener the presentation state listener
     * @return {@link ClosableListening}
     */
    ClosableListening addStateListener(IPresentationStateListener listener);
}
