package com.atsisa.gox.reels.model;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.command.DecreaseLinesCommand;
import com.atsisa.gox.reels.command.IncreaseLinesCommand;
import com.atsisa.gox.reels.command.NextLinesCommand;
import com.atsisa.gox.reels.command.PreviousLinesCommand;
import com.atsisa.gox.reels.command.SetLinesCommand;
import com.atsisa.gox.reels.command.ShowNextWinningLineCommand;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.model.WinLineInfo;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.google.gwt.thirdparty.guava.common.collect.Iterables;

/**
 * Tests for {@link LinesModelProvider} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class LinesModelProviderTest {

    private static final String PRESENTATION_NAME = "PRESENTATION_NAME";

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * Game configuration mock.
     */
    @Mock
    private GameConfiguration gameConfigurationMock;

    /**
     * Language info mock.
     */
    @Mock
    private LanguageInfo languageInfoMock;

    /**
     * Tested provider.
     */
    private LinesModelProvider provider;

    /**
     * Called before each tests.
     */
    @Before
    public void setUp() {
        provider = new LinesModelProvider(eventBusMock);
    }

    /**
     * Tests whether event bus receives notifications when init response comes.
     */
    @Test
    public void shouldNotifyModelChangedWhenInitResponseCame() {
        // GIVEN
        final List<Integer> expectedAvailableLines = Arrays.asList(1, 3, 5, 7, 9);
        InitResult initResult = createInitResult(expectedAvailableLines);

        // WHEN
        provider.handleInitResult(initResult);

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(1)).post(linesModelCaptor.capture());
        LinesModelChangedEvent linesModelChanged = linesModelCaptor.getValue();
        ILinesModel linesModel = linesModelChanged.getLinesModel();
        assertArrayEquals(expectedAvailableLines.toArray(), Iterables.toArray(linesModel.getAvailableLines(), Integer.class));
        assertTrue(linesModelChanged.hasAvailableLinesChanged());
        assertFalse(linesModelChanged.hasSelectedLinesChanged());
        assertFalse(linesModelChanged.hasWinningLinesChanged());
        assertFalse(linesModelChanged.hasCurrentWinningLineChanged());
    }

    /**
     * Tests whether the increase command causes no troubles in case it hasn't been preceded by the init response.
     */
    @Test
    public void shouldSkipNotificationWhenIncreaseNotPrecededWithInit() {
        // WHEN
        provider.handleIncreaseLinesCommand(new IncreaseLinesCommand(false));

        // THEN
        verify(eventBusMock, never()).post(any(LinesModelChangedEvent.class));
    }

    /**
     * Tests whether the show next winning line command causes no troubles in case there is no winning lines.
     */
    @Test
    public void shouldSkipNotificationWhenThereIsNoWinningLines() {
        // WHEN
        provider.handleShowNextWinningLineCommand(new ShowNextWinningLineCommand());

        // THEN
        verify(eventBusMock, never()).post(any(LinesModelChangedEvent.class));
    }

    /**
     * Tests whether the notification about model has been changed, after request for show next winning line has been sent.
     */
    @Test
    public void shouldNotifyModelChangedWhenRequestForShowNextWinningLine() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(5, 6, 7));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(5);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);
        WinningPresentation winningPresentation = createWinPresentation();
        provider.handleWinningPresentation(winningPresentation);
        reset(eventBusMock);
        IWinLineInfo expectedWinLineInfo = winningPresentation.getWinningLines().get(0);

        // WHEN
        provider.handleShowNextWinningLineCommand(new ShowNextWinningLineCommand());

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(1)).post(linesModelCaptor.capture());
        LinesModelChangedEvent linesModelChanged = linesModelCaptor.getValue();
        ILinesModel linesModel = linesModelChanged.getLinesModel();
        assertEquals(expectedWinLineInfo, linesModel.getCurrentWinningLine().get());
        assertFalse(linesModelChanged.hasAvailableLinesChanged());
        assertFalse(linesModelChanged.hasSelectedLinesChanged());
        assertFalse(linesModelChanged.hasWinningLinesChanged());
        assertTrue(linesModelChanged.hasCurrentWinningLineChanged());
    }

    /**
     * Tests whether the decrease command causes no troubles in case it hasn't been preceded by the init response.
     */
    @Test
    public void shouldSkipNotificationWhenDecreaseNotPrecededWithInit() {
        // WHEN
        provider.handleDecreaseLinesCommand(new DecreaseLinesCommand(false));

        // THEN
        verify(eventBusMock, never()).post(any(LinesModelChangedEvent.class));
    }

    /**
     * Tests whether the increase lines command works properly when the limit hasn't been reached.
     */
    @Test
    public void shouldIncreaseLinesWhenLimitIsNotReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(3);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleIncreaseLinesCommand(new IncreaseLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(5, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the next lines command works properly when the limit hasn't been reached.
     */
    @Test
    public void shouldSetNextLinesWhenLimitIsNotReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(3);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleNextLinesCommand(new NextLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(5, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the next lines command works properly when the limit has been reached.
     */
    @Test
    public void shouldSetNextLinesWhenLimitIsReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(5);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleNextLinesCommand(new NextLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(1, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the previous lines command works properly when the limit has not been reached.
     */
    @Test
    public void shouldSetPreviousLinesWhenLimitIsNotReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(5);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handlePreviousLinesCommand(new PreviousLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(3, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the previous lines command works properly when the limit has been reached.
     */
    @Test
    public void shouldSetMaxLinesWhenLimitIsReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(1);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handlePreviousLinesCommand(new PreviousLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(5, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the increase lines command works properly when the limit has been reached.
     */
    @Test
    public void shouldNotIncreaseLinesWhenLimitIsReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(5);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleIncreaseLinesCommand(new IncreaseLinesCommand(false));

        // THEN
        verify(eventBusMock, times(2)).post(any(LinesModelChangedEvent.class));
        assertEquals(5, provider.getLinesModel().getSelectedLines());
    }

    /**
     * Tests whether the decrease lines command works properly when the limit hasn't been reached.
     */
    @Test
    public void shouldDecreaseLinesWhenLimitIsNotReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(3);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleDecreaseLinesCommand(new DecreaseLinesCommand(false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());
        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(1, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the set lines command works.
     */
    @Test
    public void shouldSetLinesToGivenValue() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(5);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleSetLinesCommand(new SetLinesCommand(3, false));

        // THEN
        ArgumentCaptor<LinesModelChangedEvent> linesModelCaptor = ArgumentCaptor.forClass(LinesModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(linesModelCaptor.capture());

        LinesModelChangedEvent linesModelChangedEvent = linesModelCaptor.getValue();
        Assert.assertEquals(3, linesModelChangedEvent.getLinesModel().getSelectedLines());
        assertFalse(linesModelChangedEvent.hasAvailableLinesChanged());
        assertTrue(linesModelChangedEvent.hasSelectedLinesChanged());
        assertFalse(linesModelChangedEvent.hasWinningLinesChanged());
    }

    /**
     * Tests whether the decrease lines command works properly when the limit has been reached.
     */
    @Test
    public void shouldNotDecreaseLinesWhenLimitIsReached() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(1);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleDecreaseLinesCommand(new DecreaseLinesCommand(false));

        // THEN
        verify(eventBusMock, times(2)).post(any(LinesModelChangedEvent.class));
        assertEquals(1, provider.getLinesModel().getSelectedLines());
    }

    /**
     * Tests whether the winning lines updates are properly handled.
     */
    @Test
    public void shouldUpdateWinningLinesWhenWinResponseCame() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        provider.handleInitResult(initResult);
        reset(eventBusMock);
        WinningPresentation winningPresentation = createWinPresentation();
        List<IWinLineInfo> expectedWinningLines = winningPresentation.getWinningLines();

        // WHEN
        provider.handleWinningPresentation(winningPresentation);

        // THEN
        verify(eventBusMock, times(1)).post(any(LinesModelChangedEvent.class));
        assertEquals(expectedWinningLines, provider.getLinesModel().getWinningLines());
    }

    /**
     * Tests whether the winning lines are not updates on lose responses.
     */
    @Test
    public void shouldNotUpdateWinningLinesWhenSameAlreadyExist() {
        // GIVEN
        InitResult initResult = createInitResult(Arrays.asList(1, 3, 5));
        provider.handleInitResult(initResult);
        reset(eventBusMock);
        WinningPresentation losePresentation = createLosePresentation();

        // WHEN
        provider.handleWinningPresentation(losePresentation);

        // THEN
        verify(eventBusMock, never()).post(any(LinesModelChangedEvent.class));
        assertFalse(provider.getLinesModel().getWinningLines().iterator().hasNext());
    }

    /**
     * Creates init result with specified available lines and selected lines number.
     * @param availableLines available lines
     * @return the init result
     */
    private InitResult createInitResult(List<Integer> availableLines) {
        when(gameConfigurationMock.getLines()).thenReturn(availableLines);
        return new InitResult(gameConfigurationMock, languageInfoMock);
    }

    /**
     * Creates and returns new reel game presentation.
     * @param selectedLines selected lines
     * @return new reel game presentation
     */
    private ReelGamePresentation createReelGamePresentation(int selectedLines) {
        GameplayProperties gameplayProperties = new GameplayProperties(selectedLines, BigDecimal.valueOf(1), BigDecimal.valueOf(1000));
        return new ReelGamePresentation(PRESENTATION_NAME, gameplayProperties, Collections.emptyList(), false, false);
    }

    /**
     * Creates win presentation.
     * @return the win presentation
     */
    private static WinningPresentation createWinPresentation() {
        IWinLineInfo winLine = new WinLineInfo(1, "Sound", "Short", BigDecimal.valueOf(20), Collections.emptyList());
        return new WinningPresentation(PRESENTATION_NAME, BigDecimal.valueOf(20), Arrays.asList(winLine), false, false);
    }

    /**
     * Creates lose presentation.
     * @return the lose presentation
     */
    private static WinningPresentation createLosePresentation() {
        return new WinningPresentation(PRESENTATION_NAME, BigDecimal.valueOf(0), Collections.emptyList(), false, false);
    }
}

