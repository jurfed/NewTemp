package com.atsisa.gox.reels.view;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;

/**
 * Test utilities for symbols.
 */
public class SymbolUtility {

    /**
     * Prevents from creating.
     */
    private SymbolUtility() {
    }

    /**
     * Gets the symbol by name.
     * @param symbols The collection of symbols.
     * @param name    The name of the symbol.
     * @return A symbol of given name or null.
     */
    public static AbstractSymbol getSymbolByName(Iterable<AbstractSymbol> symbols, String name) {
        for (AbstractSymbol symbol : symbols) {
            if (symbol.getName().equals(name)) {
                return symbol;
            }
        }

        return null;
    }

    /**
     * Gets symbols by name.
     * @param symbols The collection of symbols.
     * @param name    The name of the symbol.
     * @return symbols of given name.
     */
    public static List<AbstractSymbol> getSymbolsByName(Iterable<AbstractSymbol> symbols, String name) {
        List<AbstractSymbol> answer = new ArrayList<>();
        for (AbstractSymbol symbol : symbols) {
            if (symbol.getName().equals(name)) {
                answer.add(symbol);
            }
        }

        return answer;
    }

    /**
     * Creates a new symbol mock with given name.
     * @param name The symbol name.
     * @return The symbol mock.
     */
    public static AbstractSymbol newSymbolMock(final String name) {
        AbstractSymbol symbolMock = mock(AbstractSymbol.class);
        when(symbolMock.getName()).thenReturn(name);
        AbstractSymbol symbolCloneMock = mock(AbstractSymbol.class);
        when(symbolCloneMock.getName()).thenReturn(name);
        return symbolMock;
    }

    /**
     * Creates a collection of symbol mocks.
     * @param names Symbol mock names.
     * @return A collection of symbol mocks.
     */
    public static List<AbstractSymbol> newSymbolMocks(String... names) {
        List<AbstractSymbol> symbols = new ArrayList<>();
        for (String name : names) {
            symbols.add(newSymbolMock(name));
        }

        return symbols;
    }

    /**
     * Creates a new symbol definition of given name.
     * @param symbolName The symbol name.
     * @return The symbol defintion.
     */
    public static XmlObject newSymbolDefinition(String symbolName) {
        XmlObject xmlObject = new XmlBuilder().startElement("SymbolView").writeAttribute("name", symbolName).endElement().toXmlObject();
        return xmlObject;
    }
}
