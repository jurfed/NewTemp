package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertArrayEquals;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.atsisa.gox.reels.IWinLineInfo;

/**
 * Tests for {@link StateShowSymbolAnimationsStrategy}
 */
public class StateShowSymbolAnimationsStrategyTest {

    /**
     * Tested state show symbol animations strategy class.
     */
    private StateShowSymbolAnimationsStrategy stateShowSymbolAnimationsStrategy;

    /**
     * Mocked reel group reference.
     */
    @Mock
    private IReelGroup reelGroup;

    /**
     * List with mocked reels.
     */
    private List<AbstractReel> reels;

    /**
     * Called before each test.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        reels = new ArrayList<>();

        for (int i = 0; i < 4; ++i) {
            List<AbstractSymbol> symbols = new ArrayList<>();
            symbols.add(mock(AbstractSymbol.class));
            symbols.add(mock(AbstractSymbol.class));
            symbols.add(mock(AbstractSymbol.class));

            AbstractReel abstractReel = mock(AbstractReel.class);
            when(abstractReel.getDisplayedSymbols()).thenReturn(symbols);
            reels.add(abstractReel);
        }
        when(reelGroup.getReels()).thenReturn(reels);
        when(reelGroup.getReel(anyInt())).then(new Answer<IReel>() {

            @Override
            public IReel answer(InvocationOnMock invocation) throws Throwable {
                return reels.get((int) invocation.getArguments()[0]);
            }
        });

        stateShowSymbolAnimationsStrategy = new StateShowSymbolAnimationsStrategy();
    }

    /**
     * Tests whether winning symbols are shown on win.
     */
    @Test
    public void shouldShowWinningSymbolsOnWin() {
        //GIVEN
        String winningAnimationName = "winningAnimation";
        List<IWinLineInfo> winningLines = new ArrayList<>();
        IWinLineInfo winningLine = mock(IWinLineInfo.class);
        List<Integer> rows = new ArrayList<>();
        rows.add(1);
        rows.add(2);
        rows.add(0);
        rows.add(-1);
        int[] symbolCalledRows = new int[3];
        int[] expectedPositions = new int[] { 1, 2, 0 };
        when(winningLine.getPositions()).thenReturn(rows);
        when(winningLine.getAnimationName()).thenReturn(winningAnimationName);
        winningLines.add(winningLine);
        int symbolIndex;
        ArgumentCaptor<String> argumentCaptor;
        int reelIndex = 0;

        //WHEN
        stateShowSymbolAnimationsStrategy.showAnimations(winningLines, reelGroup);

        //THEN
        for (IReel reel : reels) {
            symbolIndex = 0;
            Iterable<AbstractSymbol> symbols = reel.getDisplayedSymbols();
            for (AbstractSymbol symbol : symbols) {
                argumentCaptor = ArgumentCaptor.forClass(String.class);
                verify(symbol, atMost(1)).setState(argumentCaptor.capture());
                if (!argumentCaptor.getAllValues().isEmpty() && argumentCaptor.getValue().equals(winningAnimationName)) {
                    symbolCalledRows[reelIndex] = symbolIndex;
                }
                symbolIndex++;
            }
            reelIndex++;
        }
        assertArrayEquals(expectedPositions, symbolCalledRows);
    }

}
