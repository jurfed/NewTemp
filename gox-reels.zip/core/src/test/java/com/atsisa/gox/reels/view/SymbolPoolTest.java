package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * Tests for {@link SymbolPool} class.
 */
public class SymbolPoolTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Symbol factory mock.
     */
    @Mock
    private ISymbolFactory symbolFactoryMock;

    /**
     * Symbol pool strategy mock.
     */
    @Mock
    private ISymbolPoolStrategy symbolPoolStrategyMock;

    /**
     * Symbol mocks.
     */
    private List<AbstractSymbol> symbolMocks;

    /**
     * Sets up mocks.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        symbolMocks = SymbolUtility.newSymbolMocks("Diamond", "Cherry", "Lemon");
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(new ArrayList<>());
    }

    /**
     * Tests whether the pool strategy is incorporated to initialize the pool.
     */
    @Test
    public void shouldInitializePoolWhenSymbolPoolStrategySaysSo() {
        // GIVEN
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(symbolMocks);

        // WHEN
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);

        // THEN
        assertEquals(1, symbolPool.getSymbolsCount("Diamond"));
        assertEquals(1, symbolPool.getSymbolsCount("Cherry"));
        assertEquals(1, symbolPool.getSymbolsCount("Lemon"));
        assertEquals(3, symbolPool.getSymbolsCount());
    }

    /**
     * Tests whether the pool strategy is incorporated to resolve missing symbol.
     */
    @Test
    public void shouldAddMissingSymbolWhenStrategySaysSo() {
        // GIVEN
        final String missingSymbolName = "MissingOne";
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);
        AbstractSymbol missingSymbol = SymbolUtility.newSymbolMock(missingSymbolName);
        when(symbolPoolStrategyMock.getMissingSymbol(eq(symbolPool), eq(missingSymbolName))).thenReturn(missingSymbol);

        // WHEN
        AbstractSymbol answer = symbolPool.getSymbol(missingSymbolName);

        // THEN
        verify(symbolPoolStrategyMock, times(1)).getMissingSymbol(eq(symbolPool), eq(missingSymbolName));
        assertEquals(missingSymbol, answer);
        assertEquals(1, symbolPool.getSymbolsCount(missingSymbolName));
        assertEquals(1, symbolPool.getSymbolsCount());
    }

    /**
     * Tests whether a symbol which does not belong to the pool can be returned.
     */
    @Test
    public void shouldThrowExceptionWhenReturnedSymbolDoesNotBelongToPool() {
        // GIVEN
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(symbolMocks);
        AbstractSymbol foreignSymbol = SymbolUtility.newSymbolMock("FromOuterSpace");
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);

        // WHEN
        exception.expect(SymbolPoolException.class);
        symbolPool.returnSymbol(foreignSymbol);
    }

    /**
     * Tests whether a symbol can be taken from the pool.
     */
    @Test
    public void shouldGetSymbolFromPoolWhenItBelongsToPool() {
        // GIVEN
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(symbolMocks);
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);
        AbstractSymbol expectedSymbol = SymbolUtility.getSymbolByName(symbolMocks, "Diamond");

        // WHEN
        AbstractSymbol symbol = symbolPool.getSymbol("Diamond");

        // THEN
        assertTrue(expectedSymbol == symbol);
    }

    /**
     * Tests whether taken symbol is no longer available in the pool.
     */
    @Test
    public void shouldGetNoSymbolWhenPoolIsDrained() {
        // GIVEN
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(symbolMocks);
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);
        symbolPool.getSymbol("Diamond");

        // WHEN
        AbstractSymbol anotherDiamond = symbolPool.getSymbol("Diamond");

        // THEN
        verify(symbolPoolStrategyMock, times(1)).getMissingSymbol(eq(symbolPool), eq("Diamond"));
        assertNull(anotherDiamond);
    }

    /**
     * Tests whether taken symbol is returned properly to the pool.
     */
    @Test
    public void shouldReturnSymbolToPoolWhenTakenFromPool() {
        // GIVEN
        when(symbolPoolStrategyMock.initialize(eq(symbolFactoryMock))).thenReturn(symbolMocks);
        ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactoryMock, symbolPoolStrategyMock);
        AbstractSymbol symbolTaken = symbolPool.getSymbol("Diamond");

        // WHEN
        symbolPool.returnSymbol(symbolTaken);

        // THEN
        AbstractSymbol symbolTakenAgain = symbolPool.getSymbol(symbolTaken.getName());
        assertTrue(symbolTaken == symbolTakenAgain);
    }
}
