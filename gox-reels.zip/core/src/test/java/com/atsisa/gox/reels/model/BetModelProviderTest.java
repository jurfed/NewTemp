package com.atsisa.gox.reels.model;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.IBetModel;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.command.DecreaseBetCommand;
import com.atsisa.gox.reels.command.IncreaseBetCommand;
import com.atsisa.gox.reels.command.NextBetCommand;
import com.atsisa.gox.reels.command.PreviousBetCommand;
import com.atsisa.gox.reels.command.SetBetCommand;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.google.gwt.thirdparty.guava.common.collect.Iterables;

/**
 * Tests for {@link BetModelProvider} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class BetModelProviderTest {

    /**
     * The presentation name.
     */
    private static final String PRESENTATION_NAME = "PRESENTATION_NAME";

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * Game configuration mock.
     */
    @Mock
    private GameConfiguration gameConfigurationMock;

    /**
     * Language info mock.
     */
    @Mock
    private LanguageInfo languageInfoMock;

    /**
     * Tested provider.
     */
    private BetModelProvider provider;

    /**
     * Called before each tests.
     */
    @Before
    public void setUp() {
        provider = new BetModelProvider(eventBusMock);
    }

    /**
     * Tests whether event bus receives notifications when init response comes.
     */
    @Test
    public void shouldNotifyModelChangedWhenInitResponseCame() {
        // GIVEN
        List<BigDecimal> expectedBetSteps = Arrays
                .asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15), BigDecimal.valueOf(30), BigDecimal.valueOf(50));
        InitResult initResult = createInitResult(expectedBetSteps);

        // WHEN
        provider.handleInitResult(initResult);

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(1)).post(betModelCaptor.capture());
        BetModelChangedEvent betModelChanged = betModelCaptor.getValue();
        IBetModel betModel = betModelChanged.getBetModel();
        assertArrayEquals(expectedBetSteps.toArray(), Iterables.toArray(betModel.getBetSteps(), BigDecimal.class));
    }

    /**
     * Tests whether event bus receives notification when selected lines are changed.
     */
    @Test
    public void shouldNotifyModelChangedWhenSelectedLinesAreChanged() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(10);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(30);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(10), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);
        ILinesModel linesModel = mock(ILinesModel.class);
        LinesModelChangedEvent modelChangedEvent = new LinesModelChangedEvent(linesModel,
                LinesModelChangedEvent.AVAILABLE_LINES & LinesModelChangedEvent.SELECTED_LINES);
        when(linesModel.getSelectedLines()).thenReturn(3);

        // WHEN
        provider.handleLinesModelChangedEvent(modelChangedEvent);

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the set bet command works properly.
     */
    @Test
    public void shouldChangeCurrentBetOnSetBetCommand() {
        // GIVEN
        BigDecimal expectedBetPerLine = BigDecimal.valueOf(5);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(10);
        InitResult initResult = createInitResult(Arrays.asList(new BigDecimal(5), new BigDecimal(10), new BigDecimal(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(15), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleSetBetCommand(new SetBetCommand(BigDecimal.valueOf(5), true));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBetPerLine.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the increase bet command causes no troubles in case
     * it hasn't been preceded by the init response.
     */
    @Test
    public void shouldSkipNotificationWhenIncreaseNotPrecededWithInit() {
        // WHEN
        provider.handleIncreaseBetCommand(new IncreaseBetCommand(false));

        // THEN
        verify(eventBusMock, never()).post(any(BetModelChangedEvent.class));
    }

    /**
     * Tests whether the decrease bet command causes no troubles in case
     * it hasn't been preceded by the init response.
     */
    @Test
    public void shouldSkipNotificationWhenDecreaseNotPrecededWithInit() {
        // WHEN
        provider.handleDecreaseBetCommand(new DecreaseBetCommand(false));

        // THEN
        verify(eventBusMock, never()).post(any(BetModelChangedEvent.class));
    }

    /**
     * Tests whether the increase bet command works properly when
     * the limit hasn't been reached.
     */
    @Test
    public void shouldIncreaseBetWhenLimitIsNotReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(15);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(30);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(10), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleIncreaseBetCommand(new IncreaseBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the increase bet command works properly when
     * the limit has been reached.
     */
    @Test
    public void shouldNotIncreaseBetWhenLimitIsReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(15);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(15);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(15), 1);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleIncreaseBetCommand(new IncreaseBetCommand(false));

        // THEN
        verify(eventBusMock, times(2)).post(any(BetModelChangedEvent.class));
        assertEquals(expectedBet.compareTo(provider.getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(provider.getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the decrease bet command works properly when
     * the limit hasn't been reached.
     */
    @Test
    public void shouldDecreaseBetWhenLimitIsNotReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(10);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(20);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(10), BigDecimal.valueOf(20), BigDecimal.valueOf(30)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(20), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleDecreaseBetCommand(new DecreaseBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the decrease bet command works properly when the limit has been reached.
     */
    @Test
    public void shouldNotDecreaseBetWhenLimitIsReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(5);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(10);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(5), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleDecreaseBetCommand(new DecreaseBetCommand(false));

        // THEN
        verify(eventBusMock, times(2)).post(any(BetModelChangedEvent.class));
        assertEquals(expectedBet.compareTo(provider.getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(provider.getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the next bet command works properly when the limit is not reached.
     */
    @Test
    public void shouldSetNextBetWhenLimitIsNotReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(15);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(30);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(10), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleNextBetCommand(new NextBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Test whether the next bet command works properly when the limit is reached.
     */
    @Test
    public void shouldSetMinBetWhenMaxBetIsReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(5);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(10);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(15), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handleNextBetCommand(new NextBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the previous bet command works properly when the limit is not reached.
     */
    @Test
    public void shouldSetPreviousBetValueWhenLimitIsNotReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(10);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(20);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(15), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handlePreviousBetCommand(new PreviousBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Tests whether the previous bet command works properly when the limit is not reached.
     */
    @Test
    public void shouldSetMaxBetValueWhenLimitIsReached() {
        // GIVEN
        BigDecimal expectedBet = BigDecimal.valueOf(15);
        BigDecimal expectedTotalBet = BigDecimal.valueOf(30);
        InitResult initResult = createInitResult(Arrays.asList(BigDecimal.valueOf(5), BigDecimal.valueOf(10), BigDecimal.valueOf(15)));
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(5), 2);
        provider.handleInitResult(initResult);
        provider.handleReelGamePresentation(reelGamePresentation);

        // WHEN
        provider.handlePreviousBetCommand(new PreviousBetCommand(false));

        // THEN
        ArgumentCaptor<BetModelChangedEvent> betModelCaptor = ArgumentCaptor.forClass(BetModelChangedEvent.class);
        verify(eventBusMock, times(3)).post(betModelCaptor.capture());
        assertEquals(expectedBet.compareTo(betModelCaptor.getValue().getBetModel().getBetPerLine()), 0);
        assertEquals(expectedTotalBet.compareTo(betModelCaptor.getValue().getBetModel().getTotalBet()), 0);
    }

    /**
     * Creates and returns new init result.
     * @param betsPerLine bet steps
     * @return the init result
     */
    private InitResult createInitResult(List<BigDecimal> betsPerLine) {
        when(gameConfigurationMock.getBetsPerLine()).thenReturn(betsPerLine);
        return new InitResult(gameConfigurationMock, languageInfoMock);
    }

    /**
     * Creates and returns new reel game presentation.
     * @param betAmount     {@link BigDecimal}
     * @param selectedLines selected lines
     * @return new reel game presentation
     */
    private ReelGamePresentation createReelGamePresentation(BigDecimal betAmount, int selectedLines) {
        GameplayProperties gameplayProperties = new GameplayProperties(selectedLines, betAmount, BigDecimal.valueOf(1000));
        return new ReelGamePresentation(PRESENTATION_NAME, gameplayProperties, Collections.emptyList(), false, false);
    }
}

