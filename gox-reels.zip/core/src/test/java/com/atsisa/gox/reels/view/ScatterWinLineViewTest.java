package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.view.RectangleShapeView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.framework.view.spi.IViewActivator;
import com.atsisa.gox.reels.logic.model.WinLineInfo;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * Defines tests for {@link ScatterWinLineView}.
 */
public class ScatterWinLineViewTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * View activator mock.
     */
    @Mock
    private IViewActivator viewActivator;

    /**
     * Renderer mock.
     */
    @Mock
    private IRenderer renderer;

    /**
     * A scatter win line view object.
     */
    private ScatterWinLineView scatterWinLineView;

    /**
     * Sets up mocks.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        scatterWinLineView = new ScatterWinLineView(renderer);
    }

    /**
     * Tests if all children were deactivated and are not visible after init.
     */
    @Test
    public void shouldDeactivateChildrenAfterInit() {
        // GIVEN
        View firstChild = new ViewGroup(renderer);
        View secondChild = new ViewGroup(renderer);

        scatterWinLineView.setViewActivator(viewActivator);

        scatterWinLineView.addChild(firstChild);
        scatterWinLineView.addChild(secondChild);

        // WHEN
        scatterWinLineView.init();

        // THEN
        verify(viewActivator, times(1)).deactivate(firstChild);
        verify(viewActivator, times(1)).deactivate(secondChild);
    }

    /**
     * Tests whether proper value of frame bounds are selected depending on how many scatters are to be displayed.
     * When 4 scatters should be displayed then 4 bounds should be in the bounds list.
     */
    @Test
    public void shouldGetCorrectAmountOfWinningBounds() {
        //GIVEN
        //adds correct amount of frame bounds which are required to show scatter win line defined in received winPositions list
        addViews(15, ScatterWinLineView.FRAME_TAG);

        //WHEN
        List<Integer> winPositions = new ArrayList<>(Arrays.asList(1, 2, 0, -1, 2));
        scatterWinLineView.setWinLineInfo(new WinLineInfo(0, "WinCount0", "Short", BigDecimal.valueOf(30), winPositions));
        List<IBound> bounds = scatterWinLineView.getWinningFramesBounds();

        //THEN
        int[] scattersList = IntStream.range(0, winPositions.size()).filter(i -> winPositions.get(i) > -1).toArray();
        assertTrue(bounds.size() == scattersList.length);
    }

    /**
     * Tests whether exception was thrown when there is no appropriate bound amount in added views
     */
    @Test
    public void shouldThrowExceptionWhenThereIsWrongAmountOfWinningBounds() {
        //GIVEN
        //adds smaller amount of frame bounds than required bound index in received winPositions list
        addViews(10, ScatterWinLineView.FRAME_TAG);

        //WHEN
        //array index defines reel frame number and index value defines frame row number
        List<Integer> winPositions = new ArrayList<>(Arrays.asList(1, 2, 2, -1, 2));
        scatterWinLineView.setWinLineInfo(new WinLineInfo(0, "WinCount0", "Short", BigDecimal.valueOf(30), winPositions));

        //THEN
        exception.expect(IllegalArgumentException.class);
        scatterWinLineView.getWinningFramesBounds();
    }

    /**
     * Tests whether scatter win line is shown together with score box.
     */
    @Test
    public void shouldShowWinWithScoreBox() {
        //GIVEN
        addViews(15, ScatterWinLineView.FRAME_TAG);
        addViews(1, ScatterWinLineView.SCORE_TAG);

        //WHEN
        scatterWinLineView.setState(WinLineState.SHOWN_WINNING);
        List<Integer> winPositions = new ArrayList<>(Arrays.asList(2, -1, 0, 1, 2));
        scatterWinLineView.setWinLineInfo(new WinLineInfo(0, "WinCount0", "Short", BigDecimal.valueOf(10), winPositions));

        //THEN
        scatterWinLineView.showWin(scatterWinLineView.getWinLineInfo());

        List<View> frameViews = scatterWinLineView.getFrameViews();
        int visibleFrameViews = 0;
        for (View frameView : frameViews) {
            if (frameView.isVisible()) {
                visibleFrameViews++;
            }
        }

        List<View> visibleScoreViews = scatterWinLineView.getScoreViews();

        assertTrue(visibleFrameViews == 4 && visibleScoreViews.size() == 1 && visibleScoreViews.get(0).isVisible());
    }

    /**
     * Tests whether proper amount of score boxes are displayed when more than one score box were added.
     */
    @Test
    public void shouldShowWinWithManyScoreBoxes() {
        //GIVEN
        //set views
        int scoreViewsAmount = 5;
        addViews(15, ScatterWinLineView.FRAME_TAG);
        addViews(scoreViewsAmount, ScatterWinLineView.SCORE_TAG);

        //WHEN
        scatterWinLineView.setState(WinLineState.SHOWN_WINNING);
        List<Integer> winPositions = new ArrayList<>(Arrays.asList(0, 1, 0, 1, 2));
        scatterWinLineView.setWinLineInfo(new WinLineInfo(0, "WinCount0", "Short", BigDecimal.valueOf(10), winPositions));

        //THEN
        scatterWinLineView.showWin(scatterWinLineView.getWinLineInfo());

        //find all visible score views
        List<View> scoreViews = scatterWinLineView.getScoreViews();
        int visibleScoreViews = 0;
        for (View scoreView : scoreViews) {
            if (scoreView.isVisible()) {
                visibleScoreViews++;
            }
        }

        assertTrue(visibleScoreViews == scoreViewsAmount);
    }

    /**
     * Tests whether scatter win line is properly shown when no score boxes were added.
     */
    @Test
    public void shouldShowWinWithoutScoreBox() {
        //GIVEN
        //set views
        addViews(15, ScatterWinLineView.FRAME_TAG);

        //WHEN
        scatterWinLineView.setState(WinLineState.SHOWN_WINNING);
        List<Integer> winPositions = new ArrayList<>(Arrays.asList(0, 1, 0, 1, 2));
        scatterWinLineView.setWinLineInfo(new WinLineInfo(0, "WinCount0", "Short", BigDecimal.valueOf(10), winPositions));

        //THEN
        scatterWinLineView.showWin(scatterWinLineView.getWinLineInfo());

        //find all visible score views
        List<View> scoreViews = scatterWinLineView.getScoreViews();
        int visibleScoreViews = 0;
        for (View scoreView : scoreViews) {
            if (scoreView.isVisible()) {
                visibleScoreViews++;
            }
        }

        assertTrue(visibleScoreViews == 0);
    }

    /**
     * Adds views to be shown by renderer
     * @param viewsAmount An amount of views to be added to view group
     * @param viewType    A tag name which defines type of the view
     */
    private void addViews(int viewsAmount, String viewType) {
        for (int i = 0; i < viewsAmount; i++) {
            View view = new RectangleShapeView(renderer);
            view.setTags(Arrays.asList(viewType));
            scatterWinLineView.addChild(view);
        }
    }

}
