package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.converter.ConversionException;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.model.ReelStripDefinition;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * Tests for {@link SymbolsConfigurationConverter} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class SymbolsConfigurationConverterTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * The serializer mock.
     */
    @Mock
    private IXmlSerializer serializerMock;

    /**
     * The view builder mock.
     */
    @Mock
    private IViewBuilder viewBuilderMock;

    /**
     * Tests whether symbols configuration is properly converted from xml.
     */
    @Test
    public void shouldCreateValidSymbolsConfigurationWhenConvertedFromValidXml() throws ConversionException, SerializationException, ParseException {
        // GIVEN
        SymbolsConfigurationConverter symbolsConfigurationConverter = new SymbolsConfigurationConverter(serializerMock, viewBuilderMock);
        XmlObject symbolsConfigurationXml = newSampleConfiguration(5, "Lemon", FixedSymbolPoolStrategy.class.getName());
        HashMap<String, Integer> symbolQuantities = new HashMap<>();
        symbolQuantities.put("Lemon", 5);
        ISymbolPoolStrategy strategy = new FixedSymbolPoolStrategy();
        when(serializerMock.deserialize(any(XmlObject.class), eq(FixedSymbolPoolStrategy.class.getName()))).thenReturn(strategy);
        AbstractSymbol symbol = SymbolUtility.newSymbolMock("Lemon");
        when(viewBuilderMock.createView(any(XmlObject.class), anyBoolean())).thenReturn(symbol);

        // WHEN
        ISymbolsConfiguration symbolsConfiguration = (ISymbolsConfiguration) symbolsConfigurationConverter.convertFrom("", symbolsConfigurationXml);

        // THEN
        assertEquals(5, symbolsConfiguration.getRowCount());
        assertNotNull(symbolsConfiguration.getSymbolAppending());
        assertNotNull(symbolsConfiguration.getSymbolPool());
    }

    /**
     * Tests whether the converted properly handles symbols which cannot be instantiated.
     */
    @Test
    public void shouldThrowConversionErrorWhenViewCannotBeCreated() throws ConversionException, ParseException, SerializationException {
        // GIVEN
        SymbolsConfigurationConverter symbolsConfigurationConverter = new SymbolsConfigurationConverter(serializerMock, viewBuilderMock);
        XmlObject symbolsConfigurationXml = newSampleConfiguration(5, "Lemon", FixedSymbolPoolStrategy.class.getName());
        ReelStripDefinition reelStripDefinition = new ReelStripDefinition();
        reelStripDefinition.setType("BASEGAME");
        reelStripDefinition.setReelStripList(Arrays.asList("Lemon"));
        when(serializerMock.deserialize(anyString(), eq(ReelStripDefinition[].class))).thenReturn(Arrays.asList(reelStripDefinition));
        when(viewBuilderMock.createView(any(XmlObject.class), anyBoolean())).thenThrow(new SerializationException());

        // WHEN
        exception.expect(ConversionException.class);
        symbolsConfigurationConverter.convertFrom("", symbolsConfigurationXml);
    }

    /**
     * Tests whether the configuration converted handles nulls properly.
     */
    @Test
    public void shouldReturnNullWhenSerializedMessageIsNull() throws ConversionException {
        // GIVEN
        SymbolsConfigurationConverter symbolsConfigurationConverter = new SymbolsConfigurationConverter(serializerMock, viewBuilderMock);

        // WHEN
        Object answer = symbolsConfigurationConverter.convertFrom(null, null);

        // THEN
        assertNull(answer);
    }

    /**
     * Creates a new sample configuration.
     */
    private static XmlObject newSampleConfiguration(int rowCount, String symbolName, String strategyClass) {
        return new XmlBuilder().startElement("symbolsConfiguration").startElement("symbols").startElement("poolDefinition")
                .writeAttribute("poolInitializationStrategyClass", strategyClass).startElement("fixedSymbolCount").writeValue("5").endElement().endElement()
                .startElement("symbolsDefinition").startElement("SymbolView").writeAttribute("name", symbolName).endElement().endElement().endElement()
                .startElement("rowCount").writeValue(rowCount).endElement().endElement().toXmlObject();
    }
}
