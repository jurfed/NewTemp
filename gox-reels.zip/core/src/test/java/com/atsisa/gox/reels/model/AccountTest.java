package com.atsisa.gox.reels.model;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.atsisa.gox.reels.event.BalanceChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;

/**
 * Tests for {@link Account} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountTest {

    private static final String PRESENTATION_NAME = "PRESENTATION_NAME";

    /**
     * Transaction history length.
     */
    private static final int TRANSACTION_HISTORY_LENGTH = 5;

    /**
     * Event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger loggerMock;

    /**
     * Credits formatter mock.
     */
    @Mock
    private ICreditsFormatter creditsFormatterMock;

    /**
     * Game configuration mock.
     */
    @Mock
    private GameConfiguration gameConfigurationMock;

    /**
     * Language info mock.
     */
    @Mock
    private LanguageInfo languageInfoMock;

    /**
     * Balance changed event captor.
     */
    @Captor
    private ArgumentCaptor<BalanceChangedEvent> balanceChangedCaptor;

    /**
     * Tested account.
     */
    private Account account;

    /**
     * Called before each tests.
     */
    @Before
    public void setUp() {
        account = new Account(eventBusMock, loggerMock, creditsFormatterMock);
    }

    /**
     * Tests whether the event about balance changed is sent when response with info about that came.
     */
    @Test
    public void shouldUpdateBalanceWhenResponseWithInfoAboutThatCame() {
        // GIVEN
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(1000));

        // WHEN
        account.handleReelGamePresentation(reelGamePresentation);

        // THEN
        BigDecimal expectedBalance = reelGamePresentation.getGameplayProperties().getCreditAmount();
        assertEquals(expectedBalance, account.getBalance());
        assertEquals(expectedBalance, account.getPendingBalance());
        assertEquals(0, Iterables.size(account.getTransactionHistory()));
        verify(eventBusMock).post(balanceChangedCaptor.capture());
        assertEquals(expectedBalance, balanceChangedCaptor.getValue().getBalance());
    }

    /**
     * Tests whether the account handles win response properly.
     */
    @Test
    public void shouldUpdateBalanceAndTransactionHistoryWhenWinResponseCame() {
        // GIVEN
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(1000));
        account.handleReelGamePresentation(reelGamePresentation);
        reset(eventBusMock);

        GameplayProperties gameplayProperties = new GameplayProperties(1, BigDecimal.valueOf(1), BigDecimal.valueOf(1100));
        ReelGamePresentation presentation = new ReelGamePresentation(PRESENTATION_NAME, gameplayProperties, Collections.emptyList(), false, false);

        // WHEN
        account.handleReelGamePresentation(presentation);

        // THEN
        assertEquals(BigDecimal.valueOf(100), Iterables.getFirst(account.getTransactionHistory(), null));
        assertEquals(BigDecimal.valueOf(1000), account.getBalance());
        assertEquals(BigDecimal.valueOf(1100), account.getPendingBalance());
        verify(eventBusMock, never()).post(any(BalanceChangedEvent.class));
    }

    /**
     * Tests whether the account handles transferring credits properly.
     */
    @Test
    public void shouldTransferCreditsWhenProperEventCame() {
        // GIVEN
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(1000));
        account.handleReelGamePresentation(reelGamePresentation);
        reset(eventBusMock);
        TransferCreditsCommand transferCreditsCommand = new TransferCreditsCommand(BigDecimal.valueOf(100));

        // WHEN
        account.handleTransferCreditsCommand(transferCreditsCommand);

        // THEN
        assertEquals(0, Iterables.size(account.getTransactionHistory()));
        assertEquals(BigDecimal.valueOf(1100), account.getBalance());
        assertEquals(BigDecimal.valueOf(1000), account.getPendingBalance());
        verify(eventBusMock).post(balanceChangedCaptor.capture());
        assertEquals(BigDecimal.valueOf(1100), balanceChangedCaptor.getValue().getBalance());
    }

    /**
     * Tests whether the account disallows debit.
     */
    @Test
    public void shouldDisallowDebit() {
        // GIVEN
        ReelGamePresentation reelGamePresentation = createReelGamePresentation(BigDecimal.valueOf(100));
        account.handleReelGamePresentation(reelGamePresentation);
        reset(eventBusMock);
        TransferCreditsCommand transferCreditsCommand = new TransferCreditsCommand(BigDecimal.valueOf(-101));

        // WHEN
        account.handleTransferCreditsCommand(transferCreditsCommand);

        // THEN
        assertEquals(0, Iterables.size(account.getTransactionHistory()));
        assertEquals(BigDecimal.valueOf(100), account.getBalance());
        assertEquals(BigDecimal.valueOf(100), account.getPendingBalance());
        verify(eventBusMock, never()).post(any(BalanceChangedEvent.class));
    }

    /**
     * Tests whether the account keeps limit of the transaction history.
     */
    @Test
    public void shouldKeepLimitOfTransactionHistoryWhenMultiplePresentationResponsesCame() {
        // GIVEN
        InitResult initResult = createInitResult();
        account.handleInitResult(initResult);

        // WHEN
        for (int index = 0; index <= TRANSACTION_HISTORY_LENGTH; index++) {
            GameplayProperties gameplayProperties = new GameplayProperties(1, BigDecimal.valueOf(1), BigDecimal.valueOf((index + 1) * 100));
            ReelGamePresentation presentation = new ReelGamePresentation(PRESENTATION_NAME, gameplayProperties, Collections.emptyList(), false, false);
            account.handleReelGamePresentation(presentation);
        }

        // THEN
        assertEquals(TRANSACTION_HISTORY_LENGTH, Iterables.size(account.getTransactionHistory()));
        BigDecimal oldestTransaction = Iterables.getLast(account.getTransactionHistory(), null);
        assertEquals(new BigDecimal(100), oldestTransaction);
    }

    /**
     * Creates an init result.
     * @return the init result
     */
    private InitResult createInitResult() {
        return new InitResult(gameConfigurationMock, languageInfoMock);
    }

    /**
     * Creates and returns the reel game presentation.
     * @param credits the credits amount
     * @return the reel game presentation
     */
    private ReelGamePresentation createReelGamePresentation(BigDecimal credits) {
        GameplayProperties gameplayProperties = new GameplayProperties(1, BigDecimal.valueOf(1), credits);
        return new ReelGamePresentation(PRESENTATION_NAME, gameplayProperties, Collections.emptyList(), false, false);
    }
}

