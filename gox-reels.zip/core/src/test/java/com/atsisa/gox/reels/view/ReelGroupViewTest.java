package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.primitive.ExtendedIntViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.reels.view.spi.IHideSymbolAnimationsStrategy;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.logic.model.WinLineInfo;
import com.atsisa.gox.reels.view.spi.IReelSequenceProvider;
import com.atsisa.gox.reels.view.spi.IShowSymbolAnimationsStrategy;
import com.atsisa.gox.reels.view.state.ReelGroupState;
import com.atsisa.gox.reels.view.state.ReelState;

import rx.Observable;
import rx.observers.TestSubscriber;
import rx.subjects.PublishSubject;

/**
 * Unit test for {@link ReelGroupView}.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReelGroupViewTest {

    /**
     * Exceptions rule.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Tested reel group view class.
     */
    private ReelGroupView reelGroupView;

    /**
     * List with mocked reels.
     */
    private List<AbstractReel> reels;

    /**
     * Mocked renderer.
     */
    @Mock
    private IRenderer renderer;

    /**
     * Mocked reel sequence provider.
     */
    @Mock
    private IReelSequenceProvider reelSequenceProvider;

    /**
     * Mocked show symbol animations strategy
     */
    @Mock
    private IShowSymbolAnimationsStrategy showSymbolAnimationsStrategy;

    /**
     * Mocked hide symbol animations strategy
     */
    @Mock
    private IHideSymbolAnimationsStrategy hideSymbolAnimationsStrategy;

    /**
     * Correct collection with stopping symbol names for tests.
     */
    private List<Iterable<String>> correctStopSymbolNames;

    /**
     * Observable for the show/hide symbol animations.
     */
    private PublishSubject<IReelGroup> showHideSymbolAnimationsObservable;

    /**
     * Called before each test.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        when(reelSequenceProvider.createSequence(any(Iterable.class))).thenAnswer(new Answer<Observable<IReel>>() {

            @Override
            public Observable<IReel> answer(InvocationOnMock invocationOnMock) throws Throwable {
                Object[] args = invocationOnMock.getArguments();
                Iterable<IReel> items = (Iterable<IReel>) args[0];
                return Observable.from(items);
            }
        });

        showHideSymbolAnimationsObservable = PublishSubject.create();
        when(showSymbolAnimationsStrategy.showAnimations(any(), any())).thenReturn(showHideSymbolAnimationsObservable);
        when(hideSymbolAnimationsStrategy.hideAnimations(any())).thenReturn(showHideSymbolAnimationsObservable);

        correctStopSymbolNames = new ArrayList<>();
        reels = new ArrayList<>();

        for (int i = 0; i < 4; ++i) {
            AbstractReel abstractReel = mock(AbstractReel.class);
            reels.add(abstractReel);
            when(abstractReel.interactive()).thenReturn(mock(IObservableProperty.class));

            when(abstractReel.depth()).thenReturn(mock(ExtendedIntViewProperty.class));
            PublishSubject<ReelState> observable = PublishSubject.create();
            when(abstractReel.getReelStateObservable()).thenReturn(observable);

            correctStopSymbolNames.add(new ArrayList<>());
        }

        reelGroupView = new ReelGroupView(renderer);
        reelGroupView.setReels(reels);
        reelGroupView.setSpinSequenceProvider(reelSequenceProvider);
        reelGroupView.setForceStopOnSymbolsSequenceProvider(reelSequenceProvider);
        reelGroupView.setStopOnSymbolsSequenceProvider(reelSequenceProvider);
        reelGroupView.setShowSymbolAnimationsStrategy(showSymbolAnimationsStrategy);
        reelGroupView.setHideSymbolAnimationsStrategy(hideSymbolAnimationsStrategy);
    }

    /**
     * Tests whether an exception is thrown while getting reel but reels are not set.
     */
    @Test
    public void shouldThrowExceptionWhileGettingReelButReelsAreNotSet() {
        //GIVEN
        ReelGroupView testingReelGroupView = new ReelGroupView(renderer);

        //THEN
        exception.expect(IndexOutOfBoundsException.class);
        testingReelGroupView.getReel(1);
    }

    /**
     * Tests whether an exception is thrown while getting reel at non-existent index.
     */
    @Test
    public void shouldThrowExceptionWhileGettingReelWhenThereAreNoReelAtSpecificIndexPosition() {
        //THEN
        exception.expect(IndexOutOfBoundsException.class);
        reelGroupView.getReel(5);
    }

    /**
     * Tests whether the state has changed from idle to spinning after the spin was called.
     */
    @Test
    public void shouldChangeStateToSpinningAfterSpinWasCalledAndPreviousStateWasIdle() {
        //GIVEN
        ReelGroupState previousReelGroupState = reelGroupView.getReelGroupState();

        //WHEN
        reelGroupView.spin();

        //THEN
        assertEquals(ReelGroupState.IDLE, previousReelGroupState);
        assertEquals(ReelGroupState.SPINNING, reelGroupView.getReelGroupState());
    }

    /**
     * Tests whether an exception is thrown after spin was called and reels are not set.
     */
    @Test
    public void shouldThrowExceptionAfterSpinWasCalledAndReelsAreNotSet() {
        //GIVEN
        ReelGroupView testingReelGroupView = new ReelGroupView(renderer);

        //THEN
        exception.expect(IllegalStateException.class);
        testingReelGroupView.spin();
    }

    /**
     * Tests whether an exception is thrown after spin was called and previous state was not idle.
     */
    @Test
    public void shouldThrowExceptionAfterSpinWasCalledAndPreviousStateWasNotIdle() {
        //GIVEN
        reelGroupView.spin();

        //THEN
        exception.expect(IllegalStateException.class);
        reelGroupView.spin();
    }

    /**
     * Tests whether spin is invoked on each reel after spin was called on group.
     */
    @Test
    public void shouldCallSpinOnEachReelAfterSpinWasCalled() {
        //THEN
        reelGroupView.spin();

        //THEN
        for (IReel reel : reels) {
            verify(reel, times(1)).spin();
        }
    }

    /**
     * Tests whether an exception is thrown after normal stop was called and reels are not set.
     */
    @Test
    public void shouldThrowExceptionAfterNormalStopWasCalledAndReelsAreNotSet() {
        //GIVEN
        List<Iterable<String>> stopPositions = new ArrayList<>();
        ReelGroupView testingReelGroupView = new ReelGroupView(renderer);

        //THEN
        exception.expect(IllegalStateException.class);
        testingReelGroupView.stopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after force stop was called and reels are not set.
     */
    @Test
    public void shouldThrowExceptionAfterForceStopWasCalledAndReelsAreNotSet() {
        //GIVEN
        List<Iterable<String>> stopPositions = new ArrayList<>();
        ReelGroupView testingReelGroupView = new ReelGroupView(renderer);

        //THEN
        exception.expect(IllegalStateException.class);
        testingReelGroupView.forceStopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after stop on symbols was called and symbol names are null.
     */
    @Test
    public void shouldThrowExceptionAfterNormalStopWasCalledAndSymbolNamesAreNull() {
        //GIVEN
        List<Iterable<String>> stopPositions = null;

        //THEN
        exception.expect(IllegalArgumentException.class);
        reelGroupView.stopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after force stop was called and symbol names are null.
     */
    @Test
    public void shouldThrowExceptionAfterForceStopWasCalledAndSymbolNamesAreNull() {
        //GIVEN
        List<Iterable<String>> stopPositions = null;

        //THEN
        exception.expect(IllegalArgumentException.class);
        reelGroupView.forceStopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after normal stop was called and there is more symbol names than reels.
     */
    @Test
    public void shouldThrowExceptionAfterNormalStopWasCalledAndThereIsMoreSymbolNamesThanReels() {
        //GIVEN
        List<String> symbolNames = new ArrayList<>();
        List<Iterable<String>> stopPositions = new ArrayList<>();
        stopPositions.add(symbolNames);
        stopPositions.add(symbolNames);
        stopPositions.add(symbolNames);
        stopPositions.add(symbolNames);
        stopPositions.add(symbolNames);

        //THEN
        exception.expect(IllegalArgumentException.class);
        reelGroupView.stopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after force stop was called and there is less symbol names than reels.
     */
    @Test
    public void shouldThrowExceptionAfterForceStopWasCalledAndThereIsLessSymbolNamesThanReels() {
        //GIVEN
        List<String> symbolNames = new ArrayList<>();
        List<Iterable<String>> stopPositions = new ArrayList<>();
        stopPositions.add(symbolNames);

        //THEN
        exception.expect(IllegalArgumentException.class);
        reelGroupView.stopOnSymbols(stopPositions);
    }

    /**
     * Tests whether an exception is thrown after normal stop was called and reel group is already in stopping state.
     */
    @Test
    public void shouldThrowExceptionAfterNormalStopWasCalledAndReelGroupIsAlreadyInStoppingState() {
        //WHEN
        reelGroupView.spin();
        reelGroupView.stopOnSymbols(correctStopSymbolNames);

        //THEN
        exception.expect(IllegalStateException.class);
        reelGroupView.stopOnSymbols(correctStopSymbolNames);
    }

    /**
     * Tests whether state does not change if stop or force stop is called and current state is idle.
     */
    @Test
    public void shouldNotChangeStateToStoppingIfCurrentStateIsIdle() {
        //GIVEN
        ReelGroupState expectedState = ReelGroupState.IDLE;

        //WHEN
        reelGroupView.stopOnSymbols(correctStopSymbolNames);
        reelGroupView.forceStopOnSymbols(correctStopSymbolNames);

        //THEN
        assertEquals(expectedState, reelGroupView.getReelGroupState());
    }

    /**
     * Tests whether an exception is not thrown after force stop on symbols was called right after normal stop was called.
     */
    @Test
    public void shouldDoNotThrowExceptionIfForceStopWasCalledRightAfterNormalStop() {
        //WHEN
        reelGroupView.stopOnSymbols(correctStopSymbolNames);

        //THEN
        try {
            reelGroupView.forceStopOnSymbols(correctStopSymbolNames);
        } catch (Exception e) {
            fail("Should not have throw any exception");
        }
    }

    /**
     * Tests whether stop is called on each reel if stop on symbols was called.
     */
    @Test
    public void shouldCallStopOnEachReelIfStopOnSymbolsWasCalled() {
        //WHEN
        reelGroupView.stopOnSymbols(correctStopSymbolNames);

        //THEN
        for (IReel reel : reels) {
            verify(reel, times(1)).stopOnSymbols(any(Iterable.class));
        }
    }

    /**
     * Tests whether force stop on symbols is invoked on each reel if force stop on symbols was called on group.
     */
    @Test
    public void shouldCallForceStopOnEachReelAfterForceStopOnSymbolsWasCalled() {
        //WHEN
        reelGroupView.forceStopOnSymbols(correctStopSymbolNames);

        //THEN
        for (IReel reel : reels) {
            verify(reel, times(1)).forceStopOnSymbols(any(Iterable.class));
        }
    }

    /**
     * Tests whether the state is changed from stopping to idle,
     * if in all reels state has been changed from stopping to idle.
     */
    @Test
    public void shouldChangeStateToIdleFromStoppingIfInAllReelsStateWillChangeToIdle() {
        //GIVEN
        ReelGroupState stateAfterStopOnSymbols;

        //WHEN
        reelGroupView.spin();
        reelGroupView.stopOnSymbols(correctStopSymbolNames);
        stateAfterStopOnSymbols = reelGroupView.getReelGroupState();
        for (IReel reel : reels) {
            ((PublishSubject) reel.getReelStateObservable()).onNext(ReelState.IDLE);
        }

        //THEN
        assertEquals(ReelGroupState.IDLE, reelGroupView.getReelGroupState());
        assertEquals(ReelGroupState.STOPPING, stateAfterStopOnSymbols);
    }

    /**
     * Tests whether state does not change from stopping to any other if any reel is in stopping state.
     */
    @Test
    public void shouldDoNotChangeStateFromStoppingToAnyOtherIfAnyReelIsInStoppingState() {
        //GIVEN
        IReel firstReel = null;
        for (IReel reel : reels) {
            if (firstReel == null) {
                firstReel = reel;
                when(reel.getReelState()).thenReturn(ReelState.STOPPING);
            } else {
                when(reel.getReelState()).thenReturn(ReelState.SPINNING);
            }
        }

        //WHEN
        reelGroupView.spin();
        ((PublishSubject) firstReel.getReelStateObservable()).onNext(ReelState.STOPPING);

        //THEN
        assertEquals(ReelGroupState.STOPPING, reelGroupView.getReelGroupState());
    }

    /**
     * Tests whether an exception is thrown when new reels are set but current reel group state is not idle.
     */
    @Test
    public void shouldThrowExceptionIfNewReelsAreSetButReelGroupStateIsNotIdle() {
        //GIVEN
        List<AbstractReel> newReels = new ArrayList<>();

        //WHEN
        reelGroupView.spin();

        //THEN
        exception.expect(IllegalStateException.class);
        reelGroupView.setReels(newReels);
    }

    /**
     * Tests whether an exception is thrown when reel group is not in idle state and show winning symbols was called.
     */
    @Test
    public void shouldThrowExceptionIfReelGroupIsNotIdleStateAndShowWinningSymbolsWasCalled() {
        //WHEN
        reelGroupView.spin();

        //THEN
        exception.expect(IllegalStateException.class);
        reelGroupView.showWinningSymbols(Arrays.asList(mock(IWinLineInfo.class), mock(IWinLineInfo.class)));
    }

    /**
     * Tests whether state is changing according to the state of the symbol animations.
     */
    @Test
    public void shouldChangingStateAccordingToTheStateOfTheSymbolAnimations() {
        //GIVEN
        ReelGroupState beginState = reelGroupView.getReelGroupState();
        ReelGroupState stateAfterSymbolAnimationsStartedShowing;
        String winningAnimationName = "winningAnimation";
        List<IWinLineInfo> winningLines = new ArrayList<>();
        WinLineInfo winningLine = mock(WinLineInfo.class);
        List<Integer> rows = new ArrayList<>();
        rows.add(1);
        rows.add(2);
        rows.add(0);
        rows.add(-1);
        int[] symbolCalledRows = new int[3];
        int[] expectedPositions = new int[] { 1, 2, 0 };
        when(winningLine.getPositions()).thenReturn(rows);
        when(winningLine.getAnimationName()).thenReturn(winningAnimationName);
        winningLines.add(winningLine);
        int symbolIndex;
        ArgumentCaptor<String> argumentCaptor;
        int reelIndex = 0;


        //WHEN
        reelGroupView.showWinningSymbols(Arrays.asList(mock(IWinLineInfo.class)));
        stateAfterSymbolAnimationsStartedShowing = reelGroupView.getReelGroupState();
        showHideSymbolAnimationsObservable.onCompleted();

        //THEN
        assertEquals(ReelGroupState.IDLE, beginState);
        assertEquals(ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS, stateAfterSymbolAnimationsStartedShowing);
        assertEquals(ReelGroupState.SHOWING_WINNING_SYMBOLS, reelGroupView.getReelGroupState());
    }

    /**
     * Tests whether symbol animations are shown immediately after force show winning symbols will be called.
     */
    @Test
    public void shouldImmediatelyShowSymbolAnimationsWhenForceShowWinningSymbolsWillBeCalled() {
        //WHEN
        reelGroupView.showWinningSymbols(Arrays.asList(mock(IWinLineInfo.class)));
        reelGroupView.terminateStartsShowingWinningSymbols();
        showHideSymbolAnimationsObservable.onCompleted();

        //THEN
        assertEquals(ReelGroupState.SHOWING_WINNING_SYMBOLS, reelGroupView.getReelGroupState());
        verify(showSymbolAnimationsStrategy, times(1)).terminate();
    }

    /**
     * Tests whether animations of all symbols are stopped when stop symbol animations method will be called.
     */
    @Test
    public void shouldStopAnimationsOfAllSymbolsAfterStopSymbolAnimationsWillBeCalled() {
        //GIVEN
        ReelGroupState stateAfterStartsHidingSymbols;
        reelGroupView.showWinningSymbols(Arrays.asList(mock(IWinLineInfo.class)));

        //WHEN
        reelGroupView.stopSymbolAnimations();
        stateAfterStartsHidingSymbols = reelGroupView.getReelGroupState();
        showHideSymbolAnimationsObservable.onCompleted();

        //THEN
        assertEquals(ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS, stateAfterStartsHidingSymbols);
        assertEquals(ReelGroupState.IDLE, reelGroupView.getReelGroupState());
        verify(hideSymbolAnimationsStrategy, times(1)).hideAnimations(reelGroupView);
    }

    /**
     * Tests whether animations of all symbols are force stopped when force stop symbol animations method will be called.
     */
    @Test
    public void shouldForceStopAnimationsOfAllSymbolsAfterForceStopSymbolAnimationsWillBeCalled() {
        //GIVEN
        reelGroupView.showWinningSymbols(Arrays.asList(mock(IWinLineInfo.class)));
        TestSubscriber<ReelGroupState> testSubscriber = new TestSubscriber<>();

        //WHEN
        reelGroupView.getReelGroupStateObservable().subscribe(testSubscriber);
        reelGroupView.forceStopSymbolAnimations();

        //THEN
        assertEquals(ReelGroupState.IDLE, reelGroupView.getReelGroupState());
        verify(hideSymbolAnimationsStrategy, times(1)).terminate();
        testSubscriber.assertValueCount(2);
        assertEquals(Arrays.asList(ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS, ReelGroupState.IDLE), testSubscriber.getOnNextEvents());
    }

}
