package com.atsisa.gox.reels.view;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.framework.view.spi.IViewActivator;
import com.atsisa.gox.reels.view.spi.IWinLineViewChildSelector;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * Defines tests for {@link WinLineView}.
 */
public class WinLineViewTest {

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Mock
    private IWinLineViewChildSelector winLineViewChildSelector;

    @Mock
    private IViewActivator viewActivator;

    @Mock
    private IRenderer renderer;

    /**
     * Sequence generator.
     */
    private int sequenceGenerator = 0;

    /**
     * Sets up sample child views.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(renderer.generateNextSequentialNumber()).then(new Answer<Integer>() {

            @Override
            public Integer answer(InvocationOnMock invocationOnMock) throws Throwable {
                return sequenceGenerator++;
            }
        });
    }

    /**
     * Tests whether all child views are initially deactivated.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldHaveProperViewsDeactivatedWhenInitialized() {
        // GIVEN
        View firstChild = newViewGroup();
        View secondChild = newViewGroup();
        WinLineView winLineView = new WinLineView(renderer);
        winLineView.setViewActivator(viewActivator);
        winLineView.setChildSelector(winLineViewChildSelector);
        when(winLineViewChildSelector.selectChildren(any(Iterable.class), eq(WinLineState.INACTIVE))).thenReturn(Arrays.asList(firstChild));
        winLineView.addChild(firstChild);
        winLineView.addChild(secondChild);

        // WHEN
        winLineView.redraw();

        // THEN
        verify(viewActivator, times(1)).activate(firstChild);
        verify(viewActivator, times(1)).deactivate(secondChild);
    }

    /**
     * Tests whether child views are properly activated/deactivated when win line state changes.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldToggleViewsWhenWinStateChanges() {
        // GIVEN
        WinLineView winLineView = new WinLineView(renderer);
        winLineView.addChild(newViewGroup());
        winLineView.addChild(newViewGroup());
        winLineView.setViewActivator(viewActivator);
        winLineView.setChildSelector(winLineViewChildSelector);
        View firstChild = newViewGroup();
        View secondChild = newViewGroup();
        when(winLineViewChildSelector.selectChildren(any(Iterable.class), eq(WinLineState.ACTIVE))).thenReturn(Arrays.asList(firstChild));
        when(winLineViewChildSelector.selectChildren(any(Iterable.class), eq(WinLineState.SHOWN))).thenReturn(Arrays.asList(secondChild));

        // WHEN
        winLineView.setState(WinLineState.ACTIVE);
        winLineView.setState(WinLineState.SHOWN);

        // THEN
        verify(viewActivator, times(1)).activate(firstChild);
        verify(viewActivator, times(1)).deactivate(firstChild);
        verify(viewActivator, times(1)).activate(secondChild);
        verify(viewActivator, never()).deactivate(secondChild);
    }

    /**
     * Tests whether same views are activated again on state chages.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldNotActivateViewTwiceWhenWinStateChanges() {
        // GIVEN
        View firstChild = newViewGroup();
        View secondChild = newViewGroup();
        WinLineView winLineView = new WinLineView(renderer);
        winLineView.setViewActivator(viewActivator);
        winLineView.setChildSelector(winLineViewChildSelector);
        when(winLineViewChildSelector.selectChildren(any(Iterable.class), eq(WinLineState.ACTIVE))).thenReturn(Arrays.asList(firstChild));
        when(winLineViewChildSelector.selectChildren(any(Iterable.class), eq(WinLineState.SHOWN))).thenReturn(Arrays.asList(firstChild, secondChild));
        winLineView.addChild(firstChild);
        winLineView.addChild(secondChild);

        // WHEN
        winLineView.setState(WinLineState.ACTIVE);
        winLineView.setState(WinLineState.SHOWN);

        // THEN
        verify(viewActivator, times(1)).activate(firstChild);
        verify(viewActivator, times(1)).activate(secondChild);
    }

    /**
     * Tests whether the class guards against null child selector.
     */
    @Test
    public void shouldThrowExceptionWhenNullChildSelector() {
        // GIVEN
        WinLineView winLineView = new WinLineView(renderer);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        winLineView.setChildSelector(null);
    }

    /**
     * Tests whether the class guards against null view selector.
     */
    @Test
    public void shouldThrowExceptionWhenNullViewActivator() {
        // GIVEN
        WinLineView winLineView = new WinLineView(renderer);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        winLineView.setViewActivator(null);
    }

    /**
     * Creates a new view group.
     * @return A new view group.
     */
    private ViewGroup newViewGroup() {
        return new ViewGroup(renderer);
    }
}
