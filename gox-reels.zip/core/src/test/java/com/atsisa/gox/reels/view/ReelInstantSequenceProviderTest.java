package com.atsisa.gox.reels.view;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import rx.Observable;
import rx.observers.TestSubscriber;

/**
 * Test for ReelInstantSequenceProviderTest class.
 */
public class ReelInstantSequenceProviderTest {

    private static final int TEST_REELS_COUNT = 5;

    TestSubscriber<IReel> testSubscriber;

    /**
     * Provider instance to test.
     */
    private ReelInstantSequenceProvider sequenceProvider;

    private List<IReel> reels;

    @Before
    public void setUp() {
        testSubscriber = new TestSubscriber<>();

        reels = new ArrayList<>(TEST_REELS_COUNT);
        for (int reelIndex = 0; reelIndex < TEST_REELS_COUNT; reelIndex++) {
            reels.add(mock(IReel.class));
        }
    }

    /**
     * Test verifies that sequence subscriber gets correct subscription in case.
     */
    @Test
    public void shouldSubscribeOnSimpleSequenceWhenDelaysCase0() {
        // GIVEN
        List<Integer> sequenceOrder = Arrays.asList(0, 1, 2, 3, 4);
        sequenceProvider = new ReelInstantSequenceProvider();
        Observable<IReel> sequence = sequenceProvider.createSequence(reels);

        // WHEN
        sequence.subscribe(testSubscriber);

        // THEN
        testSubscriber.assertNoErrors();
        testSubscriber.assertValueCount(5);
        testSubscriber.assertValues(reels.get(sequenceOrder.get(0)), reels.get(sequenceOrder.get(1)), reels.get(sequenceOrder.get(2)),
                reels.get(sequenceOrder.get(3)), reels.get(sequenceOrder.get(4)));
        testSubscriber.assertCompleted();
    }

}
