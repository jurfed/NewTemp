package com.atsisa.gox.reels.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.resource.AbstractTextResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.reels.exception.ReelStripDefinitionProviderException;

/**
 * Tests for {@link LocalResourceReelStripDefinitionProvider} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class LocalResourceReelStripDefinitionProviderTest {

    /**
     * Expected exception rule.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Reel strip definition provider.
     */
    private LocalResourceReelStripDefinitionProvider reelStripDefinitionProvider;

    /**
     * Mocked resource manager.
     */
    @Mock
    private IResourceManager resourceManager;

    /**
     * Mocked serializer.
     */
    @Mock
    private IXmlSerializer serializer;

    /**
     * Mocked reel strip definition.
     */
    @Mock
    private ReelStripDefinition testReelStripDefinition;

    /**
     * Called before each test.
     */
    @Before
    public void setupUp() {
        MockitoAnnotations.initMocks(this);

        List<String> resourcesId = new ArrayList<>();
        resourcesId.add("resource1");

        AbstractTextResource textResource1 = mock(AbstractTextResource.class);
        when(textResource1.getText()).thenReturn("textResource1");
        when(resourceManager.getResource("resource1", ResourceType.TEXT)).thenReturn(textResource1);
        when(testReelStripDefinition.getReelNumber()).thenReturn(1);
        when(testReelStripDefinition.getType()).thenReturn("BaseGame");

        List<ReelStripDefinition> reelStripDefinitions = new ArrayList<>();
        reelStripDefinitions.add(testReelStripDefinition);
        try {
            when(serializer.deserialize("textResource1", ReelStripDefinition[].class)).thenReturn(reelStripDefinitions);
        } catch (SerializationException ex) {
            ex.printStackTrace();
        }
        reelStripDefinitionProvider = LocalResourceReelStripDefinitionProvider.newReelStripDefinitionProvider(resourcesId, resourceManager, serializer);
    }

    /**
     * Tests whether correct reel strip definitions are returned for specific type if there are in the resources.
     */
    @Test
    public void shouldReturnReelStripDefinitionsForSpecificTypeIfThereAreInResources() {
        //GIVEN
        String reelStripType = "BaseGame";
        int expectedReelStripeDefinitionsCount = 1;

        //WHEN
        Iterable<ReelStripDefinition> reelStripDefinitions = reelStripDefinitionProvider.getReelStripDefinitions(reelStripType);

        //THEN
        assertEquals(expectedReelStripeDefinitionsCount, Iterables.size(reelStripDefinitions));
        ReelStripDefinition reelStripDefinition = reelStripDefinitions.iterator().next();
        assertEquals(testReelStripDefinition, reelStripDefinition);
    }

    /**
     * Tests whether null is returned for specific type if it does not exist in the resources.
     */
    @Test
    public void shouldReturnNullForSpecificTypeIfItDoesNotExistInResources() {
        //GIVEN
        String reelStripType = "BaseGame2";

        //WHEN
        Iterable<ReelStripDefinition> reelStripDefinitions = reelStripDefinitionProvider.getReelStripDefinitions(reelStripType);

        //THEN
        assertNull(reelStripDefinitions);
    }

    /**
     * Tests whether exception it is thrown when parameters for constructor are incorrect.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldThrowExceptionIfTheInputParametersForConstructorAreIncorrect() {
        //GIVEN
        List<String> resourcesId = new ArrayList<>();
        resourcesId.add("resource1");
        try {
            when(serializer.deserialize("textResource1", ReelStripDefinition[].class)).thenThrow(SerializationException.class);
        } catch (SerializationException ex) {
            ex.printStackTrace();
        }

        //THEN
        exception.expect(ReelStripDefinitionProviderException.class);
        LocalResourceReelStripDefinitionProvider.newReelStripDefinitionProvider(resourcesId, resourceManager, serializer);
    }

    /**
     * Tests whether correct reel strip definition is returned for specific reel number and
     * type if it exist in resources.
     */
    @Test
    public void shouldReturnCorrectReelStripDefinitionForSpecificReelAndTypeIfItExistInResource() {
        //GIVEN
        String reelStripType = "BaseGame";
        int reelNumber = 1;

        //WHEN
        ReelStripDefinition reelStripDefinition = reelStripDefinitionProvider.getReelStripDefinition(reelStripType, reelNumber);

        //THEN
        assertEquals(testReelStripDefinition, reelStripDefinition);
    }

}
