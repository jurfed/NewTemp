package com.atsisa.gox.reels.view;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * Tests form {@link FixedSymbolPoolStrategy} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class FixedSymbolPoolStrategyTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Symbol factory mock.
     */
    @Mock
    private ISymbolFactory symbolFactoryMock;

    /**
     * Symbol pool mock.
     */
    @Mock
    private ISymbolPool symbolPoolMock;

    /**
     * Tests whether the strategy disallows missing symbol creation.
     */
    @Test
    public void shouldFailWhenMissingSymbolIsRequested() {
        // GIVEN
        ISymbolPoolStrategy strategy = new FixedSymbolPoolStrategy(new HashMap<>());

        // WHEN
        exception.expect(SymbolPoolException.class);
        strategy.getMissingSymbol(symbolPoolMock, "MissingOne");
    }

    /**
     * Tests whether proper quantities are created on initialization.
     */
    @Test
    public void shouldCreateSymbolsWithProperQuantitiesWhenInitialized() {
        // GIVEN
        Map<String, Integer> quantities = new HashMap<>();
        quantities.put("Cherry", 2);
        quantities.put("Lemon", 1);
        AbstractSymbol cherrySymbol = SymbolUtility.newSymbolMock("Cherry");
        AbstractSymbol lemonSymbol = SymbolUtility.newSymbolMock("Lemon");

        when(symbolFactoryMock.createSymbol(eq("Cherry"))).thenReturn(cherrySymbol);
        when(symbolFactoryMock.createSymbol(eq("Lemon"))).thenReturn(lemonSymbol);
        ISymbolPoolStrategy strategy = new FixedSymbolPoolStrategy(quantities);

        // WHEN
        Iterable<AbstractSymbol> symbols = strategy.initialize(symbolFactoryMock);

        // THEN
        assertEquals(2, SymbolUtility.getSymbolsByName(symbols, "Cherry").size());
        assertEquals(1, SymbolUtility.getSymbolsByName(symbols, "Lemon").size());
        verify(symbolFactoryMock, times(2)).createSymbol(eq("Cherry"));
        verify(symbolFactoryMock, times(1)).createSymbol(eq("Lemon"));
    }
}