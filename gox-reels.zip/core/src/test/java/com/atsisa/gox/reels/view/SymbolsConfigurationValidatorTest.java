package com.atsisa.gox.reels.view;

import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.atsisa.gox.reels.configuration.SymbolsConfiguration;
import com.atsisa.gox.reels.view.spi.ISymbolAppendingStrategy;
import com.atsisa.gox.reels.view.spi.ISymbolPool;

/**
 * Tests for {@link SymbolsConfigurationValidator} class.
 */
public class SymbolsConfigurationValidatorTest {

    /**
     * The symbols configuration.
     */
    private SymbolsConfiguration configuration;

    /**
     * The symbols configuration validator.
     */
    private SymbolsConfigurationValidator validator;

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Sets up the sample configuration.
     */
    @Before
    public void setUp() throws Exception {
        configuration = getSampleSymbolsConfiguration(300, 4);
        validator = new SymbolsConfigurationValidator();
    }

    /**
     * Tests whether the validator discards null configuration.
     */
    @Test
    public void shouldDiscardNullConfiguration() {
        // GIVEN
        configuration = null;

        // WHEN
        exception.expect(IllegalArgumentException.class);
        validator.validateConfiguration(configuration);
    }

    /**
     * Tests whether the validator discards null symbol pool.
     */
    @Test
    public void shouldDiscardNullSymbolPool() {
        // GIVEN
        configuration.setSymbolPool(null);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        validator.validateConfiguration(configuration);
    }

    /**
     * Tests whether the validator discards null symbol appending strategy.
     */
    @Test
    public void shouldDiscardNullSymbolAppending() {
        // GIVEN
        configuration.setSymbolAppending(null);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        validator.validateConfiguration(configuration);
    }

    /**
     * Tests whether the validator discards zero row count.
     */
    @Test
    public void shouldDiscardZeroRowCount() {
        // GIVEN
        configuration.setRowCount(0);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        validator.validateConfiguration(configuration);
    }

    /**
     * Tests whether the validator discards zero symbol height.
     */
    @Test
    public void shouldDiscardZeroSymbolHeight() {
        // GIVEN
        configuration.setSymbolHeight(0);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        validator.validateConfiguration(configuration);
    }

    /**
     * Tests whether the validator accepts valid configuration.
     */
    @Test
    public void shouldAcceptValidConfiguration() {
        // WHEN
        validator.validateConfiguration(configuration);
    }

    /**
     * Creates a sample symbols configuration.
     * @param symbolHeight The symbol height.
     * @param rowCount     The row count.
     * @return A valid symbol configuration.
     */
    private SymbolsConfiguration getSampleSymbolsConfiguration(int symbolHeight, int rowCount) {
        SymbolsConfiguration symbolsConfiguration = new SymbolsConfiguration();
        symbolsConfiguration.setSymbolHeight(symbolHeight);
        symbolsConfiguration.setRowCount(rowCount);
        symbolsConfiguration.setSymbolAppending(mock(ISymbolAppendingStrategy.class));
        symbolsConfiguration.setSymbolPool(mock(ISymbolPool.class));
        return symbolsConfiguration;
    }
}
