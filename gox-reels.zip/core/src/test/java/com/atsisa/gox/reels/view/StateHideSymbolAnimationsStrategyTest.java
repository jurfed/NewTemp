package com.atsisa.gox.reels.view;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

/**
 * Tests for {@link StateShowSymbolAnimationsStrategy}
 */
public class StateHideSymbolAnimationsStrategyTest {

    /**
     * Name of the default symbol state.
     */
    private static final String DEFAULT_SYMBOL_STATE = "DEFAULT_STATE";

    /**
     * Tested state symbol animations strategy class.
     */
    private StateHideSymbolAnimationsStrategy stateHideSymbolAnimationsStrategy;

    /**
     * Mocked reel group reference.
     */
    @Mock
    private IReelGroup reelGroup;

    /**
     * List with mocked reels.
     */
    private List<AbstractReel> reels;

    /**
     * Called before each test.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        reels = new ArrayList<>();

        for (int i = 0; i < 4; ++i) {
            List<AbstractSymbol> symbols = new ArrayList<>();
            symbols.add(createSymbol());
            symbols.add(createSymbol());
            symbols.add(createSymbol());

            AbstractReel abstractReel = mock(AbstractReel.class);
            when(abstractReel.getDisplayedSymbols()).thenReturn(symbols);
            reels.add(abstractReel);
        }
        when(reelGroup.getReels()).thenReturn(reels);
        when(reelGroup.getReel(anyInt())).then(new Answer<IReel>() {

            @Override
            public IReel answer(InvocationOnMock invocation) throws Throwable {
                return reels.get((int) invocation.getArguments()[0]);
            }
        });

        stateHideSymbolAnimationsStrategy = new StateHideSymbolAnimationsStrategy();
    }

    /**
     * Tests whether animation on each symbol will be stopped if method hide animations will be called.
     */
    @Test
    public void shouldStopAnimationInEachSymbolAfterHideAnimationsWillBeCalled() {
        //WHEN
        stateHideSymbolAnimationsStrategy.hideAnimations(reelGroup);

        //THEN
        for (IReel reel : reels) {
            Iterable<AbstractSymbol> symbols = reel.getDisplayedSymbols();
            for (AbstractSymbol abstractSymbol : symbols) {
                verify(abstractSymbol, times(1)).setState(DEFAULT_SYMBOL_STATE);
            }
        }
    }

    /**
     * Creates and returns new mocked symbol.
     * @return new symbol
     */
    private AbstractSymbol createSymbol() {
        AbstractSymbol abstractSymbol = mock(AbstractSymbol.class);
        when(abstractSymbol.getDefaultState()).thenReturn(DEFAULT_SYMBOL_STATE);
        return abstractSymbol;
    }

}
