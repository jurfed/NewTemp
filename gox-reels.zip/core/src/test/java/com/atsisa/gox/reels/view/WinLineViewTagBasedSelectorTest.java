package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.view.spi.IWinLineViewChildSelector;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * Defines tests for {@link WinLineViewTagBasedSelector}.
 */
public class WinLineViewTagBasedSelectorTest {

    /**
     * View mocks with assigned view tags.
     */
    private List<View> views = createViewsWithTags("indicator", "line", "");

    /**
     * Tests whether selector returns proper views in inactive line state.
     */
    @Test
    public void shouldReturnUntaggedViewsWhenInactiveState() {
        // GIVEN
        IWinLineViewChildSelector selector = new WinLineViewTagBasedSelector();
        WinLineState state = WinLineState.INACTIVE;

        // WHEN
        Iterable<View> result = selector.selectChildren(views, state);

        // THEN
        List<View> resultList = Iterables.toList(result);
        assertEquals(1, resultList.size());
        assertEquals(0, Iterables.size(resultList.get(0).getTags()));
    }

    /**
     * Tests whether selector returns proper views in active line state.
     */
    @Test
    public void shouldReturnIndicatorViewsWhenActiveState() {
        // GIVEN
        IWinLineViewChildSelector selector = new WinLineViewTagBasedSelector();
        WinLineState state = WinLineState.ACTIVE;

        // WHEN
        Iterable<View> result = selector.selectChildren(views, state);

        // THEN
        List<View> resultList = Iterables.toList(result);
        assertEquals(2, resultList.size());
        assertTrue(resultList.get(0).hasTag("indicator"));
        assertFalse(resultList.get(1).hasTags());
    }

    /**
     * Tests whether selector returns proper views in shown line state.
     */
    @Test
    public void shouldReturnIndicatorAndLineViewsWhenShownState() {
        // GIVEN
        IWinLineViewChildSelector selector = new WinLineViewTagBasedSelector();
        WinLineState state = WinLineState.SHOWN;

        // WHEN
        Iterable<View> result = selector.selectChildren(views, state);

        // THEN
        List<View> resultList = Iterables.toList(result);
        assertEquals(3, resultList.size());

        assertTrue(resultList.get(0).hasTag("indicator"));
        assertTrue(resultList.get(1).hasTag("line"));
        assertFalse(resultList.get(2).hasTags());
    }

    /**
     * Tests whether selector returns proper views when line state mappings are overridden.
     */
    @Test
    public void shouldReturnViewsWithCustomTagWhenStateMapOverridden() {
        // GIVEN
        Map<WinLineState, List<String>> stateMappings = new HashMap<>();
        stateMappings.put(WinLineState.ACTIVE, Arrays.asList("custom"));
        IWinLineViewChildSelector selector = new WinLineViewTagBasedSelector(stateMappings);
        WinLineState state = WinLineState.ACTIVE;
        views.addAll(createViewsWithTags("custom"));

        // WHEN
        Iterable<View> result = selector.selectChildren(views, state);

        // THEN
        List<View> resultList = Iterables.toList(result);
        assertEquals(2, resultList.size());
        assertFalse(resultList.get(0).hasTags());
        assertTrue(resultList.get(1).hasTag("custom"));
    }

    /**
     * Creates a list of views each of them has a unique tag name assigned.
     * @param tags View tags.
     * @return A list of views.
     */
    private static List<View> createViewsWithTags(String... tags) {
        IRenderer renderer = mock(IRenderer.class);
        List<View> mockViews = new ArrayList<>();
        for (String tag : tags) {
            View view = new ViewGroup(renderer);
            if (!StringUtility.isNullOrEmpty(tag)) {
                view.addTag(tag);
            }
            mockViews.add(view);
        }

        return mockViews;
    }
}
