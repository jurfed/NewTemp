package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.withSettings;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.model.property.primitive.ExtendedIntViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.spi.IStatefulViewChildFilter;

/**
 * Tests for {@link SymbolView} class.
 */
public class SymbolViewTests {

    /**
     * Symbol view.
     */
    private SymbolView symbolView;

    /**
     * Mocked select views for state selector.
     */
    @Mock
    private IStatefulViewChildFilter statefulViewChildFilter;

    /**
     * Called before each test.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        symbolView = new SymbolView(mock(IRenderer.class));
        statefulViewChildFilter = mock(IStatefulViewChildFilter.class);
        symbolView.setViewChildFilter(statefulViewChildFilter);
        symbolView.setState("ABC");
    }

    /**
     * Tests whether if child will be hidden after it will be added to the symbol view and it will not fit into its
     * current state.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldHideChildIfTheChildDoesNotFitIntoItsCurrentState() {
        // GIVEN
        View view = mock(View.class);
        when(view.depth()).thenReturn(mock(ExtendedIntViewProperty.class));
        when(statefulViewChildFilter.isValid(view, "ABC")).thenReturn(false);

        // WHEN
        symbolView.addChild(view);

        // THEN
        verify(view, times(1)).setVisible(false);
    }

    /**
     * Tests whether if child will be shown after it will be added to the symbol view and it will fits into its current
     * state.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldShowChildIfTheChildFitsIntoItsCurrentState() {
        // GIVEN
        View view = mock(View.class);
        when(view.depth()).thenReturn(mock(ExtendedIntViewProperty.class));
        when(statefulViewChildFilter.isValid(view, "ABC")).thenReturn(true);

        // WHEN
        symbolView.addChild(view);

        // THEN
        verify(view, times(1)).setVisible(true);
    }

    /**
     * Tests whether the correct children will be shown after state has been changed.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldUpdateVisibilityOfChildrenWhenTheStateIsChanged() {
        // GIVEN
        View viewOne = mock(View.class);
        ExtendedIntViewProperty viewOneDepth = mock(ExtendedIntViewProperty.class);
        when(viewOne.getDepth()).thenReturn(1);
        when(viewOne.depth()).thenReturn(viewOneDepth);
        View viewTwo = mock(View.class);
        ExtendedIntViewProperty viewTwoDepth = mock(ExtendedIntViewProperty.class);
        when(viewTwo.getDepth()).thenReturn(2);
        when(viewTwo.depth()).thenReturn(viewTwoDepth);
        View viewThree = mock(View.class);
        ExtendedIntViewProperty viewThreeDepth = mock(ExtendedIntViewProperty.class);
        when(viewThree.getDepth()).thenReturn(3);
        when(viewThree.depth()).thenReturn(viewThreeDepth);

        symbolView.addChild(viewOne);
        symbolView.addChild(viewTwo);
        symbolView.addChild(viewThree);
        when(statefulViewChildFilter.isValid(viewOne, "ABCD")).thenReturn(true);
        when(statefulViewChildFilter.isValid(viewThree, "ABCD")).thenReturn(true);
        when(statefulViewChildFilter.isValid(viewTwo, "ABCD")).thenReturn(false);

        // WHEN
        symbolView.setState("ABCD");

        // THEN
        ArgumentCaptor<Boolean> argumentCaptor = ArgumentCaptor.forClass(Boolean.class);
        verify(viewOne, times(2)).setVisible(argumentCaptor.capture());
        List<Boolean> values = argumentCaptor.getAllValues();
        assertTrue(values.contains(true));
        assertTrue(values.contains(false));
        argumentCaptor = ArgumentCaptor.forClass(Boolean.class);
        verify(viewThree, times(2)).setVisible(argumentCaptor.capture());
        values = argumentCaptor.getAllValues();
        assertTrue(values.contains(false));
        assertTrue(values.contains(true));
        argumentCaptor = ArgumentCaptor.forClass(Boolean.class);
        verify(viewTwo, times(2)).setVisible(argumentCaptor.capture());
        values = argumentCaptor.getAllValues();
        assertTrue(values.contains(false));
        assertTrue(values.contains(false));
    }

    /**
     * Tests whether the animation of the child will be stopped when this child is hidden.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldStopTheAnimationOnTheChildWhenItIsHiding() {
        // GIVEN
        View view = mock(View.class, withSettings().extraInterfaces(IViewAnimation.class));
        when(view.depth()).thenReturn(mock(ExtendedIntViewProperty.class));
        when(statefulViewChildFilter.isValid(view, "ABC")).thenReturn(false);

        // WHEN
        symbolView.addChild(view);

        // THEN
        verify((IViewAnimation) view, times(1)).stop();
    }

    /**
     * Tests whether the animation of the child will be activated when this child will be shown.
     */
    @Test
    @SuppressWarnings("unchecked")
    public void shouldPlayTheAnimationOnTheChildWhenItIsShown() {
        // GIVEN
        View view = mock(View.class, withSettings().extraInterfaces(IViewAnimation.class));
        when(view.depth()).thenReturn(mock(ExtendedIntViewProperty.class));
        when(statefulViewChildFilter.isValid(view, "ABC")).thenReturn(true);

        // WHEN
        symbolView.addChild(view);

        // THEN
        verify((IViewAnimation) view, times(1)).play();
    }

}
