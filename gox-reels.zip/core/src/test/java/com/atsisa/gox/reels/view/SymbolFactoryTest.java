package com.atsisa.gox.reels.view;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;

/**
 * Tests for {@link SymbolFactory} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class SymbolFactoryTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * View builder mock.
     */
    @Mock
    private IViewBuilder viewBuilderMock;

    /**
     * Tests whether input parameter is validated for nulls.
     */
    @Test
    public void shouldThrowExceptionWhenDefinitionIsNull() {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.addSymbolDefinition(null);
    }

    /**
     * Tests whether input parameter is validated for nulls.
     */
    @Test
    public void shouldThrowExceptionWhenViewBuilderReportsSerializationException() throws ParseException, SerializationException {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        when(viewBuilderMock.createView(eq(symbolDefintion), anyBoolean())).thenThrow(new SerializationException());

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.addSymbolDefinition(symbolDefintion);
    }

    /**
     * Tests whether input parameter is validated for nulls.
     */
    @Test
    public void shouldThrowExceptionWhenViewBuilderReportsParseException() throws ParseException, SerializationException {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        when(viewBuilderMock.createView(eq(symbolDefintion), anyBoolean())).thenThrow(new ParseException());

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.addSymbolDefinition(symbolDefintion);
    }

    /**
     * Tests whether input parameter is validated for nulls.
     */
    @Test
    public void shouldThrowExceptionWhenViewBuilderReportsClassCastException() throws ParseException, SerializationException {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        when(viewBuilderMock.createView(eq(symbolDefintion), anyBoolean())).thenThrow(new ClassCastException());

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.addSymbolDefinition(symbolDefintion);
    }

    /**
     * Tests whether input parameter is validated for duplicated entries.
     */
    @Test
    public void shouldThrowExceptionWhenDefinitionForGivenNameHasAlreadyBeenAdded() throws ParseException, SerializationException {
        // GIVEN
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        AbstractSymbol expectedSymbol = SymbolUtility.newSymbolMock("Lemon");
        when(viewBuilderMock.createView(eq(symbolDefintion), anyBoolean())).thenReturn(expectedSymbol);
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        symbolFactory.addSymbolDefinition(symbolDefintion);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.addSymbolDefinition(symbolDefintion);
    }

    /**
     * Tests whether an exception is thrown when the symbol is missing.
     */
    @Test
    public void shouldThrowExceptionWhenSymbolIsMissingInPrototypes() {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);

        // WHEN
        exception.expect(IllegalArgumentException.class);
        symbolFactory.createSymbol("MissingOne");
    }

    /**
     * Tests whether the factory incorporates verified symbols usage.
     */
    @Test
    public void shouldReturnVerifiedSymbolWhenTheSymbolIsRequestedForTheFirstTime() throws ParseException, SerializationException {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        AbstractSymbol expectedSymbol = SymbolUtility.newSymbolMock("Lemon");
        when(viewBuilderMock.createView(eq(symbolDefintion), anyBoolean())).thenReturn(expectedSymbol);
        symbolFactory.addSymbolDefinition(symbolDefintion);

        // WHEN
        AbstractSymbol symbol = symbolFactory.createSymbol("Lemon");

        // THEN
        verify(viewBuilderMock, times(1)).createView(eq(symbolDefintion), anyBoolean());
        assertTrue(expectedSymbol == symbol);
    }

    /**
     * Tests whether the factory incorporates verified symbols usage.
     */
    @Test
    public void shouldReturnNewSymbolWhenTheSymbolIsRequestedConsecutively() throws ParseException, SerializationException {
        // GIVEN
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilderMock);
        XmlObject symbolDefintion = SymbolUtility.newSymbolDefinition("Lemon");
        AbstractSymbol verifiedSymbol = SymbolUtility.newSymbolMock("Lemon");
        when(viewBuilderMock.createView(any(XmlObject.class), anyBoolean())).thenReturn(verifiedSymbol);
        symbolFactory.addSymbolDefinition(symbolDefintion);
        symbolFactory.createSymbol("Lemon");

        // WHEN
        symbolFactory.createSymbol("Lemon");

        // THEN
        verify(viewBuilderMock, times(2)).createView(eq(symbolDefintion), anyBoolean());
    }
}
