package com.atsisa.gox.reels.view;

import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * Tests form {@link DynamicSymbolPoolStrategy} class.
 */
public class DynamicSymbolPoolStrategyTest {

    /**
     * Expected exception.
     */
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    /**
     * Symbol factory mock.
     */
    @Mock
    private ISymbolFactory symbolFactoryMock;

    /**
     * Symbol pool mock.
     */
    @Mock
    private ISymbolPool symbolPoolMock;

    /**
     * Sets up mocks.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(symbolPoolMock.getSymbolFactory()).thenReturn(symbolFactoryMock);
    }

    /**
     * Tests whether the pool is initialized with an empty symbol list.
     */
    @Test
    public void shouldCreateEmptyPoolWhenInitialized() {
        // GIVEN
        ISymbolPoolStrategy strategy = new DynamicSymbolPoolStrategy();

        // WHEN
        Iterable<AbstractSymbol> initPool = strategy.initialize(symbolFactoryMock);

        // THEN
        assertFalse(initPool.iterator().hasNext());
    }

    /**
     * Tests whether the strategy delegates the creation of missing symbols to the factory.
     */
    @Test
    public void shouldUseFactoryWhenFetchingMissingSymbol() {
        // GIVEN
        final String missingSymbolName = "MissingOne";
        AbstractSymbol symbolFromFactory = SymbolUtility.newSymbolMock(missingSymbolName);
        when(symbolFactoryMock.createSymbol(eq(missingSymbolName))).thenReturn(symbolFromFactory);
        ISymbolPoolStrategy strategy = new DynamicSymbolPoolStrategy();

        // WHEN
        AbstractSymbol missingSymbol = strategy.getMissingSymbol(symbolPoolMock, missingSymbolName);

        // THEN
        assertTrue(missingSymbol == symbolFromFactory);
        verify(symbolFactoryMock).createSymbol(eq(missingSymbolName));
    }

    /**
     * Tests whether the strategy fails when the missing symbol limit is exceeded.
     */
    @Test
    public void shouldFailGettingMissingSymbolWhenLimitIsReached() {
        // GIVEN
        final String missingSymbolName = "MissingOne";
        final int limit = 1;
        ISymbolPoolStrategy strategy = new DynamicSymbolPoolStrategy(limit);
        AbstractSymbol symbolFromFactory = SymbolUtility.newSymbolMock(missingSymbolName);
        strategy.getMissingSymbol(symbolPoolMock, missingSymbolName);
        when(symbolFactoryMock.createSymbol(eq(missingSymbolName))).thenReturn(symbolFromFactory);
        when(symbolPoolMock.getSymbolsCount(eq(missingSymbolName))).thenReturn(1);

        // WHEN
        exception.expect(SymbolPoolException.class);
        strategy.getMissingSymbol(symbolPoolMock, missingSymbolName);
    }

}
