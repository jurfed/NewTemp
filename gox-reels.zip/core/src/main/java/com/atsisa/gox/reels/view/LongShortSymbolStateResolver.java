package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.reels.view.spi.ISymbolStateResolver;

/**
 * Resolves symbol's animation state to avoid wrong displaying. Animations can be "Long" for bigger wins or "Short" for lower.
 */
@XmlElement
public class LongShortSymbolStateResolver implements ISymbolStateResolver {

    /**
     * Defines value of parameter that describes long symbol's animation to compare with response from server.
     */
    private static final String LONG = "Long";

    /**
     * Defines value of parameter that describes short symbol's animation to compare with response from server.
     */
    private static final String SHORT = "Short";

    /**
     * Function resolves symbol's correct animation state
     * @param symbol Current symbol to resolve.
     * @param state  Current state that is setted.
     * @return State that should be setted.
     */
    public String resolve(ISymbol symbol, String state) {
        if (symbol.getState().equals(LONG) && state.equals(SHORT)) {
            return symbol.getState();
        }
        return state;
    }

}
