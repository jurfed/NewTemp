package com.atsisa.gox.reels.model;

import com.atsisa.gox.reels.IBetModel;

/**
 * Exposes the most recent reel game bet configuration.
 */
public interface IBetModelProvider {

    /**
     * Gets the most recent reel game bet configuration.
     * @return IBetModel
     */
    IBetModel getBetModel();

}
