package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when game was entered into history mode.
 */
@Reflectable
public class EnteredHistoryEvent {
}
