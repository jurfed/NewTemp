package com.atsisa.gox.reels.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.BasicScreen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.command.SpinReelsCommand;
import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.event.WinningLineShownEvent;

import com.atsisa.gox.reels.model.ICreditsFormatter;

import com.atsisa.gox.reels.logic.model.WinLineInfo;

import com.atsisa.gox.reels.view.IWinLine;
import com.atsisa.gox.reels.view.state.WinLineState;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Defines and controls behavior of reel game's win lines.
 */
@Reflectable
public class WinLinesScreen extends BasicScreen implements IResetable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "WinLinesScreenLayoutId";

    /**
     * A list of line views.
     */
    private final List<IWinLine> winLines;

    /**
     * The credits formatter.
     */
    private final ICreditsFormatter creditsFormatter;

    /**
     * The lines model.
     */
    private ILinesModel linesModel;

    /**
     * A number of active lines.
     */
    private int activeLines;

    /**
     * A value indicating whether active lines are currently shown.
     */
    private boolean activeLinesShown;

    /**
     * The lines model mutator.
     */
    private IMutator<ILinesModel> linesModelMutator;

    /**
     * The current win line.
     */
    private IWinLine currentWinLine;

    /**
     * Initializes a new instance of the {@link WinLinesScreen} class.
     * @param layoutId          layout identifier
     * @param model             {@link ScreenModel}
     * @param renderer          {@link IRenderer}
     * @param viewManager       {@link IViewManager}
     * @param animationFactory  {@link IAnimationFactory}
     * @param logger            {@link ILogger}
     * @param eventBus          {@link IEventBus}
     * @param creditsFormatter  {@link ICreditsFormatter}
     * @param linesModelMutator the lines model mutator
     */
    @Inject
    public WinLinesScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, ICreditsFormatter creditsFormatter,
            IMutator<ILinesModel> linesModelMutator) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.creditsFormatter = creditsFormatter;
        winLines = new ArrayList<>();
        this.linesModelMutator = linesModelMutator;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        try {
            getEventBus().register(this);
        } catch (ReflectionException e) {
            getEventBus().post(new GeneralSystemException(e));
            getLogger().error(e.getMessage(), e);
        }
    }

    /**
     * Binds and sorts layout's win line views.
     */
    @Override
    protected void afterActivated() {
        List<IWinLine> foundLineViews = findViewImplementingType(IWinLine.class);
        winLines.clear();
        winLines.addAll(foundLineViews);
        updateActiveLines(false);
    }

    /**
     * Handles the event with info about changes in lines model.
     * @param linesModelChangedEvent {@link LinesModelChangedEvent}
     */
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        linesModel = linesModelMutator.mutate(linesModelChangedEvent.getLinesModel());
        if (linesModelChangedEvent.hasCurrentWinningLineChanged()) {
            Optional<IWinLineInfo> winLineInfo = linesModel.getCurrentWinningLine();
            if (winLineInfo.isPresent()) {
                notifyWinningLineShown(winLineInfo.get(), showWinLine(winLineInfo.get()), linesModelChangedEvent);
            } else {
                hideWinningLines();
            }
            return;
        }
        updateActiveLines(linesModelChangedEvent.hasSelectedLinesChanged());
    }

    /**
     * Updates active lines when a bet changes.
     * @param betModelChangedEvent An event containing the most recent bet model.
     */
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        boolean shouldShowLines = betModelChangedEvent.getSourceEvent() instanceof UserInteractionCommand;
        updateActiveLines(shouldShowLines);
    }

    /**
     * Hides shown active lines when the user starts to spin the reels.
     * @param spinReelsCommand A command propagated when the user starts the spinning.
     */
    @Subscribe
    public void handleSpinReelsCommand(SpinReelsCommand spinReelsCommand) {
        updateActiveLines(false);
    }

    /**
     * Shows winning line.
     * @param winLineInfo {@link WinLineInfo}
     * @return representation of winning line {@link IWinLine}
     */
    protected IWinLine showWinLine(IWinLineInfo winLineInfo) {
        if (currentWinLine != null) {
            currentWinLine.setState(WinLineState.ACTIVE);
        }
        currentWinLine = getWinLine(winLineInfo.getLineNumber());
        if (currentWinLine == null) {
            notifyErrorOccurred("Could not resolve a winning line based on its info. Line number: " + winLineInfo.getLineNumber());
            return null;
        }
        currentWinLine.updateWinScore(creditsFormatter.formatWithCurrency(winLineInfo.getScore()));
        currentWinLine.setState(WinLineState.SHOWN_WINNING);
        currentWinLine.showWin(winLineInfo);
        return currentWinLine;
    }

    /**
     * Hides all winning lines.
     */
    protected void hideWinningLines() {
        for (IWinLine winLine : winLines) {
            if (winLine.getState() == WinLineState.SHOWN_WINNING) {
                winLine.setState(WinLineState.ACTIVE);
            }
            winLine.hideWin();
        }
        currentWinLine = null;
    }

    /**
     * Gets the win line number.
     * @param lineNumber the win line number
     * @return the win line number or null if the number is not found in the win lines list
     */
    private IWinLine getWinLine(int lineNumber) {
        if (lineNumber <= winLines.size()) {
            for (IWinLine winLine : winLines) {
                if (lineNumber == winLine.getLineNumber()) {
                    return winLine;
                }
            }
        }
        return null;
    }

    /**
     * Updates active lines according to current lines model.
     * @param shouldShowLines a value indicating whether active lines should be shown
     */
    private void updateActiveLines(final boolean shouldShowLines) {
        if (linesModel == null || winLines.isEmpty()) {
            return;
        }
        WinLineState nextState = shouldShowLines ? WinLineState.SHOWN : WinLineState.ACTIVE;

        int selectedLines = linesModel.getSelectedLines();

        if (activeLines != selectedLines) {
            if (activeLines == 0) {
                for (int lineNumber = 1; lineNumber <= selectedLines; ++lineNumber) {
                    getWinLine(lineNumber).setState(nextState);
                }
            } else if (activeLines < selectedLines) {
                for (int lineNumber = activeLines; lineNumber <= selectedLines; ++lineNumber) {
                    getWinLine(lineNumber).setState(nextState);
                }
            } else {
                for (int lineNumber = selectedLines + 1; lineNumber <= activeLines; ++lineNumber) {
                    getWinLine(lineNumber).setState(WinLineState.INACTIVE);
                }
            }
        }

        activeLines = selectedLines;

        if (shouldShowLines ^ activeLinesShown) {
            for (int lineNumber = 1; lineNumber <= activeLines; lineNumber++) {
                getWinLine(lineNumber).setState(nextState);
            }
            activeLinesShown = shouldShowLines;
        }
    }

    /**
     * Propagates an {@link ErrorOccurredEvent} with given message.
     * @param message the message to propagate
     */
    private void notifyErrorOccurred(String message) {
        Throwable error = new IllegalStateException(message);
        getEventBus().post(new ErrorOccurredEvent(error));
    }

    /**
     * Notifies that the win line has been shown.
     * @param winLineInfo the win line info
     * @param winLine     the win line
     * @param sourceEvent the source event
     */
    private void notifyWinningLineShown(IWinLineInfo winLineInfo, IWinLine winLine, Object sourceEvent) {
        WinningLineShownEvent event = new WinningLineShownEvent(winLineInfo, winLine);
        event.setSourceEvent(sourceEvent);
        getEventBus().post(event);
    }

    @Override
    @ExposeMethod
    public void reset() {
        hideWinningLines();
    }

}
