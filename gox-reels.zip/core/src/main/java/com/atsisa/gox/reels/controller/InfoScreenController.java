package com.atsisa.gox.reels.controller;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.reels.IInfoScreenController;
import com.atsisa.gox.reels.command.NextInfoScreenCommand;
import com.google.inject.Inject;

/**
 * InfoScreen controller default implementation.
 */
public class InfoScreenController implements IInfoScreenController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * Creates new instance of the {@link InfoScreenController}.
     * @param eventBus the event bus.
     */
    @Inject
    public InfoScreenController(IEventBus eventBus) {
        this.eventBus = eventBus;
    }

    @Override
    public synchronized void nextScreen() {
        eventBus.post(new NextInfoScreenCommand(true));
    }
}
