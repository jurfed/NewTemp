package com.atsisa.gox.reels.model;

import com.atsisa.gox.framework.exception.NotEnoughFundsException;
import com.atsisa.gox.framework.exception.UnableToConnectException;
import com.atsisa.gox.reels.exception.NoHistoryException;

/**
 * Delivers default retry button policy for error handling.
 */
public class DefaultRetryPolicy implements IRetryPolicy {

    @Override
    public boolean isRetriable(Throwable cause) {
        if (cause instanceof UnableToConnectException || cause instanceof NotEnoughFundsException || cause instanceof NoHistoryException) {
            return true;
        }
        return false;
    }
}
