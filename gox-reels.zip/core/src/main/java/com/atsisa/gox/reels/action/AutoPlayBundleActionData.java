package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.BundleActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Data used in {@link AutoPlayBundleAction}.
 */
@Reflect_Full
@XmlElement
public class AutoPlayBundleActionData extends BundleActionData {

    /**
     * A boolean value that indicates whether this action bundle should be executed when auto play is turn on or off.
     */
    @XmlAttribute
    private boolean expectAutoPlayOn;

    /**
     * Returns a boolean value that indicates whether this action bundle should be executed when auto play is turn on or off.
     * @return boolean
     */
    public boolean isExpectAutoPlayOn() {
        return expectAutoPlayOn;
    }

    /**
     * Sets a boolean value that indicates whether this action bundle should be executed when auto play is turn on or off.
     * @param expectAutoPlayOn boolean
     */
    public void setExpectAutoPlayOn(boolean expectAutoPlayOn) {
        this.expectAutoPlayOn = expectAutoPlayOn;
    }

}
