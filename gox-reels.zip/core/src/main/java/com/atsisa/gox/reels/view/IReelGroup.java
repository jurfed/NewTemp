package com.atsisa.gox.reels.view;

import java.util.List;


import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.spi.IHideSymbolAnimationsStrategy;
import com.atsisa.gox.reels.view.spi.IReelSequenceProvider;
import com.atsisa.gox.reels.view.spi.IShowSymbolAnimationsStrategy;
import com.atsisa.gox.reels.view.state.ReelGroupState;

import rx.Observable;

/**
 * Interface describing basic reel group behaviour.
 */
public interface IReelGroup {

    /**
     * Returns reel, which is at a specific position.
     * @param index int
     * @return AbstractReel
     * @throws IllegalStateException    When the reels are not set.
     * @throws IllegalArgumentException When the index is not in the available range.
     */
    AbstractReel getReel(int index);

    /**
     * Gets current reel group state.
     * @return ReelGroupState
     */
    ReelGroupState getReelGroupState();

    /**
     * Gets an observable reel group state.
     * <p>
     * This property enables users to keep track of
     * {@link ReelGroupState} changes.
     * </p>
     * @return An observable reel group state.
     */
    Observable<ReelGroupState> getReelGroupStateObservable();

    /**
     * Returns all reel, which are located in this reel group.
     * @return all reel, which are located in this reel group
     */
    Iterable<AbstractReel> getReels();

    /**
     * Sets new reels for this reel group.
     * @param reels new reels for this reel group
     * @throws IllegalStateException When the current reels are not in the idle state.
     */
    void setReels(List<AbstractReel> reels);

    /**
     * Starts the spin of all reel in this reel group.
     * @throws IllegalStateException When the reels are not set or when at least one of the reel is not ready to spin.
     */
    void spin();

    /**
     * Gently stops all reel in this reel group on selected symbols.
     * <p>
     * It directly jumps to selected symbols in case the reels are in idle state.
     * </p>
     * @param symbolNames A collection of symbol for all reels is about to be stopped upon.
     * @throws IllegalStateException    When the reels are not set or when reel group is already in stopping phase.
     * @throws IllegalArgumentException The size of collection it is not the same as the number of reels or symbol names are null.
     */
    void stopOnSymbols(List<Iterable<String>> symbolNames);

    /**
     * Forcibly stops all reels in this reel group on selected symbols.
     * <p>
     * It directly jumps to selected symbols in case the reels are in idle state.
     * </p>
     * @param symbolNames A collection of symbol names for all reels is about to be stopped upon.
     * @throws IllegalStateException    When the reels are not set or when reel group is already in force stopping phase.
     * @throws IllegalArgumentException The size of collection it is not the same as the number of reels or symbol names are null.
     */
    void forceStopOnSymbols(List<Iterable<String>> symbolNames);

    /**
     * Sets strategy which determines in what sequence, spin should be called on each reel.
     * @param spinSequenceProvider {@link IReelSequenceProvider}
     * @throws IllegalArgumentException thrown when the strategy is null.
     */
    void setSpinSequenceProvider(IReelSequenceProvider spinSequenceProvider);

    /**
     * Sets strategy which determines in what sequence, stop on symbols should be called on each reel.
     * @param stopOnSymbolsSequenceProvider {@link IReelSequenceProvider}
     * @throws IllegalArgumentException thrown when the strategy is null.
     */
    void setStopOnSymbolsSequenceProvider(IReelSequenceProvider stopOnSymbolsSequenceProvider);

    /**
     * Sets strategy which determines in what sequence, force stop should be called on each reel.
     * @param forceStopOnSymbolsSequenceProvider {@link IReelSequenceProvider}
     * @throws IllegalArgumentException thrown when the strategy is null.
     */
    void setForceStopOnSymbolsSequenceProvider(IReelSequenceProvider forceStopOnSymbolsSequenceProvider);

    /**
     * Sets strategy which decides how to show the animation on the winning symbols.
     * @param showSymbolAnimationsStrategy {@link IShowSymbolAnimationsStrategy}
     * @throws IllegalArgumentException thrown when the strategy is null.
     */
    void setShowSymbolAnimationsStrategy(IShowSymbolAnimationsStrategy showSymbolAnimationsStrategy);

    /**
     * Sets strategy which decides how to hide the animation on the winning symbols.
     * @param hideSymbolAnimationsStrategy {@link IHideSymbolAnimationsStrategy}
     * @throws IllegalArgumentException thrown when the strategy is null.
     */
    void setHideSymbolAnimationsStrategy(IHideSymbolAnimationsStrategy hideSymbolAnimationsStrategy);

    /**
     * Shows the winning symbols based on the list with information about the win.
     * @param winningLines list with information about the win
     * @throws IllegalStateException When the reel group is not in the {@link ReelGroupState#IDLE} state
     */
    void showWinningSymbols(List<? extends IWinLineInfo> winningLines);

    /**
     * Forcibly skips the starting showing winning symbols.
     * @throws IllegalStateException When the reel group is not in the {@link ReelGroupState#STARTS_SHOWING_WINNING_SYMBOLS} state
     */
    void terminateStartsShowingWinningSymbols();

    /**
     * Gently stops all symbol animations on all reels.
     * @throws IllegalStateException when reel group is not showing any winning symbol animations
     */
    void stopSymbolAnimations();

    /**
     * Forcibly stops all symbol animations on all reels.
     * @throws IllegalStateException when reel group is not showing any winning symbol animations
     */
    void forceStopSymbolAnimations();
}
