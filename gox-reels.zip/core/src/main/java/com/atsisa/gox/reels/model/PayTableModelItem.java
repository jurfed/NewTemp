package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

/**
 * Contains information about single element for pay table.
 */
class PayTableModelItem implements IPayTableModelItem {

    /**
     * Name of this item.
     */
    private final String name;

    /**
     * The original value of this item.
     */
    private final BigDecimal originalValue;

    /**
     * Type of this item.
     */
    private final PayTableModelItemType type;

    /**
     * The item value.
     */
    private BigDecimal value;

    /**
     * Creates a new instance of {@link PayTableModelItem} class.
     * @param name          name of the pay table item
     * @param originalValue {@link BigDecimal}
     * @param type          {@link PayTableModelItemType}
     */
    public PayTableModelItem(String name, BigDecimal originalValue, PayTableModelItemType type) {
        this.name = name;
        this.originalValue = originalValue;
        this.type = type;
        value = this.originalValue;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the item value as BigDecimal.
     * @param value {@link BigDecimal}
     */
    void setValue(BigDecimal value) {
        this.value = value;
    }

    @Override
    public PayTableModelItemType getType() {
        return type;
    }

    /**
     * Gets the original value of this item.
     * @return the original value of this item
     */
    BigDecimal getOriginalValue() {
        return originalValue;
    }
}
