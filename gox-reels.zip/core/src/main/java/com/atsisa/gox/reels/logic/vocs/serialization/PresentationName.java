package com.atsisa.gox.reels.logic.vocs.serialization;

/**
 * List of available presentation names which are connected with common game flow.
 */
public class PresentationName {

    /**
     * Private constructor, prevents the creation of an instance of this class.
     */
    private PresentationName() {
    }

    /**
     * Name of the presentation for base game win.
     */
    public static final String BASE_GAME_WIN = "BaseGameWin";

    /**
     * Name of the presentation for base game lose.
     */
    public static final String BASE_GAME_LOSE = "BaseGameLose";

    /**
     * Name of the presentation for base game limit.
     */
    public static final String BASE_GAME_LIMIT = "BaseGameLimit";

    /**
     * Name of the presentation for offer gambler take win.
     */
    public static final String OFFER_GAMBLER_TAKE_WIN = "OfferGamblerTakeWin";

    /**
     * Name of the presentation for limit take win.
     */
    public static final String LIMIT_TAKE_WIN = "LimitTakeWin";

    /**
     * Name of the presentation for change translation.
     */
    public static final String CHANGE_TRANSLATION = "ChangeTranslation";

    /**
     * Name of the presentation for game start.
     */
    public static final String GAME_START = "GameStart";

    /**
     * Name of the presentation for enter gambler.
     */
    public static final String ENTER_GAMBLER = "EnterGambler";

    /**
     * Name of the presentation for gambler lose.
     */
    public static final String GAMBLER_LOSE = "GamblerLose";

    /**
     * Name of the presentation for gambler win.
     */
    public static final String GAMBLER_WIN = "GamblerWin";

    /**
     * Name of the presentation for gambler take win.
     */
    public static final String GAMBLER_TAKE_WIN = "GamblerTakeWin";

    /**
     * Name of the presentation for gambler limit.
     */
    public static final String GAMBLER_LIMIT = "GamblerLimit";

}
