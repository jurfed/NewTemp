package com.atsisa.gox.reels.model;

public interface IPayTableModelProvider {

    /*
     * Gets IPayTableModel
     */
    IPayTableModel getPayTableModel();
}
