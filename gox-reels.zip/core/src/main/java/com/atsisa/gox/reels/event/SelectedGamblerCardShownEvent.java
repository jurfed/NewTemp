package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when selected gambler card was shown.
 */
@Reflectable
public class SelectedGamblerCardShownEvent {

}
