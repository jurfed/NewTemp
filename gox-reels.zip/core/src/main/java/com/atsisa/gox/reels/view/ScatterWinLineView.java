package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.ICaption;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.state.WinLineState;
import com.gwtent.reflection.client.annotations.Reflect_Full;

import rx.functions.Action2;

/**
 * Describes game scatter winning line.
 */
@XmlElement
@Reflect_Full
public class ScatterWinLineView extends AbstractWinLineView {

    /**
     * Initializes a new instance of the {@link ScatterWinLineView} class.
     */
    public ScatterWinLineView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link ScatterWinLineView} class.
     * @param renderer {@link IRenderer}
     */
    public ScatterWinLineView(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Sets new scatter win line state {@link WinLineState}
     * Sets {@link WinLineState#INACTIVE} state if new state is different than {@link WinLineState#SHOWN_WINNING}
     * @param state A state described by in the {@link WinLineState}.
     */
    @Override
    public void setState(WinLineState state) {
        super.setState(state == WinLineState.SHOWN_WINNING ? state : WinLineState.INACTIVE);
    }

    /**
     * Gets the scatter winning bounds.
     * <p>
     * The frame bound is added when value in positions list under given index is higher than -1.
     * The value in positions list defines row in which the frame exists.
     * The index in positions list defines reel number in which the frame exists.
     * </p>
     * @return The winning sequence bounds.
     * @throws IllegalArgumentException Too low amount of defined frame objects in the ScatterWinLineView view group.
     */
    protected List<IBound> getWinningFramesBounds() {
        List<IBound> bounds = new ArrayList<>();
        List<Integer> winLinePositions = Iterables.toList(getWinLineInfo().getPositions());
        int maxRowInWinLinePositions = Collections.max(winLinePositions);
        int lastIndexOfMaxRow = winLinePositions.lastIndexOf(maxRowInWinLinePositions);

        if (getFrameDataObjects().size() <= winLinePositions.size() * maxRowInWinLinePositions + lastIndexOfMaxRow) {
            throw new IllegalArgumentException("Too low amount of defined frame views in the ScatterWinLineView view group.");
        }

        for (int index = 0; index < winLinePositions.size(); index++) {
            if (winLinePositions.get(index) > -1) {
                IBound bound = getFrameDataObjects().get(winLinePositions.size() * winLinePositions.get(index) + index);
                bounds.add(bound);
            }
        }

        return bounds;
    }

    /**
     * Shows the scatters win line activating views defined in win line info positions list.
     * <p>
     * The view is shown when value in positions list under given index is higher than -1.
     * The index in position list of win line info defines reel number in which the view exists.
     * The value in position list of win line info defines row in which the view exists.
     * </p>
     * @param winLineInfo The winning scatter line info model.
     */
    public void showWin(IWinLineInfo winLineInfo) {
        setWinLineInfo(winLineInfo);
        if (getState() == WinLineState.SHOWN_WINNING) {
            List<Integer> winLinePositions = Iterables.toList(getWinLineInfo().getPositions());
            for (int index = 0; index < winLinePositions.size(); index++) {
                if (winLinePositions.get(index) > -1) {
                    View currentView = getFrameViews().get(winLinePositions.size() * winLinePositions.get(index) + index);
                    getViewActivator().activate(currentView);
                }
            }
            showScore(getWinScore());
        }
    }
}
