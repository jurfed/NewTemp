package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroupBase;

/**
 * An abstract reel class extends {@link View} and inherits from {@link IReelGroup} interface.
 */
public abstract class AbstractReelGroup extends ViewGroupBase implements IReelGroup, IResetable {

    /**
     * Initializes a new instance of the {@link AbstractReelGroup} class.
     */
    public AbstractReelGroup() {
    }

    /**
     * Initializes a new instance of the {@link AbstractReelGroup} class.
     * @param renderer {@link IRenderer}
     */
    public AbstractReelGroup(IRenderer renderer) {
        super(renderer);
    }

}
