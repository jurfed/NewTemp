package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.IGameEngine;

/**
 * Sends a request to show next history page.
 */
public class ShowNextHistoryPageRequestAction extends AbstractHistoryPageRequestAction {

    /**
     * Initializes a new instance of the {@link ShowNextHistoryPageRequestAction} class.
     */
    public ShowNextHistoryPageRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowNextHistoryPageRequestAction} class.
     * @param gameEngine game engine reference
     */
    public ShowNextHistoryPageRequestAction(IGameEngine gameEngine) {
        super(gameEngine);
    }

    @Override
    protected int getHistoryPageNumberToShow() {
        return getHistoryModel().getActivePageNumber() + 1;
    }
}
