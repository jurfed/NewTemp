package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.gwtent.reflection.client.Reflectable;

/**
 * Abstraction action to handle init request to the game server.
 */
@Reflectable(relationTypes = true)
public abstract class AbstractInitRequestAction extends AbstractSendRequestAction {

    /**
     * A configuration reference.
     */
    private final IConfiguration configuration;

    /**
     * Initializes a new instance of the {@link AbstractInitRequestAction} class.
     */
    public AbstractInitRequestAction() {
        configuration = GameEngine.current().getConfigurationProvider().getConfiguration();
    }

    /**
     * Sends getInitialParameters and then the init request to the game server. Once all responses came the action sets
     * the game model for the referenced reel game based on previous server responses.
     */
    @Override
    protected void execute() {
        logger.debug("SendInitRequestAction | execute");
        sendInitRequest();
    }

    /**
     * Gets value for specific property name.
     * @param propertyName property name
     * @return property value
     */
    private String getPropertyValue(String propertyName) {
        Object propertyValue = configuration.getProperty(propertyName);
        if (propertyValue != null) {
            return propertyValue.toString();
        }
        return null;
    }

    /**
     * Creates and returns new init request.
     * @return new init request
     */
    protected InitRequest createInitRequest() {
        return new InitRequest(getPropertyValue(ReelConfigurationConstants.WRAPPER_NAME), getPropertyValue(ReelConfigurationConstants.LANGUAGE_CODE));
    }

    /**
     * Sends init request to game logic.
     */
    protected abstract void sendInitRequest();
}
