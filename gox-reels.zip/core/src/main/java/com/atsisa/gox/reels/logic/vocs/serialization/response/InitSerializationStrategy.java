package com.atsisa.gox.reels.logic.vocs.serialization.response;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.vocs.serialization.PresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;

/**
 * Response strategy for game init presentation.
 */
public class InitSerializationStrategy implements IResponseSerializationStrategy<InitResult> {

    /**
     * Name of the presentation which is supported by this strategy.
     */
    private static final String PRESENTATION_NAME = PresentationName.GAME_START;

    @Override
    public boolean isPresentationSupported(String presentationName, XmlObject xmlObject) {
        return presentationName.charAt(0) == 'R' || PRESENTATION_NAME.contains(presentationName);
    }

    @Override
    public InitResult serialize(XmlObject input) throws SerializationException {
        return new InitResult(XmlDeserializer.deserializeGameConfiguration(input), XmlDeserializer.deserializeLanguageInfo(input));
    }
}
