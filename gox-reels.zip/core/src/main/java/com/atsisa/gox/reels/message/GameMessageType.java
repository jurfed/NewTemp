package com.atsisa.gox.reels.message;

/**
 * Defines possible game message types.
 */
public enum GameMessageType {
    /**
     * A bottom panel message.
     */
    BOTTOM_PANEL,
    /**
     * An error screen message.
     */
    ERROR
}
