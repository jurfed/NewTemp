package com.atsisa.gox.reels.model;

import java.util.Date;

/**
 * Represents the configuration of game history.
 */
public class HistoryModel implements IHistoryModel {

    /**
     * Total number of history pages.
     */
    private int totalNumberPages;

    /**
     * Number of currently active page in history.
     */
    private int activePageNumber;

    /**
     * Date of currently active history page.
     */
    private Date activePageDate;

    @Override
    public int getTotalNumberPages() {
        return totalNumberPages;
    }

    @Override
    public Date getActivePageDate() {
        return activePageDate;
    }

    @Override
    public int getActivePageNumber() {
        return activePageNumber;
    }

    /**
     * Sets total number of pages in history.
     * @param totalNumberPages total number of pages in history.
     */
    void setTotalNumberPages(int totalNumberPages) {
        this.totalNumberPages = totalNumberPages;
    }

    /**
     * Sets number of currently active page in history.
     * @param activePageNumber active page number.
     */
    void setActivePageNumber(int activePageNumber) {
        this.activePageNumber = activePageNumber;
    }

    /**
     * Sets date for currently active page in history.
     * @param activePageDate active page date.
     */
    void setActivePageDate(Date activePageDate) {
        this.activePageDate = activePageDate;
    }

    /**
     * Clears all information/data in model.
     */
    void clear() {
        activePageDate = null;
        totalNumberPages = 0;
        activePageNumber = 0;
    }
}