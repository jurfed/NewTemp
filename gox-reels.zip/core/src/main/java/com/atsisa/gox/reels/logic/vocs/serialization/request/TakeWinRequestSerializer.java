package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.TakeWinRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for take win request.
 */
public class TakeWinRequestSerializer implements ISerializer<TakeWinRequest, XmlObject> {

    @Override
    public XmlObject serialize(TakeWinRequest request) {
        return new XmlBuilder()
            .startElement("nrgs")
                .startElement("req")
                    .startElement("a")
                        .writeValue("TakeWin")
                    .endElement()
                .endElement()
            .endElement()
            .toXmlObject();
    }
}
