package com.atsisa.gox.reels.message.processing;

import java.math.BigDecimal;

import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.model.IAccount;
import com.google.inject.Inject;

/**
 * Adjusts winner paid messages according to player's latest translations.
 */
public class WinnerPaidMessageProcessor implements IGameMessageProcessor {

    /**
     * Winner paid message.
     */
    private static final String WINNER_PAID_MESSAGE = "{#LangWinnerPaid}";

    /**
     * Place your bet message.
     */
    private static final String PLACE_YOUR_BET_MESSAGE = "{#LangPlaceYourBet}";

    /**
     * The account.
     */
    private final IAccount account;

    /**
     * The logger.
     */
    private final ILogger logger;

    /**
     * Initializes a new instance of the {@link WinnerPaidMessageProcessor}
     * @param account The account reference.
     * @param logger  The logger reference.
     */
    @Inject
    public WinnerPaidMessageProcessor(IAccount account, ILogger logger) {
        this.account = account;
        this.logger = logger;
    }

    @Override
    public void process(GameMessage gameMessage) {
        if (gameMessage.getContent().equals(WINNER_PAID_MESSAGE)) {

            BigDecimal latestTransaction = Iterables.getFirst(account.getTransactionHistory(), null);
            if (latestTransaction == null || latestTransaction.signum() == -1) {
                logger.warn("WinnerPaidMessageProcessor | The latest transaction is unavailable or it is a withdraw stake transaction.");
                return;
            }

            String newMessage = StringUtility
                    .format("%s %s %s%s", WINNER_PAID_MESSAGE, account.getCreditsFormatter().formatWithCurrency(latestTransaction), "\n",
                            PLACE_YOUR_BET_MESSAGE);
            gameMessage.setContent(newMessage);
        }
    }
}
