package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for enter gambler.
 */
@Reflectable
public class EnterGamblerCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public EnterGamblerCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
