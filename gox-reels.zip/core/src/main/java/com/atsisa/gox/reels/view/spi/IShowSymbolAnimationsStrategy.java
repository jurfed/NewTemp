package com.atsisa.gox.reels.view.spi;

import java.util.List;

import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.IReelGroup;

import rx.Observable;

/**
 * It decides how to show/hide the animation on the symbols.
 */
public interface IShowSymbolAnimationsStrategy {

    /**
     * Shows the symbol animations on reels.
     * @param winningLines list with info about winning lines
     * @param reelGroup    {@link IReelGroup}
     * @return the observable result
     */
    Observable<IReelGroup> showAnimations(List<? extends IWinLineInfo> winningLines, IReelGroup reelGroup);

    /**
     *  Interrupts the current process of showing symbol animations and forces it to appear immediately.
     */
    void terminate();

}
