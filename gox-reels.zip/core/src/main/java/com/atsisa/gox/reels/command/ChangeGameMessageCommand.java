package com.atsisa.gox.reels.command;

import com.atsisa.gox.reels.message.GameMessageType;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * A command triggered when a game message needs to be changed.
 */
@Reflect_Mini
public final class ChangeGameMessageCommand {

    /**
     * The most recent message related to {@link GameMessageType} object.
     */
    private final String message;

    /**
     * Classifier of the even type.
     */
    private final GameMessageType messageType;

    /**
     * Initializes a new instance of the {@link ChangeGameMessageCommand} class.
     * @param message     message that has to be handled
     * @param messageType classifier of game message type
     */
    public ChangeGameMessageCommand(String message, GameMessageType messageType) {
        this.message = message;
        this.messageType = messageType;
    }

    /**
     * Gets the message contained in the event.
     * @return message related with
     */
    public String getMessage() {
        return message;
    }

    /**
     * Gets the event type classifier.
     * @return game message type
     */
    public GameMessageType getMessageType() {
        return messageType;
    }
}
