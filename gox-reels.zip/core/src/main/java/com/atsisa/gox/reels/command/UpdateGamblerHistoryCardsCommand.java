package com.atsisa.gox.reels.command;

import java.util.List;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the gambler cards history should be updated.
 */
@Reflectable
public class UpdateGamblerHistoryCardsCommand {

    /**
     * Gambler history cards.
     */
    private List<String> historyCards;

    /**
     * Initializes a new instance of the UpdateGamblerHistoryCardsCommand class.
     * @param historyCards list of history cards
     */
    public UpdateGamblerHistoryCardsCommand(List<String> historyCards) {
        this.historyCards = historyCards;
    }

    /**
     * Gets gambler history cards.
     * @return list of history cards
     */
    public List<String> getHistoryCards() {
        return historyCards;
    }
}
