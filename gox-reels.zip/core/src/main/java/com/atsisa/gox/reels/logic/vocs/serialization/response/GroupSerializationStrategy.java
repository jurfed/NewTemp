package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;
import com.google.inject.Inject;

/**
 * Abstract class implementation for simple vocs response serialization strategy.
 */
public abstract class GroupSerializationStrategy<T> implements IResponseSerializationStrategy<T> {

    /**
     * List of the supported presentations by this strategy.
     */
    private List<String> supportedPresentations = new ArrayList<>();

    /**
     * Initializes a new instance of the {@link GroupSerializationStrategy} class.
     */
    @Inject
    public GroupSerializationStrategy() {
        registerDefaultSupportedPresentations();
    }

    @Override
    public T serialize(XmlObject input) throws SerializationException {
        return deserializePresentation(input);
    }

    @Override
    public boolean isPresentationSupported(String presentationName, XmlObject xmlObject) {
        Iterable<String> supportedPresentations = getSupportedPresentations();
        if (isResumedPresentation(presentationName)) {
            presentationName = presentationName.substring(1);
        }
        for (String supportedPresentation : supportedPresentations) {
            if (supportedPresentation.equals(presentationName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Registers the default supported presentations.
     */
    protected void registerDefaultSupportedPresentations() {
        //Do nothing
    }

    /**
     * Checks if presentation name contains information about that this presentation is resumed or not.
     * @param presentationName the presentation name
     * @return boolean
     */
    protected boolean isResumedPresentation(String presentationName) {
        return presentationName.charAt(0) == 'R';
    }

    /**
     * Adds the supported presentations.
     * @param additionalSupportedPresentations the supported presentations
     */
    public void addSupportedPresentations(Set<String> additionalSupportedPresentations) {
        for (String presentationName : additionalSupportedPresentations) {
            addPresentation(presentationName);
        }
    }

    /**
     * Adds the specific presentation to the supporting list.
     * @param presentationName {@link String}
     */
    protected void addPresentation(String presentationName) {
        List<String> supportedPresentations = getSupportedPresentations();
        if (supportedPresentations.contains(presentationName)) {
            return;
        }
        supportedPresentations.add(presentationName);
    }

    /**
     * Gets the presentation name from the presentation xml object.
     * @param xmlObject {@link XmlObject}
     * @return the presentation name
     */
    protected String getPresentationName(XmlObject xmlObject) {
        return XmlDeserializer.deserializePresentationName(xmlObject);
    }

    /**
     * Gets supported presentations by this strategy.
     * @return supported presentations
     */
    protected List<String> getSupportedPresentations() {
        return supportedPresentations;
    }

    /**
     * Deserializes the given xml object to presentation.
     * @param xmlObject {@link XmlObject}
     * @return deserialized presentation
     */
    protected abstract T deserializePresentation(XmlObject xmlObject);

    /**
     * Checks if presentation xml object contains information about history or not.
     * @param xmlObject {@link XmlObject}
     * @return boolean
     */
    protected boolean isHistoryPresentation(XmlObject xmlObject) {
        return xmlObject.findOne("//nrgs/h") != null;
    }

}
