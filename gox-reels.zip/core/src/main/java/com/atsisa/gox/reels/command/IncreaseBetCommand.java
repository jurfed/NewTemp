package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for increasing bet value.
 */
@Reflectable
public final class IncreaseBetCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link IncreaseBetCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public IncreaseBetCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
