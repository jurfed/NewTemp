package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when presentation state change
 */
@Reflectable
public class PresentationStateChangedEvent {

    /**
     * Name of the presentation state.
     */
    private final String stateName;

    /**
     * Initializes a new instance of the {@link PresentationStateChangedEvent} class.
     * @param stateName the name of the presentation state
     */
    public PresentationStateChangedEvent(String stateName) {
        this.stateName = stateName;
    }

    /**
     * Gets the name of the presentation state.
     * @return the name of the presentation state
     */
    public String getStateName() {
        return stateName;
    }
}

