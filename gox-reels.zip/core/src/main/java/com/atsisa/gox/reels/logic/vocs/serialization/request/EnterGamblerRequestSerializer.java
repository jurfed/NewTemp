package com.atsisa.gox.reels.logic.vocs.serialization.request;

import java.math.BigDecimal;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for enter gambler request.
 */
public class EnterGamblerRequestSerializer implements ISerializer<EnterGamblerRequest, XmlObject> {

    @Override
    public XmlObject serialize(EnterGamblerRequest request) {
        return new XmlBuilder()
            .startElement("nrgs")
                .startElement("req")
                    .startElement("a")
                        .writeValue("Gamble")
                    .endElement()
                    .startElement("b")
                        .writeValue(request.getBetAmount().multiply(new BigDecimal(request.getLinesAmount())))
                    .endElement()
                    .startElement("ls")
                        .writeValue(request.getLinesAmount())
                    .endElement()
                .endElement()
            .endElement()
            .toXmlObject();
    }
}