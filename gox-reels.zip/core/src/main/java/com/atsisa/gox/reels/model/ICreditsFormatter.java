package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

/**
 * A component responsible for formatting credits.
 */
public interface ICreditsFormatter {

    /**
     * Formats given amount of credits to a proper string representation.
     * @param credits The credits to format.
     * @return Formatted credits.
     */
    String format(BigDecimal credits);

    /**
     * Formats given amount of credits to a proper string representation with a given decimal format.
     * @param credits       The credits to format.
     * @param decimalFormat The decimal format.
     * @return Formatted credits.
     */
    String format(BigDecimal credits, String decimalFormat);

    /**
     * Formats given amount of credits to a proper string representation
     * including the currency code.
     * @param credits The credits to format.
     * @return Formatted credits.
     */
    String formatWithCurrency(BigDecimal credits);

    /**
     * Formats given amount of credits to a proper string representation including the currency code and decimal format.
     * @param credits       The credits to format.
     * @param decimalFormat The decimal format
     * @return Formatted credits.
     */
    String formatWithCurrency(BigDecimal credits, String decimalFormat);

    /**
     * Sets the currency code.
     * @param currencyCode The currency code.
     */
    void setCurrencyCode(String currencyCode);

    /**
     * Gets the currency code.
     * @return the currency code
     */
    String getCurrencyCode();
}
