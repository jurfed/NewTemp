package com.atsisa.gox.reels.logic.vocs.serialization;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.vocs.LanguageRequest;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.atsisa.gox.reels.logic.request.TakeWinRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.request.BetRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.EnterGamblerRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.GambleRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.HistoryRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.InitRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.LanguageRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.TakeWinRequestSerializer;

/**
 * Represents a serialization strategy for requests.
 */
public class RequestSerializationStrategyDelegate implements ISerializer<Object, String> {

    /**
     * A map of serializers.
     */
    private final Map<Class, ISerializer> requestSerializers;

    /**
     * Initializes a new instance of the {@link RequestSerializationStrategyDelegate} class.
     */
    public RequestSerializationStrategyDelegate() {
        requestSerializers = new HashMap<>();
        registerDefaultSerializers();
    }

    /**
     * Register default serializers.
     */
    private void registerDefaultSerializers() {
        requestSerializers.put(BetRequest.class, new BetRequestSerializer());
        requestSerializers.put(EnterGamblerRequest.class, new EnterGamblerRequestSerializer());
        requestSerializers.put(GambleRequest.class, new GambleRequestSerializer());
        requestSerializers.put(InitRequest.class, new InitRequestSerializer());
        requestSerializers.put(TakeWinRequest.class, new TakeWinRequestSerializer());
        requestSerializers.put(HistoryRequest.class, new HistoryRequestSerializer());
        requestSerializers.put(LanguageRequest.class, new LanguageRequestSerializer());
    }

    /**
     * Registers other request serializers.
     * @param key        request type
     * @param serializer request serializer
     */
    public void registerRequestSerializer(Class key, ISerializer serializer) {
        requestSerializers.put(key, serializer);
    }

    @SuppressWarnings("unchecked")
    @Override
    public String serialize(Object object) throws SerializationException {
        ISerializer serializer = requestSerializers.get(object.getClass());
        if (serializer != null) {
            return ((XmlObject) serializer.serialize(object)).toXmlString();
        }
        throw new SerializationException("Cannot find serializer for class: " + object.getClass());
    }
}