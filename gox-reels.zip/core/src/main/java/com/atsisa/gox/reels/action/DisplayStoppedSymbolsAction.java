package com.atsisa.gox.reels.action;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.DisplayStoppedSymbolsCommand;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Display stopped symbols, based on last response from server.
 */
@Reflect_Mini
public class DisplayStoppedSymbolsAction extends SyncAction {

    /**
     * {@link IReelGameStateHolder} reference.
     */
    private final IReelGameStateHolder reelGameStateHolder;

    /**
     * Stopped symbols.
     */
    private List<Iterable<String>> stoppedSymbols;

    /**
     * Initializes a new instance of the {@link DisplayStoppedSymbolsAction} class.
     */
    public DisplayStoppedSymbolsAction() {
        reelGameStateHolder = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder();
    }

    /**
     * Initializes a new instance of the {@link DisplayStoppedSymbolsAction} class.
     * @param logger              a logger reference.
     * @param eventBus            an eventBus reference.
     * @param reelGameStateHolder an reelGameStateHolder reference.
     */
    public DisplayStoppedSymbolsAction(ILogger logger, IEventBus eventBus, IReelGameStateHolder reelGameStateHolder) {
        super(logger, eventBus);
        this.reelGameStateHolder = reelGameStateHolder;
    }

    @Override
    protected void reset() {
        super.reset();
        stoppedSymbols = null;
    }

    @Override
    protected void grabData() {
        stoppedSymbols = reelGameStateHolder.getStoppedSymbols();
    }

    @Override
    protected void validate() throws ValidationException {
        if (stoppedSymbols == null) {
            throw new ValidationException("Stopped symbols can not be null.");
        }
    }

    @Override
    protected void execute() {
        eventBus.post(new DisplayStoppedSymbolsCommand(stoppedSymbols));
    }
}
