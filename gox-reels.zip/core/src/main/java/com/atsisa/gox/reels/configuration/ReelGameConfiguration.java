package com.atsisa.gox.reels.configuration;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IUtility;
import com.atsisa.gox.framework.utility.reflection.IReflection;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * A representation of reel game configuration properties.
 */
@XmlElement
@Reflect_Full
public class ReelGameConfiguration {

    /**
     * Id resource where reel strips are.
     */
    @XmlCollectionElement(name = "ReelStripResources", itemType = String.class, itemName = "ReelStripResource")
    private List<String> reelStripResourcesId;

    /**
     * IReflection implementation.
     */
    private IReflection reflection;

    /**
     * Initializes a new instance of the ReelGameConfiguration class.
     */
    public ReelGameConfiguration() {
        IUtility utility = GameEngine.current().getUtility();
        reflection = utility.getReflection();
    }

    /**
     * Initializes a new instance of the ReelGameConfiguration class.
     * @param reflection - IReflection
     */
    public ReelGameConfiguration(IReflection reflection) {
        this.reflection = reflection;
    }

    /**
     * Gets a list with all available resources id, where are reel strips for the game.
     * @return list with all available resources id, where are reel strips for the game
     */
    public List<String> getReelStripResourcesId() {
        return reelStripResourcesId;
    }

    /**
     * Sets a list with all available resources id, where are reel strips for the game.
     * @param reelStripResourcesId list with all available resources id, where are reel strips for the game
     */
    public void setReelStripResourcesId(List<String> reelStripResourcesId) {
        this.reelStripResourcesId = reelStripResourcesId;
    }

}
