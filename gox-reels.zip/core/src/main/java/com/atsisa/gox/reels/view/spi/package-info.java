/**
 * Defines extension and customization points
 * for view-related structures.
 */
package com.atsisa.gox.reels.view.spi;