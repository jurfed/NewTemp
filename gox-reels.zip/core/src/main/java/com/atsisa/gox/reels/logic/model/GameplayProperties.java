package com.atsisa.gox.reels.logic.model;

import java.math.BigDecimal;

/**
 * Represents a properties of gameplay.
 */
public class GameplayProperties {

    /**
     * The lines amount.
     */
    private final int linesAmount;

    /**
     * The bet amount.
     */
    private final BigDecimal betAmount;

    /**
     * The credit amount.
     */
    private final BigDecimal creditAmount;

    /**
     * Initializes a new instance of the {@link GameplayProperties} class.
     * @param linesAmount  a lines amount
     * @param betAmount    a bet amount
     * @param creditAmount a credit amount
     */
    public GameplayProperties(int linesAmount, BigDecimal betAmount, BigDecimal creditAmount) {
        this.linesAmount = linesAmount;
        this.betAmount = betAmount;
        this.creditAmount = creditAmount;
    }

    /**
     * Gets a lines amount.
     * @return a lines amount
     */
    public int getLinesAmount() {
        return linesAmount;
    }

    /**
     * Gets a bet amount.
     * @return a bet amount
     */
    public BigDecimal getBetAmount() {
        return betAmount;
    }

    /**
     * Gets a credit amount.
     * @return a credit amount
     */
    public BigDecimal getCreditAmount() {
        return creditAmount;
    }
}
