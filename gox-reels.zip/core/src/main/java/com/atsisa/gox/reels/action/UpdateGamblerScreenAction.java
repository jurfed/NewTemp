package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.StateAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.UpdateGamblerScreenCommand;

/**
 * Requests a change in gambler screen so that they reflect given state.
 */
public class UpdateGamblerScreenAction extends StateAction {

    /**
     * Initializes a new instance of the {@link UpdateGamblerScreenAction} class.
     */
    public UpdateGamblerScreenAction() {
    }

    /**
     * Initializes a new instance of the {@link UpdateGamblerScreenAction} class.
     * @param logger   The logger.
     * @param eventBus The event bus.
     */
    public UpdateGamblerScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new UpdateGamblerScreenCommand(actionData.getState()));
    }

}
