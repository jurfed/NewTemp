package com.atsisa.gox.reels.logic.vocs.serialization;

import com.atsisa.gox.framework.serialization.SerializationException;

/**
 * Represents an interface for serialization.
 * @param <T1> type of input into serialization procedure
 * @param <T2> type of output from serialization procedure
 */
@FunctionalInterface
public interface ISerializer<T1, T2> {

    /**
     * Serializes from specific input into specific output.
     * @param input an input to serialize
     * @return a result of serialization procedure
     * @throws SerializationException cannot serialize input
     */
    T2 serialize(T1 input) throws SerializationException;
}
