package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.Map;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.model.Language;
import com.atsisa.gox.reels.logic.vocs.serialization.PresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;

/**
 * Response strategy for translation presentation.
 */
public class TranslationSerializationStrategy implements IResponseSerializationStrategy<Map<String, String>> {

    /**
     * Name of the presentation which is supported by this strategy.
     */
    private static final String PRESENTATION_NAME = PresentationName.CHANGE_TRANSLATION;

    @Override
    public boolean isPresentationSupported(String presentationName, XmlObject xmlObject) {
        return PRESENTATION_NAME.contains(presentationName);
    }

    @Override
    public Map<String, String> serialize(XmlObject input) throws SerializationException {
        Language language = XmlDeserializer.deserializeLanguage(input);
        return language.getTranslation();
    }
}
