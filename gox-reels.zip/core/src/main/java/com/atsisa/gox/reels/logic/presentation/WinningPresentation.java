package com.atsisa.gox.reels.logic.presentation;

import java.math.BigDecimal;
import java.util.List;

import com.atsisa.gox.reels.IWinLineInfo;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a winning presentation for reel games.
 */
@Reflectable
public class WinningPresentation extends LogicPresentation {

    /**
     * The winning lines.
     */
    private final List<IWinLineInfo> winningLines;

    /**
     * The win amount.
     */
    private final BigDecimal winAmount;

    /**
     * Initializes a new instance of the {@link WinningPresentation} class.
     * @param name         the name of the presentation
     * @param winAmount    the win amount
     * @param winningLines the winning lines
     * @param resumed      a boolean value that indicates whether this presentation is resumed or not.
     * @param history      a boolean value that indicates whether this presentation is history or not.
     */
    public WinningPresentation(String name, BigDecimal winAmount, List<IWinLineInfo> winningLines, boolean resumed, boolean history) {
        super(name, resumed, history);
        this.winningLines = winningLines;
        this.winAmount = winAmount;
    }

    /**
     * Gets a win amount.
     * @return a win amount
     */
    public BigDecimal getWinAmount() {
        return winAmount;
    }

    /**
     * Gets a winning lines.
     * @return a winning lines
     */
    public List<IWinLineInfo> getWinningLines() {
        return winningLines;
    }
}
