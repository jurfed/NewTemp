package com.atsisa.gox.reels.logic.vocs;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.atsisa.gox.reels.logic.request.TakeWinRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;

import rx.Observable;

/**
 * Represents a logic that integrates with Novoprime services.
 */
public class NovoGameLogic extends AbstractGameLogic implements IReelGameLogic {

    /**
     * Mock game session.
     * TODO: This parameter will be passed on game start
     */
    private static final String MOCK_SESSION_TOKEN = "mock-game-session";

    /**
     * Vocs game instance uri template.
     */
    private static final String INIT_URI_TEMPLATE = "%s/api/GameSession/%s/gameplay";

    /**
     * Vocs game instance uri template.
     */
    private static final String GAMEPLAY_URI_TEMPLATE = "%s/api/GameSession/%s/gameplay/active";

    /**
     * The map of headers.
     */
    final Map<String, String> headers = new HashMap<>();

    /**
     * Initializes a new instance of the {@link NovoGameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configurationProvider   {@link IConfigurationProvider}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    public NovoGameLogic(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
            Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
        super(xmlParser, network, configurationProvider.getConfiguration(), presentationSerializers, platform);
        headers.put("Content-Type", "text/plain");
        headers.put("Accept", "text/xml");
    }

    @Override
    public Observable<Object> init(InitRequest initRequest) {
        return sendLogicRequest(initRequest, getInitUri(), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> bet(BetRequest betRequest) {
        return sendLogicRequest(betRequest, getGameplayUri(), HttpMethod.PUT, headers);
    }

    @Override
    public Observable<LogicPresentation> takeWin() {
        return sendLogicRequest(new TakeWinRequest(), getGameplayUri(), HttpMethod.PUT, headers);
    }

    @Override
    public Observable<LogicPresentation> gamble(GambleRequest gambleRequest) {
        return sendLogicRequest(gambleRequest, getGameplayUri(), HttpMethod.PUT, headers);
    }

    @Override
    public Observable<LogicPresentation> enterGambler(EnterGamblerRequest enterGamblerRequest) {
        return sendLogicRequest(enterGamblerRequest, getGameplayUri(), HttpMethod.PUT, headers);
    }

    /**
     * Gets gameplay uri.
     * @return a gameplay uri
     */
    protected String getGameplayUri() {
        return StringUtility.format(GAMEPLAY_URI_TEMPLATE, getPropertyValue(ReelConfigurationConstants.ENTRY_POINT_ADDRESS), MOCK_SESSION_TOKEN);
    }

    /**
     * Gets init uri.
     * @return a init uri
     */
    private String getInitUri() {
        return StringUtility.format(INIT_URI_TEMPLATE, getPropertyValue(ReelConfigurationConstants.ENTRY_POINT_ADDRESS), MOCK_SESSION_TOKEN);
    }
}
