package com.atsisa.gox.reels.command;

import java.util.List;

import com.atsisa.gox.reels.IWinLineInfo;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for show winning symbols on reels.
 */
@Reflectable
public final class StartAnimationWinningSymbolsCommand {

    /**
     * Contains information about winning lines.
     */
    private List<? extends IWinLineInfo> winningLines;

    /**
     * Initializes a new instance of the StartAnimationWinningSymbolsCommand class.
     * @param winningLines list with information about winning lines
     */
    public StartAnimationWinningSymbolsCommand(List<? extends IWinLineInfo> winningLines) {
        this.winningLines = winningLines;
    }

    /**
     * Gets list with information about winning lines.
     * @return list with information about winning lines
     */
    public List<? extends IWinLineInfo> getWinningLines() {
        return winningLines;
    }

}
