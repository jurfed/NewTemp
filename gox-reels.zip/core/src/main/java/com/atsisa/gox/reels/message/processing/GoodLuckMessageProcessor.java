package com.atsisa.gox.reels.message.processing;

import java.math.BigDecimal;
import java.util.List;

import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.model.IAccount;
import com.google.inject.Inject;

/**
 * Adjusts good luck messages according to player's latest translations.
 */
public class GoodLuckMessageProcessor implements IGameMessageProcessor {

    /**
     * Winner paid message.
     */
    private static final String WINNER_PAID_MESSAGE = "{#LangWinnerPaid}";

    /**
     * Good luck message.
     */
    private static final String GOOD_LUCK_MESSAGE = "{#LangGoodLuck}";

    /**
     * The account.
     */
    private final IAccount account;

    /**
     * Initializes a new instance of the {@link GoodLuckMessageProcessor}.
     * @param account The account reference.
     */
    @Inject
    public GoodLuckMessageProcessor(IAccount account) {
        this.account = account;
    }

    @Override
    public void process(GameMessage gameMessage) {
        if (gameMessage.getContent().equals(GOOD_LUCK_MESSAGE)) {
            BigDecimal latestTransaction = getLastWinningTransaction();
            if (latestTransaction != null) {
                String newMessage = StringUtility
                        .format("%s %s %s%s", WINNER_PAID_MESSAGE, account.getCreditsFormatter().formatWithCurrency(latestTransaction), "\n",
                                GOOD_LUCK_MESSAGE);
                gameMessage.setContent(newMessage);
            }
        }
    }

    /**
     * Gets the last winning transaction provided that it exists in a transaction history.
     * @return The last winning transation.
     */
    private BigDecimal getLastWinningTransaction() {
        List<BigDecimal> transactions = Iterables.toList(account.getTransactionHistory());
        if (!transactions.isEmpty()) {
            BigDecimal answer = transactions.get(0);
            if (answer.signum() == 1) {
                return answer;
            }
        }
        return null;
    }
}
