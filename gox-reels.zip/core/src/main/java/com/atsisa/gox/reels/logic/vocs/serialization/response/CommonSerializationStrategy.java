package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.vocs.serialization.PresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Response strategy for common presentations.
 */
public class CommonSerializationStrategy extends GroupSerializationStrategy<ReelGamePresentation> {

    /**
     * Used with IoC to define presentation names supported by this strategy.
     */
    public static final String COMMON_PRESENTATIONS = "CommonPresentations";

    @Inject(optional = true)
    @Override
    public void addSupportedPresentations(@Named(COMMON_PRESENTATIONS) Set<String> additionalSupportedPresentations) {
        super.addSupportedPresentations(additionalSupportedPresentations);
    }

    @Override
    protected void registerDefaultSupportedPresentations() {
        addPresentation(PresentationName.GAME_START);
        addPresentation(PresentationName.BASE_GAME_LOSE);
        addPresentation(PresentationName.BASE_GAME_WIN);
        addPresentation(PresentationName.BASE_GAME_LIMIT);
        addPresentation(PresentationName.OFFER_GAMBLER_TAKE_WIN);
        addPresentation(PresentationName.LIMIT_TAKE_WIN);
        addPresentation(PresentationName.ENTER_GAMBLER);
        addPresentation(PresentationName.GAMBLER_LOSE);
        addPresentation(PresentationName.GAMBLER_WIN);
        addPresentation(PresentationName.GAMBLER_TAKE_WIN);
        addPresentation(PresentationName.GAMBLER_LIMIT);
    }

    @Override
    protected ReelGamePresentation deserializePresentation(XmlObject xmlObject) {
        String presentationName = getPresentationName(xmlObject);
        return new ReelGamePresentation(presentationName, XmlDeserializer.deserializeGameplayProperties(xmlObject),
                XmlDeserializer.deserializeReels(xmlObject), isResumedPresentation(presentationName), isHistoryPresentation(xmlObject));
    }
}
