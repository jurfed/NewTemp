package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the gambler screen state change has been requested.
 */
@Reflectable
public final class UpdateGamblerScreenCommand {

    /**
     * A new state.
     */
    private final String state;

    /**
     * Initializes a new instance of the {@link UpdateGamblerScreenCommand}.
     * @param state The new state.
     */
    public UpdateGamblerScreenCommand(String state) {
        this.state = state;
    }

    /**
     * Gets the new state gambler screen should be updated to.
     * @return A new gambler screen state.
     */
    public String getState() {
        return state;
    }
}
