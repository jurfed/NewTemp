package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.message.GameMessageType;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when particular game message has changed.
 */
@Reflectable
public final class GameMessageChangedEvent extends AbstractEvent {

    /**
     * The most recent message related to {@link GameMessageType} object.
     */
    private final GameMessage message;

    /**
     * Initializes a new instance of the {@link GameMessageChangedEvent} class.
     * @param message message that has to be handled
     */
    public GameMessageChangedEvent(GameMessage message) {
        this.message = message;
    }

    /**
     * Gets the message contained in the event.
     * @return message related with
     */
    public GameMessage getMessage() {
        return message;
    }
}
