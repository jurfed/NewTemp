package com.atsisa.gox.reels.screen;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.ScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.command.ShowInfoScreenCommand;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

import rx.Subscription;

/**
 * Info screen base structure.
 */
@Reflect_Mini
public class InfoScreen extends Screen implements IResetable, IPauseable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "InfoScreenLayoutId";

    /**
     * Property name for rtp value.
     */
    private static final String RTP_VALUE_PROPERTY = "RTP_VALUE";

    /**
     * A transition reference.
     */
    private final InfoScreenTransition infoScreenTransition;

    /**
     * Hide animation data.
     */
    private TweenViewAnimationData hideScreenAnimationData;

    /**
     * A list of views.
     */
    private List<View> views;

    /**
     * Current screen index.
     */
    private int currentViewIndex;

    /**
     * Current screen animation.
     */
    private IViewAnimation currentViewAnimation;

    /**
     * Animation subscription.
     */
    private Subscription animationSubscription;

    /**
     * Initializes a new instance of the {@link InfoScreen} class.
     * @param layoutId             layout identifier
     * @param model                {@link ScreenModel}
     * @param renderer             {@link IRenderer}
     * @param viewManager          {@link IViewManager}
     * @param animationFactory     {@link IAnimationFactory}
     * @param logger               {@link ILogger}
     * @param eventBus             {@link IEventBus}
     * @param infoScreenTransition {@link InfoScreenTransition}
     */
    @Inject
    public InfoScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, InfoScreenTransition infoScreenTransition) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.infoScreenTransition = infoScreenTransition;
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        hideScreenAnimationData = createDefaultHideAnimationData();
        initTransition();
    }

    /**
     * Creates the default hide animation data.
     * @return the default hide animation data
     */
    protected TweenViewAnimationData createDefaultHideAnimationData() {
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(500F);
        animationData.setDestinationY(-1080F);
        return animationData;
    }

    /**
     * Sets the custom animation data for hide screens.
     * @param hideScreenAnimationData {@link TweenViewAnimationData}
     */
    public void setHideScreenAnimationData(TweenViewAnimationData hideScreenAnimationData) {
        this.hideScreenAnimationData = hideScreenAnimationData;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new InitResultObserver(), InitResult.class);
    }

    /**
     * Handles init response.
     * @param initResult {@link InitResult}
     */
    @Subscribe
    public void handleInitResponse(InitResult initResult) {
        getModel().setProperty(RTP_VALUE_PROPERTY, initResult.getGameConfiguration().getYield());
    }

    /**
     * Initializes the transition.
     */
    private void initTransition() {
        if (infoScreenTransition != null) {
            infoScreenTransition.setInfoScreen(this);
            infoScreenTransition.setAnimationFactory(getAnimationFactory());
        }
    }

    @Override
    protected void afterActivated() {
        views = new ArrayList<>();

        ViewGroup rootGroup = (ViewGroup) getLayout().getRootView();
        Iterable<View> filteredChildren = filterInfoScreenViews(rootGroup.getChildrenRaw());

        for (View view : filteredChildren) {
            if (view instanceof ViewGroup) {
                views.add(view);
                view.setVisible(false);
            }
        }

        currentViewIndex = 0;
        getView(currentViewIndex).setVisible(true);
    }

    /**
     * Filters info screen views.
     * @param views views to filter
     * @return filtered info screen views
     */
    protected Iterable<View> filterInfoScreenViews(Iterable<View> views) {
        return views;
    }

    /**
     * Handles the show info screen command.
     * @param showInfoScreenCommand {@link ShowInfoScreenCommand}
     */
    @Subscribe
    public void handleShowInfoScreenCommand(ShowInfoScreenCommand showInfoScreenCommand) {
        show(showInfoScreenCommand.getViewId(), showInfoScreenCommand.getShowViewAnimationData(), null, showInfoScreenCommand);
    }

    @Override
    protected void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback, Object triggeredEvent) {
        if (isActive()) {
            showNext(finishCallback, triggeredEvent);
        } else {
            super.show(viewAnimationData, finishCallback, triggeredEvent);
        }
    }

    /**
     * Adds the screen layout to the main stage and display specific info screen using specified effect.
     * <p>
     * If screen is active, then view animation data will be ignored and info screen transition will be used to switch between views.
     * </p>
     * @param viewId            the id of the view which should be shown
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param finishCallback    {@link IFinishCallback}
     */
    public void show(String viewId, TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback) {
        show(viewId, viewAnimationData, finishCallback, null);
    }

    /**
     * Adds the screen layout to the main stage and display specific info screen using specified effect.
     * <p>
     * If screen is active, then view animation data will be ignored and info screen transition will be used to switch between views.
     * </p>
     * @param viewId            the id of the view which should be shown
     * @param viewAnimationData {@link TweenViewAnimationData}
     * @param finishCallback    {@link IFinishCallback}
     * @param triggeredEvent    {@link Object}
     */
    protected void show(String viewId, TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback, Object triggeredEvent) {
        if (StringUtility.isNullOrEmpty(viewId)) {
            show(viewAnimationData, finishCallback, triggeredEvent);
            return;
        }
        if (isActive()) {
            showView(getViewIndex(viewId), finishCallback, triggeredEvent);
        } else {
            super.show(viewAnimationData, finishCallback, triggeredEvent);
            int viewIndex = getViewIndex(viewId);
            getView(viewIndex).setVisible(true);
            currentViewIndex = viewIndex;
        }
    }

    @Override
    protected void processScreenCommand(ScreenCommand screenCommand) {
        if (screenCommand instanceof ShowInfoScreenCommand) {
            ShowInfoScreenCommand showInfoScreenCommand = (ShowInfoScreenCommand) screenCommand;
            show(showInfoScreenCommand.getViewId(), showInfoScreenCommand.getShowViewAnimationData(), null, screenCommand);
        } else {
            super.processScreenCommand(screenCommand);
        }
    }

    /**
     * Gets the index of the specific view.
     * @param viewId the id of the view
     * @return index of the view
     */
    protected int getViewIndex(String viewId) {
        int viewIndex = 0;
        for (View view : views) {
            if (viewId.equals(view.getId())) {
                return viewIndex;
            }
            viewIndex++;
        }
        return -1;
    }

    /**
     * Gets the view at specific index position.
     * @param index index position of the view
     * @return view at specific index position
     */
    protected View getView(int index) {
        return views != null ? views.get(index) : null;
    }

    /**
     * Shows the next info screen.
     * @param callback {@link IFinishCallback}
     */
    protected void showNext(final IFinishCallback callback) {
        showNext(callback, null);
    }

    /**
     * Shows the next info screen.
     * @param callback       {@link IFinishCallback}
     * @param triggeredEvent {@link Object}
     */
    protected void showNext(final IFinishCallback callback, Object triggeredEvent) {
        int viewIndex = (currentViewIndex + 1) % views.size();
        if (!validateScreenTransition(viewIndex)) {
            return;
        }
        if (viewIndex < currentViewIndex) {
            hide(hideScreenAnimationData, callback);
            return;
        }
        showView(viewIndex, callback, triggeredEvent);
    }

    /**
     * Shows specific view.
     * @param viewIndex the index of the view
     * @param callback  {@link IFinishCallback}
     */
    protected void showView(int viewIndex, final IFinishCallback callback) {
        showView(viewIndex, callback, null);
    }

    /**
     * Shows specific view.
     * @param viewIndex      the index of the view
     * @param callback       {@link IFinishCallback}
     * @param triggeredEvent {@link Object}
     */
    protected void showView(int viewIndex, final IFinishCallback callback, final Object triggeredEvent) {
        if (!validateScreenTransition(viewIndex)) {
            return;
        }
        beforeShowView();
        final int previousViewIndex = currentViewIndex;
        currentViewIndex = viewIndex;
        notifyScreenShowing(triggeredEvent);

        final View previousView = getView(previousViewIndex);
        final View nextView = getView(currentViewIndex);
        infoScreenTransition.beforeTransition(previousViewIndex, previousView, currentViewIndex, nextView);
        nextView.setVisible(true);
        currentViewAnimation = infoScreenTransition.getTransition(previousViewIndex, previousView, currentViewIndex, nextView);
        animationSubscription = currentViewAnimation.getAnimationStateObservable().subscribe(new NextObserver<AnimationState>() {

            @Override
            public void onNext(AnimationState animationState) {
                if (animationState != AnimationState.STOPPED) {
                    return;
                }
                previousView.setVisible(false);
                infoScreenTransition.afterTransition(previousViewIndex, previousView, currentViewIndex, nextView);
                animationSubscription.unsubscribe();
                currentViewAnimation = null;
                notifyScreenShown(triggeredEvent);
                afterShowView();
                if (callback != null) {
                    callback.onFinish();
                }
            }
        });
        currentViewAnimation.play();
    }

    /**
     * Validates if view with specific index can be shown.
     * @param viewIndex the view index to show
     * @return a boolean value that indicates whether view with specific index can be shown
     */
    private boolean validateScreenTransition(int viewIndex) {
        if (currentViewAnimation != null || currentViewIndex == viewIndex) {
            getLogger().warn(StringUtility.format("Can not show view with index: %s, because view with that index is already shown", viewIndex));
            return false;
        }
        if (viewIndex >= views.size()) {
            throw new IllegalArgumentException(StringUtility
                    .format("Can not show info screen with index: %s, because it out of range. Available range is: 0-%s", viewIndex, views.size() - 1));
        }
        return true;
    }

    /**
     * Called when the view is about to be displayed.
     */
    protected void beforeShowView() {
    }

    /**
     * Called after the view transition has occurred.
     */
    protected void afterShowView() {
    }

    @Override
    @ExposeMethod
    public void reset() {
        beforeReset();

        if (isActive()) {
            if (currentViewAnimation != null) {
                currentViewAnimation.stop();
                currentViewAnimation = null;
            }
            if (currentViewIndex != 0) {
                currentViewIndex = 0;
                for (View view : views) {
                    view.setVisible(false);
                    view.setDepth(0);
                }
            }
            float hideAnimationTimeSpan = hideScreenAnimationData.getTimeSpan();
            hideScreenAnimationData.setTimeSpan(0F);
            hide(hideScreenAnimationData, null);
            hideScreenAnimationData.setTimeSpan(hideAnimationTimeSpan);
        }
        afterReset();
    }

    @Override
    @ExposeMethod
    public void pause() {
        if (currentViewAnimation != null) {
            currentViewAnimation.pause();
        }
    }

    /**
     * Called when the info screen is about to be reset.
     */
    protected void beforeReset() {
    }

    /**
     * Called when the info screen has been reset.
     */
    protected void afterReset() {
    }

    /**
     * Gets the info screen transition description object.
     * @return info screen transition description object
     */
    public InfoScreenTransition getInfoScreenTransition() {
        return infoScreenTransition;
    }

    /**
     * Gets current screen index.
     * @return current screen index
     */
    public int getCurrentViewIndex() {
        return currentViewIndex;
    }

    @Override
    protected void beforeDeactivated() {
        if (currentViewAnimation != null) {
            currentViewAnimation.stop();
            currentViewAnimation = null;
        }
        currentViewIndex = 0;
        views = null;
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(final InitResult initResult) {
            handleInitResponse(initResult);
        }
    }

}
