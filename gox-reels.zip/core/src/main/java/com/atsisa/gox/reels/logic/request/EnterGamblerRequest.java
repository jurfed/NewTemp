package com.atsisa.gox.reels.logic.request;

import java.math.BigDecimal;

/**
 * Represents an enter gambler request.
 */
public class EnterGamblerRequest {

    /**
     * The bet amount.
     */
    private final BigDecimal betAmount;

    /**
     * The lines amount.
     */
    private final Integer linesAmount;

    /**
     * Initializes a new instance of the {@link EnterGamblerRequest} class.
     * @param betAmount   a bet amount
     * @param linesAmount a lines amount
     */
    public EnterGamblerRequest(BigDecimal betAmount, Integer linesAmount) {
        this.betAmount = betAmount;
        this.linesAmount = linesAmount;
    }

    /**
     * Gets a bet amount.
     * @return a bet amount
     */
    public BigDecimal getBetAmount() {
        return betAmount;
    }

    /**
     * Gets a lines amount.
     * @return a lines amount
     */
    public Integer getLinesAmount() {
        return linesAmount;
    }
}
