package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.google.inject.Inject;

/**
 * A default implementation of the credits formatter.
 */
public class CreditsFormatter implements ICreditsFormatter {

    /**
     * Exception message when credits have not yet been set.
     */
    private static final String NULL_CREDITS_EXCEPTION_MESSAGE = "The credits cannot be null";

    /**
     * The number of decimal places.
     */
    private static final int DECIMAL_PLACES = 2;

    /**
     * The currency code.
     */
    private String currencyCode;

    /**
     * The localization.
     */
    private ILocalization localization;

    /**
     * Initializes a new instance of {@link CreditsFormatter} class.
     * @param localization ILocalization
     */
    @Inject
    public CreditsFormatter(ILocalization localization) {
        this.localization = localization;
    }

    @Override
    public String format(BigDecimal credits) {
        if (credits == null) {
            throw new IllegalArgumentException(NULL_CREDITS_EXCEPTION_MESSAGE);
        }
        return credits.setScale(DECIMAL_PLACES).toPlainString();
    }

    @Override
    public String format(BigDecimal credits, String decimalFormat) {
        if (credits == null) {
            throw new IllegalArgumentException(NULL_CREDITS_EXCEPTION_MESSAGE);
        }
        return localization.formatDecimalNumber(credits, decimalFormat);
    }

    @Override
    public String formatWithCurrency(BigDecimal credits) {
        String formattedCredits = format(credits);
        return addCurrency(formattedCredits);
    }

    @Override
    public String formatWithCurrency(BigDecimal credits, String decimalFormat) {
        String formattedCredits = format(credits, decimalFormat);
        return addCurrency(formattedCredits);
    }

    /**
     * Adds currency to formatted credits.
     * @param formattedCredits formatted credits
     * @return formatted credits with currency
     */
    private String addCurrency(String formattedCredits) {
        StringBuilder creditsBuilder = new StringBuilder(formattedCredits);
        if (currencyCode != null) {
            creditsBuilder.append(' ');
            creditsBuilder.append(currencyCode);
        }
        return creditsBuilder.toString();
    }

    @Override
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    @Override
    public String getCurrencyCode() {
        return currencyCode;
    }
}
