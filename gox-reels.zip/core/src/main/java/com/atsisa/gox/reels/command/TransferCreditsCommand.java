package com.atsisa.gox.reels.command;

import java.math.BigDecimal;

import com.atsisa.gox.reels.model.IAccount;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * A request for transferring credits to player's {@link IAccount}.
 */
@Reflect_Mini
public final class TransferCreditsCommand {

    /**
     * The amount of credits.
     */
    private final BigDecimal amount;

    /**
     * Initializes a new instance of the {@link TransferCreditsCommand} class.
     * @param amount The amount of credits to transfer.
     */
    public TransferCreditsCommand(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * Gets the amount of credits to transfer.
     * @return The amount of credits to transfer.
     */
    public BigDecimal getAmount() {
        return amount;
    }
}
