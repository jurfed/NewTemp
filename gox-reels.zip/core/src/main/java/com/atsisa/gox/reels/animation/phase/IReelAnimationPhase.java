package com.atsisa.gox.reels.animation.phase;

import com.atsisa.gox.framework.utility.ICloneable;

/**
 * Describe the general contract that animation phase implementation has to offer.
 */
public interface IReelAnimationPhase extends ICloneable<IReelAnimationPhase> {

    /**
     * Fetches the step of a given phase animation in accordance with passed delta time.
     * @param delta delta time
     * @return number of pixels that reel should be moved
     */
    float getStepOffset(float delta);

    /**
     * Gets a value whether the animation phase is finished or not
     * @return true in case when animation phase has finished, false otherwise.
     */
    boolean isFinished();

    /**
     * Resets the animation phase to its initial state. Should also stop it in case if it is running.
     */
    void reset();
}
