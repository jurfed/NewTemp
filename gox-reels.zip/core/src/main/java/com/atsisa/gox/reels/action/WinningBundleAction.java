package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.BundleAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.gwtent.reflection.client.Reflectable;

/**
 * Winning bundle will be executed when there is a win game.
 */
@Reflectable
public class WinningBundleAction extends BundleAction {

    /**
     * The lines model provider.
     */
    private final ILinesModelProvider linesModelProvider;

    /**
     * Initializes a new instance of the {@link WinningBundleAction} class.
     */
    public WinningBundleAction() {
        linesModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider();
    }

    /**
     * Initializes a new instance of the {@link WinningBundleAction} class.
     * @param logger             {@link ILogger}
     * @param eventBus           {@link IEventBus}
     * @param linesModelProvider {@link ILinesModelProvider}
     */
    public WinningBundleAction(ILogger logger, IEventBus eventBus, ILinesModelProvider linesModelProvider) {
        super(logger, eventBus);
        this.linesModelProvider = linesModelProvider;
    }

    @Override
    protected void validate() throws ValidationException {
        super.validate();
        if (!linesModelProvider.hasWinningLines()) {
            throw new ValidationException("The winning bundle will be not executed, because there is no win.");
        }
    }

}
