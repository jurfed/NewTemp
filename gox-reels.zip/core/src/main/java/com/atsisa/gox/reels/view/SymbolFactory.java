package com.atsisa.gox.reels.view;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;

/**
 * The default implementation of the symbol factory which create symbols from a prototypes.
 */
public final class SymbolFactory implements ISymbolFactory {

    /**
     * A map of symbol definitions.
     */
    private final Map<String, XmlObject> symbolDefinitions;

    /**
     * A map of verified symbols.
     */
    private final Map<String, AbstractSymbol> verifiedSymbols;

    /**
     * The view builder.
     */
    private final IViewBuilder viewBuilder;

    /**
     * Creates a new instance of the {@link SymbolFactory} class using given collection
     * as symbol prototypes.
     * @param viewBuilder The view builder.
     */
    public SymbolFactory(IViewBuilder viewBuilder) {
        if (viewBuilder == null) {
            throw new IllegalArgumentException("The view builder cannot be null.");
        }

        this.viewBuilder = viewBuilder;
        symbolDefinitions = new HashMap<>();
        verifiedSymbols = new HashMap<>();
    }

    /**
     * Adds a symbol definition to this factory.
     * @param symbolDefinition The symbol definition.
     * @throws IllegalArgumentException The symbol definition is null or is invalid.
     */
    public void addSymbolDefinition(XmlObject symbolDefinition) {
        if (symbolDefinition == null) {
            throw new IllegalArgumentException("The symbol definition cannot be null.");
        }

        AbstractSymbol symbol = createSymbol(symbolDefinition);

        if (symbolDefinitions.containsKey(symbol.getName())) {
            throw new IllegalArgumentException(StringUtility.format("Duplicated symbol definition detected. (symbolName: %s)", symbol.getName()));
        }

        symbolDefinitions.put(symbol.getName(), symbolDefinition);
        verifiedSymbols.put(symbol.getName(), symbol);
    }

    @Override
    public AbstractSymbol createSymbol(String symbolName) {
        // try to retrieve the symbol created when the addSymbolDefinition was called
        AbstractSymbol verifiedSymbol = verifiedSymbols.remove(symbolName);
        if (verifiedSymbol != null) {
            return verifiedSymbol;
        }

        // Fallback to symbol's definition
        XmlObject symbolDefinition = symbolDefinitions.get(symbolName);
        if (symbolDefinition != null) {
            return createSymbol(symbolDefinition);
        } else {
            String errorMessage = StringUtility.format("Requested symbol has no corresponding definition defined (symbolName: %s).", symbolName);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Creates a new symbol from given definition.
     * @param symbolDefinition The symbol definition.
     * @return A new symbol.
     */
    private AbstractSymbol createSymbol(XmlObject symbolDefinition) {
        Throwable internalError = null;
        try {
            AbstractSymbol answer = (AbstractSymbol) viewBuilder.createView(symbolDefinition, false);
            if (answer != null) {
                return answer;
            }
        } catch (ParseException | SerializationException | ClassCastException e) {
            internalError = e;
        }

        String errorMessage = StringUtility.format("Given symbol definition is invalid:\r\n%s", symbolDefinition.toXmlString());
        throw new IllegalArgumentException(errorMessage, internalError);
    }

    @Override
    public Iterable<String> getSymbolNames() {
        return symbolDefinitions.keySet();
    }
}
