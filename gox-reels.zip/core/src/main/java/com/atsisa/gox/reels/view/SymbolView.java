package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.TagBasedViewChildFilter;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.spi.IStatefulViewChildFilter;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

/**
 * Common symbol view.
 */
@XmlElement
public class SymbolView extends AbstractSymbol {

    /**
     * Views filter.
     */
    private IStatefulViewChildFilter viewChildFilter;

    /**
     * Initializes a new instance of the SymbolView class.
     */
    public SymbolView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the SymbolView class using custom renderer and action binder.
     * @param renderer {@link IRenderer}
     */
    public SymbolView(IRenderer renderer) {
        super(renderer);
        viewChildFilter = new TagBasedViewChildFilter();
    }

    @Override
    protected void stateChanged() {
        updateChildren();
    }

    /**
     * Sets new filter for children, that will be used when the state is changed.
     * @param viewChildFilter - IStatefulViewChildFilter
     */
    public void setViewChildFilter(IStatefulViewChildFilter viewChildFilter) {
        if (viewChildFilter != null) {
            this.viewChildFilter = viewChildFilter;
            updateChildren();
        }
    }

    /**
     * It is called when symbol state has been changed or new selector it has been set.
     */
    @SuppressWarnings("unchecked")
    private void updateChildren() {
        ObjectArrayList<View> children = getChildrenRaw();
        for (int i = 0; i < children.size(); i++) {
            View view = children.get(i);
            if (viewChildFilter.isValid(view, getState())) {
                showChild(view);
            } else {
                hideChild(view);
            }
        }
    }

    /**
     * Hides a specific child, if that child implements IViewAnimation then view animation will be stopped.
     * @param view - View
     */
    private void hideChild(View view) {
        view.setVisible(false);
        if (view instanceof IViewAnimation) {
            ((IViewAnimation) view).stop();
        }
    }

    /**
     * Shows a specific child, if that child implements IViewAnimation, then his animation will start playing.
     * @param view - View
     */
    private void showChild(View view) {
        view.setVisible(true);
        if (view instanceof IViewAnimation) {
            ((IViewAnimation) view).play();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void addChild(View child) {
        if (child == null) {
            throw new IllegalArgumentException("Child can not be null");
        }

        if (viewChildFilter.isValid(child, getState())) {
            showChild(child);
        } else {
            hideChild(child);
        }
        super.addChild(child);
    }

}
