package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.view.WinLineView;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * Defines a strategy for filtering {@link WinLineView}'s
 * children which should be activated or deactivated
 * to reflect current{@link WinLineState}.
 */
@FunctionalInterface
public interface IWinLineViewChildSelector {

    /**
     * Filters a collection of {@link WinLineView}'s child views
     * to determine which of them should be activated on given
     * {@link WinLineState}.
     * @param children A full list of child views.
     * @param state    Current {@link WinLineState}.
     * @return A filtered list of {@link WinLineView}'s child views.
     */
    Iterable<View> selectChildren(Iterable<View> children, WinLineState state);
}
