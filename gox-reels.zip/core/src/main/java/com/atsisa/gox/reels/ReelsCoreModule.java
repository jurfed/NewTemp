package com.atsisa.gox.reels;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.inject.AbstractModule;
import com.atsisa.gox.reels.controller.AutoStartController;
import com.atsisa.gox.reels.controller.BetController;
import com.atsisa.gox.reels.controller.GamblerController;
import com.atsisa.gox.reels.controller.InfoScreenController;
import com.atsisa.gox.reels.controller.LinesController;
import com.atsisa.gox.reels.controller.PresentationController;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.fsm.ReelGameStateHolder;
import com.atsisa.gox.reels.message.MessagesProvider;
import com.atsisa.gox.reels.message.processing.GoodLuckMessageProcessor;
import com.atsisa.gox.reels.message.processing.IGameMessageProcessor;
import com.atsisa.gox.reels.message.processing.LinePaysMessageProcessor;
import com.atsisa.gox.reels.message.processing.WinnerPaidMessageProcessor;
import com.atsisa.gox.reels.model.Account;
import com.atsisa.gox.reels.model.BetModelProvider;
import com.atsisa.gox.reels.model.CreditsFormatter;
import com.atsisa.gox.reels.model.DefaultRetryPolicy;
import com.atsisa.gox.reels.model.ErrorModelProvider;
import com.atsisa.gox.reels.model.GamblerModelProvider;
import com.atsisa.gox.reels.model.HistoryModelProvider;
import com.atsisa.gox.reels.model.IAccount;
import com.atsisa.gox.reels.model.IBetModelProvider;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IErrorModelProvider;
import com.atsisa.gox.reels.model.IGamblerModelProvider;
import com.atsisa.gox.reels.model.IHistoryModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.model.IRetryPolicy;
import com.atsisa.gox.reels.model.LinesModelProvider;
import com.atsisa.gox.reels.model.NoLinesModelMutator;
import com.atsisa.gox.reels.model.PayTableModelProvider;
import com.atsisa.gox.reels.model.ReelGameSoundModel;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.atsisa.gox.reels.screen.FadeScreen;
import com.google.inject.Singleton;
import com.google.inject.TypeLiteral;

/**
 * Represents an IoC module which defines reels core dependencies.
 */
public class ReelsCoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(BaseReelGameComponents.class).asEagerSingleton();
        bind(ICreditsFormatter.class).to(CreditsFormatter.class).asEagerSingleton();
        bind(ILinesModelProvider.class).to(LinesModelProvider.class).asEagerSingleton();
        bind(IAccount.class).to(Account.class).asEagerSingleton();
        bind(IBetModelProvider.class).to(BetModelProvider.class).asEagerSingleton();
        bind(IGamblerModelProvider.class).to(GamblerModelProvider.class).asEagerSingleton();
        bind(IRetryPolicy.class).to(DefaultRetryPolicy.class).asEagerSingleton();
        bind(IPayTableModelProvider.class).to(PayTableModelProvider.class).asEagerSingleton();
        bind(IErrorModelProvider.class).to(ErrorModelProvider.class).asEagerSingleton();
        bind(IHistoryModelProvider.class).to(HistoryModelProvider.class).asEagerSingleton();
        bind(MessagesProvider.class).asEagerSingleton();

        bind(AutoStartController.class).asEagerSingleton();
        bind(IAutoStartController.class).to(AutoStartController.class);

        bind(BetController.class).asEagerSingleton();
        bind(IBetController.class).to(BetController.class);

        bind(GamblerController.class).asEagerSingleton();
        bind(IGamblerController.class).to(GamblerController.class);

        bind(InfoScreenController.class).asEagerSingleton();
        bind(IInfoScreenController.class).to(InfoScreenController.class);

        bind(LinesController.class).asEagerSingleton();
        bind(ILinesController.class).to(LinesController.class);

        bind(PresentationController.class).asEagerSingleton();
        bind(IPresentationController.class).to(PresentationController.class);

        bind(new TypeLiteral<IMutator<ILinesModel>>(){}).to(NoLinesModelMutator.class);

        bindConstant().named(FadeScreen.LAYOUT_ID_PROPERTY).to(FadeScreen.DEFAULT_LAYOUT_ID_VALUE);
        bindConstant().named(ErrorScreen.LAYOUT_ID_PROPERTY).to(ErrorScreen.DEFAULT_LAYOUT_ID_VALUE);

        bind(Screen.class).to(ErrorScreen.class).asEagerSingleton();
        bind(Screen.class).to(FadeScreen.class).asEagerSingleton();

        bind(IReelGameStateHolder.class).to(ReelGameStateHolder.class).asEagerSingleton();
        bind(ReelGameSoundModel.class).asEagerSingleton();

        bind(IDisposable.class).to(ReelsDisposer.class).in(Singleton.class);

        bind(IGameMessageProcessor.class).to(LinePaysMessageProcessor.class).asEagerSingleton();
        bind(IGameMessageProcessor.class).to(GoodLuckMessageProcessor.class).asEagerSingleton();
        bind(IGameMessageProcessor.class).to(WinnerPaidMessageProcessor.class).asEagerSingleton();

        bind(IReelsPresentationStates.class).to(ReelsPresentationStates.class).asEagerSingleton();
    }
}
