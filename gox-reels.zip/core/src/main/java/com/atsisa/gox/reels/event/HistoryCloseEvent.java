package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when history was closed.
 */
@Reflectable
public class HistoryCloseEvent {
}