package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.Set;

import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.presentation.GamblerPresentation;
import com.atsisa.gox.reels.logic.vocs.serialization.PresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Response strategy for gambler presentations.
 */
public class GamblerSerializationStrategy extends GroupSerializationStrategy<GamblerPresentation> {

    /**
     * Used with IoC to define presentation names supported by this strategy.
     */
    public static final String GAMBLER_PRESENTATIONS = "GamblerPresentations";

    @Inject(optional = true)
    @Override
    public void addSupportedPresentations(@Named(GAMBLER_PRESENTATIONS) Set<String> additionalSupportedPresentations) {
        super.addSupportedPresentations(additionalSupportedPresentations);
    }

    @Override
    protected void registerDefaultSupportedPresentations() {
        addPresentation(PresentationName.ENTER_GAMBLER);
        addPresentation(PresentationName.GAMBLER_LOSE);
        addPresentation(PresentationName.GAMBLER_WIN);
        addPresentation(PresentationName.GAMBLER_TAKE_WIN);
        addPresentation(PresentationName.GAMBLER_LIMIT);
        addPresentation(PresentationName.LIMIT_TAKE_WIN);
        addPresentation(PresentationName.GAMBLER_TAKE_WIN);
    }

    @Override
    protected GamblerPresentation deserializePresentation(XmlObject xmlObject) {
        String presentationName = getPresentationName(xmlObject);
        return new GamblerPresentation(presentationName, XmlDeserializer.deserializeGamblerDescriptor(xmlObject),
                XmlDeserializer.deserializeGamblerWonAmount(xmlObject), XmlDeserializer.deserializeGamblerBidAmount(xmlObject),
                isResumedPresentation(presentationName), isHistoryPresentation(xmlObject));
    }
}
