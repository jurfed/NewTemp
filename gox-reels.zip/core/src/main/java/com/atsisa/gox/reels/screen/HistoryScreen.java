package com.atsisa.gox.reels.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.reels.command.ExitHistoryCommand;
import com.atsisa.gox.reels.command.ShowNextHistoryPageCommand;
import com.atsisa.gox.reels.command.ShowPreviousHistoryPageCommand;
import com.atsisa.gox.reels.event.HistoryModelChangedEvent;
import com.atsisa.gox.reels.model.IHistoryModel;
import com.atsisa.gox.reels.screen.model.HistoryScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents the history screen.
 */
@Reflectable
public class HistoryScreen extends Screen<HistoryScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "HistoryScreenLayoutId";

    /**
     * Name of the properties which is responsible if show next history page button is visible or not.
     */
    private static final String NEXT_PAGE_BUTTON_VISIBLE = "nextPageButtonVisible";

    /**
     * Name of the properties which is responsible if show previous history page button is visible or not.
     */
    private static final String PREVIOUS_PAGE_BUTTON_VISIBLE = "previousPageButtonVisible";

    /**
     * Reference to the localization.
     */
    private ILocalization localization;

    /**
     * Initializes a new instance of {@link HistoryScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link HistoryScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     * @param localization     {@link ILocalization}
     */
    @Inject
    public HistoryScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, HistoryScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, ILocalization localization) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.localization = localization;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        try {
            getEventBus().register(this);
        } catch (ReflectionException e) {
            getEventBus().post(new GeneralSystemException(e));
            getLogger().error(e.getMessage(), e);
        }
    }

    /**
     * Called when exit from history button will be invoked.
     */
    @ExposeMethod
    public void exitHistoryClicked() {
        getEventBus().post(new ExitHistoryCommand());
    }

    /**
     * Called when show previous history page button will be invoked.
     */
    @ExposeMethod
    public void showPreviousHistoryPageClicked() {
        getEventBus().post(new ShowPreviousHistoryPageCommand());
    }

    /**
     * Called when show next history page button will be invoked.
     */
    @ExposeMethod
    public void showNextHistoryPageClicked() {
        getEventBus().post(new ShowNextHistoryPageCommand());
    }

    /**
     * Updates visibility of buttons on layout.
     */
    private void updateButtonsVisibility() {
        getModel().setProperty(NEXT_PAGE_BUTTON_VISIBLE, Boolean.FALSE);
        getModel().setProperty(PREVIOUS_PAGE_BUTTON_VISIBLE, Boolean.FALSE);
        if (getModel().getCurrentHistoryPageNumber() < getModel().getTotalNumberHistoryPages()) {
            getModel().setProperty(NEXT_PAGE_BUTTON_VISIBLE, Boolean.TRUE);
        }
        if (getModel().getCurrentHistoryPageNumber() > 1) {
            getModel().setProperty(PREVIOUS_PAGE_BUTTON_VISIBLE, Boolean.TRUE);
        }
    }

    /**
     * Handles event with info about history model was changed.
     * @param historyModelChangedEvent {@link HistoryModelChangedEvent}
     */
    @Subscribe
    public void handleHistoryModelChangedEvent(HistoryModelChangedEvent historyModelChangedEvent) {
        IHistoryModel historyModel = historyModelChangedEvent.getHistoryModel();
        getModel().setTotalNumberHistoryPages(historyModel.getTotalNumberPages());
        getModel().setCurrentHistoryPageNumber(historyModel.getActivePageNumber());
        String historyPageDate = StringUtility.EMPTY;
        if (historyModel.getActivePageDate() != null) {
            historyPageDate = localization.formatDate(historyModel.getActivePageDate(), getModel().getHistoryDateFormat());
        }
        getModel().setCurrentHistoryPageDate(historyPageDate);
        updateButtonsVisibility();
        getModel().update();
    }
}
