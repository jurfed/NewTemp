package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.SpinReelsCommand;

/**
 * Request begin of the reel spinning.
 */
public class SpinReelsAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link SpinReelsAction} class.
     */
    public SpinReelsAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link SpinReelsAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public SpinReelsAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new SpinReelsCommand());
    }
}
