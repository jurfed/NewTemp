package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the last gambler selected card should be hidden.
 */
@Reflectable
public class HideSelectedGamblerCardCommand {

}
