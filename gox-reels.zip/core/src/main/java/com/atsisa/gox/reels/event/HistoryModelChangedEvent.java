package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.model.IHistoryModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when history model has changed.
 */
@Reflectable
public final class HistoryModelChangedEvent extends AbstractEvent {

    /**
     * The history model.
     */
    private final IHistoryModel historyModel;

    /**
     * Initializes a new instance of the {@link HistoryModelChangedEvent} class.
     * @param historyModel {@link IHistoryModel}
     */
    public HistoryModelChangedEvent(IHistoryModel historyModel) {
        this.historyModel = historyModel;
    }

    /**
     * Gets an object representing all crucial information
     * regarding the most recent game history configuration.
     * @return history model
     */
    public IHistoryModel getHistoryModel() {
        return historyModel;
    }
}