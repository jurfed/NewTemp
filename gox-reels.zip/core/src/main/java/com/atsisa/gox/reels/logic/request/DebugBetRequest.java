package com.atsisa.gox.reels.logic.request;

import java.math.BigDecimal;

/**
 * Represents a debug bet request.
 */
public class DebugBetRequest extends BetRequest {

    /**
     * The expected stop positions.
     */
    private final Iterable<Integer> stopPositions;

    /**
     * Initializes a new instance of the {@link DebugBetRequest} class.
     * @param betAmount     a bet amount
     * @param linesAmount   a lines amount
     * @param stopPositions an expected stop positions
     */
    public DebugBetRequest(BigDecimal betAmount, int linesAmount, Iterable<Integer> stopPositions) {
        super(betAmount, linesAmount);
        this.stopPositions = stopPositions;
    }

    /**
     * Gets an expected stop positions.
     * @return an expected stop positions
     */
    public Iterable<Integer> getStopPositions() {
        return stopPositions;
    }
}
