package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request to speed up the process of starting showing winning symbols.
 */
@Reflectable
public class TerminateStartsShowingWinningSymbolsCommand {

}
