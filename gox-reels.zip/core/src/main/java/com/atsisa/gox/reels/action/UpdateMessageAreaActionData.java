package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.reels.message.GameMessageType;

/**
 * Describes data for the {@link UpdateMessageAreaAction}.
 */
@XmlElement
public class UpdateMessageAreaActionData extends ActionData {

    /**
     * The message.
     */
    @XmlAttribute
    private String message;

    /**
     * Game message type.
     */
    @XmlAttribute
    private GameMessageType messageType;

    /**
     * Gets new bottom panel message.
     * @return new bottom panel message.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets new bottom panel message.
     * @param message new bottom panel message.
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Gets the message type.
     * @return The message type.
     */
    public GameMessageType getMessageType() {
        return messageType;
    }

    /**
     * Sets the message type.
     * @param messageType The message type.
     */
    public void setMessageType(GameMessageType messageType) {
        this.messageType = messageType;
    }
}
