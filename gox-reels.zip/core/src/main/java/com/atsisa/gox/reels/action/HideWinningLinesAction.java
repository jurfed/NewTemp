package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.HideWinningLinesCommand;

/**
 * Request for hiding all the winning lines.
 */
public class HideWinningLinesAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link HideWinningLinesAction} class.
     */
    public HideWinningLinesAction() {
    }

    /**
     * Initializes a new instance of the {@link HideWinningLinesAction} class.
     * @param logger   a logger reference.
     * @param eventBus an eventBus reference.
     */
    public HideWinningLinesAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new HideWinningLinesCommand());
    }
}
