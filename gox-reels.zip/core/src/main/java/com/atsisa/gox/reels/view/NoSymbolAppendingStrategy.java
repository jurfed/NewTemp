package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.reels.view.spi.ISymbolAppendingStrategy;

/**
 * A symbol appending strategy in which
 * no symbols are prepended or appended to stopping ones.
 */
public class NoSymbolAppendingStrategy implements ISymbolAppendingStrategy {

    /**
     * An empty list of symbol names.
     */
    private static final List<String> NO_SYMBOLS = new ArrayList<>();

    @Override
    public Iterable<String> getPrependedSymbols(Iterable<String> stoppingSymbols, Iterable<String> reelStrip, int reelStripPosition) {
        return NO_SYMBOLS;
    }

    @Override
    public Iterable<String> getAppendedSymbols(Iterable<String> stoppingSymbols, Iterable<String> reelStrip, int reelStripPosition) {
        return NO_SYMBOLS;
    }
}
