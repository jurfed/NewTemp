package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.view.View;

/**
 * Represents single gambler card view.
 */
@XmlElement
public class GamblerCardView extends AbstractGamblerCard {

    /**
     * View for reversed card.
     */
    private View reversedCard;

    /**
     * View for upright card.
     */
    private View uprightCard;

    /**
     * A boolean value that indicates whether this card is reversed or not.
     */
    private boolean reversed;

    /**
     * Card hide animation.
     */
    private TweenViewAnimation hideAnimation;

    /**
     * Card show animation.
     */
    private TweenViewAnimation showAnimation;

    /**
     * Hide flip animation data.
     */
    @XmlElement(name = "flipHideAnimation", type = TweenViewAnimationData.class)
    private TweenViewAnimationData flipHideAnimationData;

    /**
     * Show flip animation data.
     */
    @XmlElement(name = "flipShowAnimation", type = TweenViewAnimationData.class)
    private TweenViewAnimationData flipShowAnimationData;

    /**
     * Animation factory reference.
     */
    private IAnimationFactory animationFactory;

    /**
     * Listener to listen when the flip animation will be finished.
     */
    private IFinishCallback onFinishFlipCallback;

    /**
     * Initializes a new instance of the {@link GamblerCardView} class.
     */
    public GamblerCardView() {
        this(GameEngine.current().getRenderer(), GameEngine.current().getAnimationFactory());
    }

    /**
     * Initializes a new instance of the {@link GamblerCardView} class.
     * @param renderer         {@link IRenderer}
     * @param animationFactory {@link IAnimationFactory}
     */
    public GamblerCardView(IRenderer renderer, IAnimationFactory animationFactory) {
        super(renderer);
        this.animationFactory = animationFactory;
        reversed = true;
        initialize();
    }

    /**
     * invoked immediately after the new instance of the GamblerCardView will be created.
     */
    private void initialize() {
        initializeHideAnimation();
        initializeShowAnimation();
    }

    /**
     * Creates hide animation.
     */
    private void initializeHideAnimation() {
        hideAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        hideAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onHideAnimationComplete();
            }
        });
        hideAnimation.setTargetView(this);
    }

    /**
     * Creates show animation.
     */
    private void initializeShowAnimation() {
        showAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        showAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onShowAnimationComplete();
            }
        });
        showAnimation.setTargetView(this);
    }

    /**
     * Sets hide animation data.
     * @param flipHideAnimationData tween view animation data
     */
    public void setFlipHideAnimationData(TweenViewAnimationData flipHideAnimationData) {
        if (!hideAnimation.isStopped()) {
            throw new IllegalStateException("Can not set new data to flip hide animation tween, because it is not in stopped state");
        }
        this.flipHideAnimationData = flipHideAnimationData;
        hideAnimation.setViewAnimationData(flipHideAnimationData);
    }

    /**
     * Sets show animation data.
     * @param flipShowAnimationData tween view animation data
     */
    public void setFlipShowAnimationData(TweenViewAnimationData flipShowAnimationData) {
        if (!showAnimation.isStopped()) {
            throw new IllegalStateException("Can not set new data to show animation tween, because it is not in stopped state");
        }
        this.flipShowAnimationData = flipShowAnimationData;
        showAnimation.setViewAnimationData(flipShowAnimationData);
    }

    @Override
    public void setUprightCard(View uprightCard) {
        validateNewCardView(uprightCard);
        validateFlipState();
        if (this.uprightCard != null) {
            removeChild(this.uprightCard);
        }
        this.uprightCard = uprightCard;
        this.uprightCard.setVisible(!reversed);
        addChild(this.uprightCard);
    }

    @Override
    public boolean isReversed() {
        return reversed;
    }

    @Override
    public void setReversedCard(View reversedCard) {
        validateNewCardView(reversedCard);
        validateFlipState();
        if (this.reversedCard != null) {
            removeChild(this.reversedCard);
        }
        this.reversedCard = reversedCard;
        addChild(this.reversedCard);
        this.reversedCard.setVisible(reversed);
    }

    @Override
    public void showUprightCard() {
        reversed = false;
        updateCardVisibleSide();
    }

    @Override
    public void showReversedCard() {
        reversed = true;
        updateCardVisibleSide();
    }

    @Override
    public void flip(IFinishCallback onFinishCallback) {
        if (uprightCard == null) {
            throw new IllegalStateException("Can not flip card, because upright card was not set.");
        } else if (reversedCard == null) {
            throw new IllegalStateException("Can not flip card, because reversed card was not set.");
        }
        validateFlipState();
        this.onFinishFlipCallback = onFinishCallback;
        hideAnimation.play();
    }

    /**
     * Updates currently visible side of the card.
     */
    private void updateCardVisibleSide() {
        validateFlipState();
        if (reversedCard != null) {
            reversedCard.setVisible(reversed);
        }
        if (uprightCard != null) {
            uprightCard.setVisible(!reversed);
        }
    }

    /**
     * Called when show animation will be completed.
     */
    private void onShowAnimationComplete() {
        if (onFinishFlipCallback != null) {
            onFinishFlipCallback.onFinish();
        }
    }

    /**
     * Called when hide animation will be completed.
     */
    private void onHideAnimationComplete() {
        reversed = !reversed;
        updateCardVisibleSide();
        showAnimation.play();
    }

    /**
     * Validates new card view.
     * @param cardView new card view
     */
    private void validateNewCardView(View cardView) {
        if (cardView == null) {
            throw new IllegalArgumentException("Can not set new card view, because new card view is null");
        }
    }

    /**
     * Validates if this card is flipping or not.
     */
    private void validateFlipState() {
        if (!hideAnimation.isStopped() || !showAnimation.isStopped()) {
            throw new IllegalStateException("Can not perform any action until card is flipping");
        }
    }

    @Override
    public void reset() {
        hideAnimation.stop();
        showAnimation.stop();
        showReversedCard();
    }

    @Override
    public void pause() {
        hideAnimation.pause();
        showAnimation.pause();
    }
}
