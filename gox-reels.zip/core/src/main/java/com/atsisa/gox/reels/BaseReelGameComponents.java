package com.atsisa.gox.reels;

import java.util.Set;

import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.model.IAccount;
import com.atsisa.gox.reels.model.IBetModelProvider;
import com.atsisa.gox.reels.model.IErrorModelProvider;
import com.atsisa.gox.reels.model.IGamblerModelProvider;
import com.atsisa.gox.reels.model.IHistoryModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.message.MessagesProvider;
import com.atsisa.gox.reels.model.ReelGameSoundModel;
import com.google.inject.Inject;

/**
 * The container with the base reel game components.
 */
public class BaseReelGameComponents extends AbstractReelGameComponents {

    /**
     * An account reference.
     */
    private IAccount account;

    /**
     * A lines model provider.
     */
    private ILinesModelProvider linesModelProvider;

    /**
     * A bet model provider.
     */
    private IBetModelProvider betModelProvider;

    /**
     * A gambler model provider.
     */
    private IGamblerModelProvider gamblerModelProvider;

    /**
     * A pay table model provider.
     */
    private IPayTableModelProvider payTableModelProvider;

    /**
     * An error model provider.
     */
    private IErrorModelProvider errorModelProvider;

    /**
     * A history model provider.
     */
    private IHistoryModelProvider historyModelProvider;

    /**
     * A message provider.
     */
    private MessagesProvider messageProvider;

    /**
     * A reel game state holder reference.
     */
    private IReelGameStateHolder reelGameStateHolder;

    /**
     * A reel game sound model.
     */
    private ReelGameSoundModel reelGameSoundModel;

    /**
     * A reel game logic reference.
     */
    private IReelGameLogic reelGameLogic;

    /**
     * Collection of the available states in the game.
     */
    private Iterable<IReelsPresentationStates> reelsPresentationStates;

    /**
     * Gets the collection of the available states in the game.
     * @return the collection of the available states in the game.
     */
    public Iterable<IReelsPresentationStates> getReelsPresentationStates() {
        return reelsPresentationStates;
    }

    /**
     * Sets the collection of the available states in the game.
     * @param reelsPresentationStates the collection of the available states in the game.
     */
    @Inject
    public void setReelsPresentationStates(Set<IReelsPresentationStates> reelsPresentationStates) {
        this.reelsPresentationStates = reelsPresentationStates;
    }

    /**
     * Gets a reel game logic.
     * @return a reel game logic
     */
    public IReelGameLogic getReelGameLogic() {
        return reelGameLogic;
    }

    /**
     * Sets a reel game logic.
     * @param reelGameLogic {@link IReelGameLogic}
     */
    @Inject
    public void setReelGameLogic(IReelGameLogic reelGameLogic) {
        this.reelGameLogic = reelGameLogic;
    }

    /**
     * Gets a reel game state holder.
     * @return a reel game state holder
     */
    public IReelGameStateHolder getReelGameStateHolder() {
        return reelGameStateHolder;
    }

    /**
     * Sets a reel game state holder.
     * @param reelGameStateHolder {@link IReelGameStateHolder}
     */
    @Inject
    public void setReelGameStateHolder(IReelGameStateHolder reelGameStateHolder) {
        this.reelGameStateHolder = reelGameStateHolder;
    }

    /**
     * Gets a reel game sound model.
     * @return a reel game sound model
     */
    public ReelGameSoundModel getReelGameSoundModel() {
        return reelGameSoundModel;
    }

    /**
     * Sets a reel game sound model.
     * @param reelGameSoundModel {@link ReelGameSoundModel}
     */
    @Inject
    public void setReelGameSoundModel(ReelGameSoundModel reelGameSoundModel) {
        this.reelGameSoundModel = reelGameSoundModel;
    }

    /**
     * Gets a message provider.
     * @return a message provider
     */
    public MessagesProvider getMessageProvider() {
        return messageProvider;
    }

    /**
     * Sets a message provider.
     * @param messageProvider {@link MessagesProvider}
     */
    @Inject
    public void setMessageProvider(MessagesProvider messageProvider) {
        this.messageProvider = messageProvider;
    }

    /**
     * Gets a history model provider.
     * @return a history model provider
     */
    public IHistoryModelProvider getHistoryModelProvider() {
        return historyModelProvider;
    }

    /**
     * Sets a history model provider.
     * @param historyModelProvider {@link IHistoryModelProvider}
     */
    @Inject
    public void setHistoryModelProvider(IHistoryModelProvider historyModelProvider) {
        this.historyModelProvider = historyModelProvider;
    }

    /**
     * Gets an error model provider.
     * @return an error model provider
     */
    public IErrorModelProvider getErrorModelProvider() {
        return errorModelProvider;
    }

    /**
     * Sets an error model provider.
     * @param errorModelProvider {@link IErrorModelProvider}
     */
    @Inject
    public void setErrorModelProvider(IErrorModelProvider errorModelProvider) {
        this.errorModelProvider = errorModelProvider;
    }

    /**
     * Gets a pay table model provider reference.
     * @return a pay table model provider
     */
    public IPayTableModelProvider getPayTableModelProvider() {
        return payTableModelProvider;
    }

    /**
     * Sets a pay table model provider.
     * @param payTableModelProvider {@link IPayTableModelProvider}
     */
    @Inject
    public void setPayTableModelProvider(IPayTableModelProvider payTableModelProvider) {
        this.payTableModelProvider = payTableModelProvider;
    }

    /**
     * Gets a gambler model provider.
     * @return a gambler model provider
     */
    public IGamblerModelProvider getGamblerModelProvider() {
        return gamblerModelProvider;
    }

    /**
     * Sets a gambler model provider.
     * @param gamblerModelProvider {@link IGamblerModelProvider}
     */
    @Inject
    public void setGamblerModelProvider(IGamblerModelProvider gamblerModelProvider) {
        this.gamblerModelProvider = gamblerModelProvider;
    }

    /**
     * Gets a bet model provider.
     * @return a bet model provider
     */
    public IBetModelProvider getBetModelProvider() {
        return betModelProvider;
    }

    /**
     * Sets a bet model provider.
     * @param betModelProvider {@link IBetModelProvider}
     */
    @Inject
    public void setBetModelProvider(IBetModelProvider betModelProvider) {
        this.betModelProvider = betModelProvider;
    }

    /**
     * Gets a line model provider.
     * @return a line model provider
     */
    public ILinesModelProvider getLinesModelProvider() {
        return linesModelProvider;
    }

    /**
     * Sets a lines model provider.
     * @param linesModelProvider {@link ILinesModelProvider}
     */
    @Inject
    public void setLinesModelProvider(ILinesModelProvider linesModelProvider) {
        validateState();
        this.linesModelProvider = linesModelProvider;
    }

    /**
     * Gets an account.
     * @return an account
     */
    public IAccount getAccount() {
        return account;
    }

    /**
     * Sets an account.
     * @param account account
     */
    @Inject
    public void setAccount(IAccount account) {
        validateState();
        this.account = account;
    }

}
