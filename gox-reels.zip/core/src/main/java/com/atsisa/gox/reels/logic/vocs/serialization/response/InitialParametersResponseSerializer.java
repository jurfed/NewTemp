package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.reels.logic.vocs.InitialParametersResponse;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for initial parameters.
 */
public class InitialParametersResponseSerializer implements ISerializer<String, InitialParametersResponse> {

    /**
     * {@link IParser} reference.
     */
    private final IParser xmlParser;

    /**
     * Initializes new instance of the {@link InitialParametersResponseSerializer} class.
     * @param xmlParser {@link IParser}
     */
    public InitialParametersResponseSerializer(IParser xmlParser) {
        this.xmlParser = xmlParser;
    }

    @Override
    public InitialParametersResponse serialize(String input) throws SerializationException {
        XmlObject xmlObject;
        try {
            xmlObject = ((XmlObjectDocument)xmlParser.parse(input)).getDocumentElement();
        }catch (ParseException ex){
            throw new SerializationException("Cannot deserialize data to xml object.", ex);
        }

        Map<String, String> params = new HashMap<>();
        List<XmlObject> paramElemList = xmlObject.find("//parameter");
        for (XmlObject paramElem : paramElemList) {
            String key = paramElem.getAttributes().get("name");
            String value = paramElem.getValue();
            if (key != null) {
                params.put(key, value);
            }
        }
        return new InitialParametersResponse(params);
    }
}
