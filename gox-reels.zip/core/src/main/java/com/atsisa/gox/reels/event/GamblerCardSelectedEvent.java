package com.atsisa.gox.reels.event;

import com.atsisa.gox.reels.CardType;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when gambler card was selected.
 */
@Reflectable
public final class GamblerCardSelectedEvent {

    /**
     * Selected card type.
     */
    private CardType cardType;

    /**
     * Initializes a new instance of the {@link GamblerCardSelectedEvent} class.
     * @param cardType selected card type.
     */
    public GamblerCardSelectedEvent(CardType cardType) {
        this.cardType = cardType;
    }

    /**
     * Gets selected card type.
     * @return card type
     */
    public CardType getCardType() {
        return cardType;
    }
}
