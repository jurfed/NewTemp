package com.atsisa.gox.reels.action;

import com.atsisa.gox.reels.logic.IReelGameHistoryLogic;

/**
 * Sends a request to exit from the history.
 */
public class SendExitHistoryRequestAction extends AbstractInitRequestAction {

    @Override
    protected void sendInitRequest() {
        subscribeForResult(((IReelGameHistoryLogic) getGameLogic()).exitHistory(createInitRequest()));
    }

}
