package com.atsisa.gox.reels.model;

import com.atsisa.gox.reels.message.GameMessage;

/**
 * Represents the configuration of error.
 */
public class ErrorModel implements IErrorModel {

    /**
     * Reason for failing.
     */
    private Throwable cause;

    /**
     * Error message.
     */
    private GameMessage message;

    /**
     * Indicates retry button should be visible or not.
     */
    private boolean retry;

    @Override
    public Throwable getCause() {
        return cause;
    }

    @Override
    public GameMessage getMessage() {
        return message;
    }

    @Override
    public boolean isRetry() {
        return retry;
    }

    /**
     * Sets reason for failing.
     * @param cause reason for failing.
     */
    void setCause(Throwable cause) {
        this.cause = cause;
    }

    /**
     * Sets error message.
     * @param message error message.
     */
    void setMessage(GameMessage message) {
        this.message = message;
    }

    /**
     * Sets retry button visiblity.
     * @param retry retry button visiblity.
     */
    void setRetry(boolean retry) {
        this.retry = retry;
    }
}
