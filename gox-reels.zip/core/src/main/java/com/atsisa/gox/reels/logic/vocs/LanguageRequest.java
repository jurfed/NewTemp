package com.atsisa.gox.reels.logic.vocs;

/**
 * Represents a request for get translations.
 * Each translation is associated with a specific language code and wrapper name.
 */
public class LanguageRequest {

    /**
     * Language code.
     */
    private final String languageCode;

    /**
     * Wrapper name.
     */
    private final String gameIdentity;

    /**
     * Initializes a new instance of the {@link LanguageRequest} class.
     * @param languageCode the language code
     * @param wrapperName  the wrapper name
     */
    LanguageRequest(String languageCode, String wrapperName) {
        this.languageCode = languageCode;
        this.gameIdentity = wrapperName;
    }

    /**
     * Gets language code.
     * @return language code
     */
    public String getLanguageCode() {
        return this.languageCode;
    }

    /**
     * Gets wrapper name.
     * @return wrapper name
     */
    public String getGameIdentity() {
        return this.gameIdentity;
    }
}
