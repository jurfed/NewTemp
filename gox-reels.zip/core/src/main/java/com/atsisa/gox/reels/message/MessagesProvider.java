package com.atsisa.gox.reels.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.reels.command.ChangeGameMessageCommand;
import com.atsisa.gox.reels.event.GameMessageChangedEvent;
import com.atsisa.gox.reels.message.processing.IGameMessageProcessor;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * Handles all aspects related with providing messages.
 */
@Reflectable
public class MessagesProvider {

    /**
     * A map of recent messages.
     */
    private final Map<GameMessageType, GameMessage> messages;

    /**
     * Message processors.
     */
    private final List<IGameMessageProcessor> messageProcessors;

    /**
     * Event bus reference.
     */
    private IEventBus eventBus;

    /**
     * Initializes a new instance of {@link MessagesProvider} class.
     * @param eventBus reference of the event bus.
     */
    @Inject
    public MessagesProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        messages = new HashMap<>();
        messageProcessors = new ArrayList<>();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new ChangeGameMessageCommandObserver(), ChangeGameMessageCommand.class);
    }

    /**
     * Updates the message according to message command.
     * @param gameStateChangedEvent change message request.
     */
    @Subscribe
    public void handle(ChangeGameMessageCommand gameStateChangedEvent) {
        GameMessage message = new GameMessage(gameStateChangedEvent.getMessageType(), gameStateChangedEvent.getMessage());
        processMessage(message);
        storeMessage(message);
        notifyMessageChanged(gameStateChangedEvent, message);
    }

    /**
     * Gets a list of message processors responsible for altering messages before they are published.
     * @return The list of message processors.
     */
    public List<IGameMessageProcessor> getMessageProcessors() {
        return messageProcessors;
    }

    /**
     * Sets game message processors.
     * @param gameMessageProcessors game message processors
     */
    @Inject
    public void setMessageProcessors(Set<IGameMessageProcessor> gameMessageProcessors) {
        if (gameMessageProcessors != null) {
            gameMessageProcessors.forEach(messageProcessors::add);
        }
    }

    /**
     * Notifies certain message has been changed.
     * @param changeGameMessageCommand change message request.
     * @param message                  The game message.
     */
    private void notifyMessageChanged(ChangeGameMessageCommand changeGameMessageCommand, GameMessage message) {
        GameMessageChangedEvent event = new GameMessageChangedEvent(message);
        event.setSourceEvent(changeGameMessageCommand);
        eventBus.post(event);
    }

    /**
     * Stores the message in cache.
     * @param message The message to store.
     */
    private void storeMessage(GameMessage message) {
        messages.put(message.getMessageType(), message);
    }

    /**
     * Processes message using registered message processors.
     * @param message The message to process.
     */
    private void processMessage(GameMessage message) {
        for (IGameMessageProcessor processor : messageProcessors) {
            processor.process(message);
        }
    }

    private class ChangeGameMessageCommandObserver extends NextObserver<ChangeGameMessageCommand> {

        @Override
        public void onNext(ChangeGameMessageCommand changeGameMessageCommand) {
            handle(changeGameMessageCommand);
        }
    }
}
