package com.atsisa.gox.reels.controller;

import java.math.BigDecimal;

import com.atsisa.gox.reels.IWinLineInfo;

/**
 * Used to control current win value in the game, which is displayed to the user.
 */
public interface ICurrentWinController {

    /**
     * Increases the current win with given value.
     * @param value {@link BigDecimal}
     * @return new current win value
     */
    BigDecimal increase(BigDecimal value);

    /**
     * Increase the win with given win line info.
     * <p>
     * If the win was already increased by a specific win line, then win will be not increased second time.
     * </p>
     * @param winLineInfo {@link IWinLineInfo}
     * @return new current win value
     */
    BigDecimal increase(IWinLineInfo winLineInfo);

    /**
     * Sets the current win value.
     * <p>
     * Ignores current win value and win lines.
     * </p>
     * @param value new value for the current win
     * @return new current win
     */
    BigDecimal setCurrentWin(BigDecimal value);

    /**
     * Decreases the current win by a certain amount.
     * @param value {@link BigDecimal}
     * @return new current win value
     */
    BigDecimal decrease(BigDecimal value);

    /**
     * Gets the current win value.
     * @return the current win value
     */
    BigDecimal getCurrentWin();

    /**
     * Clears the current win value and information about win lines that already increased win.
     */
    void clear();

    /**
     * Clears the information about win lines that already increased win.
     */
    void clearWinLineInfo();

    /**
     * Clears the current win value.
     */
    void clearWin();
}
