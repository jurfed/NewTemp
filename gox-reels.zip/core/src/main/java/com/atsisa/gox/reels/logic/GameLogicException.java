package com.atsisa.gox.reels.logic;

/**
 * Represents the game logic exception.
 */
public class GameLogicException extends RuntimeException {

    /**
     * The error code.
     */
    private final int errorCode;

    /**
     * The game logic exception details.
     */
    private final String details;

    /**
     * Initializes a new instance of the {@link GameLogicException} class with given message.
     * @param errorCode the error code
     * @param message   the error message
     * @param details   the game logic exception details
     */
    public GameLogicException(int errorCode, String message, String details) {
        super(message);
        this.errorCode = errorCode;
        this.details = details;
    }

    /**
     * Initializes a new instance of the {@link GameLogicException} class with given message and cause.
     * @param errorCode the error code
     * @param message   the error message
     * @param details   the game logic exteption details
     * @param cause     the inner exception (reason)
     */
    public GameLogicException(int errorCode, String message, String details, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.details = details;
    }

    /**
     * Gets error code.
     * @return the error code
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * Gets game logic exception details.
     * @return the game logic exception details
     */
    public String getDetails() {
        return details;
    }
}
