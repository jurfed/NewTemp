package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.Map;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;
import com.gwtent.reflection.client.Reflectable;

/**
 * A symbol pool strategy which dynamically instantiates missing symbols as we go using
 * the symbol factory up to given limits per symbol name.
 */
@Reflectable
@XmlElement
public class DynamicSymbolPoolStrategy implements ISymbolPoolStrategy {

    /**
     * The maximal number of symbols per name.
     */
    private final int maximumSymbolsPerName;

    /**
     * Creates a new instance of the {@link DynamicSymbolPoolStrategy}
     * using an unlimited symbols quantity.
     */
    public DynamicSymbolPoolStrategy() {
        maximumSymbolsPerName = 0;
    }

    /**
     * Creates a new instance of the {@link DynamicSymbolPoolStrategy}
     * using given limit of symbols quantity per their names.
     * @param maximumSymbolsPerName The maximum number of symbols allowed to be created per symbol name.
     */
    public DynamicSymbolPoolStrategy(int maximumSymbolsPerName) {
        this.maximumSymbolsPerName = maximumSymbolsPerName;
    }

    @Override
    public Iterable<AbstractSymbol> initialize(ISymbolFactory symbolFactory) {
        return new ArrayList<>();
    }

    @Override
    public AbstractSymbol getMissingSymbol(ISymbolPool symbolPool, String symbolName) {
        if (maximumSymbolsPerName > 0) {
            int currentCount = symbolPool.getSymbolsCount(symbolName);
            if (currentCount >= maximumSymbolsPerName) {
                String errorMessage = StringUtility
                        .format("The symbol pool has been drained. Missing symbol: %s (The strategy does not allow to create any more symbols of given name. "
                                        + "Limit of %s exceeded)",
                                symbolName, maximumSymbolsPerName);
                throw new SymbolPoolException(errorMessage);
            }
        }

        return symbolPool.getSymbolFactory().createSymbol(symbolName);
    }

    @Override
    public void initializeConfiguration(Map<String, Object> configurationData) {
    }
}
