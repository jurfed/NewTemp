package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.LoopBundleAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.command.ResetWinningLinesCommand;
import com.atsisa.gox.reels.model.ILinesModelProvider;

/**
 * Iterates over inner actions winning lines count times.
 */
public class WinningLinesBundleAction extends LoopBundleAction {

    /**
     * The lines model provider.
     */
    private final ILinesModelProvider linesModelProvider;

    /**
     * Initializes a new instance of the {@link WinningLinesBundleAction} class.
     */
    public WinningLinesBundleAction() {
        linesModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider();
    }

    /**
     * Initializes a new instance of the {@link WinningLinesBundleAction} class.
     * @param logger             {@link ILogger}
     * @param eventBus           {@link IEventBus}
     * @param linesModelProvider {@link ILinesModelProvider}
     */
    public WinningLinesBundleAction(ILogger logger, IEventBus eventBus, ILinesModelProvider linesModelProvider) {
        super(logger, eventBus);
        this.linesModelProvider = linesModelProvider;
    }

    @Override
    protected void grabData() {
        super.grabData();
        Iterable<? extends IWinLineInfo> winLines = linesModelProvider.getLinesModel().getWinningLines();
        if (winLines != null) {
            setRepeatCount(Iterables.size(winLines));
        }
    }

    @Override
    protected void validate() throws ValidationException {
        super.validate();
        if (getRepeatCount() == 0) {
            throw new ValidationException("The WinningBundleAction must operate on at least one winning line. Zero given.");
        }
        resetWinningLines();
    }

    @Override
    public void terminate() {
        super.terminate();
        onLoopFinished();
    }

    @Override
    protected void onLoopFinished() {
        resetWinningLines();
    }

    /**
     * Sends command to reset winning lines.
     */
    private void resetWinningLines() {
        eventBus.post(new ResetWinningLinesCommand());
    }

}
