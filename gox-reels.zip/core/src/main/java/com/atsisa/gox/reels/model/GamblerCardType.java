package com.atsisa.gox.reels.model;

/**
 * Describes the possible types of cards.
 */
public final class GamblerCardType {

    /**
     * Empty card type.
     */
    public static final String NONE = "None";

    /**
     * Spades card type.
     */
    public static final String SPADES = "Spades";

    /**
     * Diamonds card type.
     */
    public static final String DIAMONDS = "Diamonds";

    /**
     * Hearts card type.
     */
    public static final String HEARTS = "Hearts";

    /**
     * Clubs card type.
     */
    public static final String CLUBS = "Clubs";

    /**
     * Protected constructor, prevents the creation of an instance of this class.
     */
    protected GamblerCardType() {
    }
}
