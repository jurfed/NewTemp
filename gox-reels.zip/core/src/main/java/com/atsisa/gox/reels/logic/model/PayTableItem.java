package com.atsisa.gox.reels.logic.model;

import java.math.BigDecimal;

/**
 * Represents an item of pay table.
 */
public class PayTableItem {

    /**
     * The name of item.
     */
    private final String name;

    /**
     * The score of item.
     */
    private final BigDecimal score;

    /**
     * The type of item.
     */
    private final String type;

    /**
     * Initializes a new instance of the {@link PayTableItem} class.
     * @param name  a name of item
     * @param score a score of item
     * @param type  a type of item
     */
    public PayTableItem(String name, BigDecimal score, String type) {
        this.name = name;
        this.score = score;
        this.type = type;
    }

    /**
     * Gets a name of item.
     * @return a name of item
     */
    public String getName() {
        return name;
    }

    /**
     * Gets a score of item.
     * @return a score of item
     */
    public BigDecimal getScore() {
        return score;
    }

    /**
     * Gets a type of item.
     * @return a type of item
     */
    public String getType() {
        return type;
    }
}
