package com.atsisa.gox.reels.action;

import java.math.BigDecimal;

import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.model.IBetModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.gwtent.reflection.client.Reflectable;

import rx.Observable;

/**
 * Abstract action class responsible for sending bet request to the game server.
 */
@Reflectable
public class SendBetRequestAction extends AbstractSendRequestAction {

    /**
     * Bet model provider.
     */
    private final IBetModelProvider betModelProvider;

    /**
     * Lines model provider.
     */
    private final ILinesModelProvider linesModelProvider;

    /**
     * Initializes a new instance of the {@link SendBetRequestAction} class.
     */
    public SendBetRequestAction() {
        betModelProvider = getGame().getBetModelProvider();
        linesModelProvider = getGame().getLinesModelProvider();
    }

    /**
     * Gets bet model provider.
     * @return bet model provider
     */
    protected IBetModelProvider getBetModelProvider() {
        return betModelProvider;
    }

    /**
     * Gets lines model provider.
     * @return lines model provider
     */
    protected ILinesModelProvider getLinesModelProvider() {
        return linesModelProvider;
    }

    @Override
    protected void execute() {
        BetRequest betRequest = createRequest();
        BigDecimal transferAmount = getBetModelProvider().getBetModel().getTotalBet().negate();
        eventBus.post(new TransferCreditsCommand(transferAmount));
        subscribeForResult(getResponse(betRequest));
    }

    /**
     * Creates and returns new bet request.
     * @return new bet request
     */
    protected BetRequest createRequest() {
        return new BetRequest(getBetModelProvider().getBetModel().getBetPerLine(), getLinesModelProvider().getLinesModel().getSelectedLines());
    }

    /**
     * Gets presentation response.
     * @param betRequest bet request
     * @return presentation response
     */
    protected Observable<LogicPresentation> getResponse(BetRequest betRequest) {
        return getGameLogic().bet(betRequest);
    }

    @Override
    protected void validate() throws ValidationException {
        super.validate();
        if (betModelProvider.getBetModel() == null) {
            throw new ValidationException("The bet model cannot be null.");
        }
        if (linesModelProvider.getLinesModel() == null) {
            throw new ValidationException("The lines model cannot be null.");
        }
    }

}
