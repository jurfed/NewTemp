package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request to spin the reels.
 */
@Reflectable
public final class SpinReelsCommand {

}
