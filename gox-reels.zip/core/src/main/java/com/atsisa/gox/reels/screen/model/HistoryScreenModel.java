package com.atsisa.gox.reels.screen.model;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * Contains all properties required to render a history screen.
 */
@Reflectable
public class HistoryScreenModel extends ScreenModel {

    /**
     * Contains information about what currently history page it is shown.
     */
    private final NamedProperty<Integer> currentHistoryPageNumber = new NamedProperty<>(Integer.class, "currentHistoryPageNumber", 0);

    /**
     * Contains information about number of total pages in history.
     */
    private final NamedProperty<Integer> totalNumberHistoryPages = new NamedProperty<>(Integer.class, "totalNumberHistoryPages", 0);

    /**
     * Contains information about date for current history page.
     */
    private final NamedProperty<String> currentHistoryPageDate = new NamedProperty<>(String.class, "currentHistoryPageDate", StringUtility.EMPTY);

    /**
     * Configuration reference.
     */
    private IConfigurationProvider configurationProvider;

    /**
     * Logger reference.
     */
    private ILogger logger;

    /**
     * Initializes a new instance of the {@link HistoryScreenModel} class.
     *
     * @param translator            {@link ITranslator}
     * @param configurationProvider {@link IConfigurationProvider}
     * @param logger                {@link ILogger}
     */
    @Inject
    public HistoryScreenModel(ITranslator translator, IConfigurationProvider configurationProvider, ILogger logger) {
        super(translator);
        registerProperties();
        this.configurationProvider = configurationProvider;
        this.logger = logger;
    }

    /**
     * Initializes a new instance of the {@link HistoryScreenModel} class.
     */
    public HistoryScreenModel() {
        this.configurationProvider = GameEngine.current().getConfigurationProvider();
        this.logger = GameEngine.current().getLogger();
        registerProperties();
    }

    /**
     * Registers custom history screen properties.
     */
    private void registerProperties() {
        registerProperty(currentHistoryPageNumber);
        registerProperty(totalNumberHistoryPages);
        registerProperty(currentHistoryPageDate);
    }

    /**
     * Gets the current history page number.
     *
     * @return the current history page number
     */
    public int getCurrentHistoryPageNumber() {
        return currentHistoryPageNumber.get();
    }

    /**
     * Gets the total number history pages.
     *
     * @return the total number history pages
     */
    public int getTotalNumberHistoryPages() {
        return totalNumberHistoryPages.get();
    }

    /**
     * Sets the current history page number.
     *
     * @param pageNumber page number
     */
    public void setCurrentHistoryPageNumber(int pageNumber) {
        currentHistoryPageNumber.set(pageNumber);
    }

    /**
     * Sets the total number history pages.
     *
     * @param totalPages total pages in history
     */
    public void setTotalNumberHistoryPages(int totalPages) {
        totalNumberHistoryPages.set(totalPages);
    }

    /**
     * Gets the current history page date.
     *
     * @return the current history page date.
     */
    public String getCurrentHistoryPageDate() {
        return currentHistoryPageDate.get();
    }

    /**
     * Sets the current history page date.
     *
     * @param historyPageDate the current history page date
     */
    public void setCurrentHistoryPageDate(String historyPageDate) {
        currentHistoryPageDate.set(historyPageDate);
    }

    /**
     * Gets the current history page date property.
     *
     * @return the current history page date property
     */
    public IObservableProperty<String> currentHistoryPageDate() {
        return currentHistoryPageDate;
    }

    /**
     * Gets the current history page number property.
     *
     * @return the current history page number property
     */
    public IObservableProperty<Integer> currentHistoryPageNumber() {
        return currentHistoryPageNumber;
    }

    /**
     * Gets the total number history pages property.
     *
     * @return the total number history pages property
     */
    public IObservableProperty<Integer> totalNumberHistoryPages() {
        return totalNumberHistoryPages;
    }

    /**
     * Gets a history date format from configuration.
     *
     * @return the history date format
     */
    public String getHistoryDateFormat() {
        Object property = configurationProvider.getConfiguration().getProperty(ReelConfigurationConstants.HISTORY_DATE_FORMAT);
        if (property != null) {
            return (String) property;
        } else {
            logger.warn("History date format has not been provided in configuration.");
        }
        return StringUtility.EMPTY;
    }
}
