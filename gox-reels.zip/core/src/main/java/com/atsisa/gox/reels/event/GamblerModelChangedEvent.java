package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when gambler model has changed.
 */
@Reflectable
public final class GamblerModelChangedEvent extends AbstractEvent {

    /**
     * The gambler model.
     */
    private final IGamblerModel gamblerModel;

    /**
     * Initializes a new instance of the GamblerModelChangedEvent class.
     * @param gamblerModel - IGamblerModel
     */
    public GamblerModelChangedEvent(IGamblerModel gamblerModel) {
        this.gamblerModel = gamblerModel;
    }

    /**
     * Gets an object representing all crucial information
     * regarding the most recent reel game gambler configuration.
     * @return IGamblerModel
     */
    public IGamblerModel getGamblerModel() {
        return gamblerModel;
    }
}
