package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for showing the next winning line.
 */
@Reflectable
public final class ShowNextWinningLineCommand {

}
