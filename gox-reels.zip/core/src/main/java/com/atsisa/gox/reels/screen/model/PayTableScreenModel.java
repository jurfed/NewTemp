package com.atsisa.gox.reels.screen.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * Contains all data for pay table screen.
 */
@Reflectable
public class PayTableScreenModel extends ScreenModel {

    /**
     * Configuration reference.
     */
    private IConfigurationProvider configurationProvider;

    /**
     * Credits formatter reference.
     */
    protected ICreditsFormatter creditsFormatter;

    /**
     * Contains all info about pay table elements.
     */
    private Map<String, BigDecimal> payTableDescription = new HashMap<>();

    /**
     * Initializes a new instance of the {@link PayTableScreenModel} class.
     *
     * @param translator            {@link ITranslator}
     * @param configurationProvider {@link IConfigurationProvider}
     * @param creditsFormatter      {@link ICreditsFormatter}
     */
    @Inject
    public PayTableScreenModel(ITranslator translator, IConfigurationProvider configurationProvider, ICreditsFormatter creditsFormatter) {
        super(translator);
        this.configurationProvider = configurationProvider;
        this.creditsFormatter = creditsFormatter;
    }

    /**
     * Initializes a new instance of the {@link PayTableScreenModel} class.
     */
    public PayTableScreenModel() {
        this.configurationProvider = GameEngine.current().getConfigurationProvider();
    }

    /**
     * Updates pay table values.
     * @param payTableItems list with pay table items
     */
    public void updatePayTableValues(List<IPayTableModelItem> payTableItems) {
        if (payTableItems != null) {
            for (IPayTableModelItem payTableModelItem : payTableItems) {
                addPayTableItemDescription(payTableModelItem.getName(), payTableModelItem.getValue());
            }
        }
        refresh();
    }

    /**
     * Adds the specific pay table item to the descriptions.
     * @param name the name of the pay table item
     * @param value {@link BigDecimal}
     */
    protected void addPayTableItemDescription(String name, BigDecimal value) {
        payTableDescription.put(name, value);
    }

    /**
     * Updates pay table item info.
     * @param name name of property
     * @param value for value for the property.
     */
    protected void updatePayTableItemInfo(String name, BigDecimal value) {
        String credits;
        String decimalFormat = getDecimalFormat();
        if (isCurrencyVisible()) {
            credits = creditsFormatter.formatWithCurrency(value, decimalFormat);
        } else {
            credits = creditsFormatter.format(value, decimalFormat);
        }
        setProperty(name, credits);
    }

    /**
     * Updates all values for the pay table values.
     */
    public void refresh() {
        payTableDescription.forEach(this::updatePayTableItemInfo);
    }

    /**
     * Gets a boolean value that indicates whether values with currency should be displayed on pay table or not.
     * @return a boolean value
     */
    public boolean isCurrencyVisible() {
        Object property = configurationProvider.getConfiguration().getProperty(ReelConfigurationConstants.DISPLAY_CURRENCY_ON_PAY_TABLE);
        if (property != null) {
            return (Boolean) property;
        }
        return false;
    }

    /**
     * Gets a format with what decimal values should be formatted.
     * @return a boolean value
     */
    protected String getDecimalFormat() {
        Object property = configurationProvider.getConfiguration().getProperty(ReelConfigurationConstants.DECIMAL_FORMAT_ON_PAY_TABLE);
        if (property != null) {
            return (String) property;
        }
        return StringUtility.EMPTY;
    }
}