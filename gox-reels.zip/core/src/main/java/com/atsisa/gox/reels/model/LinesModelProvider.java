package com.atsisa.gox.reels.model;

import java.math.BigDecimal;
import java.util.List;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.command.CleanWinningLinesCommand;
import com.atsisa.gox.reels.command.DecreaseLinesCommand;
import com.atsisa.gox.reels.command.HideWinningLinesCommand;
import com.atsisa.gox.reels.command.IncreaseLinesCommand;
import com.atsisa.gox.reels.command.NextLinesCommand;
import com.atsisa.gox.reels.command.PreviousLinesCommand;
import com.atsisa.gox.reels.command.ResetWinningLinesCommand;
import com.atsisa.gox.reels.command.SetLinesCommand;
import com.atsisa.gox.reels.command.ShowNextWinningLineCommand;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.google.inject.Inject;

/**
 * Handles all aspect of reel game lines configuration.
 */
public class LinesModelProvider implements ILinesModelProvider {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The lines model.
     */
    private LinesModel model;

    /**
     * Initializes a new instance of the {@link LinesModelProvider} class using the specified event bus to subscribe and post to.
     * @param eventBus {@link IEventBus}
     */
    @Inject
    public LinesModelProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        model = new LinesModel();
        registerEvents();
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        eventBus.register(new WinningPresentationObserver(), WinningPresentation.class);
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new ShowNextWinningLineObserver(), ShowNextWinningLineCommand.class);
        eventBus.register(new ResetWinningLinesObserver(), ResetWinningLinesCommand.class);
        eventBus.register(new HideWinningLinesObserver(), HideWinningLinesCommand.class);
        eventBus.register(new IncreaseLineObserver(), IncreaseLinesCommand.class);
        eventBus.register(new DecreaseLineObserver(), DecreaseLinesCommand.class);
        eventBus.register(new ReelGamePresentationObserver(), ReelGamePresentation.class);
        eventBus.register(new CleanWinningLinesCommandObserver(), CleanWinningLinesCommand.class);
        eventBus.register(new NextLinesCommandObserver(), NextLinesCommand.class);
        eventBus.register(new PreviousLinesCommandObserver(), PreviousLinesCommand.class);
        eventBus.register(new SetLineObserver(), SetLinesCommand.class);
    }

    @Override
    public LinesModel getLinesModel() {
        return model;
    }

    @Override
    public boolean hasWinningLines() {
        return getLinesModel().getWinningLines() != null && Iterables.size(getLinesModel().getWinningLines()) > 0;
    }

    @Override
    public BigDecimal getTotalWinAmount() {
        BigDecimal totalWinAmount = BigDecimal.ZERO;
        if (hasWinningLines()) {
            totalWinAmount = countWin(getLinesModel().getWinningLines());
        }
        return totalWinAmount;
    }

    /**
     * Counts the total win from a specific winning lines.
     * @param winningLines the winning lines
     * @return the total win value
     */
    protected BigDecimal countWin(Iterable<? extends IWinLineInfo> winningLines) {
        BigDecimal win = BigDecimal.ZERO;
        for (IWinLineInfo winLineInfo : winningLines) {
            win = win.add(winLineInfo.getScore());
        }
        return win;
    }

    /**
     * Updates the lines model according to given init response.
     * @param initResult The init response.
     */
    @Subscribe
    public void handleInitResult(InitResult initResult) {
        model.updateAvailableLines(initResult.getGameConfiguration().getLines());
        notifyModelChanged(initResult, LinesModelChangedEvent.AVAILABLE_LINES);
    }

    /**
     * Handles the reel game presentation.
     * @param reelGamePresentation {@link ReelGamePresentation}
     */
    @Subscribe
    public void handleReelGamePresentation(ReelGamePresentation reelGamePresentation) {
        int linesAmount = reelGamePresentation.getGameplayProperties().getLinesAmount();
        if (linesAmount == model.getSelectedLines()) {
            return;
        }
        model.updateLinesAmount(linesAmount);
        notifyModelChanged(reelGamePresentation, LinesModelChangedEvent.AVAILABLE_LINES);
    }

    /**
     * Handles all presentation responses.
     * @param winningPresentation The presentation response to handle.
     */
    @Subscribe
    public void handleWinningPresentation(WinningPresentation winningPresentation) {
        if (updateWinningLines(winningPresentation.getWinningLines())) {
            model.resetCurrentWinningLine();
            notifyModelChanged(winningPresentation, LinesModelChangedEvent.WINNING_LINES);
        }
    }

    /**
     * Handles show next winning line command.
     * @param showNextWinningLineCommand The show next winning line command.
     */
    @Subscribe
    public void handleShowNextWinningLineCommand(ShowNextWinningLineCommand showNextWinningLineCommand) {
        if (model != null && model.changeCurrentWinningLineToNext()) {
            notifyModelChanged(showNextWinningLineCommand, LinesModelChangedEvent.CURRENT_WINNING_LINE);
        }
    }

    /**
     * Handles reset winning lines command.
     * @param resetWinningLinesCommand The reset winning lines command.
     */
    @Subscribe
    public void handleResetWinningLinesCommand(ResetWinningLinesCommand resetWinningLinesCommand) {
        if (model != null && model.resetCurrentWinningLine()) {
            notifyModelChanged(resetWinningLinesCommand, LinesModelChangedEvent.CURRENT_WINNING_LINE);
        }
    }

    /**
     * Handles hide winning lines command.
     * @param hideWinningLinesCommand The hide winning lines command.
     */
    @Subscribe
    public void handleHideWinningLinesCommand(HideWinningLinesCommand hideWinningLinesCommand) {
        if (model != null && model.clearCurrentWinningLine()) {
            notifyModelChanged(hideWinningLinesCommand, LinesModelChangedEvent.CURRENT_WINNING_LINE);
        }
    }

    /**
     * Increases the number of active lines if possible.
     * @param increaseLinesCommand The increase lines command.
     */
    @Subscribe
    public void handleIncreaseLinesCommand(IncreaseLinesCommand increaseLinesCommand) {
        if (model != null && model.increaseSelectedLines()) {
            notifyModelChanged(increaseLinesCommand, LinesModelChangedEvent.SELECTED_LINES);
        }
    }

    /**
     * Decreases the number of active lines if possible.
     * @param decreaseLinesCommand The increase lines command.
     */
    @Subscribe
    public void handleDecreaseLinesCommand(DecreaseLinesCommand decreaseLinesCommand) {
        if (model != null && model.decreaseSelectedLines()) {
            notifyModelChanged(decreaseLinesCommand, LinesModelChangedEvent.SELECTED_LINES);
        }
    }

    /**
     * Set the number of active lines to given amount.
     * @param setLinesCommand The set lines command.
     */
    @Subscribe
    public void handleSetLinesCommand(SetLinesCommand setLinesCommand) {
        if (model != null) {
            model.updateLinesAmount(setLinesCommand.getLinesAmount());
            notifyModelChanged(setLinesCommand, LinesModelChangedEvent.SELECTED_LINES);
        }
    }

    /**
     * Cleans the info about current winning lines.
     * @param cleanWinningLinesCommand {@link CleanWinningLinesCommand}
     */
    @Subscribe
    public void handleCleanWinningLinesCommand(CleanWinningLinesCommand cleanWinningLinesCommand) {
        if (model != null) {
            model.cleanWinningLines();
        }
    }

    /**
     * Increases the number of active lines. When current lines number reached the limit, the minimal lines value will be set.
     * @param nextLinesCommand - NextLinesCommand
     */
    @Subscribe
    public void handleNextLinesCommand(NextLinesCommand nextLinesCommand) {
        if (model == null) {
            return;
        }
        if (model.getSelectedLines() == (model.getMaxLines())) {
            model.updateLinesAmount(model.getMinLines());
        } else {
            model.increaseSelectedLines();
        }
        notifyModelChanged(nextLinesCommand, LinesModelChangedEvent.SELECTED_LINES);
    }

    /**
     * Decreases the number of active lines. When current lines number reached the limit, the maximal lines value will be set.
     * @param previousLinesCommand - PreviousLinesCommand
     */
    @Subscribe
    public void handlePreviousLinesCommand(PreviousLinesCommand previousLinesCommand) {
        if (model == null) {
            return;
        }

        if (model.getSelectedLines() == model.getMinLines()) {
            model.updateLinesAmount(model.getMaxLines());
        } else {
            model.decreaseSelectedLines();
        }
        notifyModelChanged(previousLinesCommand, LinesModelChangedEvent.SELECTED_LINES);
    }

    /**
     * Returns reference to the event bus
     * @return the event bus
     */
    protected IEventBus getEventBus() {
        return eventBus;
    }

    /**
     * Publishes an event regarding lines model changes.
     * @param sourceEvent The source message which changed.
     * @param changeType  The type of change.
     */
    protected void notifyModelChanged(Object sourceEvent, int changeType) {
        LinesModelChangedEvent event = new LinesModelChangedEvent(model, changeType);
        event.setSourceEvent(sourceEvent);
        eventBus.post(event);
    }

    /**
     * Updates winning lines according to the presentation response.
     * @param winningLines winning lines.
     * @return True if the winning lines have changed, false otherwise.
     */
    protected boolean updateWinningLines(List<? extends IWinLineInfo> winningLines) {
        if (shouldProcessWinningLines(winningLines)) {
            model.setWinningLines(winningLines);
            return true;
        }
        return false;
    }

    /**
     * Verifies that should process winning lines.
     * @param winningLines winning lines
     * @return true if should process winning lines, otherwise false
     */
    private boolean shouldProcessWinningLines(List<? extends IWinLineInfo> winningLines) {
        return !(winningLines.isEmpty() || Iterables.areEqual(winningLines, model.getWinningLines()));
    }

    private class IncreaseLineObserver extends NextObserver<IncreaseLinesCommand> {

        @Override
        public void onNext(IncreaseLinesCommand item) {
            handleIncreaseLinesCommand(item);
        }
    }

    private class DecreaseLineObserver extends NextObserver<DecreaseLinesCommand> {

        @Override
        public void onNext(DecreaseLinesCommand item) {
            handleDecreaseLinesCommand(item);
        }
    }

    private class SetLineObserver extends NextObserver<SetLinesCommand> {

        @Override
        public void onNext(SetLinesCommand item) {
            handleSetLinesCommand(item);
        }
    }

    private class WinningPresentationObserver extends NextObserver<WinningPresentation> {

        @Override
        public void onNext(WinningPresentation presentation) {
            handleWinningPresentation(presentation);
        }
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult initResult) {
            handleInitResult(initResult);
        }
    }

    private class ShowNextWinningLineObserver extends NextObserver<ShowNextWinningLineCommand> {

        @Override
        public void onNext(ShowNextWinningLineCommand item) {
            handleShowNextWinningLineCommand(item);
        }
    }

    private class ResetWinningLinesObserver extends NextObserver<ResetWinningLinesCommand> {

        @Override
        public void onNext(ResetWinningLinesCommand item) {
            handleResetWinningLinesCommand(item);
        }
    }

    private class HideWinningLinesObserver extends NextObserver<HideWinningLinesCommand> {

        @Override
        public void onNext(HideWinningLinesCommand item) {
            handleHideWinningLinesCommand(item);
        }
    }

    private class ReelGamePresentationObserver extends NextObserver<ReelGamePresentation> {

        @Override
        public void onNext(ReelGamePresentation item) {
            handleReelGamePresentation(item);
        }
    }

    private class CleanWinningLinesCommandObserver extends NextObserver<CleanWinningLinesCommand> {

        @Override
        public void onNext(CleanWinningLinesCommand cleanWinningLinesCommand) {
            handleCleanWinningLinesCommand(cleanWinningLinesCommand);
        }
    }

    private class NextLinesCommandObserver extends NextObserver<NextLinesCommand> {

        @Override
        public void onNext(NextLinesCommand nextLinesCommand) {
            handleNextLinesCommand(nextLinesCommand);
        }
    }

    private class PreviousLinesCommandObserver extends NextObserver<PreviousLinesCommand> {

        @Override
        public void onNext(PreviousLinesCommand previousLinesCommand) {
            handlePreviousLinesCommand(previousLinesCommand);
        }
    }
}
