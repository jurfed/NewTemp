package com.atsisa.gox.reels.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;

/**
 * Represents the configuration of reel game winning lines.
 */
public class LinesModel implements ILinesModel {

    /**
     * A collection of winning lines.
     */
    private List<? extends IWinLineInfo> winningLines = new LinkedList<>();

    /**
     * A collection of available line numbers.
     */
    private List<Integer> availableLines = new LinkedList<>();

    /**
     * The number of selected lines.
     */
    private int selectedLines;

    /**
     * The selected line index.
     */
    private int selectedLinesIndex;

    /**
     * Current win line info.
     */
    private IWinLineInfo currentWinLineInfo;

    /**
     * The next win line info index.
     */
    private int nextWinLineInfoIndex;

    /**
     * Initializes a new instance of the {@link LinesModel} class.
     */
    public LinesModel() {
        nextWinLineInfoIndex = 0;
    }

    /**
     * Updates the available lines.
     * @param availableLines list of the available lines
     */
    void updateAvailableLines(List<Integer> availableLines) {
        if (availableLines == null) {
            throw new IllegalArgumentException("The list of available lines is null");
        }
        this.availableLines = availableLines;
        update();
    }

    /**
     * Updates the lines amount.
     * @param selectedLines  A number of selected lines.
     */
    void updateLinesAmount(int selectedLines) {
        this.selectedLines = selectedLines;
        update();
    }

    /**
     * Updates model.
     */
    private void update() {
        if (availableLines.isEmpty() || selectedLines == 0) {
            return;
        }
        selectedLinesIndex = getSelectedLinesIndex();
        if (selectedLinesIndex == -1) {
            throw new IllegalArgumentException("The number of selected lines must exist on the list of available lines.");
        }
    }

    /**
     * Changes current winning line info to next.
     */
    boolean changeCurrentWinningLineToNext() {
        if (winningLines == null || winningLines.isEmpty()) {
            return false;
        }
        currentWinLineInfo = winningLines.get(nextWinLineInfoIndex);
        nextWinLineInfoIndex++;
        if (nextWinLineInfoIndex >= winningLines.size()) {
            nextWinLineInfoIndex = 0;
        }
        return true;
    }

    /**
     * Gets the index of a currently showing win line.
     * @return the index of a currently showing win line
     */
    int getCurrentWinLineIndex() {
        if (currentWinLineInfo == null || winningLines.isEmpty()) {
            return -1;
        }
        return winningLines.indexOf(currentWinLineInfo);
    }

    /**
     * Resets current winning line.
     * @return true if successfully reset
     */
    boolean resetCurrentWinningLine() {
        nextWinLineInfoIndex = 0;
        return clearCurrentWinningLine();
    }

    /**
     * Cleans all info about winning lines.
     */
    void cleanWinningLines() {
        winningLines = null;
        resetCurrentWinningLine();
    }

    /**
     * Clears current winning line.
     * @return true if cleared successfully
     */
    public boolean clearCurrentWinningLine() {
        if (currentWinLineInfo == null) {
            return false;
        }
        currentWinLineInfo = null;
        return true;
    }

    @Override
    public Optional<IWinLineInfo> getCurrentWinningLine() {
        return Optional.ofNullable(currentWinLineInfo);
    }

    @Override
    public int getSelectedLines() {
        return selectedLines;
    }

    @Override
    public List<Integer> getAvailableLines() {
        return availableLines;
    }

    @Override
    public int getMaxLines() {
        return Iterables.getLast(availableLines, 0);
    }

    @Override
    public int getMinLines() {
        return Iterables.getFirst(availableLines, 0);
    }

    @Override
    public Iterable<? extends IWinLineInfo> getWinningLines() {
        return winningLines;
    }

    /**
     * Sets currently active winning lines.
     * @param winningLines The winning lines.
     */
    void setWinningLines(List<? extends IWinLineInfo> winningLines) {
        if (winningLines == null) {
            throw new IllegalArgumentException("The winning lines collection is null");
        }
        this.winningLines = winningLines;
    }

    /**
     * Increases the number of selected lines.
     * @return True if the number of selected lines has changed, false otherwise.
     */
    boolean increaseSelectedLines() {
        if (selectedLinesIndex + 1 >= availableLines.size()) {
            return false;
        }
        selectedLinesIndex++;
        selectedLines = availableLines.get(selectedLinesIndex);
        return true;
    }

    /**
     * Decreases the number of selected lines.
     * @return True if the number of selected lines has changed, false otherwise.
     */
    boolean decreaseSelectedLines() {
        if (selectedLinesIndex - 1 < 0) {
            return false;
        }
        selectedLinesIndex--;
        selectedLines = availableLines.get(selectedLinesIndex);
        return true;
    }

    /**
     * Gets selected number of lines index.
     * @return An index in the available lines list.
     */
    private int getSelectedLinesIndex() {
        int index = 0;
        for (Integer line : availableLines) {
            if (line.equals(selectedLines)) {
                return index;
            }
            index++;
        }
        return -1;
    }

}
