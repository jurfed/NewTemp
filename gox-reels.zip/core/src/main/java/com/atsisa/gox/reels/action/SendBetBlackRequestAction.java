package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Sends bet black request during gambler.
 */
@Reflect_Mini
public class SendBetBlackRequestAction extends AbstractSendRequestAction {

    /**
     * Bet black selection name.
     */
    private static final String BET_BLACK_SELECTION_NAME = "BetBlack";

    /**
     * Sends black bet request.
     */
    @Override
    protected void execute() {
        subscribeForResult(getGameLogic().gamble(new GambleRequest(BET_BLACK_SELECTION_NAME)));
    }

}
