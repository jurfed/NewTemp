package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroupBase;

/**
 * An abstract reel class extends {@link View} and inherits from {@link IGamblerCard} interface.
 */
public abstract class AbstractGamblerCard extends ViewGroupBase implements IGamblerCard, IResetable, IPauseable {

    /**
     * Initializes a new instance of the {@link AbstractGamblerCard} class.
     */
    public AbstractGamblerCard() {
        super();
    }

    /**
     * Initializes a new instance of the {@link AbstractGamblerCard} class.
     * @param renderer {@link IRenderer}
     */
    public AbstractGamblerCard(IRenderer renderer) {
        super(renderer);
    }

}
