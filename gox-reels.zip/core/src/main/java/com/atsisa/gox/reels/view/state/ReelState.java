package com.atsisa.gox.reels.view.state;

import com.atsisa.gox.reels.view.IReel;

/**
 * Defines all possible states of {@link IReel} objects.
 */
public enum ReelState {
    /**
     * The reel is static and the stopped symbols are visible.
     */
    IDLE,
    /**
     * The reel is spinning, stopping sequence is yet unknown.
     */
    SPINNING,
    /**
     * The reel is spinning, the stopping sequence is known
     * and the reel is about to be stopped.
     */
    STOPPING,
}
