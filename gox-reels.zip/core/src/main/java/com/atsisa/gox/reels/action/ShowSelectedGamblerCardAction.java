package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.ShowSelectedGamblerCardCommand;
import com.atsisa.gox.reels.event.SelectedGamblerCardShownEvent;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.atsisa.gox.reels.model.IGamblerModelProvider;

/**
 * Requests to show gambler selected card.
 */
public class ShowSelectedGamblerCardAction extends WaitForEventAction<SelectedGamblerCardShownEvent> {

    /**
     * Gambler model provider reference.
     */
    private final IGamblerModelProvider gamblerModelProvider;

    /**
     * Last selected card.
     */
    private String lastSelectedCard;

    /**
     * Initializes a new instance of the {@link ShowSelectedGamblerCardAction} class.
     */
    public ShowSelectedGamblerCardAction() {
        gamblerModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getGamblerModelProvider();
    }

    /**
     * Initializes a new instance of the {@link ShowSelectedGamblerCardAction} class using custom gambler model
     * provider.
     * @param logger               a logger reference.
     * @param eventBus             an eventBus reference.
     * @param gamblerModelProvider a gambler model provider.
     */
    public ShowSelectedGamblerCardAction(ILogger logger, IEventBus eventBus, IGamblerModelProvider gamblerModelProvider) {
        super(logger, eventBus);
        this.gamblerModelProvider = gamblerModelProvider;
    }

    @Override
    protected void grabData() {
        IGamblerModel gamblerModel = gamblerModelProvider.getGamblerModel();
        Iterable<String> gamblerHistoryCards = gamblerModel.getGamblerHistory();
        lastSelectedCard = Iterables.getFirst(gamblerHistoryCards, StringUtility.EMPTY);
    }

    @Override
    protected void validate() throws IllegalArgumentException {
        if (StringUtility.EMPTY.equals(lastSelectedCard)) {
            throw new IllegalArgumentException("Can not show selected card in gambler, because none has been selected.");
        }
    }

    @Override
    protected void reset() {
        super.reset();
        lastSelectedCard = StringUtility.EMPTY;
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new ShowSelectedGamblerCardCommand(lastSelectedCard));
    }

    @Override
    protected Class<SelectedGamblerCardShownEvent> getEventClass() {
        return SelectedGamblerCardShownEvent.class;
    }
}
