package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for setting lines number.
 */
@Reflectable
public class SetLinesCommand extends UserInteractionCommand {

    /**
     * Lines amount
     */
    private final int lines;

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     * @param linesAmount     number of lines to set.
     */
    public SetLinesCommand(int linesAmount, boolean triggeredByUser) {
        super(triggeredByUser);
        this.lines = linesAmount;
    }

    /**
     * Get amount of the lines.
     * @return amount of lines to be set.
     */
    public int getLinesAmount() {
        return lines;
    }
}
