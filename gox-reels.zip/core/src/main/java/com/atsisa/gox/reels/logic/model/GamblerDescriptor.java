package com.atsisa.gox.reels.logic.model;

import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a descriptor of gambler.
 */
@Reflectable
public class GamblerDescriptor {

    /**
     * The collection of gambler history.
     */
    private final String[] gamblerHistory;

    /**
     * The size of gambler history.
     */
    private final int gamblerHistorySize;

    /**
     * Initializes a new instance of the {@link GamblerDescriptor} class.
     * @param gamblerHistory     a collection of gambler history
     * @param gamblerHistorySize a size of gambler history
     */
    public GamblerDescriptor(String[] gamblerHistory, int gamblerHistorySize) {
        this.gamblerHistory = gamblerHistory;
        this.gamblerHistorySize = gamblerHistorySize;
    }

    /**
     * Gets a collection of gambler history.
     * @return a collection of gambler history
     */
    public String[] getGamblerHistory() {
        return gamblerHistory;
    }

    /**
     * Gets a size of gambler history.
     * @return a size of gambler history
     */
    public int getGamblerHistorySize() {
        return gamblerHistorySize;
    }

}
