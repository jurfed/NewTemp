package com.atsisa.gox.reels.model;

import java.util.Set;

/**
 * Exposes the methods for reel strip definition providers.
 */
public interface IReelStripDefinitionProvider {

    /**
     * Gets reel strip definitions for specific type.
     * @param type type of reel strips definition
     * @return reel strip definitions for specific type
     */
    Iterable<ReelStripDefinition> getReelStripDefinitions(String type);

    /**
     * Gets reel strip definition for specific type and reel.
     * @param type       - String
     * @param reelNumber - int
     * @return ReelStripDefinition
     */
    ReelStripDefinition getReelStripDefinition(String type, int reelNumber);

    /**
     * Gets reel strip definition types.
     * @return the reel strip definition types
     */
    Set<String> getReelStripTypes();

    /**
     * Gets default reel strip definition type.
     * @return the default reel strip definition type
     */
    String getDefaultReelStripType();
}
