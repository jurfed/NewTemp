package com.atsisa.gox.reels.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.eventbus.UIDispatcherOnSubscribe;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.reels.logic.model.GamblerDescriptor;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.HistoryInfo;
import com.atsisa.gox.reels.logic.model.Language;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.logic.presentation.GamblerPresentation;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.atsisa.gox.reels.model.GamblerCardType;

import rx.Observable;

/**
 * Abstraction for game logic mockup.
 */
public abstract class AbstractGameLogicMockup implements IReelGameLogic, IReelGameHistoryLogic, ITranslationProvider {

    /**
     * English lang code.
     */
    private static final String ENGLISH_LANG_CODE = "EN";

    /**
     * German lang code.
     */
    private static final String GERMAN_LANG_CODE = "DE";

    /**
     * Credits value.
     */
    private BigDecimal credits;

    /**
     * Current game configuration.
     */
    private GameConfiguration gameConfiguration;

    /**
     * Last reel game presentations.
     */
    private List<LogicPresentation> lastLogicPresentations;

    /**
     * Current bet value.
     */
    private BigDecimal currentBet;

    /**
     * Current gambler win amount.
     */
    private BigDecimal currentGamblerWinAmount;

    /**
     * Current gambler play.
     */
    private int currentGamblerPlay;

    /**
     * Game history.
     */
    private List<HistoryPresentation> history;

    /**
     * Current gambler history.
     */
    private String[] currentGamblerHistory;

    /**
     * Localization reference.
     */
    private ILocalization localization;

    /**
     * Number of current lines amount.
     */
    private int currentLinesAmount;

    /**
     * Initializes a new instance of the {@link AbstractGameLogicMockup} class.
     * @param localization {@link ILocalization}
     */
    public AbstractGameLogicMockup(ILocalization localization) {
        this.localization = localization;
        this.credits = getStartCredits();
        this.gameConfiguration = getGameConfiguration();
        currentGamblerHistory = new String[] { GamblerCardType.NONE, GamblerCardType.NONE, GamblerCardType.NONE, GamblerCardType.NONE, GamblerCardType.NONE };
        history = new ArrayList<>();
        currentBet = getStartBetAmount();
        currentLinesAmount = getMaxLinesAmount();
    }

    /**
     * Gets the current game play properties.
     * @return the current game play properties
     */
    protected GameplayProperties getGameplayProperties() {
        return new GameplayProperties(getLinesAmount(), currentBet, credits);
    }

    /**
     * Gets start value for bet amount.
     * @return bet amount
     */
    protected abstract BigDecimal getStartBetAmount();

    /**
     * Gets the maximum number of available lines in the game.
     * @return the maximum number of available lines in the game
     */
    protected abstract int getMaxLinesAmount();

    /**
     * Gets the current selected lines amount in the game.
     * @return the current selected lines amount in the game
     */
    protected int getLinesAmount() {
        return currentLinesAmount;
    }

    protected BigDecimal getBetAmount() {
        return currentBet;
    }

    protected void setBetAmount(BigDecimal betAmount) {
        currentBet = betAmount;
    }

    protected void setLinesAmount(int linesAmount) {
        currentLinesAmount = linesAmount;
    }

    protected int getAmount() {
        return currentLinesAmount;
    }

    /**
     * Gets start credits value.
     * @return credits value
     */
    protected BigDecimal getStartCredits() {
        return new BigDecimal(100000);
    }

    @Override
    public Observable<Object> init(InitRequest initRequest) {
        return createObservable(getInitResult(initRequest.getLanguageCode()));
    }

    @Override
    public Observable<LogicPresentation> bet(BetRequest betRequest) {
        currentBet = betRequest.getBetAmount();
        currentLinesAmount = betRequest.getLinesAmount();
        BigDecimal newCredits = credits.subtract(currentBet.multiply(new BigDecimal(currentLinesAmount)));
        if (newCredits.compareTo(BigDecimal.ZERO) < 0) {
            throwError(2, "Not enough founds", "Not enough founds for bet.");
        }
        credits = newCredits;
        if (Math.random() < 0.5F) {
            return processPresentations(getWinningPresentations("BaseGameWin"));
        }
        return processPresentations(Collections.singletonList(getLosePresentation("BaseGameLose")));
    }

    /**
     * Gets the presentations related to win.
     * @param presentationName presentation name
     * @return presentations related to win.
     */
    protected abstract List<LogicPresentation> getWinningPresentations(String presentationName);

    /**
     * Gets the losing reel game presentation.
     * @param presentationName presentation name
     * @return the losing reel game presentation.
     */
    protected abstract ReelGamePresentation getLosePresentation(String presentationName);

    /**
     * Gets the game configuration.
     * @return the game configuration
     */
    protected abstract GameConfiguration getGameConfiguration();

    /**
     * Gets the common reel game presentation.
     * @param presentationName presentation name
     * @param reels            reels
     * @return the common reel game presentation.
     */
    protected ReelGamePresentation getReelGamePresentation(String presentationName, List<Reel> reels) {
        return new ReelGamePresentation(presentationName, getGameplayProperties(), reels, false, false);
    }

    @Override
    public Observable<LogicPresentation> takeWin() {
        String presentationName = "OfferGamblerTakeWin";
        WinningPresentation winningPresentation = getLastLogicPresentation(WinningPresentation.class);
        List<LogicPresentation> presentations = new ArrayList<>();
        if (currentGamblerWinAmount != null) {
            credits = credits.add(currentGamblerWinAmount);
            currentGamblerWinAmount = null;
            presentationName = "GamblerTakeWin";
            presentations.add(copyPresentation(getLastLogicPresentation(GamblerPresentation.class), presentationName, false, false));
        } else {
            credits = credits.add(winningPresentation.getWinAmount());
        }
        presentations.add(getCurrentReelGamePresentation(presentationName));
        presentations.add(copyPresentation(winningPresentation, presentationName, false, false));
        return processPresentations(presentations);
    }

    /**
     * Gets the last logic presentation of a certain type.
     * @param clazz presentation class type
     * @return the last presentation of a certain type
     */
    private <T extends LogicPresentation> T getLastLogicPresentation(Class<T> clazz) {
        if (lastLogicPresentations == null) {
            return null;
        }
        for (LogicPresentation logicPresentation : lastLogicPresentations) {
            if (logicPresentation.getClass() == clazz) {
                return (T) logicPresentation;
            }
        }
        return null;
    }

    /**
     * Process the reel game presentation.
     * @param presentations the logic presentations
     * @return the reel game presentation observable
     */
    private Observable<LogicPresentation> processPresentations(List<LogicPresentation> presentations) {
        lastLogicPresentations = presentations;
        history.add(new HistoryPresentation(presentations));
        return createObservable(presentations);
    }

    /**
     * Creates and returns new observable which will be dispatch in UI thread.
     * @param presentations the list of presentations to publish
     * @return the object observable
     */
    protected <T> Observable<T> createObservable(List<T> presentations) {
        return Observable.create(new UIDispatcherOnSubscribe<>(subscriber -> {
            try {
                presentations.forEach(subscriber::onNext);
            } catch (Exception ex) {
                subscriber.onError(ex);
            }
            subscriber.onCompleted();
        }));
    }

    @Override
    public Observable<Map<String, String>> getTranslation(String languageCode) {
        return createObservable(Collections.singletonList(getLanguage(languageCode).getTranslation()));
    }

    /**
     * Gets the init result.
     * @param activeLanguageCode active language code
     * @return init result
     */
    private List<Object> getInitResult(String activeLanguageCode) {
        List<Object> initResults = new ArrayList<>();
        if (!history.isEmpty()) {
            List<LogicPresentation> logicPresentations = history.get(history.size() - 1).getLogicPresentations();
            for (LogicPresentation logicPresentation : logicPresentations) {
                initResults.add(copyPresentation(logicPresentation, "R" + logicPresentation.getName(), true, false));
            }
        } else {
            initResults.add(getReelGamePresentation("GameStart", getStartReels()));
        }
        initResults.add(new InitResult(gameConfiguration, getLanguageInfo(activeLanguageCode)));
        return initResults;
    }

    /**
     * Copy and returns new reel game presentation.
     * @param logicPresentation {@link ReelGamePresentation}
     * @param name              new name for the copied presentation
     * @param resume            a boolean value that indicates whether this is resumed presentation or not
     * @param history           a boolean value that indicates whether this is history presentation or not
     * @return copied reel game presentation
     */
    protected LogicPresentation copyPresentation(LogicPresentation logicPresentation, String name, boolean resume, boolean history) {
        LogicPresentation newPresentation = null;
        if (logicPresentation instanceof GamblerPresentation) {
            newPresentation = new GamblerPresentation(name, ((GamblerPresentation) logicPresentation).getGamblerDescriptor(),
                    ((GamblerPresentation) logicPresentation).getWonAmount(), ((GamblerPresentation) logicPresentation).getBidAmount(), resume, history);
        } else if (logicPresentation instanceof WinningPresentation) {
            newPresentation = new WinningPresentation(name, ((WinningPresentation) logicPresentation).getWinAmount(),
                    ((WinningPresentation) logicPresentation).getWinningLines(), resume, history);
        } else if (logicPresentation instanceof ReelGamePresentation) {
            newPresentation = new ReelGamePresentation(name, ((ReelGamePresentation) logicPresentation).getGameplayProperties(),
                    ((ReelGamePresentation) logicPresentation).getReels(), resume, history);
        }
        return newPresentation;
    }

    /**
     * Gets start reels.
     * @return start reels
     */
    protected abstract List<Reel> getStartReels();

    /**
     * Throws game logic exception.
     * @param errorCode error code
     * @param message   error message
     * @param details   error details
     */
    private void throwError(int errorCode, String message, String details) {
        throw new GameLogicException(errorCode, message, details);
    }

    @Override
    public Observable<Object> history(HistoryRequest historyRequest) {
        if (history.isEmpty()) {
            throwError(29, "No history", "No history for this session");
        }
        if (historyRequest.getPageNumber() > history.size()) {
            throwError(29, "Wrong history page number",
                    StringUtility.format("Wrong history page number, number available history pages is: %s", history.size()));
        }
        int pageNumber = historyRequest.getPageNumber() - 1;
        if (pageNumber == -1) {
            pageNumber = history.size() - 1;
        }
        List<Object> historyResults = new ArrayList<>();
        HistoryPresentation historyPresentation = history.get(pageNumber);
        HistoryResult historyResult = new HistoryResult(new HistoryInfo(history.size(), localization.formatDate(historyPresentation.getDate())));
        historyResults.add(historyResult);
        for (LogicPresentation logicPresentation : historyPresentation.getLogicPresentations()) {
            historyResults.add(copyPresentation(logicPresentation, "R" + logicPresentation.getName(), false, true));
        }
        return createObservable(historyResults);
    }

    @Override
    public Observable<Object> exitHistory(InitRequest initRequest) {
        return createObservable(getInitResult(initRequest.getLanguageCode()));
    }

    @Override
    public Observable<LogicPresentation> enterGambler(EnterGamblerRequest enterGamblerRequest) {
        currentGamblerPlay = 0;
        String presentationName = "EnterGambler";
        List<LogicPresentation> presentations = new ArrayList<>();
        presentations.add(getCurrentReelGamePresentation(presentationName));
        WinningPresentation winningPresentation = (WinningPresentation) copyPresentation(getLastLogicPresentation(WinningPresentation.class), presentationName,
                false, false);
        presentations.add(winningPresentation);
        presentations
                .add(getGamblerPresentation(presentationName, winningPresentation.getWinAmount(), winningPresentation.getWinAmount(), StringUtility.EMPTY));
        return processPresentations(presentations);
    }

    @Override
    public Observable<LogicPresentation> gamble(GambleRequest gambleRequest) {
        currentGamblerPlay++;
        String presentationName = "GamblerLose";
        BigDecimal bidAmount = currentGamblerWinAmount;
        BigDecimal wonAmount = BigDecimal.ZERO;
        if (Math.random() < 0.5) {
            presentationName = "GamblerWin";
            bidAmount = currentGamblerWinAmount.multiply(new BigDecimal(2));
            if (bidAmount.compareTo(gameConfiguration.getGamblerWinLimit()) > 0) {
                bidAmount = gameConfiguration.getGamblerWinLimit();
                presentationName = "GamblerLimit";
            } else if (gameConfiguration.getGamblerPlayLimit() == currentGamblerPlay) {
                presentationName = "GamblerLimit";
            }
            wonAmount = bidAmount;
        }
        List<LogicPresentation> presentations = new ArrayList<>();
        presentations.add(getCurrentReelGamePresentation(presentationName));
        presentations.add(copyPresentation(getLastLogicPresentation(WinningPresentation.class), presentationName, false, false));
        presentations.add(getGamblerPresentation(presentationName, wonAmount, bidAmount, gambleRequest.getSelectionName()));
        return processPresentations(presentations);
    }

    /**
     * Returns the current reel game presentation.
     * @param name presentation name
     * @return the current reel game presentation
     */
    private ReelGamePresentation getCurrentReelGamePresentation(String name) {
        ReelGamePresentation lastReelGamePresentation = getLastLogicPresentation(ReelGamePresentation.class);
        return new ReelGamePresentation(name, getGameplayProperties(), lastReelGamePresentation.getReels(), false, false);
    }

    /**
     * Gets language info.
     * @param activeLanguageCode active language code
     * @return new language info
     */
    protected LanguageInfo getLanguageInfo(String activeLanguageCode) {
        List<String> availableLanguageCodes = new ArrayList<>();
        availableLanguageCodes.add(ENGLISH_LANG_CODE);
        availableLanguageCodes.add(GERMAN_LANG_CODE);
        return new LanguageInfo(getLanguage(activeLanguageCode), availableLanguageCodes);
    }

    /**
     * Gets the gambler presentation.
     * @param presentationName        gambler presentation name
     * @param wonAmount               won amount
     * @param bidAmount               bid amount
     * @param gamblerSelectedCardName gambler selected card name
     * @return the gambler presentation
     */
    private GamblerPresentation getGamblerPresentation(String presentationName, BigDecimal wonAmount, BigDecimal bidAmount, String gamblerSelectedCardName) {
        currentGamblerWinAmount = wonAmount;
        return new GamblerPresentation(presentationName, getGamblerDescriptor(presentationName, gamblerSelectedCardName), wonAmount, bidAmount, false, false);
    }

    /**
     * Gets the gambler descriptor.
     * @param presentationName gambler presentation name
     * @param selectedCardName selected gambler card name
     * @return the gambler descriptor
     */
    private GamblerDescriptor getGamblerDescriptor(String presentationName, String selectedCardName) {
        if (presentationName.equals("GamblerWin") || presentationName.equals("GamblerLimit")) {
            if (selectedCardName.equals("BetBlack")) {
                addGamblerHistoryCard(GamblerCardType.SPADES);
            } else {
                addGamblerHistoryCard(GamblerCardType.HEARTS);
            }
        } else if (presentationName.equals("GamblerLose")) {
            if (selectedCardName.equals("BetRed")) {
                addGamblerHistoryCard(GamblerCardType.SPADES);
            } else {
                addGamblerHistoryCard(GamblerCardType.HEARTS);
            }
        }
        return new GamblerDescriptor(currentGamblerHistory.clone(), 1);
    }

    /**
     * Adds the gambler card to the history.
     * @param cardName the card name
     */
    private void addGamblerHistoryCard(String cardName) {
        for (int i = currentGamblerHistory.length - 1; i >= 0; --i) {
            if (i > 0) {
                currentGamblerHistory[i] = currentGamblerHistory[i - 1];
            } else {
                currentGamblerHistory[i] = cardName;
            }
        }
    }

    /**
     * Gets the specific language.
     * @param languageCode language code
     * @return the language
     */
    private Language getLanguage(String languageCode) {
        Language language;
        switch (languageCode) {
            case ENGLISH_LANG_CODE:
                language = new Language(ENGLISH_LANG_CODE, getEnglishTranslation());
                break;
            case GERMAN_LANG_CODE:
                language = new Language(GERMAN_LANG_CODE, getGermanTranslation());
                break;
            default:
                language = new Language(ENGLISH_LANG_CODE, getEnglishTranslation());
        }
        return language;
    }

    /**
     * Gets the english translation.
     * @return the english translation
     */
    private Map<String, String> getEnglishTranslation() {
        Map<String, String> translation = new HashMap<>();
        translation.put("LangPlaceYourBet", "PLACE YOUR BET");
        translation.put("LangGoodLuck", "GOOD LUCK");
        translation.put("LangLineXPays", "PAYS");
        translation.put("LangGameOver", "GAME OVER");
        translation.put("LangGambleOrTakeWin", "GAMBLE OR TAKE WIN");
        translation.put("LangWinnerPaid", "WINNER PAID");
        translation.put("LangChooseBlackOrRedOrTakeWin", "CHOOSE RED OR BLACK OR TAKE WIN");
        translation.put("LangAstraWin", "WIN");
        translation.put("LangGambleCompleted", "GAMBLE COMPLETED");
        translation.put("LangGambleAmount", "GAMBLE AMOUNT");
        translation.put("LangPreviousCards", "PREVIOUS CARDS");
        translation.put("LangGambleToWin", "GAMBLE TO WIN");
        translation.put("LangWrapperHistory", "History");
        translation.put("LangAppears", "appears on the 2nd and 3rd reel");
        translation.put("LangSubstitutesFor", "substitutes for");
        translation.put("LangAllPrizesAreFor", "All prizes are for combinations left to right");
        translation.put("LangRules", "Rules");
        translation.put("LangRulesDescription",
                "All prizes are for combinations of a kind.\n" + "All prizes are for combinations left to right.\n" + "All prizes are on selected lines.\n"
                        + "Highest win only paid per selected line.\n" + "Malfunction voids all pays and plays.");
        translation.put("LangWinCombination", "Win combinations");
        translation.put("LangGamblerFeature", "Gamble Feature");
        translation.put("LangGamblerFeatureDescription", "After a winning game, you may have the chance to increase your win in the Gamble Feature.\n" + "\n"
                + "Click the \"Gamble\" button to start the Gamble Feature.\n"
                + "A deck of gamble cards appears containing an equal number of red or black cards.\n" + "\n"
                + "Choose red or black by clicking on the respective button. If your selected colour appears on the deck, your gamble amount is doubled and you may get a chance of another gamble step.\n"
                + "\n" + "If your choice does not match, the gamble amount is forfeited and the Gamble Feature ends.\n" + "\n"
                + "By pressing the \"Take\" button the Gamble Feature ends and the gamble amount will be added to your Credit meter.\n" + "\n"
                + "The Gamble Feature is limited to 5 gamble steps.");
        translation.put("LangYieldTitle", "Return to Player Percentage");
        translation.put("LangYieldValue", "Theoretical RTP:");
        translation.put("LangYieldDescription",
                "All game outcomes are independent and randomly determined. The actual RTP% is calculated as Total Win / Total Bet over a large number of games played and reflects the prizes awarded by a game as percentage of all bets made. The expected RTP% can vary widely in either direction for a small number of games due to the statistical variance.");
        translation.put("LangWrapperBalance", "CREDIT");
        translation.put("LangWrapperWin", "WIN");
        translation.put("LangWrapperBet", "Bet");
        translation.put("LangWrapperStart", "Start");
        translation.put("LangLine", "Line");
        translation.put("LangWrapperSkip", "Skip");
        translation.put("LangWrapperTake", "Take");
        translation.put("LangWrapperAutoStart", "Auto\nStart");
        translation.put("LangWrapperAutoStop", "Auto\nStop");
        translation.put("LangWrapperMaxBet", "Max\nBet");
        translation.put("LangBlack", "BLACK");
        translation.put("LangRed", "RED");
        translation.put("LangWrapperInfo", "Info");
        translation.put("LangWrapperSnapshot", "Snapshot");
        translation.put("LangWrapperGamble", "Gamble");
        return translation;
    }

    /**
     * Gets the german translation.
     * @return the german translation
     */
    private Map<String, String> getGermanTranslation() {
        Map<String, String> translation = new HashMap<>();
        translation.put("LangPlaceYourBet", "MACHEN SIE IHR SPIEL");
        translation.put("LangGoodLuck", "VIEL GLÜCK");
        translation.put("LangLineXPays", "ZAHLT");
        translation.put("LangGameOver", "SPIEL BEENDET");
        translation.put("LangGambleOrTakeWin", "RISIKO ODER GEWINN NEHMEN");
        translation.put("LangWinnerPaid", "GEWINN ZAHLT");
        translation.put("LangChooseBlackOrRedOrTakeWin", "ROT ODER SCHWARZ WÄHLEN ODER GEWINN NEHMEN");
        translation.put("LangAstraWin", "GEWINN");
        translation.put("LangGambleCompleted", "RISIKOSPIEL ABGESCHLOSSEN");
        translation.put("LangGambleAmount", "RISIKOBETRAG");
        translation.put("LangPreviousCards", "VORHERIGE KARTEN");
        translation.put("LangGambleToWin", "RISIKO GEWINN");
        translation.put("LangWrapperHistory", "Verlauf");
        translation.put("LangAppears", "erscheint auf dem 2. und 3. Walze");
        translation.put("LangSubstitutesFor", "ersetzt");
        translation.put("LangAllPrizesAreFor", "Alle Preise gelten für Kombinationen von links nach rechts");
        translation.put("LangRules", "Regeln");
        translation.put("LangRulesDescription",
                "Alle Preise sind für Kombinationen gleicher Art.\n" + "Alle Preise gelten für Kombinationen von links nach rechts.\n"
                        + "Alle Preise sind auf den gewählten Linien.\n" + "Nur der höchste Gewinn pro gewählter Linie zahlt.\n"
                        + "Fehlfunktion macht alle Spiele und Zahlungen ungültig.");
        translation.put("LangWinCombination", "Gewinnkombinationen");
        translation.put("LangGamblerFeature", "Risikospiel");
        translation.put("LangGamblerFeatureDescription", "Nach einem Gewinn-Spiel erhalten Sie die Chance, Ihren Gewinn im Risikospiel zu erhöhen.\n" + "\n"
                + "Klicken Sie auf \"Risiko\", um das Risikospiel zu starten.\n"
                + "Es erscheint ein Spielkartenstapel mit der gleichen Anzahl roter und schwarzer Karten.\n" + "\n"
                + "Wählen Sie rot oder schwarz, indem Sie auf die entsprechende Farbe klicken. Wenn die von Ihnen gewählte Farbe auf dem Stapel erscheint, wird Ihr Spielbetrag verdoppelt und Sie erhalten die Chance auf ein weiteres Risikospiel.\n"
                + "\n" + "Stimmt Ihre Auswahl nicht überein, verfällt der Risikobetrag und das Risikospiel ist beendet.\n" + "\n"
                + "Wenn Sie auf \"Nehmen\" klicken, wird das Risikospiel beendet und der Risikobetrag wird zu Ihrem Kontostand hinzugefügt.\n" + "\n"
                + "Das Risikospiel ist auf 5 Wiederholungen begrenzt.");
        translation.put("LangYieldTitle", "Ausschüttungsprozentsatz");
        translation.put("LangYieldValue", "Theoretische Ausschüttung:");
        translation.put("LangYieldDescription",
                "Alle Spielergebnisse werden unabhängig und zufällig bestimmt. Der tatsächliche Ausschüttungsprozentsatz (RTP%) wird als Gesamtgewinn / Gesamteinsatz über eine große Anzahl von gespielten Spielen berechnet und spiegelt die durch ein Spiel ausgeschütteten Preise als Prozentsatz aller getätigten Einsätze wider. Der erwartete Ausschüttungsprozentsatz (RTP%) kann bei einer geringen Anzahl von Spielen aufgrund der statistischen Varianz stark in jede Richtung variieren.");
        translation.put("LangWrapperBalance", "KREDIT");
        translation.put("LangWrapperWin", "GEWINN");
        translation.put("LangWrapperBet", "Einsatz");
        translation.put("LangWrapperStart", "Start");
        translation.put("LangLine", "Linie");
        translation.put("LangWrapperSkip", "Überspringen");
        translation.put("LangWrapperTake", "Nehmen");
        translation.put("LangWrapperAutoStart", "Auto\nStart");
        translation.put("LangWrapperAutoStop", "Auto\nStopp");
        translation.put("LangWrapperMaxBet", "Max\nEinsatz");
        translation.put("LangBlack", "SCHWARZ");
        translation.put("LangRed", "ROT");
        translation.put("LangWrapperInfo", "Info");
        translation.put("LangWrapperSnapshot", "Schnappschuss");
        translation.put("LangWrapperGamble", "Gamble");
        return translation;
    }

    /**
     * Represents information about single history presentation.
     */
    class HistoryPresentation {

        /**
         * Presentation date.
         */
        private Date date;

        /**
         * History presentations.
         */
        private List<LogicPresentation> presentations;

        /**
         * Initializes new instance of the {@link HistoryPresentation} class.
         * @param presentations list of presentations
         */
        public HistoryPresentation(List<LogicPresentation> presentations) {
            this.presentations = presentations;
            this.date = new Date();
        }

        /**
         * Gets the presentation info date.
         * @return the presentation info date
         */
        public Date getDate() {
            return date;
        }

        /**
         * Gets the history logic presentations.
         * @return history logic presentations
         */
        public List<LogicPresentation> getLogicPresentations() {
            return presentations;
        }
    }

}
