package com.atsisa.gox.reels.logic.model;

import java.util.Map;

/**
 * Represents the translations, that correspond to the language code.
 */
public class Language {

    /**
     * The current language code.
     */
    private final String languageCode;

    /**
     * The map of translations, that correspond to the current language code.
     */
    private final Map<String, String> translation;

    /**
     * Initializes a new instance of the {@link Language} class.
     * @param languageCode the language code
     * @param translation the translation
     */
    public Language(String languageCode, Map<String, String> translation) {
        this.languageCode = languageCode;
        this.translation = translation;
    }

    /**
     * Gets language code.
     * @return the language code
     */
    public String getLanguageCode() {
        return languageCode;
    }

    /**
     * Gets translation.
     * @return the translation
     */
    public Map<String, String> getTranslation() {
        return translation;
    }
}
