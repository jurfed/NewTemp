package com.atsisa.gox.reels.view;

/**
 * Interface describing basic symbol behaviour.
 */
public interface ISymbol {

    /**
     * Gets symbol name.
     * @return String
     */
    String getName();

    /**
     * Sets new symbol name.
     * @param newName - String
     */
    void setName(String newName);

    /**
     * Sets symbol new state.
     * @param state - String
     */
    void setState(String state);

    /**
     * Gets symbols current state.
     * @return String
     */
    String getState();

    /**
     * Gets default state.
     * @return String
     */
    String getDefaultState();

    /**
     * Sets default state.
     * @param defaultState String
     */
    void setDefaultState(String defaultState);

}
