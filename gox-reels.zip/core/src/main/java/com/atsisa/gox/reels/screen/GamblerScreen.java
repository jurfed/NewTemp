package com.atsisa.gox.reels.screen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.view.AbstractGamblerCard;
import com.atsisa.gox.reels.view.AbstractGamblerCard;
import com.atsisa.gox.reels.command.HideSelectedGamblerCardCommand;
import com.atsisa.gox.reels.command.ShowSelectedGamblerCardCommand;
import com.atsisa.gox.reels.command.UpdateGamblerHistoryCardsCommand;
import com.atsisa.gox.reels.command.UpdateGamblerScreenCommand;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.GamblerModelChangedEvent;
import com.atsisa.gox.reels.event.HistoryGamblerCardsUpdatedEvent;
import com.atsisa.gox.reels.event.SelectedGamblerCardHiddenEvent;
import com.atsisa.gox.reels.event.SelectedGamblerCardShownEvent;
import com.atsisa.gox.reels.model.GamblerCardType;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.view.IGamblerCard;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents the gambler screen.
 * IMPORTANT: gambler screen should be refactored, to resolve this strange history indexes ect.
 * The reason for which it is implemented in this way, is that vocs game server response are not properly adapted to this game flow.
 */
@Reflectable(fields = false)
public class GamblerScreen extends Screen<GamblerScreenModel> implements IResetable, IPauseable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "GamblerScreenLayoutId";

    /**
     * Name of the property for the history reversed red card resource reference.
     */
    public static final String HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHistoryReversedRedCardResourceReference";

    /**
     * Name of the property for the history clubs card resource reference.
     */
    public static final String HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHistoryClubsCardResourceReference";

    /**
     * Name of the property for the history diamond card resource reference.
     */
    public static final String HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHistoryDiamondCardResourceReference";

    /**
     * Name of the property for the history heart card resource reference.
     */
    public static final String HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHistoryHeartCardResourceReference";

    /**
     * Name of the property for the history spade card resource reference.
     */
    public static final String HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHistorySpadeCardResourceReference";

    /**
     * Name of the property for the clubs card resource reference.
     */
    public static final String CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerClubsCardResourceReference";

    /**
     * Name of the property for the diamond card resource reference.
     */
    public static final String DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerDiamondCardResourceReference";

    /**
     * Name of the property for the heart card resource reference.
     */
    public static final String HEART_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerHeartCardResourceReference";

    /**
     * Name of the property for the spade card resource reference.
     */
    public static final String SPADE_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerSpadeCardResourceReference";

    /**
     * Name of the property for the reversed black card resource reference.
     */
    public static final String REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY = "GamblerReversedBlackCardResourceReference";

    /**
     * Resource reference to the clubs history card.
     */
    private String reversedBlackCardResourceReference;

    /**
     * Resource reference to the reversed history red card.
     */
    private String reversedHistoryRedCardResourceReference;

    /**
     * Resource reference to the clubs history card.
     */
    private String clubsHistoryCardResourceReference;

    /**
     * Resource reference to the diamond history card.
     */
    private String diamondHistoryCardResourceReference;

    /**
     * Resource reference to the heart history card.
     */
    private String heartHistoryCardResourceReference;

    /**
     * Resource reference to the spade history card.
     */
    private String spadeHistoryCardResourceReference;

    /**
     * Resource reference to the spade card.
     */
    private String spadeCardResourceReference;

    /**
     * Resource reference to the heart card.
     */
    private String heartCardResourceReference;

    /**
     * Resource reference to the clubs card.
     */
    private String clubsCardResourceReference;

    /**
     * Resource reference to the diamond card.
     */
    private String diamondCardResourceReference;

    /**
     * History cards tag name.
     */
    private static final String HISTORY_CARDS_TAG_NAME = "history";

    /**
     * Gambler history cards.
     */
    private final List<AbstractGamblerCard> historyCards;

    /**
     * Main gambler card.
     */
    @InjectView(id = "mainCard")
    @HasReflect
    public AbstractGamblerCard mainCard;

    /**
     * List of history card types which should be displayed.
     */
    private List<String> historyCardTypes;

    /**
     * A collection of gambler history cards.
     */
    private Iterable<String> gamblerHistory;

    /**
     * List of history cards flip timeouts.
     */
    private List<Timeout> historyFlipTimeouts;

    /**
     * Resource manager reference.
     */
    private IResourceManager resourceManager;

    /**
     * Current gambler screen state.
     */
    private GamblerScreenState currentState;

    /**
     * Credits formatter reference.
     */
    private ICreditsFormatter creditsFormatter;

    /**
     * Initializes a new instance of the {@link GamblerScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link GamblerScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     * @param resourceManager  {@link IResourceManager}
     * @param creditsFormatter {@link ICreditsFormatter}
     */
    @Inject
    public GamblerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, GamblerScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IResourceManager resourceManager, ICreditsFormatter creditsFormatter) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.resourceManager = resourceManager;
        this.creditsFormatter = creditsFormatter;
        historyCards = new ArrayList<>();
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new UpdateHistoryCardsCommandObserver(), UpdateGamblerHistoryCardsCommand.class);
        getEventBus().register(new ShowSelectedGamblerCardCommandObserver(), ShowSelectedGamblerCardCommand.class);
        getEventBus().register(new HideSelectedGamblerCardCommandObserver(), HideSelectedGamblerCardCommand.class);
        getEventBus().register(new UpdateGamblerScreenCommandObserver(), UpdateGamblerScreenCommand.class);
        getEventBus().register(new GamblerModelChangedEventObserver(), GamblerModelChangedEvent.class);
    }

    /**
     * Sets the resource reference for the reversed black card.
     * @param reversedBlackCardResourceReference the resource reference for the reversed black card
     */
    @Inject
    public void setReversedBlackCardResourceReference(@Named(REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY) String reversedBlackCardResourceReference) {
        this.reversedBlackCardResourceReference = reversedBlackCardResourceReference;
    }

    /**
     * Sets the resource reference for the reversed history red card.
     * @param reversedHistoryRedCardResourceReference the resource reference for the reversed history red card
     */
    @Inject
    public void setReversedHistoryRedCardResourceReference(
            @Named(HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY) String reversedHistoryRedCardResourceReference) {
        this.reversedHistoryRedCardResourceReference = reversedHistoryRedCardResourceReference;
    }

    /**
     * Sets the resource reference for the history clubs card.
     * @param clubsHistoryCardResourceReference the resource reference for the history clubs card
     */
    @Inject
    public void setClubsHistoryCardResourceReference(@Named(HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY) String clubsHistoryCardResourceReference) {
        this.clubsHistoryCardResourceReference = clubsHistoryCardResourceReference;
    }

    /**
     * Sets the resource reference for the history diamond card.
     * @param diamondHistoryCardResourceReference the resource reference for the history diamond card
     */
    @Inject
    public void setDiamondHistoryCardResourceReference(@Named(HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY) String diamondHistoryCardResourceReference) {
        this.diamondHistoryCardResourceReference = diamondHistoryCardResourceReference;
    }

    /**
     * Sets the resource reference for the history heart card.
     * @param heartHistoryCardResourceReference the resource reference for the history heart card
     */
    @Inject
    public void setHeartHistoryCardResourceReference(@Named(HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY) String heartHistoryCardResourceReference) {
        this.heartHistoryCardResourceReference = heartHistoryCardResourceReference;
    }

    /**
     * Sets the resource reference for the history spade card.
     * @param spadeHistoryCardResourceReference the resource reference for the history spade card
     */
    @Inject
    public void setSpadeHistoryCardResourceReference(@Named(HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY) String spadeHistoryCardResourceReference) {
        this.spadeHistoryCardResourceReference = spadeHistoryCardResourceReference;
    }

    /**
     * Sets the resource reference for the spade card.
     * @param spadeCardResourceReference the resource reference for the spade card
     */
    @Inject
    public void setSpadeCardResourceReference(@Named(SPADE_CARD_RESOURCE_REFERENCE_PROPERTY) String spadeCardResourceReference) {
        this.spadeCardResourceReference = spadeCardResourceReference;
    }

    /**
     * Sets the resource reference for the heart card.
     * @param heartCardResourceReference the resource reference for the heart card
     */
    @Inject
    public void setHeartCardResourceReference(@Named(HEART_CARD_RESOURCE_REFERENCE_PROPERTY) String heartCardResourceReference) {
        this.heartCardResourceReference = heartCardResourceReference;
    }

    /**
     * Sets the resource reference for the clubs card.
     * @param clubsCardResourceReference the resource reference for the clubs card
     */
    @Inject
    public void setClubsCardResourceReference(@Named(CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY) String clubsCardResourceReference) {
        this.clubsCardResourceReference = clubsCardResourceReference;
    }

    /**
     * Sets the resource reference for the diamond card.
     * @param diamondCardResourceReference the resource reference for the diamond card
     */
    @Inject
    public void setDiamondCardResourceReference(@Named(DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY) String diamondCardResourceReference) {
        this.diamondCardResourceReference = diamondCardResourceReference;
    }

    @Override
    protected void afterActivated() {
        if (historyCards.isEmpty()) {
            List<AbstractGamblerCard> gamblerCardViews = (List<AbstractGamblerCard>) findViewInheritingType(AbstractGamblerCard.class);
            for (AbstractGamblerCard gamblerCardView : gamblerCardViews) {
                if (gamblerCardView.hasTag(HISTORY_CARDS_TAG_NAME)) {
                    historyCards.add(gamblerCardView);
                }
            }
            mainCard.setReversedCard(createGamblerCardImageView(reversedBlackCardResourceReference));
        }
        if (historyCardTypes != null) {
            updateHistoryCardsWithoutAnimation();
        }
    }

    /**
     * Resets history revers cards.
     */
    private void resetHistoryReversCards() {
        historyCards.forEach(card -> card.setReversedCard(createGamblerCardImageView(reversedHistoryRedCardResourceReference)));
    }

    /**
     * Updates history cards without animation.
     */
    private void updateHistoryCardsWithoutAnimation() {
        if (historyCardTypes == null) {
            return;
        }
        resetHistoryReversCards();
        ImageView cardView;
        IGamblerCard gamblerCardView;
        for (int index = 0; index < historyCards.size(); ++index) {
            gamblerCardView = historyCards.get(index);
            cardView = null;
            if (historyCardTypes.size() > index) {
                cardView = getGamblerCardImageView(historyCardTypes.get(index), true);
            }
            if (cardView == null) {
                gamblerCardView.showReversedCard();
            } else {
                gamblerCardView.setUprightCard(cardView);
                gamblerCardView.showUprightCard();
            }
        }
    }

    /**
     * Returns upright image view for gambler card, based on the card name.
     * @param cardType  type of the card
     * @param isHistory a boolean value that indicates whether get card for history or for main card
     * @return ImageView
     */
    private ImageView getGamblerCardImageView(String cardType, boolean isHistory) {
        String resourceReference = null;
        if (cardType != null) {
            switch (cardType) {
                case GamblerCardType.DIAMONDS:
                    resourceReference = isHistory ? diamondHistoryCardResourceReference : diamondCardResourceReference;
                    break;
                case GamblerCardType.HEARTS:
                    resourceReference = isHistory ? heartHistoryCardResourceReference : heartCardResourceReference;
                    break;
                case GamblerCardType.SPADES:
                    resourceReference = isHistory ? spadeHistoryCardResourceReference : spadeCardResourceReference;
                    break;
                case GamblerCardType.CLUBS:
                    resourceReference = isHistory ? clubsHistoryCardResourceReference : clubsCardResourceReference;
                    break;
                default:
                    break;
            }
            if (resourceReference != null) {
                return createGamblerCardImageView(resourceReference);
            }
        }
        return null;
    }

    /**
     * Creates reversed or upright image view for gambler card, based on resource reference.
     * @param resourceReference reference to the resource
     * @return ImageView
     */
    private ImageView createGamblerCardImageView(String resourceReference) {
        ImageView imageView = new ImageView();
        IImageReference resource = resourceManager.find(resourceReference);
        imageView.setImage(resource);
        return imageView;
    }

    /**
     * Updates a gamble amount value according to recent gambler model changes.
     * @param gamblerModelChangedEvent GamblerModelChangedEvent
     */
    @Subscribe
    public void handleGamblerModelChangedEvent(GamblerModelChangedEvent gamblerModelChangedEvent) {
        IGamblerModel gamblerModel = gamblerModelChangedEvent.getGamblerModel();
        BigDecimal gamblerAmount = gamblerModel.getBidAmount();
        BigDecimal gamblerWinAmount = gamblerModel.getGamblerWinAmount();
        if (gamblerWinAmount != null) {
            getModel().setGambleToWin(creditsFormatter.formatWithCurrency(gamblerModel.getGamblerWinAmount()));
        }
        if (gamblerAmount != null) {
            getModel().setGambleAmount(creditsFormatter.formatWithCurrency(gamblerAmount));
        }
        gamblerHistory = gamblerModel.getGamblerHistory();
    }

    /**
     * Changes the current state.
     * @param state {@link GamblerScreenState}
     */
    public void changeState(GamblerScreenState state) {
        if (state == null || state == currentState) {
            return;
        }
        currentState = state;
        stateChanged();
    }

    /**
     * Returns the current gambler screen state.
     * @return the current gambler screen state
     */
    public GamblerScreenState getCurrentState() {
        return currentState;
    }

    /**
     * Updates a gambler screen state.
     * @param updateGamblerScreenCommand {@link UpdateGamblerScreenCommand}
     */
    @Subscribe
    public void handleUpdateGamblerScreenCommand(UpdateGamblerScreenCommand updateGamblerScreenCommand) {
        String state = updateGamblerScreenCommand.getState();
        if (state == null) {
            return;
        }
        GamblerScreenState gamblerScreenState;
        try {
            gamblerScreenState = GamblerScreenState.valueOf(state);
        } catch (IllegalArgumentException ex) {
            return;
        }
        changeState(gamblerScreenState);
    }

    /**
     * Called when state will be changed.
     */
    protected void stateChanged() {
    }

    /**
     * Gets last selected card.
     * @return card type
     */
    public String getLastSelectedCard() {
        if (gamblerHistory == null) {
            return GamblerCardType.NONE;
        }
        return Iterables.getFirst(gamblerHistory, GamblerCardType.NONE);
    }

    /**
     * Called when black button will be invoked.
     */
    @ExposeMethod
    public void selectBlack() {
        getEventBus().post(new GamblerCardSelectedEvent(CardType.BLACK));
    }

    /**
     * Called when red button will be invoked.
     */
    @ExposeMethod
    public void selectRed() {
        getEventBus().post(new GamblerCardSelectedEvent(CardType.RED));
    }

    /**
     * Hide selected gambler card.
     * @param hideSelectedGamblerCardCommand {@link HideSelectedGamblerCardCommand}
     */
    public void handleHideSelectedGamblerCardCommand(HideSelectedGamblerCardCommand hideSelectedGamblerCardCommand) {
        mainCard.flip(this::notifySelectedCardHidden);
    }

    /**
     * Sends event about that selected card was hidden.
     */
    private void notifySelectedCardHidden() {
        getEventBus().post(new SelectedGamblerCardHiddenEvent());
    }

    /**
     * Shows selected gambler card.
     * @param showSelectedGamblerCardCommand {@link ShowSelectedGamblerCardCommand}
     */
    public void handleShowSelectedGamblerCardCommand(ShowSelectedGamblerCardCommand showSelectedGamblerCardCommand) {
        mainCard.showReversedCard();
        String cardName = showSelectedGamblerCardCommand.getSelectedCard();
        ImageView newCard = getGamblerCardImageView(cardName, false);

        mainCard.setUprightCard(newCard);
        if (isActive()) {
            if (!historyCards.isEmpty()) {
                AbstractGamblerCard historyCard = historyCards.get(0);
                ImageView newHistoryCard = getGamblerCardImageView(cardName, true);
                historyCard.setUprightCard(newHistoryCard);
                historyCard.flip(null);
            }
            mainCard.flip(this::notifySelectedCardShown);
        } else {
            mainCard.showUprightCard();
            notifySelectedCardShown();
        }
    }

    /**
     * Sends event about that selected card was shown.
     */
    private void notifySelectedCardShown() {
        getEventBus().post(new SelectedGamblerCardShownEvent());
    }

    /**
     * Updates a history cards.
     * @param updateGamblerHistoryCardsCommand {@link UpdateGamblerHistoryCardsCommand}
     */
    public void handleUpdateGamblerHistoryCardsCommand(UpdateGamblerHistoryCardsCommand updateGamblerHistoryCardsCommand) {
        historyCardTypes = updateGamblerHistoryCardsCommand.getHistoryCards();
        if (isActive()) {
            updateHistoryCardsWithAnimation();
        } else {
            notifyHistoryGamblerCardsUpdated();
        }
    }

    /**
     * Updates history cards with animation.
     */
    private void updateHistoryCardsWithAnimation() {
        ImageView cardView;
        List<IGamblerCard> flipCards = new ArrayList<>();
        IGamblerCard gamblerCard;
        for (int index = 0; index < historyCards.size(); ++index) {
            gamblerCard = historyCards.get(index);
            cardView = null;
            if (historyCardTypes.size() > index) {
                cardView = getGamblerCardImageView(historyCardTypes.get(index), true);
            }
            if (cardView == null && gamblerCard.isReversed()) {
                continue;
            }
            if (cardView != null) {
                if (gamblerCard.isReversed()) {
                    gamblerCard.setUprightCard(cardView);
                } else {
                    gamblerCard.setReversedCard(cardView);
                }
            }
            flipCards.add(gamblerCard);
        }
        int delayBetweenFlipCards = getModel().getHistoryCardsFlipDelay();
        historyFlipTimeouts = new ArrayList<>();
        for (int index = 0; index < flipCards.size(); ++index) {
            final IGamblerCard flipCard = flipCards.get(index);
            final IFinishCallback lastCardFinishedCallback;
            if (index + 1 == flipCards.size()) {
                lastCardFinishedCallback = this::notifyHistoryGamblerCardsUpdated;
            } else {
                lastCardFinishedCallback = null;
            }
            historyFlipTimeouts.add(new Timeout(delayBetweenFlipCards * index, () -> flipCard.flip(lastCardFinishedCallback), true));
        }
    }

    /**
     * Sends event about history cards are updated.
     */
    private void notifyHistoryGamblerCardsUpdated() {
        getEventBus().post(new HistoryGamblerCardsUpdatedEvent());
    }

    @Override
    @ExposeMethod
    public void reset() {
        if (mainCard != null) {
            mainCard.reset();
        }
        historyCards.forEach(AbstractGamblerCard::reset);
        updateHistoryCardsWithoutAnimation();
        clearHistoryTimeouts();
    }

    @Override
    @ExposeMethod
    public void pause() {
        if (mainCard != null) {
            mainCard.pause();
        }
        historyCards.forEach(AbstractGamblerCard::pause);
        clearHistoryTimeouts();
    }

    /**
     * Clears all history wait timeouts.
     */
    private void clearHistoryTimeouts() {
        if (historyFlipTimeouts != null) {
            historyFlipTimeouts.forEach(timeout -> {
                if (!timeout.isCleaned()) {
                    timeout.clear();
                }
            });
        }
    }

    /**
     * Defines all possible gambler screen states.
     */
    public enum GamblerScreenState {

        /**
         * Showing state.
         */
        SHOWING,

        /**
         * Select card.
         */
        SELECT_CARD,

        /**
         * Selected red card.
         */
        SELECTED_RED_CARD,

        /**
         * Selected black card.
         */
        SELECTED_BLACK_CARD,

        /**
         * Lose screen state.
         */
        LOSE,

        /**
         * History selected card.
         */
        HISTORY_SELECTED_CARD,

        /**
         * Lose history gambler state.
         */
        HISTORY_LOSE,

        /**
         * Win history gambler state.
         */
        HISTORY_WIN
    }

    private class UpdateHistoryCardsCommandObserver extends NextObserver<UpdateGamblerHistoryCardsCommand> {

        @Override
        public void onNext(final UpdateGamblerHistoryCardsCommand updateGamblerHistoryCardsCommand) {
            handleUpdateGamblerHistoryCardsCommand(updateGamblerHistoryCardsCommand);
        }
    }

    private class ShowSelectedGamblerCardCommandObserver extends NextObserver<ShowSelectedGamblerCardCommand> {

        @Override
        public void onNext(final ShowSelectedGamblerCardCommand showSelectedGamblerCardCommand) {
            handleShowSelectedGamblerCardCommand(showSelectedGamblerCardCommand);
        }
    }

    private class HideSelectedGamblerCardCommandObserver extends NextObserver<HideSelectedGamblerCardCommand> {

        @Override
        public void onNext(final HideSelectedGamblerCardCommand hideSelectedGamblerCardCommand) {
            handleHideSelectedGamblerCardCommand(hideSelectedGamblerCardCommand);
        }
    }

    private class UpdateGamblerScreenCommandObserver extends NextObserver<UpdateGamblerScreenCommand> {

        @Override
        public void onNext(UpdateGamblerScreenCommand updateGamblerScreenCommand) {
            handleUpdateGamblerScreenCommand(updateGamblerScreenCommand);
        }
    }

    private class GamblerModelChangedEventObserver extends NextObserver<GamblerModelChangedEvent> {

        @Override
        public void onNext(GamblerModelChangedEvent gamblerModelChangedEvent) {
            handleGamblerModelChangedEvent(gamblerModelChangedEvent);
        }
    }

}
