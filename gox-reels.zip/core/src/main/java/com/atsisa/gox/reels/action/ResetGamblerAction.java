package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ResetGamblerCommand;

/**
 * Sends a request to reset gambler model.
 */
public class ResetGamblerAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link ResetGamblerAction} class.
     */
    public ResetGamblerAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ResetGamblerAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public ResetGamblerAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new ResetGamblerCommand());
    }
}
