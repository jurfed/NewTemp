package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ShowNextWinningLineCommand;

/**
 * Request for showing the next winning line.
 */
public class ShowNextWinningLineAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link ShowNextWinningLineAction} class.
     */
    public ShowNextWinningLineAction() {
    }

    /**
     * Initializes a new instance of the {@link ShowNextWinningLineAction} class.
     * @param logger   a logger reference.
     * @param eventBus an eventBus reference.
     */
    public ShowNextWinningLineAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new ShowNextWinningLineCommand());
    }
}
