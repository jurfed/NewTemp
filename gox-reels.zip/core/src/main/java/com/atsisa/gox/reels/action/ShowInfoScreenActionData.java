package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.AnimationScreenActionData;
import com.atsisa.gox.framework.action.ScreenActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.Reflectable;

/**
 * Provides data for {@link ShowInfoScreenAction} class.
 */
@XmlElement
@Reflectable
public class ShowInfoScreenActionData extends AnimationScreenActionData {

    /**
     * Id of the view that should be shown.
     */
    @XmlAttribute
    private String viewId;

    /**
     * A boolean value that indicates whether sound should be played during showing screen or not.
     */
    @XmlAttribute boolean playSound;

    /**
     * Gets the id of the view that should be shown.
     * @return the id of the view that should be shown
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * Sets the id of the view that should be shown
     * @param viewId {@link String}
     */
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

    /**
     * Gets a boolean value that indicates whether sound should be played during showing screen or not.
     * @return a boolean value that indicates whether sound should be played during showing screen or not.
     */
    public boolean isPlaySound() {
        return playSound;
    }

    /**
     * Sets a boolean value that indicates whether sound should be played during showing screen or not.
     * @param playSound {@link Boolean}
     */
    public void setPlaySound(boolean playSound) {
        this.playSound = playSound;
    }
}
