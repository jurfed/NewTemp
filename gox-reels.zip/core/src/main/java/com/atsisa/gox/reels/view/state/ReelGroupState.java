package com.atsisa.gox.reels.view.state;

import com.atsisa.gox.reels.view.ReelGroupView;

/**
 * Describes all possible {@link ReelGroupView} states.
 */
public enum ReelGroupState {

    /**
     * The state in which all reels are in idle state.
     */
    IDLE,

    /**
     * The state in which at last one of the reel is spinning.
     */
    SPINNING,

    /**
     * The state in which at last one of the reel is stopping.
     */
    STOPPING,

    /**
     * The state in which reel group is starts showing winning symbols.
     */
    STARTS_SHOWING_WINNING_SYMBOLS,

    /**
     * The state in which reel group is starts hiding winning symbols.
     */
    STARTS_HIDING_WINNING_SYMBOLS,

    /**
     * The state in which reel group is showing winning symbols.
     */
    SHOWING_WINNING_SYMBOLS
}
