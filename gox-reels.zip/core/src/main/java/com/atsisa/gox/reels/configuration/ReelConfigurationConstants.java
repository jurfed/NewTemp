package com.atsisa.gox.reels.configuration;

/**
 * Contains possible parameter names for common reel games.
 */
public final class ReelConfigurationConstants {

    /**
     * Frontend address property name.
     */
    public static final String ENTRY_POINT_ADDRESS = "entrypointAddress";

    /**
     * Game id property name.
     */
    public static final String GAME_ID = "gameID";

    /**
     * Language property name.
     */
    public static final String LANGUAGE_CODE = "languageCode";

    /**
     * Game mode property name.
     */
    public static final String GAME_MODE = "gameMode";

    /**
     * Wrapper name property name.
     */
    public static final String WRAPPER_NAME = "wrapperName";

    /**
     * Display currency on pay table property name.
     */
    public static final String DISPLAY_CURRENCY_ON_PAY_TABLE = "displayCurrencyOnPayTable";

    /**
     * Decimal format on pay table property name.
     */
    public static final String DECIMAL_FORMAT_ON_PAY_TABLE = "decimalFormatOnPayTable";

    /**
     * Delay between showing history cards in gambler.
     */
    public static final String GAMBLER_HISTORY_CARDS_DELAY = "gamblerHistoryCardsDelay";

    /**
     * History date format property name.
     */
    public static final String HISTORY_DATE_FORMAT = "historyDateFormat";

    /**
     * Private constructor blocks the possibility to initialize this class.
     */
    private ReelConfigurationConstants() {
    }
}
