package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.reels.view.IReelGroup;

import rx.Observable;

/**
 * It decides how to hide the animation on the symbols.
 */
public interface IHideSymbolAnimationsStrategy {

    /**
     * Hides the symbol animations on reels.
     * @param reelGroup {@link IReelGroup}
     * @return the observable result
     */
    Observable<IReelGroup> hideAnimations(IReelGroup reelGroup);

    /**
     * Interrupts the current process of hiding symbol animations and forces it to immediately hide.
     */
    void terminate();

}
