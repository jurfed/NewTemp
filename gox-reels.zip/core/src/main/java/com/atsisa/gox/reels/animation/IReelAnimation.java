package com.atsisa.gox.reels.animation;

import com.atsisa.gox.framework.animation.IAnimation;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.IReel;

import rx.Observable;
import rx.Observer;

/**
 * Defines the animation of symbols in objects implementing the {@link IReel} interface.
 */
public interface IReelAnimation extends IAnimation {

    /**
     * Gets an observer of animating symbols.
     * @return An observer of animating symbols.
     */
    Observer<AbstractSymbol> getAnimatingSymbols();

    /**
     * Gets an observable of symbols returning from this animation back to the symbol pool.
     * @return An observable of symbols returning from this animation.
     */
    Observable<AbstractSymbol> getReturningSymbols();

    /**
     * Initializes this instance of the reel animation before it is being used.
     * @param symbolsConfiguration Currently operative symbols configuration.
     */
    void setUp(ISymbolsConfiguration symbolsConfiguration);

    /**
     * Notifies the animation that the stopping phase should begin now.
     */
    void beginStop();

    /**
     * Speeds up the animation so that the symbols move faster regardless of the animation phase.
     */
    void speedUp();

    /**
     * Gets a number of symbols this animation wishes to prepend before actual stopping symbols.
     * @return A number of symbols to prepend before stopping symbols.
     */
    int getPrependedSymbolsCount();

    /**
     * Gets a number of symbols this animation wishes to append after actual stopping symbols.
     * @return A number of symbols to append after stopping symbols.
     */
    int getAppendedSymbolsCount();
}
