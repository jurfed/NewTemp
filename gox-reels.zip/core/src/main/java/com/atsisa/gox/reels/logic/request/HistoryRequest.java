package com.atsisa.gox.reels.logic.request;

/**
 * Represents request to show specific page in history.
 */
public class HistoryRequest extends InitRequest {

    /**
     * History page number to show.
     */
    private final int pageNumber;

    /**
     * Initializes a new instance of the {@link HistoryRequest} class.
     * @param gameIdentity a game identity
     * @param languageCode a language code
     * @param pageNumber history page number
     */
    public HistoryRequest(String gameIdentity, String languageCode, int pageNumber) {
        super(gameIdentity, languageCode);
        this.pageNumber = pageNumber;
    }

    /**
     * Gets history page number to show.
     * @return history page number to show
     */
    public int getPageNumber() {
        return pageNumber;
    }
}
