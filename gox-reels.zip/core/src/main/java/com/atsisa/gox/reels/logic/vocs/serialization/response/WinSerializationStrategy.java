package com.atsisa.gox.reels.logic.vocs.serialization.response;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.atsisa.gox.reels.logic.vocs.serialization.PresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Response strategy for win presentations.
 */
public class WinSerializationStrategy extends GroupSerializationStrategy<WinningPresentation> {

    /**
     * Used with IoC to define presentation names supported by this strategy.
     */
    public static final String WIN_PRESENTATIONS = "WinPresentations";

    @Inject(optional = true)
    @Override
    public void addSupportedPresentations(@Named(WIN_PRESENTATIONS) Set<String> additionalSupportedPresentations) {
        super.addSupportedPresentations(additionalSupportedPresentations);
    }

    @Override
    protected void registerDefaultSupportedPresentations() {
        addPresentation(PresentationName.BASE_GAME_WIN);
        addPresentation(PresentationName.BASE_GAME_LIMIT);
        addPresentation(PresentationName.OFFER_GAMBLER_TAKE_WIN);
        addPresentation(PresentationName.LIMIT_TAKE_WIN);
        addPresentation(PresentationName.GAMBLER_TAKE_WIN);
    }

    @Override
    protected WinningPresentation deserializePresentation(XmlObject xmlObject) {
        String presentationName = getPresentationName(xmlObject);
        return new WinningPresentation(presentationName,
                XmlDeserializer.tryDeserializeWin(xmlObject).orElseGet(() -> XmlDeserializer.deserializeWon(xmlObject)),
                XmlDeserializer.deserializeWinningLines(xmlObject),
                isResumedPresentation(presentationName),
                isHistoryPresentation(xmlObject));
    }
}
