package com.atsisa.gox.reels.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.resource.AbstractTextResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.ResourceType;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.reels.exception.ReelStripDefinitionProviderException;

/**
 * Contains all the reel strip definitions, which are available in the game.
 */
public final class LocalResourceReelStripDefinitionProvider implements IReelStripDefinitionProvider {

    /**
     * List of id of resources, which contain reel strips.
     */
    private List<String> reelStripResourcesId;

    /**
     * IResourceManager reference.
     */
    private IResourceManager resourceManager;

    /**
     * IXmlSerializer reference.
     */
    private IXmlSerializer serializer;

    /**
     * A list that contains all reel strip definitions.
     */
    private Map<String, List<ReelStripDefinition>> reelStripDefinitions;

    /**
     * Default reel strip type.
     */
    private String defaultReelStripType;

    /**
     * Creates and returns new LocalResourceReelStripDefinitionProvider class.
     * @param reelStripResourcesId List of String
     * @param resourceManager      IResourceManager
     * @param serializer           IXmlSerializer
     * @return LocalResourceReelStripDefinitionProvider
     */
    public static LocalResourceReelStripDefinitionProvider newReelStripDefinitionProvider(List<String> reelStripResourcesId, IResourceManager resourceManager,
            IXmlSerializer serializer) {
        LocalResourceReelStripDefinitionProvider reelStripDefinitionProvider = new LocalResourceReelStripDefinitionProvider(reelStripResourcesId,
                resourceManager, serializer);
        try {
            reelStripDefinitionProvider.initialize();
        } catch (SerializationException ex) {
            throw new ReelStripDefinitionProviderException(ex.getMessage());
        }
        return reelStripDefinitionProvider;
    }

    /**
     * Initializes a new instance of the LocalResourceReelStripDefinitionProvider class.
     * @param reelStripResourcesId - List of String
     * @param resourceManager      - IResourceManager
     * @param serializer           - IXmlSerializer
     */
    private LocalResourceReelStripDefinitionProvider(List<String> reelStripResourcesId, IResourceManager resourceManager, IXmlSerializer serializer) {
        this.reelStripResourcesId = reelStripResourcesId;
        this.resourceManager = resourceManager;
        this.serializer = serializer;
    }

    /**
     * Initializes this provider.
     * @throws SerializationException - can be thrown during deserialize xml, with reel strip definitions.
     */
    @SuppressWarnings("unchecked")
    private void initialize() throws SerializationException {
        reelStripDefinitions = new HashMap<>();
        for (String resourceID : reelStripResourcesId) {
            AbstractTextResource reelStripResource = (AbstractTextResource) resourceManager.getResource(resourceID, ResourceType.TEXT);
            List<ReelStripDefinition> newReelStripDefinitions = (List<ReelStripDefinition>) serializer
                    .deserialize(reelStripResource.getText(), ReelStripDefinition[].class);
            for (ReelStripDefinition reelStripDefinition : newReelStripDefinitions) {
                addReelStripDefinition(reelStripDefinition);
            }
        }
    }

    /**
     * Adds single reel strip definition to map.
     * @param reelStripDefinition - ReelStripDefinition
     */
    private void addReelStripDefinition(ReelStripDefinition reelStripDefinition) {
        if (defaultReelStripType == null) {
            defaultReelStripType = reelStripDefinition.getType();
        }
        List<ReelStripDefinition> definitions = reelStripDefinitions.get(reelStripDefinition.getType());
        if (definitions != null) {
            definitions.add(reelStripDefinition);
        } else {
            definitions = new ArrayList<>();
            definitions.add(reelStripDefinition);
            reelStripDefinitions.put(reelStripDefinition.getType(), definitions);
        }
    }

    @Override
    public Iterable<ReelStripDefinition> getReelStripDefinitions(String type) {
        return reelStripDefinitions.get(type);
    }

    @Override
    public ReelStripDefinition getReelStripDefinition(String type, int reelNumber) {
        Iterable<ReelStripDefinition> reelStripDefinitionsType = getReelStripDefinitions(type);
        if (reelStripDefinitionsType != null) {
            for (ReelStripDefinition reelStripDefinition : reelStripDefinitionsType) {
                if (reelStripDefinition.getReelNumber() == reelNumber) {
                    return reelStripDefinition;
                }
            }
        }
        return null;
    }

    @Override
    public Set<String> getReelStripTypes() {
        return reelStripDefinitions.keySet();
    }

    @Override
    public String getDefaultReelStripType() {
        return defaultReelStripType;
    }
}
