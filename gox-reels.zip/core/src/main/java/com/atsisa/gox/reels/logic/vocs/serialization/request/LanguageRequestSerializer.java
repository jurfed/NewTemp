package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.vocs.LanguageRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer of language request.
 */
public class LanguageRequestSerializer implements ISerializer<LanguageRequest, XmlObject> {

    @Override
    public XmlObject serialize(LanguageRequest request) {
        return new XmlBuilder()
            .startElement("nrgs")
                .startElement("req")
                    .startElement("a")
                        .writeValue("ChangeTranslation")
                    .endElement()
                    .startElement("l")
                        .writeAttribute("w", request.getGameIdentity())
                        .writeValue(request.getLanguageCode())
                    .endElement()
                .endElement()
            .endElement()
            .toXmlObject();
    }
}
