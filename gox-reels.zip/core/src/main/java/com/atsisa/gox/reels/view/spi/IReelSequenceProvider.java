package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.framework.view.spi.ISequenceProvider;
import com.atsisa.gox.reels.view.IReel;

/**
 * Provides sequence for IReel type.
 */
public interface IReelSequenceProvider extends ISequenceProvider<IReel> {

}
