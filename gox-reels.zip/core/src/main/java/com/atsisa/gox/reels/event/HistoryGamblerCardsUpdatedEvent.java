package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when gambler history cards have been updated.
 */
@Reflectable
public class HistoryGamblerCardsUpdatedEvent {

}
