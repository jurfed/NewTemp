package com.atsisa.gox.reels.controller;

import java.util.HashSet;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.reels.ClosableListening;
import com.atsisa.gox.reels.IPresentationController;
import com.atsisa.gox.reels.IPresentationStateListener;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.SkipCommand;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.command.TakeWinCommand;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;
import com.google.inject.Inject;

/**
 * Presentation controller default implementation.
 */
public class PresentationController implements IPresentationController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * Current presentation state.
     */
    private String currentPresentationState = ReelsPresentationStates.NONE;

    /**
     * Set of the presentation state listeners.
     */
    private final Set<IPresentationStateListener> listeners = new HashSet<>();

    /**
     * Creates new instance of the {@link PresentationController} class.
     * @param eventBus the event bus.
     */
    @Inject
    public PresentationController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new PresentationStateChangedObserver(), PresentationStateChangedEvent.class);
    }

    @Override
    public String getState() {
        return currentPresentationState;
    }

    @Override
    public synchronized void next() throws IllegalStateException {
        switch (currentPresentationState) {
            case ReelsPresentationStates.OFFER_GAMBLER:
            case ReelsPresentationStates.GAMBLER:
                eventBus.post(new TakeWinCommand());
                break;
            case ReelsPresentationStates.IDLE:
                eventBus.post(new SpinCommand());
                break;
            case ReelsPresentationStates.STOPPING_REELS:
            case ReelsPresentationStates.WIN_COUNTING:
                eventBus.post(new SkipCommand());
                break;
        }
    }

    /**
     * Notify all presentation state listeners.
     * @param stateName state name.
     */
    private void notifyListeners(String stateName) {
        for (IPresentationStateListener listener : listeners) {
            listener.stateChanged(stateName);
        }
    }

    @Override
    public ClosableListening addStateListener(IPresentationStateListener listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    private class PresentationStateChangedObserver extends NextObserver<PresentationStateChangedEvent> {

        @Override
        public void onNext(PresentationStateChangedEvent presentationStateChangedEvent) {
            currentPresentationState = presentationStateChangedEvent.getStateName();
            notifyListeners(currentPresentationState);
        }
    }
}
