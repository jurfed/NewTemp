package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.UrnObjectConverter;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.view.Skin;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.animation.IReelAnimation;
import com.atsisa.gox.reels.animation.ReelAnimation;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.configuration.SymbolsConfiguration;
import com.atsisa.gox.reels.model.IReelStripDefinitionProvider;
import com.atsisa.gox.reels.view.spi.ISymbolAppendingStrategy;
import com.atsisa.gox.reels.view.state.ReelState;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

import rx.Observable;
import rx.Subscription;
import rx.subjects.PublishSubject;

/**
 * The most common implementation of {@link IReel} interface.
 */
@XmlElement
@Reflectable(fields = false)
public class ReelView extends AbstractReel {

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * Class level for instances of render method local variables.
     */
    private final SymbolLocalVariables slv;

    /**
     * The configuration validator.
     */
    private static final SymbolsConfigurationValidator CONFIGURATION_VALIDATOR = new SymbolsConfigurationValidator();

    /**
     * Animation subscriptions.
     */
    private final List<Subscription> animationSubscriptions;

    /**
     * Stopped symbols.
     */
    private final List<AbstractSymbol> stoppedSymbols;

    /**
     * Reel state subject.
     */
    private final PublishSubject<ReelState> reelStateSubject;

    /**
     * A view group containing symbols.
     */
    private final ViewGroup symbolsContainer;

    /**
     * The symbols configuration.
     */
    @XmlElement(converters = SymbolsConfigurationConverter.class)
    @HasReflect
    private ISymbolsConfiguration symbolsConfiguration;

    /**
     * The reel animation.
     */
    @XmlElement(converters = UrnObjectConverter.class)
    @HasReflect
    private IReelAnimation reelAnimation;

    /**
     * Current reel strip type.
     */
    private String reelStripType;

    /**
     * The reel state.
     */
    private ReelState reelState;

    /**
     * Reel strip symbols context.
     */
    private ReelStripSymbolsContext reelStripContext;

    /**
     * Stopping symbols context.
     */
    private StoppingSymbolsContext stoppingContext;

    /**
     * A value indicating whether this reel is currently force-stopping.
     */
    private boolean isForceStopping;

    /**
     * A number of symbols left before stopping.
     */
    private int symbolsLeftBeforeStop;

    /**
     * A flag indicating whether the animation currently plays the stopping phase.
     */
    private boolean isStopping;

    /**
     * The reel strip definition provider.
     */
    private final IReelStripDefinitionProvider reelStripDefinitionProvider;

    /**
     * Initializes a new instance of the {@link ReelView} using the default symbol
     * configuration.
     */
    public ReelView() {
        this(GameEngine.current().getRenderer(), ((AbstractReelGame) GameEngine.current().getGame()).getReelStripDefinitionProvider());
    }

    /**
     * Initializes a new instance of the {@link ReelView} using the default symbol configuration.
     * @param renderer                    {@link IRenderer}
     * @param reelStripDefinitionProvider {@link IReelStripDefinitionProvider}
     */
    public ReelView(IRenderer renderer, IReelStripDefinitionProvider reelStripDefinitionProvider) {
        super(renderer);
        lv = new LocalVariables();
        slv = new SymbolLocalVariables();
        symbolsContainer = new ViewGroup(renderer);

        animationSubscriptions = new ArrayList<>();
        stoppedSymbols = new ArrayList<>();
        reelStateSubject = PublishSubject.create();
        symbolsConfiguration = new SymbolsConfiguration();
        reelState = ReelState.IDLE;
        isForceStopping = false;
        addChild(symbolsContainer);
        setReelAnimation(new ReelAnimation());

        this.reelStripDefinitionProvider = reelStripDefinitionProvider;
    }

    @Override
    void setIndex(int index) {
        super.setIndex(index);
        setReelStripType(reelStripDefinitionProvider.getDefaultReelStripType());
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        View view = skin.getView();
        if (view instanceof IReel) {
            setReelAnimation(((IReel) view).getReelAnimation());
            setSymbolsConfiguration(((IReel) view).getSymbolsConfiguration());
        }
    }

    @Override
    public Observable<ReelState> getReelStateObservable() {
        return reelStateSubject;
    }

    @Override
    public ReelState getReelState() {
        return reelState;
    }

    @Override
    public void setReelStripType(String reelStripType) {
        if (reelStripType == null) {
            throw new IllegalArgumentException("The reel strip type cannot be null.");
        }
        if (reelStripType.equals(this.reelStripType)) {
            return;
        }
        ensureIdle("The reel strip type cannot be changed when the reel animation is in progress.");
        reelStripContext = new ReelStripSymbolsContext(reelStripDefinitionProvider.getReelStripDefinition(reelStripType, getIndex()).getSymbols());
        this.reelStripType = reelStripType;

        Iterable<String> symbolNames = getSymbolNamesToDisplay();
        displayStoppedSymbols(symbolNames);
    }

    @Override
    public String getReelStripType() {
        return reelStripType;
    }

    @Override
    public ISymbolsConfiguration getSymbolsConfiguration() {
        return symbolsConfiguration;
    }

    /**
     * Sets the symbols configuration.
     * @param symbolsConfiguration The symbols configuration.
     */
    public void setSymbolsConfiguration(ISymbolsConfiguration symbolsConfiguration) {
        ensureIdle("The symbols configuration cannot be changed when the reel animation is in progress.");
        CONFIGURATION_VALIDATOR.validateConfiguration(symbolsConfiguration);
        this.symbolsConfiguration = symbolsConfiguration;
        if (reelAnimation != null) {
            initializeAnimation(reelAnimation);
        }
    }

    @Override
    public void setReelAnimation(IReelAnimation reelAnimation) {
        if (reelAnimation == null) {
            throw new IllegalArgumentException("The reel animation cannot be null.");
        }

        ensureIdle("Cannot replace the reel animation when current animation is in progress.");
        clearAnimationSubscribers();
        this.reelAnimation = reelAnimation;
        registerAnimationSubscribers();
        if (symbolsConfiguration != null) {
            initializeAnimation(this.reelAnimation);
        }
    }

    @Override
    public IReelAnimation getReelAnimation() {
        return reelAnimation;
    }

    @Override
    public AbstractSymbol getDisplayedSymbol(int rowPosition) {
        validateAccessToSymbol(rowPosition);
        return stoppedSymbols.get(rowPosition);
    }

    @Override
    public List<AbstractSymbol> getDisplayedSymbols() {
        ensureIdle("Cannot determine the displayed symbols when the reel animation is in progress.");
        return stoppedSymbols;
    }

    @Override
    public void spin() {
        synchronized (this) {
            if (!isIdle()) {
                return;
            }
            resetContainerPosition();
            slv.symbols = getFullStoppingSymbolSequence();
            repositionReelStripContext();
            notifyAnimationSequence(slv.symbols);
            stoppedSymbols.clear();
            isStopping = false;
            isForceStopping = false;
            symbolsLeftBeforeStop = 0;
            reelAnimation.play();
            setReelState(ReelState.SPINNING);
        }
    }

    @Override
    public void stopOnSymbols(Iterable<String> stoppingSymbolNames) {
        synchronized (this) {
            validateSymbolNames(stoppingSymbolNames);
            switch (reelState) {
                case IDLE:
                    displayStoppedSymbols(stoppingSymbolNames);
                    break;
                case SPINNING:
                    setReelState(ReelState.STOPPING);
                    updateStoppingContext(stoppingSymbolNames);
                    break;
                case STOPPING:
                    throw new IllegalStateException("The reel is already in its stopping phase.");
            }
        }
    }

    @Override
    public void forceStopOnSymbols(Iterable<String> stoppingSymbolNames) {
        synchronized (this) {
            validateSymbolNames(stoppingSymbolNames);
            switch (reelState) {
                case IDLE:
                    displayStoppedSymbols(stoppingSymbolNames);
                    break;
                case SPINNING:
                    setReelState(ReelState.STOPPING);
                    updateStoppingContext(stoppingSymbolNames);
                    reelAnimation.speedUp();
                    break;
                case STOPPING:
                    if (isForceStopping) {
                        throw new IllegalStateException("The reel is already in its force-stopping phase.");
                    }
                    if (!hasActiveStoppingContextFor(stoppingSymbolNames)) {
                        throw new IllegalStateException("The reel is already stopping in another context.");
                    }
                    isForceStopping = true;
                    reelAnimation.speedUp();
                    break;
            }
        }
    }

    /**
     * Validates if currently is possible to access to stopped symbol or not.
     * @param rowPosition the row position of the symbol
     */
    private void validateAccessToSymbol(int rowPosition) {
        int rowCount = symbolsConfiguration.getRowCount();
        if (rowPosition < 0 || rowPosition >= rowCount) {
            throw new IllegalArgumentException(StringUtility.format("The row position must be within the range of [0,%s]", rowCount - 1));
        }
        ensureIdle("Cannot determine the displayed symbols when the reel animation is in progress.");
    }

    /**
     * Resets the position of the symbols container.
     */
    private void resetContainerPosition() {
        symbolsContainer.setY(0f);
    }

    /**
     * Gets the full stopping symbols sequence including both prepended and appended symbols.
     * @return The full stopping symbols sequence.
     */
    private List<AbstractSymbol> getFullStoppingSymbolSequence() {
        slv.symbols.clear();
        slv.prependedSymbolNames = getPrependedSymbolNames();
        slv.appendedSymbolNames = getAppendedSymbolNames();
        slv.position = -reelAnimation.getPrependedSymbolsCount();
        for (slv.index = 0; slv.index < slv.prependedSymbolNames.size(); slv.index++) {
            slv.symbolName = slv.prependedSymbolNames.get(slv.index);
            slv.symbol = createSymbol(slv.symbolName);
            addToStage(slv.symbol, slv.position++);
            slv.symbols.add(slv.symbol);
        }

        if (!stoppedSymbols.isEmpty()) {
            // reuse already displayed symbols.
            for (slv.index = 0; slv.index < stoppedSymbols.size(); slv.index++) {
                slv.symbol = stoppedSymbols.get(slv.index);
                slv.symbols.add(slv.symbol);
                slv.position++;
            }
        } else {
            // otherwise create them.
            for (slv.index = 0; slv.index < slv.prependedSymbolNames.size(); slv.index++) {
                slv.symbolName = slv.prependedSymbolNames.get(slv.index);
                slv.symbol = createSymbol(slv.symbolName);
                stoppedSymbols.add(slv.symbol);
                addToStage(slv.symbol, slv.position++);
                slv.symbols.add(slv.symbol);
            }
        }

        for (slv.index = 0; slv.index < slv.appendedSymbolNames.size(); slv.index++) {
            slv.symbolName = slv.appendedSymbolNames.get(slv.index);
            slv.symbol = createSymbol(slv.symbolName);
            addToStage(slv.symbol, slv.position++);
            slv.symbols.add(slv.symbol);
        }

        return slv.symbols;
    }

    /**
     * Gets the appended symbol names in the amount required by the reel animation.
     * @return The appended symbol names required by the reel animation.
     */
    private LinkedList<String> getAppendedSymbolNames() {
        slv.appendedSymbolNames.clear();

        // get appended symbols from stopping context.
        int appendedSize = stoppingContext.getAppendedSymbolNames().size();
        int padCount = Math.min(reelAnimation.getAppendedSymbolsCount(), appendedSize);
        for (int i = 0; i < padCount; i++) {
            slv.appendedSymbolNames.addLast(stoppingContext.getAppendedSymbolNames().get(i));
        }

        // pad the bottom part of stopping context with symbols from reel strip.
        int leftToAppend = reelAnimation.getAppendedSymbolsCount() - appendedSize;
        int reelStripPosition = stoppingContext.getReelStripPosition();
        while (leftToAppend > 0) {
            // since we're past that position on reel strip only peek for it.
            String symbolName = reelStripContext.getSymbolNameAt(reelStripPosition--);
            slv.appendedSymbolNames.addLast(symbolName);
            leftToAppend--;
        }

        return slv.appendedSymbolNames;
    }

    /**
     * Gets the prepended symbol names in the amount required by the reel animation.
     * @return The prepended symbol names required by the reel animation.
     */
    private LinkedList<String> getPrependedSymbolNames() {
        slv.prependedSymbolNames.clear();

        // get prepended symbols from stopping context.
        int prependedSize = stoppingContext.getPrependedSymbolNames().size();
        int padCount = Math.min(reelAnimation.getPrependedSymbolsCount(), prependedSize);
        for (int i = prependedSize - padCount; i < prependedSize; i++) {
            slv.prependedSymbolNames.addLast(stoppingContext.getPrependedSymbolNames().get(i));
        }

        // pad the top part of stopping context with symbols from reel strip.
        int leftToPrepend = reelAnimation.getPrependedSymbolsCount() - prependedSize;
        int reelStripPosition = stoppingContext.getReelStripPosition() + 1;
        while (leftToPrepend > 0) {
            // since that point on reel strip is ahead proceed to next symbol.
            String symbolName = reelStripContext.getSymbolNameAt(reelStripPosition++);
            slv.prependedSymbolNames.addFirst(symbolName);
            leftToPrepend--;
        }

        return slv.prependedSymbolNames;
    }

    /**
     * Repositions the reel strip context according to the recent stopping context.
     */
    private void repositionReelStripContext() {
        int prependedCount = reelAnimation.getPrependedSymbolsCount() - stoppingContext.getPrependedSymbolNames().size();
        if (prependedCount > 0) {
            int stoppingPosition = stoppingContext.getReelStripPosition();
            reelStripContext.moveTo(stoppingPosition + prependedCount);
        }
    }

    /**
     * Repositions the stopping context so that it points to.
     */
    private void repositionStoppingContext() {
        int appendedCount = stoppingContext.getPrependedSymbolNames().size() - reelAnimation.getPrependedSymbolsCount();
        if (appendedCount < 0) {
            appendedCount = 0;
        }
        stoppingContext.moveTo(stoppingContext.size() - appendedCount - 1);
    }

    /**
     * Processes symbols incoming from the animation.
     * @param returningSymbol The returning symbol.
     */
    private void processIncomingSymbol(AbstractSymbol returningSymbol) {
        if (!stoppedSymbols.contains(returningSymbol)) {
            removeFromStage(returningSymbol);
            destroySymbol(returningSymbol);
        }
        if (!isStopping) {
            processOutgoingSymbol();
        }
    }

    /**
     * Processes symbols outgoing to the animation.
     */
    private void processOutgoingSymbol() {
        ISymbolsContext symbolsContext = getCurrentSymbolsContext();
        String symbolName = symbolsContext.next();
        AbstractSymbol nextSymbol = createSymbol(symbolName);
        if (symbolsContext.isStoppingSymbol()) {
            if (stoppedSymbols.isEmpty()) {
                symbolsLeftBeforeStop = symbolsConfiguration.getRowCount() + reelAnimation.getPrependedSymbolsCount();
            }
            stoppedSymbols.add(0, nextSymbol);
        }

        lv.symbolsContainerIterator = symbolsContainer.getChildrenRaw().iterator();

        while (lv.symbolsContainerIterator.hasNext()) {
            lv.child = lv.symbolsContainerIterator.next();
            lv.child.setY(lv.child.getY() + symbolsConfiguration.getSymbolHeight());
        }

        addToStage(nextSymbol, -reelAnimation.getPrependedSymbolsCount());
        reelAnimation.getAnimatingSymbols().onNext(nextSymbol);
        if (symbolsLeftBeforeStop > 0) {
            symbolsLeftBeforeStop--;
            if (symbolsLeftBeforeStop == 0) {
                isStopping = true;
                reelAnimation.beginStop();
            }
        }
    }

    /**
     * Adds given symbol to the symbol container at given position.
     * @param symbol   The symbol to add.
     * @param position A zero-based position of the symbol.
     */
    private void addToStage(AbstractSymbol symbol, int position) {
        symbolsContainer.addChild(symbol);
        symbol.setVisible(true);
        symbol.setY(position * symbolsConfiguration.getSymbolHeight());
    }

    /**
     * Removes given symbol from the stage.
     * @param symbol The symbol to remove.
     */
    private void removeFromStage(AbstractSymbol symbol) {
        symbolsContainer.removeChild(symbol, false);
        symbol.setVisible(false);
    }

    /**
     * Notifies the animation regarding animating symbols in the reverse order of given sequence.
     * @param sequence The sequence of symbols.
     */
    private void notifyAnimationSequence(List<AbstractSymbol> sequence) {
        slv.size = sequence.size() - 1;
        for (slv.index = slv.size; slv.index >= 0; slv.index--) {
            reelAnimation.getAnimatingSymbols().onNext(sequence.get(slv.index));
        }
    }

    @Override
    public void setDisplayedSymbol(int rowPosition, String symbolName) {
        validateAccessToSymbol(rowPosition);
        AbstractSymbol symbolToPut = createSymbol(symbolName);
        if (symbolToPut == null) {
            throw new IllegalArgumentException(StringUtility.format("Symbol with name: %s, is not exists in pool", symbolName));
        }
        AbstractSymbol symbolToRemove = getDisplayedSymbol(rowPosition);
        removeFromStage(symbolToRemove);
        destroySymbol(symbolToRemove);
        stoppedSymbols.remove(rowPosition);

        stoppedSymbols.add(rowPosition, symbolToPut);
        addToStage(symbolToPut, rowPosition);
    }

    /**
     * Displays stopped symbols of given names.
     * @param stoppedSymbolNames The stopped symbols names.
     */
    private void displayStoppedSymbols(Iterable<String> stoppedSymbolNames) {
        updateStoppingContext(stoppedSymbolNames);
        resetContainerPosition();
        repositionStoppingContext();
        int symbolsCount = symbolsContainer.getChildCount();
        AbstractSymbol symbol;
        for (int index = symbolsCount - 1; index >= 0; index--) {
            symbol = (AbstractSymbol) symbolsContainer.getChildrenRaw().get(index);
            removeFromStage(symbol);
            destroySymbol(symbol);
        }

        stoppedSymbols.clear();
        int position = 0;
        for (String symbolName : stoppedSymbolNames) {
            symbol = createSymbol(symbolName);
            stoppedSymbols.add(symbol);
            addToStage(symbol, position++);
        }
    }

    /**
     * Checks whether this reel has stopped on the right spot.
     * @return True if the the reel has stopped on the right spot.
     */
    private boolean hasStoppedInRightPlace() {
        if (stoppedSymbols.size() != symbolsConfiguration.getRowCount()) {
            return false;
        }
        int symbolHeight = symbolsConfiguration.getSymbolHeight();
        for (int i = 0; i < stoppedSymbols.size(); i++) {
            AbstractSymbol stoppedSymbol = stoppedSymbols.get(i);
            if (!stoppedSymbol.getName().equals(stoppingContext.getStoppingSymbolNames().get(i))) {
                return false;
            }
            if (!stoppedSymbol.getParent().equals(symbolsContainer)) {
                return false;
            }
            if (stoppedSymbol.getY() != i * symbolHeight) {
                return false;
            }
        }
        if (symbolsContainer.getY() != 0) {
            return false;
        }
        return true;
    }

    /**
     * Verifies whether stopped symbols are in the right spot or fixes them in case they don't.
     */
    private void verifyStoppedSymbols() {
        if (hasStoppedInRightPlace()) {
            removeUnusedSymbols();
        } else {
            displayStoppedSymbols(getSymbolNamesToDisplay());
        }
    }

    /**
     * Removes additional symbols present on the stage apart from the stopped symbols.
     */
    private void removeUnusedSymbols() {
        int count = symbolsContainer.getChildCount();
        AbstractSymbol symbol;
        for (int index = count - 1; index >= 0; index--) {
            symbol = (AbstractSymbol) symbolsContainer.getChildrenRaw().get(index);
            if (!stoppedSymbols.contains(symbol)) {
                removeFromStage(symbol);
                destroySymbol(symbol);
            }
        }
    }

    /**
     * Gets a value indicating whether current stopping context matches given stopping symbol names.
     * @param stoppingSymbolNames Stopping symbol names.
     * @return True if current stopping context matches given names, false otherwise.
     */
    private boolean hasActiveStoppingContextFor(Iterable<String> stoppingSymbolNames) {
        return stoppingContext != null && Iterables.areEqual(stoppingSymbolNames, stoppingContext.getStoppingSymbolNames());
    }

    /**
     * Calculates a new stopping context according to given stopping symbol names.
     * @param stoppingSymbolNames Stopping symbol names.
     */
    private void updateStoppingContext(Iterable<String> stoppingSymbolNames) {
        int reelStripPosition = reelStripContext.getCurrentPosition();
        ISymbolAppendingStrategy symbolAppending = symbolsConfiguration.getSymbolAppending();
        slv.prependedSymbolNamesIterable = symbolAppending.getPrependedSymbols(stoppingSymbolNames, reelStripContext.getSymbols(), reelStripPosition);
        slv.appendedSymbolNamesIterable = symbolAppending.getAppendedSymbols(stoppingSymbolNames, reelStripContext.getSymbols(), reelStripPosition);
        stoppingContext = new StoppingSymbolsContext(slv.prependedSymbolNamesIterable, stoppingSymbolNames, slv.appendedSymbolNamesIterable, reelStripPosition);
    }

    /**
     * Gets currently active {@link ReelView.ISymbolsContext}.
     * @return Curretly active context.
     */
    private ISymbolsContext getCurrentSymbolsContext() {
        if (stoppingContext != null && stoppingContext.hasNext()) {
            return stoppingContext;
        }
        return reelStripContext;
    }

    /**
     * Creates a new symbol of given name using the symbol pool.
     * @param symbolName The symbol name.
     * @return An instance of symbol.
     */
    private AbstractSymbol createSymbol(String symbolName) {
        return symbolsConfiguration.getSymbolPool().getSymbol(symbolName);
    }

    /**
     * Returns given symbol to its pool.
     * @param symbol The symbol to return.
     */
    private void destroySymbol(AbstractSymbol symbol) {
        symbolsConfiguration.getSymbolPool().returnSymbol(symbol);
    }

    /**
     * Gets a default collection of symbol names to display.
     * @return a default collection of symbol names to display.
     */
    private Iterable<String> getDefaultSymbolNamesToDisplay() {
        List<String> stoppingSymbols = new ArrayList<>();
        for (int i = 0; i < symbolsConfiguration.getRowCount(); i++) {
            stoppingSymbols.add(reelStripContext.getSymbolNameAt(i));
        }
        return stoppingSymbols;
    }

    /**
     * Gets a collection of symbol names to display.
     * @return a collection of symbol names to display.
     */
    private Iterable<String> getSymbolNamesToDisplay() {
        return stoppingContext == null ? getDefaultSymbolNamesToDisplay() : stoppingContext.getStoppingSymbolNames();
    }

    /**
     * Checks whether stopping symbol names are valid.
     * @param stoppingSymbolNames Stopping symbol names to check.
     */
    private void validateSymbolNames(Iterable<String> stoppingSymbolNames) {
        if (stoppingSymbolNames == null) {
            throw new IllegalArgumentException("Stopping symbol names are not defined.");
        }
        if (Iterables.size(stoppingSymbolNames) != symbolsConfiguration.getRowCount()) {
            throw new IllegalArgumentException("The number of stopping symbols must match reel's row count.");
        }
    }

    /**
     * Registers animation subscribers.
     */
    private void registerAnimationSubscribers() {
        Subscription subscription = reelAnimation.getReturningSymbols().subscribe(returningSymbol -> processIncomingSymbol(returningSymbol));
        animationSubscriptions.add(subscription);

        Subscription subscription1 = reelAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                verifyStoppedSymbols();
                isForceStopping = false;
                isStopping = false;
                setReelState(ReelState.IDLE);
            }
        });
        animationSubscriptions.add(subscription1);
    }

    /**
     * Clears animation subscribers.
     */
    private void clearAnimationSubscribers() {
        for (Subscription subscription : animationSubscriptions) {
            subscription.unsubscribe();
        }
        animationSubscriptions.clear();
    }

    /**
     * Sets the reel state.
     * @param reelState The reel state.
     */
    private void setReelState(ReelState reelState) {
        if (this.reelState == reelState) {
            return;
        }

        this.reelState = reelState;
        reelStateSubject.onNext(reelState);
    }

    /**
     * Gets a value indicating whether the reel is in idle state.
     * @return a value indicating whether the reel is in idle state.
     */
    private boolean isIdle() {
        return reelState == ReelState.IDLE;
    }

    /**
     * Throws an exception in case the reel is not in idle state.
     * @param errorMessage The error message.
     */
    private void ensureIdle(String errorMessage) {
        if (!isIdle()) {
            throw new IllegalStateException(errorMessage);
        }
    }

    /**
     * Initializes the animation.
     * @param animation The animation to initializes.
     */
    private void initializeAnimation(IReelAnimation animation) {
        animation.setUp(symbolsConfiguration);
    }

    @Override
    public void reset() {
        reelAnimation.stop();
    }

    /**
     * A context denoting consecutive symbol names which should be used by the reel.
     */
    private interface ISymbolsContext extends Iterator<String> {

        /**
         * Resets the context to its initial position.
         */
        void reset();

        /**
         * Adjust the context by moving its pointer to a certain position (zero-based).
         * @param position The position in the context.
         */
        void moveTo(int position);

        /**
         * Checks whether the current position of this context points to a symbol name that belongs to a stopping
         * sequence.
         * @return True if current symbol name points to a stopping symbol.
         */
        boolean isStoppingSymbol();
    }

    /**
     * A context containing symbol names which the reel stops on.
     */
    private class StoppingSymbolsContext implements ISymbolsContext {

        /**
         * A list of symbol names prepended by the appending strategy.
         */
        private final List<String> prependedSymbols;

        /**
         * A list of stopping symbols.
         */
        private final List<String> stoppingSymbols;

        /**
         * A list of symbol names appended by the appending strategy.
         */
        private final List<String> appendedSymbols;

        /**
         * A joint stack of prepended, stopping and appended symbol names.
         */
        private final LinkedList<String> allSymbols;

        /**
         * A reel strip position the stopping context belongs to.
         */
        private final int reelStripPosition;

        /**
         * The first stopping symbol position.
         */
        private final int firstStoppingSymbolPosition;

        /**
         * The last stopping symbol position.
         */
        private final int lastStoppingSymbolPosition;

        /**
         * Current position.
         */
        private int currentPosition;

        /**
         * Initializes a new instance of the {@link ReelView.StoppingSymbolsContext}.
         * @param prependedSymbols  A collection of symbol names prepended to the stopping sequence by the appending strategy.
         * @param stoppingSymbols   A collection of symbol names the reel should stop on.
         * @param appendedSymbols   A collection of symbol names appended to the stopping sequence by the appending strategy.
         * @param reelStripPosition A reel strip position the stopping context belongs to.
         */
        public StoppingSymbolsContext(Iterable<String> prependedSymbols, Iterable<String> stoppingSymbols, Iterable<String> appendedSymbols,
                int reelStripPosition) {
            this.prependedSymbols = Iterables.toList(prependedSymbols);
            this.stoppingSymbols = Iterables.toList(stoppingSymbols);
            this.appendedSymbols = Iterables.toList(appendedSymbols);
            this.reelStripPosition = reelStripPosition;
            allSymbols = new LinkedList<>();
            pushAll(prependedSymbols);
            pushAll(stoppingSymbols);
            pushAll(appendedSymbols);
            reset();
            firstStoppingSymbolPosition = this.appendedSymbols.size();
            lastStoppingSymbolPosition = this.appendedSymbols.size() + this.stoppingSymbols.size() - 1;
        }

        /**
         * Gets the list strip position at which this context disjoined it.
         * @return The reel strip position at which this context disjoined it.
         */
        public int getReelStripPosition() {
            return reelStripPosition;
        }

        /**
         * Gets a list of symbol names prepended to the stopping sequence by the appending strategy.
         * @return a list of symbol names prepended to the stopping sequence by the appending strategy.
         */
        public List<String> getPrependedSymbolNames() {
            return prependedSymbols;
        }

        /**
         * Gets a list of symbol names appended to the stopping sequence by the appending strategy.
         * @return a list of symbol names appended to the stopping sequence by the appending strategy.
         */
        public List<String> getAppendedSymbolNames() {
            return appendedSymbols;
        }

        /**
         * Gets a collection of symbol names the reel should stop on.
         * @return A collection of symbol names the reel should stop on.
         */
        public List<String> getStoppingSymbolNames() {
            return stoppingSymbols;
        }

        /**
         * Gets the size of this stopping context.
         * @return The size of this stopping context including both appended and prepended symbols.
         */
        public int size() {
            return allSymbols.size();
        }

        @Override
        public String next() {
            if (!hasNext()) {
                throw new NoSuchElementException("The next symbol is unavailable");
            }
            currentPosition++;
            return allSymbols.get(currentPosition);
        }

        @Override
        public boolean hasNext() {
            return currentPosition < allSymbols.size() - 1;
        }

        @Override
        public void reset() {
            currentPosition = -1;
        }

        @Override
        public void moveTo(int position) {
            if (position >= 0 && position < allSymbols.size()) {
                currentPosition = position;
            } else {
                currentPosition = allSymbols.size();
            }
        }

        @Override
        public boolean isStoppingSymbol() {
            return currentPosition >= firstStoppingSymbolPosition && currentPosition <= lastStoppingSymbolPosition;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("The remove operation is not supported in symbols contexts");
        }

        /**
         * Push all given symbols to a common stack.
         * @param symbols The symbols to push.
         */
        private void pushAll(Iterable<String> symbols) {
            for (String symbol : symbols) {
                allSymbols.addFirst(symbol);
            }
        }
    }

    /**
     * A context containing symbol names as defined in currently active reel strip.
     */
    private class ReelStripSymbolsContext implements ISymbolsContext {

        /**
         * A reel strip symbol names.
         */
        private final List<String> reelStrip;

        /**
         * The reel strip current position.
         */
        private int currentPosition;

        /**
         * Initializes a new instance of the {@link ReelView.ReelStripSymbolsContext}
         * using given reel strip definition.
         * @param reelStrip The reel strip definition.
         */
        public ReelStripSymbolsContext(Iterable<String> reelStrip) {
            this.reelStrip = Iterables.toList(reelStrip);
            if (this.reelStrip.isEmpty()) {
                throw new IllegalArgumentException("The reel strip must have at least one symbol defined");
            }
            reset();
        }

        @Override
        public String next() {
            currentPosition = (currentPosition + 1) % reelStrip.size();
            return reelStrip.get(currentPosition);
        }

        @Override
        public boolean hasNext() {
            // since the reel strip context is round-robin, it also has the next symbol.
            return true;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("The remove operation is not supported in symbols contexts");
        }

        /**
         * Gets the current position of this reel strip.
         * @return The current position of this reel strip.
         */
        public int getCurrentPosition() {
            return currentPosition;
        }

        /**
         * Peeks the name of the symbol at given position.
         * @param position The position in the context.
         * @return The name of the symbol at given position.
         */
        public String getSymbolNameAt(int position) {
            int index = sanitizePosition(position);
            return reelStrip.get(index);
        }

        @Override
        public void reset() {
            currentPosition = reelStrip.size() - 1;
        }

        @Override
        public void moveTo(int position) {
            currentPosition = sanitizePosition(position);
        }

        @Override
        public boolean isStoppingSymbol() {
            // stopping symbols never come from the reel strip.
            return false;
        }

        /**
         * Gets symbol names in this reel strip context.
         * @return A collection of symbol names in this reel strip context.
         */
        public Iterable<String> getSymbols() {
            return reelStrip;
        }

        /**
         * Sanitizes the position by limiting it to a reel strip range.
         * @param position The position in the context.
         * @return A position within the rage of this reel strip context.
         */
        private int sanitizePosition(int position) {
            int count = reelStrip.size();
            if (position >= 0) {
                return position % count;
            } else {
                return count - position % count - 2;
            }
        }
    }

    /**
     * Holder for instances of local variables used in the {@link ReelView} render method.
     */
    private class LocalVariables {

        private Iterator<? extends View> symbolsContainerIterator;

        private View child;
    }

    /**
     * Holder for instances of local variables used for symbols in the {@link ReelView} render method.
     */
    private class SymbolLocalVariables {

        private List<AbstractSymbol> symbols = new LinkedList<>();

        private int index;

        private int size;

        private LinkedList<String> prependedSymbolNames = new LinkedList<>();

        private LinkedList<String> appendedSymbolNames = new LinkedList<>();

        private int position;

        private String symbolName;

        private AbstractSymbol symbol;

        private Iterable<String> appendedSymbolNamesIterable;

        private Iterable<String> prependedSymbolNamesIterable;
    }
}
