package com.atsisa.gox.reels.fsm;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.event.RegisterTranslationCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.command.EnterGamblerCommand;
import com.atsisa.gox.reels.command.EnterHistoryCommand;
import com.atsisa.gox.reels.command.ExitHistoryCommand;
import com.atsisa.gox.reels.command.GameErrorCommand;
import com.atsisa.gox.reels.command.NextInfoScreenCommand;
import com.atsisa.gox.reels.command.ResetGameCommand;
import com.atsisa.gox.reels.command.ShowNextHistoryPageCommand;
import com.atsisa.gox.reels.command.ShowPreviousHistoryPageCommand;
import com.atsisa.gox.reels.command.SkipCommand;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.command.StartAutoPlayCommand;
import com.atsisa.gox.reels.command.StopAutoPlayCommand;
import com.atsisa.gox.reels.command.TakeWinCommand;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.event.EnteredHistoryEvent;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.HistoryCloseEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.Language;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.model.IErrorModel;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.google.inject.Inject;

/**
 * Handles all aspects related to the reel game state.
 */
public class ReelGameStateHolder implements IReelGameStateHolder {

    /**
     * On error queue name.
     */
    private static final String ON_ERROR_QUEUE_NAME = "OnError";

    /**
     * Spin reels queue name.
     */
    private static final String SPIN_REELS_QUEUE_NAME = "SpinReels";

    /**
     * Enter history queue name.
     */
    private static final String ENTER_HISTORY_QUEUE_NAME = "EnterHistory";

    /**
     * Exit history queue name.
     */
    private static final String EXIT_HISTORY_QUEUE_NAME = "ExitHistory";

    /**
     * Show next history page queue name.
     */
    private static final String SHOW_NEXT_HISTORY_PAGE_QUEUE_NAME = "ShowNextHistoryPage";

    /**
     * Show previous history page queue name.
     */
    private static final String SHOW_PREVIOUS_HISTORY_PAGE_QUEUE_NAME = "ShowPreviousHistoryPage";

    /**
     * Selected gambler red card queue name.
     */
    private static final String SELECTED_GAMBLER_RED_CARD_QUEUE_NAME = "SelectedGamblerRedCard";

    /**
     * Selected gambler black card queue name.
     */
    private static final String SELECTED_GAMBLER_BLACK_CARD_QUEUE_NAME = "SelectedGamblerBlackCard";

    /**
     * Take win queue name.
     */
    private static final String TAKE_WIN_QUEUE_NAME = "TakeWin";

    /**
     * Reset game queue name.
     */
    private static final String RESET_GAME_QUEUE_NAME = "ResetGame";

    /**
     * Show next info screen queue name.
     */
    private static final String SHOW_NEXT_INFO_SCREEN_QUEUE_NAME = "ShowNextInfoScreen";

    /**
     * Entering gambler queue name.
     */
    private static final String ENTERING_GAMBLER_QUEUE_NAME = "EnteringGambler";

    /**
     * Event bus reference.
     */
    protected final IEventBus eventBus;

    /**
     * Action manager reference.
     */
    private final IActionManager actionManager;

    /**
     * View manager reference.
     */
    private final IViewManager viewManager;

    /**
     * Reels game state model, which contains information about current reels state in game.
     */
    private final ReelsStateModel reelsStateModel;

    /**
     * Auto play flag.
     */
    private boolean autoPlay;

    /**
     * A boolean value that indicates whether game is in history mode or not.
     */
    private final AtomicBoolean historyMode;

    /**
     * Initializes new instance of ReelGameStateHolder.
     * @param eventBus      {@link IEventBus}
     * @param actionManager {@link IActionManager}
     * @param viewManager   {@link IViewManager}
     */
    @Inject
    public ReelGameStateHolder(IEventBus eventBus, IActionManager actionManager, IViewManager viewManager) {
        this.eventBus = eventBus;
        this.actionManager = actionManager;
        this.viewManager = viewManager;
        reelsStateModel = new ReelsStateModel();
        historyMode = new AtomicBoolean(false);
        registerEvents();
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        eventBus.register(new LogicPresentationObserver(), LogicPresentation.class);
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new SpinButtonClickedObserver(), SpinCommand.class);
        eventBus.register(new SkipButtonClickedObserver(), SkipCommand.class);
        eventBus.register(new TakeButtonClickedObserver(), TakeWinCommand.class);
        eventBus.register(new StopAutoPlayCommandObserver(), StopAutoPlayCommand.class);
        eventBus.register(new StartAutoPlayCommandObserver(), StartAutoPlayCommand.class);
        eventBus.register(new GamblerCardSelectedObserver(), GamblerCardSelectedEvent.class);
        eventBus.register(new ResetGameCommandObserver(), ResetGameCommand.class);
        eventBus.register(new EnterHistoryCommandObserver(), EnterHistoryCommand.class);
        eventBus.register(new ExitHistoryCommandObserver(), ExitHistoryCommand.class);
        eventBus.register(new ShowNextHistoryPageCommandObserver(), ShowNextHistoryPageCommand.class);
        eventBus.register(new ShowPreviousHistoryPageCommandObserver(), ShowPreviousHistoryPageCommand.class);
        eventBus.register(new GameErrorCommandObserver(), GameErrorCommand.class);
        eventBus.register(new NextInfoScreenCommandObserver(), NextInfoScreenCommand.class);
        eventBus.register(new EnterGamblerCommandObserver(), EnterGamblerCommand.class);
    }

    /**
     * Handles all logic presentations.
     * @param logicPresentation {@link LogicPresentation}
     */
    private void handleLogicPresentation(LogicPresentation logicPresentation) {
        if (!(logicPresentation instanceof ReelGamePresentation)) {
            return;
        }
        reelsStateModel.initializeReels(((ReelGamePresentation) logicPresentation).getReels());
        checkHistory(logicPresentation);
        String presentationName = logicPresentation.getName();
        if (isHistoryMode()) {
            presentationName = StringUtility.format("%s%s", "H", presentationName);
        }
        processActionQueue(presentationName);
    }

    /**
     * Handles the init result.
     * @param initResult {@link InitResult}
     */
    private void handleInitResult(final InitResult initResult) {
        Language activeLanguage = initResult.getLanguageInfo().getActiveLanguage();
        eventBus.post(new RegisterTranslationCommand(activeLanguage.getLanguageCode(), activeLanguage.getTranslation()));
        reelsStateModel.initializeSymbols(initResult.getGameConfiguration().getSymbolsMap());
    }

    /**
     * Checks if specific logicPresentation is history logicPresentation or not.
     * @param logicPresentation {@link LogicPresentation}
     */
    private void checkHistory(LogicPresentation logicPresentation) {
        if (logicPresentation.isHistory() && !historyMode.getAndSet(true)) {
            eventBus.post(new EnteredHistoryEvent());
        } else if (!logicPresentation.isHistory() && historyMode.getAndSet(false)) {
            eventBus.post(new HistoryCloseEvent());
        }
    }

    /**
     * Processes the action queue in case it was define. Otherwise publishes an
     * {@link ErrorOccurredEvent}.
     * @param actionQueueName The action queue name.
     */
    protected void processActionQueue(String actionQueueName) {
        actionManager.processQueue(actionQueueName, true);
    }

    @Override
    public List<Iterable<String>> getStoppedSymbols() {
        return reelsStateModel.getStoppedSymbols();
    }

    @Override
    public List<Reel> getReels() {
        return reelsStateModel.getReels();
    }

    @Override
    public boolean isAutoPlay() {
        return autoPlay;
    }

    @Override
    public boolean isHistoryMode() {
        return historyMode.get();
    }

    /**
     * Handles spin button click events received from the bus.
     * @param spinCommand event representing spin button click.
     */
    @Subscribe
    public synchronized void handleSpinCommand(final SpinCommand spinCommand) {
        processActionQueue(SPIN_REELS_QUEUE_NAME);
    }

    /**
     * Handles request to start auto play.
     * @param startAutoPlayCommand {@link StartAutoPlayCommand}
     */
    @Subscribe
    public void handleStartAutoPlayCommand(final StartAutoPlayCommand startAutoPlayCommand) {
        processAutoPlaySpinQueue(SPIN_REELS_QUEUE_NAME, startAutoPlayCommand);
    }

    /**
     * Processes spin queue name.
     * @param queueName queue name
     * @param eventTriggered event which triggered spin queue
     */
    protected void processAutoPlaySpinQueue(final String queueName, Object eventTriggered) {
        if (!autoPlay) {
            autoPlay = true;
            AutoPlayStartedEvent autoPlayStartedEvent = new AutoPlayStartedEvent();
            autoPlayStartedEvent.setSourceEvent(eventTriggered);
            eventBus.post(autoPlayStartedEvent);
            if (actionManager.getActiveQueue() == null) {
                processActionQueue(queueName);
            }
        }
    }

    /**
     * Handles request to stop auto play.
     */
    private void handleStopAutoPlayCommand(StopAutoPlayCommand stopAutoPlayCommand) {
        if (autoPlay) {
            autoPlay = false;
            AutoPlayStoppedEvent autoPlayStoppedEvent = new AutoPlayStoppedEvent();
            autoPlayStoppedEvent.setSourceEvent(stopAutoPlayCommand);
            eventBus.post(autoPlayStoppedEvent);
        }
    }

    /**
     * Handles gambler selected card events received from the bus.
     * @param gamblerCardSelectedEvent event representing selected card.
     */
    private void handleGamblerCardSelectedEvent(final GamblerCardSelectedEvent gamblerCardSelectedEvent) {
        if (gamblerCardSelectedEvent.getCardType() == CardType.BLACK) {
            processActionQueue(SELECTED_GAMBLER_BLACK_CARD_QUEUE_NAME);
        } else if (gamblerCardSelectedEvent.getCardType() == CardType.RED) {
            processActionQueue(SELECTED_GAMBLER_RED_CARD_QUEUE_NAME);
        }
    }

    /**
     * Handles skip button click events.
     */
    private synchronized void handleSkipCommand() {
        actionManager.terminateActiveAction();
    }

    /**
     * Handles take button clicked events.
     */
    @Subscribe
    private synchronized void handleTakeCommand() {
        actionManager.terminateActiveAction();
        processActionQueue(TAKE_WIN_QUEUE_NAME);
    }

    /**
     * Handles a request to enter history.
     */
    private void handleEnterHistoryCommand() {
        if (!isHistoryMode()) {
            processActionQueue(ENTER_HISTORY_QUEUE_NAME);
        }
    }

    /**
     * Handles a request to close history.
     */
    private void handleExitHistoryCommand() {
        if (isHistoryMode()) {
            processActionQueue(EXIT_HISTORY_QUEUE_NAME);
        }
    }

    /**
     * Handles reset game.
     */
    private void handleResetGame() {
        processActionQueue(RESET_GAME_QUEUE_NAME);
    }

    /**
     * Handles show next history page command.
     */
    private void handleShowNextHistoryPageCommand() {
        processActionQueue(SHOW_NEXT_HISTORY_PAGE_QUEUE_NAME);
    }

    /**
     * Handles show previous history page command.
     */
    private void handleShowPreviousHistoryPageCommand() {
        processActionQueue(SHOW_PREVIOUS_HISTORY_PAGE_QUEUE_NAME);
    }

    /**
     * Handles game error command.
     * @param gameErrorCommand {@link GameErrorCommand}
     */
    private void handleGameErrorCommand(GameErrorCommand gameErrorCommand) {
        actionManager.destroyActiveQueue();
        if (actionManager.getActionBuilder().containsQueue(ON_ERROR_QUEUE_NAME)) {
            actionManager.processQueue(ON_ERROR_QUEUE_NAME, true);
        } else {
            List<ErrorScreen> errorScreens = viewManager.getScreenByType(ErrorScreen.class);
            if (!errorScreens.isEmpty()) {
                ErrorScreen errorScreen = errorScreens.get(0);
                errorScreen.initialize();
                IErrorModel errorModel = gameErrorCommand.getErrorModel();
                errorScreen.show(errorModel.getMessage().getContent(), errorModel.isRetry());
            }
        }
    }

    /**
     * Handles next info screen command.
     */
    private void handleNextInfoScreenCommand() {
        processActionQueue(SHOW_NEXT_INFO_SCREEN_QUEUE_NAME);
    }

    /**
     * handles enter gambler command.
     */
    private void handleEnterGamblerCommand(){
        processActionQueue(ENTERING_GAMBLER_QUEUE_NAME);
    }

    private class LogicPresentationObserver extends NextObserver<LogicPresentation> {

        @Override
        public void onNext(final LogicPresentation logicPresentation) {
            handleLogicPresentation(logicPresentation);
        }
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(final InitResult presentation) {
            handleInitResult(presentation);
        }
    }

    private class SpinButtonClickedObserver extends NextObserver<SpinCommand> {

        @Override
        public void onNext(final SpinCommand spinCommand) {
            handleSpinCommand(spinCommand);
        }
    }

    private class StartAutoPlayCommandObserver extends NextObserver<StartAutoPlayCommand> {

        @Override
        public void onNext(final StartAutoPlayCommand startAutoPlayCommand) {
            handleStartAutoPlayCommand(startAutoPlayCommand);
        }
    }

    private class StopAutoPlayCommandObserver extends NextObserver<StopAutoPlayCommand> {

        @Override
        public void onNext(final StopAutoPlayCommand stopAutoPlayCommand) {
            handleStopAutoPlayCommand(stopAutoPlayCommand);
        }
    }

    private class SkipButtonClickedObserver extends NextObserver<SkipCommand> {

        @Override
        public void onNext(final SkipCommand spinButtonClickedEvent) {
            handleSkipCommand();
        }
    }

    private class TakeButtonClickedObserver extends NextObserver<TakeWinCommand> {

        @Override
        public void onNext(TakeWinCommand takeWinCommand) {
            handleTakeCommand();
        }
    }

    private class GamblerCardSelectedObserver extends NextObserver<GamblerCardSelectedEvent> {

        @Override
        public void onNext(GamblerCardSelectedEvent gamblerCardSelectedEvent) {
            handleGamblerCardSelectedEvent(gamblerCardSelectedEvent);
        }
    }

    private class ResetGameCommandObserver extends NextObserver<ResetGameCommand> {

        @Override
        public void onNext(ResetGameCommand resetGameCommand) {
            handleResetGame();
        }
    }

    private class EnterHistoryCommandObserver extends NextObserver<EnterHistoryCommand> {

        @Override
        public void onNext(EnterHistoryCommand enterHistoryCommand) {
            handleEnterHistoryCommand();
        }
    }

    private class ExitHistoryCommandObserver extends NextObserver<ExitHistoryCommand> {

        @Override
        public void onNext(ExitHistoryCommand exitHistoryCommand) {
            handleExitHistoryCommand();
        }
    }

    private class ShowNextHistoryPageCommandObserver extends NextObserver<ShowNextHistoryPageCommand> {

        @Override
        public void onNext(ShowNextHistoryPageCommand showNextHistoryPageCommand) {
            handleShowNextHistoryPageCommand();
        }
    }

    private class ShowPreviousHistoryPageCommandObserver extends NextObserver<ShowPreviousHistoryPageCommand> {

        @Override
        public void onNext(ShowPreviousHistoryPageCommand showPreviousHistoryPageCommand) {
            handleShowPreviousHistoryPageCommand();
        }
    }

    private class GameErrorCommandObserver extends NextObserver<GameErrorCommand> {

        @Override
        public void onNext(GameErrorCommand gameErrorCommand) {
            handleGameErrorCommand(gameErrorCommand);
        }
    }

    private class NextInfoScreenCommandObserver extends NextObserver<NextInfoScreenCommand> {

        @Override
        public void onNext(NextInfoScreenCommand nextInfoScreenCommand) {
            handleNextInfoScreenCommand();
        }
    }

    private class EnterGamblerCommandObserver extends NextObserver<EnterGamblerCommand> {

        @Override
        public void onNext(EnterGamblerCommand enterGamblerCommand) {
            handleEnterGamblerCommand();
        }
    }
}
