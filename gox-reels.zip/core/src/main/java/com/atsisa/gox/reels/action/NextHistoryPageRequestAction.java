package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.IGameEngine;

/**
 * Sends a request to show next history page.
 */
public class NextHistoryPageRequestAction extends AbstractHistoryPageRequestAction {

    /**
     * Initializes a new instance of the {@link NextHistoryPageRequestAction} class.
     */
    public NextHistoryPageRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link NextHistoryPageRequestAction} class.
     * @param gameEngine game engine reference
     */
    public NextHistoryPageRequestAction(IGameEngine gameEngine) {
        super(gameEngine);
    }

    @Override
    protected int getHistoryPageNumberToShow() {
        return getHistoryModel().getActivePageNumber() + 1;
    }
}
