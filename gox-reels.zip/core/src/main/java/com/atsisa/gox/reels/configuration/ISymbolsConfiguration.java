package com.atsisa.gox.reels.configuration;

import com.atsisa.gox.reels.view.ReelView;
import com.atsisa.gox.reels.view.spi.ISymbolAppendingStrategy;
import com.atsisa.gox.reels.view.spi.ISymbolPool;

/**
 * Defines data required for a successful setup
 * of {@link ReelView} class objects.
 */
public interface ISymbolsConfiguration {

    /**
     * Gets the number of symbol rows visible to players.
     * @return The number of rows visible to players.
     */
    int getRowCount();

    /**
     * Gets the height of a single symbol in pixels.
     * @return A height of a single symbol in pixels.
     */
    int getSymbolHeight();

    /**
     * Gets the symbol pool used to manage symbol instances
     * in the reel this configuration is injected into.
     * @return The symbol pool.
     */
    ISymbolPool getSymbolPool();

    /**
     * Gets a strategy which changes the reel stopping behaviour by determining
     * how stopped symbols should be joined with the existing reel strip
     * in order not to display combinations confusing to players.
     * @return The symbol appending strategy.
     */
    ISymbolAppendingStrategy getSymbolAppending();
}
