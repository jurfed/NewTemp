package com.atsisa.gox.reels.animation;

import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import com.atsisa.gox.framework.animation.AbstractAnimation;
import com.atsisa.gox.framework.animation.AnimationState;

import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import rx.subjects.PublishSubject;

/**
 * Animation of transfer of won credits to player's account.
 */
public class WinToBalanceAnimation extends AbstractAnimation {

    /**
     * BigDecimal constant for value 100.
     */
    private final BigDecimal HUNDRED = new BigDecimal(100);

    /**
     * The animation state subject for credits.
     */
    private final PublishSubject<BigDecimal> creditsSubject;

    /**
     * Starting amount of credits before animation start.
     */
    private final BigDecimal startingCredits;

    /**
     * Total amount of credits after animation end.
     */
    private final BigDecimal totalCredits;

    /**
     * A single step animation duration in milliseconds.
     */
    private final int singleStepDuration;

    /**
     * Amount of won credits.
     */
    private BigDecimal totalWin;

    /**
     * Current win value.
     */
    private BigDecimal currentWinValue;

    /**
     * Current step of credits animation.
     */
    private int currentStep;

    /**
     * Flag indicating changing step of credits animation.
     */
    private boolean changeStep;

    /**
     * The observable subscription.
     */
    private Subscription subscription;

    /**
     * Initializes a new instance of the WinToBalanceAnimation class.
     * @param startingCredits    - BigDecimal
     * @param totalCredits       - BigDecimal
     * @param singleStepDuration A single step animation duration in milliseconds.
     */
    public WinToBalanceAnimation(BigDecimal startingCredits, BigDecimal totalCredits, int singleStepDuration) {
        this.startingCredits = startingCredits;
        this.totalCredits = totalCredits;
        this.singleStepDuration = singleStepDuration;
        creditsSubject = PublishSubject.create();
    }

    /**
     * Initializes values of local variables.
     */
    private void init() {
        totalWin = totalCredits.subtract(startingCredits);
        currentWinValue = totalWin.multiply(HUNDRED);
        currentStep = 1;
        changeStep = true;
    }

    @Override
    public void play() {
        if (isPlaying()) {
            return;
        }
        init();
        subscription = Observable.interval(singleStepDuration, TimeUnit.MILLISECONDS).subscribe(new Action1<Long>() {

            @Override
            public void call(Long aLong) {
                tick();
            }
        });
        setAnimationState(AnimationState.PLAYING);
        creditsSubject.onNext(startingCredits);
    }

    /**
     * Publishes counted credits value.
     */
    private void tick() {
        BigDecimal winValue = getValue(currentWinValue);
        BigDecimal creditsValue = startingCredits.add(totalWin).subtract(winValue.divide(HUNDRED));

        currentWinValue = winValue;

        if (winValue.compareTo(BigDecimal.ZERO) <= 0) {
            finishAnimation();
            return;
        }

        creditsSubject.onNext(creditsValue);
    }

    /**
     * Publishes total credits value and stopps the animation.
     */
    private synchronized void finishAnimation() {
        if (isStopped()) {
            return;
        }

        creditsSubject.onNext(totalCredits);
        creditsSubject.onCompleted();
        subscription.unsubscribe();
        setAnimationState(AnimationState.STOPPED);
    }

    /**
     * Counts win value.
     * @param win - BigDecimal
     * @return win value
     */
    private BigDecimal getValue(BigDecimal win) {
        if (win.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal take = win.remainder(new BigDecimal(Math.pow(10, currentStep)));

            if (!changeStep && take.compareTo(BigDecimal.ZERO) == 0) {
                currentStep++;
                changeStep = true;
            }

            if (changeStep && take.compareTo(BigDecimal.ZERO) == 0 || take.compareTo(BigDecimal.ZERO) > 0) {
                win = win.subtract(new BigDecimal(Math.pow(10, currentStep - 1)));
                changeStep = false;
            }

            return win;
        }

        return BigDecimal.ZERO;
    }

    /**
     * Does nothing, cannot pause balance animation.
     */
    @Override
    public void pause() {
        throw new UnsupportedOperationException("Pausing the WinToBalance animation is currently not supported.");
    }

    @Override
    public void stop() {
        finishAnimation();
    }

    /**
     * Returns animations observable.
     * @return animation observable
     */
    public Observable<BigDecimal> getCreditsObservable() {
        return creditsSubject;
    }
}

