package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;

/**
 * A request for next info screen.
 */
public class NextInfoScreenCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public NextInfoScreenCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
