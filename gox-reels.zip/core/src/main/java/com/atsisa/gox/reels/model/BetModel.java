package com.atsisa.gox.reels.model;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.reels.IBetModel;

/**
 * Represents the configuration of reel game bet.
 */
public class BetModel implements IBetModel {

    /**
     * An index of selected bet step in the available steps list.
     */
    private int selectedBetIndex;

    /**
     * A collection of available bet steps.
     */
    private List<BigDecimal> betSteps = new LinkedList<>();

    /**
     * Current bet value.
     */
    private BigDecimal currentBet = BigDecimal.ZERO;

    /**
     * Current total bet.
     */
    private BigDecimal totalBet = BigDecimal.ZERO;

    @Override
    public BigDecimal getBetPerLine() {
        return currentBet;
    }

    @Override
    public BigDecimal getMinBet() {
        return Iterables.getFirst(betSteps, BigDecimal.ZERO);
    }

    @Override
    public BigDecimal getMaxBet() {
        return Iterables.getLast(betSteps, BigDecimal.ZERO);
    }

    @Override
    public BigDecimal getTotalBet() {
        return totalBet;
    }

    /**
     * Sets total bet value.
     * @param totalBet - int
     */
    void setTotalBet(BigDecimal totalBet) {
        this.totalBet = totalBet;
    }

    @Override
    public List<BigDecimal> getBetSteps() {
        return betSteps;
    }

    /**
     * Sets available bet steps.
     * @param betSteps - available bet steps
     */
    void setBetSteps(List<BigDecimal> betSteps) {
        if (betSteps == null) {
            throw new IllegalArgumentException("The list of bet steps is null");
        }
        this.betSteps = betSteps;
        updateSelectedBetIndex();
    }

    /**
     * Sets current bet value.
     * @param bet current bet
     * @return a boolean value that indicates whether current bet value has been changed or not
     */
    boolean setCurrentBet(BigDecimal bet) {
        if (bet.compareTo(currentBet) != 0) {
            currentBet = bet;
            updateSelectedBetIndex();
            return true;
        }
        return false;
    }

    /**
     * Increases current bet value.
     * @return boolean
     */
    boolean increaseCurrentBet() {
        if (selectedBetIndex + 1 >= betSteps.size()) {
            return false;
        }
        setCurrentBet(betSteps.get(selectedBetIndex + 1));
        return true;
    }

    /**
     * Increases bet to maximum value.
     * @return boolean
     */
    boolean increaseBetToMax() {
        boolean success = false;
        while (increaseCurrentBet()) {
            success = true;
        }
        return success;
    }

    /**
     * Decreases bet to minimum value.
     * @return boolean
     */
    boolean decreaseBetToMin() {
        boolean success = false;
        while (decreaseCurrentBet()) {
            success = true;
        }
        return success;
    }

    /**
     * Decreases current bet value.
     * @return boolean
     */
    boolean decreaseCurrentBet() {
        if (selectedBetIndex - 1 < 0) {
            return false;
        }
        setCurrentBet(betSteps.get(selectedBetIndex - 1));
        return true;
    }

    /**
     * Updates selected bet index.
     */
    private void updateSelectedBetIndex() {

        int index = 0;
        for (BigDecimal line : betSteps) {
            if (line.equals(currentBet)) {
                break;
            }
            index++;
        }
        selectedBetIndex = index;
    }

}
