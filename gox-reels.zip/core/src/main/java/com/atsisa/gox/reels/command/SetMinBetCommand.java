package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for decreasing bet to minimum value.
 */
@Reflectable
public class SetMinBetCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link SetMinBetCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public SetMinBetCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
