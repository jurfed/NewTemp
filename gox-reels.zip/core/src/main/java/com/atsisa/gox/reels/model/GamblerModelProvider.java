package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.reels.command.ResetGamblerCommand;
import com.atsisa.gox.reels.event.GamblerModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.presentation.GamblerPresentation;
import com.google.inject.Inject;

/**
 * Handles all aspect of reel game gambler configuration.
 */
public class GamblerModelProvider implements IGamblerModelProvider {

    /**
     * Reference to the {@link IEventBus}.
     */
    private final IEventBus eventBus;

    /**
     * The gambler model.
     */
    private GamblerModel gamblerModel;

    /**
     * Initializes a new instance of the {@link GamblerModelProvider} class.
     * @param eventBus {@link IEventBus}
     */
    @Inject
    public GamblerModelProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        gamblerModel = new GamblerModel();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new GamblerPresentationObserver(), GamblerPresentation.class);
        eventBus.register(new ResetGamblerCommandObserver(), ResetGamblerCommand.class);
    }

    /**
     * Updates the gambler model according to given presentation response.
     * @param gamblerPresentation The gambler presentation.
     */
    @Subscribe
    public void handleGamblerPresentation(GamblerPresentation gamblerPresentation) {
        if (gamblerModel.setWonAmount(gamblerPresentation.getWonAmount()) | gamblerModel.setBidAmount(gamblerPresentation.getBidAmount()) | gamblerModel
                .setGamblerHistory(gamblerPresentation.getGamblerDescriptor().getGamblerHistory()) | gamblerModel
                .setGamblerHistorySize(gamblerPresentation.getGamblerDescriptor().getGamblerHistorySize())) {
            notifyModelChanged(gamblerPresentation);
        }
    }

    /**
     * Handles the init result.
     * @param initResult {@link InitResult}
     */
    @Subscribe
    public void handleInitResult(InitResult initResult) {
        if (gamblerModel.setGamblerPlayLimit(initResult.getGameConfiguration().getGamblerPlayLimit()) | gamblerModel
                .setGamblerWinLimit(initResult.getGameConfiguration().getGamblerWinLimit())) {
            notifyModelChanged(initResult);
        }
    }

    /**
     * Resets the gambler model state.
     * @param resetGamblerCommand {@link ResetGamblerCommand}
     */
    @Subscribe
    public void handleResetGamblerCommand(ResetGamblerCommand resetGamblerCommand) {
        if (gamblerModel.setWonAmount(BigDecimal.ZERO) | gamblerModel.setBidAmount(BigDecimal.ZERO)) {
            notifyModelChanged(resetGamblerCommand);
        }
    }

    /**
     * Publishes an event regarding gambler model changes.
     * @param sourceEvent The source message which changed
     */
    private void notifyModelChanged(Object sourceEvent) {
        GamblerModelChangedEvent event = new GamblerModelChangedEvent(gamblerModel);
        event.setSourceEvent(sourceEvent);
        eventBus.post(event);
    }

    @Override
    public IGamblerModel getGamblerModel() {
        return gamblerModel;
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult item) {
            handleInitResult(item);
        }
    }

    private class GamblerPresentationObserver extends NextObserver<GamblerPresentation> {

        @Override
        public void onNext(GamblerPresentation gamblerPresentation) {
            handleGamblerPresentation(gamblerPresentation);
        }
    }

    private class ResetGamblerCommandObserver extends NextObserver<ResetGamblerCommand> {

        @Override
        public void onNext(ResetGamblerCommand resetGamblerCommand) {
            handleResetGamblerCommand(resetGamblerCommand);
        }
    }

}
