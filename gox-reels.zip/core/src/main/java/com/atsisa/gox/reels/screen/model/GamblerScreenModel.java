package com.atsisa.gox.reels.screen.model;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * Gambler screen model. Contains information about gambler amount and gamble to win.
 */
@Reflectable
public class GamblerScreenModel extends ScreenModel {

    /**
     * Information about gambler amount.
     */
    private NamedProperty<String> gambleAmount = new NamedProperty<>(String.class, "gambleAmount");

    /**
     * Information about gamble to win.
     */
    private NamedProperty<String> gambleToWin = new NamedProperty<>(String.class, "gambleToWin");

    /**
     * Configuration reference.
     */
    private IConfigurationProvider configurationProvider;

    /**
     * Initializes a new instance of the {@link GamblerScreenModel} class.
     * @param translator {@link ITranslator}
     * @param configurationProvider {@link IConfigurationProvider}
     */
    @Inject
    public GamblerScreenModel(ITranslator translator, IConfigurationProvider configurationProvider) {
        super(translator);
        this.configurationProvider = configurationProvider;
    }

    /**
     * Initializes a new instance of the {@link GamblerScreenModel} class.
     */
    public GamblerScreenModel() {
        this.configurationProvider = GameEngine.current().getConfigurationProvider();
    }

    /**
     * Gets gambler amount.
     * @return gambler amount
     */
    public String getGambleAmount() {
        return gambleAmount.get();
    }

    /**
     * Sets gambler amount.
     * @param gambleAmount - gambler amount
     */
    public void setGambleAmount(String gambleAmount) {
        this.gambleAmount.set(gambleAmount);
    }

    /**
     * Returns gambleAmount object.
     * @return gambler amount
     */
    public IObservableProperty<String> gambleAmount() {
        return gambleAmount;
    }

    /**
     * Gets gamble to win amount.
     * @return gamble to win amount
     */
    public String getGambleToWin() {
        return gambleToWin.get();
    }

    /**
     * Sets gamble to symbols amount.
     * @param gambleToWin - gamble to symbols
     */
    public void setGambleToWin(String gambleToWin) {
        this.gambleToWin.set(gambleToWin);
    }

    /**
     * Returns gambleToWin object.
     * @return gamble to win
     */
    public IObservableProperty<String> gambleToWin() {
        return gambleToWin;
    }

    /**
     * Gets a value that determines delay between flip history cards.
     * @return delay between history cards
     */
    public int getHistoryCardsFlipDelay() {
        Object property = configurationProvider.getConfiguration().getProperty(ReelConfigurationConstants.GAMBLER_HISTORY_CARDS_DELAY);
        if (property != null) {
            return (int) property;
        }
        return 0;
    }
}
