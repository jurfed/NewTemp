package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.StateAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IReelsPresentationStates;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;

/**
 * Update presentation action implementation.
 */
public class UpdatePresentationAction extends StateAction {

    /**
     * Reference to the {@link AbstractReelGame}.
     */
    private AbstractReelGame abstractReelGame;

    /**
     * Initializes a new instance of the {@link UpdatePresentationAction} class.
     */
    public UpdatePresentationAction() {
        super();
        this.abstractReelGame = (AbstractReelGame) GameEngine.current().getGame();
    }

    /**
     * Initializes a new instance of the {@link UpdatePresentationAction} class.
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     * @param abstractReelGame {@link AbstractReelGame}
     */
    public UpdatePresentationAction(ILogger logger, IEventBus eventBus, AbstractReelGame abstractReelGame) {
        super(logger, eventBus);
        this.abstractReelGame = abstractReelGame;
    }

    @Override
    protected void validate() throws IllegalArgumentException {
        if (actionData == null || actionData.getState() == null) {
            throw new IllegalArgumentException("The presentation state was not set");
        }
        if (!validateState(actionData.getState())) {
            throw new IllegalArgumentException(StringUtility.format("The presentation state: %s is not available", actionData.getState()));
        }
    }

    @Override
    protected void execute() {
        eventBus.post(new PresentationStateChangedEvent(actionData.getState()));
    }

    /**
     * Validates if specific state is available in the game.
     * @param state state to check
     * @return a boolean value that indicates whether this state is available or not
     */
    private boolean validateState(String state) {
        Iterable<IReelsPresentationStates> presentationStates = abstractReelGame.getReelsPresentationStates();
        for (IReelsPresentationStates reelsPresentationStates : presentationStates) {
            String[] availableStates = reelsPresentationStates.getAvailableStates();
            for (String availableState : availableStates) {
                if (availableState.equals(state)) {
                    return true;
                }
            }
        }
        return false;
    }

}
