package com.atsisa.gox.reels.fsm;

import java.util.List;

import com.atsisa.gox.reels.logic.model.Reel;

/**
 * Exposes the most recent reel game state.
 */
public interface IReelGameStateHolder {

    /**
     * Gets last stopped symbols.
     * @return list of symbols to display
     */
    List<Iterable<String>> getStoppedSymbols();

    /**
     * Gets current reel states.
     * @return list of reel states.
     */
    List<Reel> getReels();

    /**
     * Gets flag indicating whether auto play is checked or not.
     * @return boolean true if auto play is checked, false otherwise
     */
    boolean isAutoPlay();

    /**
     * Gets flag indicating whether game is in history mode or not.
     * @return boolean true if game is in history mode, false otherwise
     */
    boolean isHistoryMode();
}
