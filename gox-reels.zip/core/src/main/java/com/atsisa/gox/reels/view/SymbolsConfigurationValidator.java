package com.atsisa.gox.reels.view;

import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;

/**
 * Responsible for the validation of
 * {@link ISymbolsConfiguration} objects.
 */
class SymbolsConfigurationValidator {

    /**
     * Validates the symbol configuration.
     * @param symbolsConfiguration The symbol configuration.
     */
    public void validateConfiguration(ISymbolsConfiguration symbolsConfiguration) {
        if (symbolsConfiguration == null) {
            throw new IllegalArgumentException("The symbols configuration is not set.");
        }
        if (symbolsConfiguration.getSymbolPool() == null) {
            throw new IllegalArgumentException("The symbol pool has not been set.");
        }
        if (symbolsConfiguration.getSymbolAppending() == null) {
            throw new IllegalArgumentException("The symbol appending strategy defined in symbols configuration has not been set.");
        }
        if (symbolsConfiguration.getRowCount() <= 0) {
            throw new IllegalArgumentException("The number of symbol rows in symbols configuration is not a positive number.");
        }
        if (symbolsConfiguration.getSymbolHeight() <= 0) {
            throw new IllegalArgumentException("The symbol height in symbols configuration is not a positive number.");
        }
    }
}
