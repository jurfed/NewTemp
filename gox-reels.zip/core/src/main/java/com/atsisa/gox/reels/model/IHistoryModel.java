package com.atsisa.gox.reels.model;

import java.util.Date;

/**
 * Represents player's game history.
 */
public interface IHistoryModel {

    /**
     * Returns the total number of pages in history.
     * @return total number of pages in history.
     */
    int getTotalNumberPages();

    /**
     * Returns the date currently active history page.
     * @return history page date.
     */
    Date getActivePageDate();

    /**
     * Returns the number currently active page in history.
     * @return currently active history page number.
     */
    int getActivePageNumber();

}