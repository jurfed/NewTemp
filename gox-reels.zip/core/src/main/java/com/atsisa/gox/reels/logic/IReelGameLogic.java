package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;

import rx.Observable;

/**
 * Represents a logic of reel game.
 */
public interface IReelGameLogic {

    /**
     * Handles a init request.
     * @param initRequest a init request
     * @return the observable result
     */
    Observable<Object> init(InitRequest initRequest);

    /**
     * Handles a bet request.
     * @param betRequest a bet request
     * @return the observable result
     */
    Observable<LogicPresentation> bet(BetRequest betRequest);

    /**
     * Handles a take win request.
     * @return the observable result
     */
    Observable<LogicPresentation> takeWin();

    /**
     * Handles a gamble request.
     * @param gambleRequest a gamble request
     * @return the observable result
     */
    Observable<LogicPresentation> gamble(GambleRequest gambleRequest);

    /**
     * Handles a gamble request.
     * @param enterGamblerRequest a enter gambler request
     * @return the observable result
     */
    Observable<LogicPresentation> enterGambler(EnterGamblerRequest enterGamblerRequest);

}
