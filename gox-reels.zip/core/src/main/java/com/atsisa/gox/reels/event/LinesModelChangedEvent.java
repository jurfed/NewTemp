package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.framework.utility.BitUtility;
import com.atsisa.gox.reels.ILinesModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when either available line numbers or the number of lines user plays on has changed.
 */
@Reflectable
public final class LinesModelChangedEvent extends AbstractEvent {

    /**
     * A change containing selected lines modification.
     */
    public static final int SELECTED_LINES = 1 << 1;

    /**
     * A change containing available lines modification.
     */
    public static final int AVAILABLE_LINES = 1 << 2;

    /**
     * A change containing available lines modification.
     */
    public static final int WINNING_LINES = 1 << 3;

    /**
     * A change containing current winning line.
     */
    public static final int CURRENT_WINNING_LINE = 1 << 4;

    /**
     * The lines model.
     */
    private final ILinesModel linesModel;

    /**
     * The change type.
     */
    private final int changeType;

    /**
     * Initializes a new instance of the {@link LinesModelChangedEvent} class.
     * @param linesModel The most recent lines model.
     * @param changeType The change type.
     */
    public LinesModelChangedEvent(ILinesModel linesModel, int changeType) {
        this.linesModel = linesModel;
        this.changeType = changeType;
    }

    /**
     * Gets an object representing all crucial information regarding the most recent reel game winning lines
     * configuration.
     * @return The lines model.
     */
    public ILinesModel getLinesModel() {
        return linesModel;
    }

    /**
     * Gets the type of change.
     * @return The type of change.
     */
    public int getChangeType() {
        return changeType;
    }

    /**
     * Gets a value indicating whether the winning lines value has changed.
     * @return True if winning lines value has changed, false otherwise.
     */
    public boolean hasWinningLinesChanged() {
        return BitUtility.isSet(changeType, WINNING_LINES);
    }

    /**
     * Gets a value indicating whether the selected lines value has changed.
     * @return True if selected lines value has changed, false otherwise.
     */
    public boolean hasSelectedLinesChanged() {
        return BitUtility.isSet(changeType, SELECTED_LINES);
    }

    /**
     * Gets a value indicating whether the available lines value has changed.
     * @return True if available lines value has changed, false otherwise.
     */
    public boolean hasAvailableLinesChanged() {
        return BitUtility.isSet(changeType, AVAILABLE_LINES);
    }

    /**
     * Gets a value indicating whether the current winning line has changed.
     * @return True if current winning line has changed, false otherwise.
     */
    public boolean hasCurrentWinningLineChanged() {
        return BitUtility.isSet(changeType, CURRENT_WINNING_LINE);
    }
}
