package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for cleans info about current winning lines.
 */
@Reflectable
public class CleanWinningLinesCommand {

}
