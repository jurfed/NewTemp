package com.atsisa.gox.reels.view;

import java.util.List;

import com.atsisa.gox.reels.animation.IReelAnimation;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.view.state.ReelState;

import rx.Observable;

/**
 * Represents a single reel.
 */
public interface IReel {

    /**
     * Gets an observable reel state. This property enables users to keep track of {@link ReelState} changes.
     * @return An observable reel state.
     */
    Observable<ReelState> getReelStateObservable();

    /**
     * Gets reel index position in reel group.
     * @return reel index position in reel group
     */
    int getIndex();

    /**
     * Gets the current state of this reel.
     * @return the reel state
     */
    ReelState getReelState();

    /**
     * Sets currently active reel strip type.
     * <p>
     * This method allows to switch between different reel strips
     * defined in the configuration (accessible via the {@link #getSymbolsConfiguration()} method).
     * method.
     * </p>
     * @param reelStripType The reel strip type.
     * @throws IllegalArgumentException Given reel strip type is null or has not been defined in the {@link ISymbolsConfiguration}.
     * @throws IllegalStateException    The state of this reel disallows to change its currently active reel strip type.
     */
    void setReelStripType(String reelStripType);

    /**
     * Gets currently active reel strip type.
     * @return Currently active reel strip type
     */
    String getReelStripType();

    /**
     * Gets the configuration of symbols this reel relies upon.
     * @return The configuration of symbols
     */
    ISymbolsConfiguration getSymbolsConfiguration();

    /**
     * Gets the reel animation.
     * @return The reel animation
     */
    IReelAnimation getReelAnimation();

    /**
     * Sets the reel animation.
     * @param reelAnimation The reel animation
     * @throws IllegalArgumentException Given reel animation is null
     */
    void setReelAnimation(IReelAnimation reelAnimation);

    /**
     * Gets currently displayed symbol at requested position.
     * @param rowPosition A zero-based index of of a stopped symbol counting from top
     * @return currently displayed symbol at requested position
     * @throws IllegalStateException    Currently displayed symbols cannot be determined (the reel is spinning).
     * @throws IllegalArgumentException The row position is not within the range of the row count.
     */
    AbstractSymbol getDisplayedSymbol(int rowPosition);

    /**
     * Puts the symbol on a specific row position.
     * @param rowPosition row position
     * @param symbolName name of the symbol to put
     * @throws IllegalStateException When reel is not in idle state
     * @throws IllegalArgumentException The row position is not within the range of the row count or name of the symbol is incorrect
     */
    void setDisplayedSymbol(int rowPosition, String symbolName);

    /**
     * Gets currently displayed symbols.
     * @return Currently displayed symbols
     * @throws IllegalStateException Currently displayed symbols cannot be determined (the reel is spinning)
     */
    List<AbstractSymbol> getDisplayedSymbols();

    /**
     * Starts the spin of this reel using previously set up animation.
     * <p>
     * This method does nothing in case the reel is already spinning.
     * </p>
     */
    void spin();

    /**
     * Gently stops this reel on selected symbols.
     * <p>
     * This method uses {@link IReelAnimation}'s stopping phase
     * to reach selected symbols when it is spinning.
     * </p>
     * <p>
     * It directly jumps to selected symbols in case the reel is {@link ReelState#IDLE}.
     * </p>
     * @param symbolNames A collection of symbol names this reel is about to be stopped upon.
     * @throws IllegalArgumentException The number of symbol names does not comply with the row count.
     */
    void stopOnSymbols(Iterable<String> symbolNames);

    /**
     * Forcibly stops this reel on selected symbols.
     * <p>
     * This method uses {@link IReelAnimation}'s force-stopping phase
     * to reach selected symbols when it is spinning.
     * </p>
     * <p>
     * It directly jumps to selected symbols in case the reel is idle.
     * </p>
     * @param symbolNames A collection of symbol names this reel is about to be stopped upon.
     * @throws IllegalArgumentException The number of symbol names does not comply with the row count.
     */
    void forceStopOnSymbols(Iterable<String> symbolNames);
}
