package com.atsisa.gox.reels.view;

import java.util.HashMap;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewBuilder;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.converter.ConversionException;
import com.atsisa.gox.framework.serialization.converter.IValueConverter;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.configuration.SymbolsConfiguration;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolModificationStrategy;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Responsible for converting symbols configuration element to an instance implementing the
 * {@link ISymbolsConfiguration} interface.
 */
@Reflect_Mini
public class SymbolsConfigurationConverter implements IValueConverter {

    /**
     * Symbols definition attribute name specifying pool initialization strategy class.
     */
    private static final String POOL_INITIALIZATION_STRATEGY_CLASS_ATTRIBUTE_NAME = "poolInitializationStrategyClass";

    /**
     * Attribute name specifying the class for symbol modification strategy class.
     */
    private static final String SYMBOL_MODIFICATION_STRATEGY_CLASS_ATTRIBUTE_NAME = "symbolModificationStrategyClass";

    /**
     * The serializer.
     */
    private final IXmlSerializer serializer;

    /**
     * The view builder.
     */
    private final IViewBuilder viewBuilder;

    /**
     * Initializes a new instance of the {@link SymbolsConfigurationConverter} class.
     */
    public SymbolsConfigurationConverter() {
        serializer = GameEngine.current().getUtility().getSerialization().getSerializer(SerializationFormat.XML);
        viewBuilder = GameEngine.current().getViewManager().getViewBuilder();
    }

    /**
     * Initializes a new instance of the {@link SymbolsConfigurationConverter} class.
     * @param serializer  The serializer.
     * @param viewBuilder The view builder.
     */
    public SymbolsConfigurationConverter(IXmlSerializer serializer, IViewBuilder viewBuilder) {
        this.serializer = serializer;
        this.viewBuilder = viewBuilder;
    }

    @Override
    public Class<?> getValueType() {
        return ISymbolsConfiguration.class;
    }

    @Override
    public String convertTo(Object objToConvert) throws ConversionException {
        throw new ConversionException("Converting symbols configuration back to string is not supported");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) throws ConversionException {
        if (serializedMessage == null || parsedObject == null) {
            return null;
        }

        XmlObject xmlObject = (XmlObject) parsedObject;
        SymbolsConfiguration symbolsConfiguration = new SymbolsConfiguration();
        for (XmlObject child : xmlObject.getChildren()) {
            String childName = child.getName();
            switch (childName) {
                case "symbols":
                    adjustSymbolPool(symbolsConfiguration, child);
                    break;
                case "rowCount":
                    adjustRowCount(symbolsConfiguration, child);
                    break;
                case "symbolHeight":
                    adjustSymbolHeight(symbolsConfiguration, child);
                    break;
                default:
                    throw new ConversionException("Unrecognizable childName in convertFrom method: " + childName);
            }
        }

        return symbolsConfiguration;
    }

    /**
     * Adjust the symbol height in given symbols configuration.
     * @param symbolsConfiguration The symbols configuration.
     * @param symbolHeightElement  The symbol height element.
     * @throws ConversionException The symbol height cannot be converted.
     */
    private void adjustSymbolHeight(SymbolsConfiguration symbolsConfiguration, XmlObject symbolHeightElement) throws ConversionException {
        try {
            int symbolHeight = Integer.parseInt(symbolHeightElement.getValue());
            symbolsConfiguration.setSymbolHeight(symbolHeight);
        } catch (NumberFormatException e) {
            throw new ConversionException("Unable to convert symbol height.", e);
        }
    }

    /**
     * Adjust the row count in given symbols configuration.
     * @param symbolsConfiguration The symbols configuration.
     * @param rowCountElement      The row count element.
     * @throws ConversionException The row count cannot be converted.
     */
    private void adjustRowCount(final SymbolsConfiguration symbolsConfiguration, final XmlObject rowCountElement) throws ConversionException {
        try {
            int rowCount = Integer.parseInt(rowCountElement.getValue());
            symbolsConfiguration.setRowCount(rowCount);
        } catch (NumberFormatException e) {
            throw new ConversionException("Unable to convert row count.", e);
        }
    }

    /**
     * Adjust the symbol pool in given symbols configuration.
     * @param symbolsConfiguration The symbols configuration.
     * @param symbolsElement       The symbols element.
     * @throws ConversionException The symbol pool cannot be converted.
     */
    private void adjustSymbolPool(final SymbolsConfiguration symbolsConfiguration, final XmlObject symbolsElement) throws ConversionException {
        try {
            ISymbolFactory symbolFactory = null;
            XmlObject poolDefinition = null;
            ISymbolModificationStrategy symbolModificationStrategy = null;
            for (XmlObject child : symbolsElement.getChildren()) {
                String childName = child.getName();
                switch (childName) {
                    case "symbolsDefinition":
                        symbolFactory = createSymbolFactory(child.getChildren());
                        break;
                    case "poolDefinition":
                        poolDefinition = child;
                        break;
                    case "symbolModification":
                        symbolModificationStrategy = (ISymbolModificationStrategy) serializer
                                .deserialize(child, child.getAttribute(SYMBOL_MODIFICATION_STRATEGY_CLASS_ATTRIBUTE_NAME));
                        break;
                    default:
                        throw new ConversionException("Unrecognizable childName in adjustSymbolPool method: " + childName);
                }
            }
            ISymbolPoolStrategy poolStrategy = createSymbolPoolStrategy(poolDefinition, symbolFactory);
            ISymbolPool symbolPool = SymbolPool.newSymbolPool(symbolFactory, poolStrategy);
            symbolPool.setSymbolModificationStrategy(symbolModificationStrategy);
            symbolsConfiguration.setSymbolPool(symbolPool);
        } catch (IllegalArgumentException e) {
            throw new ConversionException("Unable to convert a symbol pool.", e);
        } catch (SerializationException e) {
            throw new ConversionException("Unable to deserialize a symbol pool.", e);
        }
    }

    /**
     * Creates a new instance of the symbol factory using given symbol definitions.
     * @param symbolDefinitions The symbol definitions.
     * @return A symbol factory.
     */
    private ISymbolFactory createSymbolFactory(final Iterable<XmlObject> symbolDefinitions) {
        SymbolFactory symbolFactory = new SymbolFactory(viewBuilder);
        for (XmlObject symbolDefinition : symbolDefinitions) {
            symbolFactory.addSymbolDefinition(symbolDefinition);
        }
        return symbolFactory;
    }

    /**
     * Creates a new instance of the symbol pool strategy using a given symbol pool definition.
     * Instance of the pool is dynamically instantiated on the base of <b>poolInitializationStrategyClass</b> attribute.
     * It configures the pool with configuration data passed in the definition.
     * @param poolElement   The pool definition element.
     * @param symbolFactory The symbol factory
     * @return ISymbolPoolStrategy
     * @throws SerializationException The poolDefinition cannot be de-serialized.
     */
    private ISymbolPoolStrategy createSymbolPoolStrategy(final XmlObject poolElement, ISymbolFactory symbolFactory) throws SerializationException {
        if (poolElement == null) {
            throw new SerializationException("Symbol pool configuration element should not be null");
        }
        ISymbolPoolStrategy poolStrategy = (ISymbolPoolStrategy) serializer
                .deserialize(poolElement, poolElement.getAttribute(POOL_INITIALIZATION_STRATEGY_CLASS_ATTRIBUTE_NAME));
        HashMap<String, Object> configurationData = new HashMap<>();
        configurationData.put(ISymbolPoolStrategy.SYMBOL_NAMES_PROPERTY_NAME, symbolFactory.getSymbolNames());
        for (XmlObject child : poolElement.getChildren()) {
            configurationData.put(child.getName(), child.getValue());
        }
        poolStrategy.initializeConfiguration(configurationData);
        return poolStrategy;
    }

}
