package com.atsisa.gox.reels.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.DeferredExternalBinding;
import com.atsisa.gox.framework.model.DeferredTemplateBinding;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.framework.view.HorizontalAlign;
import com.atsisa.gox.framework.view.RectangleShapeView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.VerticalAlign;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.command.ResetGameCommand;
import com.atsisa.gox.reels.event.ErrorModelChangedEvent;
import com.atsisa.gox.reels.model.IErrorModel;
import com.atsisa.gox.reels.screen.model.ErrorScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Error screen class.
 */
@Reflectable
public class ErrorScreen extends Screen<ErrorScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "ErrorScreenLayoutId";

    /**
     * Default value of the layout id, under which should be layout for this screen.
     * It will be used if in game IoC configuration, this value will be not overwritten.
     */
    public static final String DEFAULT_LAYOUT_ID_VALUE = "errorScreen";

    /**
     * Default retry button text.
     */
    private static final String RETRY_BUTTON_TEXT = "RETRY";

    /**
     * Divider value.
     */
    private static final int DIVIDER = 2;

    /**
     * Default error screen color.
     */
    private static final int DEFAULT_BACKGROUND_COLOR = 0xD40F0F;

    /**
     * Default error message text field color.
     */
    private static final int DEFAULT_ERROR_MESSAGE_COLOR = 0xFFFFFF;

    /**
     * Default retry button color.
     */
    private static final int DEFAULT_RETRY_BUTTON_COLOR = 0xFFFFFF;

    /**
     * Default retry button text color.
     */
    private static final int DEFAULT_RETRY_TEXT_COLOR = 0xD40F0F;

    /**
     * Default error screen width size.
     */
    private static final float DEFAULT_ERROR_SCREEN_WIDTH = 800;

    /**
     * Default error screen height size.
     */
    private static final float DEFAULT_ERROR_SCREEN_HEIGHT = 600;

    /**
     * Default retry button width size.
     */
    private static final float DEFAULT_RETRY_BUTTON_WIDTH = 270;

    /**
     * Default retry button height size.
     */
    private static final float DEFAULT_RETRY_BUTTON_HEIGHT = 85;

    /**
     * Text font size.
     */
    private static final float DEFAULT_TEXT_FONT_SIZE = 35F;

    /**
     * Determines maximum allowed size of the error on the screen.
     */
    private static final float MAXIMUM_ALLOWED_PERCENTAGE_SIZE = 0.9F;

    /**
     * Retry button visible property.
     */
    private static final String RETRY_BUTTON_VISIBLE = "retryButtonVisible";

    /**
     * Retry button enabled property.
     */
    private static final String RETRY_BUTTON_ENABLED = "retryButtonEnabled";

    /**
     * Reference to the game configuration.
     */
    private IGameConfiguration gameConfiguration;

    /**
     * Initializes a new instance of the {@link ErrorScreen} class.
     * @param layoutId          layout identifier
     * @param model             {@link ErrorScreenModel}
     * @param renderer          {@link IRenderer}
     * @param viewManager       {@link IViewManager}
     * @param animationFactory  {@link IAnimationFactory}
     * @param logger            {@link ILogger}
     * @param eventBus          {@link IEventBus}
     * @param gameConfiguration {@link IGameConfiguration}
     */
    @Inject
    public ErrorScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ErrorScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IGameConfiguration gameConfiguration) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.gameConfiguration = gameConfiguration;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        try {
            getEventBus().register(this);
        } catch (ReflectionException e) {
            getEventBus().post(new GeneralSystemException(e));
            getLogger().error(e.getMessage(), e);
        }
    }

    /**
     * Updates layout depth.
     */
    private void updateDepth() {
        getLayout().getRootView().setDepth(Integer.MAX_VALUE);
    }

    @Override
    protected void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback, Object triggeredEvent) {
        updateDepth();
        super.show(viewAnimationData, finishCallback, triggeredEvent);
    }

    @Override
    public void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback) {
        updateDepth();
        super.show(viewAnimationData, finishCallback);
    }

    /**
     * Called when retry should be invoked.
     */
    @ExposeMethod
    public void retryButtonClicked() {
        setModelProperty(RETRY_BUTTON_ENABLED, false);
        getEventBus().post(new ResetGameCommand());
    }

    /**
     * Handles ErrorModelChangedEvent.
     * @param event ErrorModelChangedEvent.
     */
    @Subscribe
    public void handleErrorModelChangedEvent(ErrorModelChangedEvent event) {
        IErrorModel errorModel = event.getErrorModel();
        applyErrorInfo(errorModel.getMessage().getContent(), errorModel.isRetry());
    }

    /**
     * Shows error screen applying specific error model.
     * @param errorMessage error message
     * @param showRetry    a boolean value that indicates whether retry button should be shown or not
     */
    public void show(String errorMessage, boolean showRetry) {
        applyErrorInfo(errorMessage, showRetry);
        show();
    }

    /**
     * Applies error model to the screen.
     * @param errorMessage error message
     * @param showRetry    a boolean value that indicates whether retry button should be shown or not
     */
    private void applyErrorInfo(String errorMessage, boolean showRetry) {
        if (showRetry) {
            setModelProperty(RETRY_BUTTON_VISIBLE, true);
            setModelProperty(RETRY_BUTTON_ENABLED, true);
        } else {
            setModelProperty(RETRY_BUTTON_VISIBLE, false);
        }
        getModel().setErrorMessage(errorMessage);
    }

    @Override
    protected View createLayout() {
        float allowedErrorWidth = gameConfiguration.getWidth() * MAXIMUM_ALLOWED_PERCENTAGE_SIZE;
        float allowedErrorHeight = gameConfiguration.getHeight() * MAXIMUM_ALLOWED_PERCENTAGE_SIZE;
        float scale = allowedErrorWidth / DEFAULT_ERROR_SCREEN_WIDTH;
        if (scale * DEFAULT_ERROR_SCREEN_HEIGHT > allowedErrorHeight) {
            scale = allowedErrorHeight / DEFAULT_ERROR_SCREEN_HEIGHT;
        }
        ViewGroup viewGroup = new ViewGroup();
        RectangleShapeView background = createRectangle(DEFAULT_BACKGROUND_COLOR, DEFAULT_ERROR_SCREEN_WIDTH * scale, DEFAULT_ERROR_SCREEN_HEIGHT * scale);
        viewGroup.addChild(background);

        ViewGroup retryButtonElements = createRetryButton(scale);
        viewGroup.addChild(retryButtonElements);
        retryButtonElements.setX((background.getWidth() - retryButtonElements.getOffsetWidth()) / DIVIDER);
        retryButtonElements.setY(background.getHeight() - (float) (retryButtonElements.getOffsetHeight() * 1.5));
        retryButtonElements.setReleaseListener(event -> retryButtonClicked());

        TextView errorMessageField = createText(background.getWidth(), retryButtonElements.getY(), (int) (DEFAULT_TEXT_FONT_SIZE * scale),
                DEFAULT_ERROR_MESSAGE_COLOR);
        viewGroup.addChild(errorMessageField);
        DeferredTemplateBinding messageInfoBinding = new DeferredTemplateBinding(ErrorScreenModel.ERROR_MESSAGE_KEY,
                (ObservableProperty) errorMessageField.text());
        messageInfoBinding.setModel(getModel());

        viewGroup.setX((gameConfiguration.getWidth() - background.getWidth()) / DIVIDER);
        viewGroup.setY((gameConfiguration.getHeight() - background.getHeight()) / DIVIDER);
        return viewGroup;
    }

    /**
     * Creates and returns new retry button.
     * @param errorScale error scale
     * @return view group with retry button elements
     */
    private ViewGroup createRetryButton(float errorScale) {
        ViewGroup buttonElements = new ViewGroup();
        RectangleShapeView retryButton = createRectangle(DEFAULT_RETRY_BUTTON_COLOR, DEFAULT_RETRY_BUTTON_WIDTH * errorScale,
                DEFAULT_RETRY_BUTTON_HEIGHT * errorScale);
        buttonElements.addChild(retryButton);
        DeferredExternalBinding retryButtonVisibleBinding = new DeferredExternalBinding("#" + RETRY_BUTTON_VISIBLE, (ObservableProperty) retryButton.visible());
        retryButtonVisibleBinding.setModel(getModel());
        TextView retryButtonText = createText(retryButton.getWidth(), retryButton.getHeight(), (int) (DEFAULT_TEXT_FONT_SIZE * errorScale),
                DEFAULT_RETRY_TEXT_COLOR);
        retryButtonText.setText(RETRY_BUTTON_TEXT);
        buttonElements.addChild(retryButtonText);
        DeferredExternalBinding retryTextVisibleBinding = new DeferredExternalBinding("#" + RETRY_BUTTON_VISIBLE,
                (ObservableProperty) retryButtonText.visible());
        retryTextVisibleBinding.setModel(getModel());
        return buttonElements;
    }

    /**
     * Creates and returns new text view.
     * @param width    width of the field
     * @param height   height of the field
     * @param fontSize font size of the text
     * @param color    text color
     */
    private TextView createText(float width, float height, int fontSize, int color) {
        TextView textView = new TextView();
        textView.setValign(VerticalAlign.MIDDLE);
        textView.setHalign(HorizontalAlign.CENTER);
        textView.setWidth(width);
        textView.setHeight(height);
        textView.setWordWrap(true);
        textView.setFontSize(fontSize);
        textView.setColor(color);
        return textView;
    }

    /**
     * Creates and returns new rectangle shape view.
     * @param color  background color of the rectangle
     * @param width  width of the rectangle
     * @param height height of the rectangle
     */
    private RectangleShapeView createRectangle(int color, float width, float height) {
        RectangleShapeView rectangleShapeView = new RectangleShapeView();
        rectangleShapeView.setFillColor(color);
        rectangleShapeView.setWidth(width);
        rectangleShapeView.setHeight(height);
        return rectangleShapeView;
    }

}
