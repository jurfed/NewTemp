package com.atsisa.gox.reels.logic.model;

/**
 * Represents an information about history.
 */
public class HistoryInfo {

    /**
     * Total number of history pages.
     */
    private int totalNumberPages;

    /**
     * Date of the history.
     */
    private String historyDate;

    /**
     * Contains information about number of the page for which is this history info.
     */
    private int pageNumber;

    /**
     * Initializes a new instance of the {@link HistoryInfo} class.
     * @param totalNumberPages total number of pages in history
     * @param historyDate history date
     */
    public HistoryInfo(int totalNumberPages, String historyDate) {
        this.totalNumberPages = totalNumberPages;
        this.historyDate = historyDate;
    }

    /**
     * Gets number of the page for which is this history info.
     * @return history page number
     */
    public int getPageNumber() {
        return pageNumber;
    }

    /**
     * Sets number of the page for which is this history info.
     * @param pageNumber history page number
     */
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * Gets total number of pages in history.
     * @return total number of pages in history
     */
    public int getTotalNumberPages() {
        return totalNumberPages;
    }

    /**
     * Gets history date.
     * @return history date
     */
    public String getHistoryDate() {
        return historyDate;
    }
}
