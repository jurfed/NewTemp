package com.atsisa.gox.reels.view;

import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolModificationStrategy;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;
import com.gwtent.reflection.client.Reflectable;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayFIFOQueue;

/**
 * A default implementation of the symbol pool.
 * <p>
 * The symbol pool uses a {@link ISymbolFactory} to instantiate symbols on demand.
 * It also uses {@link ISymbolPoolStrategy} to customize the behavior of the pool by
 * determining how to populate the pool when it is created (via the
 * {@link ISymbolPoolStrategy#initialize(ISymbolFactory)}
 * method) and how to behave in case the pool has been drained (via the
 * {@link ISymbolPoolStrategy#getMissingSymbol(ISymbolPool, String)}
 * method).
 * </p>
 * There are three predefined symbol pool strategies:
 * <ul>
 * <li>{@link DynamicSymbolPoolStrategy} (default) - dynamically instantiates
 * missing symbols as we go using the symbol factory up to given limits per symbol name (unlimited by default).</li>
 * <li>{@link FixedSymbolPoolStrategy} - uses predefined symbol quantities which
 * are instantiated when the symbol pool is created.</li>
 * <li>{@link ReelStripSymbolPoolStrategy} - similar to fixed symbol pool
 * strategy except it uses a reel strip definition to determine quantities which should be instantiated when the symbol
 * pool is created.</li>
 * </ul>
 */
@Reflectable
public class SymbolPool implements ISymbolPool {

    /**
     * Default capacity of symbol set.
     */
    private static final int SYMBOL_SET_CAPACITY = 25;

    /**
     * Helper localSymbolSet variable instance.
     */
    private static ObjectArrayFIFOQueue<AbstractSymbol> localSymbolsSet;

    /**
     * Helper localSymbolSet variable instance.
     */
    private static Int2ObjectArrayMap<AbstractSymbol> localTakenSymbolsSet;

    /**
     * Class level for instances of render method local variables.
     */
    private final LocalVariables lv;

    /**
     * The map of symbols which are ready to be retrieved.
     */
    private final Object2ObjectArrayMap<String, ObjectArrayFIFOQueue<AbstractSymbol>> freeSymbols = new Object2ObjectArrayMap<>();

    /**
     * The map of symbols which are legit for returning.
     */
    private final Object2ObjectArrayMap<String, Int2ObjectArrayMap<AbstractSymbol>> takenSymbols = new Object2ObjectArrayMap<>();

    /**
     * Symbol pool strategy.
     */
    private final ISymbolPoolStrategy strategy;

    /**
     * Symbol pool factory.
     */
    private final ISymbolFactory symbolFactory;

    /**
     * Total symbols count.
     */
    private int totalSymbolsCount;


    /**
     * The strategy which is responsible for the symbol modifications.
     */
    private ISymbolModificationStrategy symbolModificationStrategy;

    /**
     * Initializes a new instance of the {@link SymbolPool} class using given pool
     * strategy and symbol factory.
     * @param symbolFactory The symbol factory.
     * @param strategy      The symbol pool strategy.
     */
    private SymbolPool(ISymbolFactory symbolFactory, ISymbolPoolStrategy strategy) {
        if (symbolFactory == null) {
            throw new IllegalArgumentException("The symbol factory cannot be null.");
        }
        if (strategy == null) {
            throw new IllegalArgumentException("The symbol pool strategy cannot be null.");
        }

        this.strategy = strategy;
        this.symbolFactory = symbolFactory;
        totalSymbolsCount = 0;
        lv = new LocalVariables();
    }

    /**
     * Initializes the symbol pool.
     */
    private void initialize() {
        Iterable<AbstractSymbol> initialSymbols = strategy.initialize(symbolFactory);
        if (initialSymbols != null) {
            for (AbstractSymbol symbol : initialSymbols) {
                getOrCreateSymbolSet(freeSymbols, symbol.getName()).enqueue(symbol);
                // Creates all possible sets in taken symbols map to limit the creation of objects on symbol returning.
                getOrCreateTakenSymbolSet(takenSymbols, symbol.getName());
                totalSymbolsCount++;
            }
        }
    }

    /**
     * Creates a new symbol pool using given symbol factory and a
     * {@link DynamicSymbolPoolStrategy}.
     * @param symbolFactory The symbol factory.
     * @return A new symbol pool.
     */
    public static SymbolPool newSymbolPool(ISymbolFactory symbolFactory) {
        return newSymbolPool(symbolFactory, new DynamicSymbolPoolStrategy());
    }

    /**
     * Creates a new symbol pool using given symbol factory and a
     * {@link DynamicSymbolPoolStrategy}.
     * @param symbolFactory The symbol factory.
     * @param strategy      The symbol pool strategy.
     * @return A new symbol pool.
     */
    public static SymbolPool newSymbolPool(ISymbolFactory symbolFactory, ISymbolPoolStrategy strategy) {
        SymbolPool symbolPool = new SymbolPool(symbolFactory, strategy);
        symbolPool.initialize();
        return symbolPool;
    }

    @Override
    public AbstractSymbol getSymbol(String symbolName) {
        AbstractSymbol abstractSymbol;
        lv.localFreeSymbols = freeSymbols.get(symbolName);
        if (lv.localFreeSymbols != null && !lv.localFreeSymbols.isEmpty()) {
            lv.localSymbol = lv.localFreeSymbols.dequeue();
            getOrCreateTakenSymbolSet(takenSymbols, symbolName).put(lv.localSymbol.getUuid(), lv.localSymbol);
            abstractSymbol = lv.localSymbol;
        } else {
            abstractSymbol = getSymbolFallback(symbolName);
        }

        if (symbolModificationStrategy != null) {
            symbolModificationStrategy.modify(abstractSymbol);
        }
        return abstractSymbol;
    }

    @Override
    public void returnSymbol(AbstractSymbol symbol) {
        lv.localTakenSymbols = takenSymbols.get(symbol.getName());
        if (lv.localTakenSymbols != null && lv.localTakenSymbols.remove(symbol.getUuid()) != null) {
            getOrCreateSymbolSet(freeSymbols, symbol.getName()).enqueue(symbol);
            return;
        }

        throw new SymbolPoolException("The returned symbol does not belong to this symbol pool.");
    }

    @Override
    public ISymbolFactory getSymbolFactory() {
        return symbolFactory;
    }

    @Override
    public int getSymbolsCount() {
        return totalSymbolsCount;
    }

    @Override
    public int getSymbolsCount(String symbolName) {
        int count = 0;
        if (freeSymbols.get(symbolName) != null) {
            count += freeSymbols.get(symbolName).size();
        }

        if (takenSymbols.get(symbolName) != null) {
            count += takenSymbols.get(symbolName).size();
        }

        return count;
    }

    @Override
    public ISymbolModificationStrategy getSymbolModificationStrategy() {
        return symbolModificationStrategy;
    }

    @Override
    public void setSymbolModificationStrategy(ISymbolModificationStrategy symbolModificationStrategy) {
        this.symbolModificationStrategy = symbolModificationStrategy;
    }

    /**
     * Applies the missing symbol strategy.
     * @param symbolName The missing symbol name.
     * @return An instance of the missing symbol.
     */
    private AbstractSymbol getSymbolFallback(String symbolName) {
        AbstractSymbol answer = strategy.getMissingSymbol(this, symbolName);
        if (answer != null) {
            totalSymbolsCount++;
            getOrCreateTakenSymbolSet(takenSymbols, symbolName).put(answer.getUuid(), answer);
        }

        return answer;
    }

    /**
     * Clears all local symbols.
     */
    public static void clearAllSymbols(){
        localSymbolsSet.clear();
        localTakenSymbolsSet.clear();
    }

    /**
     * Gets or creates a symbol set in given target map.
     * @param target     The target map.
     * @param symbolName Requested symbol name.
     * @return A symbol set for given name.
     */
    private static ObjectArrayFIFOQueue<AbstractSymbol> getOrCreateSymbolSet(Object2ObjectArrayMap<String, ObjectArrayFIFOQueue<AbstractSymbol>> target,
            String symbolName) {
        localSymbolsSet = target.get(symbolName);
        if (localSymbolsSet == null) {
            localSymbolsSet = new ObjectArrayFIFOQueue<>(SYMBOL_SET_CAPACITY);
            target.put(symbolName, localSymbolsSet);
        }

        return localSymbolsSet;
    }

    /**
     * Gets or creates a symbol set in given target map.
     * @param target     The target map.
     * @param symbolName Requested symbol name.
     * @return A symbol set for given name.
     */
    private static Int2ObjectArrayMap<AbstractSymbol> getOrCreateTakenSymbolSet(Object2ObjectArrayMap<String, Int2ObjectArrayMap<AbstractSymbol>> target,
            String symbolName) {
        localTakenSymbolsSet = target.get(symbolName);
        if (localTakenSymbolsSet == null) {
            localTakenSymbolsSet = new Int2ObjectArrayMap<>(SYMBOL_SET_CAPACITY);
            target.put(symbolName, localTakenSymbolsSet);
        }

        return localTakenSymbolsSet;
    }

    /**
     * Holder for instances of local variables used in the {@link SymbolPool} methods.
     */
    private class LocalVariables {

        private Int2ObjectArrayMap<AbstractSymbol> localTakenSymbols;

        private ObjectArrayFIFOQueue<AbstractSymbol> localFreeSymbols;

        private AbstractSymbol localSymbol;
    }
}
