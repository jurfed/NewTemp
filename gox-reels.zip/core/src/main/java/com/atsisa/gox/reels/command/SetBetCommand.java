package com.atsisa.gox.reels.command;

import java.math.BigDecimal;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for setting bet value.
 */
@Reflectable
public class SetBetCommand extends UserInteractionCommand {

    /**
     * The bet value to be set.
     */
    private final BigDecimal value;

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     * @param value           bet value to be set.
     */
    public SetBetCommand(BigDecimal value, boolean triggeredByUser) {
        super(triggeredByUser);
        this.value = value;
    }

    /**
     * Value of the bet.
     * @return value of the bet.
     */
    public BigDecimal getValue() {
        return value;
    }

}
