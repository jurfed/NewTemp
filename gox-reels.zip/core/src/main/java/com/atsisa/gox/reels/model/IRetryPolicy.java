package com.atsisa.gox.reels.model;

/**
 * Delivers retry button policy for error handling.
 */
public interface IRetryPolicy {

    /**
     * Gets flag if cause is retriable.
     * @param cause throwable
     * @return {true} if cause is retriable, {false} if not
     */
    boolean isRetriable(Throwable cause);
}
