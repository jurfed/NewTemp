package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.IPropertyChangedListener;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.ICaption;
import com.atsisa.gox.framework.utility.IPointsHolder;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.Point;
import com.atsisa.gox.framework.utility.Polyline;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.spi.IWinLineViewChildSelector;
import com.atsisa.gox.reels.view.state.WinLineState;
import com.gwtent.reflection.client.annotations.Reflect_Full;

import rx.functions.Action2;

/**
 * Describes a single game winning line.
 */
@XmlElement
@Reflect_Full
public class WinLineView extends AbstractWinLineView {

    /**
     * The begin tag of point-frame intersection.
     */
    private static final String POINT_BEGIN_TAG = "begin";

    /**
     * The end tag of point-frame intersection.
     */
    private static final String POINT_END_TAG = "end";

    /**
     * The indicator tag.
     */
    private static final String INDICATOR_TAG = "indicator";

    /**
     * The line tag.
     */
    private static final String LINE_TAG = "line";

    /**
     * Indicator data objects.
     */
    private final List<ICaption> indicatorDataObjects;

    /**
     * Line data objects.
     */
    private final List<IPointsHolder> lineDataObjects;

    /**
     * A list of views which were activated in current win line state.
     */
    private List<View> stateRelatedViews = new ArrayList<>();

    /**
     * A symbols line state based child selector.
     */
    private IWinLineViewChildSelector childSelector;

    /**
     * Gets a selector evaluated on win line state changes determining which children of this view should be activated.
     * @return The child view selector.
     */
    public IWinLineViewChildSelector getChildSelector() {
        return childSelector;
    }

    /**
     * Initializes a new instance of the {@link WinLineView} with a class-based children
     * filter.
     */
    public WinLineView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link WinLineView} with a class-based children
     * filter.
     * @param renderer {@link IRenderer}
     */
    public WinLineView(IRenderer renderer) {
        super(renderer);
        childSelector = new WinLineViewTagBasedSelector();
        state().addPropertyChangedListener(new WinLineStateListener());
        indicatorDataObjects = new LinkedList<>();
        lineDataObjects = new LinkedList<>();
    }

    @Override
    public void setLineNumber(int lineNumber) {
        super.setLineNumber(lineNumber);
        updateIndicators();
    }

    @Override
    public void dispose() {
        stateRelatedViews = new ArrayList<>();
        super.dispose();
    }

    /**
     * Refreshes all frame-line intersections.
     * <p>
     * This call may be needed when a new child representing either a line or a frame was added.
     * </p>
     */
    public void refreshFramesOverLinesIntersections() {
        clearFramesOverLinesIntersections();
        computeFramesOverLinesIntersections();

        if (getState() == WinLineState.SHOWN_WINNING) {
            showWin(getWinLineInfo());
            showScore(getWinScore());
        } else {
            hideWin();
        }
    }

    @Override
    public void hideWin() {
        for (IPointsHolder lineDataObject : lineDataObjects) {
            updateLinePoints(lineDataObject.getPoints(), null);
            ((View) lineDataObject).redraw();
        }

        updateFrameViews(getFrameViews(), null);
    }

    /**
     * Sets a selector evaluated on win line state changes determining which children of this view should be activated.
     * @param childSelector The child selector instance.
     * @throws IllegalArgumentException The children filter is null.
     */
    public void setChildSelector(IWinLineViewChildSelector childSelector) {
        if (childSelector == null) {
            throw new IllegalArgumentException("The child selector cannot be null.");
        }
        this.childSelector = childSelector;
    }

    @Override
    protected void init() {
        super.init();
        computeFramesOverLinesIntersections();
        updateIndicators();
    }

    @Override
    protected void deactivateChildren() {
        super.deactivateChildren();
        onStateChanged(getState());
    }

    @Override
    protected void processChildRecursive(View view, Action2<List, Object> action, Set<String> parentProcessedTags) {
        if (view.hasTag(INDICATOR_TAG) && view instanceof ICaption) {
            action.call(indicatorDataObjects, view);
            indicatorDataObjects.add((ICaption) view);
        } else if (view.hasTag(LINE_TAG) && view instanceof IPointsHolder) {
            action.call(lineDataObjects, view);
        }
        super.processChildRecursive(view, action, parentProcessedTags);
    }

    /**
     * Clears all resolved views.
     */
    @Override
    protected void clearResolvedViews() {
        super.clearResolvedViews();
        lineDataObjects.clear();
        indicatorDataObjects.clear();
    }

    /**
     * Gets the winning sequence bounds.
     * @return The list with winning sequence bounds.
     */
    @Override
    protected List<IBound> getWinningFramesBounds() {
        if (!hasWinningSequence()) {
            return Iterables.emptyList();
        }

        List<IBound> bounds = new ArrayList<>();

        int winningSequenceIndex = 0;
        List<Boolean> winningSequence = Iterables.toList(getWinLineInfo().getWinningSequence());

        int winningSequenceSize = winningSequence.size();
        for (IBound frameDataObject : getFrameDataObjects()) {
            if (winningSequenceIndex < winningSequenceSize) {
                if (winningSequence.get(winningSequenceIndex++)) {
                    bounds.add(frameDataObject);
                }
            } else {
                break;
            }
        }
        return bounds;
    }

    @Override
    public void showWin(IWinLineInfo winLineInfo) {
        setWinLineInfo(winLineInfo);
        for (IPointsHolder lineDataObject : lineDataObjects) {
            updateLinePoints(lineDataObject.getPoints(), Iterables.toList(winLineInfo.getWinningSequence()));
            ((View) lineDataObject).redraw();
        }
        updateFrameViews(getFrameViews(), winLineInfo);
        showScore(getWinScore());
    }

    /**
     * Gets a value indicating whether the winning sequence has been set.
     * @return True if the winning sequence has been set, false otherwise.
     */
    private boolean hasWinningSequence() {
        return getWinLineInfo() != null && getWinLineInfo().getWinningSequence() != null && getWinLineInfo().getWinningSequence().iterator().hasNext();
    }

    /**
     * Changes currently active child views according to the child selector and the view activator.
     * @param winLineState The new win line state value.
     */
    private synchronized void onStateChanged(WinLineState winLineState) {
        Iterable<View> newStateViews = childSelector.selectChildren(getChildrenRaw(), winLineState);
        List<View> activatedViews = stateRelatedViews;
        List<View> newStateViewsList = Iterables.newArrayListFrom(newStateViews);
        List<View> intersection = Iterables.newArrayListFrom(activatedViews);
        intersection.retainAll(newStateViewsList);
        for (View view : activatedViews) {
            if (!intersection.contains(view)) {
                getViewActivator().deactivate(view);
            }
        }
        for (View view : newStateViews) {
            if (!intersection.contains(view)) {
                getViewActivator().activate(view);
            }
        }
        stateRelatedViews = newStateViewsList;
    }

    /**
     * Update line indicators.
     */
    private void updateIndicators() {
        int tempLineNumber = getLineNumber();
        String lineNumberText = tempLineNumber > 0 ? String.valueOf(getLineNumber()) : null;
        for (ICaption indicatorDataObject : indicatorDataObjects) {
            indicatorDataObject.setText(lineNumberText);
        }
    }

    /**
     * Updates frame views according to the winning sequence.
     * @param frameViews The frame view to update.
     * @param winLine    The winning line info model.
     */
    private void updateFrameViews(List<View> frameViews, IWinLineInfo winLine) {
        if (winLine == null) {
            for (View view : frameViews) {
                getViewActivator().deactivate(view);
            }
            for (View scoreView : getScoreViews()) {
                getViewActivator().deactivate(scoreView);
            }
            return;
        }
        List<Boolean> winSequence = Iterables.toList(winLine.getWinningSequence());
        int winSequenceSize = winSequence.size();
        if (frameViews.size() != winSequenceSize) {
            throw new IllegalStateException("The number of frame views must match the size of the winning sequence.");
        }

        for (int index = 0; index < winSequenceSize; index++) {
            View currentView = frameViews.get(index);
            toggleView(currentView, winSequence.get(index));
        }
    }

    /**
     * Updates line points by cutting out sections which should be skipped according to the winning sequence.
     * @param points          The points to modify.
     * @param winningSequence The winning sequence.
     */
    private void updateLinePoints(Iterable<Point> points, List<Boolean> winningSequence) {
        List<Point> pointList = Iterables.toList(points);
        int sequenceIndex = 0;
        int beginCount = 0;
        int endCount = 0;
        for (int pointIndex = 0; pointIndex < pointList.size(); pointIndex++) {
            Point point = pointList.get(pointIndex);
            String correspondingTag = null;
            if (point.hasTag(POINT_BEGIN_TAG)) {
                beginCount++;
                correspondingTag = Point.POINT_OFF_TAG;
            } else if (point.hasTag(POINT_END_TAG)) {
                endCount++;
                correspondingTag = Point.POINT_ON_TAG;
            }

            if (correspondingTag != null) {
                if (winningSequence != null && sequenceIndex < winningSequence.size() && winningSequence.get(sequenceIndex)) {
                    point.addTag(correspondingTag);
                } else {
                    point.removeTag(correspondingTag);
                }
            }

            if (point.hasTag(POINT_END_TAG)) {
                sequenceIndex++;
            }
        }

        if (winningSequence == null || winningSequence.size() == 0) {
            if (beginCount != endCount) {
                throw new IllegalStateException("The number of '" + POINT_BEGIN_TAG + "' and '" + POINT_END_TAG + "' tags defined in points must match.");
            }
            return;
        }

        if (winningSequence.size() != beginCount || beginCount != endCount || sequenceIndex != winningSequence.size()) {
            throw new IllegalStateException(
                    "The number of '" + POINT_BEGIN_TAG + "' and '" + POINT_END_TAG + "' tags defined in points must match the size of the winning sequence ("
                            + winningSequence.size() + ')');
        }
    }

    /**
     * Computes the intersection points between point holders and boundaries.
     */
    private void computeFramesOverLinesIntersections() {
        String[] cuttingTags = new String[] { POINT_BEGIN_TAG, POINT_END_TAG };
        for (IPointsHolder lineDataObject : lineDataObjects) {
            Polyline polyline = new Polyline(Iterables.toList(lineDataObject.getPoints()));
            if (lineDataObject instanceof View) {
                polyline.setXOffset(((View) lineDataObject).getX() * -1);
                polyline.setYOffset(((View) lineDataObject).getY() * -1);
            }
            for (IBound frameDataObject : getFrameDataObjects()) {
                polyline = polyline.cutWith(frameDataObject, cuttingTags);
            }
            lineDataObject.setPoints(Iterables.toList(polyline.getPoints()));
        }
    }

    /**
     * Clears the frames over lines intersections so that.
     */
    private void clearFramesOverLinesIntersections() {
        for (IPointsHolder lineDataObject : lineDataObjects) {
            List<Point> filteredPoints = new LinkedList<>();
            for (Point point : lineDataObject.getPoints()) {
                if (!point.hasTag(POINT_BEGIN_TAG) && !point.hasTag(POINT_END_TAG)) {
                    filteredPoints.add(point);
                }
            }
            lineDataObject.setPoints(filteredPoints);
        }
    }

    /**
     * The default win line state listener.
     */
    private class WinLineStateListener implements IPropertyChangedListener<WinLineState> {

        @Override
        public void propertyChanged(IObservableProperty<WinLineState> source, WinLineState oldValue, WinLineState newValue) {
            onStateChanged(newValue);
        }
    }
}
