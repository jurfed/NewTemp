package com.atsisa.gox.reels.logic.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Represents a configuration of game.
 */
public class GameConfiguration {

    /**
     * The lines.
     */
    private final List<Integer> lines;

    /**
     * The bets per line.
     */
    private final List<BigDecimal> betsPerLine;

    /**
     * The max bet.
     */
    private final BigDecimal maxBet;

    /**
     * The max win.
     */
    private final BigDecimal maxWin;

    /**
     * The limit of gambler plays.
     */
    private final int gamblerPlayLimit;

    /**
     * The limit of gambler win.
     */
    private final BigDecimal gamblerWinLimit;

    /**
     * The pay table.
     */
    private final List<PayTableItem> payTable;

    /**
     * The currency code.
     */
    private final String currencyCode;

    /**
     * The yield value.
     */
    private final String yield;

    /**
     * The map of symbols.
     */
    private final Map<Integer, String> symbolsMap;

    /**
     * Initializes a new instance of the {@link GameConfiguration} class.
     * @param lines            the lines
     * @param betsPerLine      the bets per line
     * @param maxBet           the max bet
     * @param maxWin           the max win
     * @param gamblerPlayLimit the limit of gambler plays
     * @param gamblerWinLimit  the limit of gambler win
     * @param currencyCode     the currency code
     * @param payTable         the pay table
     * @param symbolsMap       the map of symbols
     * @param yield            the yield value
     */
    public GameConfiguration(List<Integer> lines, List<BigDecimal> betsPerLine, BigDecimal maxBet, BigDecimal maxWin, int gamblerPlayLimit,
            BigDecimal gamblerWinLimit, List<PayTableItem> payTable, String currencyCode, String yield, Map<Integer, String> symbolsMap) {
        this.lines = lines;
        this.betsPerLine = betsPerLine;
        this.maxBet = maxBet;
        this.maxWin = maxWin;
        this.gamblerPlayLimit = gamblerPlayLimit;
        this.gamblerWinLimit = gamblerWinLimit;
        this.payTable = payTable;
        this.currencyCode = currencyCode;
        this.yield = yield;
        this.symbolsMap = symbolsMap;
    }

    /**
     * Gets the lines.
     * @return the lines
     */
    public List<Integer> getLines() {
        return lines;
    }

    /**
     * Gets the bets per line.
     * @return the bets per line
     */
    public List<BigDecimal> getBetsPerLine() {
        return betsPerLine;
    }

    /**
     * Gets a max bet.
     * @return a max bet
     */
    public BigDecimal getMaxBet() {
        return maxBet;
    }

    /**
     * Gets a max win.
     * @return a max win
     */
    public BigDecimal getMaxWin() {
        return maxWin;
    }

    /**
     * Gets a limit of gambler plays.
     * @return a limit of gambler plays
     */
    public int getGamblerPlayLimit() {
        return gamblerPlayLimit;
    }

    /**
     * Gets a limit of gambler win.
     * @return a limit of gambler win
     */
    public BigDecimal getGamblerWinLimit() {
        return gamblerWinLimit;
    }

    /**
     * Gets a pay table.
     * @return a pay table
     */
    public List<PayTableItem> getPayTable() {
        return payTable;
    }

    /**
     * Gets a currency code.
     * @return a currency code
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Gets a yield value.
     * @return a yield value
     */
    public String getYield() {
        return yield;
    }

    /**
     * Gets a map of symbols.
     * @return a map of symbols
     */
    public Map<Integer, String> getSymbolsMap() {
        return symbolsMap;
    }
}
