package com.atsisa.gox.reels.logic.vocs.serialization.request;

import java.math.BigDecimal;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for bet request.
 */
public class BetRequestSerializer implements ISerializer<BetRequest, XmlObject> {

    @Override
    public XmlObject serialize(BetRequest request) {
        return new XmlBuilder()
            .startElement("nrgs")
                .startElement("req")
                    .startElement("a")
                        .writeValue("Bet")
                    .endElement()
                    .startElement("b")
                        .writeValue(request.getBetAmount().multiply(new BigDecimal(request.getLinesAmount())))
                    .endElement()
                    .startElement("ls")
                        .writeValue(request.getLinesAmount())
                    .endElement()
                .endElement()
            .endElement()
            .toXmlObject();
    }
}
