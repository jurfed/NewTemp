package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.model.HistoryInfo;

/**
 * Represents response result for history.
 */
public class HistoryResult {

    /**
     * History info.
     */
    private final HistoryInfo historyInfo;

    /**
     * Initializes a new instance of the {@link HistoryResult} class.
     * @param historyInfo       history info
     */
    public HistoryResult(HistoryInfo historyInfo) {
        this.historyInfo = historyInfo;
    }

    /**
     * Gets history info.
     * @return history info
     */
    public HistoryInfo getHistoryInfo() {
        return historyInfo;
    }
}
