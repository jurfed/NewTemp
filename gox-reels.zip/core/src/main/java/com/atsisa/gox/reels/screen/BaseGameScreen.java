package com.atsisa.gox.reels.screen;

import java.util.List;

import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.utility.reflection.ReflectionException;
import com.atsisa.gox.reels.command.DisplayStoppedSymbolsCommand;
import com.atsisa.gox.reels.command.SpinReelsCommand;
import com.atsisa.gox.reels.command.StartAnimationWinningSymbolsCommand;
import com.atsisa.gox.reels.command.StopAnimationWinningSymbolsCommand;
import com.atsisa.gox.reels.command.StopReelsCommand;
import com.atsisa.gox.reels.command.TerminateStartsShowingWinningSymbolsCommand;
import com.atsisa.gox.reels.event.ReelStoppingEvent;
import com.atsisa.gox.reels.event.ReelsShowingSymbolAnimationsEvent;
import com.atsisa.gox.reels.event.ReelsStopShowingSymbolAnimationsEvent;
import com.atsisa.gox.reels.event.ReelsStoppedEvent;
import com.atsisa.gox.reels.view.AbstractReel;
import com.atsisa.gox.reels.view.AbstractReelGroup;
import com.atsisa.gox.reels.view.IReel;
import com.atsisa.gox.reels.view.state.ReelGroupState;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

import rx.Subscription;

/**
 * Represents the base game screen.
 */
@Reflectable(fields = false)
public class BaseGameScreen extends Screen implements IResetable, IPauseable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "BaseGameScreenLayoutId";

    /**
     * List of last stopped symbols.
     */
    private List<Iterable<String>> lastStoppedSymbols;

    /**
     * The reel group view.
     */
    @InjectView
    @HasReflect
    public AbstractReelGroup reelGroupView;

    /**
     * The reel group state observable subscription.
     */
    private Subscription reelGroupStateSubscription;

    /**
     * Current reel group state.
     */
    private ReelGroupState currentReelGroupState;

    /**
     * Initializes a new instance of the {@link BaseGameScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public BaseGameScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        try {
            getEventBus().register(this);
        } catch (ReflectionException e) {
            getEventBus().post(new GeneralSystemException(e));
            getLogger().error(e.getMessage(), e);
        }
    }

    @Override
    protected void afterActivated() {
        updateStoppedSymbols();
        reelGroupStateSubscription = reelGroupView.getReelGroupStateObservable().subscribe(reelGroupState -> {
            if (reelGroupState == ReelGroupState.IDLE && currentReelGroupState == ReelGroupState.STOPPING) {
                getEventBus().post(new ReelsStoppedEvent());
            } else if (reelGroupState == ReelGroupState.IDLE && currentReelGroupState == ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS) {
                notifyReelsStopShowingWinningSymbols();
            } else if (reelGroupState == ReelGroupState.SHOWING_WINNING_SYMBOLS) {
                notifyReelsShowingWinningSymbols();
            }
            currentReelGroupState = reelGroupState;
        });
        Iterable<AbstractReel> reels = reelGroupView.getReels();
        for (final AbstractReel reel : reels) {
            reel.getReelAnimation().getAnimationStateObservable().subscribe(animationState -> {
                if (animationState == AnimationState.STOPPING) {
                    getEventBus().post(new ReelStoppingEvent(reel.getIndex()));
                }
            });
        }
        currentReelGroupState = reelGroupView.getReelGroupState();
    }

    @Override
    protected void beforeDeactivated() {
        reelGroupStateSubscription.unsubscribe();
        reelGroupStateSubscription = null;
    }

    /**
     * Sends a notification about reels stopped showing symbol animations.
     */
    private void notifyReelsStopShowingWinningSymbols() {
        getEventBus().post(new ReelsStopShowingSymbolAnimationsEvent());
    }

    /**
     * Sends a notification about reels is showing winning symbols.
     */
    private void notifyReelsShowingWinningSymbols() {
        getEventBus().post(new ReelsShowingSymbolAnimationsEvent());
    }

    /**
     * Handle spin reels command.
     * @param spinReelsCommand {@link SpinReelsCommand}
     */
    @Subscribe
    public void handleSpinReelsCommand(SpinReelsCommand spinReelsCommand) {
        reelGroupView.spin();
    }

    /**
     * Handle display stopped symbols command.
     * @param displayStoppedSymbolsCommand {@link DisplayStoppedSymbolsCommand}
     */
    @Subscribe
    public void handleDisplayStoppedSymbolsCommand(DisplayStoppedSymbolsCommand displayStoppedSymbolsCommand) {
        lastStoppedSymbols = displayStoppedSymbolsCommand.getStoppedSymbols();
        updateStoppedSymbols();
    }

    /**
     * Updates stopped symbols with last stopped.
     */
    private void updateStoppedSymbols() {
        if (reelGroupView != null && lastStoppedSymbols != null) {
            reelGroupView.stopOnSymbols(lastStoppedSymbols);
        }
    }

    /**
     * Handle stop reels command.
     * @param stopReelsCommand {@link SpinReelsCommand}
     */
    @Subscribe
    public void handleStopReelsCommand(StopReelsCommand stopReelsCommand) {
        boolean isIdle = reelGroupView.getReelGroupState() == ReelGroupState.IDLE;
        if (stopReelsCommand.isForceStop()) {
            reelGroupView.forceStopOnSymbols(stopReelsCommand.getSymbolNames());
        } else {
            reelGroupView.stopOnSymbols(stopReelsCommand.getSymbolNames());
        }
        if (isIdle) {
            getEventBus().post(new ReelsStoppedEvent());
        }
    }

    /**
     * Handle stop animation of winning symbols command.
     * @param stopAnimationWinningSymbolsCommand {@link StopAnimationWinningSymbolsCommand}
     */
    @Subscribe
    public void handleStopAnimationWinningSymbolsCommand(StopAnimationWinningSymbolsCommand stopAnimationWinningSymbolsCommand) {
        if (reelGroupView == null || (reelGroupView.getReelGroupState() != ReelGroupState.SHOWING_WINNING_SYMBOLS
                && reelGroupView.getReelGroupState() != ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS)) {
            notifyReelsStopShowingWinningSymbols();
            return;
        }

        if (stopAnimationWinningSymbolsCommand.isForceStop()) {
            reelGroupView.forceStopSymbolAnimations();
        } else {
            reelGroupView.stopSymbolAnimations();
        }
    }

    /**
     * Handle start animation of winning symbols command.
     * @param startAnimationWinningSymbolsCommand {@link StartAnimationWinningSymbolsCommand}
     */
    @Subscribe
    public void handleStartAnimationWinningSymbolsCommand(StartAnimationWinningSymbolsCommand startAnimationWinningSymbolsCommand) {
        if (reelGroupView.getReelGroupState() == ReelGroupState.IDLE) {
            reelGroupView.showWinningSymbols(startAnimationWinningSymbolsCommand.getWinningLines());
        } else if (reelGroupView.getReelGroupState() == ReelGroupState.SHOWING_WINNING_SYMBOLS
                || reelGroupView.getReelGroupState() == ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS) {
            notifyReelsShowingWinningSymbols();
        } else {
            throw new IllegalStateException(StringUtility
                    .format("Can not start animation winning symbols, because reels are not in proper condition, current state is: %s",
                            reelGroupView.getReelGroupState()));
        }
    }

    /**
     * Handle terminate starts showing winning symbols command.
     * @param startsShowingWinningSymbolsCommand {@link TerminateStartsShowingWinningSymbolsCommand}
     */
    @Subscribe
    public void handleTerminateStartsShowingAnimationWinningSymbols(TerminateStartsShowingWinningSymbolsCommand startsShowingWinningSymbolsCommand) {
        if (reelGroupView != null && reelGroupView.getReelGroupState() == ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS) {
            reelGroupView.terminateStartsShowingWinningSymbols();
        }
    }

    @Override
    @ExposeMethod
    public void reset() {
        if (reelGroupView == null) {
            return;
        }
        reelGroupView.reset();
    }

    @Override
    @ExposeMethod
    public void pause() {
        if (reelGroupView == null) {
            return;
        }
        if (reelGroupView.getReelGroupState() == ReelGroupState.SHOWING_WINNING_SYMBOLS
                || reelGroupView.getReelGroupState() == ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS) {
            reelGroupView.stopSymbolAnimations();
        } else if (reelGroupView.getReelGroupState() == ReelGroupState.SPINNING) {
            for (IReel reel : reelGroupView.getReels()) {
                reel.getReelAnimation().pause();
            }
        }
    }
}
