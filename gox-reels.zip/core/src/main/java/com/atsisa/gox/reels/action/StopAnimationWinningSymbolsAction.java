package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.StopAnimationWinningSymbolsCommand;
import com.atsisa.gox.reels.event.ReelsStopShowingSymbolAnimationsEvent;

/**
 * Sends command which stops showing winning symbols.
 */
public class StopAnimationWinningSymbolsAction extends WaitForEventAction<ReelsStopShowingSymbolAnimationsEvent> {

    /**
     * Initializes a new instance of the {@link StopAnimationWinningSymbolsAction} class.
     */
    public StopAnimationWinningSymbolsAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link StopAnimationWinningSymbolsAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public StopAnimationWinningSymbolsAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected Class<ReelsStopShowingSymbolAnimationsEvent> getEventClass() {
        return ReelsStopShowingSymbolAnimationsEvent.class;
    }

    @Override
    protected void execute() {
        super.execute();
        sendStopWinningSymbolsCommand(false);
    }

    @Override
    protected void terminate() {
        super.terminate();
        sendStopWinningSymbolsCommand(true);
    }

    /**
     * Sends a request to stop showing winning symbols.
     * @param forceStop a boolean value that indicates whether winning symbols should be force stopped or not.
     */
    private void sendStopWinningSymbolsCommand(boolean forceStop) {
        StopAnimationWinningSymbolsCommand stopCommand = new StopAnimationWinningSymbolsCommand();
        stopCommand.setForceStop(forceStop);
        eventBus.post(stopCommand);
    }

}
