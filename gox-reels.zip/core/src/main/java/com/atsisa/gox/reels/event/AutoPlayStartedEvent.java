package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when auto play was started.
 */
@Reflectable
public class AutoPlayStartedEvent extends AbstractEvent {

}
