package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for reset info about current winning line.
 */
@Reflectable
public class ResetWinningLinesCommand {

}
