package com.atsisa.gox.reels.logic.request;

/**
 * Represents a take win request.
 */
public class TakeWinRequest {

}
