package com.atsisa.gox.reels.animation.phase;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.Statics;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Animation phase that performs movement in accordance with specified predeclared configuration.
 */
@Reflect_Full
@XmlElement
public class PredeclaredStepReelAnimationPhase implements IReelAnimationPhase {

    /**
     * Index tracking position of current step.
     */
    private int index;

    /**
     * Accumulator used to accumulate increase of delta time.
     */
    private float accumulator;

    /**
     * Interval in which steps should be processed. Default value triggers the processing at the rate of 60FPS.
     */
    @XmlAttribute(name = "interval")
    private float interval = Statics.FPS_60;

    /**
     * List containing steps of a given animation.
     */
    @XmlCollectionElement(name = "steps", itemName = "value", itemType = Float.class)
    private List<Float> steps;

    /**
     * Creates a new instance of PredeclaredStepReelAnimationPhase.
     */
    public PredeclaredStepReelAnimationPhase() {
        steps = new ArrayList<>();
        index = 0;
    }

    @Override
    public float getStepOffset(float delta) {
        accumulator += delta * Statics.MILLIS_IN_SECOND;
        if (!isFinished() && shouldProcessNextStep()) {
            accumulator -= interval;
            return nextAnimationPhaseStep();
        }
        return 0;
    }

    @Override
    public boolean isFinished() {
        return index >= steps.size();
    }

    /**
     * Evaluates whether accumulator is high enough to trigger next animation step.
     * @return true if step should be processed, false otherwise
     */
    private boolean shouldProcessNextStep() {
        return accumulator > interval;
    }

    /**
     * Fetches next animation phase step and increases proper index.
     * @return number of pixels by which reels should be moved
     */
    private float nextAnimationPhaseStep() {
        return steps.get(index++);
    }

    @Override
    public void reset() {
        index = 0;
        accumulator = 0;
    }

    @Override
    public IReelAnimationPhase clone() {
        PredeclaredStepReelAnimationPhase phase = new PredeclaredStepReelAnimationPhase();
        phase.steps = steps;
        phase.interval = interval;
        return phase;
    }

    /**
     * Animation steps setter.
     * @param steps list of predeclared animation phase steps
     */
    public void setSteps(List<Float> steps) {
        this.steps = steps;
    }

    /**
     * Animation steps processing interval (in millis).
     * @param interval interval at which animation steps should be processed
     */
    public void setInterval(float interval) {
        this.interval = interval;
    }
}
