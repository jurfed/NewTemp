package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.model.IBetModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class SendGambleRequestAction extends AbstractSendRequestAction {

    /**
     * {@link IBetModelProvider} reference.
     */
    private IBetModelProvider betModelProvider;

    /**
     * {@link ILinesModelProvider} reference.
     */
    private ILinesModelProvider linesModelProvider;

    /**
     * Initializes a new instance of the {@link SendGambleRequestAction} class.
     * @param game               {@link AbstractReelGame}
     * @param betModelProvider   {@link IBetModelProvider}
     * @param linesModelProvider {@link ILinesModelProvider}
     */
    public SendGambleRequestAction(AbstractReelGame game, IBetModelProvider betModelProvider, ILinesModelProvider linesModelProvider) {
        super(game);
        this.betModelProvider = betModelProvider;
        this.linesModelProvider = linesModelProvider;
    }

    /**
     * Initializes a new instance of the {@link SendGambleRequestAction} class.
     */
    public SendGambleRequestAction() {
        super();
        betModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider();
        linesModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider();
    }

    @Override
    protected void execute() {
        EnterGamblerRequest request = new EnterGamblerRequest(betModelProvider.getBetModel().getBetPerLine(),
                linesModelProvider.getLinesModel().getSelectedLines());
        subscribeForResult(getGameLogic().enterGambler(request));
    }

}
