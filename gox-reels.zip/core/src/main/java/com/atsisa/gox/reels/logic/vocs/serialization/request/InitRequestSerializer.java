package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for init request.
 */
public class InitRequestSerializer implements ISerializer<InitRequest, XmlObject> {

    @Override
    public XmlObject serialize(InitRequest request) {
        return createBasicXmlDescription(request.getGameIdentity(), request.getLanguageCode());
    }

    /**
     * Creates and returns basic serialized description object.
     * @param gameIdentity game identity
     * @param languageCode language code
     * @return basic description object
     */
    static XmlObject createBasicXmlDescription(String gameIdentity, String languageCode) {
        return new XmlBuilder().startElement("nrgs").startElement("req").startElement("a").writeValue("Init").endElement().startElement("l")
                .writeAttribute("w", gameIdentity).writeValue(languageCode).endElement().endElement().endElement().toXmlObject();
    }

}