package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;

import rx.Observable;

/**
 * Represents a logic of reel game which is support history.
 */
public interface IReelGameHistoryLogic {

    /**
     * Handles request for history page.
     * @param historyRequest a history page request.
     * @return the observable result
     */
    Observable<Object> history(HistoryRequest historyRequest);

    /**
     * Handles request to exit from the history.
     * @param initRequest request to exit from the history
     * @return the observable result
     */
    Observable<Object> exitHistory(InitRequest initRequest);

}
