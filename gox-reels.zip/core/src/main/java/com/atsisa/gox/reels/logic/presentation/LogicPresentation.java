package com.atsisa.gox.reels.logic.presentation;

/**
 * Represents a basic properties for each presentations.
 */
public abstract class LogicPresentation {

    /**
     * Name of the presentation.
     */
    private String name;

    /**
     * A boolean value that indicates whether this presentation is resumed or not.
     */
    private boolean resumed;

    /**
     * A boolean value that indicates whether this presentation is history or not.
     */
    private boolean history;

    /**
     * Initializes a new instance of the {@link LogicPresentation} class.
     * @param name    the name of the presentation
     * @param resumed a boolean value that indicates whether this presentation is resumed or not.
     * @param history a boolean value that indicates whether this presentation is history or not.
     */
    public LogicPresentation(String name, boolean resumed, boolean history) {
        this.name = name;
        this.resumed = resumed;
        this.history = history;
    }

    /**
     * Gets a boolean value that indicates whether this presentation is history or not.
     * @return boolean
     */
    public boolean isHistory() {
        return history;
    }

    /**
     * Gets a boolean value that indicates whether this presentation is resumed or not.
     * @return boolean
     */
    public boolean isResumed() {
        return resumed;
    }

    /**
     * Gets the presentation name.
     * @return the presentation name
     */
    public String getName() {
        return name;
    }

}
