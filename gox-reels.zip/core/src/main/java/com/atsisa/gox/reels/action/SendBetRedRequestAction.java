package com.atsisa.gox.reels.action;

import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Sends bet red request during gambler.
 */
@Reflect_Mini
public class SendBetRedRequestAction extends AbstractSendRequestAction {

    /**
     * Bet red selection name.
     */
    private static final String BET_BLACK_SELECTION_NAME = "BetRed";

    @Override
    protected void execute() {
        subscribeForResult(getGameLogic().gamble(new GambleRequest(BET_BLACK_SELECTION_NAME)));
    }

}
