package com.atsisa.gox.reels.action;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.StopReelsCommand;
import com.atsisa.gox.reels.event.ReelsStoppedEvent;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;

/**
 * An action responsible for stopping reels on positions memorized and provided by an instance of the
 * {@link IReelGameStateHolder}.
 */
public class StopReelsAction extends WaitForEventAction<ReelsStoppedEvent> {

    /**
     * {@link IReelGameStateHolder} reference.
     */
    private final IReelGameStateHolder reelGameStateHolder;

    /**
     * Stopped symbols.
     */
    private List<Iterable<String>> stoppedSymbols;

    /**
     * Initializes a new instance of the {@link StopReelsAction} class.
     */
    public StopReelsAction() {
        reelGameStateHolder = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder();
    }

    /**
     * Initializes a new instance of the {@link StopReelsAction} class.
     * @param logger              {@link ILogger}
     * @param eventBus            {@link IEventBus}
     * @param reelGameStateHolder {@link IReelGameStateHolder}
     */
    public StopReelsAction(ILogger logger, IEventBus eventBus, IReelGameStateHolder reelGameStateHolder) {
        super(logger, eventBus);
        this.reelGameStateHolder = reelGameStateHolder;
    }

    @Override
    protected void execute() {
        super.execute();
        StopReelsCommand command = new StopReelsCommand(stoppedSymbols);
        command.setForceStop(((StopReelsActionData) actionData).isForceStop());
        eventBus.post(command);
    }

    @Override
    protected Class<ReelsStoppedEvent> getEventClass() {
        return ReelsStoppedEvent.class;
    }

    @Override
    protected void grabData() {
        stoppedSymbols = reelGameStateHolder.getStoppedSymbols();
    }

    @Override
    protected void reset() {
        stoppedSymbols = null;
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return StopReelsActionData.class;
    }
}
