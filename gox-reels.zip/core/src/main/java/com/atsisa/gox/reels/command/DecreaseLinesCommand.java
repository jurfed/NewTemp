package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request for decreasing current number of lines the user plays on.
 */
@Reflectable
public final class DecreaseLinesCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link DecreaseLinesCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public DecreaseLinesCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
