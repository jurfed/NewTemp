package com.atsisa.gox.reels.action;

import java.math.BigDecimal;
import java.util.LinkedList;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimation;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.animation.WinToBalanceAnimation;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.atsisa.gox.reels.model.IAccount;

import rx.Subscription;
import rx.functions.Action1;

/**
 * Starts a {@link WinToBalanceAnimation} on data provided from the player's
 * {@link IAccount}.
 */
public class StartWinToBalanceAnimationAction extends Action<StartWinToBalanceAnimationActionData> {

    /**
     * Animation subscriptions.
     */
    private final LinkedList<Subscription> animationSubscriptions;

    /**
     * The account reference.
     */
    private final IAccount account;

    /**
     * Sound manager reference.
     */
    private final ISoundManager soundManager;

    /**
     * Win to balance animation.
     */
    private WinToBalanceAnimation winToBalanceAnimation;

    /**
     * Previous value of credits counted by animation.
     */
    private BigDecimal previousValue;

    /**
     * Id of the sound which should be played when animation will be skipped.
     */
    private String skipSoundId;

    /**
     * Initializes a new instance of the StartWinToBalanceAnimationAction class.
     */
    public StartWinToBalanceAnimationAction() {
        account = ((AbstractReelGame) GameEngine.current().getGame()).getAccount();
        soundManager = GameEngine.current().getSoundManager();
        animationSubscriptions = new LinkedList<>();
    }

    /**
     * Initializes a new instance of the StartWinToBalanceAnimationAction class.
     * @param logger       the logger
     * @param eventBus     the event bus
     * @param account      account
     * @param soundManager sound manager
     */
    public StartWinToBalanceAnimationAction(ILogger logger, IEventBus eventBus, IAccount account, ISoundManager soundManager) {
        super(logger, eventBus);
        this.account = account;
        this.soundManager = soundManager;
        animationSubscriptions = new LinkedList<>();
    }

    @Override
    protected void grabData() {
        BigDecimal startCredits = account.getBalance();
        BigDecimal totalCredits = account.getPendingBalance();
        previousValue = startCredits;
        winToBalanceAnimation = new WinToBalanceAnimation(startCredits, totalCredits, actionData.getSingleStepDuration());
        skipSoundId = actionData.getSkipSoundId();
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || actionData.getSingleStepDuration() <= 0) {
            throw new ValidationException("The single step duration must be a positive integer");
        }
    }

    @Override
    protected void reset() {
        while (!animationSubscriptions.isEmpty()) {
            animationSubscriptions.removeFirst().unsubscribe();
        }
        winToBalanceAnimation = null;
        skipSoundId = null;
    }

    @Override
    protected void execute() {
        Subscription creditsSubscription = winToBalanceAnimation.getCreditsObservable().subscribe(new Action1<BigDecimal>() {

            @Override
            public void call(BigDecimal bigDecimal) {
                if (winToBalanceAnimation.isPlaying()) {
                    BigDecimal currentStep = bigDecimal.subtract(previousValue);
                    eventBus.post(new TransferCreditsCommand(currentStep.setScale(2)));
                    previousValue = bigDecimal;
                }
            }
        });
        animationSubscriptions.add(creditsSubscription);
        Subscription animationStateSubscription = winToBalanceAnimation.getAnimationStateObservable().subscribe(new Action1<AnimationState>() {

            @Override
            public void call(AnimationState animationState) {
                if (animationState == AnimationState.STOPPED) {
                    finish();
                }
            }
        });
        animationSubscriptions.add(animationStateSubscription);
        winToBalanceAnimation.play();
    }

    @Override
    protected void terminate() {
        IAnimation currentAnimation = winToBalanceAnimation;
        if (currentAnimation != null) {
            if (skipSoundId != null) {
                soundManager.play(skipSoundId);
            }
            currentAnimation.stop();
        }
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return StartWinToBalanceAnimationActionData.class;
    }
}
