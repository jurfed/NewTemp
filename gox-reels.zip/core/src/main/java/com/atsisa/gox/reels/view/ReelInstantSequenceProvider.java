package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.reels.view.spi.IReelSequenceProvider;

import rx.Observable;

/**
 * Provides instant sequence for IReel type.
 */
@XmlElement
public class ReelInstantSequenceProvider implements IReelSequenceProvider {

    @Override
    public Observable<IReel> createSequence(Iterable<? extends IReel> items) {
        validateItems(items);
        return Observable.from(items);
    }

    /**
     * Validates IReels items and throw IllegalArgumentException when is null or empty.
     * @param items iterable IReel items
     */
    private void validateItems(Iterable<? extends IReel> items) {
        if (items == null || !items.iterator().hasNext()) {
            throw new IllegalArgumentException("Reels cannot be null or empty.");
        }
    }
}
