package com.atsisa.gox.reels.view.state;

import com.atsisa.gox.reels.view.WinLineView;

/**
 * Describes all possible {@link WinLineView} states.
 */
public enum WinLineState {

    /**
     * The state in which neither line indicators or the line itself is visible.
     * <p>
     * This state typically occurs when either the line was disabled by a configuration
     * or the player has chosen not to play on this line.
     * </p>
     */
    INACTIVE,

    /**
     * The state in which line indicators are visible but the line itself isn't.
     * <p>
     * This state is the default line state indicating the player has chosen
     * to play on this line.
     * </p>
     */
    ACTIVE,

    /**
     * The state in which both line indicators and the line itself is visible.
     * <p>
     * This state happens when line or bet amount is changed during a game play.
     * </p>
     */
    SHOWN,

    /**
     * The state in which both line indicators and the line itself is visible
     * as well as rectangles surrounding the winning symbols.
     * <p>
     * This state happens when the player has won the latest game play.
     * </p>
     */
    SHOWN_WINNING
}
