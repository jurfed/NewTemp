package com.atsisa.gox.reels.logic.request;

public class DebugGambleRequest extends GambleRequest {

    /**
     * The value indicating whether a win is expected.
     */
    private final boolean win;

    /**
     * Initializes a new instance of the {@link DebugGambleRequest} class.
     * @param win           a value indicating whether a win is expected
     * @param selectionName a name of selection
     */
    public DebugGambleRequest(boolean win, String selectionName) {
        super(selectionName);
        this.win = win;
    }

    /**
     * Gets a value indicating whether a win is expected.
     * @return value indicating whether a win is expected
     */
    public boolean isWin() {
        return win;
    }
}
