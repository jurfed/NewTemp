package com.atsisa.gox.reels.action;

import java.util.Optional;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.atsisa.gox.reels.view.IWinLine;

/**
 * Plays sound for current winning line.
 */
public class PlayCurrentWinningLineSoundAction extends Action {

    /**
     * Sound manager reference.
     */
    private ISoundManager soundManager;

    /**
     * Current win line sound id.
     */
    private String soundId;

    /**
     * Reference to sound timeout.
     */
    private Timeout timeout;

    /**
     * Reference to lines model provider.
     */
    private ILinesModelProvider linesModelProvider;

    /**
     * Construct action with default sound manager and line model.
     */
    public PlayCurrentWinningLineSoundAction() {
        this(((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider(), GameEngine.current().getSoundManager());
    }

    /**
     * Construct action with sound manager given as parameter and line model.
     * @param linesModelProvider {@link ILinesModelProvider}
     * @param soundManager       {@link ISoundManager}
     */
    public PlayCurrentWinningLineSoundAction(ILinesModelProvider linesModelProvider, ISoundManager soundManager) {
        this.soundManager = soundManager;
        soundId = null;
        this.linesModelProvider = linesModelProvider;
    }

    @Override
    protected void grabData() {
        Optional<IWinLineInfo> currentWinningLine = linesModelProvider.getLinesModel().getCurrentWinningLine();
        currentWinningLine.ifPresent(iWinLineInfo -> soundId = iWinLineInfo.getSoundName());
    }

    @Override
    protected void validate() throws ValidationException {
        if (soundId == null) {
            throw new ValidationException("Can not play winning line sound, because soundId was not set.");
        }
    }

    @Override
    protected void terminate() {
        soundManager.stop(soundId);
        timeout.clear();
    }

    @Override
    protected void reset() {
        super.reset();
        soundId = null;
        timeout = null;
    }

    @Override
    protected void execute() {
        timeout = new Timeout(soundManager.length(soundId), this::finish, true);
        soundManager.play(soundId);
    }
}
