package com.atsisa.gox.reels.message.processing;

import java.math.BigDecimal;
import java.util.Optional;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.model.IAccount;
import com.google.inject.Inject;

/**
 * Adjusts line pays messages according to player's latest translations.
 */
public class LinePaysMessageProcessor implements IGameMessageProcessor {

    /**
     * Line message.
     */
    private static final String LINE_MESSAGE = "{#LangLine}";

    /**
     * Scatter line message.
     */
    private static final String SCATTER_MESSAGE = "{#LangScatterPays}";

    /**
     * Pays message.
     */
    private static final String PAYS_MESSAGE = "{#LangLineXPays}";

    /**
     * Scatter line number.
     */
    private static final int SCATTER_LINE_NUMBER = 0;

    /**
     * The eventBus.
     */
    private final IEventBus eventBus;

    /**
     * The account.
     */
    private final IAccount account;

    /**
     * The lines model mutator.
     */
    private IMutator<ILinesModel> linesModelMutator;

    /**
     * Lines model reference.
     */
    private ILinesModel linesModel;

    /**
     * Current line number.
     */
    private int currentLineNumber;

    /**
     * Current line score.
     */
    private BigDecimal currentLineScore;

    /**
     * Initializes a new instance of the {@link LinePaysMessageProcessor} class.
     * @param eventBus          {@link IEventBus}
     * @param account           {@link IAccount}
     * @param linesModelMutator the lines model mutator
     */
    @Inject
    public LinePaysMessageProcessor(IEventBus eventBus, IAccount account, IMutator<ILinesModel> linesModelMutator) {
        this.eventBus = eventBus;
        this.account = account;
        this.linesModelMutator = linesModelMutator;
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new LinesModelChangedEventObserver(), LinesModelChangedEvent.class);
    }

    @Override
    public void process(GameMessage gameMessage) {
        if (gameMessage.getContent().equals(PAYS_MESSAGE)) {
            String newMessage;
            if (isScatter()) {
                newMessage = StringUtility
                        .format("%s %s", SCATTER_MESSAGE, account.getCreditsFormatter().formatWithCurrency(currentLineScore));
            } else {
                newMessage = StringUtility.format("%s %s %s %s", LINE_MESSAGE, currentLineNumber, PAYS_MESSAGE,
                        account.getCreditsFormatter().formatWithCurrency(currentLineScore));
            }
            gameMessage.setContent(newMessage);
        }
    }

    /**
     * Checks if line is a scatter.
     * @return true if line number equals 0, otherwise false
     */
    private boolean isScatter() {
        return currentLineNumber == SCATTER_LINE_NUMBER;
    }

    /**
     * Updates a number of active lines according to recent lines model changes.
     * @param linesModelChangedEvent {@link LinesModelChangedEvent}
     */
    @Subscribe
    public void handle(LinesModelChangedEvent linesModelChangedEvent) {
        linesModel = linesModelMutator.mutate(linesModelChangedEvent.getLinesModel());
        if (linesModelChangedEvent.hasCurrentWinningLineChanged()) {
            winLineInfoChanged(linesModel.getCurrentWinningLine());
        }
    }

    /**
     * Called when win line info was changed.
     * @param currentWinningLineInfo win line info
     */
    private void winLineInfoChanged(Optional<IWinLineInfo> currentWinningLineInfo) {
        if (currentWinningLineInfo.isPresent()) {
            currentLineNumber = currentWinningLineInfo.get().getLineNumber();
            currentLineScore = currentWinningLineInfo.get().getScore();
        }
    }

    private class LinesModelChangedEventObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(LinesModelChangedEvent linesModelChangedEvent) {
            handle(linesModelChangedEvent);
        }
    }
}
