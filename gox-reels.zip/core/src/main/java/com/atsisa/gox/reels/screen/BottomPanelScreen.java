package com.atsisa.gox.reels.screen;

import java.math.BigDecimal;
import java.util.Optional;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.IBetModel;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.DecreaseBetCommand;
import com.atsisa.gox.reels.command.DecreaseLinesCommand;
import com.atsisa.gox.reels.command.EnterHistoryCommand;
import com.atsisa.gox.reels.command.IncreaseBetCommand;
import com.atsisa.gox.reels.command.IncreaseLinesCommand;
import com.atsisa.gox.reels.command.SetMaxBetCommand;
import com.atsisa.gox.reels.command.SetMinBetCommand;
import com.atsisa.gox.reels.command.SkipCommand;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.command.StartAutoPlayCommand;
import com.atsisa.gox.reels.command.StopAutoPlayCommand;
import com.atsisa.gox.reels.command.TakeWinCommand;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.atsisa.gox.reels.controller.CurrentWinController;
import com.atsisa.gox.reels.controller.ICurrentWinController;
import com.atsisa.gox.reels.event.BalanceChangedEvent;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.CurrencyCodeChangedEvent;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.GamblerModelChangedEvent;
import com.atsisa.gox.reels.event.GameMessageChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;
import com.atsisa.gox.reels.message.GameMessageType;
import com.atsisa.gox.reels.model.IAccount;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * A class representing the bottom panel screen.
 */
@Reflectable
public class BottomPanelScreen extends Screen<BottomPanelScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "BottomPanelScreenLayoutId";

    /**
     * Contains total bet value.
     */
    private BigDecimal totalBet;

    /**
     * Current balance value.
     */
    private BigDecimal balance;

    /**
     * The account.
     */
    private final IAccount account;

    /**
     * The lines model mutator.
     */
    private IMutator<ILinesModel> linesModelMutator;

    /**
     * Initializes a new instance of the WrapperScreen class by setting the layout identifier and its corresponding model.
     */
    private IBetModel betModel;

    /**
     * Lines model reference.
     */
    private ILinesModel linesModel;

    /**
     * Current bottom panel state.
     */
    private String currentState;

    /**
     * Controls the current win value.
     */
    private ICurrentWinController currentWinController = new CurrentWinController();

    /**
     * Initializes a new instance of the {@link BottomPanelScreen} class.
     * @param layoutId               layout identifier
     * @param bottomPanelScreenModel {@link BottomPanelScreenModel}
     * @param renderer               {@link IRenderer}
     * @param viewManager            {@link IViewManager}
     * @param animationFactory       {@link IAnimationFactory}
     * @param logger                 {@link ILogger}
     * @param eventBus               {@link IEventBus}
     * @param account                {@link IAccount}
     * @param linesModelMutator      the lines model mutator
     */
    @Inject
    public BottomPanelScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel, IRenderer renderer,
            IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IAccount account,
            IMutator<ILinesModel> linesModelMutator) {
        super(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger, eventBus);
        this.account = account;
        this.linesModelMutator = linesModelMutator;
    }

    /**
     * Sets the current win controller.
     * @param currentWinController {@link ICurrentWinController}
     */
    @Inject(optional = true)
    public void setCurrentWinController(ICurrentWinController currentWinController) {
        this.currentWinController = currentWinController;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new BalanceChangedEventObserver(), BalanceChangedEvent.class);
        getEventBus().register(new CurrencyCodeChangedEventObserver(), CurrencyCodeChangedEvent.class);
        getEventBus().register(new GamblerModelChangedEventObserver(), GamblerModelChangedEvent.class);
        getEventBus().register(new BetModelChangedEventObserver(), BetModelChangedEvent.class);
        getEventBus().register(new LinesModelChangedEventObserver(), LinesModelChangedEvent.class);
        getEventBus().register(new GameMessageChangedEventObserver(), GameMessageChangedEvent.class);
        getEventBus().register(new PresentationStateChangedEventObserver(), PresentationStateChangedEvent.class);
        getEventBus().register(new TransferCreditsCommandObserver(), TransferCreditsCommand.class);
    }

    /**
     * Updates remaining credits according to the balance events.
     * @param balanceChangedEvent {@link BalanceChangedEvent}
     */
    @Subscribe
    public void handleBalanceChangedEvent(BalanceChangedEvent balanceChangedEvent) {
        balance = balanceChangedEvent.getBalance();
        updateProperties();
    }

    /**
     * Updates info about currency.
     * @param currencyCodeChangedEvent {@link CurrencyCodeChangedEvent}
     */
    @Subscribe
    public void handleCurrencyCodeChangedEvent(CurrencyCodeChangedEvent currencyCodeChangedEvent) {
        updateProperties();
    }

    /**
     * Gets the current win controller.
     * @return the current win controller
     */
    protected ICurrentWinController getCurrentWinController() {
        return currentWinController;
    }

    /**
     * Updates the model properties.
     */
    protected void updateProperties() {
        updateTotalBet();
        updateCredits();
        updateWin();
        getModel().update();
    }

    /**
     * Updates the win field.
     */
    protected void updateWin() {
        BigDecimal currentWin = currentWinController.getCurrentWin();
        getModel().setWin(account.getCreditsFormatter().formatWithCurrency(currentWin));
    }

    /**
     * Updates a win value according to recent gambler model changes.
     * @param gamblerModelChangedEvent GamblerModelChangedEvent
     */
    @Subscribe
    public void handleGamblerModelChangedEvent(GamblerModelChangedEvent gamblerModelChangedEvent) {
        BigDecimal gamblerAmount = gamblerModelChangedEvent.getGamblerModel().getBidAmount();
        if (gamblerAmount == null || gamblerAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }
        currentWinController.setCurrentWin(gamblerModelChangedEvent.getGamblerModel().getWonAmount());
        updateProperties();
    }

    /**
     * Updates a bet value according to recent bet model changes.
     * @param betModelChangedEvent {@link BetModelChangedEvent}
     */
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        betModel = betModelChangedEvent.getBetModel();
        totalBet = betModel.getTotalBet();
        getModel().setBet(betModel.getBetPerLine());
        updateProperties();
    }

    /**
     * Gets the bet model.
     * @return the bet model
     */
    protected IBetModel getBetModel() {
        return betModel;
    }

    /**
     * Gets the lines model.
     * @return the lines model
     */
    protected ILinesModel getLinesModel() {
        return linesModel;
    }

    /**
     * Updates the total bet value.
     */
    protected void updateTotalBet() {
        if (totalBet != null) {
            getModel().setTotalBet(account.getCreditsFormatter().formatWithCurrency(totalBet));
        }
    }

    /**
     * Updates the credits value.
     */
    protected void updateCredits() {
        if (balance != null) {
            getModel().setCredits(account.getCreditsFormatter().formatWithCurrency(balance));
        }
    }

    /**
     * Updates a number of active lines according to recent lines model changes.
     * @param linesModelChangedEvent {@link LinesModelChangedEvent}
     */
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        linesModel = linesModelMutator.mutate(linesModelChangedEvent.getLinesModel());
        if (linesModelChangedEvent.hasAvailableLinesChanged() || linesModelChangedEvent.hasSelectedLinesChanged()) {
            getModel().setLine(linesModel.getSelectedLines());
            updateProperties();
        } else if (linesModelChangedEvent.hasCurrentWinningLineChanged()) {
            winLineInfoChanged(linesModel.getCurrentWinningLine());
        }
    }

    /**
     * Called when the win line info was changed.
     * @param winLineInfo {@link IWinLineInfo}
     */
    private void winLineInfoChanged(Optional<IWinLineInfo> winLineInfo) {
        if (winLineInfo.isPresent()) {
            currentWinController.increase(winLineInfo.get());
        } else {
            for (IWinLineInfo winningLine : linesModel.getWinningLines()) {
                currentWinController.increase(winningLine);
            }
        }
        updateProperties();
    }

    /**
     * Updates a bottom panel message according to recently published value.
     * @param gameMessageChangedEvent {@link GameMessageChangedEvent}
     */
    @Subscribe
    public void handleGameMessageChangedEvent(GameMessageChangedEvent gameMessageChangedEvent) {
        if (gameMessageChangedEvent.getMessage().getMessageType() == GameMessageType.BOTTOM_PANEL) {
            getModel().setMessage(gameMessageChangedEvent.getMessage().getContent());
        }
    }

    /**
     * Called when a number of lines should be increased.
     */
    @ExposeMethod
    public void increaseLines() {
        getEventBus().post(new IncreaseLinesCommand(true));
    }

    /**
     * Called when a number of lines should be decreased.
     */
    @ExposeMethod
    public void decreaseLines() {
        getEventBus().post(new DecreaseLinesCommand(true));
    }

    /**
     * Called when bet should be increased.
     */
    @ExposeMethod
    public void increaseBet() {
        if (betModel.getBetPerLine().compareTo(betModel.getMaxBet()) < 0) {
            getEventBus().post(new IncreaseBetCommand(true));
        } else {
            setMinBet();
        }
    }

    /**
     * Called when bet should be decreased.
     */
    @ExposeMethod
    public void decreaseBet() {
        getEventBus().post(new DecreaseBetCommand(true));
    }

    /**
     * Called when bet should be increased to possible max value.
     */
    @ExposeMethod
    public void setMaxBet() {
        getEventBus().post(new SetMaxBetCommand(true));
    }

    /**
     * Called when bet should decreased to possible minimum value.
     */
    @ExposeMethod
    public void setMinBet() {
        getEventBus().post(new SetMinBetCommand(true));
    }

    /**
     * Called when spin should be invoked.
     */
    @ExposeMethod
    public void spin() {
        getEventBus().post(new SpinCommand());
    }

    /**
     * Called when skip should be invoked.
     */
    @ExposeMethod
    public void skip() {
        getEventBus().post(new SkipCommand());
    }

    /**
     * Called when take should be invoked.
     */
    @ExposeMethod
    public void takeWin() {
        getEventBus().post(new TakeWinCommand());
    }

    /**
     * Called when auto play should be started.
     */
    @ExposeMethod
    public void startAutoPlay() {
        getEventBus().post(new StartAutoPlayCommand(true));
    }

    /**
     * Called when auto play should be stopped.
     */
    @ExposeMethod
    public void stopAutoPlay() {
        getEventBus().post(new StopAutoPlayCommand(true));
    }

    /**
     * Called when black button/card will be selected.
     */
    @ExposeMethod
    public void gamblerBlackSelected() {
        getEventBus().post(new GamblerCardSelectedEvent(CardType.BLACK));
    }

    /**
     * Called when red button/card will be selected.
     */
    @ExposeMethod
    public void gamblerRedSelected() {
        getEventBus().post(new GamblerCardSelectedEvent(CardType.RED));
    }

    /**
     * Called when enter into history request should be invoked.
     */
    @ExposeMethod
    public void enterHistory() {
        getEventBus().post(new EnterHistoryCommand());
    }

    /**
     * Changes the current state.
     * @param state {@link String}
     */
    public void changeState(String state) {
        if (state == null || state.equals(currentState)) {
            return;
        }
        currentState = state;
        stateChanged();
    }

    /**
     * Handles the bottom panel state changes.
     * @param presentationStateChangedEvent {@link PresentationStateChangedEvent}
     */
    @Subscribe
    public void handlePresentationStateChangedEvent(PresentationStateChangedEvent presentationStateChangedEvent) {
        String state = presentationStateChangedEvent.getStateName();
        if (state == null || state.isEmpty()) {
            return;
        }
        changeState(state);
    }

    /**
     * Handles the information about transfer credits.
     * @param transferCreditsCommand {@link TransferCreditsCommand}
     */
    @Subscribe
    public void handleTransferCreditsCommand(TransferCreditsCommand transferCreditsCommand) {
        if (currentWinController.getCurrentWin().compareTo(BigDecimal.ZERO) > 0) {
            currentWinController.decrease(transferCreditsCommand.getAmount());
        }
    }

    /**
     * Called when current state will be changed.
     */
    protected void stateChanged() {
        switch (getCurrentState()) {
            case ReelsPresentationStates.RUNNING_REELS:
            case ReelsPresentationStates.HISTORY:
                currentWinController.clear();
                break;
            default:
                break;
        }
    }

    /**
     * Returns the current bottom panel screen state.
     * @return the current bottom panel screen state
     */
    public String getCurrentState() {
        return currentState;
    }

    private class BalanceChangedEventObserver extends NextObserver<BalanceChangedEvent> {

        @Override
        public void onNext(final BalanceChangedEvent balanceChangedEvent) {
            handleBalanceChangedEvent(balanceChangedEvent);
        }
    }

    private class CurrencyCodeChangedEventObserver extends NextObserver<CurrencyCodeChangedEvent> {

        @Override
        public void onNext(final CurrencyCodeChangedEvent currencyCodeChangedEvent) {
            handleCurrencyCodeChangedEvent(currencyCodeChangedEvent);
        }
    }

    private class GamblerModelChangedEventObserver extends NextObserver<GamblerModelChangedEvent> {

        @Override
        public void onNext(final GamblerModelChangedEvent gamblerModelChangedEvent) {
            handleGamblerModelChangedEvent(gamblerModelChangedEvent);
        }
    }

    private class BetModelChangedEventObserver extends NextObserver<BetModelChangedEvent> {

        @Override
        public void onNext(final BetModelChangedEvent betModelChangedEvent) {
            handleBetModelChangedEvent(betModelChangedEvent);
        }
    }

    private class LinesModelChangedEventObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(final LinesModelChangedEvent linesModelChangedEvent) {
            handleLinesModelChangedEvent(linesModelChangedEvent);
        }
    }

    private class GameMessageChangedEventObserver extends NextObserver<GameMessageChangedEvent> {

        @Override
        public void onNext(final GameMessageChangedEvent gameMessageChangedEvent) {
            handleGameMessageChangedEvent(gameMessageChangedEvent);
        }
    }

    private class PresentationStateChangedEventObserver extends NextObserver<PresentationStateChangedEvent> {

        @Override
        public void onNext(final PresentationStateChangedEvent presentationStateChangedEvent) {
            handlePresentationStateChangedEvent(presentationStateChangedEvent);
        }
    }

    private class TransferCreditsCommandObserver extends NextObserver<TransferCreditsCommand> {

        @Override
        public void onNext(final TransferCreditsCommand transferCreditsCommand) {
            handleTransferCreditsCommand(transferCreditsCommand);
        }
    }

}
