package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when skip button has been clicked.
 */
@Reflectable
public final class SkipCommand {

}
