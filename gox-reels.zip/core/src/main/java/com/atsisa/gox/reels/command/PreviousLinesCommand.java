package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;

/**
 * A request for previous lines value.
 */
public class PreviousLinesCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link UserInteractionCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public PreviousLinesCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
