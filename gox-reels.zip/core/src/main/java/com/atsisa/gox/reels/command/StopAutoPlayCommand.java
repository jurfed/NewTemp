package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request to stop auto play.
 */
@Reflectable
public class StopAutoPlayCommand extends UserInteractionCommand {

    /**
     * Creates a new instance of the {@link StopAutoPlayCommand} class.
     * @param triggeredByUser a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public StopAutoPlayCommand(boolean triggeredByUser) {
        super(triggeredByUser);
    }
}
