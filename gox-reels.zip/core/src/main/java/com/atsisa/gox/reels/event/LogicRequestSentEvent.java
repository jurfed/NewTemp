package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when request to the logic has been sent.
 */
@Reflectable
public class LogicRequestSentEvent {
}
