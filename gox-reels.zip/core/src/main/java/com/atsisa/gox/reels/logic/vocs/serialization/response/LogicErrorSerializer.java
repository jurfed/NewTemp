package com.atsisa.gox.reels.logic.vocs.serialization.response;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.GameLogicException;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for game errors.
 */
public class LogicErrorSerializer implements ISerializer<XmlObject, GameLogicException> {

    /**
     * Xml tag name with the error message.
     */
    private static final String EL = "el";

    /**
     * Xml tag name with the error code.
     */
    private static final String EC = "ec";

    /**
     * Xml tag name with the error details.
     */
    private static final String EM = "em";

    @Override
    public GameLogicException serialize(XmlObject xmlObject) throws SerializationException {
        XmlObject errorElem = xmlObject.findOne("/nrgs/e");
        if (errorElem != null) {
            int errorCode = -1;
            String message = null;
            String details = null;
            for (XmlObject errorInnerElem : errorElem.getChildren()) {
                switch (errorInnerElem.getName()) {
                    case EL:
                        message = errorInnerElem.getValue();
                        break;
                    case EC:
                        errorCode = Integer.parseInt(errorInnerElem.getValue());
                        break;
                    case EM:
                        details = errorInnerElem.getValue();
                        break;
                }
            }
            return new GameLogicException(errorCode, message, details);
        }
        XmlObject otherErrorElem = xmlObject.findOne("/nrgs/error");
        if (otherErrorElem != null) {
            throw new GameLogicException(-1, otherErrorElem.getValue(), null);
        }
        throw new SerializationException("Cannot deserialize presentation");
    }

}
