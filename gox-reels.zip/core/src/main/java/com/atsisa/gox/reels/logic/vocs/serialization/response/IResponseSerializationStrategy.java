package com.atsisa.gox.reels.logic.vocs.serialization.response;

import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serialization strategy for responses.
 */
public interface IResponseSerializationStrategy<T> extends ISerializer<XmlObject, T> {

    /**
     * Checks if specific presentation is supported by this strategy.
     * @param presentationName {@link String}
     * @param xmlObject {@link XmlObject}
     * @return a boolean value that indicates whether specific presentation is support by this strategy or not
     */
    boolean isPresentationSupported(String presentationName, XmlObject xmlObject);

}
