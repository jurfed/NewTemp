package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.view.AbstractViewModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the reel games view types which could be created declaratively using XML.
 */
@Reflect_Mini
public class ReelGamesViewModule extends AbstractViewModule {

    /**
     * Core views module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/reels/view";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerView(ReelView.class);
        registerView(ReelGroupView.class);
        registerView(SymbolView.class);
        registerView(WinLineView.class);
        registerView(GamblerCardView.class);
        registerView(ScatterWinLineView.class);
    }
}
