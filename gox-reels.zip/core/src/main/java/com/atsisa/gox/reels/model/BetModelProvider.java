package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.reels.IBetModel;
import com.atsisa.gox.reels.command.DecreaseBetCommand;
import com.atsisa.gox.reels.command.IncreaseBetCommand;
import com.atsisa.gox.reels.command.NextBetCommand;
import com.atsisa.gox.reels.command.PreviousBetCommand;
import com.atsisa.gox.reels.command.SetBetCommand;
import com.atsisa.gox.reels.command.SetMaxBetCommand;
import com.atsisa.gox.reels.command.SetMinBetCommand;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.google.inject.Inject;

/**
 * Handles all aspect of reel game bet configuration.
 */
public class BetModelProvider implements IBetModelProvider {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The bet model.
     */
    private BetModel betModel;

    /**
     * A number of selected lines.
     */
    private int selectedLines;

    /**
     * Initializes a new instance of the {@link LinesModelProvider} class using the specified event bus to subscribe and post to.
     * @param eventBus the event bus
     */
    @Inject
    public BetModelProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        betModel = new BetModel();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new ReelGamePresentationObserver(), ReelGamePresentation.class);
        eventBus.register(new IncreaseBetObserver(), IncreaseBetCommand.class);
        eventBus.register(new DecreaseBetObserver(), DecreaseBetCommand.class);
        eventBus.register(new LinesModelObserver(), LinesModelChangedEvent.class);
        eventBus.register(new SetBetObserver(), SetBetCommand.class);
        eventBus.register(new SetMinBetObserver(), SetMinBetCommand.class);
        eventBus.register(new SetMaxBetObserver(), SetMaxBetCommand.class);
        eventBus.register(new NextBetObserver(), NextBetCommand.class);
        eventBus.register(new PreviousBetObserver(), PreviousBetCommand.class);
    }

    /**
     * Updates the bet model according to given init response.
     * @param initResult {@link InitResult}
     */
    @Subscribe
    public void handleInitResult(InitResult initResult) {
        betModel.setBetSteps(initResult.getGameConfiguration().getBetsPerLine());
        updateTotalBet();
        notifyModelChanged(initResult);
    }

    /**
     * Updates selected lines and current bet value.
     * @param presentation {@link ReelGamePresentation}
     */
    @Subscribe
    public void handleReelGamePresentation(ReelGamePresentation presentation) {
        GameplayProperties gameplayProperties = presentation.getGameplayProperties();
        if (gameplayProperties.getLinesAmount() != selectedLines | betModel.setCurrentBet(gameplayProperties.getBetAmount())) {
            selectedLines = gameplayProperties.getLinesAmount();
            updateTotalBet();
            notifyModelChanged(presentation);
        }
    }

    /**
     * Increases the current bet value if possible.
     * @param increaseBetCommand {@link IncreaseBetCommand}
     */
    @Subscribe
    public void handleIncreaseBetCommand(IncreaseBetCommand increaseBetCommand) {
        if (betModel != null && betModel.increaseCurrentBet()) {
            updateTotalBet();
            notifyModelChanged(increaseBetCommand);
        }
    }

    /**
     * Sets bet to given value.
     * @param setBetCommand {@link SetBetCommand}
     */
    @Subscribe
    public void handleSetBetCommand(SetBetCommand setBetCommand) {
        betModel.setCurrentBet(setBetCommand.getValue());
        updateTotalBet();
        notifyModelChanged(setBetCommand);
    }

    /**
     * Sets bet to maximum value.
     * @param maxBetCommand {@link SetMaxBetCommand}
     */
    @Subscribe
    public void handleSetMaxBetCommand(SetMaxBetCommand maxBetCommand) {
        if (betModel != null && betModel.increaseBetToMax()) {
            updateTotalBet();
            notifyModelChanged(maxBetCommand);
        }
    }

    /**
     * Sets bet to minimum value.
     * @param minBetCommand {@link SetMinBetCommand}
     */
    @Subscribe
    public void handleSetMinBetCommand(SetMinBetCommand minBetCommand) {
        if (betModel != null && betModel.decreaseBetToMin()) {
            updateTotalBet();
            notifyModelChanged(minBetCommand);
        }
    }

    /**
     * Updates the total bet value.
     * @param linesModelChangedEvent - LinesModelChangedEvent
     */
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        int selectedLinesInLinesModel = linesModelChangedEvent.getLinesModel().getSelectedLines();
        if (betModel == null || selectedLines == selectedLinesInLinesModel) {
            return;
        }
        selectedLines = selectedLinesInLinesModel;
        updateTotalBet();
        notifyModelChanged(linesModelChangedEvent);
    }

    /**
     * Decreases the current bet if possible.
     * @param decreaseBetCommand - DecreaseBetCommand
     */
    @Subscribe
    public void handleDecreaseBetCommand(DecreaseBetCommand decreaseBetCommand) {
        if (betModel != null && betModel.decreaseCurrentBet()) {
            updateTotalBet();
            notifyModelChanged(decreaseBetCommand);
        }
    }

    /**
     * Increases current bet value. When current bet reaches the limit, the minimal bet values will be set.
     * @param nextBetCommand - NextBetCommand
     */
    @Subscribe
    public void handleNextBetCommand(NextBetCommand nextBetCommand) {
        if (betModel == null) {
            return;
        }
        if ((betModel.getBetPerLine().equals(betModel.getMaxBet()))) {
            betModel.setCurrentBet(betModel.getBetSteps().get(0));
        } else {
            betModel.increaseCurrentBet();
        }
        updateTotalBet();
        notifyModelChanged(nextBetCommand);

    }

    /**
     * Decreases current bet value. When current bet reaches the limit, the maximal bet value will be set.
     * @param previousBetCommand - PreviousBetCommand
     */
    @Subscribe
    public void handlePreviousBetCommand(PreviousBetCommand previousBetCommand) {
        if (betModel == null) {
            return;
        }
        if (betModel.getBetPerLine().equals(betModel.getMinBet())) {
            betModel.increaseBetToMax();
        } else {
            betModel.decreaseCurrentBet();
        }
        updateTotalBet();
        notifyModelChanged(previousBetCommand);
    }

    /**
     * Updates total bet value in model.
     */
    private void updateTotalBet() {
        if (betModel.getBetPerLine() == null) {
            return;
        }
        betModel.setTotalBet(betModel.getBetPerLine().multiply(BigDecimal.valueOf(selectedLines)));
    }

    /**
     * Publishes an event regarding bet model changes.
     * @param sourceEvent The source message which changed
     */
    private void notifyModelChanged(Object sourceEvent) {
        BetModelChangedEvent event = new BetModelChangedEvent(betModel);
        event.setSourceEvent(sourceEvent);
        eventBus.post(event);
    }

    @Override
    public IBetModel getBetModel() {
        return betModel;
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult result) {
            handleInitResult(result);
        }
    }

    private class ReelGamePresentationObserver extends NextObserver<ReelGamePresentation> {

        @Override
        public void onNext(ReelGamePresentation reelGamePresentation) {
            handleReelGamePresentation(reelGamePresentation);
        }
    }

    private class IncreaseBetObserver extends NextObserver<IncreaseBetCommand> {

        @Override
        public void onNext(IncreaseBetCommand item) {
            handleIncreaseBetCommand(item);
        }
    }

    private class SetBetObserver extends NextObserver<SetBetCommand> {

        @Override
        public void onNext(SetBetCommand item) {
            handleSetBetCommand(item);
        }
    }

    private class SetMaxBetObserver extends NextObserver<SetMaxBetCommand> {

        @Override
        public void onNext(SetMaxBetCommand item) {
            handleSetMaxBetCommand(item);
        }
    }

    private class SetMinBetObserver extends NextObserver<SetMinBetCommand> {

        @Override
        public void onNext(SetMinBetCommand item) {
            handleSetMinBetCommand(item);
        }
    }

    private class DecreaseBetObserver extends NextObserver<DecreaseBetCommand> {

        @Override
        public void onNext(DecreaseBetCommand item) {
            handleDecreaseBetCommand(item);
        }
    }

    private class LinesModelObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(LinesModelChangedEvent item) {
            handleLinesModelChangedEvent(item);
        }
    }

    private class NextBetObserver extends NextObserver<NextBetCommand> {

        @Override
        public void onNext(NextBetCommand item) {
            handleNextBetCommand(item);
        }
    }

    private class PreviousBetObserver extends NextObserver<PreviousBetCommand> {

        @Override
        public void onNext(PreviousBetCommand item) {
            handlePreviousBetCommand(item);
        }
    }
}
