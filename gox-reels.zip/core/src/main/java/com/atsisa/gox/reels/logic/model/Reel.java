package com.atsisa.gox.reels.logic.model;

import java.util.List;

/**
 * Represents a single reel.
 */
public class Reel {

    /**
     * The sound of reel stop.
     */
    private final String soundName;

    /**
     * The array of symbol ids.
     */
    private final List<Integer> positions;

    /**
     * Initializes a new instance of the {@link Reel} class.
     * @param soundName a sound of reel stop
     * @param positions an array of symbol ids
     */
    public Reel(String soundName, List<Integer> positions) {
        this.soundName = soundName;
        this.positions = positions;
    }

    /**
     * Gets a sound of reel stop.
     * @return a sound of reel stop
     */
    public String getSoundName() {
        return soundName;
    }

    /**
     * Gets an array of symbol ids.
     * @return an array of symbol ids
     */
    public List<Integer> getPositions() {
        return positions;
    }
}
