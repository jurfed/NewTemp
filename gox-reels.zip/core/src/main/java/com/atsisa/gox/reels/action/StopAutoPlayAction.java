package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.StopAutoPlayCommand;

/**
 * Sends command to stop auto play.
 */
public class StopAutoPlayAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link StopAutoPlayAction}.
     */
    public StopAutoPlayAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link StopAutoPlayAction} using custom logger and event bus.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public StopAutoPlayAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new StopAutoPlayCommand(false));
    }
}
