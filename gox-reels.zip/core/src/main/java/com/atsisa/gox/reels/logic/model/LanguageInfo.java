package com.atsisa.gox.reels.logic.model;

import java.util.List;

/**
 * Represents an information about language.
 */
public class LanguageInfo {

    /**
     * The active language.
     */
    private final Language activeLanguage;

    /**
     * The array of available language codes.
     */
    private final List<String> availableLanguageCodes;

    /**
     * Initializes a new instance of the {@link LanguageInfo} class.
     * @param activeLanguage         a active language
     * @param availableLanguageCodes an array of available language codes
     */
    public LanguageInfo(Language activeLanguage, List<String> availableLanguageCodes) {
        this.activeLanguage = activeLanguage;
        this.availableLanguageCodes = availableLanguageCodes;
    }

    /**
     * Gets an array of available language codes.
     * @return an array of available language codes
     */
    public List<String> getAvailableLanguageCodes() {
        return availableLanguageCodes;
    }

    /**
     * Gets an active language.
     * @return an active language.
     */
    public Language getActiveLanguage() {
        return activeLanguage;
    }
}
