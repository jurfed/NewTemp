package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Executes given action if auto play is checked.
 */
@Reflect_Mini
public class ExecuteNextDependingOnAutoPlayAction extends ExecuteNextAction {

    @Override
    protected void execute() {
        allowFurtherProcessing();

        if (((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder().isAutoPlay()) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }
}
