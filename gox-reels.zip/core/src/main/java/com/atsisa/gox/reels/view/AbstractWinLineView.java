package com.atsisa.gox.reels.view;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.ICaption;
import com.atsisa.gox.framework.utility.Rectangle;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.view.DefaultViewActivator;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.framework.view.ViewGroupBase;
import com.atsisa.gox.framework.view.spi.IViewActivator;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.state.WinLineState;

import rx.functions.Action2;

/**
 * An abstract win line view class that extends {@link ViewGroup} and implements {@link IWinLine} interface.
 */
public abstract class AbstractWinLineView extends ViewGroup implements IWinLine {

    /**
     * The frame tag.
     */
    protected static final String FRAME_TAG = "frame";

    /**
     * The score tag.
     */
    protected static final String SCORE_TAG = "score";

    /**
     * The length factor.
     */
    private static final int LENGTH_FACTOR = 2;

    /**
     * A view activator.
     */
    private IViewActivator viewActivator;

    /**
     * The win line description model.
     */
    private IWinLineInfo winLineInfo;

    /**
     * The win score.
     */
    private String winScore;

    /**
     * Frame views.
     */
    private List<View> frameViews;

    /**
     * Score views.
     */
    private List<View> scoreViews;

    /**
     * Frame data objects.
     */
    private List<IBound> frameDataObjects;

    /**
     * Score data objects.
     */
    private List<ICaption> scoreDataObjects;

    /**
     * A line number property.
     */
    @XmlAttribute(type = Integer.class)
    private final ObservableProperty<Integer> lineNumber = new ObservableProperty<>(Integer.class, 0);

    /**
     * A win line state property.
     */
    @XmlAttribute(type = WinLineState.class)
    private final ObservableProperty<WinLineState> state = new ObservableProperty<>(WinLineState.class, WinLineState.INACTIVE);

    /**
     * Initializes a new instance of the {@link AbstractWinLineView} class.
     * @param renderer {@link IRenderer}
     */
    public AbstractWinLineView(IRenderer renderer) {
        super(renderer);
        viewActivator = new DefaultViewActivator();
        frameViews = new LinkedList<>();
        frameDataObjects = new LinkedList<>();
        scoreViews = new LinkedList<>();
        scoreDataObjects = new LinkedList<>();
    }

    @Override
    protected void init() {
        super.init();
        deactivateChildren();
    }

    /**
     * Gets the line state property.
     * @return the line state property.
     */
    public IObservableProperty<WinLineState> state() {
        return state;
    }

    /**
     * Gets the line number property.
     * @return the line number property
     */
    public IObservableProperty<Integer> lineNumber() {
        return lineNumber;
    }

    /**
     * Gets an object responsible for toggling the state of child views to reflect
     * {@link WinLineState} changes.
     * @return A view activator object.
     */
    public IViewActivator getViewActivator() {
        return viewActivator;
    }

    /**
     * Sets an object responsible for toggling the state of child views to reflect
     * {@link WinLineState} changes.
     * @param viewActivator A view activator object.
     * @throws IllegalArgumentException The view activator is null.
     */
    public void setViewActivator(IViewActivator viewActivator) {
        if (viewActivator == null) {
            throw new IllegalArgumentException("The view activator cannot be null.");
        }
        this.viewActivator = viewActivator;
    }

    /**
     * Gets the win score.
     * @return A string with win score.
     */
    public String getWinScore() {
        return this.winScore;
    }

    @Override
    public void hideWin() {
        if (viewActivator == null) {
            throw new IllegalStateException("viewActivator has not been set");
        }
        for (View view : frameViews) {
            viewActivator.deactivate(view);
        }
        for (View scoreView : scoreViews) {
            viewActivator.deactivate(scoreView);
        }
    }

    @Override
    public WinLineState getState() {
        return state.get();
    }

    @Override
    public void setState(WinLineState state) {
        if (!this.state.set(state)) {
            return;
        }
        WinLineState oldState = getState();
        if (oldState == WinLineState.SHOWN_WINNING || state != WinLineState.SHOWN_WINNING) {
            hideWin();
        }
    }

    @Override
    public int getLineNumber() {
        return lineNumber.get();
    }

    @Override
    public void setLineNumber(int lineNumber) {
        this.lineNumber.set(lineNumber);
    }

    @Override
    public void addChild(View view) {
        processChildRecursive(view, Actions.LIST_ADD);
        super.addChild(view);
        if (isInitialized()) {
            deactivateChildren();
        }
    }

    @Override
    public boolean removeChild(View view) {
        processChildRecursive(view, Actions.LIST_REMOVE);
        return super.removeChild(view);
    }

    @Override
    public void removeAll() {
        clearResolvedViews();
        super.removeAll();
    }

    @Override
    public void dispose() {
        setState(WinLineState.INACTIVE);
        clearResolvedViews();
        super.dispose();
    }

    /**
     * Gets the list with frame data objects.
     * @return A list with frame data objects.
     */
    protected List<IBound> getFrameDataObjects() {
        return this.frameDataObjects;
    }

    /**
     * Gets a list with all frame views.
     * @return The list of all frame views.
     */
    protected List<View> getFrameViews() {
        return this.frameViews;
    }

    /**
     * Gets a list with all score views.
     * @return The list of all score views.
     */
    protected List<View> getScoreViews() {
        return this.scoreViews;
    }

    /**
     * Gets a list with score boxes  responsible for toggling the state of child views to reflect
     * {@link WinLineState} changes.
     * @return A view activator object.
     */
    protected List<ICaption> getScoreDataObjects() {
        return this.scoreDataObjects;
    }

    /**
     * Sets the win line info model.
     * @param winLineInfo {@link IWinLineInfo}
     */
    protected void setWinLineInfo(IWinLineInfo winLineInfo) {
        this.winLineInfo = winLineInfo;
    }

    /**
     * Gets the win line info model.
     * @return A win line info model.
     */
    protected IWinLineInfo getWinLineInfo() {
        return this.winLineInfo;
    }

    @Override
    public void updateWinScore(String score) {
        if (StringUtility.equals(this.winScore, score)) {
            return;
        }
        this.winScore = score;
        if (getState() == WinLineState.SHOWN_WINNING) {
            showScore(score);
        }
    }

    /**
     * Returns bounds of winning frames which defines positions where score
     * boxes should be placed.
     * <p>
     * One instance of bound is used to place one score box.
     * The implementation of placing score box to frame has to be done
     * in inherited class.
     * </p>
     * @return The list of bounds defined by the winning frames.
     */
    protected abstract List<IBound> getWinningFramesBounds();

    /**
     * Clears all resolved views.
     */
    protected void clearResolvedViews() {
        scoreViews.clear();
        scoreDataObjects.clear();
        frameViews.clear();
        frameDataObjects.clear();
    }

    /**
     * Toggles given view's activity.
     * @param view   The view to toggle.
     * @param active True if the view should be activated, false otherwise.
     */
    protected void toggleView(View view, boolean active) {
        if (active) {
            viewActivator.activate(view);
        } else {
            viewActivator.deactivate(view);
        }
    }

    /**
     * Shows the score on winning line.
     * <p>
     * Depending how many score views are defined each score box is applied
     * in sequence to next frame view position.
     * </p>
     * @param score The line score.
     */
    protected void showScore(String score) {
        for (ICaption scoreDataObject : scoreDataObjects) {
            scoreDataObject.setText(score);
        }

        List<IBound> bounds = getWinningFramesBounds();
        int boundsIndex = 0;
        IBound currentBound;
        for (View scoreView : scoreViews) {
            boolean hasBound = boundsIndex < bounds.size();
            if (hasBound) {
                currentBound = bounds.get(boundsIndex++);
                repositionScoreView(scoreView, currentBound);
            }
            toggleView(scoreView, hasBound);
        }
    }

    /**
     * Repositions the score views.
     * @param scoreView    Score views.
     * @param currentBound Bounds
     */
    protected void repositionScoreView(View scoreView, IBound currentBound) {
        Rectangle boundaries = currentBound.getBoundaries();
        float x = boundaries.getX() + (boundaries.getWidth() - scoreView.getOffsetWidth()) / LENGTH_FACTOR;
        float y = boundaries.getY() - scoreView.getOffsetHeight() / LENGTH_FACTOR;
        scoreView.setX(x);
        scoreView.setY(y);
    }

    /**
     * Sets children visibility to <code>false</code>
     */
    protected void deactivateChildren() {
        for (View child : getChildrenRaw()) {
            viewActivator.deactivate(child);
        }
    }

    /**
     * Recursively processes a child during addition or removal to extract all required elements.
     * @param view   The child to process.
     * @param action The collection action regarding matching child.
     */
    protected void processChildRecursive(View view, Action2<List, Object> action) {
        processChildRecursive(view, action, new HashSet<>());
    }

    /**
     * Recursively processes a child during addition or removal to extract all required elements.
     * @param view                The child to process.
     * @param action              The collection action regarding matching child.
     * @param parentProcessedTags A set of tags processed by parents.
     */
    protected void processChildRecursive(View view, Action2<List, Object> action, Set<String> parentProcessedTags) {
        if (view.hasTag(FRAME_TAG)) {
            if (!parentProcessedTags.contains(FRAME_TAG)) {
                action.call(getFrameViews(), view);
                parentProcessedTags.add(FRAME_TAG);
            }
            if (view instanceof IBound) {
                action.call(getFrameDataObjects(), view);
            }
        } else if (view.hasTag(SCORE_TAG)) {
            if (!parentProcessedTags.contains(SCORE_TAG)) {
                action.call(getScoreViews(), view);
                parentProcessedTags.add(SCORE_TAG);
            }
            if (view instanceof ICaption) {
                action.call(getScoreDataObjects(), view);
            }
        }
        if (view instanceof ViewGroupBase) {
            for (View child : ((ViewGroupBase) view).getChildrenRaw()) {
                processChildRecursive(child, action, parentProcessedTags);
            }
        }
    }

    /**
     * Common actions container.
     */
    private static class Actions {

        /**
         * List addition action.
         */
        public static final Action2<List, Object> LIST_ADD = List::add;

        /**
         * List removal action.
         */
        public static final Action2<List, Object> LIST_REMOVE = List::remove;

        /**
         * Protects against creation of new instance of this class.
         */
        private Actions() {
        }
    }

}
