package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when specific reel began stopping.
 */
@Reflectable
public class ReelStoppingEvent {

    /**
     * Reel index position.
     */
    private int reelIndex;

    /**
     * Initializes a new instance of the {@link ReelsStoppedEvent} class.
     * @param reelIndex reel index position
     */
    public ReelStoppingEvent(int reelIndex) {
        this.reelIndex = reelIndex;
    }

    /**
     * Gets reel index position, which begins to stop.
     * @return index position
     */
    public int getReelIndex() {
        return reelIndex;
    }
}
