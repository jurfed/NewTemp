package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ChangeGameMessageCommand;

/**
 * Requests a change of a certain message area.
 */
public class UpdateMessageAreaAction extends SyncAction<UpdateMessageAreaActionData> {

    /**
     * Initializes a new instance of the {@link UpdateMessageAreaAction} class.
     */
    public UpdateMessageAreaAction() {
    }

    /**
     * Initializes a new instance of the {@link UpdateMessageAreaAction} class.
     * @param logger   a logger reference.
     * @param eventBus an eventBus reference.
     */
    public UpdateMessageAreaAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new ChangeGameMessageCommand(actionData.getMessage(), actionData.getMessageType()));
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData == null || actionData.getMessage() == null) {
            throw new ValidationException("The UpdateMessageArea message property must be set");
        }
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return UpdateMessageAreaActionData.class;
    }
}
