package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Used to serialize history requests.
 */
public class HistoryRequestSerializer implements ISerializer<HistoryRequest, XmlObject> {

    @Override
    public XmlObject serialize(HistoryRequest request) {
        XmlObject xmlObject = InitRequestSerializer.createBasicXmlDescription(request.getGameIdentity(), request.getLanguageCode());
        XmlObject historyInfo = new XmlBuilder().startElement("h").writeValue(request.getPageNumber()).endElement().toXmlObject();
        xmlObject.addChildAfter(historyInfo, "req");
        return xmlObject;
    }
}
