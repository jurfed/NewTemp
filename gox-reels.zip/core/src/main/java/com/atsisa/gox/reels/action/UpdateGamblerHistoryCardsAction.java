package com.atsisa.gox.reels.action;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.UpdateGamblerHistoryCardsCommand;
import com.atsisa.gox.reels.event.HistoryGamblerCardsUpdatedEvent;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.model.GamblerCardType;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.atsisa.gox.reels.model.IGamblerModelProvider;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

/**
 * Requests a update gambler history cards.
 */
public class UpdateGamblerHistoryCardsAction extends WaitForEventAction<HistoryGamblerCardsUpdatedEvent> {

    /**
     * Gambler model provider reference.
     */
    private final IGamblerModelProvider gamblerModelProvider;

    /**
     * Gambler history cards to update.
     */
    private final List<String> gamblerHistoryCards;

    /**
     * Reel game state holder.
     */
    private IReelGameStateHolder reelGameStateHolder;

    /**
     * Initializes a new instance of the {@link UpdateGamblerHistoryCardsAction} class.
     */
    public UpdateGamblerHistoryCardsAction() {
        gamblerModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getGamblerModelProvider();
        gamblerHistoryCards = new ObjectArrayList<>();
        reelGameStateHolder = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder();
    }

    /**
     * Initializes a new instance of the {@link UpdateGamblerHistoryCardsAction} class using custom gambler model
     * provider.
     * @param logger               a logger reference
     * @param eventBus             an eventBus reference
     * @param gamblerModelProvider a gambler model provider
     * @param reelGameStateHolder  a reel game state holder
     */
    public UpdateGamblerHistoryCardsAction(ILogger logger, IEventBus eventBus, IGamblerModelProvider gamblerModelProvider, IReelGameStateHolder reelGameStateHolder) {
        super(logger, eventBus);
        this.gamblerModelProvider = gamblerModelProvider;
        gamblerHistoryCards = new ObjectArrayList<>();
        this.reelGameStateHolder = reelGameStateHolder;
    }

    @Override
    protected void grabData() {
        gamblerHistoryCards.add(GamblerCardType.NONE);
        IGamblerModel gamblerModel = gamblerModelProvider.getGamblerModel();
        Iterable<String> gamblerModelCards = gamblerModel.getGamblerHistory();

        int index = 0;
        for (String cardName : gamblerModelCards) {
            index++;
            if (index == 1 && reelGameStateHolder.isHistoryMode() && gamblerModel.getGamblerHistorySize() > 0) {
                continue;
            }
            gamblerHistoryCards.add(cardName);
        }

        int leftCardsToAdd = gamblerModel.getTotalCardsInHistory() - gamblerHistoryCards.size();
        for (int i = 0; i < leftCardsToAdd; ++i) {
            gamblerHistoryCards.add(GamblerCardType.NONE);
        }
    }

    @Override
    protected void reset() {
        super.reset();
        gamblerHistoryCards.clear();
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new UpdateGamblerHistoryCardsCommand(gamblerHistoryCards));
    }

    @Override
    protected Class<HistoryGamblerCardsUpdatedEvent> getEventClass() {
        return HistoryGamblerCardsUpdatedEvent.class;
    }
}
