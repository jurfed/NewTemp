package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.atsisa.gox.reels.logic.HistoryResult;
import com.atsisa.gox.reels.logic.IReelGameHistoryLogic;
import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.model.IHistoryModel;
import com.atsisa.gox.reels.model.IHistoryModelProvider;

/**
 * Abstract action class used for sending request to show specific page in history.
 */
public abstract class AbstractHistoryPageRequestAction extends AbstractSendRequestAction {

    /**
     * Reference to the configuration provider.
     */
    private final IConfigurationProvider configurationProvider;

    /**
     * Reference to the history model provider.
     */
    private final IHistoryModelProvider historyModelProvider;

    /**
     * Name of the wrapper.
     */
    private String wrapperName;

    /**
     * Name of the language code.
     */
    private String languageCode;

    /**
     * Contains number of the history page to show.
     */
    private int historyPageNumberToShow;

    /**
     * Initializes a new instance of the {@link AbstractHistoryPageRequestAction} class.
     */
    public AbstractHistoryPageRequestAction() {
        historyModelProvider = getGame().getHistoryModelProvider();
        configurationProvider = GameEngine.current().getConfigurationProvider();
    }

    /**
     * Initializes a new instance of the {@link AbstractHistoryPageRequestAction} class.
     * @param gameEngine game engine reference
     */
    public AbstractHistoryPageRequestAction(IGameEngine gameEngine) {
        super((AbstractReelGame) gameEngine.getGame());
        historyModelProvider = getGame().getHistoryModelProvider();
        configurationProvider = gameEngine.getConfigurationProvider();
    }

    @Override
    protected void grabData() {
        super.grabData();
        historyPageNumberToShow = getHistoryPageNumberToShow();
        wrapperName = getPropertyValue(ReelConfigurationConstants.WRAPPER_NAME);
        languageCode = getPropertyValue(ReelConfigurationConstants.LANGUAGE_CODE);
    }

    @Override
    protected void validate() throws ValidationException {
        super.validate();
        if (historyPageNumberToShow < 0 || historyPageNumberToShow > getHistoryModel().getTotalNumberPages()) {
            throw new IllegalArgumentException(StringUtility
                    .format("Cannot send history request, because page number is: %s and available range is: 0-%s", historyPageNumberToShow,
                            getHistoryModel().getTotalNumberPages()));
        } else if (wrapperName == null || wrapperName.isEmpty()) {
            throw new IllegalArgumentException("Can not send history request, because wrapper name was not set in configuration");
        } else if (languageCode == null || languageCode.isEmpty()) {
            throw new IllegalArgumentException("Can not send history request, because language code was not set in configuration");
        }
    }

    /**
     * Gets reference to the history model.
     * @return history model
     */
    protected IHistoryModel getHistoryModel() {
        return historyModelProvider.getHistoryModel();
    }

    /**
     * Gets value for specific property name.
     * @param propertyName property name
     * @return property value
     */
    private String getPropertyValue(String propertyName) {
        Object propertyValue = getConfiguration().getProperty(propertyName);
        if (propertyValue != null) {
            return propertyValue.toString();
        }
        return null;
    }

    /**
     * Gets reference to the configuration.
     * @return configuration
     */
    protected IConfiguration getConfiguration() {
        return configurationProvider.getConfiguration();
    }

    /**
     * Sends a request to exit from the history.
     */
    @Override
    protected void execute() {
        subscribeForResult(((IReelGameHistoryLogic) getGameLogic()).history(new HistoryRequest(wrapperName, languageCode, historyPageNumberToShow)));
    }

    @Override
    protected void onReceiveLogicResult(Object logicResult) {
        if (!(logicResult instanceof HistoryResult)) {
            return;
        }
        if (historyPageNumberToShow == 0) {
            historyPageNumberToShow = ((HistoryResult) logicResult).getHistoryInfo().getTotalNumberPages();
        }
        ((HistoryResult) logicResult).getHistoryInfo().setPageNumber(historyPageNumberToShow);
    }

    /**
     * Gets history page number to show.
     * @return history page number to show
     */
    protected abstract int getHistoryPageNumberToShow();

}
