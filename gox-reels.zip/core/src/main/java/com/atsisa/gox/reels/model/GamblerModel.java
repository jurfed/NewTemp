package com.atsisa.gox.reels.model;

import java.math.BigDecimal;
import java.util.Arrays;

public class GamblerModel implements IGamblerModel {

    /**
     * Gambler multiplier value.
     */
    private static final BigDecimal GAMBLER_MULTIPLIER = new BigDecimal(2);

    /**
     * Maximum number of possibility cards in history.
     */
    private static final int MAX_CARDS_IN_HISTORY = 6;

    /**
     * Specified gambler play limit.
     */
    private int gamblerPlayLimit;

    /**
     * Specified gambler win limit.
     */
    private BigDecimal gamblerWinLimit = BigDecimal.ZERO;

    /**
     * Current gambler win amount.
     */
    private BigDecimal gamblerWinAmount = BigDecimal.ZERO;

    /**
     * Current gambler history size.
     */
    private int gamblerHistorySize;

    /**
     * Gambler bid amount.
     */
    private BigDecimal bidAmount = BigDecimal.ZERO;

    /**
     * Gambler won amount.
     */
    private BigDecimal wonAmount = BigDecimal.ZERO;

    /**
     * A collection of gambler history cards.
     */
    private String[] gamblerHistory;

    @Override
    public int getGamblerHistorySize() {
        return gamblerHistorySize;
    }

    @Override
    public int getTotalCardsInHistory() {
        return MAX_CARDS_IN_HISTORY;
    }

    @Override
    public Iterable<String> getGamblerHistory() {
        if (gamblerHistory == null) {
            return null;
        }
        return Arrays.asList(gamblerHistory);
    }

    @Override
    public int getGamblerPlayLimit() {
        return gamblerPlayLimit;
    }

    @Override
    public BigDecimal getGamblerWinLimit() {
        return gamblerWinLimit;
    }


    @Override
    public BigDecimal getGamblerWinAmount() {
        return gamblerWinAmount;
    }

    @Override
    public BigDecimal getBidAmount() {
        if (bidAmount == null) {
            return BigDecimal.ZERO;
        }
        return bidAmount;
    }

    @Override
    public BigDecimal getWonAmount() {
        if (wonAmount == null) {
            return BigDecimal.ZERO;
        }
        return wonAmount;
    }

    /**
     * Sets current gambler history size.
     * @param gamblerHistorySize current gambler history size
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setGamblerHistorySize(int gamblerHistorySize) {
        if (this.gamblerHistorySize != gamblerHistorySize) {
            this.gamblerHistorySize = gamblerHistorySize;
            return true;
        }
        return false;
    }

    /**
     * Sets current gambler history.
     * @param gamblerHistory current gambler history
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setGamblerHistory(String[] gamblerHistory) {
        if (gamblerHistory != null && !Arrays.equals(gamblerHistory, this.gamblerHistory)) {
            this.gamblerHistory = gamblerHistory;
            return true;
        }
        return false;
    }

    /**
     * Sets specified gambler play limit.
     * @param gamblerPlayLimit specified gambler play limit
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setGamblerPlayLimit(int gamblerPlayLimit) {
        if (gamblerPlayLimit != this.gamblerPlayLimit) {
            this.gamblerPlayLimit = gamblerPlayLimit;
            return true;
        }
        return false;
    }

    /**
     * Sets specified gambler win limit.
     * @param gamblerWinLimit specified gambler win limit
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setGamblerWinLimit(BigDecimal gamblerWinLimit) {
        if (gamblerWinLimit != null && this.gamblerWinLimit.compareTo(gamblerWinLimit) != 0) {
            this.gamblerWinLimit = gamblerWinLimit;
            updateGamblerWinAmount();
            return true;
        }
        return false;
    }

    /**
     * Sets specified gambler bid amount.
     * @param bidAmount specified gambler bid amount
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setBidAmount(BigDecimal bidAmount) {
        if (bidAmount != null && this.bidAmount.compareTo(bidAmount) != 0) {
            this.bidAmount = bidAmount;
            updateGamblerWinAmount();
            return true;
        }
        return false;
    }

    /**
     * Sets specified gambler won amount.
     * @param wonAmount specified gambler won amount
     * @return a boolean value that indicates whether this value was updated or not
     */
    boolean setWonAmount(BigDecimal wonAmount) {
        if (wonAmount != null && this.wonAmount.compareTo(wonAmount) != 0) {
            this.wonAmount = wonAmount;
            return true;
        }
        return false;
    }

    /**
     * Updates gambler win amount.
     */
    private void updateGamblerWinAmount() {
        if (bidAmount == null || gamblerWinLimit == null) {
            return;
        }
        gamblerWinAmount = bidAmount.multiply(GAMBLER_MULTIPLIER);
        if (gamblerWinLimit.signum() > 0 && gamblerWinLimit.compareTo(gamblerWinAmount) < 1) {
            gamblerWinAmount = gamblerWinLimit;
        }
    }

}
