package com.atsisa.gox.reels.controller;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.reels.ClosableListening;
import com.atsisa.gox.reels.IBetController;
import com.atsisa.gox.reels.IBetModel;
import com.atsisa.gox.reels.IBetModelListener;
import com.atsisa.gox.reels.command.*;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.model.BetModel;
import com.google.inject.Inject;

/**
 * BetController default implementation.
 */
public class BetController implements IBetController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The set of the bet model listeners.
     */
    private final Set<IBetModelListener> listeners = new HashSet<>();

    /**
     * The bet model.
     */
    private IBetModel betModel = new BetModel();

    /**
     * Creates a new instance of the {@link BetController} class.
     * @param eventBus the event bus.
     */
    @Inject
    public BetController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new BetModelChangedObserver(), BetModelChangedEvent.class);
    }

    @Override
    public IBetModel getModel() {
        return betModel;
    }

    @Override
    public synchronized void setBet(BigDecimal bet) throws IllegalArgumentException {
        if (contains(betModel.getBetSteps(), bet)) {
            eventBus.post(new SetBetCommand(bet, true));
        } else {
            throw new IllegalArgumentException("Available bets do not contain requested bet value. Requested bet: " + bet);
        }
    }

    @Override
    public synchronized void nextBet() {
        eventBus.post(new NextBetCommand(true));
    }

    @Override
    public synchronized void previousBet() {
        eventBus.post(new PreviousBetCommand(true));
    }

    @Override
    public ClosableListening addModelListener(IBetModelListener listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    /**
     * Check if acceptable bet steps contains given bet.
     * @param betSteps acceptable bet steps.
     * @param bet      given bet.
     * @return {@code true} if acceptable bet steps contains given bet.
     */
    private boolean contains(Iterable<BigDecimal> betSteps, BigDecimal bet) {
        for (BigDecimal betStep : betSteps) {
            if (bet.compareTo(betStep) == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Notify all bet model listeners.
     * @param betModel the bet model.
     */
    private void notifyListeners(IBetModel betModel) {
        for (IBetModelListener listener : listeners) {
            listener.modelChanged(betModel);
        }
    }

    private class BetModelChangedObserver extends NextObserver<BetModelChangedEvent> {

        @Override
        public void onNext(BetModelChangedEvent betModelChangedEvent) {
            betModel = betModelChangedEvent.getBetModel();
            notifyListeners(betModel);
        }
    }
}
