package com.atsisa.gox.reels.model;

import com.atsisa.gox.reels.message.GameMessage;

/**
 * Represents the configuration of error.
 */
public interface IErrorModel {

    /**
     * Gets reason for failing.
     * @return reason for failing
     */
    Throwable getCause();

    /**
     * Gets error message.
     * @return error message
     */
    GameMessage getMessage();

    /**
     * Indicates retry button should be visible or not.
     * @return {true} if retry button should be visible, otherwise {false}.
     */
    boolean isRetry();
}
