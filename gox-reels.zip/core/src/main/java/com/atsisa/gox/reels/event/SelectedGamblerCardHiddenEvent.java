package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when selected gambler card was hidden.
 */
@Reflectable
public class SelectedGamblerCardHiddenEvent {

}
