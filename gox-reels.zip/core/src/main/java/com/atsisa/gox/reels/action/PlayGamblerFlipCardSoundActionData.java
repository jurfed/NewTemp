package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Action data for {@link PlayGamblerFlipCardSoundAction} class.
 */
@XmlElement
@Reflect_Full
public class PlayGamblerFlipCardSoundActionData extends ActionData {

    /**
     * Id fo the sound.
     */
    @XmlAttribute
    private String soundId;

    /**
     * Minimum time which sound should play in milliseconds.
     */
    @XmlAttribute
    private int minSoundPlayTime;

    /**
     * Gets sound id.
     * @return sound id
     */
    public String getSoundId() {
        return soundId;
    }

    /**
     * Sets sound id.
     * @param soundId - id of the sound
     */
    public void setSoundId(String soundId) {
        this.soundId = soundId;
    }

    /**
     * Gets minimum time which sound should play.
     * @return time in milliseconds
     */
    public int getMinSoundPlayTime() {
        return minSoundPlayTime;
    }

    /**
     * Sets minimum time which sound should play.
     * @param minSoundPlayTime minimum time in milliseconds
     */
    public void setMinSoundPlayTime(int minSoundPlayTime) {
        this.minSoundPlayTime = minSoundPlayTime;
    }
}
