package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Action data for {@link StopReelsAction} class.
 */
@XmlElement
public class StopReelsActionData extends ActionData {

    /**
     * A value indicating whether the reels should be forcibly stopped.
     */
    @XmlAttribute
    private boolean forceStop;

    /**
     * Gets a value indicating whether the reels should be forcibly stopped.
     * @return A value indicating whether the reels should be forcibly stopped.
     */
    public boolean isForceStop() {
        return forceStop;
    }

    /**
     * Sets a value indicating whether the reels should be forcibly stopped.
     * @param forceStop A value indicating whether the reels should be forcibly stopped.
     */
    public void setForceStop(boolean forceStop) {
        this.forceStop = forceStop;
    }
}
