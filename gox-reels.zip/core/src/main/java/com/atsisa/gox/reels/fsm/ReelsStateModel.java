package com.atsisa.gox.reels.fsm;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.reels.logic.model.Reel;

/**
 * Contains information about current state of reels in game.
 */
class ReelsStateModel {

    /**
     * A symbol map.
     */
    private Map<Integer, String> symbolMap;

    /**
     * Contains information about last stopped symbols.
     */
    private List<Iterable<String>> stoppedSymbols;

    /**
     * Contains information about last reel states.
     */
    private List<Reel> reels;

    /**
     * Initializes reel state model.
     * @param symbols start symbols
     */
    public void initializeSymbols(Map<Integer, String> symbols) {
        symbolMap = symbols;
        updateStoppedSymbols();
    }

    /**
     * Populates model based on presentation response.
     */
    void initializeReels(List<Reel> reels) {
        this.reels = reels;
        updateStoppedSymbols();
    }

    /**
     * Updates stopped symbols based on reel states.
     */
    private void updateStoppedSymbols() {
        if (reels != null && symbolMap != null) {
            stoppedSymbols = new ArrayList<>(reels.size());
            LinkedList<String> reelStoppedSymbols;
            for (Reel reelState : reels) {
                reelStoppedSymbols = new LinkedList<>();
                for (int id : reelState.getPositions()) {
                    reelStoppedSymbols.add(symbolMap.get(id));
                }
                stoppedSymbols.add(reelStoppedSymbols);
            }
        }
    }

    /**
     * Gets information about last reel states.
     * @return List of ReelState
     */
    public List<Reel> getReels() {
        return reels;
    }

    /**
     * Gets information about last stopped symbols.
     * @return information about last stopped symbols
     */
    public List<Iterable<String>> getStoppedSymbols() {
        return stoppedSymbols;
    }

}
