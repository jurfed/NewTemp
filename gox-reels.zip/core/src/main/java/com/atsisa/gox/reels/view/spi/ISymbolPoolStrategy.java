package com.atsisa.gox.reels.view.spi;

import java.util.Map;

import com.atsisa.gox.reels.view.AbstractSymbol;

/**
 * Customizes the behavior of a symbol pool.
 */
public interface ISymbolPoolStrategy {

    /**
     * Symbol names property name.
     */
    String SYMBOL_NAMES_PROPERTY_NAME = "symbolNames";

    /**
     * Returns a pre-initialized collection of symbols
     * the pool should be populated with when created.
     * @param symbolFactory The symbol factory which should be used for the creation of symbols.
     * @return A pre-initializes collection of symbols.
     */
    Iterable<AbstractSymbol> initialize(ISymbolFactory symbolFactory);

    /**
     * When implemented, contains a policy which should be used
     * when the pool has been drained and there are no more symbols of given name left.
     * @param symbolPool The drained symbol pool.
     * @param symbolName Requested symbol name.
     * @return An additional symbol which should be added to the pool or null in case no additional symbols should be created.
     */
    AbstractSymbol getMissingSymbol(ISymbolPool symbolPool, String symbolName);

    /**
     * Initializes pool with custom data. Concrete implementation
     * should handle initialization of internal data structures on its basis.
     * @param configurationData Data containing implementation-specific configuration.
     */
    void initializeConfiguration(Map<String, Object> configurationData);
}
