package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for stop showing animations of winning symbols on reels.
 */
@Reflectable
public class StopAnimationWinningSymbolsCommand {

    /**
     * A value indicating whether the symbol animations should be stop showing immediately.
     */
    private boolean forceStop;

    /**
     * Gets a value indicating whether the symbol animations should be stop showing immediately.
     * @return A value indicating whether the symbol animations should be stop showing immediately.
     */
    public boolean isForceStop() {
        return forceStop;
    }

    /**
     * Sets a value indicating whether the symbol animations should be stop showing immediately.
     * @param forceShow A value indicating whether the symbol animations should be stop showing immediately.
     */
    public void setForceStop(boolean forceShow) {
        this.forceStop = forceShow;
    }

}
