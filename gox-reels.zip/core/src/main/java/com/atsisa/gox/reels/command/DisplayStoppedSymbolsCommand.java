package com.atsisa.gox.reels.command;

import java.util.List;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for display stopped symbols on reels.
 */
@Reflectable
public final class DisplayStoppedSymbolsCommand {

    /**
     * List of symbols to display.
     */
    private List<Iterable<String>> stoppedSymbols;

    /**
     * Initializes a new instance of the DisplayStoppedSymbolsCommand class.
     * @param stoppedSymbols list of symbols to display
     */
    public DisplayStoppedSymbolsCommand(List<Iterable<String>> stoppedSymbols) {
        this.stoppedSymbols = stoppedSymbols;
    }

    /**
     * Gets list of symbols to display.
     * @return list of symbols to display
     */
    public List<Iterable<String>> getStoppedSymbols() {
        return stoppedSymbols;
    }

}
