package com.atsisa.gox.reels.command;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.ShowScreenCommand;
import com.gwtent.reflection.client.Reflectable;

/**
 * A command used to show info screen.
 */
@Reflectable
public class ShowInfoScreenCommand extends ShowScreenCommand {

    /**
     * The id of the view that should be shown.
     */
    private String viewId;

    /**
     * Initializes a new instance of the {@link ShowInfoScreenCommand} class.
     * @param screenId              the id of the screen
     * @param showViewAnimationData {@link TweenViewAnimationData}
     * @param triggeredByUser       a boolean value that indicates whether this command was triggered by user interaction or not
     */
    public ShowInfoScreenCommand(String screenId, TweenViewAnimationData showViewAnimationData, boolean triggeredByUser) {
        super(screenId, showViewAnimationData, triggeredByUser);
    }

    /**
     * Initializes a new instance of the {@link ShowScreenCommand} class.
     * @param screenId              the id of the screen
     * @param showViewAnimationData {@link TweenViewAnimationData}
     */
    public ShowInfoScreenCommand(String screenId, TweenViewAnimationData showViewAnimationData) {
        super(screenId, showViewAnimationData);
    }

    /**
     * Gets the id of the view that should be shown.
     * @return the id of the view that should be shown
     */
    public String getViewId() {
        return viewId;
    }

    /**
     * Sets the id of the view that should be shown.
     * @param viewId {@link String}
     */
    public void setViewId(String viewId) {
        this.viewId = viewId;
    }
}
