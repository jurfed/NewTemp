package com.atsisa.gox.reels.view;

import java.util.HashMap;
import java.util.Map;

import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * A symbol pool strategy which analyzes given reel strip and pre-initializes symbols used within.
 */
public class ReelStripSymbolPoolStrategy implements ISymbolPoolStrategy {

    /**
     * Delegating strategy.
     */
    private final ISymbolPoolStrategy innerStrategy;

    /**
     * Initializes a new instance of the {@link ReelStripSymbolPoolStrategy}
     * class.
     * @param reelStripSymbolNames A collection of symbol names as defined in the reel strip.
     * @throws IllegalArgumentException The symbol quantities map is null.
     */
    public ReelStripSymbolPoolStrategy(Iterable<String> reelStripSymbolNames) {
        Map<String, Integer> quantities = getSymbolQuantities(reelStripSymbolNames);
        innerStrategy = new FixedSymbolPoolStrategy(quantities);
    }

    /**
     * Analyzes given reel strip and creates a map of symbol quantities required for given reel strip.
     * @param reelStripSymbolNames A collection of symbol names as defined in the reel strip.
     * @return A maps which tells how many symbols of given type should be pre-initialized.
     */
    private static Map<String, Integer> getSymbolQuantities(Iterable<String> reelStripSymbolNames) {
        if (reelStripSymbolNames == null) {
            throw new IllegalArgumentException("The reel strip symbol names cannot be null.");
        }

        Map<String, Integer> symbolQuantities = new HashMap<>();
        // TODO: improve it by determining the quantity of conjuctive symbols only.
        for (String symbolName : reelStripSymbolNames) {
            Integer quantity = symbolQuantities.get(symbolName);
            if (quantity == null) {
                quantity = 1;
            } else {
                quantity++;
            }

            symbolQuantities.put(symbolName, quantity);
        }

        return symbolQuantities;
    }

    @Override
    public Iterable<AbstractSymbol> initialize(ISymbolFactory symbolFactory) {
        return innerStrategy.initialize(symbolFactory);
    }

    @Override
    public AbstractSymbol getMissingSymbol(ISymbolPool symbolPool, String symbolName) {
        return innerStrategy.getMissingSymbol(symbolPool, symbolName);
    }

    @Override
    public void initializeConfiguration(Map<String, Object> configurationData) {
        innerStrategy.initializeConfiguration(configurationData);
    }
}
