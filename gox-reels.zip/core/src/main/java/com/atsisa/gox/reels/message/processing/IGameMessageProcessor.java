package com.atsisa.gox.reels.message.processing;

import com.atsisa.gox.reels.message.GameMessage;

/**
 * Alters {@link GameMessage}s before being published.
 */
public interface IGameMessageProcessor {

    /**
     * Alters given messages before it is published.
     * @param gameMessage The message to alter.
     */
    void process(GameMessage gameMessage);
}
