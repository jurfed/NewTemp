package com.atsisa.gox.reels.logic.request;

/**
 * Gets a gamble request.
 */
public class GambleRequest {

    /**
     * The selection name.
     */
    private final String selectionName;

    /**
     * Initializes a new instance of the {@link GambleRequest} class.
     * @param selectionName a selection name
     */
    public GambleRequest(String selectionName) {
        this.selectionName = selectionName;
    }

    /**
     * Gets a name of selection.
     * @return a name of selection
     */
    public String getSelectionName() {
        return selectionName;
    }
}
