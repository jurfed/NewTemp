package com.atsisa.gox.reels;

import com.atsisa.gox.framework.IDisposable;
import com.atsisa.gox.reels.view.SymbolPool;

/**
 * Responsible for releasing unmanaged resources related to the reels.
 */
public class ReelsDisposer implements IDisposable {

    @Override
    public void dispose() {
        SymbolPool.clearAllSymbols();
    }
}
