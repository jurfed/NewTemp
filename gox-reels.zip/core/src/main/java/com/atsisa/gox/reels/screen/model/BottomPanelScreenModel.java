package com.atsisa.gox.reels.screen.model;

import java.math.BigDecimal;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.google.inject.Inject;
import com.gwtent.reflection.client.Reflectable;

/**
 * Contains all properties required to render a bottom panel screen.
 */
@Reflectable
public class BottomPanelScreenModel extends ScreenModel {

    /**
     * Key of message area template.
     */
    private static final String MESSAGE_AREA_KEY= "MESSAGE_AREA";

    /**
     * Selected bet property.
     */
    private final NamedProperty<BigDecimal> bet = new NamedProperty<>(BigDecimal.class, "bet", BigDecimal.ZERO);

    /**
     * Total bet property.
     */
    private final NamedProperty<String> totalBet = new NamedProperty<>(String.class, "totalBet");

    /**
     * Message property.
     */
    private final NamedProperty<String> message = new NamedProperty<>(String.class, "message");

    /**
     * Selected line property.
     */
    private final NamedProperty<Integer> line = new NamedProperty<>(Integer.class, "line", 0);

    /**
     * Full credits description including currency property.
     */
    private final NamedProperty<String> credits = new NamedProperty<>(String.class, "credits");

    /**
     * Full win description including currency property.
     */
    private final NamedProperty<String> win = new NamedProperty<>(String.class, "win");

    /**
     * Initializes a new instance of the {@link BottomPanelScreenModel} class.
     *
     * @param translator {@link ITranslator}
     */
    @Inject
    public BottomPanelScreenModel(ITranslator translator) {
        super(translator);
        registerProperties();
    }

    /**
     * Initializes a new instance of the {@link BottomPanelScreenModel} class.
     */
    public BottomPanelScreenModel() {
        registerProperties();
    }

    /**
     * Registers custom bottom panel screen properties.
     */
    private void registerProperties() {
        registerProperty(win);
        registerProperty(credits);
        registerProperty(line);
        registerProperty(totalBet);
        registerProperty(bet);
        registerProperty(message);
    }

    /**
     * Gets currently selected line.
     *
     * @return currently selected line
     */
    public Integer getLine() {
        return line.get();
    }

    /**
     * Sets newly selected line.
     *
     * @param value newly selected line
     */
    public void setLine(Integer value) {
        line.set(value);
    }

    /**
     * Gets current message.
     *
     * @return current message
     */
    public String getMessage() {
        return getTemplate(MESSAGE_AREA_KEY).get().toString();
    }

    /**
     * Sets new message.
     *
     * @param value new message
     */
    public void setMessage(String value) {
        NamedProperty namedProperty = getTemplate(MESSAGE_AREA_KEY);
        namedProperty.setName(value);
        namedProperty.set(translator.translateTemplate(value));
    }

    /**
     * Gets full credits description including currency.
     *
     * @return full credits description including currency
     */
    public String getCredits() {
        return credits.get();
    }

    /**
     * Sets full credits description including currency.
     *
     * @param value full credits description including currency
     */
    public void setCredits(String value) {
        credits.set(value);
    }

    /**
     * Sets win including currency.
     *
     * @param winAmount win including currency
     */
    public void setWin(String winAmount) {
        win.set(winAmount);
    }

    /**
     * Gets current bet amount.
     *
     * @return current bet amount
     */
    public BigDecimal getBet() {
        return bet.get();
    }

    /**
     * Sets the current bet amount.
     *
     * @param value current bet amount
     */
    public void setBet(BigDecimal value) {
        bet.set(value);
    }

    /**
     * Gets total bet amount.
     *
     * @return current bet amount
     */
    public String getTotalBet() {
        return totalBet.get();
    }

    /**
     * Sets the total bet amount.
     *
     * @param value current bet amount
     */
    public void setTotalBet(String value) {
        totalBet.set(value);
    }

    /**
     * Gets the line property.
     *
     * @return the line property
     */
    public IObservableProperty<Integer> line() {
        return line;
    }

    /**
     * Gets the credits property.
     *
     * @return the credits property
     */
    public IObservableProperty<String> credits() {
        return credits;
    }

    /**
     * Gets the win property.
     *
     * @return the win property
     */
    public IObservableProperty<String> win() {
        return win;
    }

    /**
     * Gets the bet property.
     *
     * @return the bet property
     */
    public IObservableProperty<BigDecimal> bet() {
        return bet;
    }

    /**
     * Gets the total bet property.
     *
     * @return the total bet property
     */
    public IObservableProperty<String> totalBet() {
        return totalBet;
    }

    /**
     * Gets the message property.
     *
     * @return the message property
     */
    public IObservableProperty<String> message() {
        return getTemplate(MESSAGE_AREA_KEY);
    }
}
