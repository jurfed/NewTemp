package com.atsisa.gox.reels.logic.request;

/**
 * Represents a init request.
 */
public class InitRequest {

    /**
     * The game identity.
     */
    private final String gameIdentity;

    /**
     * The language code.
     */
    private final String languageCode;

    /**
     * Initializes a new instance of the {@link InitRequest} class.
     * @param gameIdentity a game identity
     * @param languageCode a language code
     */
    public InitRequest(String gameIdentity, String languageCode) {
        this.gameIdentity = gameIdentity;
        this.languageCode = languageCode;
    }

    /**
     * Gets a game identity.
     * @return a game identity
     */
    public String getGameIdentity() {
        return gameIdentity;
    }

    /**
     * Gets a language code.
     * @return a language code
     */
    public String getLanguageCode() {
        return languageCode;
    }
}
