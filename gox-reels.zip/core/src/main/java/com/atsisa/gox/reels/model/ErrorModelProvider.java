package com.atsisa.gox.reels.model;

import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.exception.ActionStateException;
import com.atsisa.gox.framework.exception.GameException;
import com.atsisa.gox.reels.command.ChangeGameMessageCommand;
import com.atsisa.gox.reels.command.GameErrorCommand;
import com.atsisa.gox.reels.command.ResetGameCommand;
import com.atsisa.gox.reels.event.ErrorModelChangedEvent;
import com.atsisa.gox.reels.event.GameMessageChangedEvent;
import com.atsisa.gox.reels.message.GameMessage;
import com.atsisa.gox.reels.message.GameMessageType;
import com.google.inject.Inject;

/**
 * Handles all aspect of game error configuration.
 */
public class ErrorModelProvider implements IErrorModelProvider {

    /*
     * EventBus reference.
     */
    private final IEventBus eventBus;

    /**
     * Retry policy.
     */
    private IRetryPolicy retryPolicy;

    /*
     * ErrorModel reference.
     */
    private ErrorModel errorModel;

    /**
     * Creates a new instance of ErrorModelProvider.
     * @param eventBus      the event bus
     * @param retryPolicy   retry policy
     */
    @Inject
    public ErrorModelProvider(IEventBus eventBus, IRetryPolicy retryPolicy) {
        this.eventBus = eventBus;
        registerEvents();
        setRetryPolicy(retryPolicy);
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new ErrorOccurredEventObserver(), ErrorOccurredEvent.class);
        eventBus.register(new GameMessageChangedEventObserver(), GameMessageChangedEvent.class);
        eventBus.register(new InitResponseEventObserver(), ResetGameCommand.class);
    }

    /**
     * Updates the error model according to given GameException notified.
     * @param event {@link ErrorOccurredEvent}
     */
    @Subscribe
    public void handle(ErrorOccurredEvent event) {
        updateModel(event);
        eventBus.post(new GameErrorCommand(errorModel));
    }

    /**
     * Updates error model.
     * @param event {@link ErrorOccurredEvent}
     */
    private void updateModel(ErrorOccurredEvent event) {
        Throwable cause = event.getCause();
        if (cause != null && cause instanceof ActionStateException) {
            cause = cause.getCause();
        }
        if (cause != null && cause instanceof GameException) {
            errorModel = new ErrorModel();
            errorModel.setCause(cause);
            errorModel.setRetry(retryPolicy.isRetriable(cause));
            eventBus.post(new ChangeGameMessageCommand("{#" + ((GameException) cause).getLocalizableMessage() + "}", GameMessageType.ERROR));
        }
    }

    /**
     * Updates the error model with game message.
     * @param event GameMessageChangedEvent notified
     */
    @Subscribe
    public void handle(GameMessageChangedEvent event) {
        GameMessage message = event.getMessage();
        if (message != null && message.getMessageType() == GameMessageType.ERROR) {
            errorModel.setMessage(message);
            notifyModelChanged();
        }
    }

    @Override
    public IErrorModel getErrorModel() {
        return errorModel;
    }

    @Override
    public void setRetryPolicy(IRetryPolicy retryPolicy) {
        if (retryPolicy == null) {
            throw new IllegalArgumentException("Retry policy cannot be null");
        }
        this.retryPolicy = retryPolicy;
    }

    /**
     * Publishes an event regarding error model changes.
     */
    private void notifyModelChanged() {
        eventBus.post(new ErrorModelChangedEvent(errorModel));
    }

    /**
     * Handles reset game.
     * @param resetGameCommand reset game command
     */
    @Subscribe
    public void handle(ResetGameCommand resetGameCommand) {
        errorModel = null;
    }

    private class ErrorOccurredEventObserver extends NextObserver<ErrorOccurredEvent> {

        @Override
        public void onNext(ErrorOccurredEvent errorOccurredEvent) {
            handle(errorOccurredEvent);
        }
    }

    private class GameMessageChangedEventObserver extends NextObserver<GameMessageChangedEvent> {

        @Override
        public void onNext(GameMessageChangedEvent gameMessageChangedEvent) {
            handle(gameMessageChangedEvent);
        }
    }

    private class InitResponseEventObserver extends NextObserver<ResetGameCommand> {

        @Override
        public void onNext(ResetGameCommand resetGameCommand) {
            handle(resetGameCommand);
        }
    }
}
