package com.atsisa.gox.reels.command;

import java.util.List;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request to stop the reels on particular positions.
 */
@Reflectable
public final class StopReelsCommand {

    /**
     * List of symbols to display.
     */
    private final List<Iterable<String>> symbolNames;

    /**
     * A value indicating whether the reels should be forcibly stopped.
     */
    private boolean forceStop;

    /**
     * Initializes a new instance of the {@link StopReelsCommand} class.
     * @param symbolNames The symbol names reels should stop on.
     */
    public StopReelsCommand(List<Iterable<String>> symbolNames) {
        this.symbolNames = symbolNames;
    }

    /**
     * Gets a value indicating whether the reels should be forcibly stopped.
     * @return A value indicating whether the reels should be forcibly stopped.
     */
    public boolean isForceStop() {
        return forceStop;
    }

    /**
     * Sets a value indicating whether the reels should be forcibly stopped.
     * @param forceStop A value indicating whether the reels should be forcibly stopped.
     */
    public void setForceStop(boolean forceStop) {
        this.forceStop = forceStop;
    }

    /**
     * Gets a list of symbol names the reels should be stopped on.
     * @return A list of symbol names the reels should be stopped on.
     */
    public List<Iterable<String>> getSymbolNames() {
        return symbolNames;
    }
}
