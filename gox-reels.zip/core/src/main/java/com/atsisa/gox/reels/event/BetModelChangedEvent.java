package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.IBetModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when either bet value has changed.
 */
@Reflectable
public final class BetModelChangedEvent extends AbstractEvent {

    /**
     * The bet model.
     */
    private final IBetModel betModel;

    /**
     * Initializes a new instance of the BetModelChangedEvent class.
     * @param betModel - IBetModel
     */
    public BetModelChangedEvent(IBetModel betModel) {
        this.betModel = betModel;
    }

    /**
     * Gets an object representing all crucial information
     * regarding the most recent reel game bet configuration.
     * @return IBetModel
     */
    public IBetModel getBetModel() {
        return betModel;
    }
}
