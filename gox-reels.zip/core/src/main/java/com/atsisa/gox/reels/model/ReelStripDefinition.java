package com.atsisa.gox.reels.model;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Definition of reel strip.
 */
@XmlElement(name = "reelStrip")
@Reflect_Full
public class ReelStripDefinition {

    /**
     * Reel strip list symbols.
     */
    @XmlCollectionElement(name = "symbols", itemName = "symbol", itemType = String.class)
    private List<String> reelStripList = new ArrayList<>();

    /**
     * Reel number for this reel strip.
     */
    @XmlAttribute(name = "number")
    private int reelNumber;

    /**
     * Type reel strip.
     */
    @XmlAttribute(name = "type")
    private String type;

    /**
     * Adds symbol to the end of reel strip list.
     * @param name - String
     */
    public void addSymbol(String name) {
        reelStripList.add(name);
    }

    /**
     * Adds symbol to the reel strip list at specific index.
     * @param name  - String
     * @param index - int
     */
    public void addSymbol(String name, int index) {
        reelStripList.add(index, name);
    }

    /**
     * Gets symbol name from list at specific position.
     * @param index - int
     * @return String
     */
    public String getSymbol(int index) {
        return reelStripList.get(index);
    }

    /**
     * Gets a collection of symbol names.
     * @return A collection of symbol names.
     */
    public Iterable<String> getSymbols() {
        return reelStripList;
    }

    /**
     * Gets reel number for this reel strip.
     * @return the reel number
     */
    public int getReelNumber() {
        return reelNumber;
    }

    /**
     * Sets the number of reel.
     * @param reelNumber the number of reel
     */
    public void setReelNumber(int reelNumber) {
        this.reelNumber = reelNumber;
    }

    /**
     * Gets the type of reel.
     * @return the type of reel
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of reel.
     * @param type the type of reel
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Sets reel strip list.
     * @param list List of String
     */
    public void setReelStripList(List<String> list) {
        reelStripList = list;
    }

    /**
     * Gets reel strip list size.
     * @return int
     */
    public int getSize() {
        if (reelStripList != null) {
            return reelStripList.size();
        }
        return 0;
    }

}
