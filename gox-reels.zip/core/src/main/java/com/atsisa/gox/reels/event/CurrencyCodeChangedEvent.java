package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when a currency code changes.
 */
@Reflectable
public class CurrencyCodeChangedEvent {

    /**
     * The currency code.
     */
    private final String currencyCode;

    /**
     * Initializes a new instance of the {@link CurrencyCodeChangedEvent} class.
     * @param currencyCode The currency code.
     */
    public CurrencyCodeChangedEvent(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    /**
     * Gets the currency code of this account.
     * @return the currency code.
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

}
