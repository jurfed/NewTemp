package com.atsisa.gox.reels.animation.phase;

import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.MathUtility;
import com.atsisa.gox.framework.utility.Statics;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Animation phase that performs constant shift in accordance to specified configuration.
 */
@Reflect_Full
@XmlElement(name = "ConstantPhase")
public class ConstantStepReelAnimationPhase implements IReelAnimationPhase {

    /**
     * Default value of reel phase animation speed.
     */
    private static final float DEFAULT_ANIMATION_SPEED = 3200f;

    /**
     * Default value of accumulator length.
     */
    private static final float DEFAULT_ACCUMULATOR_LENGTH = 12f;

    /**
     * Interval in which steps should be processed. Default value triggers the processing at the rate of 60FPS.
     */
    @XmlAttribute(name = "interval")
    private float interval = Statics.FPS_60;

    /**
     * Reel phase animation speed used in the linear interpolation.
     */
    private float animationSpeed;

    /**
     * Length of the accumulator used in the linear interpolation.
     */
    private float accumulatorLength;

    /**
     * Accumulator used to accumulate increase of delta time.
     */
    private float accumulator;

    /**
     * Last position of reels during linear interpolation.
     */
    private float lastPosition;

    /**
     * Creates a new instance of ConstantStepReelAnimationPhase.
     */
    public ConstantStepReelAnimationPhase() {
        accumulator = 0f;
        animationSpeed = DEFAULT_ANIMATION_SPEED;
        accumulatorLength = DEFAULT_ACCUMULATOR_LENGTH;
        lastPosition = 0f;
    }

    @Override
    public float getStepOffset(final float delta) {
        accumulator += delta;
        if (!isFinished() && shouldProcessNextStep()) {
            final float reelStepInPixels = MathUtility.lerp(0, animationSpeed, MathUtility.clamp(accumulator / accumulatorLength, 0, 1)) - lastPosition;
            lastPosition += reelStepInPixels;
            return Math.round(reelStepInPixels);
        }
        return 0;
    }

    @Override
    public boolean isFinished() {
        return false;
    }

    /**
     * Evaluates whether accumulator is high enough to trigger next animation step.
     * @return true if step should be processed, false otherwise
     */
    private boolean shouldProcessNextStep() {
        return true;
    }

    @Override
    public void reset() {
        accumulator = 0f;
        lastPosition = 0f;
    }

    @Override
    public IReelAnimationPhase clone() {
        return new ConstantStepReelAnimationPhase();
    }

    /**
     * Animation steps processing interval (in millis).
     * @param interval - interval at which animation steps should be processed
     */
    public void setInterval(float interval) {
        this.interval = interval;
    }

}
