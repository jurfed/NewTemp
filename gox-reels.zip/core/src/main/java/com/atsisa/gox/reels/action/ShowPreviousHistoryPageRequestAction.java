package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.IGameEngine;

/**
 * Sends a request to show previous history page.
 */
public class ShowPreviousHistoryPageRequestAction extends AbstractHistoryPageRequestAction {

    /**
     * Initializes a new instance of the {@link ShowPreviousHistoryPageRequestAction} class.
     */
    public ShowPreviousHistoryPageRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowPreviousHistoryPageRequestAction} class.
     * @param gameEngine game engine reference
     */
    public ShowPreviousHistoryPageRequestAction(IGameEngine gameEngine) {
        super(gameEngine);
    }

    @Override
    protected int getHistoryPageNumberToShow() {
        return getHistoryModel().getActivePageNumber() - 1;
    }
}
