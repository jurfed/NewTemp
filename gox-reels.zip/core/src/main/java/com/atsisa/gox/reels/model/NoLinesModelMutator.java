package com.atsisa.gox.reels.model;

import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.reels.ILinesModel;

/**
 * Default implementation of lines model mutator, which do nothing and returns original lines model.
 */
public class NoLinesModelMutator implements IMutator<ILinesModel> {

    @Override
    public ILinesModel mutate(ILinesModel object) {
        return object;
    }
}
