package com.atsisa.gox.reels.controller;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.reels.CardType;
import com.atsisa.gox.reels.ClosableListening;
import com.atsisa.gox.reels.IGamblerController;
import com.atsisa.gox.reels.IGamblerListener;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.EnterGamblerCommand;
import com.atsisa.gox.reels.event.GamblerCardSelectedEvent;
import com.atsisa.gox.reels.event.GamblerModelChangedEvent;
import com.atsisa.gox.reels.event.SelectedGamblerCardHiddenEvent;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.google.inject.Inject;

/**
 * Gambler controller default implementation.
 */
public class GamblerController implements IGamblerController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * Currently selected card type.
     */
    private CardType selectedCardType;

    /**
     * Gambler model.
     */
    private IGamblerModel gamblerModel;

    /**
     * Set of the gambler listeners.
     */
    private final Set<IGamblerListener> listeners = new HashSet<>();

    /**
     * Creates new instance of the {@link GamblerController} class.
     * @param eventBus the event bus
     */
    @Inject
    public GamblerController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new GamblerCardSelectedObserver(), GamblerCardSelectedEvent.class);
        eventBus.register(new SelectedGamblerCardHiddenObserver(), SelectedGamblerCardHiddenEvent.class);
        eventBus.register(new GamblerModelChangedEventObserver(), GamblerModelChangedEvent.class);
    }

    @Override
    public void select(CardType cardType) {
        eventBus.post(new GamblerCardSelectedEvent(cardType));
    }

    @Override
    public Optional<CardType> getSelectedCard() {
        return Optional.ofNullable(selectedCardType);
    }

    @Override
    public synchronized void enter() {
        eventBus.post(new EnterGamblerCommand(true));
    }

    @Override
    public ClosableListening addGamblerListener(IGamblerListener listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    /**
     * Notify all gambler listeners.
     * @param cardType selected card type.
     */
    private void notifyListeners(CardType cardType) {
        for (IGamblerListener listener : listeners) {
            listener.cardSelected(cardType);
        }
    }

    @Override
    public BigDecimal getBidAmount() {
        return gamblerModel.getBidAmount();
    }

    @Override
    public BigDecimal getWonAmount() {
        return gamblerModel.getWonAmount();
    }

    private class GamblerCardSelectedObserver extends NextObserver<GamblerCardSelectedEvent> {

        @Override
        public void onNext(GamblerCardSelectedEvent gamblerCardSelectedEvent) {
            selectedCardType = gamblerCardSelectedEvent.getCardType();
            notifyListeners(selectedCardType);
        }
    }

    private class SelectedGamblerCardHiddenObserver extends NextObserver<SelectedGamblerCardHiddenEvent> {

        @Override
        public void onNext(SelectedGamblerCardHiddenEvent selectedGamblerCardHiddenEvent) {
            selectedCardType = null;
        }
    }

    private class GamblerModelChangedEventObserver extends NextObserver<GamblerModelChangedEvent> {

        @Override
        public void onNext(GamblerModelChangedEvent gamblerModelChangedEvent) {
            gamblerModel = gamblerModelChangedEvent.getGamblerModel();
        }
    }
}
