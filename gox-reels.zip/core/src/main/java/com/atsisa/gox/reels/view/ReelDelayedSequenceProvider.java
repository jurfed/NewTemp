package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.view.spi.IReelSequenceProvider;

import rx.Observable;
import rx.subjects.ReplaySubject;

/**
 * Provides delayed sequence for IReel type.
 */
@XmlElement
public class ReelDelayedSequenceProvider implements IReelSequenceProvider {

    /**
     * Default stop delay between reels in milliseconds.
     */
    private static final int DEFAULT_STOP_DELAY_BETWEEN_REELS = 500;

    /**
     * List of reel delays in.
     */
    private final List<Integer> delays;

    /**
     * A value indicating whether the delay values should be multiplied by a number of delays loop.
     */
    private boolean roundRobinMultiply;

    /**
     * Creates an instance of ReelDelayedSequenceProvider with default delay (500 milliseconds).
     */
    public ReelDelayedSequenceProvider() {
        this(Arrays.asList(DEFAULT_STOP_DELAY_BETWEEN_REELS));
        roundRobinMultiply = true;
    }

    /**
     * Creates an instance of ReelDelayedSequenceProvider.
     * @param delays list of delays
     */
    public ReelDelayedSequenceProvider(List<Integer> delays) {
        validateDelays(delays);
        this.delays = delays;
    }

    /**
     * Validates list of delays and throw IllegalArgumentException when item < 0.
     * @param delays list of delays
     */
    private void validateDelays(List<Integer> delays) {
        if (delays != null && !delays.isEmpty()) {
            for (Integer delay : delays) {
                if (delay < 0) {
                    throw new IllegalArgumentException("Delay cannot be less than zero.");
                }
            }
        }
    }

    @Override
    public Observable<IReel> createSequence(Iterable<? extends IReel> items) {
        validateItems(items);

        int reelsCount = Iterables.size(items);
        List<Integer> matchedDelays = createMatchedDelaysToReelsCount(reelsCount);

        if (delays == null || delays.isEmpty() || areAllDelaysEqualZero(matchedDelays)) {
            return Observable.from(items);
        } else {
            return createTimeDependedSequence(items, reelsCount, matchedDelays);
        }
    }

    /**
     * Creates advanced sequence based on PublishSubject.
     * @param items         iterable IReel items
     * @param reelsCount    IReels items count
     * @param matchedDelays matched delays to IReels items count
     * @return PublishSubject object
     */
    private Observable<IReel> createTimeDependedSequence(Iterable<? extends IReel> items, int reelsCount, List<Integer> matchedDelays) {
        ReplaySubject<IReel> replaySubject = ReplaySubject.create();

        int publishedReelsCount = 0;

        List<Integer> uniqueDelays = new ArrayList<>(new HashSet<>(matchedDelays));
        Collections.sort(uniqueDelays);

        if (uniqueDelays.contains(0)) {
            List<IReel> noDelayReels = getSameDelayReels(items, matchedDelays, 0);
            publishedReelsCount += noDelayReels.size();
            for (IReel reel : noDelayReels) {
                replaySubject.onNext(reel);
            }
            uniqueDelays.remove(0);
        }

        for (Integer uniqueDelay : uniqueDelays) {
            List<IReel> sameDelayReels = getSameDelayReels(items, matchedDelays, uniqueDelay);
            publishedReelsCount += sameDelayReels.size();
            boolean completed = publishedReelsCount == reelsCount;

            DelayedAction delayedAction = new DelayedAction(sameDelayReels, replaySubject, completed);
            Timeout timeout = new Timeout(uniqueDelay, delayedAction);
            delayedAction.setTimeout(timeout);
            timeout.start();
        }

        return replaySubject;
    }

    /**
     * Gets same delays IReel items.
     * @param reels  IReel items
     * @param delays all delays
     * @param delay  delay to match
     * @return same delays IReel items
     */
    private List<IReel> getSameDelayReels(Iterable<? extends IReel> reels, List<Integer> delays, int delay) {
        List<IReel> sameDelayReels = new ArrayList<>();

        int reelIndex = 0;
        for (IReel reel : reels) {
            if (delays.get(reelIndex) == delay) {
                sameDelayReels.add(reel);
            }
            reelIndex++;
        }

        return sameDelayReels;
    }

    /**
     * Validates IReels items and throw IllegalArgumentException when is null or empty.
     * @param items iterable IReel items
     */
    private void validateItems(Iterable<? extends IReel> items) {
        if (items == null || !items.iterator().hasNext()) {
            throw new IllegalArgumentException("Reels cannot be null or empty.");
        }
    }

    /**
     * Creates matched delays to reels collection. Extends if shorter, cut if longer.
     * @param reelsCount reels count
     * @return matched delays to reels collection
     */
    private List<Integer> createMatchedDelaysToReelsCount(int reelsCount) {
        List<Integer> matchedDelays = new ArrayList<>();

        int multiplier = 1;
        for (int reelIndex = 0, delayIndex = 0; reelIndex < reelsCount; reelIndex++, delayIndex++) {
            matchedDelays.add(delays.get(delayIndex) * multiplier);
            if (delayIndex == delays.size() - 1) {
                delayIndex = -1;
                if (roundRobinMultiply) {
                    multiplier++;
                }
            }
        }

        return matchedDelays;
    }

    /**
     * Checks that all delays are equals zero.
     * @param delays delays collection.
     * @return true if all delays are equals zero, false if not equals
     */
    private boolean areAllDelaysEqualZero(List<Integer> delays) {
        for (Integer delay : delays) {
            if (delay > 0) {
                return false;
            }
        }

        return true;
    }

    /**
     * Sets a value indicating whether the delay values should be multiplied
     * by a number of delays loop.
     * @param roundRobinMultiply a value indicating whether the delay values should be multiplied by a number of delays loop.
     */
    public void setRoundRobinMultiply(boolean roundRobinMultiply) {
        this.roundRobinMultiply = roundRobinMultiply;
    }

    /**
     * Helper class for Action1 class.
     */
    private class DelayedAction implements TimeoutCallback {

        /**
         * Same delay reels collection.
         */
        private final List<IReel> sameDelayReels;

        /**
         * ReplaySubject reference.
         */
        private final ReplaySubject<IReel> replaySubject;

        /**
         * Determines when ReplaySubject should be completed.
         */
        private final boolean publishCompleted;

        /**
         * Subscription reference for unsubscribe.
         */
        private Timeout timeout;

        /**
         * Creates helper class for Action1 class.
         * @param sameDelayReels   same delay reels collection
         * @param replaySubject    ReplaySubject reference
         * @param publishCompleted determines when ReplaySubject should be completed
         */
        DelayedAction(List<IReel> sameDelayReels, ReplaySubject<IReel> replaySubject, boolean publishCompleted) {
            this.sameDelayReels = sameDelayReels;
            this.replaySubject = replaySubject;
            this.publishCompleted = publishCompleted;
        }

        public void setTimeout(Timeout timeout) {
            this.timeout = timeout;
        }

        @Override
        public void onTimeout() {
            if (!timeout.isCleaned()) {
                timeout.clear();
            }

            for (IReel reel : sameDelayReels) {
                replaySubject.onNext(reel);
            }

            if (publishCompleted) {
                replaySubject.onCompleted();
            }
        }
    }
}
