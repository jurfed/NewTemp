package com.atsisa.gox.reels.screen;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.command.ChangeLanguageCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.InteractiveView;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Common implementation of language screen.
 */
@Reflectable(fields = false)
public class LanguageScreen extends Screen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "LanguageScreenLayoutId";

    /**
     * Describes view which is language button on layout.
     */
    private static final String LANG_BUTTON_TAG = "langButton";

    /**
     * A boolean value that indicates whether lang buttons are initialized or not.
     */
    private AtomicBoolean langButtonsInitialized;

    /**
     * Initializes a new instance of the {@link LanguageScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public LanguageScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        langButtonsInitialized = new AtomicBoolean();
    }

    @Override
    protected void afterActivated() {
        if (langButtonsInitialized.getAndSet(true)) {
            return;
        }
        List<InteractiveView> views = findViewInheritingType(InteractiveView.class);
        for (InteractiveView view : views) {
            String languageCode = findLanguageCode(view.getTags());
            if (languageCode != null) {
                view.setReleaseListener(event -> changeLanguage(languageCode));
            }
        }
    }

    /**
     * Sends command to change language.
     * @param languageCode language code to change
     */
    private void changeLanguage(String languageCode) {
        getEventBus().post(new ChangeLanguageCommand(languageCode));
    }

    /**
     * Finds lang code in specific tags.
     * @param tags tags collection to check
     * @return lang code if exists
     */
    private String findLanguageCode(Iterable<String> tags) {
        for (String tag : tags) {
            String[] parts = tag.split(":");
            if (parts.length == 2 && LANG_BUTTON_TAG.equals(parts[0])) {
                return parts[1];
            }
        }
        return null;
    }

}
