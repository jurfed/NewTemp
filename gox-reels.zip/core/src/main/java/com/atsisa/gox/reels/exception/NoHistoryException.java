package com.atsisa.gox.reels.exception;

import com.atsisa.gox.framework.exception.GameException;

/**
 * Indicates n
 */
public class NoHistoryException extends GameException {

    /**
     * Game message.
     */
    public static final String LANG_ERROR_NO_HISTORY = "LangErrorNoHistory";

    /**
     * Initializes a new instance of the {@link NoHistoryException} using specific message.
     * @param message error message
     */
    public NoHistoryException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the {@link NoHistoryException} using specific message and cause.
     * @param message error message
     * @param cause   internal cause of error
     */
    public NoHistoryException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Initializes a new instance of the {@link NoHistoryException} using specific cause.
     * @param cause internal cause of error
     */
    public NoHistoryException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getLocalizableMessage() {
        return LANG_ERROR_NO_HISTORY;
    }

}
