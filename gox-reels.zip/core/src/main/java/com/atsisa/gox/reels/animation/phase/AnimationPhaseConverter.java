package com.atsisa.gox.reels.animation.phase;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlSerializer;
import com.atsisa.gox.framework.serialization.converter.IValueConverter;
import com.gwtent.reflection.client.annotations.Reflect_Full;

/**
 * Converts the XML representation of phase definition into POJO object.
 */
@Reflect_Full
public class AnimationPhaseConverter implements IValueConverter {

    /**
     * Parameter specifying attribute name containing Class which will be used during deserialization.
     */
    public static final String CLASS_ATTRIBUTE_NAME = "class";

    /**
     * XML serializer instance used during unmarshalling of objects.
     */
    private final XmlSerializer serializer;

    /**
     * Creates a new instance of AnimationPhaseConverter class.
     */
    public AnimationPhaseConverter() {
        serializer = (XmlSerializer) GameEngine.current().getUtility().getSerialization().getSerializer(SerializationFormat.XML);
    }

    @Override
    public Class<?> getValueType() {
        return List.class;
    }

    @Override
    public String convertTo(Object objToConvert) {
        throw new UnsupportedOperationException(AnimationPhaseConverter.class.getName() + " does not support yet serialization of animation phases.");
    }

    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        List<IReelAnimationPhase> phases = new ArrayList<>();
        if (parsedObject instanceof XmlObject) {
            List<XmlObject> deserializedPhases = ((XmlObject) parsedObject).getChildren();
            for (XmlObject phase : deserializedPhases) {
                if (phase.getAttribute(CLASS_ATTRIBUTE_NAME) == null) {
                    throw new UnsupportedOperationException("Phase serialized format does not contain required 'class' attribute.");
                }
                try {
                    IReelAnimationPhase animationPhase = (IReelAnimationPhase) serializer.deserialize(phase, phase.getAttribute(CLASS_ATTRIBUTE_NAME));
                    phases.add(animationPhase);
                } catch (SerializationException e) {
                    throw new UnsupportedOperationException(e.getMessage());
                }
            }
        } else {
            throw new UnsupportedOperationException("Deserialization from other data representation format is not yet supported");
        }
        return phases;
    }
}
