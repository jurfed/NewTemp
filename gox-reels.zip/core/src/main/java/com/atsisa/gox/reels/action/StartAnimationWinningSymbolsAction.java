package com.atsisa.gox.reels.action;

import java.util.List;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.command.StartAnimationWinningSymbolsCommand;
import com.atsisa.gox.reels.command.TerminateStartsShowingWinningSymbolsCommand;
import com.atsisa.gox.reels.event.ReelsShowingSymbolAnimationsEvent;
import com.atsisa.gox.reels.model.ILinesModelProvider;

/**
 * Sends command which starts showing winning symbols.
 */
public class StartAnimationWinningSymbolsAction extends WaitForEventAction<ReelsShowingSymbolAnimationsEvent> {

    /**
     * Lines model provider.
     */
    private final ILinesModelProvider linesModelProvider;

    /**
     * Stopped symbols.
     */
    private List<? extends IWinLineInfo> winningLines;

    /**
     * Initializes a new instance of the {@link StartAnimationWinningSymbolsAction} class.
     */
    public StartAnimationWinningSymbolsAction() {
        linesModelProvider = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider();
    }

    /**
     * Initializes a new instance of the {@link StartAnimationWinningSymbolsAction} class.
     * @param logger             {@link ILogger}
     * @param eventBus           {@link IEventBus}
     * @param linesModelProvider {@link ILinesModelProvider}
     */
    public StartAnimationWinningSymbolsAction(ILogger logger, IEventBus eventBus, ILinesModelProvider linesModelProvider) {
        super(logger, eventBus);
        this.linesModelProvider = linesModelProvider;
    }

    @Override
    protected Class<ReelsShowingSymbolAnimationsEvent> getEventClass() {
        return ReelsShowingSymbolAnimationsEvent.class;
    }

    @Override
    protected void grabData() {
        winningLines = Iterables.toList(linesModelProvider.getLinesModel().getWinningLines());
    }

    @Override
    protected void validate() throws ValidationException {
        if (winningLines == null || winningLines.isEmpty()) {
            throw new ValidationException("Can not show winning symbols, because there is not winning lines.");
        }
    }

    @Override
    protected void reset() {
        super.reset();
        winningLines = null;
    }

    @Override
    protected void terminate() {
        super.terminate();
        eventBus.post(new TerminateStartsShowingWinningSymbolsCommand());
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new StartAnimationWinningSymbolsCommand(winningLines));
    }

}
