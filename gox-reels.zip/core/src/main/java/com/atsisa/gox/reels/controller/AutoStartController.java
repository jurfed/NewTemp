package com.atsisa.gox.reels.controller;

import java.util.HashSet;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.reels.AutoStartState;
import com.atsisa.gox.reels.ClosableListening;
import com.atsisa.gox.reels.IAutoStartController;
import com.atsisa.gox.reels.IAutoStartListener;
import com.atsisa.gox.reels.command.StartAutoPlayCommand;
import com.atsisa.gox.reels.command.StopAutoPlayCommand;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.google.inject.Inject;

/**
 * AutoStartController default implementation.
 */
public class AutoStartController implements IAutoStartController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The set of the AutoStart listeners.
     */
    private final Set<IAutoStartListener> listeners = new HashSet<>();

    /**
     * Current AutoStart state.
     */
    private AutoStartState currentAutoStartState = AutoStartState.OFF;

    /**
     * Creates a new instance of the {@link AutoStartController} class.
     * @param eventBus the event bus.
     */
    @Inject
    public AutoStartController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        eventBus.register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
    }

    @Override
    public AutoStartState getState() {
        return currentAutoStartState;
    }

    @Override
    public synchronized void turnOn() {
        eventBus.post(new StartAutoPlayCommand(true));
    }

    @Override
    public synchronized void turnOff() {
        eventBus.post(new StopAutoPlayCommand(true));
    }

    @Override
    public ClosableListening addStateListener(IAutoStartListener listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    /**
     * Notify all AutoStart listeners.
     * @param autoStartState AutoStart state
     */
    private void notifyListeners(AutoStartState autoStartState) {
        for (IAutoStartListener listener : listeners) {
            listener.stateChanged(autoStartState);
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(AutoPlayStartedEvent autoPlayStartedEvent) {
            currentAutoStartState = AutoStartState.ON;
            notifyListeners(AutoStartState.ON);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(AutoPlayStoppedEvent autoPlayStoppedEvent) {
            currentAutoStartState = AutoStartState.OFF;
            notifyListeners(AutoStartState.OFF);
        }
    }
}
