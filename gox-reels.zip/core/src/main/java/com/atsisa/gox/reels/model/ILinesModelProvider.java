package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

import com.atsisa.gox.reels.ILinesModel;

/**
 * Exposes the most recent reel game lines configuration.
 */
public interface ILinesModelProvider {

    /**
     * Gets the most recent reel game lines
     * configuration.
     * @return An object representing the configuration of lines.
     */
    ILinesModel getLinesModel();

    /**
     * Returns a boolean value that indicates whether there are winning lines or not.
     * @return a boolean value that indicates whether there are winning lines or not
     */
    boolean hasWinningLines();

    /**
     * Gets the current total win amount.
     * @return the current total win amount.
     */
    BigDecimal getTotalWinAmount();
}
