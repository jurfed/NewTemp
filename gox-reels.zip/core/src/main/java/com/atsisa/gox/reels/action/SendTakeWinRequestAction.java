package com.atsisa.gox.reels.action;

import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Sends a TakeWin request to the game server.
 */
@Reflect_Mini
public class SendTakeWinRequestAction extends AbstractSendRequestAction {

    /**
     * Initializes a new instance of the {@link SendTakeWinRequestAction} class.
     */
    public SendTakeWinRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link SendTakeWinRequestAction} class.
     * @param game reel game reference
     */
    public SendTakeWinRequestAction(AbstractReelGame game) {
        super(game);
    }

    /**
     * Sends a take win request to the server.
     */
    @Override
    protected void execute() {
        subscribeForResult(getGameLogic().takeWin());
    }

}
