package com.atsisa.gox.reels.action;

import com.gwtent.reflection.client.Reflectable;

/**
 * Sends the Init request to the game server.
 */
@Reflectable(relationTypes = true)
public class SendInitRequestAction extends AbstractInitRequestAction {

    /**
     * Initializes a new instance of the {@link SendInitRequestAction} class.
     */
    public SendInitRequestAction() {
        super();
    }

    @Override
    protected void sendInitRequest() {
        logger.debug("SendInitRequestAction | sendInitRequest");
        subscribeForResult(getGameLogic().init(createInitRequest()));
    }
}
