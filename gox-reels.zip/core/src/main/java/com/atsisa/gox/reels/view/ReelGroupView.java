package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.CompletedObserver;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.DynamicClassConverter;
import com.atsisa.gox.framework.serialization.converter.ViewCollectionConverter;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.view.spi.IHideSymbolAnimationsStrategy;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.spi.IReelSequenceProvider;
import com.atsisa.gox.reels.view.spi.IShowSymbolAnimationsStrategy;
import com.atsisa.gox.reels.view.state.ReelGroupState;
import com.atsisa.gox.reels.view.state.ReelState;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

import rx.Observable;
import rx.Subscription;
import rx.functions.Action2;
import rx.subjects.PublishSubject;

/**
 * The most common implementation of {@link AbstractReelGroup} interface.
 */
@Reflectable(fields = false)
@XmlElement
public class ReelGroupView extends AbstractReelGroup {

    /**
     * Reels list.
     */
    @XmlElement(name = "reels", converters = ViewCollectionConverter.class)
    @HasReflect
    private List<AbstractReel> reels;

    /**
     * Contains the reels and their indices.
     */
    private final Map<IReel, Integer> reelsIndices;

    /**
     * Current reel group state.
     */
    private ReelGroupState reelGroupState;

    /**
     * Spin sequence strategy which will be used when spin is called.
     */
    @XmlElement(name = "spinSequenceProvider", converters = DynamicClassConverter.class)
    private IReelSequenceProvider spinSequenceProvider;

    /**
     * Spin sequence strategy which will be used when there is a need to stop reels on specific symbols gently.
     */
    @XmlElement(name = "stopOnSymbolsSequenceProvider", converters = DynamicClassConverter.class)
    private IReelSequenceProvider stopOnSymbolsSequenceProvider;

    /**
     * Spin sequence provider which will be used when there is a need to stop reels on specific symbols forcibly.
     */
    @XmlElement(name = "forceStopOnSymbolsSequenceProvider", converters = DynamicClassConverter.class)
    private IReelSequenceProvider forceStopOnSymbolsSequenceProvider;

    /**
     * Current strategy subscription.
     */
    private Subscription currentStrategySubscription;

    /**
     * Reel state subscriptions.
     */
    private final List<Subscription> reelStateSubscriptions;

    /**
     * A boolean value that indicates whether this reel groups is in force stopping phase.
     */
    private boolean isForceStopping;

    /**
     * Reel group state subject.
     */
    private final PublishSubject<ReelGroupState> reelGroupStateSubject;

    /**
     * A strategy which is responsible for show animations on winning symbols.
     */
    @XmlElement(name = "showSymbolAnimationsStrategy", converters = DynamicClassConverter.class)
    private IShowSymbolAnimationsStrategy showSymbolAnimationsStrategy;

    /**
     * A strategy which is responsible for hide animations on winning symbols.
     */
    @XmlElement(name = "hideSymbolAnimationsStrategy", converters = DynamicClassConverter.class)
    private IHideSymbolAnimationsStrategy hideSymbolAnimationsStrategy;

    /**
     * Initializes a new instance of the {@link ReelGroupView}.
     */
    public ReelGroupView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link ReelGroupView}.
     * @param renderer {@link IRenderer}
     */
    public ReelGroupView(IRenderer renderer) {
        super(renderer);
        spinSequenceProvider = new ReelInstantSequenceProvider();
        stopOnSymbolsSequenceProvider = new ReelDelayedSequenceProvider();
        forceStopOnSymbolsSequenceProvider = new ReelInstantSequenceProvider();
        showSymbolAnimationsStrategy = new StateShowSymbolAnimationsStrategy();
        hideSymbolAnimationsStrategy = new StateHideSymbolAnimationsStrategy();
        reelGroupState = ReelGroupState.IDLE;
        reelStateSubscriptions = new ArrayList<>();
        reelGroupStateSubject = PublishSubject.create();
        reelsIndices = new HashMap<>();
    }

    @Override
    public AbstractReel getReel(int index) {
        if (reels == null || reels.isEmpty()) {
            throw new IndexOutOfBoundsException(StringUtility.format("Can not return reel with index: %s, because the reels were not set.", index));
        }
        if (reels.size() <= index || index < 0) {
            throw new IndexOutOfBoundsException(
                    StringUtility.format("Can not return reel with index: %s, because the available range is: 0-%s", index, reels.size() - 1));
        }
        return reels.get(index);
    }

    @Override
    public ReelGroupState getReelGroupState() {
        return reelGroupState;
    }

    @Override
    public Observable<ReelGroupState> getReelGroupStateObservable() {
        return reelGroupStateSubject;
    }

    @Override
    public Iterable<AbstractReel> getReels() {
        return reels;
    }

    @Override
    public void setReels(List<AbstractReel> reels) {
        if (reels == null) {
            throw new IllegalArgumentException("Reels can not be null.");
        }
        if (this.reels != null) {
            if (reelGroupState != ReelGroupState.IDLE) {
                throw new IllegalStateException(StringUtility
                        .format("Can not set new reels, because not all of them are in the idle state. Reel group current state is: %s", reelGroupState));
            }
            removeAll();
        }
        reelsIndices.clear();
        clearReelStateSubscribers();
        this.reels = reels;
        registerReelStateSubscribers();
        int index = 0;
        for (AbstractReel reel : this.reels) {
            addChild(reel);
            reel.setIndex(index);
            reelsIndices.put(reel, Integer.valueOf(index));
            index++;
        }
        reelsStateChanged();
    }

    /**
     * Clears animation subscribers.
     */
    private void clearReelStateSubscribers() {
        for (Subscription subscription : reelStateSubscriptions) {
            subscription.unsubscribe();
        }
        reelStateSubscriptions.clear();
    }

    /**
     * Registers reel state subscribers.
     */
    private void registerReelStateSubscribers() {
        for (AbstractReel reel : reels) {
            Subscription subscription = reel.getReelStateObservable().subscribe(reelState -> reelsStateChanged());
            reelStateSubscriptions.add(subscription);
        }
    }

    /**
     * Called when in any reel state has been changed.
     */
    private void reelsStateChanged() {
        ReelGroupState newState = ReelGroupState.IDLE;
        for (AbstractReel reel : reels) {
            if (reel.getReelState() == ReelState.SPINNING && newState == ReelGroupState.IDLE) {
                newState = ReelGroupState.SPINNING;
            } else if (reel.getReelState() == ReelState.STOPPING) {
                newState = ReelGroupState.STOPPING;
            }
        }
        changeState(newState);
    }

    /**
     * Called when state in reel group should be changed.
     * @param state {@link ReelGroupState}
     */
    private void changeState(ReelGroupState state) {
        if (reelGroupState == ReelGroupState.IDLE && state == ReelGroupState.STOPPING) {
            return;
        }

        if (isForceStopping && state != ReelGroupState.STOPPING) {
            isForceStopping = false;
        }

        if (state != reelGroupState) {
            reelGroupState = state;
            reelGroupStateSubject.onNext(reelGroupState);
        }
    }

    @Override
    public void spin() {
        if (reels == null) {
            throw new IllegalStateException("Can not spin reels, because they are not set.");
        }

        if (reelGroupState != ReelGroupState.IDLE) {
            throw new IllegalStateException(
                    StringUtility.format("Can not spin reels, because not all of them are in the idle state. Reel group current state is: %s", reelGroupState));
        }
        removeCurrentSubscription();
        changeState(ReelGroupState.SPINNING);
        currentStrategySubscription = spinSequenceProvider.createSequence(reels).subscribe(IReel::spin);
    }

    @Override
    public void stopOnSymbols(List<Iterable<String>> symbolNames) {
        validateStopConditions(symbolNames);

        if (reelGroupState == ReelGroupState.STOPPING) {
            throw new IllegalStateException("Can not stop reels on the specific symbols, because they are already in stopping phase.");
        }

        changeState(ReelGroupState.STOPPING);
        stopReels(IReel::stopOnSymbols, symbolNames, stopOnSymbolsSequenceProvider);
    }

    @Override
    public void forceStopOnSymbols(List<Iterable<String>> symbolNames) {
        validateStopConditions(symbolNames);

        isForceStopping = true;
        changeState(ReelGroupState.STOPPING);
        stopReels(IReel::forceStopOnSymbols, symbolNames, forceStopOnSymbolsSequenceProvider);
    }

    /**
     * Starts stopping reels, used for stop reels in gently and forcibly way.
     * @param reelDelegate stopping action used on a reel
     * @param symbolNames  collection of symbol names on which reels should stop
     * @param stopStrategy stop strategy
     */
    private void stopReels(final Action2<IReel, Iterable<String>> reelDelegate, final List<Iterable<String>> symbolNames, IReelSequenceProvider stopStrategy) {
        if (reelGroupState == ReelGroupState.IDLE) {
            int index = 0;
            for (IReel reel : reels) {
                reelDelegate.call(reel, symbolNames.get(index));
                index++;
            }
        } else {
            removeCurrentSubscription();
            currentStrategySubscription = stopStrategy.createSequence(reels).subscribe(reel -> reelDelegate.call(reel, symbolNames.get(getReelIndex(reel))));
        }
    }

    @Override
    public void setSpinSequenceProvider(IReelSequenceProvider spinSequenceProvider) {
        if (spinSequenceProvider == null) {
            throw new IllegalArgumentException("Spin sequence strategy can not be null");
        }
        this.spinSequenceProvider = spinSequenceProvider;
    }

    @Override
    public void setStopOnSymbolsSequenceProvider(IReelSequenceProvider stopOnSymbolsSequenceProvider) {
        if (stopOnSymbolsSequenceProvider == null) {
            throw new IllegalArgumentException("Stop on symbols sequence strategy can not be null");
        }
        this.stopOnSymbolsSequenceProvider = stopOnSymbolsSequenceProvider;
    }

    @Override
    public void setForceStopOnSymbolsSequenceProvider(IReelSequenceProvider forceStopOnSymbolsSequenceProvider) {
        if (forceStopOnSymbolsSequenceProvider == null) {
            throw new IllegalArgumentException("Force stop on symbols sequence strategy can not be null");
        }
        this.forceStopOnSymbolsSequenceProvider = forceStopOnSymbolsSequenceProvider;
    }

    @Override
    public void setShowSymbolAnimationsStrategy(IShowSymbolAnimationsStrategy showSymbolAnimationsStrategy) {
        if (showSymbolAnimationsStrategy == null) {
            throw new IllegalArgumentException("Show symbol animations strategy can not be null");
        }
        this.showSymbolAnimationsStrategy = showSymbolAnimationsStrategy;
    }

    @Override
    public void setHideSymbolAnimationsStrategy(IHideSymbolAnimationsStrategy hideSymbolAnimationsStrategy) {
        if (hideSymbolAnimationsStrategy == null) {
            throw new IllegalArgumentException("Hide symbol animations strategy can not be null");
        }
        this.hideSymbolAnimationsStrategy = hideSymbolAnimationsStrategy;
    }

    @Override
    public void showWinningSymbols(List<? extends IWinLineInfo> winningLines) {
        if (reelGroupState != ReelGroupState.IDLE) {
            throw new IllegalStateException(
                    StringUtility.format("Can not show winning symbols, because reel is not in idle state, current state: %s", reelGroupState));
        }
        changeState(ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS);
        currentStrategySubscription = showSymbolAnimationsStrategy.showAnimations(winningLines, this).subscribe(new CompletedObserver<IReelGroup>() {

            @Override
            public void onCompleted() {
                removeCurrentSubscription();
                changeState(ReelGroupState.SHOWING_WINNING_SYMBOLS);
            }
        });
    }

    @Override
    public void terminateStartsShowingWinningSymbols() {
        if (reelGroupState != ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS) {
            throw new IllegalStateException(StringUtility
                    .format("Can not terminate starts showing winning symbols, because reel are not in that state, current state is: %s", reelGroupState));
        }
        showSymbolAnimationsStrategy.terminate();
    }

    @Override
    public void stopSymbolAnimations() {
        if (reelGroupState != ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS && reelGroupState != ReelGroupState.SHOWING_WINNING_SYMBOLS) {
            throw new IllegalStateException(StringUtility
                    .format("Can not stop winning symbols, because reel group state is not in: start or showing winning symbols state, current state: %s",
                            reelGroupState));
        }
        if (reelGroupState == ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS) {
            removeCurrentSubscription();
            showSymbolAnimationsStrategy.terminate();
        }
        changeState(ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS);
        currentStrategySubscription = hideSymbolAnimationsStrategy.hideAnimations(this).subscribe(new CompletedObserver<IReelGroup>() {

            @Override
            public void onCompleted() {
                removeCurrentSubscription();
                changeState(ReelGroupState.IDLE);
            }
        });
    }

    @Override
    public void forceStopSymbolAnimations() {
        if (reelGroupState != ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS) {
            stopSymbolAnimations();
        }
        if (reelGroupState == ReelGroupState.STARTS_HIDING_WINNING_SYMBOLS) {
            removeCurrentSubscription();
            hideSymbolAnimationsStrategy.terminate();
            changeState(ReelGroupState.IDLE);
        }
    }

    @Override
    public void reset() {
        reels.forEach(IResetable::reset);
        isForceStopping = false;
    }

    /**
     * Validates the stop conditions.
     * @param symbolNames collection of symbol names
     */
    private void validateStopConditions(List<Iterable<String>> symbolNames) {
        if (reels == null) {
            throw new IllegalStateException("Can not stop reels on the specific symbols, because reels are not set.");
        }

        if (symbolNames == null) {
            throw new IllegalArgumentException("Can not stop reels on the specific symbols, because symbol names can not be null.");
        }

        if (symbolNames.size() != reels.size()) {
            throw new IllegalArgumentException(
                    "Can not stop reels on the specific symbols, because the size of collection it is not the same as the number of reels.");
        }

        if (reelGroupState == ReelGroupState.SHOWING_WINNING_SYMBOLS || reelGroupState == ReelGroupState.STARTS_SHOWING_WINNING_SYMBOLS) {
            throw new IllegalStateException("Can not stop reels on the specific symbols, because reels are in showing winning symbols state");
        }

        if (isForceStopping) {
            throw new IllegalStateException("Can not stop reels on specific symbols, because they are already in stopping phase.");
        }
    }

    /**
     * Unregisters from current active strategy and cleans reference.
     */
    private void removeCurrentSubscription() {
        if (currentStrategySubscription != null) {
            currentStrategySubscription.unsubscribe();
        }
        currentStrategySubscription = null;
    }

    /**
     * Gets specific the reel index in this group.
     * @param reel IReel
     * @return the reel index
     */
    private int getReelIndex(IReel reel) {
        return reelsIndices.get(reel).intValue();
    }
}
