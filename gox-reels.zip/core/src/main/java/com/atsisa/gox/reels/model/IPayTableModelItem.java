package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

/**
 * Exposes methods for pay table model item.
 */
public interface IPayTableModelItem {

    /**
     * Gets the name of the item.
     * @return the name of the item
     */
    String getName();

    /**
     * Gets the item value as BigDecimal.
     * @return the item value
     */
    BigDecimal getValue();

    /**
     * Gets the type of this item.
     * @return the pay table item type
     */
    PayTableModelItemType getType();
}
