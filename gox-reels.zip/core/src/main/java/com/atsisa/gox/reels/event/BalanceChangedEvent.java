package com.atsisa.gox.reels.event;

import java.math.BigDecimal;

import com.atsisa.gox.reels.model.IAccount;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * An event triggered when a {@link IAccount}'s balance
 * changes.
 */
@Reflect_Mini
public final class BalanceChangedEvent {

    /**
     * The balance.
     */
    private final BigDecimal balance;

    /**
     * Initializes a new instance of the {@link BalanceChangedEvent} class.
     * @param balance      The balance.
     */
    public BalanceChangedEvent(BigDecimal balance) {
        this.balance = balance;
    }

    /**
     * Gets the actual committed balance of this account.
     * @return The actual committed balance of this account.
     */
    public BigDecimal getBalance() {
        return balance;
    }

}
