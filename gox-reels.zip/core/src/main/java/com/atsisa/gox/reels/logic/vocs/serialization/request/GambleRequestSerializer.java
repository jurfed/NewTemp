package com.atsisa.gox.reels.logic.vocs.serialization.request;

import com.atsisa.gox.framework.serialization.XmlBuilder;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;

/**
 * Represents a serializer for gamble request.
 */
public class GambleRequestSerializer implements ISerializer<GambleRequest, XmlObject> {

    @Override
    public XmlObject serialize(GambleRequest request) {
        return createBasicXmlDescription(request);
    }

    /**
     * Creates and returns basic serialized description object for gamble request.
     * @return basic description object
     */
    static XmlObject createBasicXmlDescription(GambleRequest request) {
        return new XmlBuilder().startElement("nrgs").startElement("req").startElement("a").writeValue(request.getSelectionName()).endElement().endElement()
                .endElement().toXmlObject();
    }

}
