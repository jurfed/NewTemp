package com.atsisa.gox.reels.view;

import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * Represents a win line.
 */
public interface IWinLine {

    /**
     * Updates the line score and displays it provided that the line
     * is in the {@link WinLineState#SHOWN_WINNING} state.
     * @param score A pre-formatted win line score.
     */
    void updateWinScore(String score);

    /**
     * Shows the win line.
     * @param winLineInfo The winning line data model.
     */
    void showWin(IWinLineInfo winLineInfo);

    /**
     * Hides the win line.
     */
    void hideWin();

    /**
     * Gets the state of this line.
     * @return A state described by in the {@link WinLineState}.
     */
    WinLineState getState();

    /**
     * Sets the state of this line.
     * @param state A state described by in the {@link WinLineState}.
     */
    void setState(WinLineState state);

    /**
     * Gets the number of this line.
     * @return The number of this line.
     */
    int getLineNumber();

    /**
     * Sets the number of this line.
     * @param lineNumber The number of this line.
     */
    void setLineNumber(int lineNumber);
}
