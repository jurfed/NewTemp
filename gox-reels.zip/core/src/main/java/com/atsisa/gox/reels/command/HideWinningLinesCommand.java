package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for hiding all winning lines.
 */
@Reflectable
public final class HideWinningLinesCommand {

}
