package com.atsisa.gox.reels.exception;

/**
 * Runtime exception for reel strip definition provider.
 */
public class ReelStripDefinitionProviderException extends RuntimeException {

    /**
     * Initializes a new instance of the ReelStripDefinitionProviderException class.
     * @param message - String
     */
    public ReelStripDefinitionProviderException(String message) {
        super(message);
    }

}
