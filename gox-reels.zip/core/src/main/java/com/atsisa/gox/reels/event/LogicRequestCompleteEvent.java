package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * Triggered when request to the logic has been completed.
 */
@Reflectable
public class LogicRequestCompleteEvent {

    /**
     * Collection of the results from the logic.
     */
    private Iterable<Object> logicResults;

    /**
     * Initializes a new instance of the {@link LogicRequestCompleteEvent} class.
     * @param logicResults collection of the logic results
     */
    public LogicRequestCompleteEvent(Iterable<Object> logicResults) {
        this.logicResults = logicResults;
    }

    /**
     * Gets the collection of the logic results.
     * @return the collection of the logic results
     */
    public Iterable<Object> getLogicResults() {
        return logicResults;
    }

}
