package com.atsisa.gox.reels.command;

import com.atsisa.gox.reels.model.IErrorModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * A request to handle game error.
 */
@Reflectable
public class GameErrorCommand {

    /**
     * An error model.
     */
    private final IErrorModel errorModel;

    /**
     * Initializes a new instance of the {@link GameErrorCommand} class.
     * @param errorModel {@link IErrorModel}
     */
    public GameErrorCommand(IErrorModel errorModel) {
        this.errorModel = errorModel;
    }

    /**
     * Gets an error model.
     * @return an error model
     */
    public IErrorModel getErrorModel() {
        return errorModel;
    }
}
