package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

/**
 * Represents the configuration of reel game gambler.
 */
public interface IGamblerModel {

    /**
     * Gets current gambler history size.
     * @return int
     */
    int getGamblerHistorySize();

    /**
     * Gets the maximum number of possibility cards in history.
     * @return int
     */
    int getTotalCardsInHistory();

    /**
     * Gets a collection of gambler history cards.
     * @return a collection of gambler history cards
     */
    Iterable<String> getGamblerHistory();

    /**
     * Gets defined gambler play limit.
     * @return int
     */
    int getGamblerPlayLimit();

    /**
     * Gets defined gambler win limit.
     * @return {@link BigDecimal}
     */
    BigDecimal getGamblerWinLimit();

    /**
     * Gets actual gamble win amount.
     * @return {@link BigDecimal}
     */
    BigDecimal getGamblerWinAmount();

    /**
     * Gets gambler bid amount.
     * @return {@link BigDecimal}
     */
    BigDecimal getBidAmount();

    /**
     * Gets won gambler amount. e.g. Zero when gambler lose.
     * @return {@link BigDecimal}
     */
    BigDecimal getWonAmount();

}
