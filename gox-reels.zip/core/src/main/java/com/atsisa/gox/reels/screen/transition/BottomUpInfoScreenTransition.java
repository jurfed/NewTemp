package com.atsisa.gox.reels.screen.transition;

import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.view.View;

/**
 * Represents a transition in which the previous screen goes up and reveals the next screen.
 */
public class BottomUpInfoScreenTransition extends InfoScreenTransition {

    @Override
    public void beforeTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        nextScreen.setDepth(-1);
    }

    @Override
    public IViewAnimation getTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        return getAnimationFactory().createAnimation(TweenViewAnimation.class).setTargetView(prevScreen).setDestinationY(-getHeight())
                .setTimeSpan(DEFAULT_TRANSITION_TIMESPAN);
    }

    @Override
    public void afterTransition(int prevIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        prevScreen.setY(0);
        nextScreen.setDepth(0);
    }
}
