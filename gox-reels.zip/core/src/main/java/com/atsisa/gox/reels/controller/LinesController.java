package com.atsisa.gox.reels.controller;

import java.util.HashSet;
import java.util.Set;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.reels.ClosableListening;
import com.atsisa.gox.reels.ILinesController;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.ILinesModelListener;
import com.atsisa.gox.reels.command.*;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.model.LinesModel;
import com.google.inject.Inject;

/**
 * Lines controller default implementation.
 */
public class LinesController implements ILinesController {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The set of the lines model listeners.
     */
    private final Set<ILinesModelListener> listeners = new HashSet<>();

    /**
     * The lines model.
     */
    private ILinesModel linesModel = new LinesModel();

    /**
     * Creates a new instance of the {@link LinesController} class.
     * @param eventBus the event bus.
     */
    @Inject
    public LinesController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new LinesModelChangeObserver(), LinesModelChangedEvent.class);
    }

    @Override
    public ILinesModel getModel() {
        return linesModel;
    }

    @Override
    public synchronized void setLines(int linesAmount) throws IllegalArgumentException {
        if (contains(linesModel.getAvailableLines(), linesAmount)) {
            eventBus.post(new SetLinesCommand(linesAmount, true));
        } else {
            throw new IllegalArgumentException("Available lines do not contain requested lines amount. Requested lines: " + linesAmount);
        }
    }

    @Override
    public synchronized void nextLines() {
        eventBus.post(new NextLinesCommand(true));
    }

    @Override
    public synchronized void previousLines() {
        eventBus.post(new PreviousLinesCommand(true));
    }

    @Override
    public ClosableListening addModelListener(ILinesModelListener listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    private void notifyListeners(ILinesModel linesModel) {
        for (ILinesModelListener listener : listeners) {
            listener.modelChanged(linesModel);
        }
    }

    /**
     * Check if acceptable bet steps contains given bet.
     * @param availableLines acceptable lines values.
     * @param requestedLines requested lines amount.
     * @return {@code true} if acceptable lines values contains requested lines amount.
     */
    private boolean contains(Iterable<Integer> availableLines, Integer requestedLines) {
        for (Integer lines : availableLines) {
            if (requestedLines.compareTo(lines) == 0) {
                return true;
            }
        }
        return false;
    }

    private class LinesModelChangeObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(LinesModelChangedEvent linesModelChangedEvent) {
            linesModel = linesModelChangedEvent.getLinesModel();
            notifyListeners(linesModel);
        }
    }
}
