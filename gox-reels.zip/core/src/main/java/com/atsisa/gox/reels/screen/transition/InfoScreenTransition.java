package com.atsisa.gox.reels.screen.transition;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.screen.InfoScreen;

/**
 * Describes transitions between info screen views.
 */
public abstract class InfoScreenTransition {

    /**
     * Default transition time span.
     */
    public static final float DEFAULT_TRANSITION_TIMESPAN = 1000f;

    /**
     * Info screen reference.
     */
    private InfoScreen infoScreen;

    /**
     * The animation factory.
     */
    private IAnimationFactory animationFactory;

    /**
     * Called just before the transition between prevScreen and nextScreen.
     * After this setMethod, the next screen will change visibility, will be visible
     * and then animated according to the getTransition setMethod.
     * @param prevScreenIdx previous screen index
     * @param prevScreen    previous screen
     * @param nextScreenIdx next screen index
     * @param nextScreen    next screen
     */
    public abstract void beforeTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen);

    /**
     * Gets an animation object which should be used for transition between prevScreen and nextScreen.
     * The animation can refer to either prevScreen or nextScreen, but not both.
     * @param prevScreenIdx previous screen index
     * @param prevScreen    previous screen
     * @param nextScreenIdx next screen index
     * @param nextScreen    next screen
     * @return an animation object
     */
    public abstract IViewAnimation getTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen);

    /**
     * Called just after the transition is finished.
     * At this point the prevScreen view will already be hidden, with its visibility set to false.
     * @param prevScreenIdx previous screen index
     * @param prevScreen    previous screen
     * @param nextScreenIdx next screen index
     * @param nextScreen    next screen
     */
    public abstract void afterTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen);

    /**
     * Gets the corresponding info screen.
     * @return corresponding info screen
     */
    public InfoScreen getInfoScreen() {
        return infoScreen;
    }

    /**
     * Sets the corresponding info screen.
     * @param infoScreen the corresponding info screen
     */
    public void setInfoScreen(InfoScreen infoScreen) {
        this.infoScreen = infoScreen;
    }

    /**
     * Gets the animation factory.
     * @return The animationFactory.
     */
    public IAnimationFactory getAnimationFactory() {
        return animationFactory;
    }

    /**
     * Sets the animation factory.
     * @param animationFactory The animation factory.
     */
    public void setAnimationFactory(IAnimationFactory animationFactory) {
        this.animationFactory = animationFactory;
    }

    /**
     * Gets the height of the layout's root view.
     * @return the height of the layout's root view
     */
    protected float getHeight() {
        return infoScreen.getLayout().getRootView().getHeight();
    }

    /**
     * Gets the width of the layout's root view.
     * @return the width of the layout's root view
     */
    protected float getWidth() {
        return infoScreen.getLayout().getRootView().getWidth();
    }
}
