package com.atsisa.gox.reels.logic.vocs;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.HttpRequest;
import com.atsisa.gox.framework.net.HttpResponse;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.utility.Callback;
import com.atsisa.gox.reels.logic.GameLogicException;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.RequestSerializationStrategyDelegate;
import com.atsisa.gox.reels.logic.vocs.serialization.ResponseSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;

import rx.Observable;
import rx.Subscriber;

/**
 * Represents an logic wrapper that integrates with Vocs server.
 */
public abstract class AbstractGameLogic {

    /**
     * Reference to the network implementation.
     */
    private final INetwork network;

    /**
     * Reference to the configuration implementation.
     */
    private final IConfiguration configuration;

    /**
     * Response serializer strategy.
     */
    private ResponseSerializationStrategy responseSerializationStrategy;

    /**
     * Contains serializers for requests.
     */
    private RequestSerializationStrategyDelegate requestSerializerDelegate;

    /**
     * {@link IPlatform} reference.
     */
    private IPlatform platform;

    /**
     * Initializes a new instance of the {@link AbstractGameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configuration           {@link IConfiguration}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    public AbstractGameLogic(IParser xmlParser, INetwork network, IConfiguration configuration, Set<IResponseSerializationStrategy> presentationSerializers,
            IPlatform platform) {
        this.network = network;
        this.configuration = configuration;
        this.platform = platform;
        requestSerializerDelegate = new RequestSerializationStrategyDelegate();
        responseSerializationStrategy = new ResponseSerializationStrategy(xmlParser, presentationSerializers);
    }

    /**
     * Registers other request serializers.
     * @param key        request type
     * @param serializer {@link ISerializer}
     */
    protected void registerRequestSerializer(Class key, ISerializer serializer) {
        requestSerializerDelegate.registerRequestSerializer(key, serializer);
    }

    /**
     * Prepares request before sending it to the server.
     * @param request info about request
     * @param uri     uri to call
     * @param method  {@link HttpMethod}
     * @param headers map of headers
     * @param <T>     observable type
     * @return the observable result
     */
    protected <T> Observable<T> sendLogicRequest(Object request, String uri, HttpMethod method, Map<String, String> headers) {
        try {
            HttpRequest httpRequest = network.getHttpRequest(uri, method);
            httpRequest.setContent(requestSerializerDelegate.serialize(request));
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpRequest.addHeader(entry.getKey(), entry.getValue());
            }
            Observable<HttpResponse> httpResponse = sendRequest(httpRequest);
            return httpResponse.flatMap(response -> Observable.create(subscriber -> {
                try {
                    handleResponse(subscriber, response.getResultAsString());
                } catch (SerializationException | GameLogicException ex) {
                    platform.invokeLaterRendering(() -> subscriber.onError(ex));
                }
                platform.invokeLaterRendering(subscriber::onCompleted);
            }));
        } catch (Exception ex) {
            return Observable.error(new GameLogicException(-1, "An error occurred during send a logic request.", null, ex));
        }
    }

    /**
     * Handles the presentation response.
     * @param subscriber     {@link Subscriber}
     * @param responseResult the presentation response
     */
    private void handleResponse(Subscriber subscriber, String responseResult) throws SerializationException {
        List<Object> deserializedObjects = responseSerializationStrategy.serialize(responseResult);
        for (Object deserializedObject : deserializedObjects) {
            platform.invokeLaterRendering(() -> subscriber.onNext(deserializedObject));
        }
    }

    /**
     * Gets the network reference.
     * @return the network reference.
     */
    protected INetwork getNetwork() {
        return network;
    }

    /**
     * Sends request to the server.
     * @param request http request
     * @return the observable result
     */
    protected Observable<HttpResponse> sendRequest(HttpRequest request) {
        return Observable.create(subscriber -> network.sendHttpRequest(request, new Callback<HttpResponse>() {

            @Override
            public void onSuccess(HttpResponse result) {
                subscriber.onNext(result);
                subscriber.onCompleted();
            }

            @Override
            public void onFailure(Throwable cause) {
                platform.invokeLaterRendering(() -> {
                    subscriber.onError(cause);
                    subscriber.onCompleted();
                });
            }
        }));
    }

    /**
     * Gets a frontend address.
     * @param key property key value
     * @return a frontend address
     */
    protected String getPropertyValue(String key) {
        Object property = configuration.getProperty(key);
        if (property == null) {
            throw new IllegalStateException("The property " + key + " is not yet available.");
        }
        return property.toString();
    }

}
