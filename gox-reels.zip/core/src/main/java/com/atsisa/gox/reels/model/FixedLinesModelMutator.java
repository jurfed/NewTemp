package com.atsisa.gox.reels.model;

import java.util.Arrays;
import java.util.Optional;

import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.IWinLineInfo;

/**
 * Modifies a lines model to a fixed number.
 */
public class FixedLinesModelMutator implements IMutator<ILinesModel> {

    /**
     * The number of lines as far as the game presentation layer is concerned.
     */
    private final int LINES_NUMBER_IN_GAME;

    /**
     * Creates a new instance of the {@link FixedLinesModelMutator} class.
     * @param numberFixedLines number of fixed lines
     */
    public FixedLinesModelMutator(final int numberFixedLines) {
        LINES_NUMBER_IN_GAME = numberFixedLines;
    }

    @Override
    public ILinesModel mutate(ILinesModel object) {
        return new FixedLinesModel(LINES_NUMBER_IN_GAME, object.getWinningLines(), object.getCurrentWinningLine());
    }

    /**
     * Defines a line model for a fixed number of lines.
     */
    private class FixedLinesModel implements ILinesModel {

        /**
         * Fixed number of lines.
         */
        private final int numberOfLines;

        /**
         * A collection of available lines.
         */
        private final Iterable<Integer> availableLines;

        /**
         * Win line infos.
         */
        private final Iterable<? extends IWinLineInfo> winningLines;

        /**
         * Current win line info.
         */
        private Optional<IWinLineInfo> currentWinningLine;

        /**
         * Initializes a new instance of the {@link FixedLinesModelMutator.FixedLinesModel} class.
         * @param numberOfLines The fixed number of lines.
         */
        private FixedLinesModel(int numberOfLines, Iterable<? extends IWinLineInfo> winningLines, Optional<IWinLineInfo> currentWinningLine) {
            this.numberOfLines = numberOfLines;
            this.winningLines = winningLines;
            availableLines = Arrays.asList(numberOfLines);
            this.currentWinningLine = currentWinningLine;
        }

        @Override
        public int getSelectedLines() {
            return numberOfLines;
        }

        @Override
        public Iterable<Integer> getAvailableLines() {
            return availableLines;
        }

        @Override
        public int getMaxLines() {
            return numberOfLines;
        }

        @Override
        public int getMinLines() {
            return numberOfLines;
        }

        @Override
        public Iterable<? extends IWinLineInfo> getWinningLines() {
            return winningLines;
        }

        @Override
        public Optional<IWinLineInfo> getCurrentWinningLine() {
            return currentWinningLine;
        }
    }
}
