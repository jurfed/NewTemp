package com.atsisa.gox.reels.logic.presentation;

import java.util.List;

import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.Reel;

/**
 * Represents a base presentation for reel games.
 */
public class ReelGamePresentation extends LogicPresentation {

    /**
     * The gameplay properties.
     */
    private final GameplayProperties gameplayProperties;

    /**
     * The array of reels.
     */
    private final List<Reel> reels;

    /**
     * Initializes a new instance of the {@link ReelGamePresentation} class.
     * @param name               the presentation name
     * @param gameplayProperties {@link GameplayProperties}
     * @param reels              the reels
     * @param resumed            a boolean value that indicates whether this presentation is resumed or not.
     * @param history            a boolean value that indicates whether this presentation is history or not.
     */
    public ReelGamePresentation(String name, GameplayProperties gameplayProperties, List<Reel> reels, boolean resumed, boolean history) {
        super(name, resumed, history);
        this.gameplayProperties = gameplayProperties;
        this.reels = reels;
    }

    /**
     * Gets a gameplay properties.
     * @return a gameplay properties
     */
    public GameplayProperties getGameplayProperties() {
        return gameplayProperties;
    }

    /**
     * Gets reels.
     * @return the reels
     */
    public List<Reel> getReels() {
        return reels;
    }
}
