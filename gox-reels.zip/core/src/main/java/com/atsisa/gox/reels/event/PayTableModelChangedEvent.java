package com.atsisa.gox.reels.event;

import java.util.List;

import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.gwtent.reflection.client.Reflectable;

@Reflectable
public class PayTableModelChangedEvent {

    /*
     * IPayTableModelItem collection
     */
    private final List<IPayTableModelItem> values;

    /**
     * Initializes a new instance of the {@link PayTableModelChangedEvent} class.
     * @param values the most recent IPayTableModelItem collection.
     */
    public PayTableModelChangedEvent(List<IPayTableModelItem> values) {
        this.values = values;
    }

    /*
     * Gets IPayTableModelItem collection
     */
    public List<IPayTableModelItem> getValues() {
        return values;
    }
}
