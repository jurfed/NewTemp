package com.atsisa.gox.reels.model;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.utility.localization.AbstractLocalization;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.reels.event.HistoryCloseEvent;
import com.atsisa.gox.reels.event.HistoryModelChangedEvent;
import com.atsisa.gox.reels.logic.HistoryResult;
import com.atsisa.gox.reels.logic.model.HistoryInfo;
import com.google.inject.Inject;

/**
 * Handles all aspect of game history configuration.
 */
public class HistoryModelProvider implements IHistoryModelProvider {

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The history model.
     */
    private HistoryModel historyModel;

    /**
     * Reference to the localization.
     */
    private final ILocalization localization;

    /**
     * Initializes a new instance of the {@link HistoryModelProvider} class using the
     * specified event bus to subscribe and post to.
     * @param eventBus {@link IEventBus}
     * @param localization {@link AbstractLocalization}
     */
    @Inject
    public HistoryModelProvider(IEventBus eventBus, ILocalization localization) {
        this.eventBus = eventBus;
        historyModel = new HistoryModel();
        this.localization = localization;
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new HistoryCloseEventObserver(), HistoryCloseEvent.class);
        eventBus.register(new HistoryResultObserver(), HistoryResult.class);
    }

    /**
     * Handles history result.
     * @param historyResult history result
     */
    private void handleHistoryResult(HistoryResult historyResult) {
        HistoryInfo historyInfo = historyResult.getHistoryInfo();
        historyModel.setTotalNumberPages(historyInfo.getTotalNumberPages());
        historyModel.setActivePageDate(localization.parseDate(historyInfo.getHistoryDate()));
        historyModel.setActivePageNumber(historyInfo.getPageNumber());
        notifyModelChanged(historyResult);
    }

    /**
     * Handles event about history was closed.
     * @param historyCloseEvent {@link HistoryModelChangedEvent}
     */
    private void handleExitHistory(HistoryCloseEvent historyCloseEvent) {
        historyModel.clear();
        notifyModelChanged(historyCloseEvent);
    }

    /**
     * Publishes an event regarding history model changes.
     * @param sourceEvent The source message which changed
     */
    private void notifyModelChanged(Object sourceEvent) {
        HistoryModelChangedEvent historyModelChangedEvent = new HistoryModelChangedEvent(historyModel);
        historyModelChangedEvent.setSourceEvent(sourceEvent);
        eventBus.post(historyModelChangedEvent);
    }

    @Override
    public IHistoryModel getHistoryModel() {
        return historyModel;
    }

    private class HistoryCloseEventObserver extends NextObserver<HistoryCloseEvent> {

        @Override
        public void onNext(HistoryCloseEvent historyCloseEvent) {
            handleExitHistory(historyCloseEvent);
        }
    }

    private class HistoryResultObserver extends NextObserver<HistoryResult> {

        @Override
        public void onNext(HistoryResult item) {
            handleHistoryResult(item);
        }
    }
}