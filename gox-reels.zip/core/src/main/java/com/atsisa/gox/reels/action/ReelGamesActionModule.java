package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.AbstractActionModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the reel games action types which could be created declaratively using XML.
 */
@Reflect_Mini
public class ReelGamesActionModule extends AbstractActionModule {

    /**
     * Core actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/reels/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        /* Actions connected with requests to server */
        registerAction("SendInitRequest", SendInitRequestAction.class);
        registerAction("SendBetRequest", SendBetRequestAction.class);
        registerAction("SendGambleRequest", SendGambleRequestAction.class);
        registerAction("SendBetRedRequest", SendBetRedRequestAction.class);
        registerAction("SendBetBlackRequest", SendBetBlackRequestAction.class);
        registerAction("SendTakeWinRequest", SendTakeWinRequestAction.class);

        /* Actions connected with symbols */
        registerAction("DisplayStoppedSymbols", DisplayStoppedSymbolsAction.class);
        registerAction("StartAnimationWinningSymbols", StartAnimationWinningSymbolsAction.class);
        registerAction("StopAnimationWinningSymbols", StopAnimationWinningSymbolsAction.class);

        registerAction("SpinReels", SpinReelsAction.class);
        registerAction("StopReels", StopReelsAction.class);
        registerAction("UpdateMessageArea", UpdateMessageAreaAction.class);
        registerAction("UpdatePresentation", UpdatePresentationAction.class);

        registerAction("StartWinToBalanceAnimation", StartWinToBalanceAnimationAction.class);
        registerAction("ShowNextWinningLine", ShowNextWinningLineAction.class);
        registerAction("WinningLinesBundle", WinningLinesBundleAction.class);
        registerAction("HideWinningLines", HideWinningLinesAction.class);
        registerAction("PlayCurrentWinningLineSound", PlayCurrentWinningLineSoundAction.class);
        registerAction("CleanWinningLines", CleanWinningLinesAction.class);
        registerAction("WinningBundle", WinningBundleAction.class);

        registerAction("UpdateGamblerHistoryCards", UpdateGamblerHistoryCardsAction.class);
        registerAction("UpdateGamblerScreen", UpdateGamblerScreenAction.class);
        registerAction("ShowSelectedGamblerCard", ShowSelectedGamblerCardAction.class);
        registerAction("HideSelectedGamblerCard", HideSelectedGamblerCardAction.class);
        registerAction("PlayGamblerFlipCardSound", PlayGamblerFlipCardSoundAction.class);
        registerAction("ResetGambler", ResetGamblerAction.class);

        registerAction("ExecuteNextDependingOnAutoPlay", ExecuteNextDependingOnAutoPlayAction.class);
        registerAction("StopAutoPlay", StopAutoPlayAction.class);
        registerAction("AutoPlayBundle", AutoPlayBundleAction.class);

        registerAction("ShowInfoScreen", ShowInfoScreenAction.class);

        /* History actions */
        registerAction("SendEnterHistoryRequest", SendEnterHistoryRequestAction.class);
        registerAction("SendExitHistoryRequest", SendExitHistoryRequestAction.class);
        registerAction("ShowPreviousHistoryPageRequest", ShowPreviousHistoryPageRequestAction.class);
        registerAction("ShowNextHistoryPageRequest", ShowNextHistoryPageRequestAction.class);
    }
}
