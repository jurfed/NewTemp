package com.atsisa.gox.reels.logic.vocs.serialization.response;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.logic.HistoryResult;
import com.atsisa.gox.reels.logic.vocs.serialization.XmlDeserializer;

/**
 * Response strategy for game history presentations.
 */
public class HistorySerializationStrategy implements IResponseSerializationStrategy<HistoryResult> {

    @Override
    public boolean isPresentationSupported(String presentationName, XmlObject xmlObject) {
        return xmlObject.findOne("//nrgs/h") != null;
    }

    @Override
    public HistoryResult serialize(XmlObject input) throws SerializationException {
        return new HistoryResult(XmlDeserializer.deserializeHistoryInfo(input));
    }
}
