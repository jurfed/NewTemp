package com.atsisa.gox.reels.logic.vocs;

import java.util.Map;

/**
 * The response model of the GetInitialParameters call.
 */
public class InitialParametersResponse {

    /**
     * Game instance identifier key.
     */
    private static final String GAME_INSTANCE_ID = "gameInstanceId";

    /**
     * Game server address key.
     */
    private static final String GAME_SERVER_ADDRESS = "gameServerAddress";

    /**
     * Initial parameters.
     */
    private final Map<String, String> parameters;

    /**
     * Initialize new instance of the {@link InitialParametersResponse} class.
     * @param parameters initial parameters
     */
    public InitialParametersResponse(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    /**
     * Gets the game instance id.
     * @return the game instance id
     */
    public String getGameInstanceId() {
        return parameters.get(GAME_INSTANCE_ID);
    }

    /**
     * Gets the game server address.
     * @return the game server address
     */
    public String getGameServerAddress() {
        return parameters.get(GAME_SERVER_ADDRESS);
    }
}
