package com.atsisa.gox.reels.model;

import java.math.BigDecimal;
import java.util.LinkedList;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.atsisa.gox.reels.event.BalanceChangedEvent;
import com.atsisa.gox.reels.event.CurrencyCodeChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;
import com.google.inject.Inject;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * The default implementation of player's financial account.
 */
@Reflect_Mini
public class Account implements IAccount {

    /**
     * Transaction history length.
     */
    private static final int TRANSACTION_HISTORY_LENGTH = 5;

    /**
     * Template message for logger.
     */
    private static final String BALANCE_DEBUG_TEMPLATE_MESSAGE = "Account | Balance: %s, PendingBalance: %s";

    /**
     * The event bus.
     */
    private final IEventBus eventBus;

    /**
     * The logger.
     */
    private final ILogger logger;

    /**
     * The currency code.
     */
    private String currencyCode;

    /**
     * The balance.
     */
    private BigDecimal balance;

    /**
     * The pending balance.
     */
    private BigDecimal pendingBalance;

    /**
     * The pending balance history.
     */
    private LinkedList<BigDecimal> transactionHistory;

    /**
     * The credits formatter.
     */
    private ICreditsFormatter creditsFormatter;

    /**
     * Initializes a new instance of the {@link Account} class.
     * @param eventBus         {@link IEventBus}
     * @param logger           {@link ILogger}
     * @param creditsFormatter {@link ICreditsFormatter}
     */
    @Inject
    public Account(IEventBus eventBus, ILogger logger, ICreditsFormatter creditsFormatter) {
        this.eventBus = eventBus;
        this.logger = logger;
        this.creditsFormatter = creditsFormatter;
        currencyCode = "";
        balance = BigDecimal.ZERO;
        pendingBalance = balance;
        transactionHistory = new LinkedList<>();
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new ReelGamePresentationObserver(), ReelGamePresentation.class);
        eventBus.register(new WinningPresentationObserver(), WinningPresentation.class);
        eventBus.register(new TransferCreditsCommandObserver(), TransferCreditsCommand.class);
    }

    @Override
    public String getCurrencyCode() {
        return currencyCode;
    }

    @Override
    public BigDecimal getBalance() {
        return balance;
    }

    @Override
    public BigDecimal getPendingBalance() {
        return pendingBalance;
    }

    @Override
    public Iterable<BigDecimal> getTransactionHistory() {
        return transactionHistory;
    }

    @Override
    public ICreditsFormatter getCreditsFormatter() {
        return creditsFormatter;
    }

    /**
     * Updates remaining credits according to the latest presentation response.
     * @param presentation The latest game server's presentation response.
     */
    @Subscribe
    public void handleReelGamePresentation(ReelGamePresentation presentation) {
        BigDecimal newBalance = presentation.getGameplayProperties().getCreditAmount();
        if (presentation.isResumed() || presentation.isHistory() || balance.compareTo(BigDecimal.ZERO) == 0) {
            updateBalance(newBalance);
        } else {
            processTransaction(newBalance.subtract(pendingBalance));
        }
        pendingBalance = newBalance;
        logger.debug(BALANCE_DEBUG_TEMPLATE_MESSAGE, balance, pendingBalance);
    }

    /**
     * Stores pending balance.
     * @param pendingBalance {@link BigDecimal}
     */
    private void processTransaction(BigDecimal pendingBalance) {
        if (pendingBalance.equals(BigDecimal.ZERO)) {
            return;
        }
        transactionHistory.addFirst(pendingBalance);
        if (transactionHistory.size() > TRANSACTION_HISTORY_LENGTH) {
            transactionHistory.removeLast();
        }
    }

    /**
     * Handles Init result and updates initial settings.
     * @param initResult {@link InitResult}
     */
    @Subscribe
    public void handleInitResult(InitResult initResult) {
        String newCurrencyCode = initResult.getGameConfiguration().getCurrencyCode();
        if (currencyCode.equals(newCurrencyCode)) {
            return;
        }
        currencyCode = newCurrencyCode;
        creditsFormatter.setCurrencyCode(currencyCode);
        eventBus.post(new CurrencyCodeChangedEvent(currencyCode));
    }

    /**
     * Handles the winning presentation.
     * @param winningPresentation {@link WinningPresentation}
     */
    @Subscribe
    public void handleWinningPresentation(WinningPresentation winningPresentation) {
        if (winningPresentation.isResumed()) {
            processTransaction(winningPresentation.getWinAmount());
        }
    }

    /**
     * Updates balance and sends proper notifications.
     * @param newBalance A new balance.
     * @return True if the balance was actually changed, false otherwise.
     */
    private boolean updateBalance(BigDecimal newBalance) {
        if (balance.equals(newBalance)) {
            return false;
        }
        balance = newBalance;
        logger.debug(BALANCE_DEBUG_TEMPLATE_MESSAGE, balance, pendingBalance);
        notifyBalanceChanged();
        return true;
    }

    /**
     * Notifies that the balance has been changed.
     */
    private void notifyBalanceChanged() {
        eventBus.post(new BalanceChangedEvent(balance));
    }

    /**
     * Handles credits transfers.
     * @param transferCreditsCommand an credits transfer request.
     */
    @Subscribe
    public void handleTransferCreditsCommand(TransferCreditsCommand transferCreditsCommand) {
        BigDecimal newBalance = balance.add(transferCreditsCommand.getAmount());
        if (newBalance.compareTo(BigDecimal.ZERO) >= 0) {
            updateBalance(newBalance);
        } else {
            logger.warn("Unable to transfer credits. Not enough funds (balance: %s, transfer amount: %s)", balance.toPlainString(),
                    transferCreditsCommand.getAmount().toPlainString());
        }
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult result) {
            handleInitResult(result);
        }
    }

    private class ReelGamePresentationObserver extends NextObserver<ReelGamePresentation> {

        @Override
        public void onNext(ReelGamePresentation reelGamePresentation) {
            handleReelGamePresentation(reelGamePresentation);
        }
    }

    private class WinningPresentationObserver extends NextObserver<WinningPresentation> {

        @Override
        public void onNext(WinningPresentation winningPresentation) {
            handleWinningPresentation(winningPresentation);
        }
    }

    private class TransferCreditsCommandObserver extends NextObserver<TransferCreditsCommand> {

        @Override
        public void onNext(TransferCreditsCommand transferCreditsCommand) {
            handleTransferCreditsCommand(transferCreditsCommand);
        }
    }
}
