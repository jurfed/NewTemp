package com.atsisa.gox.reels.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.reels.logic.model.PayTableItem;

/**
 * PayTableModel class.
 */
class PayTableModel implements IPayTableModel {

    /**
     * Pay table model items.
     */
    private final Map<String, PayTableModelItem> payTableModelItems;

    /**
     * PayTableModel constructor.
     */
    public PayTableModel(Map<String, PayTableModelItem> payTableModelItems) {
        this.payTableModelItems = payTableModelItems;
    }

    /**
     * Creates PayTableModel instance from PayTable.
     * @param payTable initial pay table
     * @return pay table model
     */
    public static PayTableModel createFrom(List<PayTableItem> payTable) {
        Map<String, PayTableModelItem> values = new HashMap<>();
        if (payTable != null) {
            for (PayTableItem payTableItem : payTable) {
                values.put(payTableItem.getName(),
                        new PayTableModelItem(payTableItem.getName(), payTableItem.getScore(), PayTableModelItemType.fromString(payTableItem.getType())));
            }
        }
        return new PayTableModel(values);
    }

    /**
     * Updates PayTableModel model.
     * @param betPerLine    current bet per line
     * @param selectedLines number of lines
     * @param maxWin        possible maximum win value
     */
    public void update(BigDecimal betPerLine, int selectedLines, BigDecimal maxWin) {
        BigDecimal winValue;
        for (PayTableModelItem payTableModelItem : payTableModelItems.values()) {
            winValue = calculateValue(betPerLine, selectedLines, payTableModelItem);
            if (winValue.compareTo(maxWin) > 0) {
                winValue = maxWin;
            }
            payTableModelItem.setValue(winValue);
        }
    }

    /**
     * Calculates new value in PayTableModelItem.
     * @param betPerLine        bet value per line
     * @param selectedLines     current number selected lines
     * @param payTableModelItem pay table model item for which will be recalculated value
     */
    private BigDecimal calculateValue(BigDecimal betPerLine, int selectedLines, PayTableModelItem payTableModelItem) {
        return payTableModelItem.getOriginalValue().multiply(betPerLine)
                .multiply(BigDecimal.valueOf(payTableModelItem.getType() == PayTableModelItemType.SCATTER ? selectedLines : 1));
    }

    @Override
    public List<IPayTableModelItem> getValues() {
        return new ArrayList<>(payTableModelItems.values());
    }

    @Override
    public IPayTableModelItem getValue(String name) {
        return payTableModelItems.get(name);
    }
}
