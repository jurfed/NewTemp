package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

/**
 * Represents player's financial account.
 */
public interface IAccount {

    /**
     * Gets the currency code of this account.
     * @return A 3-letter currency code.
     */
    String getCurrencyCode();

    /**
     * Gets the actual committed balance of this account.
     * @return The actual committed balance of this account.
     */
    BigDecimal getBalance();

    /**
     * Gets the pending balance of this account.
     * @return The pending balance of this account.
     */
    BigDecimal getPendingBalance();

    /**
     * Get the history of transactions .
     * @return The history of pending balance updates.
     */
    Iterable<BigDecimal> getTransactionHistory();

    /**
     * Gets the credits formatter.
     * @return The credits formatter.
     */
    ICreditsFormatter getCreditsFormatter();
}
