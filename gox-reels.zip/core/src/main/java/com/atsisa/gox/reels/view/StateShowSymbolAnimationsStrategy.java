package com.atsisa.gox.reels.view;

import java.util.List;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.spi.IShowSymbolAnimationsStrategy;

import rx.Observable;

/**
 * Shows symbol animations, by setting the symbols to the appropriate state.
 */
@XmlElement
public class StateShowSymbolAnimationsStrategy implements IShowSymbolAnimationsStrategy {

    @Override
    public Observable<IReelGroup> showAnimations(List<? extends IWinLineInfo> winningLines, IReelGroup reelGroup) {
        int index;
        int winningLinesIndex;
        for (winningLinesIndex = 0; winningLinesIndex < winningLines.size(); winningLinesIndex++) {
            Iterable<Integer> rows = winningLines.get(winningLinesIndex).getPositions();
            index = 0;
            for (int row : rows) {
                IReel reel = reelGroup.getReel(index);
                List<AbstractSymbol> displayedSymbols = reel.getDisplayedSymbols();
                if (row >= 0 && row < displayedSymbols.size()) {
                    displayedSymbols.get(row).setState(winningLines.get(winningLinesIndex).getAnimationName());
                }
                index++;
            }
        }
        return Observable.just(reelGroup);
    }

    @Override
    public void terminate() {
        //do nothing, just handle
    }

}
