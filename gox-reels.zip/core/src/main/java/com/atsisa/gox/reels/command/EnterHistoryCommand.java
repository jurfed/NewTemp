package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for enter to history.
 */
@Reflectable
public class EnterHistoryCommand {
}
