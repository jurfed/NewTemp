package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Command used to send request about take win.
 */
@Reflectable
public final class TakeWinCommand {

}
