package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.reels.view.spi.IHideSymbolAnimationsStrategy;

import rx.Observable;

/**
 * Hides symbol animations, by setting the symbols to the default state.
 */
@XmlElement
public class StateHideSymbolAnimationsStrategy implements IHideSymbolAnimationsStrategy {

    @Override
    public Observable<IReelGroup> hideAnimations(IReelGroup reelGroup) {
        for (IReel reel : reelGroup.getReels()) {
            for (AbstractSymbol abstractSymbol : reel.getDisplayedSymbols()) {
                abstractSymbol.setState(abstractSymbol.getDefaultState());
            }
        }
        return Observable.just(reelGroup);
    }

    @Override
    public void terminate() {
        //do nothing, just handle
    }

}
