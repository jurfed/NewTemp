package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.model.IGamblerModel;
import com.atsisa.gox.reels.model.IGamblerModelProvider;

/**
 * Plays gambler flip sound.
 */
public class PlayGamblerFlipCardSoundAction extends Action<PlayGamblerFlipCardSoundActionData> {

    /**
     * Instance of sound manager.
     */
    private ISoundManager soundManager;

    /**
     * Gambler model provider reference.
     */
    private IGamblerModelProvider gamblerModelProvider;

    /**
     * Reference to timeout used during blocking action.
     */
    private Timeout timeout;

    /**
     * Total length of how long sound will play.
     */
    private int soundPlayTime;

    /**
     * Id of the sound.
     */
    private String soundId;

    /**
     * Construct action with default sound manager.
     */
    public PlayGamblerFlipCardSoundAction() {
        this(GameEngine.current().getSoundManager(), ((AbstractReelGame) GameEngine.current().getGame()).getGamblerModelProvider());
    }

    /**
     * Construct action with sound manager given as parameter.
     * @param soundManager         {@link ISoundManager}
     * @param gamblerModelProvider {@link IGamblerModelProvider}
     */
    public PlayGamblerFlipCardSoundAction(ISoundManager soundManager, IGamblerModelProvider gamblerModelProvider) {
        this.soundManager = soundManager;
        this.gamblerModelProvider = gamblerModelProvider;
    }

    @Override
    public Class<PlayGamblerFlipCardSoundActionData> getActionDataType() {
        return PlayGamblerFlipCardSoundActionData.class;
    }

    @Override
    protected void grabData() {
        soundId = actionData.getSoundId();
        IGamblerModel gamblerModel = gamblerModelProvider.getGamblerModel();
        float multiplier = (float) gamblerModel.getGamblerHistorySize() / gamblerModel.getTotalCardsInHistory();
        int soundTotalLength = soundManager.length(soundId);
        int lengthToPlay = actionData.getMinSoundPlayTime() + Math.round(soundTotalLength * multiplier);
        soundPlayTime = Math.min(soundTotalLength, lengthToPlay);
    }

    @Override
    protected void execute() {
        timeout = new Timeout(soundPlayTime, new TimeoutCallback() {

            @Override
            public void onTimeout() {
                finish();
            }
        }, true);
        soundManager.play(soundId);
    }

    @Override
    protected void reset() {
        super.reset();
        timeout = null;
        soundPlayTime = 0;
        soundId = StringUtility.EMPTY;
    }

    @Override
    protected void finish() {
        soundManager.stop(soundId);
        super.finish();
    }

    @Override
    protected void terminate() {
        super.terminate();
        soundManager.stop(soundId);
        timeout.clear();
    }

}
