package com.atsisa.gox.reels.serialization.converter;

import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.framework.serialization.IParsableObject;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.converter.IValueConverter;
import com.atsisa.gox.framework.utility.StringUtility;

/**
 * Converts a positions (int[][]) object from and to string positions description.
 */
public class PositionConverter implements IValueConverter {

    /**
     * Gets the type of a value object
     * @return int[][].class
     */
    @Override
    public Class<?> getValueType() {
        return int[][].class;
    }

    /**
     * Convert positions to xml string description.
     * @param objToConvert - int[][] with positions
     * @return String - position description
     */
    @Override
    public String convertTo(Object objToConvert) {
        int[][] positions = (int[][]) objToConvert;
        int reelCount = positions.length;
        int rowCount = 0;
        if (reelCount > 0) {
            rowCount = positions[0].length;
        }
        String description = "<positions>";
        for (int i = 0; i < reelCount; ++i) {
            description = StringUtility.format("%s<reel>", description);
            for (int j = 0; j < rowCount; ++j) {
                description = StringUtility.format("%s<position>%s</position>", description, positions[i][j]);
            }
            description = StringUtility.format("%s</reel>", description);
        }
        description = StringUtility.format("%s</positions>", description);
        return description;
    }

    /**
     * Converts a string, parse object representation of positions to int[][].
     * @param serializedMessage a string representation of a Java object
     * @param parsedObject      - IParsedObject
     * @return return int[][]
     */
    @Override
    public Object convertFrom(String serializedMessage, IParsableObject parsedObject) {
        if (serializedMessage == null || parsedObject == null) {
            return null;
        }
        XmlObject xmlObject = (XmlObject) parsedObject;
        List<XmlObject> xmlChildren = xmlObject.getChildren();
        List<List<Integer>> positionsList = new ArrayList<>();

        for (XmlObject xmlChild : xmlChildren) {
            if (xmlChild.getName().equals("reel")) {
                List<XmlObject> xmlPositions = xmlChild.getChildren();
                List<Integer> intList = new ArrayList<>();
                for (XmlObject xmlPosition : xmlPositions) {
                    int position = Integer.parseInt(xmlPosition.getValue());
                    intList.add(position);
                }
                positionsList.add(intList);
            }
        }

        int reelCount = positionsList.size();
        int rowCount = 0;
        if (reelCount > 0) {
            rowCount = positionsList.get(0).size();
        }

        int[][] positions = new int[reelCount][rowCount];

        for (int i = 0; i < reelCount; ++i) {
            for (int j = 0; j < rowCount; ++j) {
                positions[i][j] = positionsList.get(i).get(j);
            }
        }

        return positions;
    }
}
