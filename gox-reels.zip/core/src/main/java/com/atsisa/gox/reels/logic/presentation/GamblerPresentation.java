package com.atsisa.gox.reels.logic.presentation;

import java.math.BigDecimal;

import com.atsisa.gox.reels.logic.model.GamblerDescriptor;

/**
 * Represents a gambler presentation for reel games.
 */
public class GamblerPresentation extends LogicPresentation {

    /**
     * Gambler won amount.
     */
    private final BigDecimal gamblerWonAmount;

    /**
     * Gambler bid amount.
     */
    private final BigDecimal gamblerBidAmount;

    /**
     * The gambler descriptor.
     */
    private final GamblerDescriptor gamblerDescriptor;

    /**
     * Initializes a new instance of the {@link GamblerPresentation} class.
     * @param name              the name of the presentation
     * @param gamblerDescriptor {@link GamblerDescriptor}
     * @param gamblerWonAmount  {@link BigDecimal}
     * @param gamblerBidAmount  {@link BigDecimal}
     * @param resumed           a boolean value that indicates whether this presentation is resumed or not.
     * @param history           a boolean value that indicates whether this presentation is history or not.
     */
    public GamblerPresentation(String name, GamblerDescriptor gamblerDescriptor, BigDecimal gamblerWonAmount, BigDecimal gamblerBidAmount, boolean resumed,
            boolean history) {
        super(name, resumed, history);
        this.gamblerWonAmount = gamblerWonAmount;
        this.gamblerBidAmount = gamblerBidAmount;
        this.gamblerDescriptor = gamblerDescriptor;
    }

    /**
     * Gets a gambler descriptor.
     * @return a gambler descriptor
     */
    public GamblerDescriptor getGamblerDescriptor() {
        return gamblerDescriptor;
    }

    /**
     * Gets gambler bid amount.
     * @return {@link BigDecimal}
     */
    public BigDecimal getBidAmount() {
        return gamblerBidAmount;
    }

    /**
     * Gets won gambler amount. e.g. zero when gambler lose.
     * @return {@link BigDecimal}
     */
    public BigDecimal getWonAmount() {
        return gamblerWonAmount;
    }
}
