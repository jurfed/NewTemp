package com.atsisa.gox.reels.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.event.CurrencyCodeChangedEvent;
import com.atsisa.gox.reels.event.PayTableModelChangedEvent;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents the pay table screen.
 */
@Reflectable
public class PayTableScreen extends Screen<PayTableScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "PayTableScreenLayoutId";

    /**
     * Initializes a new instance of {@link PayTableScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public PayTableScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, PayTableScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new PayTableModelChangedEventObserver(), PayTableModelChangedEvent.class);
        getEventBus().register(new CurrencyCodeChangedEventObserver(), CurrencyCodeChangedEvent.class);
    }

    /**
     * Handles pay table values changed.
     * @param payTableModelChangedEvent {@link PayTableModelChangedEvent}
     */
    @Subscribe
    public void handlePayTableModelChangedEvent(PayTableModelChangedEvent payTableModelChangedEvent) {
        getModel().updatePayTableValues(payTableModelChangedEvent.getValues());
    }

    /**
     * Handles the event about that the currency code has changed.
     * @param currencyCodeChangedEvent {@link CurrencyCodeChangedEvent}
     */
    @Subscribe
    public void handleCurrencyCodeChangedEvent(CurrencyCodeChangedEvent currencyCodeChangedEvent) {
        if (getModel().isCurrencyVisible()) {
            getModel().refresh();
        }
    }

    private class PayTableModelChangedEventObserver extends NextObserver<PayTableModelChangedEvent> {

        @Override
        public void onNext(final PayTableModelChangedEvent payTableModelChangedEvent) {
            handlePayTableModelChangedEvent(payTableModelChangedEvent);
        }
    }

    private class CurrencyCodeChangedEventObserver extends NextObserver<CurrencyCodeChangedEvent> {

        @Override
        public void onNext(final CurrencyCodeChangedEvent currencyCodeChangedEvent) {
            handleCurrencyCodeChangedEvent(currencyCodeChangedEvent);
        }
    }

}
