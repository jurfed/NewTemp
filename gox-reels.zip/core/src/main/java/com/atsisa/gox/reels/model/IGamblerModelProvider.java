package com.atsisa.gox.reels.model;

/**
 * Exposes the most recent reel game gambler configuration.
 */
public interface IGamblerModelProvider {

    /**
     * Gets the most recent reel game gambler configuration.
     * @return IGamblerModel
     */
    IGamblerModel getGamblerModel();
}
