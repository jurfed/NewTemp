package com.atsisa.gox.reels.logic.vocs.serialization;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;

import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.ParseException;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.framework.serialization.XmlObjectDocument;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.LogicErrorSerializer;

/**
 * Represents a serialization strategy for responses.
 */
public class ResponseSerializationStrategy implements ISerializer<String, List<Object>> {

    /**
     * Contains serializers for presentation responses.
     */
    private final Iterable<IResponseSerializationStrategy> presentationSerializers;

    /**
     * {@link IParser} reference.
     */
    private IParser xmlParser;

    /**
     * The logic error serializer.
     */
    private LogicErrorSerializer logicErrorSerializer;

    /**
     * Initializes a new instance of the {@link ResponseSerializationStrategy} class.
     * @param xmlParser               {@link IParser}
     * @param presentationSerializers the presentation serializers
     */
    public ResponseSerializationStrategy(IParser xmlParser, Set<IResponseSerializationStrategy> presentationSerializers) {
        this.xmlParser = xmlParser;
        this.presentationSerializers = presentationSerializers;
        logicErrorSerializer = new LogicErrorSerializer();
    }

    @Override
    public List<Object> serialize(String input) throws SerializationException {
        List<Object> deserializedObjects = new ArrayList<>();
        XmlObject xmlObject;
        try {
            xmlObject = ((XmlObjectDocument) xmlParser.parse(input)).getDocumentElement();
        } catch (ParseException ex) {
            throw new SerializationException("Cannot deserialize data to xml object.", ex);
        }
        Optional<String> presentationNameOptional = XmlDeserializer.tryDeserializePresentationName(xmlObject);
        if (presentationNameOptional.isPresent()) {
            for (IResponseSerializationStrategy strategy : presentationSerializers) {
                if (strategy.isPresentationSupported(presentationNameOptional.get(), xmlObject)) {
                    deserializedObjects.add(strategy.serialize(xmlObject));
                }
            }
            if (deserializedObjects.size() == 0) {
                throw new SerializationException("Cannot deserialize presentation - unknown presentation");
            }
        } else {
            throw logicErrorSerializer.serialize(xmlObject);
        }
        return deserializedObjects;
    }
}
