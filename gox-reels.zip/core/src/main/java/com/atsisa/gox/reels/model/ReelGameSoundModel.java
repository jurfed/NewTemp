package com.atsisa.gox.reels.model;

import java.util.Iterator;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.command.UserInteractionCommand;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.ReelStoppingEvent;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Handles all events related with the sounds in reel game.
 */
public class ReelGameSoundModel {

    /**
     * Name of the sound id property, used with IoC to define what is id of the sound in game for showing animation in info screens.
     */
    public static final String INFO_SCREEN_SHOW_ANIMATION_SOUND_ID_PROPERTY = "InfoScreenShowAnimationSoundId";

    /**
     * Name of the sound id property, used with IoC to define what is id of the sound in game when auto play will be turn on after user interaction.
     */
    public static final String AUTO_PLAY_ON_SOUND_ID_PROPERTY = "AutoPlayOnSoundId";

    /**
     * Name of the sound id property, used with IoC to define what is id of the sound in game when auto play will be turn off after user interaction.
     */
    public static final String AUTO_PLAY_OFF_SOUND_ID_PROPERTY = "AutoPlayOffSoundId";

    /**
     * Name of the sound id property, used with IoC to define what is id of the sound in game when bet will be changed after user interaction.
     */
    public static final String BET_CHANGING_SOUND_ID_PROPERTY = "BetChangingSoundId";

    /**
     * Local variables in methods.
     */
    private final LocalVariables lv;

    /**
     * Event bus reference.
     */
    private final IEventBus eventBus;

    /**
     * Sound manager reference.
     */
    private final ISoundManager soundManager;

    /**
     * Id of the sound which should be played out during the show info screen animation.
     */
    private String infoScreenShowAnimationSoundId;

    /**
     * Id of the sound which should be played after auto play will be turn on.
     */
    private String autoPlayTurnOnSoundId;

    /**
     * Id of the sound which should be played after auto play will be turn off.
     */
    private String autoPlayTurnOffSoundId;

    /**
     * Id of the sound which should be played after bet is changing.
     */
    private String betChangingSoundId;

    /**
     * Reel game state holder reference.
     */
    private final IReelGameStateHolder reelGameStateHolder;

    /**
     * Initializes a new instance of the {@link ReelGameSoundModel} class.
     * @param eventBus            IEventBus
     * @param soundManager        ISoundManager
     * @param reelGameStateHolder IReelGameStateHolder
     */
    @Inject
    public ReelGameSoundModel(IEventBus eventBus, ISoundManager soundManager, IReelGameStateHolder reelGameStateHolder) {
        this.eventBus = eventBus;
        this.soundManager = soundManager;
        this.reelGameStateHolder = reelGameStateHolder;
        lv = new LocalVariables();
        registerEvents();
    }

    /**
     * Sets the id of the sound which should be played out during the show info screen animation.
     * @param infoScreenShowAnimationSoundId id of the sound which should be played during showing animation
     */
    @Inject
    public void setShowAnimationSoundId(@Named(INFO_SCREEN_SHOW_ANIMATION_SOUND_ID_PROPERTY) String infoScreenShowAnimationSoundId) {
        this.infoScreenShowAnimationSoundId = infoScreenShowAnimationSoundId;
    }

    /**
     * Sets the id of the sound which should be played when auto play will be turn on.
     * @param autoPlayTurnOnSoundId id of the sound which should be played after auto play will be turn on
     */
    @Inject
    public void setAutoPlayTurnOnSoundId(@Named(AUTO_PLAY_ON_SOUND_ID_PROPERTY) String autoPlayTurnOnSoundId) {
        this.autoPlayTurnOnSoundId = autoPlayTurnOnSoundId;
    }

    /**
     * Sets the id of the sound which should be played when auto play will be turn off.
     * @param autoPlayTurnOffSoundId id of the sound which should be played after auto play will be turn off
     */
    @Inject
    public void setAutoPlayTurnOffSoundId(@Named(AUTO_PLAY_OFF_SOUND_ID_PROPERTY) String autoPlayTurnOffSoundId) {
        this.autoPlayTurnOffSoundId = autoPlayTurnOffSoundId;
    }

    /**
     * Sets the id of the sound which should be played when bet is changing.
     * @param betChangingSoundId id of the sound which should be played when bet is changing
     */
    @Inject
    public void setBetChangingSoundId(@Named(BET_CHANGING_SOUND_ID_PROPERTY) String betChangingSoundId) {
        this.betChangingSoundId = betChangingSoundId;
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new ReelStoppingObserver(), ReelStoppingEvent.class);
        eventBus.register(new ScreenShowingObserver(), ScreenShowingEvent.class);
        eventBus.register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        eventBus.register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        eventBus.register(new BetModelChangedEventObserver(), BetModelChangedEvent.class);
    }

    /**
     * Plays the stopping reel sound.
     * @param reelStoppingEvent reel stopping event
     */
    @Subscribe
    public void handleReelStopping(ReelStoppingEvent reelStoppingEvent) {
        lv.index = 0;
        lv.iterator = reelGameStateHolder.getReels().iterator();
        while (lv.iterator.hasNext()) {
            lv.reelState = lv.iterator.next();
            if (lv.index == reelStoppingEvent.getReelIndex()) {
                playSound(lv.reelState.getSoundName());
                break;
            }
            lv.index++;
        }
    }

    /**
     * Handles auto play stopped event.
     * @param autoPlayStoppedEvent {@link AutoPlayStoppedEvent}
     */
    @Subscribe
    public void handleAutoPlayStoppedEvent(AutoPlayStoppedEvent autoPlayStoppedEvent) {
        if (isTriggeredByUser(autoPlayStoppedEvent)) {
            playSound(autoPlayTurnOffSoundId);
        }
    }

    /**
     * Handles auto play started event.
     * @param autoPlayStartedEvent {@link AutoPlayStartedEvent}
     */
    @Subscribe
    public void handleAutoPlayStartedEvent(AutoPlayStartedEvent autoPlayStartedEvent) {
        if (isTriggeredByUser(autoPlayStartedEvent)) {
            playSound(autoPlayTurnOnSoundId);
        }
    }

    /**
     * Handles bet model changed event.
     * @param betModelChangedEvent {@link BetModelChangedEvent}
     */
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        if (isTriggeredByUser(betModelChangedEvent)) {
            playSound(betChangingSoundId);
        }
    }

    /**
     * Checks if specific event was triggered by user.
     * @param event event object
     * @return returns true if event is triggered by user otherwise false
     */
    private boolean isTriggeredByUser(Object event) {
        UserInteractionCommand userInteractionCommand = findUserInteractionCommand(event);
        if (userInteractionCommand != null) {
            return userInteractionCommand.isTriggeredByUser();
        }
        return false;
    }

    /**
     * Finds and returns user interaction command in specific event and its source.
     * @param event event object
     * @return user interaction command
     */
    private UserInteractionCommand findUserInteractionCommand(Object event) {
        if (event instanceof UserInteractionCommand) {
            return (UserInteractionCommand) event;
        } else if (event instanceof AbstractEvent) {
            return findUserInteractionCommand(((AbstractEvent) event).getSourceEvent());
        }
        return null;
    }

    /**
     * Reacts to start the info screen transition.
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (isTriggeredByUser(screenShowingEvent) && screenShowingEvent.getScreen() instanceof InfoScreen && !StringUtility
                .isNullOrEmpty(infoScreenShowAnimationSoundId)) {
            soundManager.play(infoScreenShowAnimationSoundId);
        }
    }

    /**
     * Plays specific sound.
     * @param id sound id
     */
    private void playSound(String id) {
        soundManager.play(id);
    }

    private class ReelStoppingObserver extends NextObserver<ReelStoppingEvent> {

        @Override
        public void onNext(ReelStoppingEvent event) {
            handleReelStopping(event);
        }
    }

    private class ScreenShowingObserver extends NextObserver<ScreenShowingEvent> {

        @Override
        public void onNext(ScreenShowingEvent event) {
            handleScreenShowingEvent(event);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(AutoPlayStoppedEvent event) {
            handleAutoPlayStoppedEvent(event);
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(AutoPlayStartedEvent event) {
            handleAutoPlayStartedEvent(event);
        }
    }

    private class BetModelChangedEventObserver extends NextObserver<BetModelChangedEvent> {

        @Override
        public void onNext(BetModelChangedEvent event) {
            handleBetModelChangedEvent(event);
        }
    }

    /**
     * Holder for instances of local variables used in the {@link ReelGameSoundModel} methods.
     */
    private class LocalVariables {

        private Reel reelState;

        private int index;

        private Iterator<Reel> iterator;
    }
}
