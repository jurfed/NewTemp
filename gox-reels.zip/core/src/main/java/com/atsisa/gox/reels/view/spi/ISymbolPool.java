package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelView;

/**
 * Manages the collection of symbols
 * ready to be displayed by the {@link ReelView}.
 */
public interface ISymbolPool {

    /**
     * Retrieves the symbol of given name from this pool.
     * @param symbolName The symbol name to retrieve.
     * @return A symbol from the pool.
     * @throws SymbolPoolException The symbol cannot be retrieved.
     */
    AbstractSymbol getSymbol(String symbolName);

    /**
     * Returns the symbol to this pool.
     * @param symbol The symbol to give back.
     * @throws SymbolPoolException The returned symbol never belonged to this pool.
     */
    void returnSymbol(AbstractSymbol symbol);

    /**
     * Gets the symbol factory this symbol pool uses to create symbols.
     * @return The symbol factory.
     */
    ISymbolFactory getSymbolFactory();

    /**
     * Gets a total number of symbols kept by this pool.
     * @return A total number of symbols kept by this pool.
     */
    int getSymbolsCount();

    /**
     * Gets a total number of symbols of given name kept by this pool.
     * @param symbolName A symbol name filter.
     * @return A total number of symbols of given name kept by this pool.
     */
    int getSymbolsCount(String symbolName);

    /**
     * Gets the strategy which is responsible for the modification on symbols.
     * @return the strategy which is responsible for the modifications on symbols
     */
    ISymbolModificationStrategy getSymbolModificationStrategy();

    /**
     * Sets the strategy which is responsible for the modification on symbols.
     * <p>
     * Each of the symbol during getSymbol will be modify using this strategy.
     * </p>
     * @param symbolmodificationStrategy {@link ISymbolModificationStrategy}
     */
    void setSymbolModificationStrategy(ISymbolModificationStrategy symbolmodificationStrategy);
}
