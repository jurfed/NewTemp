package com.atsisa.gox.reels.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.logic.model.WinLineInfo;
import com.atsisa.gox.reels.view.IWinLine;
import com.gwtent.reflection.client.Reflectable;

/**
 * Reports that a winning line has been shown.
 */
@Reflectable
public final class WinningLineShownEvent extends AbstractEvent {

    /**
     * The winning line info.
     */
    private final IWinLineInfo winningLine;

    /**
     * The win line handler.
     */
    private final IWinLine winLine;

    /**
     * Initializes a new instance of the {@link WinLineInfo} class.
     * @param winningLine the corresponding winning line info
     * @param winLine     the win line
     */
    public WinningLineShownEvent(IWinLineInfo winningLine, IWinLine winLine) {
        this.winningLine = winningLine;
        this.winLine = winLine;
    }

    /**
     * Gets the data object describing shown winning line.
     * @return the data object describing shown winning line
     */
    public IWinLineInfo getWinningLine() {
        return winningLine;
    }

    /**
     * Gets the win line which is responsible for handling the winning line data.
     * @return the win line which is responsible for handling the winning line data
     */
    public IWinLine getWinLine() {
        return winLine;
    }
}
