package com.atsisa.gox.reels.logic.vocs.serialization;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.XmlObject;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.logic.model.GamblerDescriptor;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.model.HistoryInfo;
import com.atsisa.gox.reels.logic.model.Language;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.model.PayTableItem;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.logic.model.WinLineInfo;

/**
 * Used to deserialize game presentation.
 */
public class XmlDeserializer {

    /**
     * Private constructor, prevents the creation of an instance of this class.
     */
    private XmlDeserializer() {
    }

    /**
     * Deserializes gambler description from given xml object.
     * @param xmlObject xml object with gambler description
     * @return the gambler description
     */
    public static GamblerDescriptor deserializeGamblerDescriptor(XmlObject xmlObject) {
        XmlObject presElem = xmlObject.findOne("//rsp/p");
        List<XmlObject> historyElemList = presElem.find("//h/c");
        if (historyElemList != null) {
            String[] gamblerHistory = new String[historyElemList.size()];
            int i = 0;
            for (XmlObject historyElem : historyElemList) {
                gamblerHistory[i++] = historyElem.getValue();
            }
            presElem = presElem.findOne("//ct");
            int historySize = 0;
            if (presElem != null) {
                historySize = Integer.parseInt(presElem.getValue());
            }
            return new GamblerDescriptor(gamblerHistory, historySize);
        }
        return null;
    }

    /**
     * Deserializes a won amount in the gambler xml object.
     * @param xmlObject xml object with gambler won amount
     * @return the gambler won amount
     */
    public static BigDecimal deserializeGamblerBidAmount(XmlObject xmlObject) {
        XmlObject presElem = xmlObject.findOne("//rsp/p/ga");
        if (presElem == null) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(presElem.getValue());
    }

    /**
     * Deserializes a won amount in the gambler xml object.
     * @param xmlObject xml object with gambler won amount
     * @return the gambler won amount
     */
    public static BigDecimal deserializeGamblerWonAmount(XmlObject xmlObject) {
        XmlObject presElem = xmlObject.findOne("//rsp/p/ga");
        String presentationName = deserializePresentationName(xmlObject);
        if (presElem == null || presentationName.contains(PresentationName.GAMBLER_LOSE)) {
            return BigDecimal.ZERO;
        } else if (presentationName.contains(PresentationName.GAMBLER_LIMIT)) {
            return tryDeserializeWin(xmlObject).orElseGet(() -> deserializeWon(xmlObject));
        }
        return new BigDecimal(presElem.getValue());
    }

    /**
     * Deserializes game play properties from given xml object.
     * @param xmlObject xml object with game play properties
     * @return the game play properties
     */
    public static GameplayProperties deserializeGameplayProperties(XmlObject xmlObject) {
        XmlObject presElem = xmlObject.findOne("//rsp/p");

        int linesAmount = Integer.parseInt(presElem.findOne("//l").getValue());
        BigDecimal betAmount = new BigDecimal(presElem.findOne("//b").getValue()).divide(new BigDecimal(linesAmount));
        BigDecimal creditAmount = new BigDecimal(xmlObject.findOne("//c1").getValue());

        return new GameplayProperties(linesAmount, betAmount, creditAmount);
    }

    /**
     * Deserializes history info from given xml object.
     * @param xmlObject xml object with history info
     * @return the history info
     * @throws SerializationException throws when error during deserialization will occur
     */
    public static HistoryInfo deserializeHistoryInfo(XmlObject xmlObject) throws SerializationException {
        XmlObject historyElem = xmlObject.findOne("//nrgs/h");
        int totalNumberPages = Integer.parseInt(historyElem.findOne("/ha").getValue());
        String dateInfo = historyElem.findOne("/ht").getValue();
        return new HistoryInfo(totalNumberPages, dateInfo);
    }

    /**
     * Deserializes language info from given xml object.
     * @param xmlObject xml object with languages
     * @return the language info
     */
    public static LanguageInfo deserializeLanguageInfo(XmlObject xmlObject) {
        return new LanguageInfo(deserializeLanguage(xmlObject), deserializeAvailableLanguages(xmlObject));
    }

    /**
     * Deserializes language from given xml object.
     * @param xmlObject xml object with language
     * @return the language
     */
    public static Language deserializeLanguage(XmlObject xmlObject) {
        XmlObject translElem = xmlObject.findOne("//rsp/ll");

        String langCode = translElem.getAttributes().get("l");
        Map<String, String> translationDict = new HashMap<>();
        for (XmlObject sentenceElem : translElem.getChildren()) {
            String name = sentenceElem.getAttributes().get("n");
            String value = sentenceElem.getValue();
            translationDict.put(name, value);
        }

        return new Language(langCode, translationDict);
    }

    /**
     * Deserializes reels from given xml object.
     * @param xmlObject xml object with reels
     * @return the reel list
     */
    public static List<Reel> deserializeReels(XmlObject xmlObject) {
        XmlObject xmlDescription = xmlObject.findOne("//rsp/p/sp");
        if (xmlDescription == null) {
            return new ArrayList<>();
        }
        List<XmlObject> reelDescElemList = xmlDescription.getChildren();
        List<Reel> reels = new ArrayList<>(reelDescElemList.size());
        for (XmlObject reelDescElem : reelDescElemList) {
            String soundName = reelDescElem.getAttributes().get("sd");
            List<XmlObject> positionElements = reelDescElem.getChildren();
            List<Integer> positions = new ArrayList<>(positionElements.size());
            for (XmlObject positionElem : positionElements) {
                positions.add(Integer.parseInt(positionElem.getValue()));
            }
            reels.add(new Reel(soundName, positions));
        }
        return reels;
    }

    /**
     * Deserializes winning lines from given xml object.
     * @param xmlObject xml object with win lines
     * @return the win line list
     */
    public static List<IWinLineInfo> deserializeWinningLines(XmlObject xmlObject) {
        List<XmlObject> winningLineElements = xmlObject.find("//rsp/p/wa/l");
        List<IWinLineInfo> winningLines = new ArrayList<>(winningLineElements.size());
        for (XmlObject winningLineElem : winningLineElements) {
            Map<String, String> attributes = winningLineElem.getAttributes();
            int lineId = Integer.parseInt(attributes.get("id")) + 1;
            BigDecimal score = new BigDecimal(attributes.get("sc"));
            String soundName = attributes.get("sd");

            List<XmlObject> positionElemList = winningLineElem.find("//p");
            String animationName = attributes.get("a");
            List<Integer> positions = new ArrayList<>(positionElemList.size());
            for (XmlObject positionElem : positionElemList) {
                positions.add(Integer.parseInt(positionElem.getValue()));
            }
            winningLines.add(new WinLineInfo(lineId, soundName, animationName, score, positions));
        }
        return winningLines;
    }

    /**
     * Deserializes won value from given xml object.
     * @param xmlObject xml object with won value
     * @return the won value
     */
    public static BigDecimal deserializeWon(XmlObject xmlObject) {
        XmlObject wonXmlObject = xmlObject.findOne("//rsp/p/won");
        return wonXmlObject == null ? BigDecimal.ZERO : new BigDecimal(wonXmlObject.getValue());
    }

    /**
     * Trying to deserializes win value from given xml object.
     * @param xmlObject xml object with win value
     * @return the win value
     */
    public static Optional<BigDecimal> tryDeserializeWin(XmlObject xmlObject) {
        XmlObject winXmlObject = xmlObject.findOne("//rsp/p/win");
        return winXmlObject == null ? Optional.empty() : Optional.of(new BigDecimal(winXmlObject.getValue()));
    }

    /**
     * Trying to deserializes presentation name from given xml object.
     * @param xmlObject xml object with presentation name
     * @return the presentation name
     */
    public static Optional<String> tryDeserializePresentationName(XmlObject xmlObject) {
        XmlObject presElem = xmlObject.findOne("//rsp/p");
        return presElem == null ? Optional.empty() : Optional.of(presElem.getAttribute("n"));
    }

    /**
     * Deserializes presentation name from given xml object.
     * @param xmlObject xml object with presentation name
     * @return the presentation name
     */
    public static String deserializePresentationName(XmlObject xmlObject) {
        return xmlObject.findOne("//rsp/p").getAttribute("n");
    }

    /**
     * Deserializes game configuration from given xml object.
     * @param xmlObject xml object with game configuration
     * @return the game configuration
     */
    public static GameConfiguration deserializeGameConfiguration(XmlObject xmlObject) {
        XmlObject configurationElem = xmlObject.findOne("//rsp/i");

        String currencyCode = configurationElem.findOne("//c").getValue();
        String yield = configurationElem.findOne("//y").getValue();

        Map<String, String> attributes = configurationElem.findOne("//l").getAttributes();
        BigDecimal maxBet = new BigDecimal(attributes.get("mb"));
        BigDecimal maxWin = new BigDecimal(attributes.get("mw"));
        int gamblerPlayLimit = Integer.parseInt(attributes.get("gp"));
        BigDecimal gamblerWinLimit = new BigDecimal(attributes.get("gw"));

        List<BigDecimal> betsPerLine = deserializeBetsPerLine(configurationElem);
        List<Integer> lines = deserializeLines(configurationElem);
        Map<Integer, String> symbolsMap = deserializeSymbolMap(configurationElem);
        List<PayTableItem> payTable = deserializePayTable(configurationElem);

        return new GameConfiguration(lines, betsPerLine, maxBet, maxWin, gamblerPlayLimit, gamblerWinLimit, payTable, currencyCode, yield, symbolsMap);
    }

    /**
     * Deserializes available languages from given xml object.
     * @param xmlObject xml object with available languages
     * @return the available languages
     */
    private static List<String> deserializeAvailableLanguages(XmlObject xmlObject) {
        XmlObject availableLanguagesXmlObject = xmlObject.findOne("//rsp/i/ls");
        if (availableLanguagesXmlObject == null) {
            return new ArrayList<>();
        }
        List<XmlObject> availableLanguagesElements = availableLanguagesXmlObject.getChildren();
        List<String> availableLanguages = new ArrayList<>(availableLanguagesElements.size());
        for (XmlObject availableLanguageElem : availableLanguagesElements) {
            availableLanguages.add(availableLanguageElem.getValue());
        }
        return availableLanguages;
    }

    /**
     * Deserializes pay table from given xml object.
     * @param configurationElement xml object with pay table
     * @return the pay table items
     */
    public static List<PayTableItem> deserializePayTable(XmlObject configurationElement) {
        List<XmlObject> payTableItemElemList = configurationElement.find("//pt/c");
        List<PayTableItem> payTable = new ArrayList<>(payTableItemElemList.size());
        for (XmlObject payTableItemElem : payTableItemElemList) {
            Map<String, String> attributes = payTableItemElem.getAttributes();
            String name = attributes.get("n");
            BigDecimal value = new BigDecimal(attributes.get("sc"));
            String type = attributes.get("t");
            payTable.add(new PayTableItem(name, value, type));
        }
        return payTable;
    }

    /**
     * Deserializes lines from given xml object.
     * @param configurationElement xml object with lines
     * @return the available lines in game
     */
    private static List<Integer> deserializeLines(XmlObject configurationElement) {
        List<XmlObject> lineElemList = configurationElement.find("//ld/l");
        List<Integer> lines = new ArrayList<>(lineElemList.size());
        for (XmlObject lineElem : lineElemList) {
            lines.add(Integer.parseInt(lineElem.getValue()));
        }
        return lines;
    }

    /**
     * Deserializes bet per line from given xml object.
     * @param configurationElement xml object with bet per line info
     * @return the list with available bets
     */
    private static List<BigDecimal> deserializeBetsPerLine(XmlObject configurationElement) {
        List<XmlObject> betElemList = configurationElement.find("//bd/b");
        List<BigDecimal> betsPerLine = new ArrayList<>(betElemList.size());
        for (XmlObject betElem : betElemList) {
            betsPerLine.add(new BigDecimal(betElem.getValue()));
        }
        return betsPerLine;
    }

    /**
     * Deserializes symbol map from given xml object.
     * @param configurationElement xml object with symbols mapping
     * @return the map with symbols mapping
     */
    private static Map<Integer, String> deserializeSymbolMap(XmlObject configurationElement) {
        List<XmlObject> symbolElemList = configurationElement.find("//ss/s");
        Map<Integer, String> parsedSymbolMap = new HashMap<>();
        for (XmlObject symbolElem : symbolElemList) {
            Integer symbolId = Integer.parseInt(symbolElem.getAttributes().get("id"));
            String symbolName = symbolElem.getAttributes().get("n");
            parsedSymbolMap.put(symbolId, symbolName);
        }
        return parsedSymbolMap;
    }
}
