package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.BundleAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.exception.ValidationException;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;

/**
 * Auto play bundle which is based on current auto play state.
 */
public class AutoPlayBundleAction extends BundleAction<AutoPlayBundleActionData> {

    /**
     * Reel game state holder reference.
     */
    private IReelGameStateHolder reelGameStateHolder;

    /**
     * Subscription for auto play events.
     */
    private Subscription autoPlaySubscription;

    /**
     * Initializes a new instance of the {@link AutoPlayBundleAction} class.
     */
    public AutoPlayBundleAction() {
        this.reelGameStateHolder = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder();
    }

    /**
     * Initializes a new instance of the {@link AutoPlayBundleAction} class.
     * @param logger              {@link ILogger}
     * @param eventBus            {@link IEventBus}
     * @param reelGameStateHolder {@link IReelGameStateHolder}
     */
    public AutoPlayBundleAction(ILogger logger, IEventBus eventBus, IReelGameStateHolder reelGameStateHolder) {
        super(logger, eventBus);
        this.reelGameStateHolder = reelGameStateHolder;
    }

    /**
     * Gets action data type for this action.
     * @return action data type for this action
     */
    @Override
    public Class<? extends AutoPlayBundleActionData> getActionDataType() {
        return AutoPlayBundleActionData.class;
    }

    @Override
    protected void validate() throws ValidationException {
        if (actionData.isExpectAutoPlayOn() != reelGameStateHolder.isAutoPlay()) {
            throw new ValidationException("Auto play is in different state other than is required to execute this auto play bundle.");
        }
    }

    @Override
    protected void execute() {
        if (actionData.isExpectAutoPlayOn()) {
            autoPlaySubscription = eventBus.register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        } else {
            autoPlaySubscription = eventBus.register(new AutoPlayStartEventObserver(), AutoPlayStartedEvent.class);
        }
        super.execute();
    }

    @Override
    protected void finish() {
        super.finish();
        clearSubscription();
    }

    @Override
    protected void reset() {
        super.reset();
        clearSubscription();
    }

    @Override
    public void terminate() {
        super.terminate();
        clearSubscription();
    }

    /**
     * Clears active subscription for auto play events.
     */
    private void clearSubscription() {
        if (autoPlaySubscription != null) {
            autoPlaySubscription.unsubscribe();
            autoPlaySubscription = null;
        }
    }

    /**
     * Stops currently active action and set state to finished.
     */
    private void stopExecution() {
        terminate();
        finish();
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(AutoPlayStoppedEvent autoPlayStoppedEvent) {
            stopExecution();
        }
    }

    private class AutoPlayStartEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(AutoPlayStartedEvent autoPlayStartedEvent) {
            stopExecution();
        }
    }

}
