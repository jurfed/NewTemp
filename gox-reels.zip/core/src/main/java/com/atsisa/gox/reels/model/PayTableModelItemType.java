package com.atsisa.gox.reels.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Pay table model item type.
 */
public enum PayTableModelItemType {

    /**
     * Line type of pay table item.
     */
    LINE("Line"),

    /**
     * Scatter type of pay table item.
     */
    SCATTER("Scatter");

    /**
     * Stores all pay table model item types.
     */
    private static final Map<String, PayTableModelItemType> fromString = new HashMap<>();

    static {
        for (PayTableModelItemType payTableModelItemType : values()) {
            fromString.put(payTableModelItemType.toString(), payTableModelItemType);
        }
    }

    /**
     * The pay table item value.
     */
    private final String value;

    /**
     * Creates PayTableModelItemType.
     * @param value string value of enum
     */
    PayTableModelItemType(String value) {
        this.value = value;
    }

    /**
     * Gets the pay table item type from the string.
     * @param value string value of enum
     * @return the pay table model item type
     */
    public static PayTableModelItemType fromString(String value) {
        return fromString.get(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
