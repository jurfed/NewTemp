package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.DynamicClassConverter;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.view.spi.ISymbolStateResolver;

/**
 * An abstract symbol class extends ViewGroupBase and inherits from ISymbol interface.
 */
public abstract class AbstractSymbol extends ViewGroup implements ISymbol {

    /**
     * Default symbol state.
     */
    @XmlAttribute(type = String.class)
    private final ObservableProperty<String> defaultState = new ObservableProperty<>(String.class, "");

    /**
     * Symbol state.
     */
    @XmlAttribute(type = String.class)
    private final ObservableProperty<String> state = new ObservableProperty<>(String.class, "");

    /**
     * Symbol name.
     */
    @XmlAttribute(type = String.class)
    private final ObservableProperty<String> name = new ObservableProperty<>(String.class);

    /**
     * Resolver for symbol's states.
     */
    @XmlElement(name = "symbolStateResolver", converters = DynamicClassConverter.class)
    private ISymbolStateResolver symbolStateResolver;

    /**
     * Initializes a new instance of the {@link AbstractSymbol} class.
     * @param renderer {@link IRenderer}
     */
    public AbstractSymbol(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Initializes a new instance of the {@link AbstractSymbol} class.
     */
    public AbstractSymbol() {
        super();
    }

    @Override
    public void setState(String state) {
        if (state == null || this.state.get().equals(state)) {
            return;
        }
        if (symbolStateResolver != null) {
            state = symbolStateResolver.resolve(this, state);
        }
        this.state.set(state);
        stateChanged();
    }

    /**
     * Gets symbol's animation state resolver.
     * @return current symbol's state resolver as ISymbolStateResolver
     */
    public ISymbolStateResolver getSymbolStateResolver() {
        return symbolStateResolver;
    }

    /**
     * Sets symbol's animation state resolver.
     * @param resolver current symbol's state resolver as ISymbolStateResolver
     */
    public void setSymbolStateResolver(ISymbolStateResolver resolver) {
        this.symbolStateResolver = resolver;
    }

    @Override
    public String getState() {
        return state.get();
    }

    @Override
    public String getDefaultState() {
        return defaultState.get();
    }

    @Override
    public void setDefaultState(String defaultState) {
        this.defaultState.set(defaultState);
        if (state.hasDefaultValue()) {
            setState(this.defaultState.get());
        }
    }

    @Override
    public String getName() {
        return name.get();
    }

    @Override
    public void setName(String name) {
        this.name.set(name);
    }

    @Override
    public String toString() {
        return getName();
    }

    /**
     * Gets the observable property for the name.
     * @return the observable property for the name
     */
    public ObservableProperty<String> name() {
        return name;
    }

    /**
     * Gets the observable property for the default state.
     * @return the observable property for the default state
     */
    public ObservableProperty<String> defaultState() {
        return defaultState;
    }

    /**
     * Gets the observable property for the state.
     * @return the observable property for the state
     */
    public ObservableProperty<String> state() {
        return state;
    }

    /**
     * Called when state has been changed.
     */
    protected abstract void stateChanged();
}
