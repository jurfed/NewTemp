package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroupBase;

/**
 * An abstract reel class extends {@link View} and inherits from {@link IReel} interface.
 */
public abstract class AbstractReel extends ViewGroupBase implements IReel, IResetable {

    /**
     * Reel index position in reel group.
     */
    private int index;

    /**
     * Initializes a new instance of the {@link AbstractReel} class.
     */
    public AbstractReel() {
        super();
    }

    /**
     * Initializes a new instance of the {@link AbstractReel} class.
     * @param renderer {@link IRenderer}
     */
    public AbstractReel(IRenderer renderer) {
        super(renderer);
    }

    /**
     * Sets index position in reel group.
     * @param index index position
     */
    void setIndex(int index) {
        this.index = index;
    }

    @Override
    public int hashCode() {
        return index;
    }

    @Override
    public int getIndex() {
        return index;
    }
}
