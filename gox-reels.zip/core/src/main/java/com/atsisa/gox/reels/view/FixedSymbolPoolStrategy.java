package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.exception.SymbolPoolException;
import com.atsisa.gox.reels.view.spi.ISymbolFactory;
import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;
import com.gwtent.reflection.client.Reflectable;

/**
 * A symbol pool strategy which uses predefined symbol quantities instantiated when the symbol pool is created.
 */
@Reflectable
@XmlElement
public class FixedSymbolPoolStrategy implements ISymbolPoolStrategy {

    /**
     * Configuration map entry property name specifying value of fixed symbol counts.
     */
    public static final String SYMBOL_QUANTITIES_PROPERTY_NAME = "fixedSymbolCount";

    /**
     * A map of symbol quantities.
     */
    private final Map<String, Integer> symbolsQuantities;

    /**
     * Initializes a new instance of the {@link FixedSymbolPoolStrategy} class
     * with empty symbols quantities map.
     */
    public FixedSymbolPoolStrategy() {
        symbolsQuantities = new HashMap<>();
    }

    /**
     * Initializes a new instance of the {@link FixedSymbolPoolStrategy} class.
     * @param symbolsQuantities Maps symbol names to their quantities.
     * @throws IllegalArgumentException The symbol quantities map is null.
     */
    public FixedSymbolPoolStrategy(Map<String, Integer> symbolsQuantities) {
        if (symbolsQuantities == null) {
            throw new IllegalArgumentException("The map of symbols quantities cannot be null.");
        }
        this.symbolsQuantities = symbolsQuantities;
    }

    @Override
    public Iterable<AbstractSymbol> initialize(ISymbolFactory symbolFactory) {
        List<AbstractSymbol> symbols = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : symbolsQuantities.entrySet()) {
            int quantity = entry.getValue();
            for (int index = 0; index < quantity; index++) {
                AbstractSymbol symbol = symbolFactory.createSymbol(entry.getKey());
                symbols.add(symbol);
            }
        }

        return symbols;
    }

    @Override
    public AbstractSymbol getMissingSymbol(ISymbolPool symbolPool, String symbolName) {
        String errorMessage = StringUtility
                .format("The symbol pool has been drained. Missing symbol: %s (The strategy does not allow to create any missing symbols)", symbolName);
        throw new SymbolPoolException(errorMessage);
    }

    @Override
    public void initializeConfiguration(Map<String, Object> configurationData) {
        Integer symbolCount = Integer.valueOf((String) configurationData.get(SYMBOL_QUANTITIES_PROPERTY_NAME));
        Iterable<String> symbolNames = (Iterable<String>) configurationData.get(SYMBOL_NAMES_PROPERTY_NAME);
        if (symbolCount != null && symbolNames != null) {
            symbolsQuantities.clear();
            for (String symbolName : symbolNames) {
                symbolsQuantities.put(symbolName, symbolCount);
            }
        } else {
            throw new SymbolPoolException(StringUtility
                    .format("Property %s or %s has not been configured properly for %s", SYMBOL_QUANTITIES_PROPERTY_NAME, SYMBOL_NAMES_PROPERTY_NAME,
                            FixedSymbolPoolStrategy.class.getName()));
        }
    }
}
