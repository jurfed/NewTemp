package com.atsisa.gox.reels.screen.model;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ILocalization;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.google.inject.Inject;

/**
 * Represents a model for error screen.
 */
public class ErrorScreenModel extends ScreenModel {

    /**
     * Key of message area template.
     */
    public static final String ERROR_MESSAGE_KEY = "ERROR_MESSAGE";

    /**
     * Initializes a new instance of the {@link ErrorScreenModel} class.
     * @param translator {@link ITranslator}
     */
    @Inject
    public ErrorScreenModel(ITranslator translator) {
        super(translator);
    }

    /**
     * Initializes a new instance of the {@link ErrorScreenModel} class.
     */
    public ErrorScreenModel() {
        super();
    }

    /**
     * Sets new message.
     * @param value new message
     */
    public void setErrorMessage(String value) {
        NamedProperty namedProperty = getTemplate(ERROR_MESSAGE_KEY);
        namedProperty.setName(value);
        namedProperty.set(translator.translateTemplate(value));
    }

    /**
     * Gets the message property.
     * @return the message property
     */
    public IObservableProperty<String> message() {
        return getTemplate(ERROR_MESSAGE_KEY);
    }

}
