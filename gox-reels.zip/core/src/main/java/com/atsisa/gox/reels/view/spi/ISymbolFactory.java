package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.reels.view.AbstractSymbol;

/**
 * Creates instances of {@link AbstractSymbol}s.
 */
public interface ISymbolFactory {

    /**
     * Creates a new instance of symbol of given name.
     * @param symbolName The name of the symbol that is about to be created.
     * @return A new instance of symbol.
     * @throws IllegalArgumentException The symbol name is not recognizable.
     */
    AbstractSymbol createSymbol(String symbolName);

    /**
     * Returns the names of all registered symbols.
     * @return The names of registered symbols.
     */
    Iterable<String> getSymbolNames();
}
