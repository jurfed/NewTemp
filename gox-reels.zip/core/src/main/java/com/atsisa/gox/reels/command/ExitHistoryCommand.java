package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request for exit from history.
 */
@Reflectable
public class ExitHistoryCommand {
}
