package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.HideSelectedGamblerCardCommand;
import com.atsisa.gox.reels.event.SelectedGamblerCardHiddenEvent;

/**
 * Requests to hide gambler selected card.
 */
public class HideSelectedGamblerCardAction extends WaitForEventAction<SelectedGamblerCardHiddenEvent> {

    /**
     * Initializes a new instance of the {@link HideSelectedGamblerCardAction} class.
     */
    public HideSelectedGamblerCardAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link HideSelectedGamblerCardAction} class.
     * @param logger   a logger reference.
     * @param eventBus an eventBus reference.
     */
    public HideSelectedGamblerCardAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new HideSelectedGamblerCardCommand());
    }

    @Override
    protected Class<SelectedGamblerCardHiddenEvent> getEventClass() {
        return SelectedGamblerCardHiddenEvent.class;
    }
}
