package com.atsisa.gox.reels.event;

import com.atsisa.gox.reels.model.IErrorModel;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when either error model value has changed.
 */
@Reflectable
public class ErrorModelChangedEvent {

    /**
     * The error model.
     */
    private final IErrorModel errorModel;

    /**
     * Initializes a new instance of the ErrorModelChangedEvent class.
     * @param errorModel - IErrorModel
     */
    public ErrorModelChangedEvent(IErrorModel errorModel) {
        this.errorModel = errorModel;
    }

    /**
     * Gets an object representing all crucial information regarding the most recent game error configuration.
     * @return IErrorModel
     */
    public IErrorModel getErrorModel() {
        return errorModel;
    }
}
