package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.action.ShowScreenAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.screen.event.ScreenHiddenEvent;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ShowInfoScreenCommand;

/**
 * Action used to display info screen.
 */
public class ShowInfoScreenAction extends ShowScreenAction {

    /**
     * Subscription for hidden screen event.
     */
    private Subscription hiddenScreenEventSubscription;

    /**
     * Initializes a new instance of the {@link ShowInfoScreenAction} class.
     */
    public ShowInfoScreenAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowInfoScreenAction} class.
     * @param logger   {@link ILogger}
     * @param eventBus {@link IEventBus}
     */
    public ShowInfoScreenAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    public Class<? extends ActionData> getActionDataType() {
        return ShowInfoScreenActionData.class;
    }

    @Override
    protected void execute() {
        registerEvents();
        ShowInfoScreenCommand showInfoScreenCommand = new ShowInfoScreenCommand(getScreenId(), getShowViewAnimationData(),
                ((ShowInfoScreenActionData) actionData).isPlaySound());
        showInfoScreenCommand.setViewId(((ShowInfoScreenActionData) actionData).getViewId());
        eventBus.post(showInfoScreenCommand);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        hiddenScreenEventSubscription = eventBus.register(new ScreenHiddenEventObserver(), ScreenHiddenEvent.class);
    }

    /**
     * Handles the screen hidden event.
     * @param screenHiddenEvent {@link ScreenHiddenEvent}
     */
    private void handleScreenHiddenEvent(ScreenHiddenEvent screenHiddenEvent) {
        if (getScreenId().equals(screenHiddenEvent.getScreen().getLayoutId())) {
            finish();
        }
    }

    @Override
    protected void clearWaitEventSubscription() {
        super.clearWaitEventSubscription();
        if (hiddenScreenEventSubscription != null) {
            hiddenScreenEventSubscription.unsubscribe();
            hiddenScreenEventSubscription = null;
        }
    }

    /**
     * Wait for event observer.
     */
    private class ScreenHiddenEventObserver extends NextObserver<ScreenHiddenEvent> {

        @Override
        public void onNext(ScreenHiddenEvent screenHiddenEvent) {
            handleScreenHiddenEvent(screenHiddenEvent);
        }
    }
}
