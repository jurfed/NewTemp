package com.atsisa.gox.reels.configuration;

import com.atsisa.gox.reels.view.NoSymbolAppendingStrategy;
import com.atsisa.gox.reels.view.ReelView;
import com.atsisa.gox.reels.view.spi.ISymbolAppendingStrategy;
import com.atsisa.gox.reels.view.spi.ISymbolPool;

/**
 * Defines data required for a successful setup
 * of {@link ReelView} class objects.
 */
public class SymbolsConfiguration implements ISymbolsConfiguration {

    /**
     * The default row count.
     */
    private static final int DEFAULT_ROW_COUNT = 3;

    /**
     * The symbol pool.
     */
    private ISymbolPool symbolPool;

    /**
     * The symbol appending strategy.
     */
    private ISymbolAppendingStrategy symbolAppendingStrategy;

    /**
     * The row count.
     */
    private int rowCount;

    /**
     * The symbol height.
     */
    private int symbolHeight;

    /**
     * Initializes a new instance of the {@link SymbolsConfiguration}.
     */
    public SymbolsConfiguration() {
        symbolAppendingStrategy = new NoSymbolAppendingStrategy();
        rowCount = DEFAULT_ROW_COUNT;
    }

    @Override
    public ISymbolPool getSymbolPool() {
        return symbolPool;
    }

    /**
     * Sets the symbol pool used to manage symbol instances in the reel this configuration is injected into.
     * @param symbolPool symbol pool
     */
    public void setSymbolPool(ISymbolPool symbolPool) {
        this.symbolPool = symbolPool;
    }

    @Override
    public int getRowCount() {
        return rowCount;
    }

    /**
     * Sets the number of symbol rows visible to players.
     * @param rowCount row count
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    @Override
    public int getSymbolHeight() {
        return symbolHeight;
    }

    /**
     * Sets the height of a single symbol in pixels.
     * @param symbolHeight symbol height
     */
    public void setSymbolHeight(int symbolHeight) {
        this.symbolHeight = symbolHeight;
    }

    @Override
    public ISymbolAppendingStrategy getSymbolAppending() {
        return symbolAppendingStrategy;
    }

    /**
     * Sets a strategy which changes the reel stopping behaviour by determining how stopped symbols should be joined with the existing reel strip in order
     * not to display combinations confusing to players.
     * @param symbolAppendingStrategy The symbol appending strategy
     */
    public void setSymbolAppending(ISymbolAppendingStrategy symbolAppendingStrategy) {
        this.symbolAppendingStrategy = symbolAppendingStrategy;
    }
}
