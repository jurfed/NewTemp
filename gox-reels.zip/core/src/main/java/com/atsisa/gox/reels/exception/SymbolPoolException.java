package com.atsisa.gox.reels.exception;

import com.atsisa.gox.reels.view.spi.ISymbolPool;
import com.atsisa.gox.reels.view.spi.ISymbolPoolStrategy;

/**
 * Denotes error occurred within objects implementing the
 * {@link ISymbolPool} and
 * {@link ISymbolPoolStrategy} interfaces.
 */
public class SymbolPoolException extends RuntimeException {

    /**
     * Initializes a new instance of the SymbolPoolException class.
     */
    public SymbolPoolException() {
    }

    /**
     * Initializes a new instance of the SymbolPoolException class with given message.
     * @param message error message
     */
    public SymbolPoolException(String message) {
        super(message);
    }

    /**
     * Initializes a new instance of the SymbolPoolException class with given message and cause.
     * @param message error message
     * @param cause   the inner exception (reason)
     */
    public SymbolPoolException(String message, Throwable cause) {
        super(message, cause);
    }
}
