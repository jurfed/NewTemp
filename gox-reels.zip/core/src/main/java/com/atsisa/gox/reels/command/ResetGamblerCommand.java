package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * Used to reset gambler model.
 */
@Reflectable
public class ResetGamblerCommand {
}
