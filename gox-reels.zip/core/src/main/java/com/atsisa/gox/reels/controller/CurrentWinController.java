package com.atsisa.gox.reels.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.atsisa.gox.reels.IWinLineInfo;

/**
 * Basic implementation of the win controller.
 */
public class CurrentWinController implements ICurrentWinController {

    /**
     * List of the win lines which has already increased the win value.
     */
    private List<IWinLineInfo> winLineInfos = new ArrayList<>();

    /**
     * Current win value.
     */
    private BigDecimal win = BigDecimal.ZERO;

    @Override
    public BigDecimal increase(BigDecimal value) {
        win = win.add(value);
        return win;
    }

    @Override
    public BigDecimal increase(IWinLineInfo winLineInfo) {
        if (!winLineInfos.contains(winLineInfo)) {
            winLineInfos.add(winLineInfo);
            win = win.add(winLineInfo.getScore());
        }
        return win;
    }

    @Override
    public BigDecimal setCurrentWin(BigDecimal value) {
        win = value;
        return win;
    }

    @Override
    public BigDecimal decrease(BigDecimal value) {
        win = win.subtract(value);
        return win;
    }

    @Override
    public BigDecimal getCurrentWin() {
        return win;
    }

    @Override
    public void clear() {
        clearWin();
        clearWinLineInfo();
    }

    @Override
    public void clearWinLineInfo() {
        winLineInfos.clear();
    }

    @Override
    public void clearWin() {
        win = BigDecimal.ZERO;
    }

}
