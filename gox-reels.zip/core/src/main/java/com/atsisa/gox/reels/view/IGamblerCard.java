package com.atsisa.gox.reels.view;

import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.view.View;

/**
 * Exposes common methods for gambler card.
 */
public interface IGamblerCard {

    /**
     * Sets upright card view.
     * @param uprightCard {@link View}
     */
    void setUprightCard(View uprightCard);

    /**
     * Returns a boolean value that indicates whether this card is reversed or not.
     * @return a boolean value that indicates whether this card is reversed or not
     */
    boolean isReversed();

    /**
     * Sets reversed card view.
     * @param reversedCard {@link View}
     */
    void setReversedCard(View reversedCard);

    /**
     * Shows upright card view.
     */
    void showUprightCard();

    /**
     * Shows reversed card view.
     */
    void showReversedCard();

    /**
     * Flips the card.
     * @param onFinishCallback {@link IFinishCallback}
     */
    void flip(IFinishCallback onFinishCallback);

}
