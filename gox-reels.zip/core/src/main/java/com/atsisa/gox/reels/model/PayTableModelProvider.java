package com.atsisa.gox.reels.model;

import java.math.BigDecimal;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.event.PayTableModelChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.google.inject.Inject;

/**
 * Handles all aspect of reel game pay table configuration.
 */
public class PayTableModelProvider implements IPayTableModelProvider {

    /**
     * EventBus instance
     */
    private final IEventBus eventBus;

    /**
     * PayTableModel instance
     */
    private PayTableModel payTableModel;

    /**
     * Currents bet value.
     */
    private BigDecimal currentBet = BigDecimal.ZERO;

    /**
     * Possible max win value in game.
     */
    private BigDecimal maxWin = new BigDecimal(Integer.MAX_VALUE);

    /**
     * Current line
     */
    private int currentLine;

    /**
     * Initializes a new instance of the {@link PayTableModelProvider} class.
     * @param eventBus the event bus
     */
    @Inject
    public PayTableModelProvider(IEventBus eventBus) {
        this.eventBus = eventBus;
        registerEvents();
    }

    /**
     * Registers events.
     */
    private void registerEvents() {
        eventBus.register(new InitResultObserver(), InitResult.class);
        eventBus.register(new BetModelChangedObserver(), BetModelChangedEvent.class);
        eventBus.register(new LinesModelChangedObserver(), LinesModelChangedEvent.class);
    }

    @Override
    public IPayTableModel getPayTableModel() {
        return payTableModel;
    }

    /**
     * Updates the pay table model according to given init response.
     * @param initResponse The init response.
     */
    @Subscribe
    public void handleInitResult(InitResult initResponse) {
        payTableModel = PayTableModel.createFrom(initResponse.getGameConfiguration().getPayTable());
        maxWin = initResponse.getGameConfiguration().getMaxWin();
        updateModel();
    }

    /**
     * Updates the pay table model according to given bet model changed response.
     * @param betModelChangedEvent The bet model changed response event.
     */
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        currentBet = betModelChangedEvent.getBetModel().getBetPerLine();
        updateModel();
    }

    /**
     * Updates the pay table model according to given lines model changed response.
     * @param linesModelChangedEvent The lines model changed response event.
     */
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        currentLine = linesModelChangedEvent.getLinesModel().getSelectedLines();
        updateModel();
    }

    /**
     * Updates model.
     */
    private void updateModel() {
        if (payTableModel == null) {
            return;
        }
        payTableModel.update(currentBet, currentLine, maxWin);
        notifyModelChanged();
    }

    /**
     * Publishes an event regarding pay table model changes.
     */
    private void notifyModelChanged() {
        eventBus.post(new PayTableModelChangedEvent(payTableModel.getValues()));
    }

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult initResult) {
            handleInitResult(initResult);
        }
    }

    private class BetModelChangedObserver extends NextObserver<BetModelChangedEvent> {

        @Override
        public void onNext(BetModelChangedEvent betModelChangedEvent) {
            handleBetModelChangedEvent(betModelChangedEvent);
        }
    }

    private class LinesModelChangedObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(LinesModelChangedEvent linesModelChangedEvent) {
            handleLinesModelChangedEvent(linesModelChangedEvent);
        }
    }
}
