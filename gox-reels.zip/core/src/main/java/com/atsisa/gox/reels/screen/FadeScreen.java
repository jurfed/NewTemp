package com.atsisa.gox.reels.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.RectangleShapeView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.gwtent.reflection.client.Reflectable;

/**
 * Fade screen class.
 */
@Reflectable
public class FadeScreen extends Screen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "FadeScreenLayoutId";

    /**
     * Default value of the layout id, under which should be layout for this screen.
     * It will be used if in game IoC configuration, this value will be not overwritten.
     */
    public static final String DEFAULT_LAYOUT_ID_VALUE = "fadeScreen";

    /**
     * Reference to the game configuration.
     */
    private IGameConfiguration gameConfiguration;

    /**
     * Initializes a new instance of the {@link FadeScreen} class.
     * @param layoutId          layout identifier
     * @param model             {@link ScreenModel}
     * @param renderer          {@link IRenderer}
     * @param viewManager       {@link IViewManager}
     * @param animationFactory  {@link IAnimationFactory}
     * @param logger            {@link ILogger}
     * @param eventBus          {@link IEventBus}
     * @param gameConfiguration {@link IGameConfiguration}
     */
    @Inject
    public FadeScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IGameConfiguration gameConfiguration) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.gameConfiguration = gameConfiguration;
    }

    @Override
    protected View createLayout() {
        ViewGroup viewGroup = new ViewGroup();
        viewGroup.setDepth(Integer.MAX_VALUE - 1);

        RectangleShapeView rectangleShapeView = new RectangleShapeView();
        rectangleShapeView.setFillColor(0);
        rectangleShapeView.setWidth(gameConfiguration.getWidth());
        rectangleShapeView.setHeight(gameConfiguration.getHeight());
        viewGroup.addChild(rectangleShapeView);

        return viewGroup;
    }
}
