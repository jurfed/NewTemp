package com.atsisa.gox.reels.animation;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AbstractAnimation;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimation;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.SequentialAnimation;
import com.atsisa.gox.framework.animation.TweenAnimation;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroupBase;
import com.atsisa.gox.reels.configuration.ISymbolsConfiguration;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.gwtent.reflection.client.HasReflect;
import com.gwtent.reflection.client.Reflectable;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenCallback;
import aurelienribon.tweenengine.equations.Linear;
import it.unimi.dsi.fastutil.objects.ObjectArrayFIFOQueue;
import rx.Observable;
import rx.Observer;
import rx.Subscription;
import rx.functions.Action1;
import rx.subjects.PublishSubject;

/**
 * A default implementation of the reel animation.
 */
@XmlElement
@Reflectable(fields = false)
public class ReelAnimation extends AbstractAnimation implements IReelAnimation {

    /**
     * Spinning phase single duration.
     */
    @XmlAttribute
    @HasReflect
    private float spinningPhaseSingleDuration = 90f;

    /**
     * Stopping phase duration.
     */
    @XmlAttribute
    @HasReflect
    private float stoppingPhaseDuration = 200f;

    /**
     * Stopping phase shift.
     */
    @XmlAttribute
    @HasReflect
    private float stoppingPhaseShift = 0.3f;

    /**
     * Speed increase.
     */
    @XmlAttribute
    @HasReflect
    private float speedIncrease = 4.0f;

    /**
     * Returning symbols subject.
     */
    private final PublishSubject<AbstractSymbol> returningSymbolsSubject;

    /**
     * Animating symbols observer.
     */
    private final AnimatingSymbolsObserver animatingSymbolsObserver;

    /**
     * Prepended symbols count.
     */
    private final int prependedSymbolsCount;

    /**
     * Appended symbols count.
     */
    private final int appendedSymbolsCount;

    /**
     * Animation factory.
     */
    private final IAnimationFactory animationFactory;

    /**
     * A list of animating symbols.
     */
    private final ObjectArrayFIFOQueue<AbstractSymbol> animatingSymbols;

    /**
     * A list of animation subscriptions.
     */
    private final ObjectArrayFIFOQueue<Subscription> animationSubscriptions;

    /**
     * The symbols configuration.
     */
    private ISymbolsConfiguration symbolsConfiguration;

    /**
     * The composite animation.
     */
    private IAnimation compositeAnimation;

    /**
     * The spinning phase animation.
     */
    private TweenAnimation spinningPhaseAnimation;

    /**
     * The symbols container.
     */
    private ViewGroupBase symbolsContainer;

    /**
     * Initializes a new instance of the {@link ReelAnimation} class
     * with given numbers of prepended and appended symbols.
     * @param prependedSymbolsCount A number of symbols this animation wishes to prepend before actual stopping symbols.
     * @param appendedSymbolsCount  A number of symbols this animation wishes to append after actual stopping symbols.
     */
    public ReelAnimation(int prependedSymbolsCount, int appendedSymbolsCount) {
        this.prependedSymbolsCount = prependedSymbolsCount;
        this.appendedSymbolsCount = appendedSymbolsCount;
        animatingSymbolsObserver = new AnimatingSymbolsObserver();
        returningSymbolsSubject = PublishSubject.create();
        animationFactory = GameEngine.current().getAnimationFactory();
        animatingSymbols = new ObjectArrayFIFOQueue<>(32);
        animationSubscriptions = new ObjectArrayFIFOQueue<>(32);
    }

    /**
     * Initializes a new instance of the {@link ReelAnimation} class
     * with a default numbers of prepended (1) and appended (1) symbols.
     */
    public ReelAnimation() {
        this(1, 1);
    }

    @Override
    public Observer<AbstractSymbol> getAnimatingSymbols() {
        return animatingSymbolsObserver;
    }

    @Override
    public Observable<AbstractSymbol> getReturningSymbols() {
        return returningSymbolsSubject;
    }

    @Override
    public void setUp(final ISymbolsConfiguration symbolsConfiguration) {
        this.symbolsConfiguration = symbolsConfiguration;
    }

    @Override
    public void play() {
        if (symbolsConfiguration == null) {
            throw new IllegalStateException("The ReelAnimation has not yet been initialize. Please invoke the setUp method first.");
        }
        if (isPlaying()) {
            return;
        }
        compositeAnimation = createCopositeAnimation();
        compositeAnimation.play();
        setAnimationState(AnimationState.PLAYING);
    }

    @Override
    public void pause() {
        if (isPaused() || isStopped()) {
            return;
        }

        compositeAnimation.pause();
        setAnimationState(AnimationState.PAUSED);
    }

    @Override
    public int getPrependedSymbolsCount() {
        return prependedSymbolsCount;
    }

    @Override
    public int getAppendedSymbolsCount() {
        return appendedSymbolsCount;
    }

    @Override
    public void stop() {
        if (isStopped()) {
            return;
        }
        getSymbolsContainer().setY(0);
        compositeAnimation.stop();
    }

    @Override
    public void beginStop() {
        setAnimationState(AnimationState.STOPPING);
        getSymbolsContainer().setY(0);
        spinningPhaseAnimation.stop();
    }

    @Override
    public void speedUp() {
        if (spinningPhaseAnimation == null) {
            return;
        }
        BaseTween<Tween> tween = spinningPhaseAnimation.getTween();
        if (tween != null) {
            tween.setSpeed(speedIncrease);
        }
    }

    /**
     * Gets a number of milliseconds a tween of a single symbol height lasts.
     * @return a number of milliseconds a tween of a single symbol height lasts.
     */
    public float getSpinningPhaseSingleDuration() {
        return spinningPhaseSingleDuration;
    }

    /**
     * Sets a number of milliseconds a tween of a single symbol height lasts.
     * @param spinningPhaseSingleDurationMillis a number of milliseconds a tween of a single symbol height lasts.
     */
    public void setSpinningPhaseSingleDuration(float spinningPhaseSingleDurationMillis) {
        spinningPhaseSingleDuration = spinningPhaseSingleDurationMillis;
    }

    /**
     * Gets a number of milliseconds the stopping phase lasts.
     * @return a number of milliseconds the stopping phase lasts.
     */
    public float getStoppingPhaseDuration() {
        return stoppingPhaseDuration;
    }

    /**
     * Sets a number of milliseconds the stopping phase lasts.
     * @param stoppingPhaseDurationMillis a number of milliseconds the stopping phase lasts.
     */
    public void setStoppingPhaseDuration(float stoppingPhaseDurationMillis) {
        stoppingPhaseDuration = stoppingPhaseDurationMillis;
    }

    /**
     * Gets a fractional part of a single symbol height a stopping symbol should be shifted back and forth.
     * @return a fractional part of a single symbol height a stopping symbol should be shifted back and forth.
     */
    public float getStoppingPhaseShift() {
        return stoppingPhaseShift;
    }

    /**
     * Sets a fractional part of a single symbol height a stopping symbol should be shifted back and forth.
     * @param stoppingPhaseShift a fractional part of a single symbol height a stopping symbol should be shifted back and forth.
     */
    public void setStoppingPhaseShift(float stoppingPhaseShift) {
        this.stoppingPhaseShift = stoppingPhaseShift;
    }

    /**
     * Gets the relative speed of the reel animation when the reel is forced to be stopped.
     * @return the relative speed of the reel animation when the reel is forced to be stopped.
     */
    public float getSpeedIncrease() {
        return speedIncrease;
    }

    /**
     * Sets the relative speed of the reel animation when the reel is forced to be stopped.
     * @param speedIncrease The speed increase (1.0 for natural speed, 4.0 for four times faster).
     */
    public void setSpeedIncrease(float speedIncrease) {
        this.speedIncrease = speedIncrease;
    }

    /**
     * Cleans up after the animation is finished.
     */
    private void cleanUp() {
        animatingSymbols.clear();
        while (!animationSubscriptions.isEmpty()) {
            Subscription subscription = animationSubscriptions.dequeue();
            if (!subscription.isUnsubscribed()) {
                subscription.unsubscribe();
            }
        }
        symbolsContainer = null;
    }

    /**
     * Creates a composite animation consisting of
     * a spinning phase and a stopping phase.
     * @return A composite animation.
     */
    private IAnimation createCopositeAnimation() {
        spinningPhaseAnimation = createSpinningPhase(spinningPhaseSingleDuration);
        TweenAnimation stoppingPhaseAnimation = createStoppingPhase(stoppingPhaseDuration, stoppingPhaseShift);
        IAnimation compositeAnimation = new SequentialAnimation(spinningPhaseAnimation, stoppingPhaseAnimation);
        Subscription subscription = compositeAnimation.getAnimationStateObservable().subscribe(new Action1<AnimationState>() {

            @Override
            public void call(AnimationState animationState) {
                if (animationState == AnimationState.STOPPED) {
                    cleanUp();
                    setAnimationState(AnimationState.STOPPED);
                }
            }
        });
        animationSubscriptions.enqueue(subscription);
        return compositeAnimation;
    }

    /**
     * Creates a spinning phase animation.
     * @param singleStepDurationMillis A number of milliseconds denoting how long a one position tween lasts.
     * @return a spinning phase animation.
     */
    private TweenAnimation createSpinningPhase(float singleStepDurationMillis) {
        final TweenAnimation spinningPhase = animationFactory.createAnimation(TweenAnimation.class);

        Tween tween = Tween.to(getSymbolsContainer(), View.ViewPropertyName.Y, singleStepDurationMillis).target(symbolsConfiguration.getSymbolHeight())
                .setCallbackTriggers(TweenCallback.COMPLETE | TweenCallback.END).ease(Linear.INOUT).repeat(-1, 0);
        spinningPhase.setTween(tween);
        Subscription subscription = spinningPhase.getTweenStateObservable().subscribe(new Action1<Integer>() {

            @Override
            public void call(Integer tweenEvent) {
                if (tweenEvent == TweenCallback.END) {
                    requestNextSymbol();
                }
            }
        });
        animationSubscriptions.enqueueFirst(subscription);
        return spinningPhase;
    }

    /**
     * Creates a stopping phase animation.
     * @param durationMillis          A number of milliseconds denoting how long the stopping phase lasts.
     * @param symbolOffsetCoefficient A fractional part of a single symbol height the tween should consider.
     * @return a stopping phase animation.
     */
    private TweenAnimation createStoppingPhase(float durationMillis, float symbolOffsetCoefficient) {
        final TweenAnimation stoppingPhase = animationFactory.createAnimation(TweenAnimation.class);
        Tween tween = Tween.to(getSymbolsContainer(), View.ViewPropertyName.Y, durationMillis);
        tween.waypoint(symbolsConfiguration.getSymbolHeight() * symbolOffsetCoefficient).target(0f);
        stoppingPhase.setTween(tween);
        return stoppingPhase;
    }

    /**
     * Requests the next symbol for animation.
     */
    private void requestNextSymbol() {
        if (!animatingSymbols.isEmpty()) {
            AbstractSymbol symbol = animatingSymbols.dequeue();
            returningSymbolsSubject.onNext(symbol);
        }
    }

    /**
     * Gets the container view for symbols.
     * @return The container view for symbols.
     */
    private ViewGroupBase getSymbolsContainer() {
        if (symbolsContainer == null) {
            symbolsContainer = animatingSymbols.first().getParent();
        }

        return symbolsContainer;
    }

    /**
     * An animating symbol observer.
     */
    private class AnimatingSymbolsObserver extends NextObserver<AbstractSymbol> {

        @Override
        public void onNext(AbstractSymbol symbol) {
            animatingSymbols.enqueue(symbol);
        }
    }
}
