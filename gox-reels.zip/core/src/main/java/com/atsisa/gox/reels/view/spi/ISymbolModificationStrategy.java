package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.reels.view.ISymbol;

/**
 * Strategy used to modify the symbols.
 */
public interface ISymbolModificationStrategy {

    /**
     * Modifies the symbol.
     * @param symbol {@link ISymbol}
     */
    void modify(ISymbol symbol);

}
