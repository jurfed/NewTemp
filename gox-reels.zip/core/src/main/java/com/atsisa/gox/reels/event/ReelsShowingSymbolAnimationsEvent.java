package com.atsisa.gox.reels.event;

import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when reel group is showing symbol animations.
 */
@Reflectable
public class ReelsShowingSymbolAnimationsEvent {
}
