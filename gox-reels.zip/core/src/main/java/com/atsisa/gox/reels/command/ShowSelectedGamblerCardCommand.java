package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command triggered when the last gambler selected card should be displayed.
 */
@Reflectable
public class ShowSelectedGamblerCardCommand {

    /**
     * Selected card name.
     */
    private String selectedCard;

    /**
     * Initializes a new instance of the {@link ShowSelectedGamblerCardCommand}.
     * @param selectedCard selected card.
     */
    public ShowSelectedGamblerCardCommand(String selectedCard) {
        this.selectedCard = selectedCard;
    }

    /**
     * Gets selected card.
     * @return String
     */
    public String getSelectedCard() {
        return selectedCard;
    }

}
