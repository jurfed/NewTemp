package com.atsisa.gox.reels.view.spi;

/**
 * Changes the reel stopping behaviour by determining
 * how stopped symbols should be joined with the existing reel strip
 * in order not to display combinations confusing to players.
 */
public interface ISymbolAppendingStrategy {

    /**
     * Returns a list of symbols which should be prepended to (added before) stopping symbols when
     * the reel is stopped in order not to display combinations confusing to players.
     * @param stoppingSymbols   A collection of stopping symbol names.
     * @param reelStrip         A collection of symbol names as defined in a reel strip.
     * @param reelStripPosition A zero-based index in the reel strip denoting the position before which the stopping symbols should be placed.
     * @return A list of symbol names which should be prepended to (added before) stopping symbols.
     */
    Iterable<String> getPrependedSymbols(Iterable<String> stoppingSymbols, Iterable<String> reelStrip, int reelStripPosition);

    /**
     * Returns a list of symbols which should be appended to (added after) stopping symbols when
     * the reel is stopped in order not to display combinations confusing to players.
     * @param stoppingSymbols   A collection of stopping symbol names.
     * @param reelStrip         A collection of symbol names as defined in a reel strip.
     * @param reelStripPosition A zero-based index in the reel strip denoting the position before which the stopping symbols should be placed.
     * @return A list of symbol names which should be appended to (added after) stopping symbols.
     */
    Iterable<String> getAppendedSymbols(Iterable<String> stoppingSymbols, Iterable<String> reelStrip, int reelStripPosition);
}
