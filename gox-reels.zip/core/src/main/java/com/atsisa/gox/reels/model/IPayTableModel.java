package com.atsisa.gox.reels.model;

import java.util.List;

/**
 * Exposes methods for pay table model.
 */
public interface IPayTableModel {

    /**
     * Gets a collection of all pay table model items.
     * @return a collection of all pay table model items
     */
    List<IPayTableModelItem> getValues();

    /**
     * Gets a value for specific pay table model item.
     * @param name name of the pay table model item
     * @return the pay table model item
     */
    IPayTableModelItem getValue(String name);
}
