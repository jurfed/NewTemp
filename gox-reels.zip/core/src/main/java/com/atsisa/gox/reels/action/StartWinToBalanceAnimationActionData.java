package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

/**
 * Action data for {@link StartWinToBalanceAnimationAction} class.
 */
@XmlElement
public class StartWinToBalanceAnimationActionData extends ActionData {

    /**
     * Single step duration.
     */
    @XmlAttribute
    private int singleStepDuration = 100;

    /**
     * Id of the sound which should be played when animation will be skipped.
     */
    @XmlAttribute
    private String skipSoundId;

    /**
     * Gets id of the sound which should be played when animation will be skipped.
     * @return sound id
     */
    public String getSkipSoundId() {
        return skipSoundId;
    }

    /**
     * Sets id of the sound which should be played when animation will be skipped.
     * @param skipSoundId sound id
     */
    public void setSkipSoundId(String skipSoundId) {
        this.skipSoundId = skipSoundId;
    }

    /**
     * Gets a single step animation duration in milliseconds.
     * @return a single step animation duration in milliseconds.
     */
    public int getSingleStepDuration() {
        return singleStepDuration;
    }

    /**
     * Sets a single step animation duration in milliseconds.
     * @param singleStepDuration a single step animation duration in milliseconds.
     */
    public void setSingleStepDuration(int singleStepDuration) {
        this.singleStepDuration = singleStepDuration;
    }
}
