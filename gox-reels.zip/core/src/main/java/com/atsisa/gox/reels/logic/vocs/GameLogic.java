package com.atsisa.gox.reels.logic.vocs;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.HttpRequest;
import com.atsisa.gox.framework.net.HttpResponse;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.reels.configuration.ReelConfigurationConstants;
import com.atsisa.gox.reels.logic.GameLogicException;
import com.atsisa.gox.reels.logic.HistoryResult;
import com.atsisa.gox.reels.logic.IReelGameHistoryLogic;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.EnterGamblerRequest;
import com.atsisa.gox.reels.logic.request.GambleRequest;
import com.atsisa.gox.reels.logic.request.HistoryRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;
import com.atsisa.gox.reels.logic.request.TakeWinRequest;
import com.atsisa.gox.reels.logic.vocs.serialization.ISerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;
import com.atsisa.gox.reels.logic.vocs.serialization.response.InitialParametersResponseSerializer;

import com.google.inject.Inject;

import rx.Observable;

/**
 * Represents a logic that integrates with Vocs services.
 */
public class GameLogic extends AbstractGameLogic implements IReelGameLogic, IReelGameHistoryLogic, ITranslationProvider {

    /**
     * The initial parameter uri template.
     */
    private static final String INITIAL_PARAMETER_URI_TEMPLATE = "%s/GetInitialParameters.aspx?languageCode=%s&gameID=%s&gameMode=%s";

    /**
     * The process game parameter uri template.
     */
    private static final String PROCESS_GAME_URI_TEMPLATE = "%s?gameInstanceId=%s";

    /**
     * URI history template.
     */
    private static final String PROCESS_HISTORY_GAME_URI_TEMPLATE = "%s?gameInstanceId=%s&history=true";

    /**
     * Serializer for initial parameters response.
     */
    private final ISerializer<String, InitialParametersResponse> initialParametersResponseSerializer;

    /**
     * Reference to the initial parameters response.
     */
    private InitialParametersResponse initialParametersResponse;

    /**
     * The map of headers.
     */
    protected final Map<String, String> headers = new HashMap<>();

    /**
     * Initializes a new instance of the {@link GameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configurationProvider   {@link IConfigurationProvider}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    @Inject
    public GameLogic(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
            Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
        super(xmlParser, network, configurationProvider.getConfiguration(), presentationSerializers, platform);
        headers.put("Content-Type", "text/plain; charset=utf-8");
        initialParametersResponseSerializer = new InitialParametersResponseSerializer(xmlParser);
    }

    @Override
    public Observable<Object> init(InitRequest initRequest) {
        Observable<InitialParametersResponse> initialParameters = getInitialParameters();
        return initialParameters.flatMap(response -> {
            initialParametersResponse = response;
            return sendLogicRequest(initRequest, getProcessGameUri(initRequest), HttpMethod.POST, headers);
        });
    }

    @Override
    public Observable<LogicPresentation> bet(BetRequest betRequest) {
        return sendLogicRequest(betRequest, getProcessGameUri(betRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> takeWin() {
        TakeWinRequest request = new TakeWinRequest();
        return sendLogicRequest(request, getProcessGameUri(request), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> gamble(GambleRequest gambleRequest) {
        return sendLogicRequest(gambleRequest, getProcessGameUri(gambleRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> enterGambler(EnterGamblerRequest enterGamblerRequest) {
        return sendLogicRequest(enterGamblerRequest, getProcessGameUri(enterGamblerRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<Object> history(HistoryRequest historyRequest) {
        return sendLogicRequest(historyRequest, getProcessGameUri(historyRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<Object> exitHistory(InitRequest initRequest) {
        return sendLogicRequest(initRequest, getProcessGameUri(initRequest), HttpMethod.POST, headers);
    }

    @Override
    public Observable<Map<String, String>> getTranslation(String languageCode) {
        LanguageRequest request = new LanguageRequest(languageCode, getPropertyValue(ReelConfigurationConstants.WRAPPER_NAME));
        return sendLogicRequest(request, getProcessGameUri(request), HttpMethod.POST, headers);
    }

    /**
     * Gets process game uri.
     * @param request request to the server
     * @return process game uri
     */
    protected String getProcessGameUri(Object request) {
        if (initialParametersResponse != null) {
            String uriTemplate = PROCESS_GAME_URI_TEMPLATE;
            if (request instanceof HistoryRequest) {
                uriTemplate = PROCESS_HISTORY_GAME_URI_TEMPLATE;
            }
            return StringUtility.format(uriTemplate, initialParametersResponse.getGameServerAddress(), initialParametersResponse.getGameInstanceId());
        } else {
            throw new IllegalStateException("The initial parameters are not available.");
        }
    }

    /**
     * Gets initial parameters from the server.
     * @return the observable result
     */
    private Observable<InitialParametersResponse> getInitialParameters() {
        try {
            HttpRequest httpRequest = getNetwork().getHttpRequest(getInitialParametersUri(), HttpMethod.GET);
            Observable<HttpResponse> httpResponse = sendRequest(httpRequest);
            return httpResponse.flatMap(response -> Observable.create(subscriber -> {
                try {
                    subscriber.onNext(initialParametersResponseSerializer.serialize(response.getResultAsString()));
                } catch (SerializationException ex) {
                    subscriber.onError(ex);
                }
                subscriber.onCompleted();
            }));
        } catch (Exception ex) {
            return Observable.error(new GameLogicException(-1, "An error occurred during getting initial parameters from server.", null, ex));
        }
    }

    /**
     * Gets initial parameters uri.
     * @return initial parameters uri
     */
    private String getInitialParametersUri() {
        return StringUtility.format(INITIAL_PARAMETER_URI_TEMPLATE, getPropertyValue(ReelConfigurationConstants.ENTRY_POINT_ADDRESS),
                getPropertyValue(ReelConfigurationConstants.LANGUAGE_CODE), getPropertyValue(ReelConfigurationConstants.GAME_ID),
                getPropertyValue(ReelConfigurationConstants.GAME_MODE));
    }
}
