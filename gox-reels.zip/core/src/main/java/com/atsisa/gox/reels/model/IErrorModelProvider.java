package com.atsisa.gox.reels.model;

/**
 * Exposes the most recent game error.
 */
public interface IErrorModelProvider {

    /**
     * Gets the most recent game error.
     * @return IErrorModel
     */
    IErrorModel getErrorModel();

    /**
     * Sets retry policy for retry button.
     * @param retryPolicy retry policy
     */
    void setRetryPolicy(IRetryPolicy retryPolicy);
}
