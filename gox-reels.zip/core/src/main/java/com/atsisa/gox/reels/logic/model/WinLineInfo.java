package com.atsisa.gox.reels.logic.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import com.atsisa.gox.reels.IWinLineInfo;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a winning line.
 */
@Reflectable
public class WinLineInfo implements IWinLineInfo {

    /**
     * The winning sequence.
     */
    private final Boolean[] winningSequence;

    /**
     * The number of the line.
     */
    private final int lineNumber;

    /**
     * The name of sound.
     */
    private final String soundName;

    /**
     * The name of animation.
     */
    private final String animationName;

    /**
     * The score of win.
     */
    private final BigDecimal score;

    /**
     * The positions of winning line.
     */
    private final List<Integer> positions;

    /**
     * Initializes a new instance of the {@link WinLineInfo} class.
     * @param lineNumber    a number of line
     * @param soundName     a name of sound
     * @param animationName a name of animation
     * @param score         a score of win
     * @param positions     a positions of winning line
     */

    public WinLineInfo(int lineNumber, String soundName, String animationName, BigDecimal score, List<Integer> positions) {
        this.lineNumber = lineNumber;
        this.soundName = soundName;
        this.animationName = animationName;
        this.score = score;
        this.positions = positions;
        winningSequence = new Boolean[positions.size()];
        int rowIndex = 0;
        for (int position : positions) {
            winningSequence[rowIndex++] = position >= 0;
        }
    }

    /**
     * Gets number of the line.
     * @return a number of the line
     */
    public int getLineNumber() {
        return lineNumber;
    }

    /**
     * Gets a name of sound.
     * @return a name of sound
     */
    public String getSoundName() {
        return soundName;
    }

    /**
     * Gets a name of animation.
     * @return a name of animation
     */
    public String getAnimationName() {
        return animationName;
    }

    /**
     * Gets a score of win.
     * @return a score of win
     */
    public BigDecimal getScore() {
        return score;
    }

    /**
     * Gets a positions of winning line.
     * @return a positions of winning line
     */
    public List<Integer> getPositions() {
        return positions;
    }

    /**
     * Gets the winning sequence.
     * @return The winning sequence
     */
    public Iterable<Boolean> getWinningSequence() {
        return Arrays.asList(winningSequence);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        WinLineInfo that = (WinLineInfo) o;
        if (lineNumber != that.lineNumber) {
            return false;
        }

        return Arrays.equals(getPositions().toArray(), that.getPositions().toArray());
    }

    @Override
    public int hashCode() {
        int result = lineNumber;
        result = 31 * result + Arrays.hashCode(getPositions().toArray());
        return result;
    }
}
