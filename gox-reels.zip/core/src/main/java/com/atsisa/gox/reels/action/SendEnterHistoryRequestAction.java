package com.atsisa.gox.reels.action;

import com.atsisa.gox.framework.IGameEngine;

/**
 * Sends a request to enter into history.
 */
public class SendEnterHistoryRequestAction extends AbstractHistoryPageRequestAction {

    /**
     * Initializes a new instance of the {@link SendEnterHistoryRequestAction} class.
     */
    public SendEnterHistoryRequestAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link SendEnterHistoryRequestAction} class.
     * @param gameEngine game engine reference
     */
    public SendEnterHistoryRequestAction(IGameEngine gameEngine) {
        super(gameEngine);
    }

    @Override
    protected int getHistoryPageNumberToShow() {
        return 0;
    }
}
