package com.atsisa.gox.reels.message;

import com.gwtent.reflection.client.Reflectable;

/**
 * Represents a game message.
 */
@Reflectable
public final class GameMessage {

    /**
     * The original content.
     */
    private final String originalContent;

    /**
     * The message type.
     */
    private final GameMessageType messageType;

    /**
     * The content.
     */
    private String content;

    /**
     * Initializes a new instance of the {@link GameMessage}.
     * @param messageType     The message type.
     * @param originalContent The original content.
     */
    public GameMessage(GameMessageType messageType, String originalContent) {
        this.messageType = messageType;
        this.originalContent = originalContent;
        content = originalContent;
    }

    /**
     * Gets the original content of this message
     * (before it was processed by message processors).
     * @return The original content of this message.
     */
    public String getOriginalContent() {
        return originalContent;
    }

    /**
     * Gets the content of this message
     * (after it was processed by message processors).
     * @return The content of this message.
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the content of the message.
     * @param content The message content.
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * Gets the message type.
     * @return The message type.
     */
    public GameMessageType getMessageType() {
        return messageType;
    }
}
