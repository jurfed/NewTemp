package com.atsisa.gox.reels.logic;

import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.LanguageInfo;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.gwtent.reflection.client.Reflectable;

/**
 * Represents the game init result.
 */
@Reflectable
public class InitResult {

    /**
     * The game configuration.
     */
    private final GameConfiguration gameConfiguration;

    /**
     * The language information.
     */
    private final LanguageInfo languageInfo;

    /**
     * Initializes a new instance of the {@link InitResult} class.
     * @param gameConfiguration the game configuration
     * @param languageInfo      the language info
     */
    public InitResult(GameConfiguration gameConfiguration, LanguageInfo languageInfo) {
        this.gameConfiguration = gameConfiguration;
        this.languageInfo = languageInfo;
    }

    /**
     * Gets game configuration.
     * @return the game configuration
     */
    public GameConfiguration getGameConfiguration() {
        return gameConfiguration;
    }

    /**
     * Gets language info.
     * @return the language info
     */
    public LanguageInfo getLanguageInfo() {
        return languageInfo;
    }

}
