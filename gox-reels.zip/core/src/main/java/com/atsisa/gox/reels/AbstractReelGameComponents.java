package com.atsisa.gox.reels;

import com.atsisa.gox.framework.utility.StringUtility;

/**
 * An abstraction class for the reel game components.
 */
public class AbstractReelGameComponents {

    /**
     * A value indicating whether it is no longer possible to use setters in this container.
     */
    private boolean frozen = false;

    /**
     * Freezes the components so that using setters will no longer be possible.
     */
    void freeze() {
        frozen = true;
    }

    /**
     * Validates if the current instance was frozen and throws an exception if it was.
     */
    protected void validateState() {
        if (frozen) {
            throw new UnsupportedOperationException(StringUtility.format("Cannot modify a reference of this (%s) reel game component!", this));
        }
    }

}
