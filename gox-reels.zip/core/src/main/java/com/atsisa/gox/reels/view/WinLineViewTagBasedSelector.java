package com.atsisa.gox.reels.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.view.spi.IWinLineViewChildSelector;
import com.atsisa.gox.reels.view.state.WinLineState;

/**
 * A class-based view selector which uses a map of {@link WinLineState}s and
 * its corresponding view tags to determine which views belong
 * to current {@link WinLineState}.
 */
class WinLineViewTagBasedSelector implements IWinLineViewChildSelector {

    /**
     * A view tag representing line indicator components.
     */
    public static final String INDICATOR_TAG = "indicator";

    /**
     * An view tag representing line components.
     */
    public static final String LINE_TAG = "line";

    /**
     * Default state mappings.
     */
    private static final Map<WinLineState, List<String>> DEFAULT_STATE_MAPPINGS;

    /**
     * Initializes default state mappings.
     */
    static {
        DEFAULT_STATE_MAPPINGS = new HashMap<>();
        DEFAULT_STATE_MAPPINGS.put(WinLineState.ACTIVE, Arrays.asList(INDICATOR_TAG));
        DEFAULT_STATE_MAPPINGS.put(WinLineState.SHOWN, Arrays.asList(INDICATOR_TAG, LINE_TAG));
        DEFAULT_STATE_MAPPINGS.put(WinLineState.SHOWN_WINNING, Arrays.asList(INDICATOR_TAG, LINE_TAG));
    }

    /**
     * A map of win line states to their corresponding view tags.
     */
    private final Map<WinLineState, List<String>> stateMappings;

    /**
     * Initializes a {@link WinLineViewTagBasedSelector}
     * using given win line state as a view tags selection knowledge source.
     */
    public WinLineViewTagBasedSelector() {
        stateMappings = DEFAULT_STATE_MAPPINGS;
    }

    /**
     * Initializes a {@link WinLineViewTagBasedSelector}
     * using customized win line state mappings.
     * @param stateMappings Custom state mappings.
     */
    public WinLineViewTagBasedSelector(final Map<WinLineState, List<String>> stateMappings) {
        if (stateMappings == null) {
            throw new IllegalArgumentException("State mappings cannot be null.");
        }
        this.stateMappings = stateMappings;
    }

    /**
     * Filters the collection of views according to current win line state.
     * @param views        A collection of views to filter.
     * @param winLineState Current win line state.
     * @return A filter collection of views.
     */
    @Override
    public final Iterable<View> selectChildren(final Iterable<View> views, final WinLineState winLineState) {
        List<View> filteredViews = new ArrayList<>();
        List<String> viewTags = stateMappings.get(winLineState);
        for (View view : views) {
            if (viewTags != null) {
                for (String tag : viewTags) {
                    if (view.hasTag(tag)) {
                        filteredViews.add(view);
                        break;
                    }
                }
            }
            if (!view.hasTags()) {
                filteredViews.add(view);
            }
        }

        return filteredViews;
    }
}
