package com.atsisa.gox.reels.model;

/**
 * Exposes the most recent game history configuration for a player.
 */
public interface IHistoryModelProvider {

    /**
     * Gets the most recent history game model.
     * @return history game model.
     */
    IHistoryModel getHistoryModel();

}
