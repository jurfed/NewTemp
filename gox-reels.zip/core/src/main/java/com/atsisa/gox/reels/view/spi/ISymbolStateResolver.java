package com.atsisa.gox.reels.view.spi;

import com.atsisa.gox.reels.view.ISymbol;

/**
 * Resolves symbol's state to avoid wrong displaying.
 */
public interface ISymbolStateResolver {

    /**
     * Returns resolved symbol's state.
     * @param symbol Symbol that state is resolved.
     * @param state New state which is to check.
     * @return State that should be setted.
     */
    String resolve(ISymbol symbol, String state);

}
