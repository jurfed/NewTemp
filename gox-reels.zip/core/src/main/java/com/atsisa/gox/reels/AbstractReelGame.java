package com.atsisa.gox.reels;

import java.util.Set;

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.action.ActionQueueState;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.event.ErrorOccurredEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.exception.GeneralSystemException;
import com.atsisa.gox.framework.resource.AbstractTextResource;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.serialization.SerializationException;
import com.atsisa.gox.framework.serialization.SerializationFormat;
import com.atsisa.gox.framework.utility.ConfigurationStatics;
import com.atsisa.gox.reels.configuration.ReelGameConfiguration;
import com.atsisa.gox.reels.fsm.IReelGameStateHolder;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.message.MessagesProvider;
import com.atsisa.gox.reels.model.IAccount;
import com.atsisa.gox.reels.model.IBetModelProvider;
import com.atsisa.gox.reels.model.IErrorModelProvider;
import com.atsisa.gox.reels.model.IGamblerModelProvider;
import com.atsisa.gox.reels.model.IHistoryModelProvider;
import com.atsisa.gox.reels.model.ILinesModelProvider;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.model.IReelStripDefinitionProvider;
import com.atsisa.gox.reels.model.LocalResourceReelStripDefinitionProvider;
import com.atsisa.gox.reels.model.ReelGameSoundModel;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.google.inject.Inject;

/**
 * Reel game abstraction class. Inherit this class if you want to deploy your own reel-based game.
 */
public abstract class AbstractReelGame extends AbstractGame {

    /**
     * Initialize game queue name.
     */
    private static final String INITIALIZE_GAME_QUEUE_NAME = "InitializeGame";

    /**
     * An EventBus reference.
     */
    protected IEventBus eventBus;

    /**
     * A reference to a serializer.
     */
    private IXmlSerializer serializer;

    /**
     * A reference to resource manager.
     */
    private IResourceManager resourceManager;

    /**
     * A reference to action manager.
     */
    private IActionManager actionManager;

    /**
     * Reel game configuration.
     */
    private ReelGameConfiguration reelGameConfiguration;

    /**
     * The reel strip definition provider.
     */
    private IReelStripDefinitionProvider reelStripDefinitionProvider;

    /**
     * Container with reel game components.
     */
    private BaseReelGameComponents baseReelGameComponents;

    /**
     * Collection of the additional reel game components.
     */
    private Set<AbstractReelGameComponents> additionalReelGameComponents;

    /**
     * Initializes a new instance of the {@link AbstractReelGame} class.
     * @param baseReelGameComponents {@link BaseReelGameComponents}
     */
    @Inject
    public AbstractReelGame(BaseReelGameComponents baseReelGameComponents) {
        this.baseReelGameComponents = baseReelGameComponents;
    }

    /**
     * Sets the additional reel game components.
     * @param additionalReelGameComponents collection of the additional reel game components
     */
    @Inject(optional = true)
    public void setAdditionalReelGameComponents(Set<AbstractReelGameComponents> additionalReelGameComponents) {
        this.additionalReelGameComponents = additionalReelGameComponents;
        for (AbstractReelGameComponents additionalReelGameComponent : additionalReelGameComponents) {
            additionalReelGameComponent.freeze();
        }
    }

    /**
     * Finds and returns specific type of the additional registered reel game component.
     * @param type class of the additional reel game component to find
     * @param <T>  type of the additional reel game component to find
     * @return the additional reel game component
     */
    public <T extends AbstractReelGameComponents> T findReelGameComponent(Class<T> type) {
        for (AbstractReelGameComponents additionalReelGameComponent : additionalReelGameComponents) {
            if (additionalReelGameComponent.getClass().equals(type)) {
                return (T) additionalReelGameComponent;
            }
        }
        return null;
    }

    /**
     * Gets the collection of the reels presentation states.
     * return the collection of the reels presentation states
     */
    public Iterable<IReelsPresentationStates> getReelsPresentationStates() {
        return baseReelGameComponents.getReelsPresentationStates();
    }

    /**
     * Loads the resources and registers views regarding reel games.
     */
    @Override
    public void onCreate() {
        super.onCreate();
        registerErrorScreen();
        baseReelGameComponents.freeze();

        eventBus = gameEngine.getEventBus();
        serializer = gameEngine.getUtility().getSerialization().getSerializer(SerializationFormat.XML);
        resourceManager = gameEngine.getResourceManager();
        actionManager = gameEngine.getActionManager();
    }

    /**
     * Initialize error screen.
     */
    private void registerErrorScreen() {
        ErrorScreen errorScreen = findStartScreen(ErrorScreen.class);
        if (errorScreen != null) {
            getEngine().getViewManager().registerScreen(errorScreen);
        }
    }

    /**
     * Gets reel game components.
     * @return reel game components
     */
    protected BaseReelGameComponents getBaseReelGameComponents() {
        return baseReelGameComponents;
    }

    /**
     * Gets reel game state holder.
     * @return IReelGameStateHolder
     */
    public IReelGameStateHolder getReelGameStateHolder() {
        return baseReelGameComponents.getReelGameStateHolder();
    }

    @Override
    protected final void executeOnReady() {
        try {
            createReelGameConfiguration();
            reelStripDefinitionProvider = LocalResourceReelStripDefinitionProvider
                    .newReelStripDefinitionProvider(reelGameConfiguration.getReelStripResourcesId(), resourceManager, serializer);
        } catch (Exception e) {
            eventBus.post(new ErrorOccurredEvent(new GeneralSystemException(e)));
            return;
        }
        super.executeOnReady();
    }

    @Override
    protected void executeOnStart() {
        actionManager.processQueue(INITIALIZE_GAME_QUEUE_NAME, (source, state) -> {
            if (state == ActionQueueState.FINISHED) {
                onStart();
            }
        });
    }

    /**
     * Gets reel game configuration.
     * @return ReelGameConfiguration
     */
    public ReelGameConfiguration getReelGameConfiguration() {
        return reelGameConfiguration;
    }

    /**
     * Creates reel game configuration definition from a file.
     * @throws SerializationException if reel game configuration could not be deserialized
     */
    private void createReelGameConfiguration() throws SerializationException {
        AbstractTextResource textResource = resourceManager.getResource(ConfigurationStatics.REEL_GAME_CONFIGURATION_ENTRY_NAME);
        reelGameConfiguration = (ReelGameConfiguration) serializer.deserialize(textResource.getText(), ReelGameConfiguration.class);
    }

    /**
     * Gets reel strip definition provider.
     * @return IReelStripDefinitionProvider
     */
    public IReelStripDefinitionProvider getReelStripDefinitionProvider() {
        return reelStripDefinitionProvider;
    }

    /**
     * Gets the reel game logic.
     * @return reel game logic
     */
    public IReelGameLogic getReelGameLogic() {
        return baseReelGameComponents.getReelGameLogic();
    }

    /**
     * Gets the bet model provider.
     * @return IBetModelProvider
     */
    public IBetModelProvider getBetModelProvider() {
        return baseReelGameComponents.getBetModelProvider();
    }

    /**
     * Gets the gambler model provider.
     * @return IGamblerModelProvider
     */
    public IGamblerModelProvider getGamblerModelProvider() {
        return baseReelGameComponents.getGamblerModelProvider();
    }

    /**
     * Gets the lines model provider.
     * @return lines model provider
     */
    public ILinesModelProvider getLinesModelProvider() {
        return baseReelGameComponents.getLinesModelProvider();
    }

    /**
     * Gets pay table model provider.
     * @return pay table model provider
     */
    public IPayTableModelProvider getPayTableModelProvider() {
        return baseReelGameComponents.getPayTableModelProvider();
    }

    /**
     * Gets history model provider.
     * @return history model provider
     */
    public IHistoryModelProvider getHistoryModelProvider() {
        return baseReelGameComponents.getHistoryModelProvider();
    }

    /**
     * Gets error model provider.
     * @return error model provider
     */
    public IErrorModelProvider getErrorModelProvider() {
        return baseReelGameComponents.getErrorModelProvider();
    }

    /**
     * Gets a message provider.
     * @return a message provider
     */
    public MessagesProvider getMessageProvider() {
        return baseReelGameComponents.getMessageProvider();
    }

    /**
     * Gets the player's account.
     * @return Player's account.
     */
    public IAccount getAccount() {
        return baseReelGameComponents.getAccount();
    }

    /**
     * Gets a reel game sound model.
     * @return a reel game sound model
     */
    public ReelGameSoundModel getReelGameSoundModel() {
        return baseReelGameComponents.getReelGameSoundModel();
    }
}
