package com.atsisa.gox.reels.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A request to show next page in history.
 */
@Reflectable
public class ShowNextHistoryPageCommand {
}
