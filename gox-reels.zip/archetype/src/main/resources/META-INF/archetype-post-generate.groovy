def availableResolutions = ["FHD", "UXGA"];
def artifactId = binding.getVariable("artifactId");
def gameAssetsDirectoryPath = artifactId + "/assets/src/main/resources/assets/";
def gameResolution = binding.getVariable("resolution").toUpperCase();

for (String resolutionName : availableResolutions) {
    if (resolutionName != gameResolution) {
        new File(gameAssetsDirectoryPath + "resolution-" + resolutionName).deleteDir();
    }
}

new File(gameAssetsDirectoryPath + "resolution-" + gameResolution).renameTo(new File(gameAssetsDirectoryPath + "default"));

if (binding.getVariable("twoMonitors") == "false") {
    String payTableFilePath = gameAssetsDirectoryPath + "default/layouts/payTableScreen.xml";
    new File(payTableFilePath).delete();
}
