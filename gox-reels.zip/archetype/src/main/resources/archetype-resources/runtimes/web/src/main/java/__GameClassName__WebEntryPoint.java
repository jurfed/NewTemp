#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import com.atsisa.gox.framework.HtmlGameEntryPoint;

public class ${GameClassName}WebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "${GameClassName}";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

}
