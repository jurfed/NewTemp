#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import com.atsisa.gox.framework.FrameworkCoreModule;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.inject.IModule;
import com.atsisa.gox.reels.ReelsCoreModule;

public class ${GameClassName}DesktopEntryPoint extends JavaGameEntryPoint {

    public static void main(String[] args) throws Exception {
        new ${GameClassName}DesktopEntryPoint().start();
    }

    @Override
    protected IModule getModule() {
        return new AggregatedModule(
        new FrameworkCoreModule(),
        new FrameworkDesktopModule(),
        new ReelsCoreModule(),
        new ${GameClassName}CoreModule());
    }
}
