#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.configuration;

import com.atsisa.gox.framework.configuration.GameConfiguration;

public class ${GameClassName}Configuration extends GameConfiguration {

    public ${GameClassName}Configuration() {
        setResourcePath("${GameClassName}/");
        setupWindowSize();
        setWindowDecorated(true);
        setGameName("${GameName}");
    }

    #if ($resolution.toLowerCase() == "fhd")
private void setupWindowSize() {
    setWidth(1920);
    #if ($twoMonitors == "true" ||  $twoMonitors == "y" ||  $twoMonitors == "yes")
    setHeight(2160);
    #else
    setHeight(1080);
    #end
}
    #end

    #if ($resolution.toLowerCase() == "uxga")
private void setupWindowSize() {
    setWidth(1600);
    #if ($twoMonitors == "true" ||  $twoMonitors == "y" ||  $twoMonitors == "yes")
    setHeight(2400);
    #else
    setHeight(1200);
    #end
}
    #end

}
