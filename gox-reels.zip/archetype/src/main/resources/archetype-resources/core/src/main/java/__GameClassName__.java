#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};

import com.atsisa.gox.reels.BaseReelGameComponents;
import com.google.inject.Inject;
import com.atsisa.gox.reels.AbstractReelGame;

public class ${GameClassName} extends AbstractReelGame {

    /**
     * Initializes a new instance of the {@link ${GameClassName}} class.
     * @param reelGameComponents {@link BaseReelGameComponents}
     */
    @Inject
    public ${GameClassName}(BaseReelGameComponents reelGameComponents) {
        super(reelGameComponents);
    }

}
