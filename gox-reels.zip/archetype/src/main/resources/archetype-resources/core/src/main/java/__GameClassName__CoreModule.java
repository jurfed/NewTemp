package ${package};

import com.atsisa.gox.framework.AbstractGame;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.inject.AbstractModule;
import com.atsisa.gox.reels.model.ReelGameSoundModel;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.GamblerScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.WinLinesScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.reels.screen.transition.TopDownInfoScreenTransition;
import ${package}.configuration.${GameClassName}Configuration;
import ${package}.screen.${GameClassName}BottomPanelScreen;
import ${package}.screen.${GameClassName}InfoScreen;
import ${package}.screen.${GameClassName}GamblerScreen;
import ${package}.logic.${GameClassName}LogicMockup;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
#if ($twoMonitors == "true" ||  $twoMonitors == "y" ||  $twoMonitors == "yes")
import com.atsisa.gox.reels.screen.PayTableScreen;
#end

/**
 * Represents an IoC module configuration.
 */
public class ${GameClassName}CoreModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(${GameClassName}.class).asEagerSingleton();
        bind(IGame.class).to(${GameClassName}.class).asEagerSingleton();
        bind(AbstractGame.class).to(${GameClassName}.class).asEagerSingleton();
        bind(IGameConfiguration.class).to(${GameClassName}Configuration.class).asEagerSingleton();

        bindConstant().named(GamblerScreen.LAYOUT_ID_PROPERTY).to("gamblerScreen");
        bindConstant().named(InfoScreen.LAYOUT_ID_PROPERTY).to("infoScreen");
        bindConstant().named(WinLinesScreen.LAYOUT_ID_PROPERTY).to("winLinesScreen");
        bindConstant().named(BottomPanelScreen.LAYOUT_ID_PROPERTY).to("bottomPanelScreen");
        bindConstant().named(BaseGameScreen.LAYOUT_ID_PROPERTY).to("baseGameScreen");

        bindConstant().named(ReelGameSoundModel.INFO_SCREEN_SHOW_ANIMATION_SOUND_ID_PROPERTY).to("Shift");
        bindConstant().named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY).to("AutoPlayOff");
        bindConstant().named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY).to("AutoPlayOn");
        bindConstant().named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY).to("BetChanging");

        bindConstant().named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/small_red_card_reverse.png");
        bindConstant().named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/small_clubs_card.png");
        bindConstant().named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/small_diamond_card.png");
        bindConstant().named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/small_heart_card.png");
        bindConstant().named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/small_spade_card.png");
        bindConstant().named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/spade_card.png");
        bindConstant().named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/clubs_card.png");
        bindConstant().named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/heart_card.png");
        bindConstant().named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/diamond_card.png");
        bindConstant().named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY).to("@spriteSheet/GamblerSpriteSheet/blue_card_reverse.png");

        bind(GamblerScreenModel.class);
        bind(BottomPanelScreenModel.class);
        bind(PayTableScreenModel.class);
        bind(GamblerScreenModel.class);
        #if ($twoMonitors == "true" ||  $twoMonitors == "y" ||  $twoMonitors == "yes")
bindConstant().named(PayTableScreen.LAYOUT_ID_PROPERTY).to("payTableScreen");
        bind(Screen.class).to(PayTableScreen.class).asEagerSingleton();
        #end

        bind(InfoScreenTransition.class).to(TopDownInfoScreenTransition.class).asEagerSingleton();

        bind(Screen.class).to(${GameClassName}GamblerScreen.class).asEagerSingleton();
        bind(Screen.class).to(${GameClassName}InfoScreen.class).asEagerSingleton();
        bind(Screen.class).to(BaseGameScreen.class).asEagerSingleton();
        bind(Screen.class).to(${GameClassName}BottomPanelScreen.class).asEagerSingleton();
        bind(Screen.class).to(WinLinesScreen.class).asEagerSingleton();

        bind(${GameClassName}LogicMockup.class).asEagerSingleton();
        bind(IReelGameLogic.class).to(${GameClassName}LogicMockup.class).asEagerSingleton();
        bind(ITranslationProvider.class).to(${GameClassName}LogicMockup.class).asEagerSingleton();
    }
}
