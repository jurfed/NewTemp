package ${package}.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.GameMessageChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.model.IAccount;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.google.inject.Inject;
import com.google.inject.name.Named;

/**
 * Implementation for bottom panel screen.
 */
public class ${GameClassName}BottomPanelScreen extends BottomPanelScreen {

    /**
     * Name of the properties which is responsible if increase bet button is enable or not.
     */
    private static final String BET_INCREASE_ENABLE = "betIncreaseEnable";

    /**
     * Name of the properties which is responsible if increase bet button is enable or not.
     */
    private static final String BET_DECREASE_ENABLE = "betDecreaseEnable";

    /**
     * Name of the properties which is responsible if enter into history button is visible or not.
     */
    private static final String HISTORY_VISIBLE = "historyVisible";

    /**
     * Name of the properties which is responsible if auto play button is enable or not.
     */
    private static final String AUTO_PLAY_ENABLE = "autoPlayEnable";

    /**
     * Name of the properties which is responsible if auto stop button is visible or not.
     */
    private static final String AUTO_STOP_VISIBLE = "autoStopVisible";

    /**
     * Name of the properties which is responsible if spin button is enable or not.
     */
    private static final String SPIN_ENABLE = "spinEnable";

    /**
     * Name of the properties which is responsible if skip button is visible or not.
     */
    private static final String SKIP_VISIBLE = "skipVisible";

    /**
     * Name of the properties which is responsible if take button is visible or not.
     */
    private static final String TAKE_VISIBLE = "takeVisible";

    /**
     * Win visible.
     */
    private static final String WIN_VISIBLE = "winVisible";

    /**
     * Name of the properties which is responsible if info button is enable or not.
     */
    private static final String INFO_ENABLE = "infoEnable";

    /**
     * Name of the properties which is responsible if increase lines button is enable or not.
     */
    private static final String LINES_INCREASE_ENABLE = "linesIncreaseEnable";

    /**
     * Name of the properties which is responsible if decrease lines button is enable or not.
     */
    private static final String LINES_DECREASE_ENABLE = "linesDecreaseEnable";

    /**
     * Name of the properties which is responsible if gamble button is enable or not.
     */
    private static final String GAMBLE_ENABLE = "gambleEnable";

    /**
     * Name of the properties which is responsible if select red card button is visible or not.
     */
    private static final String SELECT_RED_CARD_VISIBLE = "selectRedCardVisible";

    /**
     * Name of the properties which is responsible if select black card button is visible or not.
     */
    private static final String SELECT_BLACK_CARD_VISIBLE = "selectBlackCardVisible";

    /**
     * Boolean value that indicates whether auto play is on or off.
     */
    private boolean isAutoPlay;

    /**
     * Initializes a new instance of the {@link com.atsisa.gox.${package}BottomPanelScreen} class.
     * @param layoutId               layout identifier
     * @param bottomPanelScreenModel {@link BottomPanelScreenModel}
     * @param renderer               {@link IRenderer}
     * @param viewManager            {@link IViewManager}
     * @param animationFactory       {@link IAnimationFactory}
     * @param logger                 {@link ILogger}
     * @param eventBus               {@link IEventBus}
     * @param account                {@link IAccount}
     * @param linesModelMutator      the lines model mutator
     */
    @Inject
    public ${GameClassName}BottomPanelScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel, IRenderer renderer,
        IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IAccount account,
        IMutator<ILinesModel> linesModelMutator) {
        super(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger, eventBus, account, linesModelMutator);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ScreenShowingEventObserver(), ScreenShowingEvent.class);
        getEventBus().register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        getEventBus().register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        getEventBus().register(new ScreenShownEventObserver(), ScreenShownEvent.class);
    }

    @Override
    protected void stateChanged() {
        super.stateChanged();
        hideAllButtons();
        switch (getCurrentState()) {
            case ReelsPresentationStates.IDLE:
                setModelProperty(SPIN_ENABLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                setModelProperty(INFO_ENABLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(HISTORY_VISIBLE, Boolean.TRUE);
                updateVisibleBetButtons();
                updateVisibleLineButtons();
            break;
            case ReelsPresentationStates.WIN_COUNTING:
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.STOPPING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.REELS_WIN_ANIMATION:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.OFFER_GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                if (!isAutoPlay) {
                    setModelProperty(GAMBLE_ENABLE, Boolean.TRUE);
                }
                break;
            case ReelsPresentationStates.GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            default:
                break;
        }
    }

    /**
     * Updates visible bet buttons.
     */
    private void updateVisibleBetButtons() {
        if (getBetModel() == null || getBetModel().getBetPerLine() == null || getBetModel().getMaxBet() == null
        || getBetModel().getMinBet() == null) {
            return;
        }
        setModelProperty(BET_INCREASE_ENABLE, Boolean.valueOf(getBetModel().getBetPerLine().compareTo(getBetModel().getMaxBet()) < 0));
        setModelProperty(BET_DECREASE_ENABLE, Boolean.valueOf(getBetModel().getBetPerLine().compareTo(getBetModel().getMinBet()) > 0));
    }

    /**
     * Updates visible line buttons.
     */
    private void updateVisibleLineButtons() {
        if (getLinesModel() == null) {
            return;
        }
        setModelProperty(LINES_DECREASE_ENABLE, Boolean.valueOf(getLinesModel().getSelectedLines() > getLinesModel().getMinLines()));
        setModelProperty(LINES_INCREASE_ENABLE, Boolean.valueOf(getLinesModel().getSelectedLines() < getLinesModel().getMaxLines()));
    }

    @Subscribe
    @Override
    public void handleGameMessageChangedEvent(GameMessageChangedEvent gameMessageChangedEvent) {
        super.handleGameMessageChangedEvent(gameMessageChangedEvent);
        String message = getModel().getMessage();
        if (!StringUtility.isNullOrEmpty(message)) {
            message = message.replace("\n", "- ").replace("\r", "- ");
            getModel().setMessage(message);
        }
    }

    /**
     * Reacts to start the info screen transition.
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (screenShowingEvent.getScreen() instanceof InfoScreen) {
            hideAllButtons();
        }
    }

    @Override
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        super.handleBetModelChangedEvent(betModelChangedEvent);
        updateVisibleBetButtons();
    }

    @Override
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        super.handleLinesModelChangedEvent(linesModelChangedEvent);
        String state = getCurrentState();
        if (state!=null && state.equals("Idle")) {
            updateVisibleLineButtons();
        }
    }

    /**
     * Reacts to finish the info screen transition.
     * @param screenShownEvent screen shown event
     */
    @Subscribe
    public void handleScreenShownEvent(ScreenShownEvent screenShownEvent) {
        if (screenShownEvent.getScreen() instanceof InfoScreen) {
            setModelProperty(INFO_ENABLE, Boolean.TRUE);
            setModelProperty(SPIN_ENABLE, Boolean.TRUE);
            setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
            setModelProperty(BET_DECREASE_ENABLE, Boolean.TRUE);
            setModelProperty(BET_INCREASE_ENABLE, Boolean.TRUE);
            setModelProperty(HISTORY_VISIBLE, Boolean.TRUE);
            updateVisibleBetButtons();
            updateVisibleLineButtons();
        }
    }

    /**
     * Hides all buttons.
     */
    private void hideAllButtons() {
        setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        setModelProperty(SPIN_ENABLE, Boolean.FALSE);
        setModelProperty(TAKE_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(BET_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(GAMBLE_ENABLE, Boolean.FALSE);
        setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(BET_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(INFO_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(HISTORY_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, isAutoPlay);
    }

    /**
     * Handles event about that auto play was started.
     * @param autoPlayStartedEvent {@link AutoPlayStartedEvent}
     */
    @Subscribe
    public void handleAutoPlayStartedEvent(AutoPlayStartedEvent autoPlayStartedEvent) {
        isAutoPlay = true;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.TRUE);
    }

    /**
     * Handles event about that auto play was stopped.
     * @param autoPlayStoppedEvent {@link AutoPlayStoppedEvent}
     */
    @Subscribe
    public void handleAutoPlayStoppedEvent(AutoPlayStoppedEvent autoPlayStoppedEvent) {
        isAutoPlay = false;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.FALSE);
    }

    private class ScreenShowingEventObserver extends NextObserver<ScreenShowingEvent> {

        @Override
        public void onNext(final ScreenShowingEvent screenShowingEvent) {
            handleScreenShowingEvent(screenShowingEvent);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(final AutoPlayStoppedEvent autoPlayStoppedEvent) {
            handleAutoPlayStoppedEvent(autoPlayStoppedEvent);
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(final AutoPlayStartedEvent autoPlayStartedEvent) {
            handleAutoPlayStartedEvent(autoPlayStartedEvent);
        }
    }

    private class ScreenShownEventObserver extends NextObserver<ScreenShownEvent> {

        @Override
        public void onNext(final ScreenShownEvent screenShownEvent) {
            handleScreenShownEvent(screenShownEvent);
        }
    }
}
