package ${package};

import com.atsisa.gox.logic.GameState;
import com.atsisa.gox.logic.IGameStateRepository;
import com.atsisa.gox.logic.RepositoryConstants;
import com.atsisa.gox.logic.model.ReelsPresentation;

public class ${GameClassName}StateRepository implements IGameStateRepository {

    private GameState gameState = new GameState(ReelsPresentation.GAME_START, ${GameClassName}Constants.REELS_GAME_INIT, RepositoryConstants.GAMBLER_INIT, RepositoryConstants.BANK_INIT);

    @Override
    public GameState getState() {
        return gameState;
    }

    @Override
    public void save(GameState gameState) {
        this.gameState = gameState;
    }

    @Override
    public void reset() {
        gameState.setPresentation(ReelsPresentation.GAME_START);
        gameState.setBank(RepositoryConstants.BANK_INIT);
        gameState.setReelsGame(${GameClassName}Constants.REELS_GAME_INIT);
    }
}