package ${package};

import java.util.Arrays;

import com.atsisa.gox.logic.model.Reel;
import com.atsisa.gox.logic.model.ReelsGame;

class ${GameClassName}Constants {

    static final ReelsGame REELS_GAME_INIT = new ReelsGame(
            Arrays.asList(
                    new Reel(Arrays.asList(2, 2, 6)),
                    new Reel(Arrays.asList(4, 1, 3)),
                    new Reel(Arrays.asList(4, 3, 3)),
                    new Reel(Arrays.asList(5, 5, 5)),
                    new Reel(Arrays.asList(5, 5, 5))
            ));
}