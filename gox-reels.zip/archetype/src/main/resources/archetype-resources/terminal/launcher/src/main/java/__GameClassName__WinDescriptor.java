package ${package};

import com.atsisa.gox.logic.calculator.IReelGameWinDescriptor;
import com.atsisa.gox.logic.calculator.WinCombinationDescriptor;
import com.atsisa.gox.logic.calculator.enums.CombinationStyle;
import com.atsisa.gox.logic.calculator.enums.FeatureType;
import com.atsisa.gox.logic.calculator.enums.PlaceStyle;
import com.atsisa.gox.logic.calculator.model.MultiplierDescriptor;
import com.atsisa.gox.logic.calculator.model.WildDescriptor;

public class ${GameClassName}WinDescriptor implements IReelGameWinDescriptor {

    private final WinCombinationDescriptor[] winCombinationDescriptors = new WinCombinationDescriptor[] {
            new WinCombinationDescriptor(0, "SYMBOL7_X_5", new byte[] { 6 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 1000),
            new WinCombinationDescriptor(1, "SYMBOL7_X_4", new byte[] { 6 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 500),
            new WinCombinationDescriptor(2, "SYMBOL7_X_3", new byte[] { 6 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 250),
            new WinCombinationDescriptor(3, "SYMBOL6_X_5", new byte[] { 5 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 800),
            new WinCombinationDescriptor(4, "SYMBOL6_X_4", new byte[] { 5 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 400),
            new WinCombinationDescriptor(5, "SYMBOL6_X_3", new byte[] { 5 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 200),
            new WinCombinationDescriptor(6, "SYMBOL5_X_5", new byte[] { 4 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 600),
            new WinCombinationDescriptor(7, "SYMBOL5_X_4", new byte[] { 4 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 300),
            new WinCombinationDescriptor(8, "SYMBOL5_X_3", new byte[] { 4 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 150),
            new WinCombinationDescriptor(9, "SYMBOL4_X_5", new byte[] { 3 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 400),
            new WinCombinationDescriptor(10, "SYMBOL4_X_4", new byte[] { 3 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 200),
            new WinCombinationDescriptor(11, "SYMBOL4_X_3", new byte[] { 3 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 100),
            new WinCombinationDescriptor(12, "SYMBOL3_X_5", new byte[] { 2 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 200),
            new WinCombinationDescriptor(13, "SYMBOL3_X_4", new byte[] { 2 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 100),
            new WinCombinationDescriptor(14, "SYMBOL3_X_3", new byte[] { 2 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 50),
            new WinCombinationDescriptor(15, "SYMBOL2_X_5", new byte[] { 1 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 100),
            new WinCombinationDescriptor(16, "SYMBOL2_X_4", new byte[] { 1 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 50),
            new WinCombinationDescriptor(17, "SYMBOL2_X_3", new byte[] { 1 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 25),
            new WinCombinationDescriptor(18, "SYMBOL1_X_5", new byte[] { 0 }, (byte) 5, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 50),
            new WinCombinationDescriptor(19, "SYMBOL1_X_4", new byte[] { 0 }, (byte) 4, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 25),
            new WinCombinationDescriptor(20, "SYMBOL1_X_3", new byte[] { 0 }, (byte) 3, PlaceStyle.Line, CombinationStyle.LeftToRight, FeatureType.No, 10), };

    private final byte[][] lineDescriptor = new byte[][] {  //
            { 1, 1, 1, 1, 1, }, //
            { 0, 0, 0, 0, 0, }, //
            { 2, 2, 2, 2, 2, }, //
            { 0, 1, 2, 1, 0, }, //
            { 2, 1, 0, 1, 2, }, //
            { 1, 2, 2, 2, 1 }, //
            { 1, 0, 0, 0, 1 }, //
            { 2, 2, 1, 0, 0 }, //
            { 0, 0, 1, 2, 2 }, //
    };

    private final WildDescriptor[] wildDescriptor = new WildDescriptor[] {};

    private final MultiplierDescriptor[] multiplierDescriptor = new MultiplierDescriptor[0];

    @Override
    public WildDescriptor getWildDescriptor(int wildIdx) {
        return wildDescriptor[wildIdx];
    }

    @Override
    public int getWildDescriptorCount() {
        return wildDescriptor.length;
    }

    @Override
    public MultiplierDescriptor getMultiplierDescriptor(int multiplierIdx) {
        return multiplierDescriptor[multiplierIdx];
    }

    @Override
    public int getMultiplierDescriptorCount() {
        return multiplierDescriptor.length;
    }

    @Override
    public int getWinCombinationCount() {
        return winCombinationDescriptors.length;
    }

    @Override
    public byte[][] getLinesDescriptor() {
        return lineDescriptor;
    }

    @Override
    public WinCombinationDescriptor getWinCombinationDescriptor(int winId) {
        return winCombinationDescriptors[winId];
    }

    @Override
    public void setWinCombinationDescriptor(WinCombinationDescriptor[] combinationDescriptor) {

    }

    @Override
    public void setLineDescriptor(byte[][] linedescriptor) {

    }

    @Override
    public void setWildDescriptor(WildDescriptor[] wildDescriptor) {

    }

    @Override
    public byte getReelAmount() {
        return (byte) lineDescriptor[0].length;
    }
}
