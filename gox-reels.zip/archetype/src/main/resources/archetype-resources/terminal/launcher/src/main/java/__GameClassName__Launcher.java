package ${package};

import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.inject.AggregatedModule;
import com.atsisa.gox.inject.IModule;
import com.atsisa.gox.terminal.financial.IBalance;
import com.atsisa.gox.terminal.financial.IFinancialTransaction;
import com.atsisa.gox.terminal.launcher.GameIdentity;
import com.atsisa.gox.terminal.launcher.ReelsGameLauncher;
import com.google.inject.Inject;

public class ${GameClassName}Launcher extends ReelsGameLauncher {

    /**
     * The game identity.
     */
    private final GameIdentity gameIdentity = new GameIdentity("${GameClassName}", 1);

    @Inject
    public ${GameClassName}Launcher(IBalance balance, IFinancialTransaction financialTransaction) {
        super(balance, financialTransaction);
    }

    @Override
    protected JavaGameEntryPoint createGame(IModule module) {
        return new ${GameClassName}DesktopEntryPoint(){
            @Override
            protected IModule getModule() {
                return new AggregatedModule(super.getModule(), new ${GameClassName}LauncherModule(), module);
            }
        };
    }

    @Override
    public GameIdentity getIdentity() {
        return gameIdentity;
    }
}