package ${package};

import com.atsisa.gox.inject.AbstractModule;
import com.atsisa.gox.logic.IGameStateRepository;
import com.atsisa.gox.logic.IGameStateStore;
import com.atsisa.gox.logic.ReelsGameLogic;
import com.atsisa.gox.logic.calculator.IReelGameWinDescriptor;
import com.atsisa.gox.logic.calculator.ReelGameWinCalculator;
import com.atsisa.gox.logic.calculator.model.IReelStrip;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.rng.IRngService;
import com.atsisa.gox.rng.mersenne.RngService;
import com.google.inject.Singleton;

public class ${GameClassName}LauncherModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(IGameStateRepository.class).to(${GameClassName}StateRepository.class).in(Singleton.class);
        bind(IGameStateStore.class).to(IGameStateRepository.class).in(Singleton.class);
        bind(IReelStrip.class).to(${GameClassName}ReelStrip.class).in(Singleton.class);
        bind(IRngService.class).to(RngService.class).in(Singleton.class);
        bind(ReelGameWinCalculator.class).in(Singleton.class);
        bind(IReelGameWinDescriptor.class).to(${GameClassName}WinDescriptor.class).in(Singleton.class);
        bind(ReelsGameLogic.class).in(Singleton.class);
        bind(IReelGameLogic.class).to(${GameClassName}Logic.class).in(Singleton.class);
    }
}