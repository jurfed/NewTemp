package ${package};

import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.calculator.enums.ReelStripType;
import com.atsisa.gox.logic.calculator.model.IReelStrip;

public class ${GameClassName}ReelStrip implements IReelStrip {
    private final int rows = 3;
    private final int reels = 5;

    private final byte lemon = 0x00;
    private final byte seven = 0x01;
    private final byte bell = 0x02;
    private final byte melon = 0x03;
    private final byte grapes = 0x04;
    private final byte plum = 0x05;
    private final byte orange = 0x06;
    private final byte empty = Byte.MIN_VALUE;

    private final double Yield = 92.28;

    public int[] baseGameReelStripLength = { 27, 27, 26, 25, 28 };
    public Byte[][] baseGameReelStrip = {
            { seven,    seven,    seven,    seven,    seven  }, //  0
            { plum,     lemon,    lemon,    orange,   plum   }, //  1
            { plum,     lemon,    lemon,    orange,   plum   }, //  2
            { plum,     lemon,    lemon,    orange,   lemon  }, //  3
            { plum,     lemon,    bell,     orange,   lemon  }, //  4
            { grapes,   melon,    bell,     seven,    lemon  }, //  5
            { seven,    melon,    bell,     orange,   plum   }, //  6
            { grapes,   seven,    orange,   plum,     lemon  }, //  7
            { grapes,   melon,    orange,   plum,     melon  }, //  8
            { lemon,    lemon,    orange,   plum,     orange }, //  9
            { lemon,    lemon,    seven,    bell,     bell   }, // 10
            { lemon,    bell,     orange,   grapes,   orange }, // 11
            { lemon,    bell,     melon,    grapes,   orange }, // 12
            { bell,     bell,     melon,    lemon,    orange }, // 13
            { bell,     plum,     plum,     lemon,    bell   }, // 14
            { bell,     plum,     melon,    lemon,    orange }, // 15
            { lemon,    plum,     plum,     bell,     plum   }, // 16
            { lemon,    plum,     plum,     lemon,    plum   }, // 17
            { melon,    orange,   plum,     bell,     plum   }, // 18
            { melon,    orange,   grapes,   bell,     lemon  }, // 19
            { orange,   orange,   grapes,   bell,     seven  }, // 20
            { melon,    orange,   bell,     plum,     lemon }, // 21
            { orange,   grapes,   lemon,    plum,     lemon }, // 22
            { orange,   grapes,   lemon,    melon,    lemon }, // 23
            { orange,   grapes,   lemon,    melon,    grapes }, // 24
            { orange,   grapes,   lemon,    empty,    bell }, // 25
            { plum,     lemon,    empty,    empty,    grapes }, // 26
            { empty,    empty,    empty,    empty,    grapes }, // 27
    };

    @Override
    public byte[][] getStopSymbols(int[] stopPositions, ReelStripType type) {
        byte[][] result = new byte[rows][reels];

        for(int reel = 0;reel<reels; reel++)
        {
            for(int row = 0;row<rows;row++) {
                result[row][reel] = baseGameReelStrip[(stopPositions[reel] +row) % baseGameReelStripLength[reel]][reel];
            }
        }

        return result;
    }

    @Override
    public int[] GetReelLength(ReelStripType reelstripType) throws GameLogicException {
        if(reelstripType == ReelStripType.BaseGame)
            return baseGameReelStripLength;
        else
            throw new GameLogicException("");
    }
}
