package com.octavianonline.games.eyeOfDragonAndBall.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.Skin;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.games.octavian.core.view.winlines.WinLineFrame;
import com.atsisa.gox.games.octavian.core.view.winlines.WinLinesGroup;
import com.atsisa.gox.logic.provider.ILinesModelProvider;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
/*import com.octavianonline.games.finestblend40.event.PushSymbolAnimationsInWinningLinesCommand;
import com.octavianonline.games.finestblend40.event.WinLineFrameAnimationCommand;*/

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

import static com.atsisa.gox.games.octavian.core.service.GameHelper.toList;

public class EyeOfDragonWinLinesScreen extends Screen<EyeOfDragonWinLinesScreenModel> {

    public static final String LAYOUT_ID_PROPERTY = "WinLinesScreenLayoutId";
    private final List<Subscription> subscriptions = new ArrayList<>();
    private final ILinesModelProvider linesModelProvider;
    private SymbolAnimationFactory factory;
    private List<ViewGroup> winLineViews;
    //private List<WinLineFrame> winLineFrames;
    private List<WinLineFrame> currentLineFrames = new ArrayList<>();

    @InjectView
    private WinLinesGroup winLinesGroup;

    @Inject
    public EyeOfDragonWinLinesScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, EyeOfDragonWinLinesScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, ILinesModelProvider linesModelProvider) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.linesModelProvider = linesModelProvider;
    }

    @Override
    protected void beforeActivated() {
        super.beforeActivated();
        this.subscriptions.add(getEventBus().register(new LinesModelChangedEventObserver(), LinesModelChangedEvent.class));
/*        this.subscriptions.add(getEventBus().register(new PushSymbolAnimationsInWinningLinesCommandObserver(), PushSymbolAnimationsInWinningLinesCommand.class));
        this.subscriptions.add(getEventBus().register(new WinLineFrameAnimationCommandObserver(), WinLineFrameAnimationCommand.class));*/
        this.factory = new SymbolAnimationFactory();
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
        this.winLinesGroup.constructWinLines(this.linesModelProvider.getLineDescriptors().get());
        this.winLineViews = this.winLinesGroup.getWinLineViews();
        //this.winLineFrames = getViewManager().findViewByType(WinLineFrame.class);
        //Collections.reverse(this.winLineFrames);
       // this.winLineFrames.forEach(winLineFrame -> {
       //     winLineFrame.setVisible(false);
        //});

    }


/*    private void handlePushSymbolAnimationsInWinningLinesCommand(PushSymbolAnimationsInWinningLinesCommand command) {
        final List<Iterable<String>> stoppedSymbols = command.getStoppedSymbols();
        for (int i = 0; i < stoppedSymbols.size(); i++) {
            final List<String> names = toList(stoppedSymbols.get(i));
            final int size = names.size();
            for (int j = 0; j < size; j++) {
                int index = i + j * stoppedSymbols.size();
                final WinLineFrame winLineFrame = this.winLineFrames.get(index);
                final String symbolName = names.get(j);
                winLineFrame.setAnimationSkin(this.factory.getSkin(symbolName));
                final KeyframeAnimationView symbolAnimation = winLineFrame.getSymbolAnimation();
                symbolAnimation.setY(17f);
                symbolAnimation.setX(0f);
                if (symbolName.equals("SEVEN") || symbolName.equals("SCATTER")) {
                    symbolAnimation.setX(-17f);
                }
                if (symbolAnimation.isPlaying()) {
                    symbolAnimation.stop();
                }
                symbolAnimation.play();
            }
        }
    }*/


    private void handleLinesModelChangedEvent(LinesModelChangedEvent event) {
        switch (event.getChangeType()) {
            case LinesModelChangedEvent.CURRENT_WINNING_LINE:
                this.hideWinLines();
                if (event.getLinesModel().getCurrentWinningLine().isPresent()) {
                    this.handleCurrentWinningLineEvent(event.getLinesModel().getCurrentWinningLine().get());
                }
                break;
            case LinesModelChangedEvent.AVAILABLE_LINES:
                break;
            case LinesModelChangedEvent.SELECTED_LINES:
                break;
            case LinesModelChangedEvent.WINNING_LINES:
                break;
            default:
                break;
        }
    }

    private void hideWinLines() {
        this.winLineViews.forEach(view -> {
            if (view.isVisible()) {
                view.setVisible(false);
            }
        });
/*        this.winLineFrames.forEach(winLineFrame -> {
            if (winLineFrame.isVisible()) {
                winLineFrame.setVisible(false);
            }
        });*/
    }


    private void showFrames(IWinLineInfo currentWinningLine) {
        this.currentLineFrames.clear();
        final List<Integer> positions = toList(currentWinningLine.getPositions());
        for (int i = 0; i < positions.size(); i++) {
            final Integer position = positions.get(i);
            if (position >= 0) {
                int index = (i + 5 * position);
/*                final WinLineFrame winLineFrame = this.winLineFrames.get(index);
                winLineFrame.setVisible(true);
                this.currentLineFrames.add(winLineFrame);*/
            }
        }
    }

    private void showLine(IWinLineInfo currentWinningLine) {
        final int lineNumber = currentWinningLine.getLineNumber() - 1;
        if (lineNumber >= 0) {
            this.winLineViews.get(lineNumber).setVisible(true);
        }
    }


    @Override
    protected void beforeDeactivated() {
        super.beforeDeactivated();
        this.subscriptions.forEach(Subscription::unsubscribe);
    }

/*    private void handleWinLineFrameAnimationCommand(WinLineFrameAnimationCommand command) {
        this.currentLineFrames.forEach(winLineFrame -> winLineFrame.runAnimation(command.getScale(), (int) command.getTime()));
    }*/


    private void handleCurrentWinningLineEvent(IWinLineInfo currentWinningLine) {
        this.showLine(currentWinningLine);
        this.showFrames(currentWinningLine);
    }

    private class LinesModelChangedEventObserver extends NextObserver<LinesModelChangedEvent> {
        @Override
        public void onNext(LinesModelChangedEvent event) {
            handleLinesModelChangedEvent(event);
        }
    }

    private final class SymbolAnimationFactory {
        private final Skin watterMelon;
        private final Skin plum;
        private final Skin lemon;
        private final Skin orange;
        private final Skin cherry;
        private final Skin scatter;
        private final Skin bell;
        private final Skin seven;

        private SymbolAnimationFactory() {
            bell = getViewManager().getSkinManager().getSkin("BELL_animation");
            scatter = getViewManager().getSkinManager().getSkin("SCATTER_animation");
            cherry = getViewManager().getSkinManager().getSkin("CHERRY_animation");
            orange = getViewManager().getSkinManager().getSkin("ORANGE_animation");
            lemon = getViewManager().getSkinManager().getSkin("LEMON_animation");
            plum = getViewManager().getSkinManager().getSkin("PLUM_animation");
            watterMelon = getViewManager().getSkinManager().getSkin("WATERMELON_animation");
            seven = getViewManager().getSkinManager().getSkin("SEVEN_animation");

        }

        public Skin getSkin(String symbolName) {
            switch (symbolName) {
                case "BELL":
                    return bell;
                case "SEVEN":
                    return seven;
                case "WATERMELON":
                    return watterMelon;
                case "SCATTER":
                    return scatter;
                case "CHERRY":
                    return cherry;
                case "ORANGE":
                    return orange;
                case "LEMON":
                    return lemon;
                case "PLUM":
                    return plum;
                default:
                    throw new RuntimeException("Unknown symbol name " + symbolName);
            }
        }


//        KeyframeAnimationView getAnimation(String symbolName) {
//            KeyframeAnimationView view = new KeyframeAnimationView();
//            switch (symbolName) {
//                case "BELL":
//                    view.setSkin(bell);
//                    break;
//                case "WATERMELON":
//                    view.setSkin(watterMelon);
//                    break;
//                case "SCATTER":
//                    view.setSkin(scatter);
//                    break;
//                case "CHERRY":
//                    view.setSkin(cherry);
//                    break;
//                case "ORANGE":
//                    view.setSkin(orange);
//                    break;
//                case "LEMON":
//                    view.setSkin(lemon);
//                    break;
//                case "PLUM":
//                    view.setSkin(plum);
//                    break;
//                default:
//                    throw new RuntimeException("Unknown symbol name " + symbolName);
//
//            }
//            return view;
//        }
    }

/*    private class PushSymbolAnimationsInWinningLinesCommandObserver extends NextObserver<PushSymbolAnimationsInWinningLinesCommand> {

        @Override
        public void onNext(PushSymbolAnimationsInWinningLinesCommand command) {
            handlePushSymbolAnimationsInWinningLinesCommand(command);
        }
    }

    private class WinLineFrameAnimationCommandObserver extends NextObserver<WinLineFrameAnimationCommand> {

        @Override
        public void onNext(WinLineFrameAnimationCommand command) {
            handleWinLineFrameAnimationCommand(command);
        }
    }*/


}

