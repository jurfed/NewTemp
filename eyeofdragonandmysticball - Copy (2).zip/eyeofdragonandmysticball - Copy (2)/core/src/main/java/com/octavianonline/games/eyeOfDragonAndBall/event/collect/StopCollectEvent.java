package com.octavianonline.games.eyeOfDragonAndBall.event.collect;

public class StopCollectEvent {
}
