package com.octavianonline.games.eyeOfDragonAndBall.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.inject.Inject;

import com.atsisa.gox.financial.FinancialException;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.ReelsPresentation;
import com.atsisa.gox.logic.model.InitialParameters;
import com.atsisa.gox.logic.model.ReelsGameConfiguration;
import com.atsisa.gox.logic.provider.IReelsGameConfigurationProvider;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.request.InitRequest;

public class QueenCleopatraPresentationFactory {

    private static final String ENGLISH_LANG_CODE = "EN";

    private static final String GERMAN_LANG_CODE = "DE";

    private final IBalance balance;

    private final GameConfigurationAdapter gameConfigurationAdapter;

    private final IReelsGameConfigurationProvider reelsGameConfigurationProvider;

    @Inject
    public QueenCleopatraPresentationFactory(IBalance balance, GameConfigurationAdapter gameConfigurationAdapter,  IReelsGameConfigurationProvider reelsGameConfigurationProvider) {
        this.balance = balance;
        this.gameConfigurationAdapter = gameConfigurationAdapter;
        this.reelsGameConfigurationProvider = reelsGameConfigurationProvider;
    }

    public List<Object> getPresentations(InitRequest initRequest) throws GameLogicException {
        List<Object> presentations = new ArrayList<>();
        long creditsAmount;
        try {
            creditsAmount = balance.getBalance();
        } catch (FinancialException e) {
            throw new GameLogicException("Cannot obtain balance credits amount", e);
        }
        Optional<ReelsGameConfiguration> reelsGameConfiguration = reelsGameConfigurationProvider.get();
        if (!reelsGameConfiguration.isPresent()) {
            throw new GameLogicException("The reel game configuration is empty.");
        }
        InitialParameters initialParameters = reelsGameConfiguration.get().getInitialParameters();
        InitResult initResult = new InitResult(gameConfigurationAdapter.getGameConfiguration(), initRequest.getLanguageCode(),
                this.getAvailableLanguageCodes());
        ReelGamePresentation reelGamePresentation = new ReelGamePresentation(ReelsPresentation.GAME_START.getName(),
                new GameplayProperties(initialParameters.getInitialLinesAmount(), initialParameters.getInitialBetPerLine(), creditsAmount), QueenCleopatraInitialStopReels.INITIAL_REELS, false, false);

        presentations.add(initResult);
        presentations.add(reelGamePresentation);
        return presentations;
    }

    private List<String> getAvailableLanguageCodes() {
        List<String> availableLanguageCodes = new ArrayList<>();
        availableLanguageCodes.add(ENGLISH_LANG_CODE);
        availableLanguageCodes.add(GERMAN_LANG_CODE);
        return availableLanguageCodes;
    }

}
