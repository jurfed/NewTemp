package com.octavianonline.games.eyeOfDragonAndBall.logic;

import com.atsisa.gox.logic.ExtendedSymbolRequest;
import com.atsisa.gox.logic.ExtendedSymbolResult;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.reels.backend.IStep;
import com.atsisa.gox.reels.logic.ExtendedSymbolWinResult;

import java.util.Map;

public class FixedParseExtendedSymbolResult implements IStep {
    private final FixedWinConverter winConverter = new FixedWinConverter();
    private final ExtendedSymbolRequest extendedSymbolRequest;
    private final ExtendedSymbolResult extendedSymbolResult;
    private final Map<Integer, String> extendedSymbolWinSounds;

    public FixedParseExtendedSymbolResult(ExtendedSymbolRequest extendedSymbolRequest, ExtendedSymbolResult extendedSymbolResult, Map<Integer, String> extendedSymbolWinSounds) {
        this.extendedSymbolRequest = extendedSymbolRequest;
        this.extendedSymbolResult = extendedSymbolResult;
        this.extendedSymbolWinSounds = extendedSymbolWinSounds;
    }

    public Map<String, Object> execute(Map<String, Object> logicPresentationMap) throws GameLogicException {
        if (this.extendedSymbolResult.getBank().getWinAmount() != 0L) {
            logicPresentationMap.put(ExtendedSymbolWinResult.class.getName(), new ExtendedSymbolWinResult(this.winConverter.convertExtendedWinningLines(this.extendedSymbolResult.getWinningLines(), this.extendedSymbolRequest.getStopSymbols().size(), this.extendedSymbolWinSounds, this.extendedSymbolRequest.getExtendedSymbol().getName())));
        }

        return logicPresentationMap;
    }
}

