package com.octavianonline.games.eyeOfDragonAndBall.action.takewin;

import com.atsisa.gox.framework.action.Action;

public class Ftemp1 extends Action {
    @Override
    protected void execute() {
        finish();
    }
}
