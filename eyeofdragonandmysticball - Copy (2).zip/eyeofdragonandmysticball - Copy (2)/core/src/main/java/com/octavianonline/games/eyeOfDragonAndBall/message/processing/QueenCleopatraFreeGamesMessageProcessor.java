package com.octavianonline.games.eyeOfDragonAndBall.message.processing;

import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.reels.message.Message;
import com.atsisa.gox.reels.message.processing.IMessageProcessor;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;

import javax.inject.Inject;

/**
 * Adjusts messages during free games according to received translations.
 */
public class QueenCleopatraFreeGamesMessageProcessor implements IMessageProcessor {

    /**
     * Free game message.
     */
    private static final String FREE_GAME_MESSAGE = "{#LangFreeSpin}";

    /**
     * Of message.
     */
    private static final String OF_MESSAGE = "{#LangOf}";

    /**
     * Expected template which is supported by  this message processor.
     */
    private static final String EXPECTED_TEMPLATE = FREE_GAME_MESSAGE + " - " + OF_MESSAGE;

    /**
     * Reference to the {@link IFreeGamesModelProvider} instance.
     */
    private final IFreeGamesModelProvider freeGamesModelProvider;

    /**
     * Initializes a new instance of the {@link QueenCleopatraFreeGamesMessageProcessor} class.
     * @param freeGamesModelProvider {@link IFreeGamesModelProvider}
     */
    @Inject
    public QueenCleopatraFreeGamesMessageProcessor(IFreeGamesModelProvider freeGamesModelProvider) {
        this.freeGamesModelProvider = freeGamesModelProvider;
    }

    @Override
    public Message process(Message message) {
        if (EXPECTED_TEMPLATE.equals(message.getContent())) {
            IFreeGamesModel freeGamesModel = freeGamesModelProvider.getModel();
            String newMessage = StringUtility
                    .format("%s %s %s %s", FREE_GAME_MESSAGE, freeGamesModel.getCurrentFreeGameNumber(), OF_MESSAGE, freeGamesModel.getTotalFreeGamesNumber());
            message.setContent(newMessage);
        }
        return message;
    }
}