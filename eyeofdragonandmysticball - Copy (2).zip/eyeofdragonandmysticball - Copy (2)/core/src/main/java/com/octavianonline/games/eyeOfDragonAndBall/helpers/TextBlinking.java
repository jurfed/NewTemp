package com.octavianonline.games.eyeOfDragonAndBall.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.TextView;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.GetLiveGlassObjects;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassAnimationId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassSymbolsId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.GamblerIsStart;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.IdentifiersForFlashingText;

import java.util.HashMap;
import java.util.Hashtable;


/**
 * Class for blinking text with winnings on the Pay table
 */
public class TextBlinking {

    /**
     * Array with TextView to change
     */
    private TextView[] textView;
    private int time;

    /**
     * Contain a color for changing text
     */
//    int colorToChange;

    String fontToChange;

    /**
     * The initial color of the text
     */
    int[] initColor;

    String[] initFont;

    /**
     * Is the text color changed?
     */
    boolean textColorChanged = true;

    /**
     * symbol identifier
     */
    String identifier;

    /**
     * Contains the coefficient number and TextView on the pay table during free games. For exmample: (2, text=2x); (3, text=3x), etc
     */
    Hashtable<Integer, TextView> textMultiplier = new Hashtable();

    /**
     * Contains the coefficient number and TextView on the pay table during free games. For exmample: (4, text=0.25 FUN), etc
     */
    Hashtable<Integer, TextView> textAmount = new Hashtable();


    /**
     * To define an extended character during free games
     */
    ImageView symbolFree;

    /**
     * To define a coefficient during free games
     */
    Integer symbolXNumber;

    /**
     * To determine if an extended character is visible
     */
    boolean extendedSymbol = false;

    private HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation = new HashMap<>();
    private GetLiveGlassObjects liveGlassObjects;
    private HashMap<String, ImageView> symbolsImageView = new HashMap<>();

    public TextBlinking(TextView[] textView, int time, String fontFirst, String identifier) {
        liveGlassObjects = new GetLiveGlassObjects("payTableBgrScreen", GameEngine.current().getViewManager());
        mapUpperScreenSymbolsAnimation = liveGlassObjects.getLiveGlassAnimation(LiveGlassAnimationId.getSyblosAnimationsNames());
        symbolsImageView = liveGlassObjects.getLiveGlassSymbols(LiveGlassSymbolsId.getSyblosNames());
        this.textView = textView;
        this.time = time;

        this.fontToChange = fontFirst;

        this.identifier = identifier;


        initFont = new String[textView.length];
        for (int i = 0; i < textView.length; i++) {
            initFont[i] = textView[i].getFontName();
        }
    }

    /**
     * Determines whether the free game is active and starts a flashing cycle
     */
    public void start() {

        symbolFree = GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, identifier);

        //If the expanded symbol is active and the incoming symbol coincides with it, we will change the color of the inscriptions of the active symbol
        if (symbolFree != null && symbolFree.isVisible()) {
            extendedSymbol = true;
            symbolXNumber = Integer.parseInt(textView[0].getText().substring(0, 1));
        }

        for (int i = 2; i <= 5; i++) {
            textMultiplier.put(i, GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, i + IdentifiersForFlashingText.EXTENDED_SYMBOL_MULTIPLIER));
            textAmount.put(i, GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, i + IdentifiersForFlashingText.EXTENDED_SYMBOL));
        }

        new Timeout(time, new TimeoutTextBlinking(), false).start();
    }

    /**
     * Class for cyclical change of text color
     */
    private class TimeoutTextBlinking implements TimeoutCallback {

        @Override
        public void onTimeout() {
            if (textColorChanged) {//return the initial color
                if (extendedSymbol) {
                    textMultiplier.get(symbolXNumber).setFontName(fontToChange);
                    textAmount.get(symbolXNumber).setFontName(fontToChange);
                } else {
                    for (int i = 0; i < textView.length; i++) {
                        textView[i].setFontName(fontToChange);
                    }
                }
                textColorChanged = false;
            } else {//change the text color
                if (extendedSymbol) {
                    textMultiplier.get(symbolXNumber).setFontName(initFont[0]);
                    textAmount.get(symbolXNumber).setFontName(initFont[1]);


                } else {
                    for (int i = 0; i < textView.length; i++) {
                        textView[i].setFontName(initFont[i]);
                    }
                }
                textColorChanged = true;
            }
            if (IdentifiersForFlashingText.playingBlinking.get(identifier) && !GamblerIsStart.gamblerIsStart) {//Re-change text color if the symbol is playing and gamble game not started
                new Timeout(time, new TimeoutTextBlinking(), false).start();
            } else {
                IdentifiersForFlashingText.sympleTextBlinking.put(textView[1].getId(), false);
                if (extendedSymbol) {//At the end we return the initial color
                    textMultiplier.get(symbolXNumber).setFontName(initFont[0]);
                    textAmount.get(symbolXNumber).setFontName(initFont[1]);

                } else {
                    for (int i = 0; i < textView.length; i++) {
                        textView[i].setFontName(initFont[i]);
                    }
                }
                extendedSymbol = false;
                AniliseSymbolsForBlinking.getLines=false;
                if (GamblerIsStart.gamblerIsStart) {
                    for (String key : mapUpperScreenSymbolsAnimation.keySet()) {
                        mapUpperScreenSymbolsAnimation.get(key).setVisible(false);
                    }

                    for (String key : symbolsImageView.keySet()) {
                        symbolsImageView.get(key).setVisible(true);
                    }
                }

            }
        }
    }
}