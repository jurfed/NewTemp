package com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

public class IdentifiersForFlashingText {
    public static ArrayList<String> SymbolsName = new ArrayList();

    //Does this text is blinking now (true/false): 5person, 4person, 3person, 2person, 5AceKing, 4AceKing, etc...
    public static HashMap<String, Boolean> sympleTextBlinking = new HashMap();

    //Does this text is blinking now (true/false): 5personMultiplier, 4personMultiplier, 3personMultiplier, etc...
    //not used
    public static HashMap<String, Boolean> multiplierTextBlinking = new HashMap();

    //Does this character is playing now(true/false). Used by class TextBlinking to understand when to stop flashing text
    public static HashMap<String, Boolean> playingBlinking = new HashMap();

    //("Person", "personMultiplier"), ("Jack", "TenQueenJackMultiplier"),("Ace", "AceKingMultiplier") , etc...
    public static HashMap<String, String> symbolMultiplierName = new HashMap();

    //("Person", "person"), ("Queen", "TenQueenJack"), ("King", "AceKing"), etc...
    public static HashMap<String, String> symbolSympleName = new HashMap();

    public static final String PAY_TABLE_SCREEN = "payTableScreen";

    /**
     * Identifier for TextView on the Pay Table during free games
     */
    public static final String EXTENDED_SYMBOL_MULTIPLIER = "extendedSymbolMultiplier";
    public static final String EXTENDED_SYMBOL = "extendedSymbol";

    public static Hashtable<String, Boolean> tombState = new Hashtable<>();

//    public final static int textColor=0x6affff;
    public final static String textFontBase="seepays_wins3";

    public final static String textFont="seepays_wins3";
    public final static int blinkingTime=500;

    /**
     *Is the Scatter symbol currently animated?
     */
    public static boolean startScatterTextBlinking=false;

    /**
     * Number of active Scatter symbols
     */
    public static volatile int tombCount=0;


    public static String tombSymbolName="Tomb";

    public IdentifiersForFlashingText() {
        SymbolsName.add("Cleopatra");
        SymbolsName.add("Queen");
        SymbolsName.add("Ten");
        SymbolsName.add("Jack");
        SymbolsName.add("Bracelet");
        SymbolsName.add("Griffin");
        SymbolsName.add("Ace");
        SymbolsName.add("King");
        SymbolsName.add("Necklace");

        sympleTextBlinking.put("5Cleopatra", false);
        sympleTextBlinking.put("4Cleopatra", false);
        sympleTextBlinking.put("3Cleopatra", false);
        sympleTextBlinking.put("2Cleopatra", false);

        sympleTextBlinking.put("5Griffin", false);
        sympleTextBlinking.put("4Griffin", false);
        sympleTextBlinking.put("3Griffin", false);
        sympleTextBlinking.put("2Griffin", false);

        sympleTextBlinking.put("5Necklace", false);
        sympleTextBlinking.put("4Necklace", false);
        sympleTextBlinking.put("3Necklace", false);
        sympleTextBlinking.put("2Necklace", false);

//        sympleTextBlinking.put("5Tomb", false);
//        sympleTextBlinking.put("4Tomb", false);
//        sympleTextBlinking.put("3Tomb", false);
//        sympleTextBlinking.put("2Tomb", false);

        sympleTextBlinking.put("5TenQueenJack", false);
        sympleTextBlinking.put("4TenQueenJack", false);
        sympleTextBlinking.put("3TenQueenJack", false);

        sympleTextBlinking.put("5AceKing", false);
        sympleTextBlinking.put("4AceKing", false);
        sympleTextBlinking.put("3AceKing", false);

        sympleTextBlinking.put("5Bracelet", false);
        sympleTextBlinking.put("4Bracelet", false);
        sympleTextBlinking.put("3Bracelet", false);
        sympleTextBlinking.put("2Bracelet", false);

        multiplierTextBlinking.put("5CleopatraMultiplier", false);
        multiplierTextBlinking.put("4CleopatraMultiplier", false);
        multiplierTextBlinking.put("3CleopatraMultiplier", false);
        multiplierTextBlinking.put("2CleopatraMultiplier", false);

        multiplierTextBlinking.put("5GriffinMultiplier", false);
        multiplierTextBlinking.put("4GriffinMultiplier", false);
        multiplierTextBlinking.put("3GriffinMultiplier", false);
        multiplierTextBlinking.put("2GriffinMultiplier", false);

        multiplierTextBlinking.put("5NecklaceMultiplier", false);
        multiplierTextBlinking.put("4NecklaceMultiplier", false);
        multiplierTextBlinking.put("3NecklaceMultiplier", false);
        multiplierTextBlinking.put("2NecklaceMultiplier", false);

//        multiplierTextBlinking.put("5TombMultiplier", false);
//        multiplierTextBlinking.put("4TombMultiplier", false);
//        multiplierTextBlinking.put("3TombMultiplier", false);
//        multiplierTextBlinking.put("2TombMultiplier", false);

        multiplierTextBlinking.put("5TenQueenJackMultiplier", false);
        multiplierTextBlinking.put("4TenQueenJackMultiplier", false);
        multiplierTextBlinking.put("3TenQueenJackMultiplier", false);

        multiplierTextBlinking.put("5BraceletMultiplier", false);
        multiplierTextBlinking.put("4BraceletMultiplier", false);
        multiplierTextBlinking.put("3BraceletMultiplier", false);
        multiplierTextBlinking.put("2BraceletMultiplier", false);

        multiplierTextBlinking.put("5AceKingMultiplier", false);
        multiplierTextBlinking.put("4AceKingMultiplier", false);
        multiplierTextBlinking.put("3AceKingMultiplier", false);
        multiplierTextBlinking.put("2AceKingMultiplier", false);

        for (String symbolName : IdentifiersForFlashingText.SymbolsName) {
//            sendBlinking.put(symbolName, false);
            playingBlinking.put(symbolName, false);
        }

        symbolMultiplierName.put("Cleopatra", "CleopatraMultiplier");
        symbolMultiplierName.put("Queen", "TenQueenJackMultiplier");
        symbolMultiplierName.put("Ten", "TenQueenJackMultiplier");
        symbolMultiplierName.put("Jack", "TenQueenJackMultiplier");
        symbolMultiplierName.put("Bracelet", "BraceletMultiplier");
        symbolMultiplierName.put("Griffin", "GriffinMultiplier");
        symbolMultiplierName.put("Ace", "AceKingMultiplier");
        symbolMultiplierName.put("King", "AceKingMultiplier");
        symbolMultiplierName.put("Necklace", "NecklaceMultiplier");
//        symbolMultiplierName.put("Tomb", "TombMultiplier");

        symbolSympleName.put("Cleopatra", "Cleopatra");
        symbolSympleName.put("Queen", "TenQueenJack");
        symbolSympleName.put("Ten", "TenQueenJack");
        symbolSympleName.put("Jack", "TenQueenJack");
        symbolSympleName.put("Bracelet", "Bracelet");
        symbolSympleName.put("Griffin", "Griffin");
        symbolSympleName.put("Ace", "AceKing");
        symbolSympleName.put("King", "AceKing");
        symbolSympleName.put("Necklace", "Necklace");
//        symbolSympleName.put("Tomb", "Tomb");

        for(int i=1; i<=5; i++){
            tombState.put(i+tombSymbolName, false);
        }
    }

}
