package com.octavianonline.games.eyeOfDragonAndBall.action.playSounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.SoundManager;

import static com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.StartSoundSpeenReelBaseGame.getSoundId;

public class StopSoundSpeenReelBaseGame extends Action {

    private SoundManager spinReelSound;

    @Override
    protected void execute() {
        spinReelSound = (SoundManager) GameEngine.current().getSoundManager();
        if(spinReelSound!=null && getSoundId()!=null) {
            spinReelSound.stop(getSoundId());
        }
        if(!this.isFinished()){
            finish();
        }
    }
}
