package com.octavianonline.games.eyeOfDragonAndBall.screen.model;

import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;

import javax.inject.Inject;


/**
 * Screen model for {@link }. Stores data about total free games number and extended symbol name.
 */
public class QueenCleopatraFeatureScreenModel extends ScreenModel {

    /**
     * Number of all won free games
     */
    private int totalFreeGamesNumber;

    /**
     * Selected extended symbol
     */
    private String selectedExtendedSymbol;

    /**
     * Initializes new instance of {@link QueenCleopatraFeatureScreenModel} class
     * @param translator {@link ITranslator} a translator reference
     */
    @Inject
    public QueenCleopatraFeatureScreenModel(ITranslator translator) {
        super(translator);
    }

    /**
     * Sets total free games number value
     * @param value total free games number
     */
    public void setTotalFreeGamesNumber( int value ){
        totalFreeGamesNumber = value;
    }

    /**
     * Gets total free games number value
     * @return total free games number
     */
    public int getTotalFreeGamesNumber(){
        return totalFreeGamesNumber;
    }

    /**
     * Sets extended symbol name
     * @param value extended symbol name
     */
    public void setExtendedSymbolName( String value ){
        selectedExtendedSymbol = value;
    }

    /**
     * Gets extended symbol name
     * @return extended symbol name
     */
    public String getExtendedSymbolName(){
        return selectedExtendedSymbol;
    }

}