package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.view.WinLineView;
import com.octavianonline.games.eyeOfDragonAndBall.customviews.CustomKeyframeAnimationView;
import com.octavianonline.games.eyeOfDragonAndBall.listener.CustomKeyframeAnimationListener;

import java.util.Map;

/**
 * To process the display of win lines
 */
public class ShowHideWinLines {
    private IViewManager viewManager;
    private WinLineView winLineView;
    private CustomKeyframeAnimationView[] customKeyframeAnimationView = new CustomKeyframeAnimationView[5];
    private CustomKeyframeAnimationListener customKeyframeAnimationListener;
    private ImageView[] lines1Front;
    private ImageView[] lines1Back;
    private static final int REELS_COUNT = 5;

    /**
     * @param segmentsLinesCount
     * @param indexVisibleLines
     * @param viewManager
     * @param winLineView
     * @param LineViewname
     * @param linesSegments
     */
    public ShowHideWinLines(int segmentsLinesCount, int indexVisibleLines, IViewManager viewManager, WinLineView winLineView, String LineViewname, Map<Integer, Integer[]> linesSegments) {
        this.viewManager = viewManager;
        this.winLineView = winLineView;
        lines1Front = new ImageView[segmentsLinesCount];
        lines1Back = new ImageView[segmentsLinesCount];

        //Fill the arrays of line segments and shadow segments for one win line
        for (int i = 0; i < segmentsLinesCount; i++) {
            lines1Front[i] = viewManager.findViewById(LineViewname, (i * 2 + 1) + "");
            lines1Back[i] = viewManager.findViewById(LineViewname, (i * 2 + 2) + "");
        }

        //Initialize the listener animation frame for this win line
        customKeyframeAnimationListener = new CustomKeyframeAnimationListener(customKeyframeAnimationView, lines1Front, lines1Back, segmentsLinesCount, indexVisibleLines, linesSegments);
        startFrameListener();
    }

    /**
     * Gets the animation frame for line
     */
    public void startFrameListener() {
        Iterable<View> linesObjects = winLineView.getChildren();
        int i = 0;
        for (View view : linesObjects) {
            try {
                int index = Integer.parseInt(view.getId());
                    customKeyframeAnimationView[i] = (CustomKeyframeAnimationView) view;
                    customKeyframeAnimationView[i].addPropertyChangedListener(customKeyframeAnimationListener);
                    i++;
            }catch(NumberFormatException e1){
            }catch(ClassCastException e2){
            }
        }
    }
}



