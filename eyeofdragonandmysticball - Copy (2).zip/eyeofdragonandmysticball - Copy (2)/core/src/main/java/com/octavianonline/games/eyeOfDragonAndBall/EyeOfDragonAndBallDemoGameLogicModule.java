package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.Map;
import javax.inject.Named;
import javax.inject.Singleton;

import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.framework.utility.ServicesType;
import com.atsisa.gox.logic.*;
import com.atsisa.gox.logic.calculator.*;
import com.atsisa.gox.logic.handler.DebugDrawStopSymbols;
import com.atsisa.gox.logic.messaging.*;
import com.atsisa.gox.logic.messaging.conditional.*;
import com.atsisa.gox.logic.messaging.handler.*;
import com.atsisa.gox.logic.provider.*;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.IExtendedSymbolGameLogic;
import com.atsisa.gox.reels.logic.IFreeGamesGameLogic;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.rng.IRngService;
import com.atsisa.gox.rng.mersenne.RngService;
import com.octavianonline.games.eyeOfDragonAndBall.logic.GameConfigurationAdapter;
import com.octavianonline.games.eyeOfDragonAndBall.logic.QueenCleopatraDebugLogic;

import com.atsisa.gox.logic.ScatterLogic;
import com.octavianonline.view.EyeOfDragonAndBallWildHitChecker;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.ClassKey;
import dagger.multibindings.IntoMap;
import dagger.multibindings.IntoSet;
import dagger.multibindings.StringKey;

/**
 * Represents an IoC game logic configuration module.
 */
@Module
public abstract class EyeOfDragonAndBallDemoGameLogicModule {

    private static ServiceResolver serviceResolver;

    @Singleton
    @Provides
    static IServiceResolver bindServiceResolver(@Named(GamelogicServicesType.ALL_SERVICES) Map<Class<?>, Object> gamelogicServices) {
        if (serviceResolver == null) {
            serviceResolver = new ServiceResolver(gamelogicServices);
        }
        return serviceResolver;
    }

    @Provides
    @IntoMap
    @Named(ServicesType.CONTROLLERS)
    @Singleton
    @ClassKey(IServiceRegister.class)
    static Object provideServiceRegister(@Named(GamelogicServicesType.ALL_SERVICES) Map<Class<?>, Object> gamelogicServices) {
        if (serviceResolver == null) {
            serviceResolver = new ServiceResolver(gamelogicServices);
        }
        return serviceResolver;
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IGameLogicStateRepository.class)
    public static Object provideGameLogicStateRepository() {
        return new GameLogicStateRepository();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IHistoryCardsProvider.class)
    public static Object provideHistoryCardsProvider() {
        return new HistoryCardsProvider();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IRngService.class)
    public static Object provideRngService() {
        return new RngService();
    }

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IBalance.class)
    abstract Object provideBalance(IBalance balance);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAccount.class)
    abstract Object provideAccount(IAccount account);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ISoundsProvider.class)
    abstract Object provideSoundProvider(ISoundsProvider soundProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAnimationsProvider.class)
    abstract Object provideAnimationProvider(IAnimationsProvider animationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IStopSymbolsProvider.class)
    abstract Object provideStopSymbolProvider(IStopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsDescriptorProvider.class)
    abstract Object provideReelsDescriptorProvider(IReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ILinesCalculator.class)
    abstract Object provideLinesCalculator(LinesCalculator linesCalculator);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IPayTableProvider.class)
    abstract Object providePayTableProvider(IPayTableProvider IGameLogicStateRepository);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsGameConfigurationProvider.class)
    abstract Object provideReelsGameConfigurationProvider(IReelsGameConfigurationProvider reelsGameConfigurationProvider);


    @Singleton
    @Provides
    @Named(ReelsDescriptorProvider.REELS_DESCRIPTOR_FILE_RESOURCE_NAME)
    static String reelsDescriptorFilePath() {
        return "reelstrips";
    }

    @Singleton
    @Provides
    @Named(ReelsGameConfigurationProvider.REELS_GAME_CONFIGURATION_FILE_RESOURCE_NAME)
    static String reelsGameConfigurationFilePath() {
        return "reelsGameConfiguration";
    }

    @Singleton
    @Provides
    @Named(PayTableProvider.PAYTABLE_FILE_RESOURCE_NAME)
    static String payTableConfigurationFilePath() {
        return "payTable";
    }

    @Singleton
    @Provides
    @Named(SoundDescriptionsProvider.REEL_STRIP_SOUNDS_FILE_RESOURCE_NAME)
    static String reelStripsStopSoundsFilePath() {
        return "reelStripStopSounds";
    }

    @Singleton
    @Provides
    @Named(SoundDescriptionsProvider.WIN_SOUNDS_FILE_RESOURCE_NAME)
    static String winSoundsFilePath() {
        return "winSounds";
    }

    @Singleton
    @Provides
    @Named(LinesModelProvider.LINES_FILE_RESOURCE_NAME)
    static String linesPathConfigurationFilePath() {
        return "lines";
    }

    @Singleton
    @Provides
    @Named(AnimationDescriptionsProvider.ANIMATIONS_FILE_RESOURCE_NAME)
    static String animationsFilePath() {
        return "animations";
    }

    @IntoSet
    @Binds
    abstract ILogicInitializable animationProviderInitializableBind(AnimationDescriptionsProvider animationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable soundsProviderInitializableBind(SoundDescriptionsProvider soundsProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelsGameConfigurationInitializableBind(ReelsGameConfigurationProvider reelsGameConfigurationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable paytTableProviderInitializable(PayTableProvider payTableProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelDescriptorProviderInitializable(ReelsDescriptorProvider reelsDescriptorProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelLogicInitializableBind(ReelsLogic reelsLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable gamblerLogicInitializableBind(GamblerLogic gamblerLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable linesModelProviderInitializable(LinesModelProvider linesModelProvider);

    @Binds
    @Singleton
    abstract ILinesCalculator linesCalculatorBind(LinesCalculator linesCalculator);

    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker symbolHitChecker() {
        return new SymbolHitChecker();
    }

    @Binds
    @Singleton
    abstract IReelsGameConfigurationProvider reelsGameConfigurationProviderBind(ReelsGameConfigurationProvider reelGameConfigurationProvider);

    @Binds
    @Singleton
    abstract IReelsDescriptorProvider reelsDescriptorProviderBind(ReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    abstract IStopSymbolsProvider stopSymbolsProviderBind(StopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    abstract ISoundDescriptionsProvider soundsDescriptionsProviderBind(SoundDescriptionsProvider soundProvider);

    @Binds
    @Singleton
    abstract ISoundsProvider soundsProviderBind(SoundsProvider soundProvider);

    @Binds
    @Singleton
    abstract IAnimationsProvider animationProviderBind(AnimationsProvider animationProvider);

    @Binds
    @Singleton
    abstract IAnimationDescriptionsProvider animationDescriptionProviderBind(AnimationDescriptionsProvider animationProvider);


    @Binds
    @Singleton
    abstract IPayTableProvider payTableProviderBind(PayTableProvider payTableProvider);

    @Binds
    @Singleton
    abstract ILinesModelProvider linesProvider(LinesModelProvider linesProvider);

    @Binds
    @Singleton
    abstract IReelsLogic reelsLogicBind(ReelsLogic reelsLogic);

    @Binds
    @Singleton
    abstract IReelGameLogic reelGameLogicBind(QueenCleopatraDebugLogic logic);

    @Binds
    @Singleton
    abstract IDebugReelGameLogic debugReelGameLogic(QueenCleopatraDebugLogic logic);

    @Binds
    @Singleton
    abstract IGamblerLogic gamblerLogicBind(GamblerLogic reelsLogic);

    @Singleton
    @Provides
    public static IGameLogicStateRepository gameLogicStateRepository() {
        return new GameLogicStateRepository();
    }

    @Singleton
    public abstract IntegrationFlowFactory integrationFlowFactory();

    @Singleton
    public abstract GameConfigurationAdapter gameConfigurationAdapter();

    @IntoMap
    @StringKey(CoreConditions.POSITIVE_CONDITION)
    @Singleton
    @Provides
    public static IConditionalMessage positiveCondition() {
        return new PositiveConditionalMessage();
    }

    @IntoMap
    @StringKey(ReelsConditions.SPIN_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage spinWinDetectorCondition() {
        return new SpinWinDetector();
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyWinLimitsHandler() {
        return new ApplyWinLimits();
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateLoseResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_TAKE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createTakeWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateTakeWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.DRAW_STOP_SYMBOLS)
    @Singleton
    @Provides
    public static IMessageHandler drawStopSymbolsHandler(IServiceResolver serviceResolver) {
        return new DebugDrawStopSymbols(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.REEL_DEPOSIT_WIN)
    @Singleton
    @Provides
    public static IMessageHandler reelDepositWinHandler(IServiceResolver serviceResolver) {
        return new ReelDepositWin(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinArgumentValidatorHandler(IServiceResolver serviceResolver) {
        return new SpinArgumentValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_BALANCE_VERIFIER)
    @Singleton
    @Provides
    public static IMessageHandler spinBalanceVerifierHandler(IServiceResolver serviceResolver) {
        return new SpinBalanceVerifier(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinStateValidatorHandler(IGameLogicStateRepository stateRepository) {
        return new com.octavianonline.games.eyeOfDragonAndBall.logic.handler.SpinStateValidator(stateRepository);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_WITHDRAW_MONEY)
    @Singleton
    @Provides
    public static IMessageHandler spinWithdrawMoney(IServiceResolver serviceResolver) {
        return new SpinWithdrawMoney(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.TAKE_WIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler takeWinStateValidatorHandler(IServiceResolver serviceResolver) {
        return new TakeWinStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.WIN_LINES_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler winLinesCalculatorHandler(IServiceResolver serviceResolver) {
        return new WinLinesCalculator(serviceResolver);
    }

    @Provides
    @Singleton
    static IHistoryCardsProvider historyCardsProviderBind() {
        return new HistoryCardsProvider();
    }

    @IntoMap
    @StringKey(GamblerHandlers.ENTER_GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler enterGamblerStateValidator(IServiceResolver serviceResolver) {
        return new EnterGamblerStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_ENTER_GAMBLER_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createEnterGamblerResponse(IServiceResolver serviceResolver) {
        return new CreateEnterGamblerResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerConditions.GAMBLE_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage gambleWinDetector() {
        return new GambleWinDetector();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerArgumentValidator() {
        return new GamblerArgumentValidator();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerStateValidator(IServiceResolver serviceResolver) {
        return new GamblerStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleWinResponse(IServiceResolver serviceResolver) {
        return new CreateGambleWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleLoseResponse(IServiceResolver serviceResolver) {
        return new CreateGambleLoseResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.DRAW_GAMBLE_CARD)
    @Singleton
    @Provides
    public static IMessageHandler drawGambleCard(IServiceResolver serviceResolver) {
        return new DrawGambleCard(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.APPLY_GAMBLER_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyGamblerLimits(IGameLogicStateRepository gameLogicStateRepository) {
        return new ApplyGamblerLimits();
    }

    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker wildSymbolHitChecker() {
        return new EyeOfDragonAndBallWildHitChecker();
    }


    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IScatterCalculator.class)
    abstract Object provideScatterCalculator(IScatterCalculator scatterCalculator);

    @Binds
    @Singleton
    abstract IScatterLogic bindScatterLogic(ScatterLogic scatterLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable scatterLogicInitializableBind(ScatterLogic scatterLogic);

    // Scatter
    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterArgumentValidator() {
        return new ScatterArgumentValidator();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterStateValidatorHandler(IServiceResolver serviceResolver) {
        return new ScatterStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_WIN_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler scatterWinCalculatorHandler(IServiceResolver serviceResolver) {
        return new ScatterWinCalculator(serviceResolver);
    }


    @IntoMap
    @StringKey(ScatterConditions.SCATTER_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage scatterWinDetectorCondition() {
        return new ScatterWinDetector();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.SCATTER_APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler scatterApplyWinLimitsHandler() {
        return new ScatterApplyWinLimits();
    }

    @IntoMap
    @StringKey(ScatterLogicHandler.CREATE_SCATTER_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createScatterWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateScatterWinResponse(serviceResolver);
    }


    @IntoMap
    @StringKey(ScatterLogicHandler.CREATE_SCATTER_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createScatterLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateScatterLoseResponse(serviceResolver);
    }


    @Binds

    @Singleton

    abstract IScatterCalculator bindIScatterCalculator(ScatterCalculator calculator);


    @Binds

    @Singleton

    abstract IScatterConfigurationProvider bindScatterConfigurationProvider(ScatterConfigurationProvider scatterConfigurationProvider);


    @Binds

    @IntoSet

    abstract ILogicInitializable initializeScatterConfigurationProvider(ScatterConfigurationProvider scatterConfigurationProvider);


    @Provides
    @Singleton
    @Named("scatterConfigurationId")
    static String bindScatterConfigurationId() {
        return "scatterPayTable";
    }

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IFreeGamesConfigurationProvider.class)
    abstract Object provideFreeGamesConfigurationProvider(IFreeGamesConfigurationProvider freeGamesConfigurationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IFreeGamePayTableProvider.class)
    abstract Object provideFreeGamesPayTableProvider(IFreeGamePayTableProvider freeGamePayTableProvider);

    @Singleton
    @Provides
    @Named(FreeGamesConfigurationProvider.FREE_GAMES_CONFIGURATION_RESOURCE_NAME)
    static String freeGamesConfiguratioFilePath() {
        return "freeGameConfiguration";
    }

    @Singleton
    @Provides
    @Named(FreeGamePayTableProvider.PAYTABLE_FILE_RESOURCE_NAME)
    static String freeGamesPayTableFilePath() {
        return "freeGamePayTable";
    }

    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesLogicInitializable(FreeGamesLogic freeGamesLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesConfigurationProvider(FreeGamesConfigurationProvider freeGamesConfigurationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable freeGamesPayTableProvider(FreeGamePayTableProvider freeGamePayTableProvider);

    @Binds
    @Singleton
    abstract IFreeGamesGameLogic freeGamesGameLogic(QueenCleopatraDebugLogic logic);

    @Binds
    @Singleton
    abstract IFreeGamesLogic freeGamesLogicBind(FreeGamesLogic freeGamesLogic);

    @Binds
    @Singleton
    abstract IFreeGamesConfigurationProvider freeGamesConfigurationProviderBind(FreeGamesConfigurationProvider configurationProvider);

    @Binds
    @Singleton
    abstract IFreeGamePayTableProvider freeGamePayTableProviderBind(FreeGamePayTableProvider freeGamePayTableProvider);

    //Free games
    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES_REQUEST_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesRequestValidatorHandler() {
        return new CalculateFreeGamesRequestValidator();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesStateValidatorHandler(IServiceResolver serviceResolver) {
        return new CalculateFreeGamesStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CALCULATE_FREE_GAMES)
    @Singleton
    @Provides
    public static IMessageHandler calculateFreeGamesHandler(IServiceResolver serviceResolver) {
        return new CalculateFreeGamesAmount(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicConditions.FREE_GAMES_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage freeGamesDetector() {
        return new FreeGamesDetector();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAMES_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGamesWinResponse(IServiceResolver serviceResolver) {
        return new CreateFreeGamesWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_NO_FREE_GAMES_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createNoFreeGamesResponse(IServiceResolver serviceResolver) {
        return new CreateNoFreeGamesResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.SPIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesSpinStateValidator(IServiceResolver serviceResolver) {
        return new FreeGameSpinStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.FREE_GAMES_AMOUNT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesAmountValidatorHandler(IServiceResolver serviceResolver) {
        return new FreeGamesSpinAmountValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.DRAW_STOP_SYMBOLS)
    @Singleton
    @Provides
    public static IMessageHandler drawStopSymbolsInFreeGamesHandler(IServiceResolver serviceResolver) {
        return new FreeGameDrawStopSymbols(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.WIN_LINES_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler freeGamesWinLinesCalculatorHandler(IServiceResolver serviceResolver) {
        return new FreeGamesWinCalculatorWithExcludedSymbols(serviceResolver);
//        return new FreeGamesWinCalculator(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.INCREMENT_FREE_GAME_SPIN_AMOUNT)
    @Singleton
    @Provides
    public static IMessageHandler incrementFreeGameSpinAmountHandler(IServiceResolver serviceResolver) {
        return new IncrementFreeGameSpinAmount(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicConditions.FREE_GAME_SPIN_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage freeGameSpinWinDetectorHandler() {
        return new FreeGameSpinWinDetector();
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAME_SPIN_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGameSpinWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateFreeGameSpinWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(FreeGamesLogicHandlers.CREATE_FREE_GAME_SPIN_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createFreeGameSpinLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateFreeGameSpinLoseResponse(serviceResolver);
    }

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolPayTableProvider.class)
    abstract Object provideExtendedSymbolPayTableProvider(IExtendedSymbolPayTableProvider extendedSymbolPayTableProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolCalculator.class)
    abstract Object provideExtendedSymbolCalculatorProvider(IExtendedSymbolCalculator extendedSymbolCalculator);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IExtendedSymbolConfigurationProvider.class)
    abstract Object provideExtendedSymbolConfigurationProvider(IExtendedSymbolConfigurationProvider extendedSymbolConfigurationProvider);

    @Singleton
    @Provides
    @Named(ExtendedSymbolConfigurationProvider.EXTENDED_SYMBOL_DESCRIPTOR_FILE_RESOURCE_NAME)
    static String extendedSymbolConfigurationFilePath() {
        return "extendedSymbolConfiguration";
    }

    @Singleton
    @Provides
    @Named(ExtendedSymbolPayTableProvider.EXTENDED_SYMBOL_PAYTBABLE_RESOURCE_NAME)
    static String extendedSymbolPayTableFilePath() {
        return "extendedSymbolPayTable";
    }

    @IntoSet
    @Binds
    abstract ILogicInitializable extendedSymbolLogicInitializable(ExtendedSymbolLogic extendedSymbolLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable extendedSymbolConfigurationProvider(ExtendedSymbolConfigurationProvider extendedSymbolConfigurationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable extendedSymbolPayTableProvider(ExtendedSymbolPayTableProvider extendedSymbolPayTableProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolGameLogic extendedSymbolGameLogic(QueenCleopatraDebugLogic logic);

    @Binds
    @Singleton
    abstract IExtendedSymbolLogic extendedSymbolLogic(ExtendedSymbolLogic extendedSymbolLogic);

    @Binds
    @Singleton
    abstract IExtendedSymbolConfigurationProvider extendedSymbolConfigurationProviderBind(
            ExtendedSymbolConfigurationProvider extendedSymbolConfigurationProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolPayTableProvider extendedSymbolPayTableProviderBind(ExtendedSymbolPayTableProvider extendedSymbolPayTableProvider);

    @Binds
    @Singleton
    abstract IExtendedSymbolCalculator extendedSymbolCalculatorBind(ExtendedSymbolCalculator extendedSymbolCalculator);

    @IntoSet
    @Provides
    @Singleton
    public static IExtendedSymbolHitChecker extendedSymbolHitChecker() {
        return new ExtendedSymbolHitChecker();
    }

    // Extended symbol
    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.DRAW_SYMBOL_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler drawExtendedSymbolStateValidator(IServiceResolver serviceResolver) {
        return new DrawSymbolStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.DRAW_SYMBOL)
    @Singleton
    @Provides
    public static IMessageHandler drawExtendedSymbolHandler(IServiceResolver serviceResolver) {
        return new DrawSymbol(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.CREATE_DRAW_SYMBOL_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createDrawSymbolResponseHandler(IServiceResolver serviceResolver) {
        return new CreateDrawSymbolResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.EXTENDED_SYMBOL_REQUEST_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler extendedSymbolRequestValidator(IServiceResolver serviceResolver) {
        return new ExtendedSymbolRequestArgumentValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.EXTENDED_SYMBOL_REQUEST_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler extendedSymbolRequestStateValidator(IServiceResolver serviceResolver) {
        return new ExtendedSymbolRequestStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.EXTEND_SYMBOL_ON_REEL)
    @Singleton
    @Provides
    public static IMessageHandler extendSymbolOnReelHandler() {
        return new ExtendSymbolOnReel();
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.CALCULATE_EXTENDED_SYMBOL_WIN)
    @Singleton
    @Provides
    public static IMessageHandler calculateExtendedSymbolWinHandler(IServiceResolver serviceResolver) {
        return new CalculateExtendedSymbolWin(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicConditions.EXTENDED_SYMBOL_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage extendedSymbolWinDetector() {
        return new ExtendedSymbolWinDetector();
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler extendedSymbolApplyWinLimits() {
        return new ExtendedSymbolApplyWinLimits();
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.CREATE_EXTENDED_SYMBOL_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createExtendedSymbolWinResponse(IServiceResolver serviceResolver) {
        return new CreateExtendedSymbolWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ExtendedSymbolLogicHandlers.CREATE_EXTENDED_SYMBOL_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createExtendedSymbolLoseResponse(IServiceResolver serviceResolver) {
        return new CreateExtendedSymbolLoseResponse(serviceResolver);
    }


}
