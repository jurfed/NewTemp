package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.StartControlPanelWinCollectCommand;
import com.octavianonline.games.eyeOfDragonAndBall.action.collect.FinishCollect;

public class InitCollectFreeGames extends Action {
    @Override
    protected void execute() {
        long totalAmount = GetWinAmountsForCollect.getTotalAmountForBigWin();
        long startAmount = GetWinAmountsForCollect.getStartAmountForBigWin();
        int collectTime = (int) FinishCollect.getCollectTime();

        if (!GetWinAmountsForCollect.isTerminate()) {
            GameEngine.current().getEventBus().post(new StartControlPanelWinCollectCommand(collectTime,new Long(startAmount),totalAmount));
        }
        finish();
    }
}
