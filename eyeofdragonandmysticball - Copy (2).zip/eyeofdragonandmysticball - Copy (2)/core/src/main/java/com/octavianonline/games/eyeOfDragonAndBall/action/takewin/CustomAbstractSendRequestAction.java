package com.octavianonline.games.eyeOfDragonAndBall.action.takewin;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.action.AsyncAction;
import com.atsisa.gox.framework.exception.*;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.event.LogicRequestCompleteEvent;
import com.atsisa.gox.reels.event.LogicRequestSentEvent;
import com.atsisa.gox.reels.exception.NoHistoryException;
import com.atsisa.gox.reels.logic.GameLogicException;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.gwtent.reflection.client.annotations.Reflect_Mini;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;


@Reflect_Mini
public abstract class CustomAbstractSendRequestAction<T extends ActionData> extends AsyncAction<T> {

    /**
     * Not enough funds error code.
     */
    private static final int NOT_ENOUGH_FUNDS_ERROR_CODE = 2;

    /**
     * No history error code.
     */
    private static final int NO_HISTORY_ERROR_CODE = 29;

    /**
     * Reel game reference.
     */
    private final AbstractReelGame game;

    /**
     * An instance of the game server model.
     */
    private IReelGameLogic reelGameLogic;

    /**
     * Collection of the logic results.
     */
    private List<Object> logicResults = new ArrayList<>();

    /**
     * Initializes a new instance of {@link com.atsisa.gox.reels.action.AbstractSendRequestAction} class.
     */
    CustomAbstractSendRequestAction() {
        game = (AbstractReelGame) GameEngine.current().getGame();
    }

    /**
     * Initializes a new instance of {@link com.atsisa.gox.reels.action.AbstractSendRequestAction} class.
     * @param game {@link AbstractReelGame}
     */
    CustomAbstractSendRequestAction(AbstractReelGame game) {
        this.game = game;
    }

    /**
     * Gets reel game reference.
     * @return reel game reference
     */
    protected AbstractReelGame getGame() {
        return game;
    }

    /**
     * Gets game server client.
     * @return game server client
     */
    protected IReelGameLogic getGameLogic() {
        return reelGameLogic;
    }

    @Override
    protected void validate() throws ValidationException {
        if (reelGameLogic == null) {
            throw new ValidationException("The game server client cannot be null.");
        }
    }

    @Override
    protected void grabData() {
        reelGameLogic = game.getReelGameLogic();
    }

    @Override
    protected void reset() {
        logicResults.clear();
        reelGameLogic = null;
    }

    /**
     * Called when on action fail.
     * @param throwable {@link Throwable}
     */
    protected void handleLogicError(Throwable throwable) {
        logger.debug("SendInitRequestAction | responseFailure");
        cancelFurtherProcessing();
        if (throwable instanceof GameLogicException) {
            fail(translateGameServerException((GameLogicException) throwable));
        } else {
            fail(new UnableToConnectException(throwable));
        }
    }

    /**
     * Subscribes for result from the logic.
     * @param observable the observable result
     */
    protected void subscribeForResult(Observable<? extends Object> observable) {
        eventBus.post(new LogicRequestSentEvent());
        observable.subscribe(result -> {
            logicResults.add(result);
            onReceiveLogicResult(result);
            eventBus.post(result);
        }, this::handleLogicError, () -> {
            eventBus.post(new LogicRequestCompleteEvent(logicResults));
            this.onLogicComplete();
        });
    }

    /**
     * Called when the logic subscriber will notify complete.
     */
    protected void onLogicComplete() {
        finish();
    }

    /**
     * Called when result from the logic will come.
     * @param logicResult result from the logic
     */
    protected void onReceiveLogicResult(Object logicResult) {
    }

    /**
     * Translates game server exception.
     * @param cause {@link GameLogicException} with error code
     * @return {@link GameException}
     */
    private GameException translateGameServerException(GameLogicException cause) {
        int errorCode = cause.getErrorCode();
        if (errorCode == NOT_ENOUGH_FUNDS_ERROR_CODE) {
            return new NotEnoughFundsException(cause);
        } else if (errorCode == NO_HISTORY_ERROR_CODE) {
            return new NoHistoryException(cause);
        }
        return new GeneralSystemException(cause);
    }
}
