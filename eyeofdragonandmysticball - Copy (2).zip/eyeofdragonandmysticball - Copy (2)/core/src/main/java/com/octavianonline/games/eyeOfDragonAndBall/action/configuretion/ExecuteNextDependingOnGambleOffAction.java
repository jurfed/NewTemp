package com.octavianonline.games.eyeOfDragonAndBall.action.configuretion;

import com.atsisa.gox.framework.action.ExecuteNextAction;

public class ExecuteNextDependingOnGambleOffAction extends ExecuteNextAction {

    @Override
    protected void execute() {
        allowFurtherProcessing();

       // if (!QueenCleopatraSettingsScreen.getGambleOn()) {
       //     cancelFurtherProcessing();
       //     super.execute();
       // } else {
            finish();
       // }
    }
}
