package com.octavianonline.games.eyeOfDragonAndBall.customviews;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.Rectangle;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.gwtent.reflection.client.Reflectable;


/**
 * For adding KeyframeAnimationView on the wining symbols
 */
@XmlElement
@Reflectable
public class CustomKeyframeAnimationView extends KeyframeAnimationView implements IBound {
    @XmlElement
    private Rectangle boundaries;

/*    @XmlElement
    private String test;*/

    public void setBoundaries(Rectangle boundaries) {
        this.boundaries = boundaries;
    }

/*    public void setTest(String test) {
        this.test = test;
        if(test.equals("go")){
            setVisible(true);
            setAutoPlay(true);
            play();
        }
    }*/


    public CustomKeyframeAnimationView() {
        super();
    }

    @Override
    public Rectangle getBoundaries() {
        if (boundaries != null) {
            return boundaries;
        } else
            return new Rectangle(getX(), getY(), 310, 310);
    }



}
