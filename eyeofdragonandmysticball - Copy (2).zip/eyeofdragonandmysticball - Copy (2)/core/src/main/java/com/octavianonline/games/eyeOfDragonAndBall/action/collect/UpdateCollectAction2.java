package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.games.octavian.core.action.UpdateCollectActionData;
import com.atsisa.gox.games.octavian.core.event.UpdateCollectCommand;

public class UpdateCollectAction2 extends SyncAction<UpdateCollectActionData> {


    protected void execute() {
        this.eventBus.post(new UpdateCollectCommand(((UpdateCollectActionData)this.actionData).getTarget()));

    }

    public Class<? extends ActionData> getActionDataType() {
        return UpdateCollectActionData.class;
    }
}