package com.octavianonline.games.eyeOfDragonAndBall.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.FreeGamesMode;
import com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.StartSoundSpeenReelBaseGame;

/**
 * Class for continuous playback of fragments of background music in the auto play mode
 */
public class AutoplayButtomListener{
    private static boolean isSoundPlaying = false;
    private static int i = 0;
    private final String SOUND_ID = "ReelAutoMelody";
    private final int SOUNDS_COUNT = 16;
    private final int PAUSE = 2600;


    public void startPlaySound(){
        if (!isSoundPlaying) {
            playSound();
            isSoundPlaying = true;
        }
    }

    public void stopPlaySound(){
        isSoundPlaying = false;
    }


    private void playSound() {
        new Timeout(0, new TimerPlaySound(), false).start();
    }

    /**
     * Continuously plays fragments of music
     */
    class TimerPlaySound implements TimeoutCallback {

        @Override
        public void onTimeout() {
            SoundManager spinReelSound = (SoundManager) GameEngine.current().getSoundManager();
            if (isSoundPlaying) {
                i++;
                if (i == SOUNDS_COUNT + 1) {
                    i = 1;
                }
                new Timeout(PAUSE, new TimerPlaySound(), false).start();
                spinReelSound.play(SOUND_ID + i);
                StartSoundSpeenReelBaseGame.setSoundId(i);
                if(FreeGamesMode.isFreeGames){
                    spinReelSound.setVolume(SOUND_ID + i,0);
                }else{
                    spinReelSound.setVolume(SOUND_ID + i,1);
                }
            } else {
                spinReelSound.stop(SOUND_ID + i);
            }
        }
    }

    public static void setIsSoundPlaying(boolean stopSound) {
        isSoundPlaying = stopSound;
    }

}