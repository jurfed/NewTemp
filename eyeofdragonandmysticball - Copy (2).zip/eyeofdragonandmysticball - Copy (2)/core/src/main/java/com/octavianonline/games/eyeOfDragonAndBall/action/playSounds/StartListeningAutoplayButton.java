package com.octavianonline.games.eyeOfDragonAndBall.action.playSounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.octavianonline.games.eyeOfDragonAndBall.helpers.AutoplayButtomListener;

import java.util.ArrayList;
import java.util.List;

public class StartListeningAutoplayButton extends Action {
    boolean b = false;
    private final String LAYOUT_ID = "bottomPanelScreen";
    private final String START_BUTTOM_NAME = "autoPlayButton";
    private final String STOP_BUTTOM_NAME = "autoStopButton";
    private AutoplayButtomListener autoplayButtomListener;

    List<String> str2 = new ArrayList<String>();
    List<String> str = new ArrayList<String>();

    @Override
    protected void execute() {




        if (autoplayButtomListener == null) {

            autoplayButtomListener = new AutoplayButtomListener();

            ViewGroup activeGrp = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "autoPlayButtons");
            Iterable<View> children = activeGrp.getChildren();

            int viewNumber=0;
            for (View view : children){
                viewNumber++;
            }

        }

        class ButtonViewReleasedListener implements IEventListener<InputEvent> {
            private boolean released = false;

            @Override
            public void onEvent(InputEvent event) {


            }
        }

        finish();
    }
}
