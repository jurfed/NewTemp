package com.octavianonline.games.eyeOfDragonAndBall.action.movie;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.MovieView;
import com.octavianonline.games.eyeOfDragonAndBall.action.movie.actionData.VisibleAndPlayMovieActionData;

/**
 * Class to stop standby playing video
 */
public class SetUnvisibleAndStopMovie extends Action<VisibleAndPlayMovieActionData> {
    private MovieView video;

    @Override
    protected void execute() {
        int i=this.actionData.getVideoId().size();
        for(int j=1; j<=i; j++){
            SetVisibleAndPlayMovie.stopMovie=true;
            video = GameEngine.current().getViewManager().findViewById(this.actionData.getVideoLayoutId().get(j), this.actionData.getVideoId().get(j));
            video.setVisible(false);
            try{
                video.stop();
            }catch (Exception e){
                GameEngine.current().getLogger().debug("Error!!!: ",e);
            }

        }
    }
}
