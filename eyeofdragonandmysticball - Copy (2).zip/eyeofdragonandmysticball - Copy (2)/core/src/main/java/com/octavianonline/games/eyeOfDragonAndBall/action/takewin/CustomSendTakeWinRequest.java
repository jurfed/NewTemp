package com.octavianonline.games.eyeOfDragonAndBall.action.takewin;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;


@Reflect_Mini
public class CustomSendTakeWinRequest extends CustomAbstractSendRequestAction {

    private static volatile boolean canTake = true;

    /**
     * Initializes a new instance of the {@link CustomSendTakeWinRequest} class.
     */
    public CustomSendTakeWinRequest() {
        super();
    }

    /**
     * Initializes a new instance of the {@link CustomSendTakeWinRequest class.
     *
     * @param game reel game reference
     */
    public CustomSendTakeWinRequest(AbstractReelGame game) {
        super(game);
    }

    /**
     * Sends a take win request to the server.
     */
    @Override
    protected synchronized void execute() {

        canTake = false;

        long freeGamesWinAmount = EyeOfDragonAndBallBaseGameScreen.getFreeGamesModelProvider().getModel().getTotalWinAmount();
        long totalWinAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        if (freeGamesWinAmount != 0) {
            totalWinAmount = freeGamesWinAmount;
        }
        if (totalWinAmount > 0) {
            subscribeForResult(getGameLogic().takeWin());
        }

    }

    public static void setCanTake(boolean parameter) {
        canTake = parameter;

    }

    @Override
    protected void terminate() {
        System.out.println();
    }

}