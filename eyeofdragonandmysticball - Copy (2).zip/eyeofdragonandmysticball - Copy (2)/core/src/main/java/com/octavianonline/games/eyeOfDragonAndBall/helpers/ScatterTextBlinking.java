package com.octavianonline.games.eyeOfDragonAndBall.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.TextView;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.IdentifiersForFlashingText;

/**
 * Class for text animation next to the Scatter symbol.
 * The character on the upper screen is animated.
 * The text "10 free games.." is animated
 */
public class ScatterTextBlinking {
    TextView tv51;
    TextView tv52;
    TextView tv41;
    TextView tv42;
    TextView tv31;
    TextView tv32;

    TextView tv1;
    TextView tv2;

    TextView text10;
    TextView textPlus;
    TextView textFreeGames;
    TextView textSpecialSymbol;
    TextView textSymbol;

    String fonrFreeCount1 = "free_count1";
    String fonrFreeCount2 = "free_count2";

    String seepaysTextBig1 = "seepays_text_big1";
    String seepaysTextBig2 = "seepays_text_big2";

/*    int initColor1;
    int initColor2;*/


    String initFont1;
    String initFont2;

    //    int colorToChange;
    String fontToChange;

    int time;
    /**
     * Scatter symbol on the upper screen
     */
    private KeyframeAnimationView scatterAnimation;

    /**
     * Initialize TextViews, colors and scatter symbol
     */
    public ScatterTextBlinking(int time) {
        tv51 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "5TombMultiplier");
        tv52 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "5Tomb");

        tv41 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "4TombMultiplier");
        tv42 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "4Tomb");

        tv31 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "3TombMultiplier");
        tv32 = (TextView) GameEngine.current().getViewManager().findViewById(IdentifiersForFlashingText.PAY_TABLE_SCREEN, "3Tomb");

        initFont1 = tv51.getFontName();
        initFont2 = tv52.getFontName();
        fontToChange = IdentifiersForFlashingText.textFontBase;


        textFreeGames = GameEngine.current().getViewManager().findViewById("payTableScreen", "FreeGames");
        textSpecialSymbol = GameEngine.current().getViewManager().findViewById("payTableScreen", "LangSpecialSymbol");
        textSymbol = GameEngine.current().getViewManager().findViewById("payTableScreen", "Symbol");

//        scatterAnimation = GameEngine.current().getViewManager().findViewById("payTableBgrScreen", "tombSymbolWinShortAnimation");
        scatterAnimation = GameEngine.current().getViewManager().findViewById("payTableScreen", "tombSymbolWinShortAnimation");

        text10 = GameEngine.current().getViewManager().findViewById("payTableScreen", "10");
        textPlus = GameEngine.current().getViewManager().findViewById("payTableScreen", "symbol+");

        this.time = time;
    }


    /**
     * flag indicates whether the text is changed color.
     */
    static boolean textColorChanged = false;

    //Determine which line to change the color next to the Scatter symbol
    public void start() {
        switch (IdentifiersForFlashingText.tombCount) {
            case 5:
                tv1 = tv51;
                tv2 = tv52;
                break;
            case 4:
                tv1 = tv41;
                tv2 = tv42;
                break;
            case 3:
                tv1 = tv31;
                tv2 = tv32;
                break;
        }

        //animate the scatter symbol on the upper screen
        scatterAnimation.gotoAndPlay(1);
        new Timeout(time, new ScatterTextFlashing(), false).start();
    }

    /**
     * Cyclically change the color of the text.
     */
    class ScatterTextFlashing implements TimeoutCallback {
        @Override
        public void onTimeout() {
            if (textColorChanged) {
                tv1.setFontName(initFont1);
                tv2.setFontName(initFont2);

                textFreeGames.setFontName(seepaysTextBig1);
                textSpecialSymbol.setFontName(seepaysTextBig1);
                textSymbol.setFontName(seepaysTextBig1);
                text10.setFontName(fonrFreeCount1);
                textPlus.setFontName(fonrFreeCount1);
                textColorChanged = false;
            } else {
                tv1.setFontName(fontToChange);
                tv2.setFontName(fontToChange);

                textFreeGames.setFontName(seepaysTextBig2);
                textSpecialSymbol.setFontName(seepaysTextBig2);
                textSymbol.setFontName(seepaysTextBig2);
                text10.setFontName(fonrFreeCount2);
                textPlus.setFontName(fonrFreeCount2);
                textColorChanged = true;
            }
            if (IdentifiersForFlashingText.startScatterTextBlinking) {
                new Timeout(time, new ScatterTextFlashing(), false).start();
            } else {
                tv1.setFontName(initFont1);
                tv2.setFontName(initFont2);
                IdentifiersForFlashingText.tombCount = 0;
                for (int i = 1; i <= 5; i++) {
                    IdentifiersForFlashingText.tombState.put(i + IdentifiersForFlashingText.tombSymbolName, false);
                }
                textFreeGames.setFontName(seepaysTextBig1);
                textSpecialSymbol.setFontName(seepaysTextBig1);
                textSymbol.setFontName(seepaysTextBig1);
                text10.setFontName(fonrFreeCount1);
                textPlus.setFontName(fonrFreeCount1);
                scatterAnimation.gotoAndPause(1);
            }
        }
    }
}
