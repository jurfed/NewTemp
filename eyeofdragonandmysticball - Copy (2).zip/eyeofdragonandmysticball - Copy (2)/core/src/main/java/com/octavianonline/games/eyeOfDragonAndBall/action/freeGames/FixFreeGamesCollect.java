package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.action.Action;

public class FixFreeGamesCollect extends Action{
    @Override
    protected void execute() {
        GetWinAmountsForCollect.setTempWin(0L);
        finish();
    }
}
