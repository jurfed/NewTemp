package com.octavianonline.games.eyeOfDragonAndBall.gameobjects;

import java.util.ArrayList;
import java.util.HashMap;

public class TextObjectsPaytable {
    private static HashMap<String, String> symbolMultiplierName = new HashMap();
    private static HashMap<String, String> symbolSympleName = new HashMap();
    private ArrayList<String> SymbolsName = new ArrayList();

    public void fillTextIdentifiers(){

    }

}
