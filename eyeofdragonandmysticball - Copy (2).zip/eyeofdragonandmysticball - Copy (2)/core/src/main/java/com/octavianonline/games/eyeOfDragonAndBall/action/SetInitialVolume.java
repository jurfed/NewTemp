package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.octavianonline.games.eyeOfDragonAndBall.event.VolumeChangedEvent;

public class SetInitialVolume extends Action {

    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new VolumeChangedEvent(2));
        finish();
    }
}
