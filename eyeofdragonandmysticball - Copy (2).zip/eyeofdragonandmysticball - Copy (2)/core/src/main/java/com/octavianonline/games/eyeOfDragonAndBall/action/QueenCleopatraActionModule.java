package com.octavianonline.games.eyeOfDragonAndBall.action;


import com.atsisa.gox.framework.action.AbstractActionModule;
import com.octavianonline.games.eyeOfDragonAndBall.action.bigwin.ExecuteNextDependingOnBigWin;
import com.octavianonline.games.eyeOfDragonAndBall.action.bigwin.ExecuteNextDependingOnBigWinInFreeGames;
import com.octavianonline.games.eyeOfDragonAndBall.action.collect.*;
import com.octavianonline.games.eyeOfDragonAndBall.action.configuretion.ExecuteNextDependingOnGambleOffAction;
import com.octavianonline.games.eyeOfDragonAndBall.action.configuretion.SetConfigurationWinLineView;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.*;
import com.octavianonline.games.eyeOfDragonAndBall.action.helpers.CustomShowHideScreen;
import com.octavianonline.games.eyeOfDragonAndBall.action.movie.InitHandlingLogoMovies;
import com.octavianonline.games.eyeOfDragonAndBall.action.movie.StopSplashScreenVideo;
import com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.SpinFlashPlay;
import com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.StartSoundSpeenReelBaseGame;
import com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.StopSoundSpeenReelBaseGame;
import com.octavianonline.games.eyeOfDragonAndBall.action.reelsSpeen.FindStoppedSymbols;
import com.octavianonline.games.eyeOfDragonAndBall.action.reelsSpeen.SetReelsSpeen;
import com.octavianonline.games.eyeOfDragonAndBall.action.takewin.CustomSendTakeWinRequest;
import com.octavianonline.games.eyeOfDragonAndBall.action.takewin.Ftemp1;
import com.octavianonline.games.eyeOfDragonAndBall.action.takewin.Ftemp2;

/**
 * Action module for Book Of Ra Deluxe
 */
public class QueenCleopatraActionModule extends AbstractActionModule {

    /**
     * Book Of Ra Deluxe actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/game/queencleopatra/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    /**
     * Animation of the book and characters in the free game mode
     */
    @Override
    protected void register() {
        registerAction("StartSelectingExtendedSymbolAnimation", StartSelectingExtendedSymbolAnimationAction.class);
        registerAction("HideSelectedExtendedSymbol", HideSelectedExtendedSymbolAction.class);
        registerAction("ShowBgrFreeGames", ShowBgrFreeGames.class);//show background for Free Games
        registerAction("HideBgrFreeGames", HideBgrFreeGames.class);//hide background for Free Games
        registerAction("MoveUpBackground", MoveUpBackground.class);
        registerAction("SetYForTombTextWin", SetYForTombTextWin.class);//set the tomb symbol win text to center
        registerAction("ReturnOriginalSymbolDepth", ReturnOriginalSymbolDepth.class);//set the depth of symbols to the initial state: scatter=1, any other symbol=0
        registerAction("SetInitialVolume", SetInitialVolume.class);
        registerAction("EmptyAction", EmptyAction.class);
        registerAction("Temp3", Temp3.class);
        registerAction("Temp4", Temp4.class);
        registerAction("ExecuteNextDependingOnGambleOffAction", ExecuteNextDependingOnGambleOffAction.class);
        registerAction("SetConfigurationWinLineView", SetConfigurationWinLineView.class);
        registerAction("FreeGamesMode", FreeGamesMode.class);
        registerAction("ReturnBackgroundForBaseGameMode", ReturnBackgroundForBaseGameMode.class);
        registerAction("ShowFreeGamesWonPanel", ShowFreeGamesWonPanel.class);
        registerAction("SpinFlashPlay", SpinFlashPlay.class);
        registerAction("StopSoundSpeenReelBaseGame", StopSoundSpeenReelBaseGame.class);
        registerAction("SetReelsSpeen", SetReelsSpeen.class);
        registerAction("ShowSelectedExtendedSymbol", ShowSelectedExtendedSymbolAction.class);
        registerAction("StartSoundSpeenReelBaseGame", StartSoundSpeenReelBaseGame.class);
        registerAction("HighlightSelectedExtendedSymbol", HighlightSelectedExtendedSymbolAction.class);//flashing the selected character frame
        registerAction("CustomShowHideScreen", CustomShowHideScreen.class);
        registerAction("Bookpause", Bookpause.class);
        registerAction("PlayCurrentWinningLineFreeSound", PlayCurrentWinningLineFreeSound.class);
        registerAction("InitCollect", InitCollectAction.class);
        registerAction("TransferWinCustom", TransferWinCustom.class);
        registerAction("FinishCollect", FinishCollect.class);
        registerAction("GetWinAmountsForCollect", GetWinAmountsForCollect.class);
        registerAction("ExecuteNextDependingOnLoseFreeGame", ExecuteNextDependingOnLoseFreeGame.class);
        registerAction("CustomSendTakeWinRequest", CustomSendTakeWinRequest.class);
        registerAction("InitAllFreeGamesAmount", InitAllFreeGamesAmount.class);
        registerAction("UpdateCollectAction2", UpdateCollectAction2.class);
        registerAction("PauseCustom", PauseCustom.class);
        registerAction("WinCountStopCustom", WinCountStopCustom.class);
        registerAction("FixFreeGamesCollect", FixFreeGamesCollect.class);
        registerAction("FindStoppedSymbols", FindStoppedSymbols.class);
        registerAction("SkipCollectAction", SkipCollectAction.class);
        registerAction("ReturnLines", ReturnLines.class);
        registerAction("HideFreeGamesWonPanel", HideFreeGamesWonPanel.class);
        registerAction("CheckShortCollect", CheckShortCollect.class);
        registerAction("CheckShortCollectFreeGames", CheckShortCollectFreeGames.class);
        registerAction("ExecuteNextDependingOnEndFreeGames", ExecuteNextDependingOnEndFreeGames.class);
        registerAction("Ftemp2", Ftemp2.class);
        registerAction("Ftemp1", Ftemp1.class);
//  Movies
        registerAction("InitHandlingLogoMovies", InitHandlingLogoMovies.class);
        registerAction("StopSplashScreenVideo", StopSplashScreenVideo.class);
        registerAction("ExecuteNextDependingOnBigWin", ExecuteNextDependingOnBigWin.class);
        registerAction("ExecuteNextDependingOnBigWinInFreeGames", ExecuteNextDependingOnBigWinInFreeGames.class);
        registerAction("InitCollectFreeGames", InitCollectFreeGames.class);
//        registerAction("ResetStoppedReels", ResetStoppedReels.class);
    }

}