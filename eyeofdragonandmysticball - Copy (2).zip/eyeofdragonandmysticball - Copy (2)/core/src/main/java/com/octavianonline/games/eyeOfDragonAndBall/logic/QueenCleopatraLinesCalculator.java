package com.octavianonline.games.eyeOfDragonAndBall.logic;

import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.calculator.HitCheckResult;
import com.atsisa.gox.logic.calculator.IHitChecker;
import com.atsisa.gox.logic.calculator.ILinesCalculator;
import com.atsisa.gox.logic.model.*;
import com.atsisa.gox.logic.model.utils.ReelGameType;
import com.atsisa.gox.logic.provider.ILinesModelProvider;

import javax.inject.Inject;
import java.util.*;

/**
 * The lines calculator for reels game.
 */
public class QueenCleopatraLinesCalculator implements ILinesCalculator {

    /**
     * The symbol marked as already used.
     */
    private static final byte MARK_SYMBOL = Byte.MIN_VALUE;

    /**
     * The possible combination styles.
     */
    private static final List<String> COMBINATION_STYLES = new ArrayList<>();

    static {
        COMBINATION_STYLES.add(WinLineCombinationStyle.LEFT_TO_RIGHT);
        COMBINATION_STYLES.add(WinLineCombinationStyle.RIGHT_TO_LEFT);
    }

    /**
     * The {@link ILinesModelProvider}
     */
    private final ILinesModelProvider linesProvider;

    /**
     * The hit checkers.
     */
    private final Set<IHitChecker> hitCheckers;

    /**
     * Initializes a new instance of the {@link com.atsisa.gox.logic.calculator.LinesCalculator} class.
     *
     * @param linesProvider The lines provider
     * @param hitCheckers   The set of {@link IHitChecker}
     */
    @Inject
    public QueenCleopatraLinesCalculator(ILinesModelProvider linesProvider, Set<IHitChecker> hitCheckers) {
        this.linesProvider = linesProvider;
        this.hitCheckers = hitCheckers;
    }

    /**
     * Calculates the win for given lines numer
     *
     * @param activeLines        number of lines
     * @param stopSymbols        stop symbols list
     * @param lineWinDescriptors the list of {@link LineWinDescriptor}
     * @return the list of {@link LineWinResult}
     * @throws GameLogicException when calculation could not be properly processed
     */
    @Override
    public List<LineWinResult> calculate(int activeLines, List<Reel> stopSymbols, List<LineWinDescriptor> lineWinDescriptors) throws GameLogicException {
        ArrayList<LineWinResult> winResults = new ArrayList<>();

        if (!linesProvider.getLineDescriptors().isPresent()) {
            throw new GameLogicException("The lines model is null");
        }

        List<LineDescriptor> linesDescriptors = linesProvider.getLineDescriptors().get();

        for (int line = 0; line < activeLines; line++) {

            LineDescriptor lineDescriptor = linesDescriptors.get(line);
            List<Reel> stopSymbolsCopy = deepCopy(stopSymbols);

            for (LineWinDescriptor lineWinDescriptor : lineWinDescriptors) {
                evaluateWinDescriptor(lineWinDescriptor, stopSymbolsCopy, lineDescriptor, line, winResults);
            }
        }

        return winResults;
    }

    /**
     * Creates deep copy of {@link Reel} list
     *
     * @param listToCopy The list to copy
     * @return The deep copy of the listToCopy
     */
    private List<Reel> deepCopy(List<Reel> listToCopy) {
        List<Reel> deepCopy = new ArrayList<>(listToCopy.size());
        for (int i = 0; i < listToCopy.size(); i++) {
            List<Symbol> symbols = new ArrayList<>();
            for (Symbol symbol : listToCopy.get(i).getSymbols()) {
                symbols.add(new Symbol(symbol.getName(), symbol.getId(), symbol.getType()));
            }
            deepCopy.add(new Reel(i, symbols));
        }

        return deepCopy;
    }

    /**
     * Evaluates the win descriptor.
     *
     * @param lineWinDescriptor The win line descriptor.
     * @param stopSymbols       The stop symbols.
     * @param lineDescriptor    The line descriptor.
     * @param lineIndex         The line index.
     * @param winResults        The win results.
     */
    private void evaluateWinDescriptor(LineWinDescriptor lineWinDescriptor, List<Reel> stopSymbols, LineDescriptor lineDescriptor, int lineIndex,
                                       List<LineWinResult> winResults) {

        List<String> winLineCombinationStyles = lineWinDescriptor.getWinLineCombinationStyles();
        int reelsCount = stopSymbols.size();

        Optional<String> combinationStyle = lineDescriptor.getDirection();

        if (combinationStyle.isPresent()) {
            int startReel = (combinationStyle.get().contains(WinLineCombinationStyle.LEFT_TO_RIGHT)) ?
                    0 : reelsCount - lineWinDescriptor.getWinDescriptor().getSymbolsAmount();
            // if combination style is set on line ignore win descriptor combination styles
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, startReel, lineDescriptor, lineIndex, winResults, false);
        } else if (winLineCombinationStyles.containsAll(COMBINATION_STYLES)) {
            // check for hit starting at leftmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, false);

            // check for hit starting at rightmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, reelsCount - lineWinDescriptor.getWinDescriptor().getSymbolsAmount(), lineDescriptor,
                    lineIndex, winResults, false);
        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.LEFT_TO_RIGHT)) {

            // check for hit starting at leftmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, false);
        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.RIGHT_TO_LEFT)) {

            // check for hit starting at rightmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, reelsCount - lineWinDescriptor.getWinDescriptor().getSymbolsAmount(), lineDescriptor,
                    lineIndex, winResults, false);

        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.SCATTERED)) {
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, true);
        }
    }

    /**
     * Evaluates the win descriptor.
     *
     * @param lineWinDescriptor The win line descriptor.
     * @param stopSymbols       The stop symbols.
     * @param startReel         The start reel.
     * @param lineDescriptor    The line descriptor.
     * @param lineIndex         The line index.
     * @param winResults        The win results.
     * @param isScattered       The {@link WinLineCombinationStyle} is scattered.
     */
    private void evaluateWinDescriptor(LineWinDescriptor lineWinDescriptor, List<Reel> stopSymbols, int startReel, LineDescriptor lineDescriptor, int lineIndex,
                                       List<LineWinResult> winResults, boolean isScattered) {
        int reelsCount = stopSymbols.size();

        // no win if not enough symbols left
        if (lineWinDescriptor.getWinDescriptor().getSymbolsAmount() > reelsCount - startReel) {
            return;
        }

        // list of win symbols
        List<SymbolPosition> winSymbolPositions = new ArrayList<>(lineWinDescriptor.getWinDescriptor().getSymbolsAmount());

        // list of win symbols that are non repeatable
        List<SymbolPosition> nonRepeatableSymbolPositions = new ArrayList<>(lineWinDescriptor.getWinDescriptor().getSymbolsAmount());

        int occurrencesCount = 0;

        int max = isScattered ? reelsCount : startReel + lineWinDescriptor.getWinDescriptor().getSymbolsAmount();
        boolean fixWild = true;
        int tomb = 0;
        for (int reel = startReel; reel < max; reel++) {
            int row = lineDescriptor.getPositions().get(reel).getRow();

            // if any symbol already used, there is no reason to check further symbols
            Symbol symbolToCheck = stopSymbols.get(reel).getSymbols().get(row);
            if (symbolToCheck.getId() == MARK_SYMBOL) {
                return;
            }

            boolean hit = false;

            Iterator<IHitChecker> checkerIterator = hitCheckers.iterator();
            while (checkerIterator.hasNext() && !hit) {
                HitCheckResult result = checkerIterator.next().check(lineWinDescriptor.getWinDescriptor().getSymbol(), symbolToCheck);
                if (result.isHit()) {
                    if (symbolToCheck.getName().equals("Tomb")) {
                        tomb++;
                    }
                    hit = true;
                    occurrencesCount++;
                    SymbolPosition winSymbolPosition = new SymbolPosition(reel, row);
                    winSymbolPositions.add(winSymbolPosition);
                    if (!result.isRepeatable()) {
                        nonRepeatableSymbolPositions.add(winSymbolPosition);
                    }
                }

            }

            // None of checkers found a match, so we break evaluation.
            if (!hit && !isScattered) {
                return;
            }
        }

        if (lineDescriptor.getNumber() != 0 && tomb == max) {
            return;
        }


        if (lineWinDescriptor.getWinDescriptor().getSymbolsAmount() > occurrencesCount) {
            return;
        }

        // If this symbol participates in this win combination, it is marked as used symbol and will prevent next combination from being evaluated.
        nonRepeatableSymbolPositions
                .forEach(symbolPosition -> stopSymbols.get(symbolPosition.getReel()).getSymbols().get(symbolPosition.getRow()).setId(MARK_SYMBOL));
        WinResult winResult = new WinResult(lineWinDescriptor.getWinDescriptor().getWinId(), lineWinDescriptor.getWinDescriptor().getScore(),
                winSymbolPositions);
        LineWinResult lineWinResult = new LineWinResult(winResult, lineIndex, ReelGameType.LINES);
        winResults.add(lineWinResult);
    }
}
