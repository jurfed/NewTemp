package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.gwtent.reflection.client.annotations.Reflect_Mini;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;

/**
 * if amount in this free game == 0
 */
@Reflect_Mini
public class ExecuteNextDependingOnEndFreeGames extends ExecuteNextAction {
    IFreeGamesModel freeGamesModel;

    @Override
    protected void execute() {
        freeGamesModel = EyeOfDragonAndBallBaseGameScreen.getFreeGamesModelProvider().getModel();
        allowFurtherProcessing();
        int totalFreeGames = freeGamesModel.getTotalFreeGamesNumber();
        int currentFreeGame = freeGamesModel.getCurrentFreeGameNumber();
        if (currentFreeGame == totalFreeGames) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }

}
