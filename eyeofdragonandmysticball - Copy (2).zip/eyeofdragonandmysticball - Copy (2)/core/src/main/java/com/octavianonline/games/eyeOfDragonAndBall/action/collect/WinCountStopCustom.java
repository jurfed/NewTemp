package com.octavianonline.games.eyeOfDragonAndBall.action.collect;


import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.WinCountStopEvent;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;

public class WinCountStopCustom extends Action {
    @Override
    protected void execute() {
        final long totalWinAmount = EyeOfDragonAndBallBaseGameScreen.getAllFreeGamesAmount();
        eventBus.post(new WinCountStopEvent(totalWinAmount));
        finish();
    }
}
