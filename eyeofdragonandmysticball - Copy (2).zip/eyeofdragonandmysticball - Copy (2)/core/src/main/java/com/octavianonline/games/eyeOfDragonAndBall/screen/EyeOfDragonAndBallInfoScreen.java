package com.octavianonline.games.eyeOfDragonAndBall.screen;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.event.PayTableModelChangedEvent;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;
import com.octavianonline.games.eyeOfDragonAndBall.screen.transitions.QueenCleopatraInfoScreenTransition;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Represents the info screen.
 */
/**
 * Represents the info screen.
 */
@Reflectable
public class EyeOfDragonAndBallInfoScreen extends InfoScreen {

    /**
     * Book animation view id.
     */
    private static final String BOOK_ANIMATION_VIEW = "bookAnimation";

    /**
     * Contains numbers of frames for different symbols.
     */
//    private final int[] bookAnimationFrameHooks = { 1, 21, 46, 69, 92, 117, 140, 164, 186, 210 };
    private final int[] bookAnimationFrameHooks = {1, 9, 17, 25, 33, 41, 49, 57, 65, 72};


    @InjectView
    public ViewGroup featureInfoScreen;

    private KeyframeAnimationView bookAnimation;

    /**
     * Initializes a new instance of the {@link EyeOfDragonAndBallInfoScreen} class.
     *
     * @param layoutId             layout identifier
     * @param model                {@link PayTableScreenModel}
     * @param renderer             {@link IRenderer}
     * @param viewManager          {@link IViewManager}
     * @param animationFactory     {@link IAnimationFactory}
     * @param logger               {@link ILogger}
     * @param eventBus             {@link IEventBus}
     * @param infoScreenTransition {@link InfoScreenTransition}
     */
    @Inject
    public EyeOfDragonAndBallInfoScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, PayTableScreenModel model, IRenderer renderer, IViewManager viewManager,
                                        IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, QueenCleopatraInfoScreenTransition infoScreenTransition) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new PayTableModelChangedEventObserver(), PayTableModelChangedEvent.class);
    }

    /**
     * Handles pay table values changed.
     *
     * @param event event with changed values
     */
    @Subscribe
    public void handlePayTableModelChangedEvent(PayTableModelChangedEvent event) {
        ((PayTableScreenModel) getModel()).updatePayTableValues(event.getValues());
    }

    private class PayTableModelChangedEventObserver extends NextObserver<PayTableModelChangedEvent> {

        @Override
        public void onNext(final PayTableModelChangedEvent payTableModelChangedEvent) {
            handlePayTableModelChangedEvent(payTableModelChangedEvent);
        }
    }

    @Override
    protected void notifyScreenShown(Object sourceEvent) {//animation of the book on the info page
        super.notifyScreenShown(sourceEvent);
        if (this.featureInfoScreen.isVisible()) {
            playBookAnimation();
        }
    }

    @Override
    protected void beforeShowView() {
        super.beforeShowView();
        if (this.featureInfoScreen.isVisible()) {
            pauseBookAnimation();
        }
    }

    @Override
    public void hide(TweenViewAnimationData viewAnimationData, final IFinishCallback callback) {
        viewAnimationData.setTimeSpan(0);
        GameEngine.current().getSoundManager().play("ShiftDef");
        super.hide(viewAnimationData, callback);
        if (this.featureInfoScreen != null && this.featureInfoScreen.isVisible()) {
            pauseBookAnimation();
        }
    }

    @Override
    public void show(String viewId, TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback) {
        viewAnimationData.setTimeSpan(0);
        super.show(viewAnimationData, finishCallback);
    }

    @Override
    public void afterActivated() {
        int indexFrameNumber = (int) Math.floor(Math.random() * 10);
        bookAnimation = getViewManager().findViewById(featureInfoScreen, BOOK_ANIMATION_VIEW);
        bookAnimation.gotoAndPause(bookAnimationFrameHooks[indexFrameNumber]);
        super.afterActivated();
    }

    /**
     * Pauses book animation.
     */
    private void pauseBookAnimation() {
        ((KeyframeAnimationView) getViewManager().findViewById(featureInfoScreen, BOOK_ANIMATION_VIEW)).pause();
    }

    /**
     * Plays book animation.
     */
    private void playBookAnimation() {
        ((KeyframeAnimationView) getViewManager().findViewById(featureInfoScreen, BOOK_ANIMATION_VIEW)).play();
    }

}