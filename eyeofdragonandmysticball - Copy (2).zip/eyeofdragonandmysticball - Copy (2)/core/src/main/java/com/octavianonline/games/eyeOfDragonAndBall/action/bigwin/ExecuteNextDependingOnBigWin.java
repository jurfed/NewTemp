package com.octavianonline.games.eyeOfDragonAndBall.action.bigwin;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class ExecuteNextDependingOnBigWin extends ExecuteNextAction {
    private static boolean bigwinOnOff = true;

    public static boolean getBigwinOnOff() {
        return bigwinOnOff;
    }

    public static void setBigwinOnOff(boolean value) {
        bigwinOnOff = value;
    }

    @Override
    protected void execute() {
        allowFurtherProcessing();
        AbstractReelGame game = (AbstractReelGame) GameEngine.current().getGame();
        Long totalWinAmount = game.getLinesModelProvider().getTotalWinAmount();
        if (totalWinAmount == null || totalWinAmount <= 0) {
            finish();
        } else {
            long totalBet = game.getBetModelProvider().getBetModel().getTotalBet();
            long winSum = totalWinAmount / totalBet;

            if (
                    (
                            (winSum >= 20d && winSum < 50d) ||
                                    (winSum >= 50 && winSum < 100) ||
                                    (winSum >= 100 && winSum < 200) ||
                                    (winSum >= 200))
                            && bigwinOnOff

                    ) {
                cancelFurtherProcessing();
                super.execute();
            } else {
                finish();
            }
        }

    }
}
