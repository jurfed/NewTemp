package com.octavianonline.games.eyeOfDragonAndBall.action.reelsSpeen;


import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.octavianonline.games.eyeOfDragonAndBall.event.FormStoppedSymbols;

public class FindStoppedSymbols extends Action {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new FormStoppedSymbols());
        finish();
    }
}
