package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.view.*;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassAnimationId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassFramesId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassSymbolsId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.GamblerIsStart;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Starts and stops the animation of characters and frames on the upper screen
 */
public class LiveGlassWinAnimationStartStop implements IViewPropertyChangedListener {
    private KeyframeAnimationView upperAnimSymbol;
    private volatile ConcurrentHashMap<Integer, KeyframeAnimationView> mapReelSymbolsAnimation = new ConcurrentHashMap<>();
    //    private volatile HashMap<Integer, KeyframeAnimationView> mapReelSymbolsAnimation = new HashMap<>();
    private HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation = new HashMap<>();
    private HashMap<String, ImageView> symbolsImageView;
    private KeyframeAnimationView reelSymbol;
    private Integer[] locki = new Integer[18];

    /**
     * @param mapReelSymbolsAnimation
     * @param mapUpperScreenSymbolsAnimation
     * @param symbolsImageView
     */
    public LiveGlassWinAnimationStartStop(ConcurrentHashMap<Integer, KeyframeAnimationView> mapReelSymbolsAnimation, HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation, HashMap<String, ImageView> symbolsImageView) {
        this.mapReelSymbolsAnimation = mapReelSymbolsAnimation;
        this.mapUpperScreenSymbolsAnimation = mapUpperScreenSymbolsAnimation;
        this.symbolsImageView = symbolsImageView;
        for (int t = 0; t < locki.length; t++) {
            locki[t] = -1;
        }

    }

    /**
     * @param view
     * @param viewType
     * @param property Processing animation of each character on reels
     */
    @Override
    public void propertyChanged(View view, ViewType viewType, int property) {
        for (Integer key : mapReelSymbolsAnimation.keySet()) {
            reelSymbol = mapReelSymbolsAnimation.get(key);
            if (reelSymbol != null && reelSymbol.isPlaying()) {
                switch (key) {
//Ace long animation
                    case 0:
                    case 29:
                    case 58:
                    case 87:
                    case 116:

                        if (locki[0] == -1) {
                            locki[0] = key;
                        }
                        if (key == locki[0])//If the symbol is already received from one of the rels, we do not process it from the other reels
                            startStopAnimation(LiveGlassSymbolsId.get(4) + "", LiveGlassAnimationId.get(5) + "", LiveGlassFramesId.get(2) + "", 0);
                        break;
//Ace short animation
                    case 10:
//                    case 20:
                    case 39:
//                    case 49:
                    case 68:
//                    case 78:
                    case 97:
//                    case 107:
                    case 126:
//                    case 136:
                        if (locki[1] == -1) {
                            locki[1] = key;
                        }
                        if (key == locki[1])
                            startStopAnimation(LiveGlassSymbolsId.get(4) + "", LiveGlassAnimationId.get(17) + "", LiveGlassFramesId.get(2) + "", 1);
                        break;
//King long animation
                    case 1:
                    case 30:
                    case 59:
                    case 88:
                    case 117:

                        if (locki[2] == -1) {
                            locki[2] = key;
                        }
                        if (key == locki[2])
                            startStopAnimation(LiveGlassSymbolsId.get(6) + "", LiveGlassAnimationId.get(11) + "", LiveGlassFramesId.get(2) + "", 2);
                        break;
//King short animation
                    case 11:
//                    case 21:
                    case 40:
//                    case 50:
                    case 69:
//                    case 79:
                    case 98:
//                    case 108:
                    case 127:
//                    case 137:
                        if (locki[3] == -1) {
                            locki[3] = key;
                        }
                        if (key == locki[3])
                            startStopAnimation(LiveGlassSymbolsId.get(6) + "", LiveGlassAnimationId.get(18) + "", LiveGlassFramesId.get(2) + "", 3);
                        break;
//Person long animation
                    case 7:
                    case 36:
                    case 65:
                    case 94:
                    case 123:

                        if (locki[4] == -1) {
                            locki[4] = key;
                        }
                        if (key == locki[4])
                            startStopAnimation(LiveGlassSymbolsId.get(0) + "", LiveGlassAnimationId.get(0) + "", LiveGlassFramesId.get(0) + "", 4);
                        break;

//Person short animation
                    case 17:
//                    case 26:
                    case 46:
//                    case 55:
                    case 75:
//                    case 84:
                    case 104:
//                    case 113:
                    case 133:
//                    case 142:
                        if (locki[5] == -1) {
                            locki[5] = key;
                        }
                        if (key == locki[5])
                            startStopAnimation(LiveGlassSymbolsId.get(0) + "", LiveGlassAnimationId.get(16) + "", LiveGlassFramesId.get(0) + "", 5);
                        break;
//Queen long animation
                    case 2:
                    case 31:
                    case 60:
                    case 89:
                    case 118:

                        if (locki[6] == -1) {
                            locki[6] = key;
                        }
                        if (key == locki[6])
                            startStopAnimation(LiveGlassSymbolsId.get(2) + "", LiveGlassAnimationId.get(2) + "", LiveGlassFramesId.get(1) + "", 6);
                        break;
//Queen short animation
                    case 12:
//                    case 22:
                    case 41:
//                    case 51:
                    case 70:
//                    case 80:
                    case 99:
//                    case 109:
                    case 128:
//                    case 138:

                        if (locki[7] == -1) {
                            locki[7] = key;
                        }
                        if (key == locki[7])
                            startStopAnimation(LiveGlassSymbolsId.get(2) + "", LiveGlassAnimationId.get(19) + "", LiveGlassFramesId.get(1) + "", 7);
                        break;
//Jack long animation
                    case 3:
                    case 32:
                    case 61:
                    case 90:
                    case 119:
                        if (locki[8] == -1) {
                            locki[8] = key;
                        }
                        if (key == locki[8])
                            startStopAnimation(LiveGlassSymbolsId.get(5) + "", LiveGlassAnimationId.get(10) + "", LiveGlassFramesId.get(1) + "", 8);
                        break;
//Jack short animation
                    case 13:
//                    case 23:
                    case 42:
//                    case 52:
                    case 71:
//                    case 81:
                    case 100:
//                    case 110:
                    case 129:
//                    case 139:

                        if (locki[9] == -1) {
                            locki[9] = key;
                        }
                        if (key == locki[9])
                            startStopAnimation(LiveGlassSymbolsId.get(5) + "", LiveGlassAnimationId.get(20) + "", LiveGlassFramesId.get(1) + "", 9);
                        break;
//Ten long animation
                    case 4:
                    case 33:
                    case 62:
                    case 91:
                    case 120:

                        if (locki[10] == -1) {
                            locki[10] = key;
                        }
                        if (key == locki[10])
                            startStopAnimation(LiveGlassSymbolsId.get(1) + "", LiveGlassAnimationId.get(3) + "", LiveGlassFramesId.get(1) + "", 10);
                        break;

//Ten short animation
                    case 14:
//                    case 24:
                    case 43:
//                    case 53:
                    case 72:
//                    case 82:
                    case 101:
//                    case 111:
                    case 130:
//                    case 140:
                        if (locki[11] == -1) {
                            locki[11] = key;
                        }
                        if (key == locki[11])
                            startStopAnimation(LiveGlassSymbolsId.get(1) + "", LiveGlassAnimationId.get(1) + "", LiveGlassFramesId.get(1) + "", 11);
                        break;
//  statueSymbol long
                    case 6:
                    case 35:
                    case 64:
                    case 93:
                    case 122:
                        if (locki[12] == -1) {
                            locki[12] = key;
                        }
                        if (key == locki[12])
                            startStopAnimation(LiveGlassSymbolsId.get(3) + "", LiveGlassAnimationId.get(4) + "", LiveGlassFramesId.get(3) + "", 12);
                        break;
//  statueSymbol short animation
                    case 16:
//                    case 25:
                    case 45:
//                    case 54:
                    case 74:
//                    case 83:
                    case 103:
//                    case 112:
                    case 132:
//                    case 141:

                        if (locki[13] == -1) {
                            locki[13] = key;
                        }
                        if (key == locki[13])
                            startStopAnimation(LiveGlassSymbolsId.get(3) + "", LiveGlassAnimationId.get(23) + "", LiveGlassFramesId.get(3) + "", 13);
                        break;
//scarab (snake) long animation
                    case 8:
                    case 37:
                    case 66:
                    case 95:
                    case 124:

                        if (locki[14] == -1) {
                            locki[14] = key;
                        }
                        if (key == locki[14])
                            startStopAnimation(LiveGlassSymbolsId.get(7) + "", LiveGlassAnimationId.get(12) + "", LiveGlassFramesId.get(4) + "", 14);
                        break;
//scarab (snake) short animation
                    case 18:
//                    case 27:
                    case 47:
//                    case 56:
                    case 76:
//                    case 85:
                    case 105:
//                    case 114:
                    case 134:
//                    case 143:

                        if (locki[15] == -1) {
                            locki[15] = key;
                        }
                        if (key == locki[15])
                            startStopAnimation(LiveGlassSymbolsId.get(7) + "", LiveGlassAnimationId.get(21) + "", LiveGlassFramesId.get(4) + "", 15);
                        break;
//Mummy(griffin) long animation
                    case 9:
                    case 38:
                    case 67:
                    case 96:
                    case 125:
                        if (locki[16] == -1) {
                            locki[16] = key;
                        }
                        if (key == locki[16])
                            startStopAnimation(LiveGlassSymbolsId.get(8) + "", LiveGlassAnimationId.get(15) + "", LiveGlassFramesId.get(5) + "", 16);
                        break;

//Mummy(griffin) short animation
                    case 19:
//                    case 28:
                    case 48:
//                    case 57:
                    case 77:
//                    case 86:
                    case 106:
//                    case 115:
                    case 135:
//                    case 144:
                        if (locki[17] == -1) {
                            locki[17] = key;
                        }
                        if (key == locki[17])
                            startStopAnimation(LiveGlassSymbolsId.get(8) + "", LiveGlassAnimationId.get(22) + "", LiveGlassFramesId.get(5) + "", 17);
                        break;

                }
            }
        }
    }

    /**
     * @param symbol
     * @param symbolAnimation
     * @param winFrameAnimation
     * @param integer           Animate the symbol on the upper screen if the corresponding symbol is played on one of the reels
     */
    public void startStopAnimation(String symbol, String symbolAnimation, String winFrameAnimation, Integer integer) {
        upperAnimSymbol = mapUpperScreenSymbolsAnimation.get(symbolAnimation);
        if (reelSymbol.isPlaying() && reelSymbol.isVisible() && !GamblerIsStart.gamblerIsStart) {
            symbolsImageView.get(symbol).setVisible(false);
            mapUpperScreenSymbolsAnimation.get(winFrameAnimation).setVisible(true);
            upperAnimSymbol.setVisible(true);
            upperAnimSymbol.setAutoPlay(false);
            if (!upperAnimSymbol.isPlaying()) {
                upperAnimSymbol.gotoAndPlay(reelSymbol.getCurrentFrameNumber());
            }
            if (!mapUpperScreenSymbolsAnimation.get(winFrameAnimation).isPlaying()) {
                mapUpperScreenSymbolsAnimation.get(winFrameAnimation).gotoAndPlay(1);
            }
        } else {
            mapUpperScreenSymbolsAnimation.get(winFrameAnimation).setVisible(false);
            upperAnimSymbol.setVisible(false);
            upperAnimSymbol.gotoAndPause(1);
            mapUpperScreenSymbolsAnimation.get(winFrameAnimation).gotoAndPause(1);
            symbolsImageView.get(symbol).setVisible(true);
            locki[integer] = -1;
        }
    }
}
