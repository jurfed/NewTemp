package com.octavianonline.games.eyeOfDragonAndBall.action.movie;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.ButtonView;
import com.octavianonline.games.eyeOfDragonAndBall.action.movie.actionData.VisibleAndPlayMovieActionData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Class for the initialization of standby video playback
 */
public class InitHandlingLogoMovies extends Action {

    /**
     * The time interval between playing a video
     */
    static final int videoTimer = 15000;
    static final int initVideoTimer = 30000;
    private static Timeout timeout;

    /**
     * Drum trigger button
     */
    private ButtonView startButton;


    /**
     * Whether objects are initialized
     */
    private static boolean needInitialization = true;

    /**
     * Map with video number in the queue with the layoutID
     */
    static final HashMap<Integer, String> layoutIdHashMap = new HashMap<Integer, String>() {
        {
            put(1, "payTableScreen");
            put(2, "payTableScreen");
            put(3, "payTableScreen");
            put(4, "payTableScreen");
            put(5, "payTableScreen");
            put(6, "payTableScreen");
            put(7, "payTableScreen");
        }
    };

    /**
     * Map with video number in the queue with the video ID
     */
    static final HashMap<Integer, String> videoIdHashMap = new HashMap<Integer, String>() {
        {
//            put(1, "16x10_logo_1");
//            put(2, "16x10_text_bgr_3");
//            put(3, "16x10_movie_2");
//            put(4, "16x10_text_bgr_3");
//            put(5, "16x10_text_bgr_3");
//            put(6, "16x10_logo_4");
//            put(7, "16x10_logo_1");
        }
    };

    /**
     * To track the drum rotation button
     */
    private final String BUTTON_NAME = "spinButton";


    /**
     * Call the initialization buttons, buttons - listeners and timer for playing video
     */
    @Override
    protected void execute() {

        if (needInitialization) {
            needInitialization = false;
            new Timeout(initVideoTimer, new TimeOutLogoMoviePlay(layoutIdHashMap, videoIdHashMap), true).start();
        }

        finish();
    }


    /**
     * Method for start the video timer or to clear the video
     *
     * @param timerStart - true - start timer for video; false - stop video
     */
    public static void enableTimer(boolean timerStart) {
        if (timeout != null){
            timeout.clear();
        }

            if (timerStart) {//If the button is active, then start the timer
                SetVisibleAndPlayMovie.stopMovie = false;
                SetVisibleAndPlayMovie.canPlay = true;
                timeout = new Timeout(initVideoTimer, new TimeOutLogoMoviePlay(layoutIdHashMap, videoIdHashMap), true);
            } else if (SetVisibleAndPlayMovie.canPlay == true) {//Otherwise, we prohibit the playback of the video and stop the current playback
                SetVisibleAndPlayMovie.canPlay = false;
                IActionManager manager = GameEngine.current().getActionManager();
                List<Action> actionList = new ArrayList<Action>();
                VisibleAndPlayMovieActionData visibleAndPlayMovieActionData = new VisibleAndPlayMovieActionData();

                visibleAndPlayMovieActionData.setVideoLayoutId(layoutIdHashMap);
                visibleAndPlayMovieActionData.setVideoId(videoIdHashMap);

                SetUnvisibleAndStopMovie setUnvisibleAndStopMovie = new SetUnvisibleAndStopMovie();
                setUnvisibleAndStopMovie.setActionData(visibleAndPlayMovieActionData);
                setUnvisibleAndStopMovie.executeStandalone();// execute();
            }
    }


}
