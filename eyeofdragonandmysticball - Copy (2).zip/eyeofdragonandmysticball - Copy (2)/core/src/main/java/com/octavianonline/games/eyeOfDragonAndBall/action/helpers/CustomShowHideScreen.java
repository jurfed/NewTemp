package com.octavianonline.games.eyeOfDragonAndBall.action.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.command.ShowScreenCommand;
import com.octavianonline.games.eyeOfDragonAndBall.action.helpers.data.CustomShowHideScreenData;

public class CustomShowHideScreen extends Action<CustomShowHideScreenData> {

    Boolean finish=false;

    @Override
    protected void execute() {

        //ShowBigWin.getBottomPanelHelper().setSkipEnable(false);
        finish=false;
        TweenViewAnimationData tweenViewAnimationData = new TweenViewAnimationData();
        tweenViewAnimationData.setTimeSpan(this.actionData.getAnimationTime());
        if (this.actionData.getShowScreen()) {
            tweenViewAnimationData.setDestinationAlpha(1f);
            GameEngine.current().getEventBus().post(new ShowScreenCommand(this.actionData.getScreenId(), tweenViewAnimationData));
        } else {
            tweenViewAnimationData.setDestinationAlpha(0f);
            GameEngine.current().getEventBus().post(new HideScreenCommand(this.actionData.getScreenId(), tweenViewAnimationData));
        }

/*        new Timeout((int)this.actionData.getAnimationTime()+20, ()->{
            if(!finish){
                finish=true;
                finish();
            }
        }, true).start();*/

        finish();
    }

    @Override
    protected void terminate() {
        finish=true;
    }


    @Override
    public Class<CustomShowHideScreenData> getActionDataType() {
        return CustomShowHideScreenData.class;
    }
}
