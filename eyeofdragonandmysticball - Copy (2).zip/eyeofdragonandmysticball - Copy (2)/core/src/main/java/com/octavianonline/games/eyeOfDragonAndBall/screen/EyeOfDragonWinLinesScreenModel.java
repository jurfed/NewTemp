package com.octavianonline.games.eyeOfDragonAndBall.screen;

import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;

import javax.inject.Inject;

public class EyeOfDragonWinLinesScreenModel extends ScreenModel {

    @Inject
    public EyeOfDragonWinLinesScreenModel(ITranslator translator) {
        super(translator);
    }
}
