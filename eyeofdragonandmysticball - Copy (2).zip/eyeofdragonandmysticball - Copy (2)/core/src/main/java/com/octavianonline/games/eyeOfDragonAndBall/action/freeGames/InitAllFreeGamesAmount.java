package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.AbstractReelGame;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;

public class InitAllFreeGamesAmount extends Action {
    @Override
    protected void execute() {
        EyeOfDragonAndBallBaseGameScreen.setAllFreeGamesAmount(((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount());
        finish();
    }
}
