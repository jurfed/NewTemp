package com.octavianonline.games.eyeOfDragonAndBall.action.reelsSpeen;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class SetReelsSpeenActionData extends ActionData {
    @XmlAttribute
    private boolean turboMode=false;

    public boolean getTurboMode() {
        return turboMode;
    }

    public void setTurboMode(boolean turboMode) {
        this.turboMode = turboMode;
    }
}
