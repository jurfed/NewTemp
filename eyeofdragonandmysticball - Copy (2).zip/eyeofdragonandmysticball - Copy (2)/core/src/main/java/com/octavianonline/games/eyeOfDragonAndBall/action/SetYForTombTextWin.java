package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class SetYForTombTextWin extends Action {
    private final int NUMBERS_OF_REELS = 5;

    private final String LAYOUT_BASE_GAME_SCREEN_ID = "baseGameScreen";
    private final String REEL_GROUP_VIEW = "reelGroupView";
    private static boolean isFinish = false;

    /**
     * For getting Reel Group
     */
    private ReelGroupView reelGroupView;

    /**
     * For getting symbol on the reel
     */
    private AbstractSymbol abstractSymbol;

    private final String TOMB_SYMBOL = "Tomb";

    private final String SCATTER_NORMAL_SIZE = "scatter_fix_normal";

    @Override
    protected void execute() {
        isFinish=false;
        setY();


    }

    void setY() {
        //Set the full-sized Scatter - symbol on the first line
        reelGroupView = GameEngine.current().getViewManager().findViewById(LAYOUT_BASE_GAME_SCREEN_ID, REEL_GROUP_VIEW);
        //Getting a list of reel cell object
        for (int i = 0; i < NUMBERS_OF_REELS; i++) {

            abstractSymbol = reelGroupView.getReel(i).getDisplayedSymbol(0);
            if (abstractSymbol.getName().equals(TOMB_SYMBOL)) {
                for (View symbolView : abstractSymbol.getChildren()) {

                    if (symbolView instanceof ImageView) {
                        ((ImageView) symbolView).setImage(GameEngine.current().getResourceManager().getResource(SCATTER_NORMAL_SIZE));
                    }
                }
            }
        }


//set Y
        GameEngine.current().getViewManager().findViewById("payTableScreen", "5TombMultiplier").setY(-34);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "5Tomb").setY(-38);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "4TombMultiplier").setY(12);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "4Tomb").setY(8);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "3TombMultiplier").setY(58);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "3Tomb").setY(54);
//set X
        GameEngine.current().getViewManager().findViewById("payTableScreen", "5TombMultiplier").setX(-20);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "5Tomb").setX(0);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "4TombMultiplier").setX(-20);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "4Tomb").setX(0);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "3TombMultiplier").setX(-20);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "3Tomb").setX(0);
        if(!isFinish){
            isFinish=true;
            finish();
        }
    }

    @Override
    protected void terminate() {
        if(!isFinish) {
            isFinish = true;
            setY();
        }
    }

}
