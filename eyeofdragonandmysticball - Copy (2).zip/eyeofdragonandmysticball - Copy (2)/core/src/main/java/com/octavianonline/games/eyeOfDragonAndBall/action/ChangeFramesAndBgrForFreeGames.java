package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.view.CombinationWinLineView;
import com.atsisa.gox.reels.view.WinLineView;
import com.octavianonline.games.eyeOfDragonAndBall.customviews.CustomKeyframeAnimationView;

import java.util.ArrayList;

/**
 * Class for changing animation frames during the FreeGames mode
 */
public class ChangeFramesAndBgrForFreeGames {

    private IViewManager viewManager;

    /**
     * View which contains animated frames for lines from 1 to 10
     */
    private WinLineView winLineView;

    /**
     * View which contains animated frames for line 0
     */
    private CombinationWinLineView winLine0View;

    /**
     * for finding CustomKeyframeAnimationView in the WinLineView
     */
    private Iterable<View> linesObjects;

    /**
     * CustomKeyframeAnimationView for freeGames mode
     */
    private CustomKeyframeAnimationView freeGamesFrames;

    /**
     * CustomKeyframeAnimationView for BageGames mode
     */
    private CustomKeyframeAnimationView baseGamesFrames;

    /**
     * Number of winning lines
     */
    private final int LINES_COUNT = 10;

    /**
     * Number of frames in each line
     */
    private final int COLUMNS_COUNT = 5;


    /**
     * Layout that contains animation for both types of games
     */
    private final String LAYOUT_BGS_ID = "bgrScreen";

    /**
     * Layout with WinLineView objects
     */
    private final String LAYOUT_WIN_LINES_ID = "winLinesScreen";


    /**
     * The id of each line begins with "line"
     */
    private final String WIN_LINE_VIEW_ID = "line";

    /**
     * The id of line0
     */
    private final String WIN_LINE0_VIEW_ID = "line0";

    /**
     * Id CustomKeyframeAnimationView for FREE_GAMES mode
     */
    private final String FREE_GAMES_FRAME_ID = "1";

    /**
     * Id CustomKeyframeAnimationView for BASE_GAME mode
     */
    private final String BASE_GAME_FRAME_ID = "2";

    /**
     * Array of animation frames over winning symbols
     */
    private CustomKeyframeAnimationView[][] customKeyframeAnimationView;

    ArrayList<CustomKeyframeAnimationView> line0List;
    /**
     * Layout with background images for rels
     */
    private final String LAYOUT_ID_FOR_BACKGROUND = "reel_bg";

    /**
     * Array of background images for reels
     */
    private ImageView[] backgroundReels = new ImageView[10];

    /**
     * The index in the (reel_br.xml) from which the background images for the main game begin
     */
    private final static int BaseBgrIndex = 5;

    private KeyframeAnimationView scatterAnimation;

    /**
     * IDs of screens in order to make them on the foreground after the end of free games
     */
    private final String LAYOUT_ID_FOR_BGR_FREE_GAMES = "payTableBgrScreen";
    private final String ID_FOR_BGR_IMAGE = "bgr_fg";
    private final String LAYOUT_ID_FOR_BGR_PANEL = "payTableScreen";
//    private final String ID_FOR_BUTTON_SCREEN_TEMP = "buttonscreen_tmp";
    private final String ID_FOR_TOMB_SYMBOL = "tombSymbolWinShortAnimation";
//    private final String ID_FOR_BIG_WIN_SCREEN = "BigWinScreen";

    /**
     * ID of the panel that moves from the lower screen to the upper one after the end of free games
     * Here it is only hiding from the screen
     */
    private final String ID_FOR_BGR_FREE_GAMES_IMAGE2 = "center_mg";

    public ChangeFramesAndBgrForFreeGames() {
        viewManager = GameEngine.current().getViewManager();
        customKeyframeAnimationView = new CustomKeyframeAnimationView[LINES_COUNT][COLUMNS_COUNT];
        line0List = new ArrayList<>();
        freeGamesFrames = GameEngine.current().getViewManager().findViewById(LAYOUT_BGS_ID, FREE_GAMES_FRAME_ID);
        baseGamesFrames = GameEngine.current().getViewManager().findViewById(LAYOUT_BGS_ID, BASE_GAME_FRAME_ID);
        //InitCustomKeyframes();
        //initBackgroundReels();
    }

    /**
     * Initializing an array of background images for reels
     */
    private void initBackgroundReels() {
        for (int i = 0; i < backgroundReels.length; i++) {
            backgroundReels[i] = GameEngine.current().getViewManager().findViewById(LAYOUT_ID_FOR_BACKGROUND, i + "");
        }
    }


    /**
     * Initialize the filling of the array with all the frames
     */
    public void InitCustomKeyframes() {

        //for lines from 1 to 10
        for (int i = 0; i < LINES_COUNT; i++) {
            winLineView = viewManager.findViewById(LAYOUT_WIN_LINES_ID, WIN_LINE_VIEW_ID + (i + 1));
            fillArrayFrames(i + 1);
        }

        //for line 0
        winLine0View = viewManager.findViewById(LAYOUT_WIN_LINES_ID, WIN_LINE0_VIEW_ID);
        fillArrayFramesForLine0();
    }

    /**
     * Fill the array with frames
     */
    public void fillArrayFrames(int lineNumber) {
        linesObjects = winLineView.getChildren();
        int i = 0;
        for (View view : linesObjects) {
            if (view.getClass() == (CustomKeyframeAnimationView.class)) {
                customKeyframeAnimationView[lineNumber - 1][i++] = (CustomKeyframeAnimationView) view;
            }
        }
    }

    /**
     * Fills the list of frames for the line 0
     */
    public void fillArrayFramesForLine0(){
        linesObjects = winLine0View.getChildren();
        for (View view : linesObjects) {
            if (view.getClass() == (CustomKeyframeAnimationView.class)) {
                line0List.add((CustomKeyframeAnimationView) view);
            }
        }
    }

    /**
     * Show the frames and background for the FreeGames mode
     */
    public void showFreeGamesFramesAndBgr() {
        //changeFrames(freeGamesFrames);
        //changeBackground(true);
    }

    /**
     * Hide the frames and background for the FreeGames mode
     * change the priority of screens
     */
    public void hideFreeGamesFramesAndBgr() {
        //changeFrames(baseGamesFrames);
        //changeBackground(false);

        //hide the background on the payTableScreen
        ImageView centerPanel = GameEngine.current().getViewManager().findViewById(LAYOUT_ID_FOR_BGR_PANEL, ID_FOR_BGR_FREE_GAMES_IMAGE2);
        centerPanel.setVisible(false);
        centerPanel.setAlpha(1);
        centerPanel.setY(MoveUpBackground.getinitialYPosition());

        //hide the sliding panel after the end of free games
        GameEngine.current().getViewManager().findViewById(LAYOUT_ID_FOR_BGR_FREE_GAMES, ID_FOR_BGR_IMAGE).setVisible(false);

        //change the priority of screens
        IViewManager viewManager = GameEngine.current().getViewManager();
        ViewGroup stage = viewManager.getStage();
//        stage.addChild(viewManager.getLayout(ID_FOR_BUTTON_SCREEN_TEMP).getRootView());
//        stage.addChild(viewManager.getLayout(ID_FOR_BIG_WIN_SCREEN).getRootView());

        stage.addChild(viewManager.getLayout("reel_bg_ground").getRootView());
        stage.addChild(viewManager.getLayout("bgrScreen").getRootView());
//        viewManager.getLayout("bgrScreen").getRootView().setDepth(10);
        stage.addChild(viewManager.getLayout("winLinesScreen").getRootView());
        stage.addChild(viewManager.getLayout("wonPanelScreen").getRootView());
        stage.addChild(viewManager.getLayout(LAYOUT_ID_FOR_BGR_FREE_GAMES).getRootView());
        stage.addChild(viewManager.getLayout("payTableScreen").getRootView());
//        viewManager.getLayout("payTableScreen").getRootView().setDepth(11);
        viewManager.redrawAll();
        if(MoveUpBackground.getActionIsFinish())MoveUpBackground.setActionIsFinish(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Cleopatra").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Griffin").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Necklace").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Bracelet").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Ace").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "King").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Queen").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Jack").setVisible(false);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "Ten").setVisible(false);

    }

    /**
     * Specify the appropriate frames for the corresponding mode
     *
     * @param keyframeAnimationView
     */
    private void changeFrames(CustomKeyframeAnimationView keyframeAnimationView) {
        //for lines from 1 to 10
        for (CustomKeyframeAnimationView[] keyframeAnimationArray : customKeyframeAnimationView) {
            for (CustomKeyframeAnimationView keyframeAnimation : keyframeAnimationArray) {
                keyframeAnimation.setFrames(keyframeAnimationView.getFrames());
            }
        }
        //for line 0
        for(CustomKeyframeAnimationView keyframeAnimation:line0List){
            keyframeAnimation.setFrames(keyframeAnimationView.getFrames());
        }
    }

    private void changeBackground(boolean freeGamesbackground) {
        //Stop the animation for scattere symbol on the upper screen
        if (scatterAnimation == null) {
            scatterAnimation = GameEngine.current().getViewManager().findViewById(LAYOUT_ID_FOR_BGR_FREE_GAMES, ID_FOR_TOMB_SYMBOL);
        }
        scatterAnimation.gotoAndPause(1);

        //change the background of reels during free games
        if (freeGamesbackground) {
            for (int i = 0; i < BaseBgrIndex; i++)
                backgroundReels[i].setVisible(true);
            for (int j = BaseBgrIndex; j < backgroundReels.length; j++)
                backgroundReels[j].setVisible(false);
        }
    }
}
