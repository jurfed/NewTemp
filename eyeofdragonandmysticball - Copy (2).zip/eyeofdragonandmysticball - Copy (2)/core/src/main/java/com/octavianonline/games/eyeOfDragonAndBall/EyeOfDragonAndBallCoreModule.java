package com.octavianonline.games.eyeOfDragonAndBall;

import javax.inject.Named;
import javax.inject.Singleton;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.utility.localization.LocalResourceTranslationProvider;
import com.atsisa.gox.games.octavian.formatter.IOctavianFormatter;
import com.atsisa.gox.games.octavian.formatter.OctavianFormatter;
import com.atsisa.gox.games.octavian.reels.ODenominationModelProvider;
import com.atsisa.gox.reels.ReelsReleaseModule;
import com.atsisa.gox.reels.model.*;
//import com.atsisa.gox.reels.screen.NovolineControlPanelScreen;
import com.atsisa.gox.rng.IRngService;
import com.octavianonline.games.eyeOfDragonAndBall.logic.QueenCleopatraRngService;
import com.atsisa.gox.framework.configuration.GameConfiguration;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.framework.resource.ResourceDescriptionModel;
import com.atsisa.gox.reels.ReelSpinModule;
import com.atsisa.gox.reels.ReelsCoreModule;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.atsisa.gox.reels.screen.FadeScreen;
import com.atsisa.gox.reels.screen.GamblerScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
//import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallGamblerScreen;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallPaytableScreen;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.WinLinesScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.reels.screen.transition.TopDownInfoScreenTransition;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallInfoScreen;
import com.atsisa.gox.framework.utility.GameConfigurationStatics;
import com.atsisa.gox.framework.utility.IConfigurationProperties;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoSet;

/**
 * Represents an IoC module configuration.
 */
@Module(includes = {ReelsCoreModule.class,
        ReelSpinModule.class,
        ReelsReleaseModule.class,
        EyeOfDragonAndBallGameLogicModule.class})
public abstract class EyeOfDragonAndBallCoreModule {

    @Provides
    @Named(IConfigurationProperties.CONFIGURATION_PROPERTIES)
    static Map<String, String> configurationPropertiesBind() {
        Map<String, String> configurationProperties = new HashMap<>();
        configurationProperties.put(GameConfigurationStatics.GAME_RESOLUTION, "FHD_TWO_MONITORS");
        return configurationProperties;
    }

    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel gameResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("EyeOfDragonAndBall", "resources.xml");
    }

    @Singleton
    @Binds
    abstract IDenominationModelProvider bindIDenominationModelProvider(ODenominationModelProvider provider);

    @Binds
    @Singleton
    abstract IGameConfiguration gameConfigurationBind(GameConfiguration gameConfiguration);

    @Provides
    @Singleton
    static IMutator<ILinesModel> linesModelMutatorBind() {
        return new NoLinesModelMutator();
    }


    @Singleton
    @Provides
    @Named(GamblerScreen.LAYOUT_ID_PROPERTY)
    static String gamblerScreenLayoutBind() {
        return "gamblerScreen";
    }

    @Singleton
    @Provides
    @Named(InfoScreen.LAYOUT_ID_PROPERTY)
    static String infoScreenLayoutBind() {
        return "infoScreen";
    }

    @Singleton
    @Provides
    @Named(WinLinesScreen.LAYOUT_ID_PROPERTY)
    static String winLineScreenLayoutBind() {
        return "winLinesScreen";
    }

    @Singleton
    @Provides
    @Named(BaseGameScreen.LAYOUT_ID_PROPERTY)
    static String baseGameScreenLayoutBind() {
        return "baseGameScreen";
    }

    @Provides
    @Singleton
    @Named(ErrorScreen.LAYOUT_ID_PROPERTY)
    static String errorScreenLayoutBind() {
        return "errorScreen";
    }

    @Singleton
    @Provides
    @Named(BottomPanelScreen.LAYOUT_ID_PROPERTY)
    static String controlPanelScreenLayoutBind() {
        return "controlPanelScreen";
    }

    @Singleton
    @Provides
    @Named(ReelGameSpinSoundStrategy.SPIN_SOUND_ID_PROPERTY)
    static String classicSpinSoundBind() {
        return "ReelSpinMelody";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.SHOW_INFO_SCREEN_SOUND_ID_PROPERTY)
    static String infoScreenShowSoundBind() {
        return "Shift";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY)
    static String autoPlayOnSoundBind() {
        return "AutoPlayOff";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY)
    static String autoPlayOffSoundBind() {
        return "AutoPlayOn";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY)
    static String betChangingSoundBind() {
        return "BetChanging";
    }

    @Provides
    @Singleton
    @Named(FadeScreen.LAYOUT_ID_PROPERTY)
    static String fadeScreenLayoutBind() {
        return FadeScreen.LAYOUT_ID_DEFAULT;
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyReversedRedCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_red_card_reverse.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyClubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyDiamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyHeartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historySpadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_spade_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String spadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/spade_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String clubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String heartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String diamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String reversedBlackCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/blue_card_reverse.png";
    }

    @Provides
    @Singleton
    static InfoScreenTransition infoScreenTransitionBind() {
        return new TopDownInfoScreenTransition();
    }

    @Provides
    @Singleton
    static IRngService rngServiceBind() {
        return new QueenCleopatraRngService();
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(LocalResourceTranslationProvider.TRANSLATION_RESOURCE)
    static String languageListConfiguration() {
        return "LanguagesList";
    }

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen novolineControlPanelScreenBind(NovolineControlPanelScreen novolineControlPanelScreen);*/

/*    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel novolineResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("NovolineControlPanel", "resources.xml");
    }*/

/*    @Provides
    @Singleton
    @Named(NovolineControlPanelScreen.SHOW_GAME_INFO_EXECUTABLE)
    static IExecutable novolineShowGameInfoExecutableBind(IActionManager actionManager) {
        return new ActionQueueExecutable("ShowNextInfoScreen", actionManager);
    }

    @Provides
    @Singleton
    @Named(NovolineControlPanelScreen.ENTER_GAMBLER_EXECUTABLE)
    static IExecutable novolineEnterGamblerExecutableBind(IActionManager actionManager) {
        return new ActionQueueExecutable("EnteringGambler", actionManager);
    }*/

    @Binds
    @Singleton
    abstract ITranslationProvider translationProviderBind(LocalResourceTranslationProvider localResourceTranslationProvider);

    @Provides
    @Named(BottomPanelScreen.BUTTON_STATES_RESOURCES_ID)
    static Set<String> buttonStatesResourcesId() {
        HashSet<String> resources = new HashSet<>();
        resources.add("buttonStates");
        return resources;
    }


    @Binds
    @Singleton
    abstract IGame gameBind(EyeOfDragonAndBall game);

/*    @Binds
    @Singleton
    abstract ILinesModelProvider linesModelProviderBind(LinesModelProvider linesModelProvider);*/

    @Singleton
    abstract GamblerScreenModel gamblerScreenModelBind();

    @Singleton
    abstract BottomPanelScreenModel bottomPanelScreenModelBind();

    @Binds
    @Singleton
    @IntoSet
    abstract Screen gamblerScreenBind(EyeOfDragonAndBallGamblerScreen gamblerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen infoScreenBind(EyeOfDragonAndBallInfoScreen infoScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen baseGameScreenBind(EyeOfDragonAndBallBaseGameScreen baseGameScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen winLinesScreenBind(WinLinesScreen winLinesScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen errorScreenBind(ErrorScreen errorScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen fadeScreenBind(FadeScreen fadeScreen);

    @Singleton
    @Provides
    @Named(EyeOfDragonAndBallPaytableScreen.LAYOUT_ID_PROPERTY)
    static String payTableScreenLayoutBind() {
        return "payTableScreen";
    }

/*    @Provides
    @Singleton
    @IntoSet
    static Screen payTableScreenBind(IGameConfiguration gameConfiguration, @Named(EyeOfDragonAndBallPaytableScreen.LAYOUT_ID_PROPERTY) String layoutId,
            PayTableScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus,
            InfoScreenTransition infoScreenTransition) {
            return new EyeOfDragonAndBallPaytableScreen(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);
    }

    @Singleton
    abstract PayTableScreenModel payTableScreenModelBind();*/

    @Binds
    @Singleton
    abstract IValueFormatter bindIValueFormatter(OctavianFormatter formatter);

    @Binds
    @Singleton
    abstract ICreditsFormatter creditsFormatterBind(OctavianFormatter creditsFormatter);

    @Singleton
    @Provides
    @Named(IOctavianFormatter.DENOMINATION_CURRENCY_CODE)
    static String bindDenominationCurrencyCode() {
        return "\u00A2";
//        return "c";
    }
}
