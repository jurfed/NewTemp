package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.octavianonline.games.eyeOfDragonAndBall.command.StartSelectingExtendedSymbolAnimationCommand;

/**
 * Request for start feature extended symbol animation
 */
public class StartSelectingExtendedSymbolAnimationAction extends SyncAction {

    /**
     * Initializes a new instance of the {@link StartSelectingExtendedSymbolAnimationAction} class.
     */
    public StartSelectingExtendedSymbolAnimationAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link StartSelectingExtendedSymbolAnimationAction} class.
     * @param logger {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public StartSelectingExtendedSymbolAnimationAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        eventBus.post(new StartSelectingExtendedSymbolAnimationCommand() );
    }

}