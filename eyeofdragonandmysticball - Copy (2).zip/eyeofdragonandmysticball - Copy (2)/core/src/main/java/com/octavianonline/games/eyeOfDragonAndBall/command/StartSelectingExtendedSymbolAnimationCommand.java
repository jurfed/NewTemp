package com.octavianonline.games.eyeOfDragonAndBall.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to play book select scatter animation
 */
@Reflectable
public class StartSelectingExtendedSymbolAnimationCommand {

}
