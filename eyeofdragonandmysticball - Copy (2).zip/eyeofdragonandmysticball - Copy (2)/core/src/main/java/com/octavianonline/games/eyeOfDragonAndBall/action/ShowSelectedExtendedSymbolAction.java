package com.octavianonline.games.eyeOfDragonAndBall.action;


import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.Bookpause;
import com.octavianonline.games.eyeOfDragonAndBall.command.ShowSelectedExtendedSymbolCommand;
import com.octavianonline.games.eyeOfDragonAndBall.event.ShownExtendedSymbolEvent;

/**
 * Request for stop feature extended symbol animation at specified symbol
 */
public class ShowSelectedExtendedSymbolAction extends WaitForEventAction<ShownExtendedSymbolEvent> {

    /**
     * Initializes a new instance of the {@link ShowSelectedExtendedSymbolAction} class.
     */
    public ShowSelectedExtendedSymbolAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowSelectedExtendedSymbolAction} class.
     * @param logger   {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public ShowSelectedExtendedSymbolAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        super.execute();
        Bookpause.setPauseTime(450);
        eventBus.post(new ShowSelectedExtendedSymbolCommand());
    }

    @Override
    protected Class<ShownExtendedSymbolEvent> getEventClass() {
        return ShownExtendedSymbolEvent.class;
    }
}