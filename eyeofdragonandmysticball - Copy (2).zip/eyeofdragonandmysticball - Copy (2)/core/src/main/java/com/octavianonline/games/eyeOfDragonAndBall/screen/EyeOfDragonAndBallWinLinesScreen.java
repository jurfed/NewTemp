package com.octavianonline.games.eyeOfDragonAndBall.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;
import com.atsisa.gox.reels.model.IValueFormatter;
import com.atsisa.gox.reels.screen.WinLinesScreen;

import javax.inject.Inject;
import javax.inject.Named;

public class EyeOfDragonAndBallWinLinesScreen extends WinLinesScreen {
    private static boolean spinEnable = true;
    public static final String LAYOUT_ID_PROPERTY = "QueenCleopatraWinLinesScreenLayoutId";
    WinLinesScreen winLinesScreen;

    /**
     *
     * @param layoutId          layout identifier
     * @param model             {@link ScreenModel}
     * @param renderer          {@link IRenderer}
     * @param viewManager       {@link IViewManager}
     * @param animationFactory  {@link IAnimationFactory}
     * @param logger            {@link ILogger}
     * @param eventBus          {@link IEventBus}
     * @param linesModelMutator the lines model mutator
     * @param creditsFormatter  the credits formatter
     */
    @Inject
    public EyeOfDragonAndBallWinLinesScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IMutator<ILinesModel> linesModelMutator, IValueFormatter creditsFormatter) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, linesModelMutator, creditsFormatter);
        this.winLinesScreen = winLinesScreen;
    }


    @Override
    protected void afterActivated() {
        super.afterActivated();
        getEventBus().register(new PresentationStateChangedEventObserver(), PresentationStateChangedEvent.class);
    }

    /**
     * Called when spin should be invoked.
     */
    @ExposeMethod
    public void spin() {
        getEventBus().post(new SpinCommand());
    }

    private class PresentationStateChangedEventObserver extends NextObserver<PresentationStateChangedEvent> {
        @Override
        public void onNext(final PresentationStateChangedEvent presentationStateChangedEvent) {

            if (presentationStateChangedEvent.getStateName().equals("Idle")) {
                setModelProperty("spinEnable", Boolean.TRUE);
            } else {
                setModelProperty("spinEnable", Boolean.FALSE);
            }
        }
    }

}
