package com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.actionData;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class SpinFlashPlayActionData extends ActionData {

    @XmlAttribute
    private boolean winLine=false;

    public boolean getWinLine() {
        return winLine;
    }

    public void setWinLine(boolean winLine) {
        this.winLine = winLine;
    }

}
