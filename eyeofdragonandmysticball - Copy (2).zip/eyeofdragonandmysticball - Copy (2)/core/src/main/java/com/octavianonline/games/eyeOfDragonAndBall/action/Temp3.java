package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.StartControlPanelWinCollectCommand;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.GetWinAmountsForCollect;

public class Temp3  extends Action {
    public static final int AWESOME_WIN = 8700;
    @Override
    protected void execute() {
        Long totalWinAmount = GetWinAmountsForCollect.getTotalAmountForBigWin();
        Long startWinAmount = GetWinAmountsForCollect.getStartAmountForBigWin();
        eventBus.post(new StartControlPanelWinCollectCommand(AWESOME_WIN, startWinAmount, totalWinAmount));
        finish();
    }
}
