package com.octavianonline.games.eyeOfDragonAndBall.action.configuretion;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.spi.IViewActivator;
import com.atsisa.gox.reels.view.WinLineView;
import com.octavianonline.games.eyeOfDragonAndBall.customviews.CustomKeyframeAnimationView;

/**
 * The class makes the animated frames inactive when the winning lines are not visible
 */
public class SetConfigurationWinLineView extends Action {

    /**
     * Number of lines
     */
    private final int LINES_COUNT = 10;
    private final String LAYOUT_WIN_LINES_ID = "winLinesScreen";
    private final String WIN_LINE_VIEW_ID = "line";
    private CustomViewActivator customViewActivator = new CustomViewActivator();

    @Override
    protected void execute() {
        for (int i = 0; i < LINES_COUNT; i++) {
            WinLineView winLineView = GameEngine.current().getViewManager().findViewById(LAYOUT_WIN_LINES_ID, WIN_LINE_VIEW_ID + (i + 1));
            winLineView.setViewActivator(customViewActivator);

        }
        finish();
    }

    class CustomViewActivator implements IViewActivator {

        @Override
        public void activate(View view) {
            view.setVisible(true);
            if (view instanceof CustomKeyframeAnimationView) {
                ((CustomKeyframeAnimationView) view).play();
            }
        }

        @Override
        public void deactivate(View view) {
            view.setVisible(false);
            if (view instanceof CustomKeyframeAnimationView) {
                ((CustomKeyframeAnimationView) view).stop();
            }
        }
    }
}
