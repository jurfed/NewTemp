package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.action.Action;

public class EmptyAction extends Action{
    @Override
    protected void execute() {
        finish();
    }
}
