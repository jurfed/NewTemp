package com.octavianonline.games.eyeOfDragonAndBall.logic;

import java.util.*;
import java.util.stream.Collectors;
import javax.inject.Inject;

import com.atsisa.gox.framework.eventbus.UIDispatcherOnSubscribe;
import com.atsisa.gox.logic.*;
import com.atsisa.gox.logic.model.CardType;
import com.atsisa.gox.logic.model.LineWinResult;
import com.atsisa.gox.logic.model.Symbol;
import com.atsisa.gox.logic.model.WinResult;
import com.atsisa.gox.logic.model.utils.ReelStripSymbolType;
import com.atsisa.gox.logic.provider.IAnimationsProvider;
import com.atsisa.gox.logic.provider.ISoundsProvider;
import com.atsisa.gox.reels.backend.PresentationBuilder;
import com.atsisa.gox.reels.backend.step.*;
import com.atsisa.gox.reels.logic.DenominationResult;
import com.atsisa.gox.reels.logic.IExtendedSymbolGameLogic;
import com.atsisa.gox.reels.logic.IFreeGamesGameLogic;
import com.atsisa.gox.reels.logic.IReelGameLogic;
import com.atsisa.gox.reels.logic.request.BetRequest;
import com.atsisa.gox.reels.logic.request.InitRequest;

import com.octavianonline.games.eyeOfDragonAndBall.EyeOfDragonAndBallDenomination;
import rx.Observable;


/**
 * Contains logic implementation
 */
public class QueenCleopatraLogic implements IReelGameLogic, IFreeGamesGameLogic, IExtendedSymbolGameLogic {

    /**
     * Number of cards in gambler history.
     */
    private static final int NUMBER_OF_CARDS_IN_HISTORY = 5;

    /**
     * Set of logic initializables components
     */
    private final Set<ILogicInitializable> logicInitializables;

    /**
     * Logic presentation factoru
     */
    private final QueenCleopatraPresentationFactory presentationFactory;

    /**
     * The {@link IReelsLogic}
     */
    private final IReelsLogic reelsLogic;

    /**
     * The {@link IScatterLogic}
     */
    private final IScatterLogic scatterLogic;

    /**
     * The {@link IGamblerLogic}
     */
    private final IGamblerLogic gamblerLogic;

    /**
     * The {@link IFreeGamesLogic}
     */
    private final IFreeGamesLogic freeGamesLogic;

    /**
     * The {@link IExtendedSymbolLogic}
     */
    private final IExtendedSymbolLogic extendedSymbolLogic;
    protected IAnimationsProvider animationsProvider;
    protected ISoundsProvider soundProvider;
    /**
     * The current {@link SpinRequest}
     */
    SpinRequest spinRequest;
    /**
     * The current {@link SpinResult}
     */
    SpinResult spinResult;
    /**
     * The extended symbol
     */
    private Symbol extendedSymbol;

    /**
     * Initializes a new instance of the {@link QueenCleopatraLogic} class
     *
     * @param logicInitializables The set of {@link ILogicInitializable}
     * @param presentationFactory The logic presentation factory
     * @param reelsLogic          The {@link IReelsLogic}
     * @param scatterLogic        The {@link IScatterLogic}
     * @param gamblerLogic        The {@link IGamblerLogic}
     * @param freeGamesLogic      The {@link IFreeGamesLogic}
     * @param extendedSymbolLogic The {@link IExtendedSymbolLogic}
     * @param animationsProvider
     * @param soundProvider
     */
    @Inject
    public QueenCleopatraLogic(Set<ILogicInitializable> logicInitializables, QueenCleopatraPresentationFactory presentationFactory, IReelsLogic reelsLogic,
                          IScatterLogic scatterLogic, IGamblerLogic gamblerLogic, IFreeGamesLogic freeGamesLogic, IExtendedSymbolLogic extendedSymbolLogic, IAnimationsProvider animationsProvider, ISoundsProvider soundProvider) {
        this.logicInitializables = logicInitializables;
        this.presentationFactory = presentationFactory;
        this.reelsLogic = reelsLogic;
        this.scatterLogic = scatterLogic;
        this.gamblerLogic = gamblerLogic;
        this.freeGamesLogic = freeGamesLogic;
        this.extendedSymbolLogic = extendedSymbolLogic;
        this.animationsProvider = animationsProvider;
        this.soundProvider = soundProvider;
    }

    @Override
    public Observable<Object> init(InitRequest initRequest) {
        try {
            for (ILogicInitializable initializable : logicInitializables) {
                initializable.initialize();
            }

            List<Object> result = presentationFactory.getPresentations(initRequest);
            EyeOfDragonAndBallDenomination denomination = new EyeOfDragonAndBallDenomination();
            result.add(new DenominationResult(denomination.getDenominationSteps().get(0), denomination.getDenominationSteps()));
            return this.createObservable(result);
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(1, "Game logic", "Init request", e));
        }
    }

    @Override
    public Observable<Object> bet(BetRequest betRequest) {
        spinRequest = new SpinRequest(betRequest.getBetAmount(), betRequest.getLinesAmount());
        ScatterResult scatterResult;
        ScatterRequest scatterRequest;
        CalculateFreeGamesResult calculateFreeGamesResult;
        try {
            spinResult = reelsLogic.spin(this.spinRequest);
            scatterRequest = new ScatterRequest(spinResult.getStopSymbols(), spinRequest.getBet(), spinRequest.getLines());

            scatterResult = scatterLogic.calculate(scatterRequest);
            calculateFreeGamesResult = freeGamesLogic.calculate(new CalculateFreeGamesRequest(scatterResult.getWinningLines()));
        } catch (GameLogicException ex) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "Game logic", "Spin error", ex));
        }

        List<WinResult> spinResults = spinResult.getWinningLines().stream().map(LineWinResult::getWinResult).collect(Collectors.toList());
        List<WinResult> scatterResults = scatterResult.getWinningLines().stream().map(winResult -> new WinResult(winResult.getWinDescriptorId(),
                winResult.getScore(),
                winResult.getPositions())).collect(Collectors.toList());

        List<WinResult> winResults = new ArrayList<>();
        winResults.addAll(spinResults);
        winResults.addAll(scatterResults);
        Map<Integer, String> winSounds;
        Map<Integer, String> winAnimations;
        Map<Integer, String> reelStripStopSounds;

        try {
            winSounds = soundProvider.getWinSounds(winResults);
            winAnimations = animationsProvider.getAnimations(winResults);
            reelStripStopSounds = soundProvider.getReelStripStopSound(spinResult.getStopSymbols());
        } catch (GameLogicException ex) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Error during obtaining win sounds and                    animations", ex));
        }

        List<Object> presentations;
        try {
            presentations = new PresentationBuilder().execute(new FixedParseSpinResult(spinResult, spinRequest, winSounds, winAnimations, reelStripStopSounds))
                    .execute(new FixedParseScatterResult(scatterRequest, scatterResult, winSounds, winAnimations, reelStripStopSounds)).execute(new ParseCalculateFreeGameResult(calculateFreeGamesResult, 0))
                    .get();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Spin error", e));
        }

        return this.createObservable(presentations);
    }

    @Override
    public synchronized Observable<Object> takeWin() {
        TakeWinResult takeWinResult;

        try {
            takeWinResult = reelsLogic.takeWin();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(1, "GameLogic", "Take win error", e));
        }

        List<Object> presentations;
        try {
            presentations = new PresentationBuilder().execute(new ParseTakeWinResult(takeWinResult)).get();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Spin error", e));
        }
        return this.createObservable(presentations);
    }

    @Override
    public Observable<Object> gamble(com.atsisa.gox.reels.logic.request.GambleRequest gambleRequest) {
        com.atsisa.gox.logic.GambleRequest request;
        if (gambleRequest.getSelectionName().equals("BetBlack")) {
            request = new com.atsisa.gox.logic.GambleRequest(CardType.BLACK);
        } else {
            request = new com.atsisa.gox.logic.GambleRequest(CardType.RED);
        }

        GambleResult response;
        try {
            response = gamblerLogic.gamble(request);
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(1, "GameLogic", "Gamble error", e));
        }
        List<Object> presentations;
        try {
            presentations = new PresentationBuilder().execute(new ParseGambleResult(response, NUMBER_OF_CARDS_IN_HISTORY)).get();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Gamble error", e));
        }
        return createObservable(presentations);
    }

    @Override
    public Observable<Object> enterGambler(com.atsisa.gox.reels.logic.request.EnterGamblerRequest enterGamblerRequest) {
        EnterGamblerResult response;
        com.atsisa.gox.logic.EnterGamblerRequest request = new com.atsisa.gox.logic.EnterGamblerRequest();
        try {
            response = gamblerLogic.enterGambler(request);
        } catch (Exception e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(1, "GamblerLogic", "Enter Gambler error 1", e));
        }

        List<Object> presentations;
        try {
            presentations = new PresentationBuilder().execute(new ParseEnterGamblerResult(response, NUMBER_OF_CARDS_IN_HISTORY)).get();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GamblerLogic", "Enter Gambler error", e));
        }
        return createObservable(presentations);
    }

    @Override
    public Observable<Object> selectExtendedSymbol() {
        DrawExtendedSymbolResult result;
        try {
            result = extendedSymbolLogic.drawSymbol();
            this.extendedSymbol = result.getExtendedSymbolDescriptor().getSymbol();

        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(3, "Extended symbol logic", "Draw extended symbol error.", e));
        }

        List<Object> presentations;
        try {
            presentations = new PresentationBuilder().
                    execute(new ParseDrawExtendedSymbolResult(result, spinRequest, spinResult, QueenCleopatraInitialStopReels.INITIAL_REELS)).get();
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(3, "Extended symbol logic", "Draw extended symbol error.", e));
        }
        return createObservable(presentations);
    }

    @Override
    public Observable<Object> nextFreeGame() {

        if (spinRequest == null) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(4, "Free game logic", "Spin cannot be null during free games"));
        }

        if (extendedSymbol == null) {
            return Observable
                              .error(new com.atsisa.gox.reels.logic.GameLogicException(4, "Free game logic", "Extended symbol cannot be null during free games"));
        }

        FreeGameSpinResult freeGameSpinResult;
        ExtendedSymbolRequest extendedSymbolRequest;
        ExtendedSymbolResult extendedSymbolResult;
        ScatterRequest scatterRequest;
        ScatterResult scatterResult;
        CalculateFreeGamesResult calculateFreeGamesResult;

        List<Symbol> excludedSymbols = new ArrayList<>();
//
//        // Free games paytable consists of base symbols
         excludedSymbols.add(new Symbol(extendedSymbol.getName(), extendedSymbol.getId(), ReelStripSymbolType.BASE_SYMBOL));
        Map<String, Object> freeGameSpinFeature = new HashMap<>();
        freeGameSpinFeature.put(FreeGameSpinRequestFeatures.EXCLUDED_SYMBOLS, excludedSymbols);

        FreeGameSpinRequest freeGameSpinRequest = new FreeGameSpinRequest(spinRequest.getLines(), spinRequest.getBet(), freeGameSpinFeature);

        try {
            freeGameSpinResult = freeGamesLogic.spin(freeGameSpinRequest);
            scatterRequest = new ScatterRequest(freeGameSpinResult.getStopSymbols(), spinRequest.getBet(), spinRequest.getLines());
            scatterResult = scatterLogic.calculate(scatterRequest);
            calculateFreeGamesResult = freeGamesLogic.calculate(new CalculateFreeGamesRequest(scatterResult.getWinningLines()));
            extendedSymbolRequest = new ExtendedSymbolRequest(extendedSymbol, spinRequest.getLines(), freeGameSpinResult.getStopSymbols(),
                    spinRequest.getBet());
            extendedSymbolResult = extendedSymbolLogic.calculate(extendedSymbolRequest);
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(4, "Free game logic", "Next free game error", e));
        }

        List<Object> presentations;
        long currentWin = freeGameSpinResult.getCurrentWinAmount() + extendedSymbolResult.getBank().getWinAmount() + scatterResult.getBank().getWinAmount();
        long totalWin = freeGameSpinResult.getBank().getWinAmount() + extendedSymbolResult.getBank().getWinAmount() + scatterResult.getBank().getWinAmount();

/*        long totalWin = freeGameSpinResult.getBank().getWinAmount() + scatterResult.getBank().getWinAmount();
        long currentWin = freeGameSpinResult.getCurrentWinAmount() + scatterResult.getBank().getWinAmount();*/

        List<WinResult> winResults = spinResult.getWinningLines().stream().map(LineWinResult::getWinResult).collect(Collectors.toList());
        winResults.addAll(freeGameSpinResult.getWinningLines().stream().map(LineWinResult::getWinResult).collect(Collectors.toList()));
        Map<Integer, String> winSounds;
        Map<Integer, String> winAnimations;
        Map<Integer, String> reelStripStopSounds;
        Map<Integer, String> extendedSymbolWinSounds;
        List<WinResult> scatterResults = scatterResult.getWinningLines().stream().map(winResult -> new WinResult(winResult.getWinDescriptorId(),
                winResult.getScore(),
                winResult.getPositions())).collect(Collectors.toList());
        try {
            winSounds = soundProvider.getWinSounds(winResults);
            winSounds.putAll(soundProvider.getWinSounds(scatterResults));
            winAnimations = animationsProvider.getAnimations(winResults);
            winAnimations.putAll(animationsProvider.getAnimations(scatterResults));
            reelStripStopSounds = soundProvider.getReelStripStopSound(spinResult.getStopSymbols());
            extendedSymbolWinSounds = soundProvider
                    .getWinSounds(extendedSymbolResult.getWinningLines().stream().map(LineWinResult::getWinResult).collect(Collectors.toList()));

        } catch (GameLogicException ex) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Error during obtaining win sounds and                    animations", ex));
        }
        try {
            presentations = new PresentationBuilder()
                    //.execute(new ParseExtendedSymbolResult(extendedSymbolRequest, extendedSymbolResult))
                    .execute(new FixedParseFreeGameSpinResult(spinRequest, freeGameSpinResult, calculateFreeGamesResult.getTotalFreeGamesAmount(), currentWin, totalWin,
                            reelStripStopSounds,winSounds,winAnimations))
                    .execute(new FixedParseExtendedSymbolResult(extendedSymbolRequest, extendedSymbolResult, extendedSymbolWinSounds))
                    .execute(new FixedParseScatterResult(scatterRequest, scatterResult, winSounds, winAnimations,  reelStripStopSounds))
                    .execute(new ParseCalculateFreeGameResult(calculateFreeGamesResult, freeGameSpinResult.getFreeGamesPlayed()))
                    .get();
            //GameEngine.current().getEventBus().post(new CalculateFreeGamesEvent(calculateFreeGamesResult));
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(4, "Free game logic", "Next free game error", e));
        }
        return createObservable(presentations);
    }


    protected <T> Observable<T> createObservable(List<T> presentations) {
        return Observable.create(new UIDispatcherOnSubscribe<>(subscriber -> {
            try {
                presentations.forEach(subscriber::onNext);
            } catch (Exception ex) {
                subscriber.onError(ex);
            }
            subscriber.onCompleted();
        }));
    }
}
