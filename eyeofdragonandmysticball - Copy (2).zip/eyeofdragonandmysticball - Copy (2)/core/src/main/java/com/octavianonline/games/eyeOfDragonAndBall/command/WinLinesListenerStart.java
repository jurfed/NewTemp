package com.octavianonline.games.eyeOfDragonAndBall.command;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.view.WinLineView;
import com.octavianonline.games.eyeOfDragonAndBall.action.ShowHideWinLines;

import java.util.HashMap;
import java.util.Map;

/**
 * class for specifying win line parameters and starting the line display mechanism
 */
public class WinLinesListenerStart {
    private static final String WIN_LINES_SCREEN = "winLinesScreen";
    private Map<Integer, Integer[]> linesSegments;

    public void initTimer() {
        /**
         *The local class is waiting for resource initialization
         */
        class TimeOutForResources implements TimeoutCallback {

            /**
             * Set parameters for win lines
             * linesSegments - A map indicating which frame, which line segments depend on
             */
            @Override
            public void onTimeout() {
                IViewManager viewManager = GameEngine.current().getViewManager();
                WinLineView winLineView = viewManager.findViewById(WIN_LINES_SCREEN, "line1");
                linesSegments = new HashMap<>();
                linesSegments.put(0, new Integer[]{0});
                linesSegments.put(1, new Integer[]{1});
                linesSegments.put(2, new Integer[]{2});
                linesSegments.put(3, new Integer[]{3});
                linesSegments.put(4, new Integer[]{4});
                //Transmit: the number of line segments, the line number, with which the always visible lines begin
                new ShowHideWinLines(7, 6, viewManager, winLineView, "Line1Screen", linesSegments);


                winLineView = viewManager.findViewById(WIN_LINES_SCREEN, "line2");
                linesSegments = new HashMap<>();
                linesSegments.put(0, new Integer[]{0});
                linesSegments.put(1, new Integer[]{1});
                linesSegments.put(2, new Integer[]{2});
                linesSegments.put(3, new Integer[]{3});
                linesSegments.put(4, new Integer[]{4});
                new ShowHideWinLines(7, 6, viewManager, winLineView, "Line2Screen", linesSegments);

                winLineView = viewManager.findViewById(WIN_LINES_SCREEN, "line3");
                linesSegments = new HashMap<>();
                linesSegments.put(0, new Integer[]{0});
                linesSegments.put(1, new Integer[]{1});
                linesSegments.put(2, new Integer[]{2});
                linesSegments.put(3, new Integer[]{3});
                linesSegments.put(4, new Integer[]{4});
                new ShowHideWinLines(7, 6, viewManager, winLineView, "Line3Screen", linesSegments);

                winLineView = viewManager.findViewById(WIN_LINES_SCREEN, "line4");
                linesSegments = new HashMap<>();
                linesSegments.put(0, new Integer[]{0, 1});
                linesSegments.put(1, new Integer[]{2});
                linesSegments.put(2, new Integer[]{3, 4});
                linesSegments.put(3, new Integer[]{5});
                linesSegments.put(4, new Integer[]{6, 7});
                new ShowHideWinLines(14, 9, viewManager, winLineView, "Line4Screen", linesSegments);

                winLineView = viewManager.findViewById(WIN_LINES_SCREEN, "line5");
                linesSegments = new HashMap<>();
                linesSegments.put(0, new Integer[]{0, 1});
                linesSegments.put(1, new Integer[]{2});
                linesSegments.put(2, new Integer[]{3, 4});
                linesSegments.put(3, new Integer[]{5});
                linesSegments.put(4, new Integer[]{6, 7});
                new ShowHideWinLines(14, 9, viewManager, winLineView, "Line5Screen", linesSegments);

            }
        }
        new Timeout(1000, new TimeOutForResources(), true).start();
    }

}
