package com.octavianonline.games.eyeOfDragonAndBall.logic;

import java.util.Arrays;
import java.util.List;

import com.atsisa.gox.reels.logic.model.Reel;

public class QueenCleopatraInitialStopReels {

    private final static String SOUND_NAME = "ReelStop0";

    static final List<Reel> INITIAL_REELS = Arrays.asList(
            new Reel(SOUND_NAME, Arrays.asList(1, 0, 3)),
            new Reel(SOUND_NAME, Arrays.asList(9, 5, 2)),
            new Reel(SOUND_NAME, Arrays.asList(4, 6, 3)),
            new Reel(SOUND_NAME, Arrays.asList(3, 5, 4)),
            new Reel(SOUND_NAME, Arrays.asList(4, 2, 0))
    );
}
