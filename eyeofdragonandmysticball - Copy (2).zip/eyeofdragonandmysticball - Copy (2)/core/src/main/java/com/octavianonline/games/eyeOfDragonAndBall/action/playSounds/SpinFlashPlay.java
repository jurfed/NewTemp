package com.octavianonline.games.eyeOfDragonAndBall.action.playSounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.octavianonline.games.eyeOfDragonAndBall.action.playSounds.actionData.SpinFlashPlayActionData;

/**
 * Plays sound "spinFlash" in the free games mode when the drum rotates,
 * if before it was a win or this is the first rotation of the drum.
 */
public class SpinFlashPlay extends Action<SpinFlashPlayActionData> {

    /**
     * sound id
     */
    private final String SPIN_FLASH="spinFlash";

    /**
     * Was there a previous win
     */
    private static boolean playSpinFlashSound = false;

    @Override
    protected void execute() {

        if (this.actionData.getWinLine()) {
            playSpinFlashSound = true;
        } else if (playSpinFlashSound && !this.actionData.getWinLine()) {
            playSpinFlashSound = false;
            ((SoundManager) GameEngine.current().getSoundManager()).play(SPIN_FLASH);
        }

        finish();
    }

    @Override
    public Class<SpinFlashPlayActionData> getActionDataType() {
        return SpinFlashPlayActionData.class;
    }

}
