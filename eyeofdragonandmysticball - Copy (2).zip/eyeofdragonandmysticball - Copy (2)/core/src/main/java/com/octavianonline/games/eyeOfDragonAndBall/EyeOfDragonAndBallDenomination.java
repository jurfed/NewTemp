package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.reels.model.IDenominationModel;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class EyeOfDragonAndBallDenomination implements IDenominationModel {
    /**
     * Current denomination value.
     */
    private final BigDecimal currentDenomination = BigDecimal.ZERO;

    /**
     * The list of denomination steps.
     */
    private final List<BigDecimal> denominationSteps = prepareDenominationSteps();

    @Override
    public BigDecimal getCurrentDenomination() {
        return currentDenomination;
    }

    @Override
    public List<BigDecimal> getDenominationSteps() {
        return denominationSteps;
    }

    @Override
    public BigDecimal getDenominationStep(int index) {
        return currentDenomination;
    }

    private List<BigDecimal> prepareDenominationSteps() {
        List<BigDecimal> denominationSteps = new ArrayList<>();
        denominationSteps.add(BigDecimal.valueOf(1));
        denominationSteps.add(BigDecimal.valueOf(2));
        denominationSteps.add(BigDecimal.valueOf(10));
        return denominationSteps;
    }
}
