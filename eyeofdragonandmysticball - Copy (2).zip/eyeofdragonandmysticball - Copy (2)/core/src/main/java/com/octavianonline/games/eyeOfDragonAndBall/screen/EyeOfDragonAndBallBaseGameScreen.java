package com.octavianonline.games.eyeOfDragonAndBall.screen;

import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.command.ChangeLanguageCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.games.octavian.core.event.WakeUpScreenSaverEvent;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.animation.ReelAnimation;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.command.StartAutoPlayCommand;
import com.atsisa.gox.reels.command.StopAutoPlayCommand;
import com.atsisa.gox.reels.event.PresentationStateChangedEvent;
import com.atsisa.gox.reels.logic.InitResult;
import com.atsisa.gox.reels.model.IExtendedSymbolModelProvider;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import com.atsisa.gox.reels.view.AbstractReel;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.atsisa.gox.reels.view.ReelView;
import com.atsisa.gox.reels.view.state.ReelState;
//import com.atsisa.gox.games.octavian.core.service.ReelsService;
import com.octavianonline.games.eyeOfDragonAndBall.action.movie.InitHandlingLogoMovies;
import com.octavianonline.games.eyeOfDragonAndBall.event.FormStoppedSymbols;
import com.octavianonline.games.eyeOfDragonAndBall.helpers.AutoplayButtomListener;
import rx.Observable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents the base game screen
 */
public class EyeOfDragonAndBallBaseGameScreen extends BaseGameScreen {

    /**
     * Flag: is debug button visible
     */
    private final String DEBUG_BUTTON_VISIBLE = "debugButtonVisible";
    private static final String REEL_GROUP_VIEW = "reelGroupView";
    private Observable<ReelState>[] reelStateObservable = new Observable[5];
    private ISoundManager soundManager;
    private int scatterSoundCount = 0;
    private AutoplayButtomListener autoplayButtomListener;
    private static IFreeGamesModelProvider freeGamesModelProvider;
    private static IExtendedSymbolModelProvider extendedSymbolModelProvider;
    private static long allFreeGamesAmount;
    private static boolean spinEnable = true;
    private Map<Integer, Iterable<String>> stopSymbolsmap;
    private ReelAnimation reelAnimation;
    private static final String REEL_STATE_SPINNING = "SPINNING";

    /**
     * True, if this reels was stopped by clicking on it
     */
    private Map<Integer, Boolean> clickOnSpinningReels = new HashMap() {{
        put(0, false);
        put(1, false);
        put(2, false);
        put(3, false);
        put(4, false);
    }};
/*    @Inject
    public ReelsService reelsHelper;*/

    /**
     * Initializes a new instance of the {@link EyeOfDragonAndBallBaseGameScreen} class.
     *
     * @param layoutId         layout identifier
     * @param model            {@link ScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public EyeOfDragonAndBallBaseGameScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory,
                                            ILogger logger, IEventBus eventBus, ISoundManager soundManager, IFreeGamesModelProvider freeGamesModelProvider, IExtendedSymbolModelProvider iExtendedSymbolModelProvider) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.soundManager = soundManager;
        this.freeGamesModelProvider = freeGamesModelProvider;
        this.extendedSymbolModelProvider = iExtendedSymbolModelProvider;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new InitResultObserver(), InitResult.class);

    }

    private void handlePresentationStateChangedEvent(PresentationStateChangedEvent presentationStateChangedEvent) {
        switch (presentationStateChangedEvent.getStateName()) {
            case ReelsPresentationStates.IDLE:
                setModelProperty(DEBUG_BUTTON_VISIBLE, true);
                break;
            default:
                setModelProperty(DEBUG_BUTTON_VISIBLE, false);
        }
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
        getEventBus().register(new PresentationStateChangedEventObserver(), PresentationStateChangedEvent.class);
        getEventBus().register(new StartAutoPlayObserver(), StartAutoPlayCommand.class);
        getEventBus().register(new StopAutoPlayObserver(), StopAutoPlayCommand.class);
        getEventBus().register(new StopVideoPlaying(), WakeUpScreenSaverEvent.class);

//        getEventBus().post(new ReelSpeedChangeEvent(0, 1.5f));
/*
        getEventBus().post(new ApplyReelsRotationTimeEvent(new ArrayList() {{
            add(400);
            add(700);
            add(1000);
            add(1300);
            add(1600);
        }}));
*/

        getEventBus().register(new ChangeLanguageObserver(), ChangeLanguageCommand.class);

        autoplayButtomListener = new AutoplayButtomListener();
        reelGroupView = (ReelGroupView) findViewById(REEL_GROUP_VIEW);
        for (int i = 0; i < reelGroupView.getChildCount(); i++) {
            reelStateObservable[i] = ((ReelView) reelGroupView.getReel(i)).getReelStateObservable();

        }
        initScatterStopSound();
        setModelProperty("spinEnable", Boolean.TRUE);
        languageChangeInit();
        new Timeout(30000, () -> InitHandlingLogoMovies.enableTimer(true), true);
    }

    class ReelsNextObserver extends NextObserver<ReelState> {

        @Override
        public void onNext(ReelState reelState) {
            System.out.println();
        }
    }

    /**
     * Called when spin should be invoked.
     */
    @ExposeMethod
    public void spin() {
        getEventBus().post(new SpinCommand());
    }

    /**
     * For stopping reels by clicking on it
     *
     * @param reelNumber - reel number (0, 1, 2, 3, 4) that we want to stop
     */
    @ExposeMethod
    public void stopReel(int reelNumber) {
        List<String> stoppingSymbolsNames = new ArrayList<>();
        Iterable<String> stoppingSymbols = stopSymbolsmap.get(reelNumber);
        stoppingSymbols.forEach(symbolName -> {
            stoppingSymbolsNames.add(symbolName);
        });
        AbstractReel reel = reelGroupView.getReel(reelNumber);
        reelAnimation = (ReelAnimation) reelGroupView.getReel(reelNumber).getReelAnimation();
        reelAnimation.setSpeedIncrease(10);
        reelAnimation.speedUp();
        if (reel.getReelState().name().equals(REEL_STATE_SPINNING)) {
//            System.out.println("######## reel: " + reelNumber + "     " + reel.getReelState().name());
            reel.forceStopOnSymbols(stoppingSymbolsNames);
        }
        clickOnSpinningReels.put(reelNumber, true);
        setReelTouchButtonVisible(reelNumber + 1, false);
//        skipReelsSpin();
//        GameEngine.current().getUtility().getTimerManager().getTimer("spin").cancel();
    }

    private class PresentationStateChangedEventObserver extends NextObserver<PresentationStateChangedEvent> {
        @Override
        public void onNext(final PresentationStateChangedEvent presentationStateChangedEvent) {
            handlePresentationStateChangedEvent(presentationStateChangedEvent);
            if (presentationStateChangedEvent.getStateName().equals("RunningReels") || presentationStateChangedEvent.getStateName().equals("FreeGamesRunningReels")) {
                scatterSoundCount = 0;
            }
            if (presentationStateChangedEvent.getStateName().equals("enterFeatureBannerScreen")) {

            }
            if (presentationStateChangedEvent.getStateName().equals("Idle")) {
                InitHandlingLogoMovies.enableTimer(true);
                setModelProperty("spinEnable", Boolean.TRUE);


            } else {
                InitHandlingLogoMovies.enableTimer(false);
                setModelProperty("spinEnable", Boolean.FALSE);
            }
        }
    }

    //For stop playing video
    class StopVideoPlaying extends NextObserver<WakeUpScreenSaverEvent> {

        @Override
        public void onNext(WakeUpScreenSaverEvent wakeUpScreenSaverEvent) {
            InitHandlingLogoMovies.enableTimer(false);
        }
    }


    /**
     * for playing scatter stop sound
     */
    void initScatterStopSound() {
        class ReelsNextObserver extends NextObserver<ReelState> {
            int reelNumber;


            ReelsNextObserver(int rellNumber) {
                this.reelNumber = rellNumber;

            }

            @Override
            public void onNext(ReelState reelState) {
                if (reelState.name().equals("IDLE")) {
                    //stoppedReels++;

                    for (int i = 0; i < 3; i++) {
                        AbstractSymbol scatterSymbol = reelGroupView.getReel(reelNumber).getDisplayedSymbol(i);
                        if (scatterSymbol.getName().equals("Tomb")) {
                            soundManager.play("FeatureTeaser0" + (scatterSoundCount + 1));
                            scatterSoundCount++;
                        }
                    }

/*                    if (stoppedReels == 4) {
//                        ITimer spinTimer = GameEngine.current().getUtility().getTimerManager().getTimer("spin");
                        GameEngine.current().getActionManager().processAction(new StopReelsAction());
                    }*/
                }
            }
        }
        for (int i = 0; i < reelStateObservable.length; i++) {
            reelStateObservable[i].subscribe(new ReelsNextObserver(i));
        }
    }

    /**
     * for start autoplay music
     */
    class StartAutoPlayObserver extends NextObserver<StartAutoPlayCommand> {

        @Override
        public void onNext(StartAutoPlayCommand startAutoPlayCommand) {
            if (startAutoPlayCommand.isTriggeredByUser()) {
                autoplayButtomListener.startPlaySound();
            }
        }
    }

    /**
     * for stop autoplay music
     */
    class StopAutoPlayObserver extends NextObserver<StopAutoPlayCommand> {

        @Override
        public void onNext(StopAutoPlayCommand stopAutoPlayCommand) {
            if (stopAutoPlayCommand.isTriggeredByUser()) {
                autoplayButtomListener.stopPlaySound();
            }
        }
    }


    public static long getAllFreeGamesAmount() {
        return allFreeGamesAmount;
    }

    public static void setAllFreeGamesAmount(long allFreeGamesAmount) {
        EyeOfDragonAndBallBaseGameScreen.allFreeGamesAmount = allFreeGamesAmount;
    }

    /**
     * For fill the reels stop symbols Map
     */
    @Subscribe
    public void formStoppedSymbolsEvent(FormStoppedSymbols event) {

        try {
            //get all stop symbols on the reels
            List<Iterable<String>> stopListSymbols = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder().getStoppedSymbols();
            //map for fill all stop symbols on the reels
            stopSymbolsmap = new HashMap<>();
            for (int i = 0; i < reelGroupView.getChildCount(); i++) {
                stopSymbolsmap.put(i, stopListSymbols.get(i));
                setReelTouchButtonVisible(i + 1, true);//for stop reel by click on it
                clickOnSpinningReels.put(i, false);
            }

        } catch (Exception e) {
            System.out.println("Error form stopped symbols");
        }
        //if (((String) ((LinkedList) stopListSymbols.get(0)).get(0)).equals("Track")) {
        //getEventBus().post(new ApplyReelsRotationTimeEvent(new ArrayList(){{add(400);add(700);add(5000);add(1300);add(1600);}}));
        // } else {
        // getEventBus().post(new ApplyReelsRotationTimeEvent(new ArrayList(){{add(400);add(700);add(1000);add(1300);add(1600);}}));
        // }
//            getModel().setProperty("symbolVisible", true);
    }

    /**
     * Visible area for stopping reels by clicking ot it
     *
     * @param reelNumber
     * @param visible
     */
    private void setReelTouchButtonVisible(int reelNumber, boolean visible) {
        if (visible) {
            setModelProperty("reel" + reelNumber + "Visible", Boolean.TRUE);
        } else {
            setModelProperty("reel" + reelNumber + "Visible", Boolean.FALSE);
        }

    }


    //    FOR DELETE
    class ChangeLanguageObserver extends NextObserver<ChangeLanguageCommand> {

        @Override
        public void onNext(ChangeLanguageCommand changeLanguageCommand) {
            if (changeLanguageCommand.getLanguageCode().equals("EN")) {
                if (czText != null) czText.setVisible(false);
                if (deText != null) deText.setVisible(false);
                if (LangSpecialSymbolFreeGames != null) LangSpecialSymbolFreeGames.setX(300);
                if (LangOnActiveLinePays != null) LangOnActiveLinePays.setText("on active line pays");
                if (LangTimesLineBet != null) LangTimesLineBet.setText("times line bet");

                if (Lang3OrMoreScattered != null) Lang3OrMoreScattered.setText("3333 or more scattered");
                if (LangTrigger10Free != null)
                    LangTrigger10Free.setText("trigger 10 Free Games\nwith special expanding symbol");

                if (LangOneSymbolIs != null) LangOneSymbolIs.setText("One symbol is randomly selected as\n" +
                        "the special symbol which expands and\n" +
                        "pays any on all lines played");

                if (settingsTitle != null) settingsTitle.setText("LANGUAGE");
                if (soundTitle != null) soundTitle.setText("SOUND");
                if (gamblerTitle != null) gamblerTitle.setText("GAMBLE");
                if (settingsQuite != null) settingsQuite.setLabel("Quit");
                if (reelsSound != null) reelsSound.setText("REELS SOUND");
                if (SoundVol1 != null) SoundVol1.setLabel("Volume");
                if (SoundVol2 != null) SoundVol2.setLabel("Volume");
                if (SoundVol3 != null) SoundVol3.setLabel("Volume");
                if (soundMechnic1 != null) soundMechnic1.setLabel("Mechanical");
                if (soundMechnic2 != null) soundMechnic2.setLabel("Mechanical");
                if (classic1 != null) classic1.setLabel("Classic");
                if (classic2 != null) classic2.setLabel("Classic");
                if (music1 != null) music1.setLabel("Music");
                if (music2 != null) music2.setLabel("Music");

                if (allPrizes != null) allPrizes.setText("ALL PRIZES SHOWN IN CREDITS");
                if (malfunction != null) malfunction.setText("MALFUNCTION VOIDS ALL PAYS AND PLAYS");
                if (malfunction != null) malfunction.setX(1370);

            } else if (changeLanguageCommand.getLanguageCode().equals("DE")) {
                if (czText != null) czText.setVisible(false);
                if (deText != null) deText.setVisible(true);
                if (LangSpecialSymbolFreeGames != null) LangSpecialSymbolFreeGames.setX(240);
                if (LangOnActiveLinePays != null) LangOnActiveLinePays.setText("auf einer aktiven Linie zahlt");
                if (LangTimesLineBet != null) LangTimesLineBet.setText("mal Einsatz pro Linie");

                if (Lang3OrMoreScattered != null) Lang3OrMoreScattered.setText("3 oder mehr SCATTER");
                if (LangTrigger10Free != null) LangTrigger10Free.setText("lösen 10 Freispiele\nmit Bonus-Symbol aus");

                if (LangOneSymbolIs != null)
                    LangOneSymbolIs.setText("Ein Symbol wird als Bonus-Symbol zufällig gewählt.\n" +
                            "Dieses nimmt alle Positionen auf der Walze ein\n" +
                            "und zahlt in beliebiger Position\n" +
                            "auf allen gespielten Linien");

                if (settingsTitle != null) settingsTitle.setText("SPRACHE");
                if (soundTitle != null) soundTitle.setText("TONAUSGABE");
                if (gamblerTitle != null) gamblerTitle.setText("RISIKOSPIEL");
                if (settingsQuite != null) settingsQuite.setLabel("Beenden");
                if (reelsSound != null) reelsSound.setText("WALZEN-SOUND");
                if (SoundVol1 != null) SoundVol1.setLabel("Lautstärke");
                if (SoundVol2 != null) SoundVol2.setLabel("Lautstärke");
                if (SoundVol3 != null) SoundVol3.setLabel("Lautstärke");
                if (soundMechnic1 != null) soundMechnic1.setLabel("Mechanisch");
                if (soundMechnic2 != null) soundMechnic2.setLabel("Mechanisch");
                if (classic1 != null) classic1.setLabel("Klassisch");
                if (classic2 != null) classic2.setLabel("Klassisch");
                if (music1 != null) music1.setLabel("Musik");
                if (music2 != null) music2.setLabel("Musik");

                if (allPrizes != null) allPrizes.setText("ALLE PREISE WERDEN IN KREDITEN ANGEZEIGT");
                if (malfunction != null) malfunction.setText("FEHLFUNKTION MACHT ALLE SPIELE UND ZAHLUNGEN UNGÜLTIG");
                if (malfunction != null) malfunction.setX(1250);
            } else if (changeLanguageCommand.getLanguageCode().equals("CS")) {
                if (czText != null) czText.setVisible(true);
                if (deText != null) deText.setVisible(false);
                if (LangSpecialSymbolFreeGames != null) LangSpecialSymbolFreeGames.setX(240);
                if (LangOnActiveLinePays != null) LangOnActiveLinePays.setText("3 nebo více SCATTER-symbolů");
                if (LangTimesLineBet != null) LangTimesLineBet.setText("krát sázku na linii");

                if (Lang3OrMoreScattered != null) Lang3OrMoreScattered.setText("times line bet");
                if (LangTrigger10Free != null) LangTrigger10Free.setText("spustí 10 Volných her\ns Bonus symbolem");

                if (LangOneSymbolIs != null)
                    LangOneSymbolIs.setText("Jeden symbol bude náhodně zvolen jako Bonus symbol,\n" +
                            "který se rozšíří na všechny pozice\n" +
                            "válce a platí na libovolných pozicích\n" +
                            "na všech hraných liniích");

                if (settingsTitle != null) settingsTitle.setText("JAZYK");
                if (soundTitle != null) soundTitle.setText("ZVUK");
                if (gamblerTitle != null) gamblerTitle.setText("HRA S RIZIKEM");
                if (settingsQuite != null) settingsQuite.setLabel("Ukončit");
                if (reelsSound != null) reelsSound.setText("ZVUK VÁLCŮ");
                if (SoundVol1 != null) SoundVol1.setLabel("Hlasitost");
                if (SoundVol2 != null) SoundVol2.setLabel("Hlasitost");
                if (SoundVol3 != null) SoundVol3.setLabel("Hlasitost");
                if (soundMechnic1 != null) soundMechnic1.setLabel("Mechanický");
                if (soundMechnic2 != null) soundMechnic2.setLabel("Mechanický");
                if (classic1 != null) classic1.setLabel("Klasický");
                if (classic2 != null) classic2.setLabel("Klasický");
                if (music1 != null) music1.setLabel("Hudba");
                if (music2 != null) music2.setLabel("Hudba");
                if (allPrizes != null) allPrizes.setText("VŠECHNY VÝHRY JSOU ZOBRAZENY V KREDITECH");
                if (malfunction != null) malfunction.setText("PORUCHA ZNEMOŽŇUJE VŠECHNY VÝPLATY A HRY");
                if (malfunction != null) malfunction.setX(1370);
            }

        }
    }

    public void languageChangeInit() {
        czText = getTextView("freeGamesBannerScreen", "endGame", "wrongText");
        deText = getTextView("infoScreen", "gamblerInfoScreen", "LangGamblerFeatureDescription2");
        LangSpecialSymbolFreeGames = getViewManager().findViewById("enterFeatureBannerScreen", "LangSpecialSymbolFreeGames");


        LangOnActiveLinePays = getViewManager().findViewById("payTableScreen", "LangOnActiveLinePays");
        LangTimesLineBet = getViewManager().findViewById("payTableScreen", "LangTimesLineBet");

        Lang3OrMoreScattered = getViewManager().findViewById("payTableScreen", "Lang3OrMoreScattered");
        LangTrigger10Free = getViewManager().findViewById("payTableScreen", "LangTrigger10Free");

        LangOneSymbolIs = getViewManager().findViewById("payTableScreen", "LangOneSymbolIs");

        //controll panel
        ViewGroup vg1 = getViewManager().findViewById("settingsScreen", "group1");
        ViewGroup vg2 = getViewManager().findViewById(vg1, "languageTab");
        ViewGroup vg3 = getViewManager().findViewById(vg2, "languageButtons");
        settingsTitle = getViewManager().findViewById(vg3, "title1");

        vg2 = getViewManager().findViewById(vg1, "soundTab");
        vg3 = getViewManager().findViewById(vg2, "soundButtons");
        soundTitle = getViewManager().findViewById(vg3, "title2");

        vg2 = getViewManager().findViewById(vg1, "gamblerTab");
        vg3 = getViewManager().findViewById(vg2, "gamblerButtons");
        gamblerTitle = GameEngine.current().getViewManager().findViewById(vg3, "title3");

        vg2 = getViewManager().findViewById(vg1, "soundTab");
        reelsSound = getViewManager().findViewById(vg2, "reelsSoundText");

        settingsQuite = getViewManager().findViewById("settingsScreen", "settingsQuite");

        vg2 = getViewManager().findViewById(vg1, "soundTab");
        vg3 = getViewManager().findViewById(vg2, "soundButtons");
        SoundVol1 = getViewManager().findViewById(vg3, "vol1");
        SoundVol2 = getViewManager().findViewById(vg3, "vol2");
        SoundVol3 = getViewManager().findViewById(vg3, "vol3");

        soundMechnic1 = getViewManager().findViewById(vg3, "mechanic1");
        soundMechnic2 = getViewManager().findViewById(vg3, "mechanic2");

        music1 = getViewManager().findViewById(vg3, "music1");
        music2 = getViewManager().findViewById(vg3, "music2");

        classic1 = getViewManager().findViewById(vg3, "classic1");
        classic2 = getViewManager().findViewById(vg3, "classic2");

        View sidePanel = getViewManager().findViewById("bottomPanelScreen", "linesSidePanel");
        View linesSide = getViewManager().findViewById(sidePanel, "linesSidePanelMainButton");
        LinesText = getViewManager().findViewById(linesSide, "textLines");

        View denomGroup = getViewManager().findViewById("denominationScreen", "denomId");
        denomText = getViewManager().findViewById(denomGroup, "denomText");

        sidePanelBetShadow = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "betsSidePanelDragButton"), "sidePanelBetShadow");
        sidePanelBet = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "betsSidePanelDragButton"), "sidePanelBet");
        betMainButtonText = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "betsSidePanelMainButton"), "betMainButtonText");
        myBetText = getViewManager().findViewById(getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "mainID"), "myBet"), "myBetText");

        sidePanelLineShadow = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "linesSidePanelDragButton"), "sidePanelLineShadow");
        sidePanelLine = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "linesSidePanelDragButton"), "sidePanelLine");

        ViewGroup liveglass_info = getViewManager().findViewById("payTableScreen", "liveglass_info");
        allPrizes = getViewManager().findViewById(liveglass_info, "allPrizes");
        malfunction = getViewManager().findViewById(liveglass_info, "malfunction");
    }

    private TextView getTextView(String layOutId, String groupViewIdm, String textViewId) {
        ViewGroup gamblerInfoScreen = GameEngine.current().getViewManager().findViewById(layOutId, groupViewIdm);

        for (View text : gamblerInfoScreen.getChildren()) {
            if (text.getId() != null && text.getId().equals(textViewId)) {
                return (TextView) text;
            }
        }
        return null;
    }

    public static IFreeGamesModelProvider getFreeGamesModelProvider() {
        return freeGamesModelProvider;
    }

    public static void setFreeGamesModelProvider(IFreeGamesModelProvider freeGamesModelProvider) {
        EyeOfDragonAndBallBaseGameScreen.freeGamesModelProvider = freeGamesModelProvider;
    }

    public static IExtendedSymbolModelProvider getExtendedSymbolModelProvider() {
        return extendedSymbolModelProvider;
    }

    public static void setExtendedSymbolModelProvider(IExtendedSymbolModelProvider extendedSymbolModelProvider) {
        EyeOfDragonAndBallBaseGameScreen.extendedSymbolModelProvider = extendedSymbolModelProvider;
    }

/*    public static int getStoppedReels() {
        return stoppedReels;
    }

    public static void setStoppedReels(int stoppedReels) {
        EyeOfDragonAndBallBaseGameScreen.stoppedReels = stoppedReels;
    }*/

    //    LANGUAGE CHANGE
    private TextView languageButton;
    private TextView czText;
    private TextView deText;

    private TextView LangSpecialSymbolFreeGames;
    private TextView LangOnActiveLinePays;
    private TextView LangTimesLineBet;

    private TextView Lang3OrMoreScattered;
    private TextView LangTrigger10Free;

    private TextView LangOneSymbolIs;


    private TextView settingsTitle;
    private TextView soundTitle;
    private TextView gamblerTitle;

    private TextView reelsSound;

    private ButtonView settingsQuite;

    private ButtonView SoundVol1;
    private ButtonView SoundVol2;
    private ButtonView SoundVol3;

    private ButtonView soundMechnic1;
    private ButtonView soundMechnic2;

    private ButtonView music1;
    private ButtonView music2;
    private ButtonView classic1;
    private ButtonView classic2;

    private TextView LinesText;
    private TextView denomText;

    private TextView sidePanelBetShadow;
    private TextView sidePanelBet;
    private TextView betMainButtonText;
    private TextView myBetText;
    private TextView sidePanelLineShadow;
    private TextView sidePanelLine;
    private TextView allPrizes;
    private TextView malfunction;

    private class InitResultObserver extends NextObserver<InitResult> {

        @Override
        public void onNext(InitResult initResult) {
            System.out.println();
        }
    }

//    private static int stoppedReels = 0;
}