package com.octavianonline.games.eyeOfDragonAndBall.screen;

import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.SpinCommand;
import com.atsisa.gox.reels.event.*;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.WinLinesScreen;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.gwtent.reflection.client.annotations.Reflect_Full;
import com.octavianonline.games.eyeOfDragonAndBall.event.HideWinLinesEvent;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.ExtendedSymbolStatic;
import com.octavianonline.games.eyeOfDragonAndBall.helpers.AniliseSymbolsForBlinking;
import com.octavianonline.games.eyeOfDragonAndBall.screen.model.QueenCleopatraPayTableScreenModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the Pay table screen.
 */
@Reflect_Full
public class EyeOfDragonAndBallPaytableScreen extends InfoScreen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String QUEEN_CLEOPATRA_PAYTABLE_LAYOUT_ID_PROPERTY = "QueenCleopatraPayTableScreen";

    /**
     * Pay table feature screen visible.
     */
    private static final String PAY_TABLE_FEATURE_SCREEN_VISIBLE = "payTableFeatureScreenVisible";

    /**
     * Pay table base game screen visible.
     */
    private static final String PAY_TABLE_BASE_GAME_SCREEN_VISIBLE = "payTableBaseGameScreenVisible";

    /**
     * Fourth scatter symbol visible.
     */
    private static final String TWO_SCATTER_PAYS_VISIBLE = "twoScatterPaysVisible";

    /**
     * Inject View of the extended symbol.
     */
    @InjectView
    public ViewGroup extendedSymbolGroup;


    /**
     * To get the logo animation object
     */
    private final String LAYOUT_ID_FOR_LOGO = "payTableBgrScreen";
    private final String KEY_FRAME_ANIMATION_VIEW_ID_FOR_UPPER_LOGO = "logoAnimation";

    /**
     * For logo animation object
     */
    private KeyframeAnimationView logoAnimation;

    public static final String LAYOUT_ID_PROPERTY = "PaytableScreenLayoutId";

    static IFreeGamesModel freeGamesModel;

    /**
     * Screen saver image
     */
    private ImageView shinebar2;

    /**
     * Animation for screen saver
     */
    private TweenViewAnimation tweenViewAnimation;
    private Timeout timeout;

    private boolean canPlayScreenSaverLine = false;
    private int betIndex;
    WinLinesScreen winLinesScreen;
    Timeout hide50LinesTimeOut;
    private List<LineShapeView> lineShapeViewList = new ArrayList<>();

    /**
     * Initializes a new instance of the {@link EyeOfDragonAndBallPaytableScreen} class.
     *
     * @param layoutId             layout identifier
     * @param model                {@link PayTableScreenModel}
     * @param renderer             {@link IRenderer}
     * @param viewManager          {@link IViewManager}
     * @param animationFactory     {@link IAnimationFactory}
     * @param logger               {@link ILogger}
     * @param eventBus             {@link IEventBus}
     * @param infoScreenTransition {@link InfoScreenTransition}
     */
    @Inject
    public EyeOfDragonAndBallPaytableScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, PayTableScreenModel model, IRenderer renderer, IViewManager viewManager,
                                            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, InfoScreenTransition infoScreenTransition) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);
        this.winLinesScreen = winLinesScreen;
    }



    private class HideAllWinLines extends NextObserver<HideWinLinesEvent> {

        @Override
        public void onNext(HideWinLinesEvent hideWinLinesEvent) {
            if(hide50LinesTimeOut!=null && !hide50LinesTimeOut.isCleaned()){
                hide50LinesTimeOut.clear();
            }
/*            lineShapeViewList.stream().forEach(line -> {
                if (line.getAlpha() != 0) {
                    line.setAlpha(0);
                }
            });*/
            GameEngine.current().getViewManager().getLayout("winLinesScreen").getRootView().setVisible(false);
        }
    }


    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new PayTableModelChangedEventObserver(), PayTableModelChangedEvent.class);
        getEventBus().register(new ExtendedSymbolModelChangedEventObserver(), ExtendedSymbolModelChangedEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
        getEventBus().register(new PresentationStateChangedEventObserver(), PresentationStateChangedEvent.class);
        betIndex = ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider().getBetModel().getSelectedBetIndex();
    }

    private class ExtendedSymbolModelChangedEventObserver extends NextObserver<ExtendedSymbolModelChangedEvent> {

        @Override
        public void onNext(final ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
            handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);
        }
    }

    /**
     * Handles pay table values changed.
     *
     * @param event event with changed values
     */
    @Subscribe
    public void handlePayTableModelChangedEvent(PayTableModelChangedEvent event) {
        ((PayTableScreenModel) getModel()).updatePayTableValues(event.getValues());
    }

    /**
     * Updates pay table with received scatter amount, updates Scatter symbol on pay table.
     */
    @Subscribe
    public void handleExtendedSymbolModelChangedEvent(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
        IExtendedSymbolModel extendedSymbolModel = extendedSymbolModelChangedEvent.getExtendedSymbolModel();
        if (extendedSymbolModel != null && extendedSymbolModel.getExtendedSymbolPayTableItems() != null) {
            Iterable<IPayTableModelItem> symbols = extendedSymbolModel.getExtendedSymbolPayTableItems();
            if (Iterables.size(extendedSymbolModel.getExtendedSymbolPayTableItems()) > 3) {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.TRUE);
            } else {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
            }
            ((QueenCleopatraPayTableScreenModel) getModel()).updateExtendedSymbols(symbols);
            updateFeatureInfo(extendedSymbolModel.getExtendedSymbolName());
            showFeatureInfo();
        } else {
            hideFeatureInfo();
        }
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        hideFeatureInfo();

/*        ILayout layout = getLayout();
        ViewGroup viewGroup = (ViewGroup) layout.getRootView();*//*

//        ViewGroup viewGroup2 = (ViewGroup) GameEngine.current().getViewManager().getLayout("Line1Screen").getRootView();
        ViewGroup viewGroup2 = (ViewGroup) GameEngine.current().getViewManager().getLayout("Line1Screen").getRootView();

        ImageView lineImageView = new ImageView();
//        lineImageView.setId("line_tex");

        //get Image from resource
        IImageReference imageReference = GameEngine.current().getResourceManager().getResource("image.png");

        //get Image from SpriteSheet
        ((SpriteSheetResource)GameEngine.current().getResourceManager().getResource("bigWin")).getChildResource("Awesome_Win")

        lineImageView.setImage(imageReference);
//        viewGroup.addChild(lineImageView);
        System.err.println();*/
    }

    @Override
    protected void afterActivated() {
        lineShapeViewList.addAll(GameEngine.current().getViewManager().findViewByType("winLinesScreen",LineShapeView.class));
//        System.err.println(System.nanoTime()/ 1000000000);
//        kf = getViewManager().findViewById("payTableScreen", "1811");
        shinebar2 = (ImageView) findViewById("shinebar2");
        shinebar2.setVisible(false);
//        getEventBus().register(new ShowAllWinLines(), BetModelChangedEvent.class);
//        getEventBus().register(new HideAllWinLines(), HideWinLinesEvent.class);
        if (!StringUtility.isNullOrEmpty(ExtendedSymbolStatic.extendedSymbolName)) {
            updateFeatureInfo(ExtendedSymbolStatic.extendedSymbolName);
        } else {
            hideFeatureInfo();
        }


        //Initialize the mechanism of blinking texts on the upper screen
        new AniliseSymbolsForBlinking(getEventBus());


/*
        ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        reelGroupView.getReel(5).spin();
        reelGroupView.setSpinSequenceProvider(new ReelDelayedSequenceProvider(new ArrayList<Integer>(){{add(0);add(100);add(0);add(0);add(0);}}));
        reelGroupView.setStopOnSymbolsSequenceProvider(new ReelDelayedSequenceProvider(new ArrayList<Integer>(){{add(-100);add(100);add(100);add(100);add(100);}}));
*/

//        ParticleView p = findViewById("13qwe");
//        FrameParticleView p = findViewById("13qwe");

/*
        p.setEndScale(1.1f);
        p.setHeight(500);
        p.setMaxAngle(30);
        p.setMaxParticleLifetime(30);
        p.setMaxParticles(100);
        p.setWidth(500);
        p.setYOffset(3.5f);
        p.setRotation(1.5f);
        p.setEndingSpeed(1);
        p.setEndingSpeed(100);
        p.start();*/

        //Calling the method for logo animation
        logoAnimation();

        new Timeout(1000, new TempTimeout(), true);

        super.afterActivated();
    }

    /**
     * Updates extended info visibility depending on the extended symbol name.
     *
     * @param extendedSymbolName the extended symbol name.
     */
    private void updateFeatureInfo(String extendedSymbolName) {
        ExtendedSymbolStatic.extendedSymbolName = extendedSymbolName;
        if (extendedSymbolGroup == null) {
            return;
        }
        for (View view : extendedSymbolGroup.getChildren()) {
            if (view.getId().contains(ExtendedSymbolStatic.extendedSymbolName)) {
                view.setVisible(true);
            } else {
                view.setVisible(false);
            }
        }
    }

    /**
     * Shows feature screen.
     */
    private void showFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.TRUE);
    }

    /**
     * Hides feature screen.
     */
    private void hideFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.TRUE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
    }

    private class PayTableModelChangedEventObserver extends NextObserver<PayTableModelChangedEvent> {

        @Override
        public void onNext(final PayTableModelChangedEvent payTableModelChangedEvent) {
            handlePayTableModelChangedEvent(payTableModelChangedEvent);
        }
    }

    /**
     * Animation of the logo on the upper screen every 5 seconds
     */
    public void logoAnimation() {

        logoAnimation = getViewManager().findViewById("payTableScreen", KEY_FRAME_ANIMATION_VIEW_ID_FOR_UPPER_LOGO);
        /**
         *local class for start playing logo animation
         */


        TimeoutCallback timeOutLogoAnimation = () -> {
            logoAnimation.gotoAndPlay(1);
//            kf.setTest("go");
        };

        new Timeout(0, timeOutLogoAnimation, true).start();

        //Call every 5 seconds playing the logo
        logoAnimation.addPropertyChangedListener((view, viewType, i) -> {
            if (!logoAnimation.isPlaying()) {
//                GameEngine.current().getActionManager().processAction(new HideWinningLinesAction());
                new Timeout(5000, timeOutLogoAnimation, true).start();

            }
        });

    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            freeGamesModel = freeGamesModelChangedEvent.getFreeGamesModel();
            System.out.println();

        }
    }

    private class PresentationStateChangedEventObserver extends NextObserver<PresentationStateChangedEvent> {
        @Override
        public void onNext(final PresentationStateChangedEvent presentationStateChangedEvent) {
            if (timeout != null) {
                timeout.clear();
            }
            if (!canPlayScreenSaverLine && presentationStateChangedEvent.getStateName().equals("RunningReels")) {
                canPlayScreenSaverLine = true;
            }

            if (presentationStateChangedEvent.getStateName().equals("Idle") && canPlayScreenSaverLine) {
                timeout = new Timeout(30000, new StartPlayScreenSaver(), true);
            } else {
                stopScreenSaverLine();
            }
        }
    }

    private void stopScreenSaverLine() {
        if (shinebar2 != null) {
            shinebar2.setVisible(false);
        }
    }


    /**
     * Start playing first video for screen saver
     */
    class StartPlayScreenSaver implements TimeoutCallback {
        @Override
        public void onTimeout() {
            shinebar2.setY(2900);
            shinebar2.setVisible(true);
            tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
            TweenViewAnimationData tweenViewAnimationData = new TweenViewAnimationData();
            tweenViewAnimationData.setDestinationY(-1450f);
            tweenViewAnimationData.setTimeSpan(4000);
            tweenViewAnimation.setViewAnimationData(tweenViewAnimationData);
            tweenViewAnimation.setTargetView(shinebar2);
            tweenViewAnimation.play();
        }
    }

    /**
     * Called when spin should be invoked.
     */
    @ExposeMethod
    public void spin() {
        getEventBus().post(new SpinCommand());
    }

//Win Lines image show and hide
    /**
     * for show custom 5 lines on the screen and set alpha 0 to the drawn lines
     */
/*    private class ShowAllWinLines extends NextObserver<BetModelChangedEvent> {

        @Override
        public void onNext(BetModelChangedEvent betModelChangedEvent) {
            GameEngine.current().getViewManager().getLayout("winLinesScreen").getRootView().setVisible(true);
            if (betIndex != betModelChangedEvent.getBetModel().getSelectedBetIndex()) {
                betIndex = betModelChangedEvent.getBetModel().getSelectedBetIndex();

                if(hide50LinesTimeOut!=null){
                    hide50LinesTimeOut.clear();
                }
                hide50LinesTimeOut = new Timeout(15000, ()->{
                    getEventBus().post(new HideWinLinesEvent());
                },true);

*//*                lineShapeViewList.stream().forEach(line -> {
                    if (line.getAlpha() != 1) {
                        line.setAlpha(1);
                    }
                });*//*
            }

        }
    }*/

    class TempTimeout implements TimeoutCallback{

        @Override
        public void onTimeout() {
            System.out.println();
            new Timeout(1000,new TempTimeout(),true);
        }
    }

}
