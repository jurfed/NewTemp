package com.octavianonline.games.eyeOfDragonAndBall.event;

public class VolumeChangedEvent {

    /**
     * Volume value.
     */
    private int volume;

    /**
     * Initializes a new instance of the {@link VolumeChangedEvent} class.
     * @param volume int
     */
    public VolumeChangedEvent(int volume) {
        this.volume = volume;
    }

    /**
     * Gets volume value.
     * @return int
     */
    public int getVolume(){
        return volume;
    }

}
