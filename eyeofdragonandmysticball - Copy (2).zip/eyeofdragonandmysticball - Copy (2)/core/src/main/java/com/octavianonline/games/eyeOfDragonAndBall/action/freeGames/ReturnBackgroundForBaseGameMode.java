package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.reels.view.ReelGroupView;

public class ReturnBackgroundForBaseGameMode extends Action {
    /**
     * Array of background images for reels
     */
    private ImageView[] backgroundReels = new ImageView[10];

    @Override
    protected void execute() {

        ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        for(int i=0; i< 5; i++){
            for(int j=0; j<3; j++){
                reelGroupView.getReel(i).getDisplayedSymbol(j).setState("IDLE");
            }
        }

        //initBackgroundReels();
        //hideBackFreeGamesGround();
        finish();
    }

    /**
     * Initializing an array of background images for reels
     */
    private void initBackgroundReels() {
        for (int i = 0; i < backgroundReels.length; i++) {
            backgroundReels[i] = GameEngine.current().getViewManager().findViewById("reel_bg", i + "");
        }
    }


    private void hideBackFreeGamesGround(){
        for (int i = 0; i < 5; i++)
            backgroundReels[i].setVisible(false);
        for (int j = 5; j < backgroundReels.length; j++)
            backgroundReels[j].setVisible(true);
    }
}
