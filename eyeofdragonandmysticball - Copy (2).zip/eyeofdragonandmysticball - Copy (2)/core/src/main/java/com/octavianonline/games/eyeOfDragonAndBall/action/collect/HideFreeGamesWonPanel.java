package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.games.octavian.core.view.particle.OctavianParticleView;

import java.util.ArrayList;
import java.util.List;

public class HideFreeGamesWonPanel extends Action {
//    IViewManager viewManager;
    private List<OctavianParticleView> particles = new ArrayList<>();
    @Override
    protected void execute() {
        particles = new ArrayList<>();
        Iterable<View> views=((ViewGroup)GameEngine.current().getViewManager().findViewById("payTableScreen","Mega")).getChildren();
        views.forEach(view->{
            if(view instanceof OctavianParticleView){
                particles.add((OctavianParticleView) view);
                ((OctavianParticleView) view).setActiveGravityTimeLines(true);
                ((OctavianParticleView) view).setActiveVelocityTimeLines(true);
                ((OctavianParticleView) view).start();
            }
        });


/*        viewManager = GameEngine.current().getViewManager();

        View wonPanel = viewManager.findViewById("freeGamesBannerScreen", "you_won_plate");
        if (wonPanel != null && wonPanel.isVisible()) {
            wonPanel.setVisible(false);
            viewManager.findViewById("freeGamesBannerScreen", "LangFeatureWin").setVisible(false);
            viewManager.findViewById("freeGamesBannerScreen", "currentFreeGamesNumber").setVisible(false);
            viewManager.findViewById("freeGamesBannerScreen", "wrongText").setVisible(false);
        }*/
        finish();

    }
}
