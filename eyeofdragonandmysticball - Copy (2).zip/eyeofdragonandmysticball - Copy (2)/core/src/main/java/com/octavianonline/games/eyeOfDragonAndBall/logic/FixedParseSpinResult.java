package com.octavianonline.games.eyeOfDragonAndBall.logic;

import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.ReelsPresentation;
import com.atsisa.gox.logic.SpinRequest;
import com.atsisa.gox.logic.SpinResult;
import com.atsisa.gox.reels.backend.IStep;
import com.atsisa.gox.reels.backend.adapter.ReelConverter;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;

import java.util.Map;
import java.util.Optional;

public class FixedParseSpinResult implements IStep {
    private final SpinResult spinResult;
    private final SpinRequest spinRequest;
    private final ReelConverter reelConverter = new ReelConverter();
    private final FixedWinConverter winConverter = new FixedWinConverter();
    private final Map<Integer, String> winSounds;
    private final Map<Integer, String> winAnimations;
    private final Map<Integer, String> reelStripStopSounds;

    public FixedParseSpinResult(SpinResult spinResult, SpinRequest spinRequest, Map<Integer, String> winSounds, Map<Integer, String> winAnimations, Map<Integer, String> reelStripStopSounds) {
        this.spinResult = spinResult;
        this.spinRequest = spinRequest;
        this.winSounds = winSounds;
        this.winAnimations = winAnimations;
        this.reelStripStopSounds = reelStripStopSounds;
    }

    public Map<String, Object> execute(Map<String, Object> logicPresentationMap) throws GameLogicException {
        ReelGamePresentation reelGamePresentation = new ReelGamePresentation(this.spinResult.getPresentation().getName(), new GameplayProperties(this.spinRequest.getLines(), this.spinRequest.getBet(), this.spinResult.getBalance()), this.reelConverter.convert(this.spinResult.getStopSymbols(), this.reelStripStopSounds), false, false);
        logicPresentationMap.put(ReelGamePresentation.class.getName(), reelGamePresentation);
        if (this.spinResult.getBank().getWinAmount() != 0L) {
            Optional<Map<String, Object>> features = this.spinResult.getFeatures();
            if (!features.isPresent()) {
                throw new GameLogicException("The spin result features list is empty.");
            }

            WinningPresentation winningPresentation = new WinningPresentation(ReelsPresentation.BASE_GAME_WIN.getName(), this.spinResult.getBank().getWinAmount(), this.winConverter.convertWinningLines(this.spinResult.getWinningLines(), this.spinResult.getStopSymbols().size(), this.winSounds, this.winAnimations), "", false, false);
            logicPresentationMap.put(WinningPresentation.class.getName(), winningPresentation);
        }

        return logicPresentationMap;
    }
}
