package com.octavianonline.games.eyeOfDragonAndBall.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to highlight feature special scatter symbol
 */
@Reflectable
public class HighlightSelectedExtendedSymbolCommand {

}
