package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class HideBgrFreeGames extends Action {

    @Override
    protected void execute() {
        GameEngine.current().getViewManager().findViewById("payTableBgrScreen", "bgr_fg").setVisible(false);
        finish();
    }
}
