package com.octavianonline.games.eyeOfDragonAndBall.action.reelsSpeen;

import com.atsisa.gox.framework.action.Action;

public class ResetStoppedReels extends Action{
    @Override
    protected void execute() {
//        EyeOfDragonAndBallBaseGameScreen.setStoppedReels(0);
        finish();
    }
}
