package com.octavianonline.games.eyeOfDragonAndBall.screen;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;

import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.ButtonView;
import com.atsisa.gox.reels.model.IDebugDataModelProvider;
import com.atsisa.gox.reels.screen.DebugScreen;
import com.atsisa.gox.reels.screen.model.DebugScreenModel;
import com.octavianonline.games.eyeOfDragonAndBall.action.bigwin.ExecuteNextDependingOnBigWin;

import javax.inject.Inject;
import javax.inject.Named;

public class EyeOfDragonAndBallDebugScreen extends DebugScreen {

    public static final String LAYOUT_ID_PROPERTY = "DebugScreenLayoutId";

    /**
     * Initializes a new instance of the {@link DebugScreen} class.
     *
     * @param layoutId               layout identifier
     * @param model                  the model that extends the debug screen model
     * @param renderer               {@link IRenderer}
     * @param viewManager            {@link IViewManager}
     * @param animationFactory       {@link IAnimationFactory}
     * @param logger                 {@link ILogger}
     * @param eventBus               {@link IEventBus}
     * @param debugDataModelProvider
     */
    @Inject
    public EyeOfDragonAndBallDebugScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, DebugScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IDebugDataModelProvider debugDataModelProvider) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, debugDataModelProvider);
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
    }

    @ExposeMethod
    public void bigWinOnOff() {
        ButtonView BigWinButton = GameEngine.current().getViewManager().findViewById("debugScreen", "bigWinOnOff");
        if (BigWinButton.getLabel().equals("Big Wins on")) {
            BigWinButton.setLabel("Big Wins off");
            ExecuteNextDependingOnBigWin.setBigwinOnOff(false);
        } else {
            BigWinButton.setLabel("Big Wins on");
            ExecuteNextDependingOnBigWin.setBigwinOnOff(true);
        }

      //  OBetModelProvider g = (OBetModelProvider) ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider();
       // ((OBetModel)g.getBetModel()).setBetSteps(new ArrayList(){{add(11L);add(12L); add(13L);}});
    }


}