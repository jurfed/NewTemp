package com.octavianonline.games.eyeOfDragonAndBall.action.helpers.data;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class CustomShowHideScreenData extends ActionData {
    @XmlAttribute
    private boolean showScreen;
    @XmlAttribute
    private float animationTime;
    @XmlAttribute
    private String screenId;

    public boolean getShowScreen() {
        return showScreen;
    }

    public void setShowScreen(boolean showScreen) {
        this.showScreen = showScreen;
    }



    public float getAnimationTime() {
        return animationTime;
    }

    public void setAnimationTime(float animationTime) {
        this.animationTime = animationTime;
    }



    public String getScreenId() {
        return screenId;
    }

    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }


}
