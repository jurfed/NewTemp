package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.ExecuteNextAction;

public class SkipCollectAction extends ExecuteNextAction {

    private long startSoundCollectSystemTime;

    @Override
    protected void execute() {
        allowFurtherProcessing();

        long playSoundTime;
        startSoundCollectSystemTime = System.currentTimeMillis();
        playSoundTime = startSoundCollectSystemTime - FinishCollect.getBeginTime();//time spent

        if (FinishCollect.getCollectTime() > playSoundTime) {
            finish();
        }else{
                 cancelFurtherProcessing();
                 super.execute();
        }

        // if (!QueenCleopatraSettingsScreen.getGambleOn()) {
        //     cancelFurtherProcessing();
        //     super.execute();
        // } else {
//        finish();

    }

}
