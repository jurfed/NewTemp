package com.octavianonline.games.eyeOfDragonAndBall.screen;


import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.IPauseable;
import com.atsisa.gox.framework.model.IResetable;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.IViewPropertyChangedListener;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.gwtent.reflection.client.Reflectable;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.Bookpause;
import com.octavianonline.games.eyeOfDragonAndBall.command.HideSelectedExtendedSymbolCommand;
import com.octavianonline.games.eyeOfDragonAndBall.command.HighlightSelectedExtendedSymbolCommand;
import com.octavianonline.games.eyeOfDragonAndBall.command.ShowSelectedExtendedSymbolCommand;
import com.octavianonline.games.eyeOfDragonAndBall.command.StartSelectingExtendedSymbolAnimationCommand;
import com.octavianonline.games.eyeOfDragonAndBall.event.HiddenExtendedSymbolEvent;
import com.octavianonline.games.eyeOfDragonAndBall.event.HighlightedExtendedSymbolEvent;
import com.octavianonline.games.eyeOfDragonAndBall.event.ShownExtendedSymbolEvent;
import com.octavianonline.games.eyeOfDragonAndBall.screen.model.QueenCleopatraFeatureScreenModel;
import rx.Subscription;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashMap;
import java.util.Map;

@Reflectable
public class EyeOfDragonAndBallEnterFeatureBannerScreen extends Screen<QueenCleopatraFeatureScreenModel> implements IResetable, IPauseable {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "EnterFeatureBannerScreenLayoutId";

    /**
     * Frame number when book is shown and closed.
     */
    private static final int CLOSED_BOOK_ANIMATION_FRAME = 7;

    /**
     * Last flipping pages frame number
     */
    private static final int LAST_FLIPPING_PAGES_FRAME = 99;

    /**
     * Start closing book animation frame number
     */
    private static final int START_CLOSING_BOOK_ANIMATION_FRAME = 100;

    /**
     * Mapping of symbols frames in a book animation
     */
    private Map<String, Integer> symbolFrames;

    /**
     * Mapping of two previous symbols frames in a book animation for slowdown animation
     */
    private Map<String, Integer> twoPreviousSymbolFrames;

    /**
     * Property changed listener for slowdown book animation
     */
    private SelectingExtendedSymbolAnimationListener selectingExtendedSymbolAnimationListener;


    private String symbolName;

    /**
     * The first character in the book
     */
    private static final String firstSymbolName="cleopatra";


    /**
     * Book select extended symbol animation
     */
    @InjectView
    public KeyframeAnimationView selectingExtendedSymbolAnimation;

    /**
     * Book select extended symbol glow animation
     */
    @InjectView
    public KeyframeAnimationView selectingExtendedSymbolGlowAnimation;

    /**
     * Subscription for selecting extended symbol animation
     */
    private Subscription selectingExtendedSymbolAnimationSubscription;

    /**
     * Subscription for selecting extended symbol glow animation
     */
    private Subscription selectingExtendedSymbolGlowAnimationSubscription;

    /**
     * Determines if selecting extended symbol animation was played
     */
    private boolean animationPlayed = false;

    /**
     * Initializes a new instance of the {@link EyeOfDragonAndBallEnterFeatureBannerScreen} class.
     *
     * @param layoutId         layout identifier
     * @param model            {@link QueenCleopatraFeatureScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public EyeOfDragonAndBallEnterFeatureBannerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, QueenCleopatraFeatureScreenModel model, IRenderer renderer,
                                                      IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        setupSymbolFramesMap();
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ExtendedSymbolModelChangedEventObserver(), ExtendedSymbolModelChangedEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
        getEventBus().register(new StartSelectingExtendedSymbolAnimationCommandObserver(), StartSelectingExtendedSymbolAnimationCommand.class);
        getEventBus().register(new ShowSelectedExtendedSymbolCommandObserver(), ShowSelectedExtendedSymbolCommand.class);
        getEventBus().register(new HideSelectedExtendedSymbolCommandObserver(), HideSelectedExtendedSymbolCommand.class);
        getEventBus().register(new HighlightSelectedExtendedSymbolCommandObserver(), HighlightSelectedExtendedSymbolCommand.class);
        //getEventBus().register(new SpinReelsCommandObserver(),SpinReelsCommand.class);
    }

    /**
     * Handles the event about free games model was changed.
     *
     * @param event {@link FreeGamesModelChangedEvent}
     */
    @Subscribe
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent event) {
        getModel().setTotalFreeGamesNumber(event.getFreeGamesModel().getTotalFreeGamesNumber());
    }

    /**
     * Handles the command that starts the animation of the book.
     *
     * @param startSelectingExtendedSymbolAnimationCommand {@link StartSelectingExtendedSymbolAnimationCommand}
     */
    @Subscribe
    public void handleStartSelectingExtendedSymbolAnimationCommand(StartSelectingExtendedSymbolAnimationCommand startSelectingExtendedSymbolAnimationCommand) {
        startBookScatterAnimation();
    }

    /**
     * Handles the command that animation of the book should be stopped on the selected symbol.
     *
     * @param showSelectedExtendedSymbolCommand {@link ShowSelectedExtendedSymbolCommand}
     */
    @Subscribe
    public void handleShowSelectedExtendedSymbolCommand(ShowSelectedExtendedSymbolCommand showSelectedExtendedSymbolCommand) {
        selectFeatureSpecialScatterSymbol();
    }

    /**
     * Handles the command to highlight selected extended scatter symbol.
     *
     * @param highlightSelectedExtendedSymbolCommand
     */
    public void handleHighlightSelectedExtendedSymbolCommand(HighlightSelectedExtendedSymbolCommand highlightSelectedExtendedSymbolCommand) {
        selectingExtendedSymbolGlowAnimationSubscription = selectingExtendedSymbolGlowAnimation.getAnimationStateObservable().subscribe(animationGlowState -> {
            if (animationGlowState == AnimationState.STOPPED) {
                getEventBus().post(new HighlightedExtendedSymbolEvent());
            }
        });
        selectingExtendedSymbolGlowAnimation.play();
    }

    /**
     * Handles the event about extended symbol model was changed.
     *
     * @param extendedSymbolModelChangedEvent {@link ExtendedSymbolModelChangedEvent}
     */
    @Subscribe
    public void handleExtendedSymbolModelChangedEvent(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
        getModel().setExtendedSymbolName(extendedSymbolModelChangedEvent.getExtendedSymbolModel().getExtendedSymbolName());
    }

    /**
     * Handles the command that book animation should be hidden
     *
     * @param hideSelectedExtendedSymbolCommand {@link HideSelectedExtendedSymbolCommand}
     */
    @Subscribe
    public void handleHideSelectedExtendedSymbolCommand(HideSelectedExtendedSymbolCommand hideSelectedExtendedSymbolCommand) {
        hideFeatureScatterSymbol();
    }

    /**
     * Starts the book animation.
     */
    @ExposeMethod
    public void startBookScatterAnimation() {
        if (!animationPlayed) {
            selectingExtendedSymbolAnimation.setLoop(true);
            selectingExtendedSymbolAnimation.setEndLoopFrameNumber(LAST_FLIPPING_PAGES_FRAME);
            selectingExtendedSymbolAnimation.play();
            animationPlayed = true;
        }
    }

    /**
     * Hides the book animation.
     */
    @ExposeMethod
    public void hideFeatureScatterSymbol() {
        if (selectingExtendedSymbolAnimation != null) {
            clearAnimationSubscription();
            selectingExtendedSymbolAnimation.setEndLoopFrameNumber(0);
            selectingExtendedSymbolAnimation.gotoAndPlay(START_CLOSING_BOOK_ANIMATION_FRAME);
            selectingExtendedSymbolAnimationSubscription = selectingExtendedSymbolAnimation.getAnimationStateObservable().subscribe(animationState -> {
                if (animationState == AnimationState.STOPPED) {
                    this.getEventBus().post(new HiddenExtendedSymbolEvent());
                    reset();
                }
            });
        }
    }

    @Override
    @ExposeMethod
    public void pause() {
        clearAnimationSubscription();
        if (selectingExtendedSymbolAnimation != null && selectingExtendedSymbolAnimation.isPlaying()) {
            selectingExtendedSymbolAnimation.pause();
        }
        if (selectingExtendedSymbolGlowAnimation != null && selectingExtendedSymbolGlowAnimation.isPlaying()) {
            selectingExtendedSymbolGlowAnimation.pause();
        }
    }

    @Override
    @ExposeMethod
    public void reset() {
        clearAnimationSubscription();
        selectingExtendedSymbolAnimation.gotoAndPause(1);
        selectingExtendedSymbolAnimation.setLoop(true);
        selectingExtendedSymbolAnimation.setEndLoopFrameNumber(LAST_FLIPPING_PAGES_FRAME);
        selectingExtendedSymbolGlowAnimation.gotoAndPause(1);
        animationPlayed = false;
    }

    @Override
    protected void notifyScreenShown(Object sourceEvent) {
        super.notifyScreenShown(sourceEvent);
        selectingExtendedSymbolAnimation.playToAndPause(CLOSED_BOOK_ANIMATION_FRAME);
    }

    /**
     * Fills maps with symbol name key and animation frame to slowdown and stop
     */
    private void setupSymbolFramesMap() {
        //for stop
        symbolFrames = new HashMap<>();
        symbolFrames.put("ace", 59);
        symbolFrames.put("king", 67);
        symbolFrames.put("queen", 75);
        symbolFrames.put("jack", 83);
        symbolFrames.put("ten", 91);
        symbolFrames.put("necklace", 43);
        symbolFrames.put("cleopatra", 27);
        symbolFrames.put("bracelet", 51);
        symbolFrames.put("griffin", 35);

        //for slowdown before stop
        twoPreviousSymbolFrames = new HashMap<>();
        twoPreviousSymbolFrames.put("ace", 43);
        twoPreviousSymbolFrames.put("king", 51);
        twoPreviousSymbolFrames.put("queen", 59);
        twoPreviousSymbolFrames.put("jack", 67);
        twoPreviousSymbolFrames.put("ten", 75);
        twoPreviousSymbolFrames.put("necklace", 27);
        twoPreviousSymbolFrames.put("bracelet", 35);
        twoPreviousSymbolFrames.put("griffin", 27);
    }

    /**
     * Stops the book animation on the selected symbol.
     */
    @ExposeMethod
    public void selectFeatureSpecialScatterSymbol() {
        symbolName = getModel().getExtendedSymbolName().toLowerCase();
        selectingExtendedSymbolAnimation.setLoop(false);
        selectingExtendedSymbolAnimationSubscription = selectingExtendedSymbolAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                selectingExtendedSymbolAnimation.gotoAndPlay(selectingExtendedSymbolAnimation.getBeginLoopFrameNumber());
                if(!symbolName.equals(firstSymbolName)){
                    selectingExtendedSymbolAnimationListener = new SelectingExtendedSymbolAnimationListener();
                    selectingExtendedSymbolAnimation.addPropertyChangedListener(selectingExtendedSymbolAnimationListener);
                    selectingExtendedSymbolAnimation.play();
                }else{
                    selectingExtendedSymbolAnimation.playToAndPause(symbolFrames.get(symbolName));
                    selectingExtendedSymbolAnimation.setFps(26);
                }


            } else if (animationState == AnimationState.PAUSED) {
                getEventBus().post(new ShownExtendedSymbolEvent());
            }
        });
    }

    /*
        /**
         * Shows the extended symbol for history purpose.
         */
    @ExposeMethod
    public void forceShowExtendedSymbol() {
        symbolName = getModel().getExtendedSymbolName().toLowerCase();
        selectingExtendedSymbolAnimation.gotoAndPause(symbolFrames.get(symbolName));
    }

    /**
     * Clears the subscription for the selecting extended symbol animation.
     */
    private void clearAnimationSubscription() {
        if (selectingExtendedSymbolAnimationSubscription != null) {
            selectingExtendedSymbolAnimation.setFps(26);
            selectingExtendedSymbolAnimationSubscription.unsubscribe();
            selectingExtendedSymbolAnimationSubscription = null;
        }
        if (selectingExtendedSymbolGlowAnimationSubscription != null) {
            selectingExtendedSymbolAnimation.removePropertyChangedListener(selectingExtendedSymbolAnimationListener);
            selectingExtendedSymbolGlowAnimationSubscription.unsubscribe();
            selectingExtendedSymbolGlowAnimationSubscription = null;
        }
    }

    private class StartSelectingExtendedSymbolAnimationCommandObserver extends NextObserver<StartSelectingExtendedSymbolAnimationCommand> {

        @Override
        public void onNext(StartSelectingExtendedSymbolAnimationCommand startSelectingExtendedSymbolAnimationCommand) {
            handleStartSelectingExtendedSymbolAnimationCommand(startSelectingExtendedSymbolAnimationCommand);
        }
    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);
        }
    }

    private class ExtendedSymbolModelChangedEventObserver extends NextObserver<ExtendedSymbolModelChangedEvent> {

        @Override
        public void onNext(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
            handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);
        }
    }

    private class ShowSelectedExtendedSymbolCommandObserver extends NextObserver<ShowSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(ShowSelectedExtendedSymbolCommand showSelectedExtendedSymbolCommand) {
            handleShowSelectedExtendedSymbolCommand(showSelectedExtendedSymbolCommand);
        }
    }

    private class HideSelectedExtendedSymbolCommandObserver extends NextObserver<HideSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(HideSelectedExtendedSymbolCommand hideSelectedExtendedSymbolCommand) {
            handleHideSelectedExtendedSymbolCommand(hideSelectedExtendedSymbolCommand);
        }
    }

    private class HighlightSelectedExtendedSymbolCommandObserver extends NextObserver<HighlightSelectedExtendedSymbolCommand> {

        @Override
        public void onNext(HighlightSelectedExtendedSymbolCommand highlightSelectedExtendedSymbolCommand) {
            handleHighlightSelectedExtendedSymbolCommand(highlightSelectedExtendedSymbolCommand);

        }
    }

    /**
     * Slow down the book animation before stopping
     */
    private class SelectingExtendedSymbolAnimationListener implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {

            if (symbolName != null && selectingExtendedSymbolAnimation != null && selectingExtendedSymbolAnimation.getCurrentFrameIndex() == twoPreviousSymbolFrames.get(symbolName) && !symbolName.equals(firstSymbolName)) {
                Bookpause.setPauseTime(800);
                selectingExtendedSymbolAnimation.setFps(7);
                selectingExtendedSymbolAnimation.playToAndPause(symbolFrames.get(symbolName));

            }
        }
    }

    //class SpinReelsCommandObserver extends NextObserver<SpinReelsCommand>{

     //   @Override
     //   public void onNext(SpinReelsCommand spinReelsCommand) {
/*            if(GameEngine.current().getViewManager().findViewById("freeGamesBannerScreen","you_won_plate").isVisible()){
                GameEngine.current().getViewManager().findViewById("freeGamesBannerScreen","you_won_plate").setVisible(false);
                GameEngine.current().getViewManager().findViewById("freeGamesBannerScreen","LangFeatureWin").setVisible(false);
                GameEngine.current().getViewManager().findViewById("freeGamesBannerScreen","currentFreeGamesNumber").setVisible(false);
                GameEngine.current().getViewManager().findViewById("freeGamesBannerScreen","wrongText").setVisible(false);
            }*/
      //  }
   // }
}