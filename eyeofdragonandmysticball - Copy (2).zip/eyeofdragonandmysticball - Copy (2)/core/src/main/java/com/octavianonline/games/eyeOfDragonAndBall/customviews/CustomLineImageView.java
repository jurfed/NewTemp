package com.octavianonline.games.eyeOfDragonAndBall.customviews;

import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.Rectangle;
import com.gwtent.reflection.client.Reflectable;

/**
 * For adding win lines as image
 */
@XmlElement
@Reflectable
public class CustomLineImageView extends com.atsisa.gox.framework.view.ImageView implements IBound{


    public CustomLineImageView() {
        super();
    }

    @Override
    public Rectangle getBoundaries() {
        return new Rectangle(getX(), getY(), getWidth(), getHeight());
    }
}
