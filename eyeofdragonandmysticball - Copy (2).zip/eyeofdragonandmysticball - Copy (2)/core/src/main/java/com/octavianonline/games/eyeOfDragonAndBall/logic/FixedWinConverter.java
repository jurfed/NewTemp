package com.octavianonline.games.eyeOfDragonAndBall.logic;

import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.model.LineWinResult;
import com.atsisa.gox.logic.model.SymbolPosition;
import com.atsisa.gox.logic.model.WinResult;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.logic.model.ExtendedSymbolWinLineInfo;
import com.atsisa.gox.reels.logic.model.WinLineInfo;

import java.util.*;
import java.util.stream.Collectors;


/**
 * Converts winning lines from game logic.
 */

public class FixedWinConverter {


    /**
     * Converts winning lines
     *
     * @param winningLines  collection of the {@link LineWinResult}
     * @param reelsAmount   number of reels
     * @param winLineSounds sounds for win lines
     * @param winAnimations win animations
     * @return list of the {@link IWinLineInfo}
     * @throws GameLogicException when result from game logic is wrong
     */

    public List<IWinLineInfo> convertWinningLines(Collection<LineWinResult> winningLines, int reelsAmount, Map<Integer, String> winLineSounds,

                                                  Map<Integer, String> winAnimations) throws GameLogicException {

        List<LineWinResult> collect = winningLines.stream().sorted((o1, o2) -> (int) (o2.getWinResult().getScore() - o1.getWinResult().getScore())).collect(Collectors.toList());

        List<IWinLineInfo> winLineInfos = new ArrayList<>(winningLines.size());


        for (LineWinResult winLineResult : collect) {

            String soundName = winLineSounds.get(winLineResult.getWinResult().getWinDescriptorId());

            if (StringUtility.isNullOrEmpty(soundName)) {

                throw new GameLogicException("The sound name is empty.");

            }


            String animationName = winAnimations.get(winLineResult.getWinResult().getWinDescriptorId());

            if (StringUtility.isNullOrEmpty(animationName)) {

                throw new GameLogicException("The animation name is empty.");

            }

            //Presentation counts line id from 1

            winLineInfos

                    .add(new WinLineInfo(winLineResult.getLineId().orElse(-1) + 1, winLineSounds.get(winLineResult.getWinResult().getWinDescriptorId()),

                            animationName, winLineResult.getWinResult().getScore(),

                            convertWinLinePositions(winLineResult.getWinResult().getPositions(), reelsAmount)));

        }

        return winLineInfos;

    }


    public List<IWinLineInfo> convertWinning(Collection<WinResult> winningLines, int reelsAmount, Map<Integer, String> winLineSounds,

                                             Map<Integer, String> winAnimations) throws GameLogicException {


        List<IWinLineInfo> winLineInfos = new ArrayList<>(winningLines.size());


        for (WinResult winResult : winningLines) {

            String soundName = winLineSounds.get(winResult.getWinDescriptorId());

            if (StringUtility.isNullOrEmpty(soundName)) {

                throw new GameLogicException("The sound name is empty.");

            }


            String animationName = winAnimations.get(winResult.getWinDescriptorId());

            if (StringUtility.isNullOrEmpty(animationName)) {

                throw new GameLogicException("The animation name is empty.");

            }

            // todo Presentation counts line id from 1

            winLineInfos

                    .add(new WinLineInfo(0, winLineSounds.get(winResult.getWinDescriptorId()),

                            animationName, winResult.getScore(),

                            convertWinLinePositions(winResult.getPositions(), reelsAmount)));

        }

        return winLineInfos;

    }


    /**
     * Converts win positions
     *
     * @param logicSymbolPositions List of the {@link SymbolPosition}
     * @param reels                number of reels
     * @return List of ints
     */

    private List<Integer> convertWinLinePositions(List<SymbolPosition> logicSymbolPositions, int reels) {

        List<Integer> positions = new ArrayList<>();

        int reelId = 0;

        for (int reel = 0; reel < reels; reel++) {

            if (logicSymbolPositions.size() > reelId) {

                if (logicSymbolPositions.get(reelId).getReel() == reel) {

                    positions.add(logicSymbolPositions.get(reelId).getRow());

                    reelId++;

                } else

                    positions.add(-1);

            } else {

                positions.add(-1);

            }

        }

        return positions;

    }

    public List<ExtendedSymbolWinLineInfo> convertExtendedWinningLines(Collection<LineWinResult> winningLines, int reelsAmount, Map<Integer, String> winLineSounds, String extendedSymbolName) throws GameLogicException {
        List<ExtendedSymbolWinLineInfo> winLineInfos = new ArrayList(winningLines.size());
        Iterator var6 = winningLines.iterator();

        while(var6.hasNext()) {
            LineWinResult winLineResult = (LineWinResult)var6.next();
            int id = winLineResult.getWinResult().getWinDescriptorId();
            if (!winLineSounds.containsKey(id)) {
                throw new GameLogicException(String.format("Missing sound for win id: %d", id));
            }

            String soundName = (String)winLineSounds.get(id);
            winLineInfos.add(new ExtendedSymbolWinLineInfo(((Integer)winLineResult.getLineId().orElse(Integer.valueOf(-1))).intValue() + 1, soundName, extendedSymbolName, winLineResult.getWinResult().getScore(), this.convertWinLinePositions(winLineResult.getWinResult().getPositions(), reelsAmount)));
        }

        return winLineInfos;
    }

}