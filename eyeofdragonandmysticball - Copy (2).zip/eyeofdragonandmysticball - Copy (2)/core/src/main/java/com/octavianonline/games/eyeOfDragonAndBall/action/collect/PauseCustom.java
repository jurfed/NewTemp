package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.ActionState;
import com.atsisa.gox.framework.action.PauseActionData;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.annotations.Reflect_Mini;


@Reflect_Mini
public class PauseCustom extends Action<PauseActionData> {

    /**
     * Default time.
     */
    private static final int DEFAULT_TIME = 1000;

    /**
     * Pause time, default is 1000 milliseconds (1 second).
     */
    private int pauseTime = DEFAULT_TIME;

    /**
     * Timeout.
     */
    private Timeout timeout;

    /**
     * Initializes a new instance of the PauseCustom class.
     */
    public PauseCustom() {
    }

    /**
     * Initializes a new instance of the PauseCustom class.
     *
     * @param logger   a logger reference
     * @param eventBus an eventBus reference
     */
    public PauseCustom(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    /**
     * Gets action data type for this action.
     *
     * @return action data type for this action
     */
    @Override
    public Class<PauseActionData> getActionDataType() {
        return PauseActionData.class;
    }

    @Override
    protected void grabData() {
        if (actionData != null) {
            pauseTime = actionData.getPauseTime();
        }
    }

    @Override
    protected void execute() {
        logger.debug("PauseCustom | execute");
        timeout = new Timeout(pauseTime, new TimeoutCallback() {

            @Override
            public void onTimeout() {
                finish();
            }
        }, true);
    }

    @Override
    protected void finish() {
        if (getState().equals(ActionState.ACTIVE)) {
            super.finish();
        }
    }

    @Override
    protected void reset() {
        if (timeout != null && !timeout.isCleaned()) {
            timeout.clear();
        }
        super.reset();
    }

    @Override
    protected void terminate() {
        if (!isFinished()) {
            if (timeout != null && !timeout.isCleaned()) {
                timeout.clear();
            }
            super.terminate();
        }
    }

}
