package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;

public class ReturnLines extends Action {
//    private List<LineShapeView> lineShapeViewList = new ArrayList<>();
    @Override
    protected void execute() {
/*        if(lineShapeViewList.size()==0){
            lineShapeViewList.addAll(GameEngine.current().getViewManager().findViewByType("winLinesScreen",LineShapeView.class));
        }*/
        GameEngine.current().getViewManager().getLayout("winLinesScreen").getRootView().setVisible(false);
/*        lineShapeViewList.stream().forEach(line -> {
            if (line.getAlpha() != 1) {
                line.setAlpha(1);
            }
        });*/
        finish();
    }
}
