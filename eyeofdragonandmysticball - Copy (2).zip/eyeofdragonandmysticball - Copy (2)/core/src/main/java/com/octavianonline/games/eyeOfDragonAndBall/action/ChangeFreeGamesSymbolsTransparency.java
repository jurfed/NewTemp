package com.octavianonline.games.eyeOfDragonAndBall.action;


import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.view.*;
import com.gwtent.reflection.client.Reflectable;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.ExtendedSymbolStatic;
import rx.Observable;

import java.util.List;

/**
 * Class for changing the transparency of characters in the free game mode
 */
@Reflectable
@XmlElement
public class ChangeFreeGamesSymbolsTransparency extends ShowExtendedSymbolAnimationsStrategy {

    /**
     * Flag for indication the appearance of an extended symbol on the reel
     */
    private boolean startTransparency = false;

    /**
     * To get symbols on a stopped drum
     */
    private static AbstractSymbol symbol;

    /**
     * Number of lines on the drum
     */
    private static final int ROW_COUNT = 3;

    public ChangeFreeGamesSymbolsTransparency() {
        super();
        setDelayBetweenShowSymbols(300);
    }


/*    @Override
    private void startProcessNextSymbol() { // TODO this method is convenient for track the beginning of the symbol extention

    }*/

    /**
     * Determine whether there is an extended symbol when the drum is stopped
     *
     * @param winningLines
     * @param reelGroup
     * @return
     */
    @Override
    public Observable<IReelGroup> showAnimations(List<? extends IWinLineInfo> winningLines, IReelGroup reelGroup) {

        startTransparency = false;
        for (IWinLineInfo lineInfo : winningLines) {
            if ((lineInfo.getAnimationName()).equals(ExtendedSymbolStateName.EXTENDED_SYMBOL_ANIMATION_NAME)) {
                if (!startTransparency) {
                    startTransparency = true;
                }
            }
        }

        if (startTransparency) {
            startProcessTransparency(reelGroup);
        }

        return super.showAnimations(winningLines, reelGroup);
    }

    /**
     * Filling the array of characters that need transparency
     *
     * @param reelGroup
     */
    void startProcessTransparency(IReelGroup reelGroup) {

        Iterable<AbstractReel> r = reelGroup.getReels();
        for (AbstractReel s : r) {
            for (int i = 0; i < ROW_COUNT; i++) {
                symbol = s.getDisplayedSymbol(i);
                if (!ExtendedSymbolStatic.extendedSymbolName.equals(symbol.getName())) {
                    ExtendedSymbolStatic.symbolsTransparency.add(symbol);
                }
            }
        }

        new Timeout(ExtendedSymbolStatic.DELAY_TIME, new TimeOutTransparencyAnimation(), false).start();

        ExtendedSymbolStatic.transparencyDone = true;
    }

    /**
     * set transparency for added characters
     */
    class TimeOutTransparencyAnimation implements TimeoutCallback {

        @Override
        public void onTimeout() {
            for (AbstractSymbol symbol : ExtendedSymbolStatic.symbolsTransparency) {
                symbol.setAlpha((symbol.getAlpha() - ExtendedSymbolStatic.TRANSPARENCY_STEP));
            }
            try{
                if (ExtendedSymbolStatic.symbolsTransparency.get(0).getAlpha() > ExtendedSymbolStatic.MAX_TRANSPARENCY) {
                    new Timeout(ExtendedSymbolStatic.DELAY_TIME, new TimeOutTransparencyAnimation(), false).start();
                }
            }catch(IndexOutOfBoundsException e){
               e.printStackTrace();
            }

        }
    }

}
