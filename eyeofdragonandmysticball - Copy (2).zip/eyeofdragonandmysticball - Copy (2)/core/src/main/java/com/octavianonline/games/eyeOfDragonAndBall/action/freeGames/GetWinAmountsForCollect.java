package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.octavianonline.games.eyeOfDragonAndBall.action.collect.FinishCollect;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;

/**
 * Class for get win sum for collect in the free games mode
 */
public class GetWinAmountsForCollect extends Action<InitFreeGameCollectActionData> {
    private static boolean terminate = false;
    private static long tempWin = 0L;

    public static boolean isTerminate() {
        return terminate;
    }

    public static void setTempWin(long tempWin) {
        GetWinAmountsForCollect.tempWin = tempWin;
    }

    private static long totalAmountForBigWin = 0;
    private static long startAmountForBigWin = 0;
    private static int collectTime = 0;

    public static long getTotalAmountForBigWin() {
        return totalAmountForBigWin;
    }

    public static void setTotalAmountForBigWin(long totalAmountForBigWin) {
        GetWinAmountsForCollect.totalAmountForBigWin = totalAmountForBigWin;
    }

    public static long getStartAmountForBigWin() {
        return startAmountForBigWin;
    }

    public static void setStartAmountForBigWin(long startAmountForBigWin) {
        GetWinAmountsForCollect.startAmountForBigWin = startAmountForBigWin;
    }

    public static int getCollectTime() {
        return collectTime;
    }

    public static void setCollectTime(int collectTime) {
        GetWinAmountsForCollect.collectTime = collectTime;
    }

    @Override
    protected void execute() {
        totalAmountForBigWin = 0;
        startAmountForBigWin = 0;
        collectTime = 0;
        terminate = false;

        Long totalWinAmount = new Long(((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount());


        IFreeGamesModelProvider freeGamesModelProvider = EyeOfDragonAndBallBaseGameScreen.getFreeGamesModelProvider();
        Long currentGameWinAmount = new Long(freeGamesModelProvider.getModel().getCurrentGameWinAmount());

        Iterable<? extends IWinLineInfo> lines = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getLinesModel().getWinningLines();
        if (lines == null) {
            GameEngine.current().getActionManager().terminateActiveAction();
            terminate = true;
        }

        if (!terminate) {
            long latestWins = ((AbstractReelGame) GameEngine.current().getGame()).getAccountModelProvider().getAccountModel().getLatestWinnings();
            long allFreeGamesAmount = EyeOfDragonAndBallBaseGameScreen.getAllFreeGamesAmount();
            if (this.actionData.isExtended()) {//for extended win
                collectTime = (int) ((totalWinAmount - tempWin) * 2);
                totalAmountForBigWin = totalWinAmount - tempWin;
                startAmountForBigWin = allFreeGamesAmount;
                EyeOfDragonAndBallBaseGameScreen.setAllFreeGamesAmount(allFreeGamesAmount + (totalWinAmount - tempWin));
                tempWin = 0;
            } else {
                if (currentGameWinAmount != 0) {//for simple win
                    collectTime = (int) ((latestWins - allFreeGamesAmount) * 2);
                    totalAmountForBigWin = latestWins - allFreeGamesAmount;
                    startAmountForBigWin = allFreeGamesAmount;
                    tempWin = latestWins - allFreeGamesAmount;
                    EyeOfDragonAndBallBaseGameScreen.setAllFreeGamesAmount(latestWins);

                } else {//for scatter trigger
                    collectTime = (int) ((latestWins - allFreeGamesAmount) * 2);
                    totalAmountForBigWin = latestWins - allFreeGamesAmount;
                    startAmountForBigWin = allFreeGamesAmount;
                    tempWin = latestWins - allFreeGamesAmount;
                    EyeOfDragonAndBallBaseGameScreen.setAllFreeGamesAmount(latestWins);

                }
            }

            FinishCollect.setBeginTime(System.currentTimeMillis());
            FinishCollect.setCollectTime(collectTime);

        }

        if (!isTerminate() && !isFinished()) {
            finish();
        }

    }

    @Override
    protected void terminate() {
        terminate = true;
        super.terminate();
    }

    @Override
    public Class<InitFreeGameCollectActionData> getActionDataType() {
        return InitFreeGameCollectActionData.class;
    }

}
