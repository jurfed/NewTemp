package com.octavianonline.games.eyeOfDragonAndBall;

import dagger.Module;

/**
 * Represents an IoC game logic configuration module.
 */
@Module
public abstract class EyeOfDragonAndBallGameLogicModule {
/*

private static ServiceResolver serviceResolver;

    @Singleton
    @Provides
    static IServiceResolver bindServiceResolver(@Named(GamelogicServicesType.ALL_SERVICES) Map<Class<?>, Object> gamelogicServices) {
       if (serviceResolver == null) {
            serviceResolver = new ServiceResolver(gamelogicServices);
       }
       return serviceResolver;
    }

    @Provides
    @IntoMap
    @Named(ServicesType.CONTROLLERS)
    @Singleton
    @ClassKey(IServiceRegister.class)
    static Object provideServiceRegister(@Named(GamelogicServicesType.ALL_SERVICES) Map<Class<?>, Object> gamelogicServices) {
        if (serviceResolver == null) {
            serviceResolver = new ServiceResolver(gamelogicServices);
        }
        return serviceResolver;
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IGameLogicStateRepository.class)
    public static Object provideGameLogicStateRepository() {
            return new GameLogicStateRepository();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IHistoryCardsProvider.class)
    public static Object provideHistoryCardsProvider() {
            return new HistoryCardsProvider();
    }

    @Provides
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IRngService.class)
    public static Object provideRngService() {
            return new RngService();
    }

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IBalance.class)
    abstract Object provideBalance(IBalance balance);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAccount.class)
    abstract Object provideAccount(IAccount account);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ISoundsProvider.class)
    abstract Object provideSoundProvider(ISoundsProvider soundProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IAnimationsProvider.class)
    abstract Object provideAnimationProvider(IAnimationsProvider animationProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IStopSymbolsProvider.class)
    abstract Object provideStopSymbolProvider(IStopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsDescriptorProvider.class)
    abstract Object provideReelsDescriptorProvider(IReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(ILinesCalculator.class)
    abstract Object provideLinesCalculator(QueenCleopatraLinesCalculator linesCalculator);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IPayTableProvider.class)
    abstract Object providePayTableProvider(IPayTableProvider IGameLogicStateRepository);

    @Binds
    @Singleton
    @IntoMap
    @Named(GamelogicServicesType.ALL_SERVICES)
    @ClassKey(IReelsGameConfigurationProvider.class)
    abstract Object provideReelsGameConfigurationProvider(IReelsGameConfigurationProvider reelsGameConfigurationProvider);

    @Singleton
    @Provides
    @Named(ReelsDescriptorProvider.REELS_DESCRIPTOR_FILE_RESOURCE_NAME)
    static String reelsDescriptorFilePath() {
        return "reelstrips";
    }

    @Singleton
    @Provides
    @Named(ReelsGameConfigurationProvider.REELS_GAME_CONFIGURATION_FILE_RESOURCE_NAME)
    static String reelsGameConfigurationFilePath() {
        return "reelsGameConfiguration";
    }

    @Singleton
    @Provides
    @Named(PayTableProvider.PAYTABLE_FILE_RESOURCE_NAME)
    static String payTableConfigurationFilePath() {
        return "payTable";
    }

    @Singleton
    @Provides
    @Named(SoundDescriptionsProvider.REEL_STRIP_SOUNDS_FILE_RESOURCE_NAME)
    static String reelStripsStopSoundsFilePath() {
        return "reelStripStopSounds";
    }

    @Singleton
    @Provides
    @Named(SoundDescriptionsProvider.WIN_SOUNDS_FILE_RESOURCE_NAME)
    static String winSoundsFilePath() {
        return "winSounds";
    }


    @Singleton
    @Provides
    @Named(LinesModelProvider.LINES_FILE_RESOURCE_NAME)
    static String linesPathConfigurationFilePath() {
        return "lines";
    }

    @Singleton
    @Provides
    @Named(AnimationDescriptionsProvider.ANIMATIONS_FILE_RESOURCE_NAME)
    static String animationsFilePath() {
        return "animations";
    }

    @IntoSet
    @Binds
    abstract ILogicInitializable animationProviderInitializableBind(AnimationDescriptionsProvider animationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable soundsProviderInitializableBind(SoundDescriptionsProvider soundsProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelsGameConfigurationInitializableBind(ReelsGameConfigurationProvider reelsGameConfigurationProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable paytTableProviderInitializable(PayTableProvider payTableProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelDescriptorProviderInitializable(ReelsDescriptorProvider reelsDescriptorProvider);

    @IntoSet
    @Binds
    abstract ILogicInitializable reelLogicInitializableBind(ReelsLogic reelsLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable gamblerLogicInitializableBind(GamblerLogic gamblerLogic);

    @IntoSet
    @Binds
    abstract ILogicInitializable linesModelProviderInitializable(LinesModelProvider linesModelProvider);

    @Binds
    @Singleton
    abstract ILinesCalculator linesCalculatorBind(QueenCleopatraLinesCalculator linesCalculator);

    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker symbolHitChecker() {
        return new SymbolHitChecker();
    }

    @Binds
    @Singleton
    abstract IReelsGameConfigurationProvider reelsGameConfigurationProviderBind(ReelsGameConfigurationProvider reelGameConfigurationProvider);

    @Binds
    @Singleton
    abstract IReelsDescriptorProvider reelsDescriptorProviderBind(ReelsDescriptorProvider reelsDescriptorProvider);

    @Binds
    @Singleton
    abstract IStopSymbolsProvider stopSymbolsProviderBind(StopSymbolsProvider stopSymbolsProvider);

    @Binds
    @Singleton
    abstract ISoundDescriptionsProvider soundsDescriptionsProviderBind(SoundDescriptionsProvider soundProvider);

    @Binds
    @Singleton
    abstract ISoundsProvider soundsProviderBind(QueenCleopatraSoundsProvider soundProvider);

    @Binds
    @Singleton
    abstract IAnimationsProvider animationProviderBind(AnimationsProvider animationProvider);

    @Binds
    @Singleton
    abstract IAnimationDescriptionsProvider animationDescriptionProviderBind(AnimationDescriptionsProvider animationProvider);

    @Binds
    @Singleton
    abstract IPayTableProvider payTableProviderBind(PayTableProvider payTableProvider);

    @Binds
    @Singleton
    abstract ILinesModelProvider linesProvider(LinesModelProvider linesProvider);

    @Binds
    @Singleton
    abstract IReelsLogic reelsLogicBind(ReelsLogic reelsLogic);

    @Binds
    @Singleton
    abstract IReelGameLogic reelGameLogicBind(QueenCleopatraLogic logic);

    @Binds
    @Singleton
    abstract IGamblerLogic gamblerLogicBind(GamblerLogic reelsLogic);

    @Singleton
    @Provides
    public static IGameLogicStateRepository gameLogicStateRepository() {
        return new GameLogicStateRepository();
    }

    @Singleton
    public abstract IntegrationFlowFactory integrationFlowFactory();

    @Singleton
    public abstract GameConfigurationAdapter gameConfigurationAdapter();

    @IntoMap
    @StringKey(CoreConditions.POSITIVE_CONDITION)
    @Singleton
    @Provides
    public static IConditionalMessage positiveCondition() {
        return new PositiveConditionalMessage();
    }

    @IntoMap
    @StringKey(ReelsConditions.SPIN_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage spinWinDetectorCondition() {
            return new SpinWinDetector();
    }

    @IntoMap
    @StringKey(ReelsHandlers.APPLY_WIN_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyWinLimitsHandler() {
            return new ApplyWinLimits();
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createLoseResponseHandler(IServiceResolver serviceResolver) {
        return new CreateLoseResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_TAKE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createTakeWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateTakeWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.CREATE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createWinResponseHandler(IServiceResolver serviceResolver) {
        return new CreateWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.DRAW_STOP_SYMBOLS)
    @Singleton
    @Provides
    public static IMessageHandler drawStopSymbolsHandler(IServiceResolver serviceResolver){
        return new DrawStopSymbols(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.REEL_DEPOSIT_WIN)
    @Singleton
    @Provides
    public static IMessageHandler reelDepositWinHandler(IServiceResolver serviceResolver) {
            return new ReelDepositWin(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinArgumentValidatorHandler(IServiceResolver serviceResolver) {
            return new SpinArgumentValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_BALANCE_VERIFIER)
    @Singleton
    @Provides
    public static IMessageHandler spinBalanceVerifierHandler(IServiceResolver serviceResolver) {
        return new SpinBalanceVerifier(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler spinStateValidatorHandler(IServiceResolver serviceResolver) {
            return new SpinStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.SPIN_WITHDRAW_MONEY)
    @Singleton
    @Provides
    public static IMessageHandler spinWithdrawMoney(IServiceResolver serviceResolver) {
            return new SpinWithdrawMoney(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.TAKE_WIN_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler takeWinStateValidatorHandler(IServiceResolver serviceResolver) {
            return new TakeWinStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(ReelsHandlers.WIN_LINES_CALCULATOR)
    @Singleton
    @Provides
    public static IMessageHandler winLinesCalculatorHandler(IServiceResolver serviceResolver) {
        return new WinLinesCalculator(serviceResolver);
    }

    @Provides
    @Singleton
    static IHistoryCardsProvider historyCardsProviderBind() {
            return new HistoryCardsProvider();
    }

    @IntoMap
    @StringKey(GamblerHandlers.ENTER_GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler enterGamblerStateValidator(IServiceResolver serviceResolver) {
        return new EnterGamblerStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_ENTER_GAMBLER_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createEnterGamblerResponse(IServiceResolver serviceResolver) {
        return new CreateEnterGamblerResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerConditions.GAMBLE_WIN_DETECTOR)
    @Singleton
    @Provides
    public static IConditionalMessage gambleWinDetector() {
        return new GambleWinDetector();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_ARGUMENT_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerArgumentValidator() {
        return new GamblerArgumentValidator();
    }

    @IntoMap
    @StringKey(GamblerHandlers.GAMBLER_STATE_VALIDATOR)
    @Singleton
    @Provides
    public static IMessageHandler gamblerStateValidator(IServiceResolver serviceResolver) {
            return new GamblerStateValidator(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_WIN_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleWinResponse(IServiceResolver serviceResolver) {
        return new CreateGambleWinResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.CREATE_GAMBLE_LOSE_RESPONSE)
    @Singleton
    @Provides
    public static IMessageHandler createGambleLoseResponse(IServiceResolver serviceResolver) {
        return new CreateGambleLoseResponse(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.DRAW_GAMBLE_CARD)
    @Singleton
    @Provides
    public static IMessageHandler drawGambleCard(IServiceResolver serviceResolver) {
        return new DrawGambleCard(serviceResolver);
    }

    @IntoMap
    @StringKey(GamblerHandlers.APPLY_GAMBLER_LIMITS)
    @Singleton
    @Provides
    public static IMessageHandler applyGamblerLimits(IGameLogicStateRepository gameLogicStateRepository) {
        return new ApplyGamblerLimits();
    }

    @IntoSet
    @Provides
    @Singleton
    public static IHitChecker wildSymbolHitChecker() {
        return new EyeOfDragonAndBallWildHitChecker();
    }
*/
}
