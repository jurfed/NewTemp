package com.octavianonline.games.eyeOfDragonAndBall.action.movie;

import com.atsisa.gox.framework.action.Action;
import com.octavianonline.games.eyeOfDragonAndBall.helpers.AniliseSymbolsForBlinking;

public class StopSplashScreenVideo extends Action{
    @Override
    protected void execute() {
        InitHandlingLogoMovies.enableTimer(false);
        AniliseSymbolsForBlinking.getLines=false;
        finish();
    }
}
