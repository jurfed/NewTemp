package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.AbstractReelGameComponent;
import com.atsisa.gox.reels.DebugAbstractReelGame;
import com.atsisa.gox.reels.event.LogicRequestCompleteEvent;
import com.atsisa.gox.reels.logic.DenominationResult;
import com.octavianonline.games.eyeOfDragonAndBall.customviews.CustomViewModule;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EyeOfDragonAndBall extends DebugAbstractReelGame {

    /**
     * Initializes a new instance of the {@link EyeOfDragonAndBall} class.
     * @param reelGameComponents reel game components
     */
    @Inject
    public EyeOfDragonAndBall(Set<AbstractReelGameComponent> reelGameComponents, IEventBus eventBus) {
        super(reelGameComponents);
        eventBus.register(new LogicRequestCompleteEventObserver(),LogicRequestCompleteEvent.class);
    }

    public void onStart() {
        IViewManager viewManager = GameEngine.current().getViewManager();

        viewManager.addLayout("reel_bg_ground");
        viewManager.addLayout("bgrScreen");
        viewManager.addLayout("payTableScreen");
        viewManager.addLayout("sideBarScreen");
        viewManager.addLayout("advancedControlPanelScreen");

    }

    @Override
    public void onReady() {
        IViewManager viewManager = GameEngine.current().getViewManager();
        viewManager.addLayout("reel_bg");

        viewManager.addLayout("reel_bg_freegame");

        viewManager.addLayout("baseGameScreen");
//        viewManager.addLayout("wonPanelScreen");

/*        BigWinScreen bigWinScreen = new BigWinScreen();
        GameEngine.current().getViewManager().registerScreen(bigWinScreen);
        bigWinScreen.initialize();*/
//        GameEngine.current().getViewManager().getScreenById("BigWinScreen").show();
        viewManager.addLayout("payTableBgrScreen");


//        SampleScreen screen = new SampleScreen();
//        GameEngine.current().getViewManager().registerScreen(screen);
//        screen.initialize();
//        GameEngine.current().getViewManager().getScreenById("sample").show();


        new Timeout(1000, new TempTimeoutCallback(),true);
    }

    @Override
    public void onCreate() {
        super.onCreate();
//        GameEngine.current().getViewManager().getViewBuilder().registerModule(new EyeOfDragonAndBallCoreViewModule());
        GameEngine.current().getViewManager().getViewBuilder().registerModule(new CustomViewModule());
        eventBus.post(getDenominationResult());

    }
    private class LogicRequestCompleteEventObserver extends NextObserver<LogicRequestCompleteEvent> {
        @Override
        public void onNext(LogicRequestCompleteEvent logicRequestCompleteEvent) {
            System.err.println(System.nanoTime()/ 1000000000);
        }
    }

    public DenominationResult getDenominationResult() {
        List<BigDecimal> denominationSteps = new ArrayList<>();
        denominationSteps.add(new BigDecimal(1));
        denominationSteps.add(new BigDecimal(2));
        denominationSteps.add(new BigDecimal(10));
        return new DenominationResult(denominationSteps.get(0), denominationSteps);
    }

    class TempTimeoutCallback implements TimeoutCallback{

        @Override
        public void onTimeout() {
            new Timeout(1000, new TempTimeoutCallback(),true);
        }
    }
}
