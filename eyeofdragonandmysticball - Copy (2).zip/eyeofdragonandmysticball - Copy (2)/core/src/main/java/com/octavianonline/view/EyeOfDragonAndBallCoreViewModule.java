package com.octavianonline.view;

import com.atsisa.gox.framework.view.AbstractViewModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

//import com.atsisa.gox.games.trextrack.view.paytable.PayTableWinAnimationView;

/**
 * Represents the core view types which could be created declaratively using XML.
 */
@Reflect_Mini
public class EyeOfDragonAndBallCoreViewModule extends AbstractViewModule {

    /**
     * Core views module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/eyeOfDragonAndBall/view";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        //registerView(CustomKeyframeAnimationView.class);
//        registerView(LineSymbolWinAnimation.class);
//        registerView(PayTableWinAnimationView.class);
    }

}
