package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.GetWinAmountsForCollect;

public class CheckShortCollectFreeGames extends ExecuteNextAction {
    @Override
    protected void execute() {
        allowFurtherProcessing();
        long playingTime = System.currentTimeMillis() - FinishCollect.getBeginTime();
        if (GetWinAmountsForCollect.isTerminate() || playingTime > FinishCollect.getCollectTime()) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }


}
