package com.octavianonline.games.eyeOfDragonAndBall.action;

import com.atsisa.gox.framework.action.Action;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class ShowBgrFreeGames extends Action {

    @Override
    protected void execute() {
/*        GameEngine.current().getViewManager().findViewById("payTableBgrScreen", "bgr_fg").setVisible(true);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "5TombMultiplier").setY(-148);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "5Tomb").setY(-148);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "4TombMultiplier").setY(-102);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "4Tomb").setY(-102);

        GameEngine.current().getViewManager().findViewById("payTableScreen", "3TombMultiplier").setY(-56);
        GameEngine.current().getViewManager().findViewById("payTableScreen", "3Tomb").setY(-56);*/

        finish();
    }
}