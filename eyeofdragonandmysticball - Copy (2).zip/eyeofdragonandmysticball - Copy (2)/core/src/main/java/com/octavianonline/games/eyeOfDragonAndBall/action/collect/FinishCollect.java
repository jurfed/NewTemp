package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;

public class FinishCollect extends Action {

    /**
     * Time for indicator collect
     */
    private static long collectTime;

    /**
     * System time when was begun indicatorCollect
     */
    private static long beginTime;

    public static long getBeginTime() {
        return beginTime;
    }

    public static void setBeginTime(long beginTime) {
        com.octavianonline.games.eyeOfDragonAndBall.action.collect.FinishCollect.beginTime = beginTime;
    }

    public static long getCollectTime() {
        return collectTime;
    }

    public static void setCollectTime(long collectTime) {
        com.octavianonline.games.eyeOfDragonAndBall.action.collect.FinishCollect.collectTime = collectTime;
    }


    private Timeout timeout;

    @Override
    protected void execute() {

        timeout = new Timeout(70, new CheckForFinish(), true);
    }

    class CheckForFinish implements TimeoutCallback {

        @Override
        public void onTimeout() {
            long playSoundTime = System.currentTimeMillis() - beginTime;
            if (playSoundTime >= collectTime) {
                finish();
            } else {
                timeout = new Timeout(70, new CheckForFinish(), true);
            }
        }
    }

    @Override
    protected void finish() {
        if (getState().name().equals("ACTIVE")) {
            if (timeout != null && !timeout.isCleaned()) {
                timeout.clear();
            }
            super.finish();
        }
    }

    @Override
    protected void reset() {
        if (timeout != null && !timeout.isCleaned()) {
            timeout.clear();
        }
        super.reset();
    }

    @Override
    protected void terminate() {
        if (timeout != null && !timeout.isCleaned()) {
            timeout.clear();
        }
        if (!isFinished()) {
            super.terminate();
        }
    }
}
