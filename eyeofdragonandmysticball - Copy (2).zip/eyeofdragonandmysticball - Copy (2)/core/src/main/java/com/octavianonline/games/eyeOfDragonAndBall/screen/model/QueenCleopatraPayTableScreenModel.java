package com.octavianonline.games.eyeOfDragonAndBall.screen.model;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.ConfigurationProvider;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.games.octavian.reels.screen.model.OPayTableScreenModel;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.model.IValueFormatter;

import javax.inject.Inject;
import java.util.*;

/**
 * Contains data for the pay table with the extended symbol.
 */
public class QueenCleopatraPayTableScreenModel extends OPayTableScreenModel {

    /**
     * Name of the pay table item for 5 symbols.
     */
    private static final String EXTENDED_SYMBOL_5_X_PAYS = "extendedSymbolX5Pays";

    /**
     * Name of the pay table item for 4 symbols.
     */
    private static final String EXTENDED_SYMBOL_4_X_PAYS = "extendedSymbolX4Pays";

    /**
     * Name of the pay table item for 3 symbols.
     */
    private static final String EXTENDED_SYMBOL_3_X_PAYS = "extendedSymbolX3Pays";

    /**
     * Name of the pay table item for 2 symbols.
     */
    private static final String EXTENDED_SYMBOL_2_X_PAYS = "extendedSymbolX2Pays";

    /**
     * List of pay table names for extended symbol.
     */
    private static final List<String> SYMBOL_NAMES = Arrays.asList(EXTENDED_SYMBOL_5_X_PAYS, EXTENDED_SYMBOL_4_X_PAYS, EXTENDED_SYMBOL_3_X_PAYS, EXTENDED_SYMBOL_2_X_PAYS);

    /**
     * Initializes a new instance of the {@link QueenCleopatraPayTableScreenModel} class.
     * @param translator            {@link ITranslator}
     * @param configurationProvider {@link ConfigurationProvider}
     * @param creditsFormatter      {@link ICreditsFormatter}
     */
    @Inject
    public QueenCleopatraPayTableScreenModel(ITranslator translator, IConfigurationProvider configurationProvider, IValueFormatter creditsFormatter, IEventBus eventBus, IPayTableModelProvider payTableModelProvider) {
        super(translator, configurationProvider, creditsFormatter, eventBus, payTableModelProvider);
    }

    /**
     * Handles incoming pay table item array and updates on the layout.
     * @param symbols the collection of {@link IPayTableModelItem}
     */
    public void updateExtendedSymbols(Iterable<IPayTableModelItem> symbols) {
        ArrayList<IPayTableModelItem> sortedSymbols = new ArrayList<>();
        symbols.forEach(sortedSymbols::add);
        Collections.sort(sortedSymbols, new CustomComparator());
        for (int i = 0; i < sortedSymbols.size(); i++) {
            addPayTableItemDescription(SYMBOL_NAMES.get(i), sortedSymbols.get(i).getValue());
        }
        refresh();
    }

    /**
     * Used to sorts the pay table model items.
     */
    private class CustomComparator implements Comparator<IPayTableModelItem> {

        @Override
        public int compare(IPayTableModelItem o1, IPayTableModelItem o2) {
            return (int)(o2.getValue()-(o1.getValue()));
        }
    }
}






