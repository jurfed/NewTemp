package com.octavianonline.games.eyeOfDragonAndBall.action.bigwin;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.games.octavian.core.event.StartControlPanelWinCollectCommand;
import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;
import com.octavianonline.games.eyeOfDragonAndBall.action.freeGames.GetWinAmountsForCollect;

/**
 * Class for check if Big Win will be play
 */
@Reflect_Mini
public class ExecuteNextDependingOnBigWinInFreeGames extends ExecuteNextAction {

    /**
     * For enable or disable big win
     */
    private static boolean bigwinOnOff = true;

    public static boolean getBigwinOnOff() {
        return bigwinOnOff;
    }

    public static void setBigwinOnOff(boolean value) {
        bigwinOnOff = value;
    }

    /**
     * time for playing big win
     */
    public static final int AWESOME_WIN = 8700;
    public static final int BIG_WIN = 11150;
    public static final int SUPER_BIG_WIN = 19700;
    public static final int MEGA_BIG_WIN = 28900;

    @Override
    protected void execute() {
        int collectTime = 0;

        allowFurtherProcessing();
        AbstractReelGame game = (AbstractReelGame) GameEngine.current().getGame();
        Long totalWinAmount = GetWinAmountsForCollect.getTotalAmountForBigWin();
        Long startWinAmount = GetWinAmountsForCollect.getStartAmountForBigWin();

        if (totalWinAmount == null || totalWinAmount <= 0 || GetWinAmountsForCollect.isTerminate()) {
            finish();
        } else {
            long totalBet = game.getBetModelProvider().getBetModel().getTotalBet();
            long winSum = totalWinAmount / totalBet;

            if (winSum >= 20 && bigwinOnOff) {
                collectTime = AWESOME_WIN;
                if (winSum >= 50) collectTime = BIG_WIN;
                if (winSum >= 100) collectTime = SUPER_BIG_WIN;
                if (winSum >= 200) collectTime = MEGA_BIG_WIN;

                eventBus.post(new StartControlPanelWinCollectCommand(collectTime, startWinAmount, totalWinAmount));
                cancelFurtherProcessing();
                super.execute();
                GameEngine.current().getActionManager().destroyActiveQueue();
            } else {
                finish();
            }
        }

    }
}
