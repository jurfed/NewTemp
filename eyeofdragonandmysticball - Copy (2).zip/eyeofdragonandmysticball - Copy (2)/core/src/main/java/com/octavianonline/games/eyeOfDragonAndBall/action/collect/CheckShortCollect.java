package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.action.ExecuteNextAction;

public class CheckShortCollect extends ExecuteNextAction {
    @Override
    protected void execute() {
        allowFurtherProcessing();
        long playingTime = System.currentTimeMillis() - FinishCollect.getBeginTime();
        if (playingTime > FinishCollect.getCollectTime()) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }
}
