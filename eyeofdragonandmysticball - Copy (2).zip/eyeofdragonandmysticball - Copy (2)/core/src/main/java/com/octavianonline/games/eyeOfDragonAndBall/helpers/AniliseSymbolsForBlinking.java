package com.octavianonline.games.eyeOfDragonAndBall.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.GetLiveGlassObjects;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassAnimationId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassFramesId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.enums.LiveGlassSymbolsId;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.GamblerIsStart;
import com.octavianonline.games.eyeOfDragonAndBall.gameobjects.staticClasses.IdentifiersForFlashingText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Class handles win lines, changes the depth of active symbols and collects data for flashing texts
 * <p>
 * Depth of symbols versus activity and type:
 * 0 - not active simple symbols
 * 1 - not active scatter symbols
 * 1 - active simple symbols not on the current win line
 * 2 - active scatter symbols not on the current win line
 * 3 - active symbols on the current win line
 */
public class AniliseSymbolsForBlinking {
    /**
     * For symbols analysis on reels
     */
    private ReelGroupView reelGroupView;


    private ArrayList previousSymbols;
    private List positions;
    private AbstractSymbol symbol;
    private AbstractSymbol symbolForFlashingText;
    ArrayList scatterSymbols;

    /**
     * For blinking text in the book in the free games mode
     */
    private ScatterTextBlinking scatterTextBlinking;

    /**
     * Are the current lines processed?
     */
    public static boolean getLines = false;

    private List positionsForFlashingText;

    private static final String PAY_TABLE_SCREEN = "payTableScreen";
    private static final String BASE_GAME_SCREEN = "baseGameScreen";
    private static final String REEL_GROUP_VIEW = "reelGroupView";


    private final String TOMB_SYMBOL = "Tomb";

    /**
     * Flag of line 0
     */
    private boolean freeGame = false;

    /**
     * To replace the frames of the scatter symbol before the free games mode
     */
    private KeyframeAnimationView scatterLongAnimation;
    private final String NAME_TOMB_LONG = "tombLong";
    private final int FRAMES_COUNT = 30;

    /**
     * To replace the frames of the scatter symbol before if there is no free game mode
     */
    private KeyframeAnimationView scatterShortAnimation;
    private final String NAME_TOMB_SHORT = "tombShort";

    private GetLiveGlassObjects liveGlassObjects;
    private HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation = new HashMap<>();
    private IViewManager viewManager;
    private HashMap<String, ImageView> symbolsImageView = new HashMap<>();

    LiveGlassAnimation liveGlassAnimationnew;


    public AniliseSymbolsForBlinking(IEventBus eventBus) {
        new IdentifiersForFlashingText();//initializes object identifiers for text flashing
        reelGroupView = GameEngine.current().getViewManager().findViewById(BASE_GAME_SCREEN, REEL_GROUP_VIEW);
        eventBus.register(new AniliseSymbolsForBlinking.LinesModelChangedEventObserver(), LinesModelChangedEvent.class);
        scatterLongAnimation = GameEngine.current().getViewManager().findViewById(BASE_GAME_SCREEN, NAME_TOMB_LONG);
        scatterShortAnimation = GameEngine.current().getViewManager().findViewById(BASE_GAME_SCREEN, NAME_TOMB_SHORT);

        liveGlassObjects = new GetLiveGlassObjects("payTableBgrScreen", GameEngine.current().getViewManager());
        mapUpperScreenSymbolsAnimation = liveGlassObjects.getLiveGlassAnimation(LiveGlassAnimationId.getSyblosAnimationsNames());
        symbolsImageView = liveGlassObjects.getLiveGlassSymbols(LiveGlassSymbolsId.getSyblosNames());
        // liveGlassAnimationnew = new LiveGlassAnimation();
    }

    /**
     * Initializing handling lines
     */
    private class LinesModelChangedEventObserver extends NextObserver<LinesModelChangedEvent> {

        @Override
        public void onNext(LinesModelChangedEvent linesModelChangedEvent) {
            handleLinesModelChanged(linesModelChangedEvent);
        }
    }


    /**
     * Move the active character to the top
     *
     * @param linesModelChangedEvent
     */
    private void handleLinesModelChanged(LinesModelChangedEvent linesModelChangedEvent) {


        if (linesModelChangedEvent.getChangeType() == LinesModelChangedEvent.CURRENT_WINNING_LINE) {
            if (linesModelChangedEvent.getLinesModel().getCurrentWinningLine().isPresent()) {
                freeGame = false;
                scatterSymbols = new ArrayList();

                if (previousSymbols == null) {
                    previousSymbols = new ArrayList();
                } else {
                    for (int i = 0; i < previousSymbols.size(); i++) {
                        AbstractSymbol symbolType = ((AbstractSymbol) previousSymbols.get(i));
                        if (symbolType.getName().equals(TOMB_SYMBOL)) {
                            symbolType.setDepth(2);
                        } else {
                            symbolType.setDepth(1);
                        }
                    }
                    previousSymbols = new ArrayList();
                }
                positions = Iterables.toList(linesModelChangedEvent.getLinesModel().getCurrentWinningLine().get().getPositions());

                for (int i = 0; i < positions.size(); i++) {
                    if ((int) positions.get(i) >= 0) {
                        symbol = reelGroupView.getReel(i).getDisplayedSymbol((int) positions.get(i));
                        symbol.setDepth(3);
                        previousSymbols.add(symbol);
                        scatterSymbols.add(symbol);
                    }

                }

                if (linesModelChangedEvent.getLinesModel().getCurrentWinningLine().get().getLineNumber() == 0) {
                    freeGame = true;
                    setScatterLongAnimation(scatterSymbols);
                    AutoplayButtomListener.setIsSoundPlaying(false);
                }

                reelGroupView.redraw();
                if (!getLines) {//If the current lines have not yet been processed, then we process them
                    getLines = true;
                    //initAllWinLines(linesModelChangedEvent);
                }
            }
        }
    }

    /**
     * Analyze all active lines and get the symbol on the line
     *
     * @param linesModelChangedEvent
     */
    public void initAllWinLines(LinesModelChangedEvent linesModelChangedEvent) {
        Iterable<? extends IWinLineInfo> winLines = linesModelChangedEvent.getLinesModel().getWinningLines();

        for (IWinLineInfo winLineInfo : winLines) {
            positionsForFlashingText = Iterables.toList(winLineInfo.getPositions());

            for (int i = 0; i < positionsForFlashingText.size(); i++) {
                if ((int) positionsForFlashingText.get(i) >= 0) {
                    symbolForFlashingText = reelGroupView.getReel(i).getDisplayedSymbol((int) positionsForFlashingText.get(i));
                }

                for (String symbolName : IdentifiersForFlashingText.SymbolsName) {
                    Iterable<Boolean> sequence = winLineInfo.getWinningSequence();
                    getActiveSymbol(symbolName, sequence);
                }
            }
        }

        //Count the number of animated Scatter symbols
        for (int i = 1; i <= IdentifiersForFlashingText.tombState.size(); i++) {
            if (IdentifiersForFlashingText.tombState.get(i + IdentifiersForFlashingText.tombSymbolName) == true) {
                IdentifiersForFlashingText.tombCount++;
            }
        }

        //If the number of animated Scatter symbols is more than 3, then we start the animation of the Scatter text and the Scatter-symbol on the upper screen.
        if (IdentifiersForFlashingText.tombCount >= 3 && !IdentifiersForFlashingText.startScatterTextBlinking) {
            if (scatterTextBlinking == null) {
                scatterTextBlinking = new ScatterTextBlinking(IdentifiersForFlashingText.blinkingTime);
            }
            scatterTextBlinking.start();
            IdentifiersForFlashingText.startScatterTextBlinking = true;
        } else if (IdentifiersForFlashingText.tombCount < 3) {//Otherwise, reset the counter of the number of animated Scatter symbols
            IdentifiersForFlashingText.tombCount = 0;
            for (int i = 1; i <= 5; i++) {
                IdentifiersForFlashingText.tombState.put(i + IdentifiersForFlashingText.tombSymbolName, false);
            }
            IdentifiersForFlashingText.startScatterTextBlinking = false;
        }
    }

    /**
     * Count the number of animated symbols on the line and initialize the text sending to blink
     *
     * @param activeSymbol
     * @param booleanSequence
     */
    public void getActiveSymbol(String activeSymbol, Iterable<Boolean> booleanSequence) {

        if (symbolForFlashingText.getName() != null && symbolForFlashingText.getName().equals(activeSymbol)) {
            for (View symbolView : symbolForFlashingText.getChildren()) {

                if (symbolView instanceof KeyframeAnimationView) {
                    symbolView.addPropertyChangedListener(new LiveGlassAnimation());
                }
            }

            int CountSymbolAnimation = 0;
            for (boolean winningSymbol : booleanSequence) {
                if (winningSymbol) CountSymbolAnimation++;
            }
            BlinkingPersonSymbol(activeSymbol, CountSymbolAnimation);
        }

        //If the scatter symbol is animated, then we increase the counter
        if (symbolForFlashingText.getName().equals(IdentifiersForFlashingText.tombSymbolName)) {
            String tombId = symbolForFlashingText.getId();
            for (View symbolView : symbolForFlashingText.getChildren()) {
                if ((symbolView instanceof ImageView)) {
                    symbolView.addPropertyChangedListener(new IViewPropertyChangedListener() {
                        @Override
                        public void propertyChanged(View view, ViewType viewType, int property) {
                            //If the symple picture is visible, then the scatter symbol animation flag is reset
                            if (symbolView.isVisible() && IdentifiersForFlashingText.startScatterTextBlinking) {
                                IdentifiersForFlashingText.startScatterTextBlinking = false;
                            }
                        }
                    });
                }

                if (symbolView instanceof KeyframeAnimationView && symbolView.isVisible()) {
                    IdentifiersForFlashingText.tombState.put(tombId, true);

                    if (!freeGame) {//If not a free games mode, then we change the animation of the scatter symbol to the standard (short)
                        setScatterShortAnimation(symbolView);
                    }
                }
            }
        }
    }

    /**
     * Sending text to blink if not already sent
     *
     * @param symbol
     * @param CountSymbol
     */
    void BlinkingPersonSymbol(String symbol, int CountSymbol) {

        try {

            if (!IdentifiersForFlashingText.sympleTextBlinking.get(CountSymbol + IdentifiersForFlashingText.symbolSympleName.get(symbol))) {
                IdentifiersForFlashingText.sympleTextBlinking.put(CountSymbol + IdentifiersForFlashingText.symbolSympleName.get(symbol), true);
                TextView[] textView1 = {GameEngine.current().getViewManager().findViewById(PAY_TABLE_SCREEN, CountSymbol + IdentifiersForFlashingText.symbolMultiplierName.get(symbol)), GameEngine.current().getViewManager().findViewById(PAY_TABLE_SCREEN, CountSymbol + IdentifiersForFlashingText.symbolSympleName.get(symbol))};
                new TextBlinking(textView1, IdentifiersForFlashingText.blinkingTime, IdentifiersForFlashingText.textFontBase, symbol).start();
            }
        } catch (NullPointerException n) {
            System.out.println("Cant' fing sympleTextBlinking for " + symbol);
        }
    }

    /**
     * If the zero line is active, then we set up a long animation of the scatter symbol
     *
     * @param scatterSymbols
     */
    public void setScatterLongAnimation(ArrayList scatterSymbols) {

        for (int i = 0; i < scatterSymbols.size(); i++) {
            AbstractSymbol symbol = (AbstractSymbol) scatterSymbols.get(i);

            if (symbol.getName().equals(TOMB_SYMBOL)) {
                for (View symbolView : symbol.getChildren()) {

                    if (symbolView instanceof KeyframeAnimationView) {
                        ((KeyframeAnimationView) symbolView).setFrames(scatterLongAnimation.getFrames());
                    }
                }
            }
        }
    }

    public void setScatterShortAnimation(View scatter) {

        if (((KeyframeAnimationView) scatter).getFrames().size() > FRAMES_COUNT) {
            ((KeyframeAnimationView) scatter).setFrames(scatterShortAnimation.getFrames());
        }
    }

    class LiveGlassAnimation implements IViewPropertyChangedListener {
        Integer lock;

        private Integer[] locki = new Integer[18];
        private KeyframeAnimationView upperAnimSymbol;
        KeyframeAnimationView keyframeAnimationView;

        LiveGlassAnimation() {
            for (int t = 0; t < locki.length; t++) {
                locki[t] = -1;
            }
        }

        boolean startPlay = false;

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            keyframeAnimationView = ((KeyframeAnimationView) view);
            if (((KeyframeAnimationView) view).isVisible() && !startPlay) {//if the character is played on the reel
                startPlay = true;
                IdentifiersForFlashingText.playingBlinking.put(String.valueOf(view.getParent()), true);

                try {
                    Integer key = Integer.parseInt(view.getId());
                    analyze(((KeyframeAnimationView) view), "start");
                } catch (NumberFormatException e) {

                }

            }
            if (startPlay && !((KeyframeAnimationView) view).isVisible()) {//if the character is not played
                //getLines = false;
                startPlay = false;
                IdentifiersForFlashingText.playingBlinking.put(String.valueOf(view.getParent()), false);

                try {
                    Integer key = Integer.parseInt(view.getId());
                    analyze(((KeyframeAnimationView) view), "stop");
                } catch (NumberFormatException e) {

                }

            }

        }

        void analyze(KeyframeAnimationView reelSymbol, String state) {
            if (reelSymbol != null && reelSymbol.isPlaying()) {
                Integer key = Integer.parseInt(reelSymbol.getId());
                switch (key) {
//Ace long animation
                    case 0:
                    case 29:
                    case 58:
                    case 87:
                    case 116:

                        if (locki[0] == -1) {
                            locki[0] = key;
                        }
                        if (key == locki[0])//If the symbol is already received from one of the rels, we do not process it from the other reels
                            startStopAnimation(LiveGlassSymbolsId.get(4) + "", LiveGlassAnimationId.get(5) + "", LiveGlassFramesId.get(2) + "", 0, state, reelSymbol);
                        break;
//Ace short animation
                    case 10:
//                    case 20:
                    case 39:
//                    case 49:
                    case 68:
//                    case 78:
                    case 97:
//                    case 107:
                    case 126:
//                    case 136:
                        if (locki[1] == -1) {
                            locki[1] = key;
                        }
                        if (key == locki[1])
                            startStopAnimation(LiveGlassSymbolsId.get(4) + "", LiveGlassAnimationId.get(17) + "", LiveGlassFramesId.get(2) + "", 1, state, reelSymbol);
                        break;
//King long animation
                    case 1:
                    case 30:
                    case 59:
                    case 88:
                    case 117:

                        if (locki[2] == -1) {
                            locki[2] = key;
                        }
                        if (key == locki[2])
                            startStopAnimation(LiveGlassSymbolsId.get(6) + "", LiveGlassAnimationId.get(11) + "", LiveGlassFramesId.get(2) + "", 2, state, reelSymbol);
                        break;
//King short animation
                    case 11:
//                    case 21:
                    case 40:
//                    case 50:
                    case 69:
//                    case 79:
                    case 98:
//                    case 108:
                    case 127:
//                    case 137:
                        if (locki[3] == -1) {
                            locki[3] = key;
                        }
                        if (key == locki[3])
                            startStopAnimation(LiveGlassSymbolsId.get(6) + "", LiveGlassAnimationId.get(18) + "", LiveGlassFramesId.get(2) + "", 3, state, reelSymbol);
                        break;
//Person long animation
                    case 7:
                    case 36:
                    case 65:
                    case 94:
                    case 123:

                        if (locki[4] == -1) {
                            locki[4] = key;
                        }
                        if (key == locki[4])
                            startStopAnimation(LiveGlassSymbolsId.get(0) + "", LiveGlassAnimationId.get(0) + "", LiveGlassFramesId.get(0) + "", 4, state, reelSymbol);
                        break;

//Person short animation
                    case 17:
//                    case 26:
                    case 46:
//                    case 55:
                    case 75:
//                    case 84:
                    case 104:
//                    case 113:
                    case 133:
//                    case 142:
                        if (locki[5] == -1) {
                            locki[5] = key;
                        }
                        if (key == locki[5])
                            startStopAnimation(LiveGlassSymbolsId.get(0) + "", LiveGlassAnimationId.get(16) + "", LiveGlassFramesId.get(0) + "", 5, state, reelSymbol);
                        break;
//Queen long animation
                    case 2:
                    case 31:
                    case 60:
                    case 89:
                    case 118:

                        if (locki[6] == -1) {
                            locki[6] = key;
                        }
                        if (key == locki[6])
                            startStopAnimation(LiveGlassSymbolsId.get(2) + "", LiveGlassAnimationId.get(2) + "", LiveGlassFramesId.get(1) + "", 6, state, reelSymbol);
                        break;
//Queen short animation
                    case 12:
//                    case 22:
                    case 41:
//                    case 51:
                    case 70:
//                    case 80:
                    case 99:
//                    case 109:
                    case 128:
//                    case 138:

                        if (locki[7] == -1) {
                            locki[7] = key;
                        }
                        if (key == locki[7])
                            startStopAnimation(LiveGlassSymbolsId.get(2) + "", LiveGlassAnimationId.get(19) + "", LiveGlassFramesId.get(1) + "", 7, state, reelSymbol);
                        break;
//Jack long animation
                    case 3:
                    case 32:
                    case 61:
                    case 90:
                    case 119:
                        if (locki[8] == -1) {
                            locki[8] = key;
                        }
                        if (key == locki[8])
                            startStopAnimation(LiveGlassSymbolsId.get(5) + "", LiveGlassAnimationId.get(10) + "", LiveGlassFramesId.get(1) + "", 8, state, reelSymbol);
                        break;
//Jack short animation
                    case 13:
//                    case 23:
                    case 42:
//                    case 52:
                    case 71:
//                    case 81:
                    case 100:
//                    case 110:
                    case 129:
//                    case 139:

                        if (locki[9] == -1) {
                            locki[9] = key;
                        }
                        if (key == locki[9])
                            startStopAnimation(LiveGlassSymbolsId.get(5) + "", LiveGlassAnimationId.get(20) + "", LiveGlassFramesId.get(1) + "", 9, state, reelSymbol);
                        break;
//Ten long animation
                    case 4:
                    case 33:
                    case 62:
                    case 91:
                    case 120:

                        if (locki[10] == -1) {
                            locki[10] = key;
                        }
                        if (key == locki[10])
                            startStopAnimation(LiveGlassSymbolsId.get(1) + "", LiveGlassAnimationId.get(3) + "", LiveGlassFramesId.get(1) + "", 10, state, reelSymbol);
                        break;

//Ten short animation
                    case 14:
//                    case 24:
                    case 43:
//                    case 53:
                    case 72:
//                    case 82:
                    case 101:
//                    case 111:
                    case 130:
//                    case 140:
                        if (locki[11] == -1) {
                            locki[11] = key;
                        }
                        if (key == locki[11])
                            startStopAnimation(LiveGlassSymbolsId.get(1) + "", LiveGlassAnimationId.get(1) + "", LiveGlassFramesId.get(1) + "", 11, state, reelSymbol);
                        break;
//  statueSymbol long
                    case 6:
                    case 35:
                    case 64:
                    case 93:
                    case 122:
                        if (locki[12] == -1) {
                            locki[12] = key;
                        }
                        if (key == locki[12])
                            startStopAnimation(LiveGlassSymbolsId.get(3) + "", LiveGlassAnimationId.get(4) + "", LiveGlassFramesId.get(3) + "", 12, state, reelSymbol);
                        break;
//  statueSymbol short animation
                    case 16:
//                    case 25:
                    case 45:
//                    case 54:
                    case 74:
//                    case 83:
                    case 103:
//                    case 112:
                    case 132:
//                    case 141:

                        if (locki[13] == -1) {
                            locki[13] = key;
                        }
                        if (key == locki[13])
                            startStopAnimation(LiveGlassSymbolsId.get(3) + "", LiveGlassAnimationId.get(23) + "", LiveGlassFramesId.get(3) + "", 13, state, reelSymbol);
                        break;
//scarab (snake) long animation
                    case 8:
                    case 37:
                    case 66:
                    case 95:
                    case 124:

                        if (locki[14] == -1) {
                            locki[14] = key;
                        }
                        if (key == locki[14])
                            startStopAnimation(LiveGlassSymbolsId.get(7) + "", LiveGlassAnimationId.get(12) + "", LiveGlassFramesId.get(4) + "", 14, state, reelSymbol);
                        break;
//scarab (snake) short animation
                    case 18:
//                    case 27:
                    case 47:
//                    case 56:
                    case 76:
//                    case 85:
                    case 105:
//                    case 114:
                    case 134:
//                    case 143:

                        if (locki[15] == -1) {
                            locki[15] = key;
                        }
                        if (key == locki[15])
                            startStopAnimation(LiveGlassSymbolsId.get(7) + "", LiveGlassAnimationId.get(21) + "", LiveGlassFramesId.get(4) + "", 15, state, reelSymbol);
                        break;
//Mummy(griffin) long animation
                    case 9:
                    case 38:
                    case 67:
                    case 96:
                    case 125:
                        if (locki[16] == -1) {
                            locki[16] = key;
                        }
                        if (key == locki[16])
                            startStopAnimation(LiveGlassSymbolsId.get(8) + "", LiveGlassAnimationId.get(15) + "", LiveGlassFramesId.get(5) + "", 16, state, reelSymbol);
                        break;

//Mummy(griffin) short animation
                    case 19:
//                    case 28:
                    case 48:
//                    case 57:
                    case 77:
//                    case 86:
                    case 106:
//                    case 115:
                    case 135:
//                    case 144:
                        if (locki[17] == -1) {
                            locki[17] = key;
                        }
                        if (key == locki[17])
                            startStopAnimation(LiveGlassSymbolsId.get(8) + "", LiveGlassAnimationId.get(22) + "", LiveGlassFramesId.get(5) + "", 17, state, reelSymbol);
                        break;

                }
            }
        }

        public void startStopAnimation(String symbol, String symbolAnimation, String winFrameAnimation, Integer integer, String state, KeyframeAnimationView reelSymbol) {
            lock = integer;
            upperAnimSymbol = mapUpperScreenSymbolsAnimation.get(symbolAnimation);
            if (reelSymbol.isPlaying() && reelSymbol.isVisible() && !GamblerIsStart.gamblerIsStart && state.equals("start")) {
                symbolsImageView.get(symbol).setVisible(false);
                mapUpperScreenSymbolsAnimation.get(winFrameAnimation).setVisible(true);
                upperAnimSymbol.setVisible(true);
                upperAnimSymbol.setAutoPlay(false);
                if (!upperAnimSymbol.isPlaying()) {
                    upperAnimSymbol.gotoAndPlay(reelSymbol.getCurrentFrameNumber());
                }
                if (!mapUpperScreenSymbolsAnimation.get(winFrameAnimation).isPlaying()) {
                    mapUpperScreenSymbolsAnimation.get(winFrameAnimation).gotoAndPlay(1);
                }
            } else {
//                stopIfGamble(winFrameAnimation,integer);
                mapUpperScreenSymbolsAnimation.get(winFrameAnimation).setVisible(false);
                upperAnimSymbol.setVisible(false);
                upperAnimSymbol.gotoAndPause(1);
                mapUpperScreenSymbolsAnimation.get(winFrameAnimation).gotoAndPause(1);
                symbolsImageView.get(symbol).setVisible(true);
                locki[integer] = -1;
            }
        }

        void stopIfGamble(String winFrameAnimation, Integer integer) {
            mapUpperScreenSymbolsAnimation.get(winFrameAnimation).setVisible(false);
            upperAnimSymbol.setVisible(false);
            upperAnimSymbol.gotoAndPause(1);
            mapUpperScreenSymbolsAnimation.get(winFrameAnimation).gotoAndPause(1);
            symbolsImageView.get(symbol).setVisible(true);
            locki[integer] = -1;
        }
    }

}


