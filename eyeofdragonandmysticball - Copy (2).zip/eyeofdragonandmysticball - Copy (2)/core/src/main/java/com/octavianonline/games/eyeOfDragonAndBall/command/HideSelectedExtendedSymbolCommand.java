package com.octavianonline.games.eyeOfDragonAndBall.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to hide feature special scatter symbol
 */
@Reflectable
public class HideSelectedExtendedSymbolCommand {

}
