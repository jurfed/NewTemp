package com.octavianonline.games.eyeOfDragonAndBall;

import javax.inject.Named;
import javax.inject.Singleton;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.utility.localization.LocalResourceTranslationProvider;
import com.atsisa.gox.games.ODebugReelsCoreModule;
import com.atsisa.gox.games.OExtendedSymbolModule;
import com.atsisa.gox.games.OctavianControlPanelModule;
import com.atsisa.gox.games.OctavianCoreModule;
import com.atsisa.gox.games.octavian.OctavianBigWinsModule;
import com.atsisa.gox.games.octavian.core.service.ReelsService;
import com.atsisa.gox.games.octavian.formatter.IOctavianFormatter;
import com.atsisa.gox.games.octavian.formatter.OctavianFormatter;
import com.atsisa.gox.games.octavian.reels.ODenominationModelProvider;
import com.atsisa.gox.reels.*;
import com.atsisa.gox.reels.message.processing.IMessageProcessor;
import com.atsisa.gox.reels.model.*;
import com.atsisa.gox.rng.IRngService;
import com.octavianonline.games.eyeOfDragonAndBall.logic.QueenCleopatraRngService;
import com.atsisa.gox.framework.configuration.GameConfiguration;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.framework.resource.ResourceDescriptionModel;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import com.atsisa.gox.reels.screen.ErrorScreen;
import com.atsisa.gox.reels.screen.FadeScreen;
import com.atsisa.gox.reels.screen.GamblerScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.octavianonline.games.eyeOfDragonAndBall.message.processing.QueenCleopatraFreeGamesMessageProcessor;
import com.octavianonline.games.eyeOfDragonAndBall.screen.*;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.framework.utility.GameConfigurationStatics;
import com.atsisa.gox.framework.utility.IConfigurationProperties;
import com.octavianonline.games.eyeOfDragonAndBall.screen.model.QueenCleopatraPayTableScreenModel;
import com.octavianonline.games.eyeOfDragonAndBall.screen.transitions.QueenCleopatraInfoScreenTransition;
import com.octavianonline.games.eyeOfDragonAndBall.screen.transitions.QueenCleopatraTopDownInfoScreenTransition;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoSet;

/**
 * Represents an IoC module configuration.
 */
@Module(includes = {
//        ReelsCoreModule.class,
//        DebugReelsCoreModule.class,
        ODebugReelsCoreModule.class,
        EyeOfDragonAndBallDemoGameLogicModule.class,
        OctavianControlPanelModule.class,
        OctavianCoreModule.class,
        ReelSpinModule.class,
        FreeGamesModule.class,
        OExtendedSymbolModule.class,
        OctavianBigWinsModule.class
        })


public abstract class EyeOfDragonAndBallDemoCoreModule {

    @Provides
    @Named(IConfigurationProperties.CONFIGURATION_PROPERTIES)
    static Map<String, String> configurationPropertiesBind() {
        Map<String, String> configurationProperties = new HashMap<>();
        configurationProperties.put(GameConfigurationStatics.GAME_RESOLUTION, "FHD_TWO_MONITORS");
//        configurationProperties.put(GameConfigurationStatics.WINDOW_Y, "-1080");
        return configurationProperties;
    }

    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel gameResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("EyeOfDragonAndBall", "resourcesDemo.xml");
    }

    @Binds
    @Singleton
    abstract IGameConfiguration gameConfigurationBind(GameConfiguration gameConfiguration);

    @Provides
    @Singleton
    static IMutator<ILinesModel> linesModelMutatorBind() {
        return new NoLinesModelMutator();
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.LAYOUT_ID_PROPERTY)
    static String gamblerScreenLayoutBind() {
        return "gamblerScreen";
    }

    @Singleton
    @Provides
    @Named(InfoScreen.LAYOUT_ID_PROPERTY)
    static String infoScreenLayoutBind() {
        return "infoScreen";
    }

/*    @Singleton
    @Provides
    @Named(WinLinesScreen.LAYOUT_ID_PROPERTY)
    static String winLineScreenLayoutBind() {
        return "winLinesScreen";
    }*/

    @Singleton
    @Provides
    @Named(EyeOfDragonWinLinesScreen.LAYOUT_ID_PROPERTY)
    static String winLineScreenLayoutBind() {
        return "winLinesScreen";
    }


    @Singleton
    @Provides
    @Named(BaseGameScreen.LAYOUT_ID_PROPERTY)
    static String baseGameScreenLayoutBind() {
        return "baseGameScreen";
    }

/*    @Provides
    @Singleton
    @Named(DebugScreen.LAYOUT_ID_PROPERTY)
    static String debugScreenLayoutBind() {
        return "debugScreen";
    }*/

    @Provides
    @Singleton
    @Named(EyeOfDragonAndBallDebugScreen.LAYOUT_ID_PROPERTY)
    static String debugScreenLayoutBind() {
        return "debugScreen";
    }

    @Provides
    @Singleton
    @Named(ErrorScreen.LAYOUT_ID_PROPERTY)
    static String errorScreenLayoutBind() {
        return "errorScreen";
    }

    @Singleton
    @Provides
    @Named(BottomPanelScreen.LAYOUT_ID_PROPERTY)
    static String controlPanelScreenLayoutBind() {
        return "controlPanelScreen";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.SHOW_INFO_SCREEN_SOUND_ID_PROPERTY)
    static String infoScreenShowSoundBind() {
        return "ShiftDef";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY)
    static String autoPlayOnSoundBind() {
        return "AutoPlayOff";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY)
    static String autoPlayOffSoundBind() {
        return "AutoPlayOn";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY)
    static String betChangingSoundBind() {
        return "BetChanging";
    }

    @Provides
    @Singleton
    @Named(FadeScreen.LAYOUT_ID_PROPERTY)
    static String fadeScreenLayoutBind() {
        return FadeScreen.LAYOUT_ID_DEFAULT;
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyReversedRedCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_red_card_reverse.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyClubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyDiamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyHeartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historySpadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_spade_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String spadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/spade_card.png";
    }

    @Singleton
    @Binds
    abstract IDenominationModelProvider bindIDenominationModelProvider(ODenominationModelProvider provider);

    @Singleton
    @Provides
    @Named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String clubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String heartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String diamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String reversedBlackCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/blue_card_reverse.png";
    }

    @Provides
    @Singleton
    static IRngService rngServiceBind() {
        return new QueenCleopatraRngService();
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(LocalResourceTranslationProvider.TRANSLATION_RESOURCE)
    static String languageListConfiguration() {
        return "LanguagesList";
    }

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen novolineControlPanelScreenBind(NovolineControlPanelScreen novolineControlPanelScreen);*/

/*    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel novolineResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("NovolineControlPanel", "resources.xml");
    }*/

/*    @Provides
    @Singleton
    @Named(NovolineControlPanelScreen.SHOW_GAME_INFO_EXECUTABLE)
    static IExecutable novolineShowGameInfoExecutableBind(IActionManager actionManager) {
        return new ActionQueueExecutable("ShowNextInfoScreen", actionManager);
    }*/

/*    @Provides
    @Singleton
    @Named(NovolineControlPanelScreen.ENTER_GAMBLER_EXECUTABLE)
    static IExecutable novolineEnterGamblerExecutableBind(IActionManager actionManager) {
        return new ActionQueueExecutable("EnteringGambler", actionManager);
    }*/

    @Binds
    @Singleton
    abstract ITranslationProvider translationProviderBind(LocalResourceTranslationProvider localResourceTranslationProvider);

    @Provides
    @Named(BottomPanelScreen.BUTTON_STATES_RESOURCES_ID)
    static Set<String> buttonStatesResourcesId() {
        HashSet<String> resources = new HashSet<>();
        resources.add("buttonStates");
        return resources;
    }


    @Binds
    @Singleton
    abstract IGame gameBind(EyeOfDragonAndBallDemo game);

/*    @Binds
    @Singleton
    abstract ILinesModelProvider linesModelProviderBind(OLinesModelProvider linesModelProvider);*/

    @Singleton
    abstract GamblerScreenModel gamblerScreenModelBind();

    @Singleton
    abstract BottomPanelScreenModel bottomPanelScreenModelBind();

    @Binds
    @Singleton
    @IntoSet
    abstract Screen gamblerScreenBind(EyeOfDragonAndBallGamblerScreen gamblerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen infoScreenBind(EyeOfDragonAndBallInfoScreen infoScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen baseGameScreenBind(EyeOfDragonAndBallBaseGameScreen baseGameScreen);

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen debugScreenBind(DebugScreen debugScreen);*/

    @Binds
    @Singleton
    @IntoSet
    abstract Screen debugScreenBind(EyeOfDragonAndBallDebugScreen debugScreen);

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen winLinesScreenBind(WinLinesScreen winLinesScreen);*/

    @Binds
    @Singleton
    @IntoSet
    abstract Screen winLinesScreenBind(EyeOfDragonWinLinesScreen winLinesScreen);

    @Singleton
    abstract EyeOfDragonWinLinesScreenModel bindWinLinesScreenModel();

    @Binds
    @Singleton
    @IntoSet
    abstract Screen errorScreenBind(ErrorScreen errorScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen fadeScreenBind(FadeScreen fadeScreen);

    @Singleton
    @Provides
    @Named(EyeOfDragonAndBallPaytableScreen.LAYOUT_ID_PROPERTY)
    static String payTableScreenLayoutBind() {
        return "payTableScreen";
    }

    @Provides
    @Singleton
    @IntoSet
    static Screen payTableScreenBind(IGameConfiguration gameConfiguration, @Named(EyeOfDragonAndBallPaytableScreen.LAYOUT_ID_PROPERTY) String layoutId,
                                     QueenCleopatraPayTableScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus,
                                     QueenCleopatraInfoScreenTransition infoScreenTransition) {
        return new EyeOfDragonAndBallPaytableScreen(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);
    }

    @Singleton
    abstract QueenCleopatraPayTableScreenModel payTableScreenModelBind();

    @Binds
    @Singleton
    abstract IValueFormatter bindIValueFormatter(OctavianFormatter formatter);

    @Singleton
    @Provides
    @Named(IOctavianFormatter.DENOMINATION_CURRENCY_CODE)
    static String bindDenominationCurrencyCode() {
        return "\u00A2";
//        return "c";
    }

    @Binds
    @Singleton
    abstract ICreditsFormatter creditsFormatterBind(OctavianFormatter creditsFormatter);

    @Singleton
    @Provides
    @Named(EyeOfDragonAndBallEnterFeatureBannerScreen.LAYOUT_ID_PROPERTY)
    static String enterFeatureBannerScreenLayoutBind() {
        return "enterFeatureBannerScreen";
    }

    @Binds
    @Singleton
    @IntoSet
    abstract Screen enterFeatureBannerScreenBind(EyeOfDragonAndBallEnterFeatureBannerScreen enterFeatureBannerScreen);

    @Singleton
    @Provides
    @Named(EyeOfDragonAndBallFreeGamesBannerScreen.LAYOUT_ID_PROPERTY)
    static String freeGamesBannerScreenLayoutBind() {
        return "freeGamesBannerScreen";
    }

    @Binds
    @Singleton
    @IntoSet
    abstract Screen freeGamesBannerScreenBind(EyeOfDragonAndBallFreeGamesBannerScreen freeGamesBannerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract IMessageProcessor gamesMessageProcessorBind(QueenCleopatraFreeGamesMessageProcessor gamesMessageProcessor);

    @Provides
    @Singleton
    static QueenCleopatraInfoScreenTransition infoScreenTransitionBind() {
        return new QueenCleopatraTopDownInfoScreenTransition();
    }

    @Provides
    @Singleton
    static ReelsService bindReelsService(IEventBus eventBus, @Named(BaseGameScreen.LAYOUT_ID_PROPERTY) String baseScreenLayoutId) {
        return new ReelsService(eventBus, baseScreenLayoutId, "reelGroupView");
    }
}
