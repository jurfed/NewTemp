package com.octavianonline.games.eyeOfDragonAndBall.action.freeGames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.StartControlPanelWinCollectCommand;
import com.atsisa.gox.reels.AbstractReelGame;
import com.octavianonline.games.eyeOfDragonAndBall.action.collect.FinishCollect;

public class InitCollectAction extends Action {
    @Override
    protected void execute() {

        long totalWinAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        int collectTime = (int) (totalWinAmount * 2);
        FinishCollect.setBeginTime(System.currentTimeMillis());
        FinishCollect.setCollectTime(collectTime);
        eventBus.post(new StartControlPanelWinCollectCommand(collectTime, 0, totalWinAmount));
        finish();
    }
}
