package com.octavianonline.games.eyeOfDragonAndBall.helpers;

import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;

public interface BottomPanelHelper{
    public TextView getIndicatorTextID1();
    public TextView getIndicatorTextID2();

    public void setSkipEnable(boolean setEnable);
    public void initializeIndicatorTextIDs();
    public View getWinView();
//    public boolean getSkipEnable();


    public default boolean getTurbomode() {
        return false;
    }

    public void setIndicatorSum(Long winSum) ;

    public Long getIndicatorSum();

    public boolean isCollectPlaying();

    public void setCollectPlaying(boolean collectPlaying);

}
