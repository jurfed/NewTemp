package com.octavianonline.games.eyeOfDragonAndBall.event;

public class TestEvent {
}
