package com.octavianonline.games.eyeOfDragonAndBall.action.collect;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.FinishControlPanelWinCollectCommand;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.TransferCreditsCommand;
import com.octavianonline.games.eyeOfDragonAndBall.screen.EyeOfDragonAndBallBaseGameScreen;

public class TransferWinCustom extends Action {
    @Override
    protected synchronized void execute() {



        long totalWinAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        long freeGamesWinAmount = EyeOfDragonAndBallBaseGameScreen.getAllFreeGamesAmount();

        if (freeGamesWinAmount != 0) {
            totalWinAmount = freeGamesWinAmount;
        }
        if(totalWinAmount>0){
            this.eventBus.post(new TransferCreditsCommand(totalWinAmount));
            this.eventBus.post(new FinishControlPanelWinCollectCommand());
            EyeOfDragonAndBallBaseGameScreen.setAllFreeGamesAmount(0);
        }

//        TRexTrackBaseGameScreen.resetFreeGamesWinAmount();
        this.finish();
    }
}
