package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.IGameEngine;
import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component(modules = { QueenCleopatraWebModule.class })
public interface QueenCleopatraWebContainer {

    IGameEngine gameEngine();
}
