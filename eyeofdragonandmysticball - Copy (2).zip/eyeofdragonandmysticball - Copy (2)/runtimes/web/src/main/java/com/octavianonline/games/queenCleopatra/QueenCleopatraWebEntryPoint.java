package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.HtmlGameEntryPoint;
import com.atsisa.gox.framework.IGameEngine;

public class QueenCleopatraWebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "EyeOfDragonAndBall";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

    @Override
    protected IGameEngine createGameEngine() {
        QueenCleopatraWebContainer container = DaggerQueenCleopatraWebContainer.builder().build();
        return container.gameEngine();
    }
}
