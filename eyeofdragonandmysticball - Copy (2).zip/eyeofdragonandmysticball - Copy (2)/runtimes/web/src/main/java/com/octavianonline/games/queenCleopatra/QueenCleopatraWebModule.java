package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.FrameworkWebModule;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.financial.IFinancialTransaction;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

@Module(includes = { QueenCleopatraCoreModule.class, FrameworkWebModule.class})
abstract class QueenCleopatraWebModule {

    @Singleton
    @Provides
    static IBalance gameBalanceBind(){
        return new QueenCleopatraBalance();
    }

    @Binds
    @Singleton
    abstract IFinancialTransaction financialTransactionBind(FinancialTransaction transaction);
    }
