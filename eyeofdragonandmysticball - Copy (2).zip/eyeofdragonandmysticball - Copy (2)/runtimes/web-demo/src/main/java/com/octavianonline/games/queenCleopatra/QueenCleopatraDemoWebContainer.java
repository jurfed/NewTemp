package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.IGameEngine;
import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component(modules = { QueenCleopatraDemoWebModule.class })
public interface QueenCleopatraDemoWebContainer {

    IGameEngine gameEngine();
}
