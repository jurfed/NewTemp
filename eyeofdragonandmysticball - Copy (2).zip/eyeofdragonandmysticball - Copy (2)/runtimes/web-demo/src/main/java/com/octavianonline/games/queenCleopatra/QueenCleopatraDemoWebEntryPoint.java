package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.framework.HtmlGameEntryPoint;
import com.atsisa.gox.framework.IGameEngine;

public class QueenCleopatraDemoWebEntryPoint extends HtmlGameEntryPoint {

    private static final String GAME_NAME = "EyeOfDragonAndBall";

    @Override
    protected String getGameName() {
        return GAME_NAME;
    }

    @Override
    protected IGameEngine createGameEngine() {
        QueenCleopatraDemoWebContainer container = DaggerQueenCleopatraDemoWebContainer.builder().build();
        return container.gameEngine();
    }
}
