package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.financial.FinancialException;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.financial.IBalanceListener;

/**
 * Contains implementation of the game balance.
 */
public class QueenCleopatraBalance implements IBalance {

    private long credits = 10000L;

    @Override
    public long getBalance() throws FinancialException {
        return credits;
    }

    @Override
    public AutoCloseable addBalanceListener(IBalanceListener iBalanceListener) {
        return () -> {};
    }

    public void setCredits(long credits) {
        this.credits = credits;
    }
}