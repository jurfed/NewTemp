package com.octavianonline.games.eyeOfDragonAndBall;

import com.atsisa.gox.financial.FinancialException;
import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.financial.IFinancialTransaction;

import javax.inject.Inject;

/**
 * Contains implementation of the financial transaction class.
 */
public class FinancialTransaction implements IFinancialTransaction {

    /**
     * The game balance.
     */
    private final IBalance balance;

    @Inject
    public FinancialTransaction(IBalance balance) {
        this.balance = balance;
    }

    @Override
    public IAccount beginTransaction() throws FinancialException {
        return new IAccount() {

            @Override
            public void withdraw(long amount) throws FinancialException {
                QueenCleopatraBalance gameBalance = (QueenCleopatraBalance) balance;
                gameBalance.setCredits(balance.getBalance() - amount);
            }

            @Override
            public void deposit(long amount) throws FinancialException {
                QueenCleopatraBalance gameBalance = (QueenCleopatraBalance) balance;
                gameBalance.setCredits(balance.getBalance() + amount);
            }
        };
    }

    @Override
    public void commit() throws FinancialException {

    }
}