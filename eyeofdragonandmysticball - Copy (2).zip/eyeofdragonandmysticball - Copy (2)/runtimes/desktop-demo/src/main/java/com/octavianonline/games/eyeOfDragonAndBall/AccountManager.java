package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.UUID;
import javax.inject.Inject;
import javax.inject.Singleton;

import com.atsisa.gox.financial.FinancialException;
import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.financial.IBalanceListener;

@Singleton
public class AccountManager implements IBalance, IAccount {

    private long credits = 10000000;

    @Inject
    public AccountManager() {
    }

    @Override
    public void withdraw(long amount, UUID transactionId) throws FinancialException {
        credits -= amount;
    }

    @Override
    public void deposit(long amount, UUID transactionId) throws FinancialException {
        credits += amount;
    }

    @Override
    public long getBalance() throws FinancialException {
        return credits;
    }

    @Override
    public AutoCloseable addBalanceListener(IBalanceListener balanceListener) {
        return () -> {};
    }
}
