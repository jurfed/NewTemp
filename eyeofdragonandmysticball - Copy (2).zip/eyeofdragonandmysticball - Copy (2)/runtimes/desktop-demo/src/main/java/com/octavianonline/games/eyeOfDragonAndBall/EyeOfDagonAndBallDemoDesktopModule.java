package com.octavianonline.games.eyeOfDragonAndBall;
import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import dagger.Binds;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import dagger.Module;

@Module(includes = { EyeOfDragonAndBallDemoCoreModule.class, FrameworkDesktopModule.class })
abstract class EyeOfDagonAndBallDemoDesktopModule {

    @Binds abstract IBalance gameBalanceBind(AccountManager accountManager);

    @Binds abstract IAccount accountBind(AccountManager accountManager);
}
