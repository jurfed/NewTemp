package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.utility.ServicesType;
import com.atsisa.gox.framework.utility.logger.ILogger;
import dagger.Component;

import javax.inject.Named;
import javax.inject.Singleton;

@Singleton
@Component(modules = { EyeOfDagonAndBallDemoDesktopModule.class })
public interface EyeOfDagonAndBallDemoDesktopContainer {
    IGameEngine gameEngine();

    ILogger getLogger();

    @Named(ServicesType.CONTROLLERS)
    Map<Class<?>, Object> getControllers();
}
