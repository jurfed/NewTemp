package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.framework.utility.logger.LogLevel;

public class EyeOfDagonAndBallDemoDesktopEntryPoint extends JavaGameEntryPoint {

    private Map<Class<?>, Object> controllerRegistry;

    public static void main(String[] args) throws Exception {
        new EyeOfDagonAndBallDemoDesktopEntryPoint().start();
    }

    @Override
    protected IGameEngine createGameEngine() {
        System.err.println("Start\t" + System.nanoTime()/1000000000);
        EyeOfDagonAndBallDemoDesktopContainer container = DaggerEyeOfDagonAndBallDemoDesktopContainer.builder().build();
        controllerRegistry = container.getControllers();
        container.getLogger().setLevel(LogLevel.WARN);
        return container.gameEngine();
    }

    @Override
    public Map<Class<?>, Object> getServiceRegistry() {
        return controllerRegistry;
    }
}
