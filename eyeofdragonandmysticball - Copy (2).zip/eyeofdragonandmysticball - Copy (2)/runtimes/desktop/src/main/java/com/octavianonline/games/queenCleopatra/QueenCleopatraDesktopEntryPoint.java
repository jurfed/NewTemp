package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.JavaGameEntryPoint;

public class QueenCleopatraDesktopEntryPoint extends JavaGameEntryPoint {

    private Map<Class<?>, Object> controllerRegistry;

    public static void main(String[] args) throws Exception {
        new QueenCleopatraDesktopEntryPoint().start();
    }

    @Override
    protected IGameEngine createGameEngine() {
        QueenCleopatraDesktopContainer container = DaggerQueenCleopatraDesktopContainer.builder().build();
        controllerRegistry = container.getControllers();
        return container.gameEngine();
    }

    @Override
    public Map<Class<?>, Object> getServiceRegistry() {
        return controllerRegistry;
    }
}
