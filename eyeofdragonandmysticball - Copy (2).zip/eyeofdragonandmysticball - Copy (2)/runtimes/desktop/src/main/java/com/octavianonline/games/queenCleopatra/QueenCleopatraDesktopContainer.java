package com.octavianonline.games.eyeOfDragonAndBall;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.utility.ServicesType;
import dagger.Component;

import javax.inject.Named;
import javax.inject.Singleton;

@Singleton
@Component(modules = { QueenCleopatraDesktopModule.class })
public interface QueenCleopatraDesktopContainer {
    IGameEngine gameEngine();

    @Named(ServicesType.CONTROLLERS)
    Map<Class<?>, Object> getControllers();
}
