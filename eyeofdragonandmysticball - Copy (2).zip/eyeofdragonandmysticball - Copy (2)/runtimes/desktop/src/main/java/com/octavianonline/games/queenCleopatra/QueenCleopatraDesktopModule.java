package com.octavianonline.games.eyeOfDragonAndBall;
import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import dagger.Binds;
import com.atsisa.gox.framework.FrameworkDesktopModule;
import dagger.Module;

@Module(includes = { QueenCleopatraCoreModule.class, FrameworkDesktopModule.class })
abstract class QueenCleopatraDesktopModule{

    @Binds abstract IBalance gameBalanceBind(AccountManager accountManager);

    @Binds abstract IAccount accountBind(AccountManager accountManager);
}
