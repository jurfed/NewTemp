package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.action.Action;

public class Temp extends Action {
    @Override
    protected void execute() {
        finish();
    }
}
