package com.atsisa.gox.games.trextrack.screen.model;

import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class WinLinesScreenModel extends ScreenModel {

    /**
     * To match the names of characters and skins
     */
    private Map<String, String> winLinesSymbolsSkin = new HashMap<>();

    /**
     * Flag for starting analyze win lines
     */
    private boolean canAnalize = true;

    @Inject
    public WinLinesScreenModel(ITranslator translator) {
        super(translator);
        winLinesSymbolsSkin.put("Green", "symbol1WinAnimation");
        winLinesSymbolsSkin.put("Green2", "symbol1WinAnimation2");
        winLinesSymbolsSkin.put("Yellow", "symbol2WinAnimation");
        winLinesSymbolsSkin.put("Yellow2", "symbol2WinAnimation2");
        winLinesSymbolsSkin.put("Pink", "symbol3WinAnimation");
        winLinesSymbolsSkin.put("Pink2", "symbol3WinAnimation2");
        winLinesSymbolsSkin.put("Blue", "symbol4WinAnimation");
        winLinesSymbolsSkin.put("Blue2", "symbol4WinAnimation2");
        winLinesSymbolsSkin.put("Violet", "symbol5WinAnimation");
        winLinesSymbolsSkin.put("Violet2", "symbol5WinAnimation2");
        winLinesSymbolsSkin.put("SymbolA", "symbolAWinAnimation");
        winLinesSymbolsSkin.put("SymbolK", "symbolKWinAnimation");
        winLinesSymbolsSkin.put("SymbolQ", "symbolQWinAnimation");
        winLinesSymbolsSkin.put("SymbolJ", "symbolJWinAnimation");
        winLinesSymbolsSkin.put("Symbol10", "symbol10WinAnimation");
        winLinesSymbolsSkin.put("Scatter", "scatterSymbolAnimation");
        winLinesSymbolsSkin.put("TrackR", "symbol4WinAnimation");
        winLinesSymbolsSkin.put("Track", "symbol4WinAnimation");
        winLinesSymbolsSkin.put("Wild", "wildSymbolAnimation");
        winLinesSymbolsSkin.put("Wild2", "wild2SymbolAnimation");
    }

    public Map getSymbolsSkin() {
        return winLinesSymbolsSkin;
    }


    public boolean isCanAnalize() {
        return canAnalize;
    }

    public void setCanAnalize(boolean canAnalize) {
        this.canAnalize = canAnalize;
    }

    private final static Map<String, String> winSymbolsSounds = new HashMap() {{
        put("Violet","win_Violet");
        put("Blue","win_Blue");
        put("Green","win_Green");
        put("Yellow","win_Yellow");
        put("Pink","win_Pink");
        put("Green2","win_Green");
        put("Yellow2","win_Yellow");
        put("Pink2","win_Pink");
        put("Blue2","win_Blue");
        put("Violet2","win_Violet");
    }};

    public static Map<String, String> getWinSymbolsSounds() {
        return winSymbolsSounds;
    }
}
