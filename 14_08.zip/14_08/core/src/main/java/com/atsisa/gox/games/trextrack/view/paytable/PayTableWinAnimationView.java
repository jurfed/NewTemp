/*
package com.atsisa.gox.games.trextrack.view.paytable;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.Subscription;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlCollectionElement;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.ViewGroup;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

*/
/**
 * View for win animation on the pay table
 * includes text animation and KeyFrames animation
 *//*

@XmlElement
public class PayTableWinAnimationView extends ViewGroup {

    */
/**
     * Set for coefficients of winning indexes
     *//*

    private Set<Integer> winIndicatorsIndexes = new HashSet<>();

    */
/**
     * if the animation is playing now
     *//*

    private boolean isPlaying = false;

    */
/**
     * Set with image indexes, which need to be made invisible while animation playing
     *//*

    private Set<Integer> invisibleIndexes = new HashSet<>();

    */
/**
     * Set witch key frame animation indexes witch must be animating
     *//*

    private Set<Integer> keyFrameIndexes = new HashSet<>();
    private Set<KeyframeAnimationView> keyframesThatBecomsInvisibleAtTheEnd = new HashSet<>();

    */
/**
     * indicates that when synchronizing, the main frame starts flashing his text
     *//*

    private static volatile boolean textFlashing = false;

    */
/**
     * notifies other frames when the text is blinking in the main frame
     *//*

    Subscription subscription;

    */
/**
     * For start playing animation
     *
     * @param winIndicatorsIndexes - list with text indexes that must be playing
     * @param keyFrameIndexes      - list with key Frame animation indexes wich can be playing
     * @param invisibleIndexes     - list with images wich must be invisible while playing
     *//*

    public void playAnimation(Set<Integer> winIndicatorsIndexes, Set<Integer> keyFrameIndexes, Set<Integer> invisibleIndexes) {
        this.invisibleIndexes = invisibleIndexes;
        this.winIndicatorsIndexes = winIndicatorsIndexes;
        this.keyFrameIndexes = keyFrameIndexes;
        isPlaying = true;
        playIndicators();
        playKeyFrames();
        invisibleImages();

    }

    */
/**
     * For start playing animation
     *
     * @param winIndicators   - list with text indexes that must be playing
     * @param keyFrameIndexes - list with key Frame animation indexes wich can be playing
     *//*

    public void playAnimation(Set<Integer> winIndicators, Set<Integer> keyFrameIndexes) {
        this.invisibleIndexes = null;
        this.winIndicatorsIndexes = winIndicators;
        this.keyFrameIndexes = keyFrameIndexes;
        isPlaying = true;
        playIndicators();
        playKeyFrames();
        invisibleImages();
    }

    */
/**
     * For start playing animation
     *
     * @param winIndicators - list with text indexes that must be playing
     *//*

    public void playAnimation(Set<Integer> winIndicators) {
        this.invisibleIndexes = null;
        this.winIndicatorsIndexes = winIndicators;
        this.keyFrameIndexes = null;
        isPlaying = true;
        playIndicators();
        playKeyFrames();
        invisibleImages();
    }

    */
/**
     * For start playing animation
     *//*

    public void playAnimation() {
        this.invisibleIndexes = null;
        this.winIndicatorsIndexes = new HashSet<>();
        this.keyFrameIndexes = null;
        isPlaying = true;
        playKeyFrames();
        invisibleImages();
    }

    */
/**
     * stops all animation
     *//*

    public void stopAnimation() {
        isPlaying = false;
        stopKeyFrames();
        visibleImages();
        stopIndicators();
        textFlashing = false;
        if (subscription != null) {
            subscription.unsubscribe();
        }
    }

    */
/**
     * start playing all keyframes or which the user indicated
     *//*

    private void playKeyFrames() {
        if (animations != null && keyFrameIndexes != null) {
            keyFrameIndexes.forEach(index -> {
                animations.get(index).setVisible(true);
                animations.get(index).play();
            });
        } else if (animations != null && keyFrameIndexes == null) {
            animations.stream().forEach(animation -> {
                animation.setVisible(true);
                animation.play();
            });
        }
    }

    */
/**
     * sets invisible all images or which the user indicated
     *//*

    private void invisibleImages() {
        if (invisibles != null && invisibleIndexes != null) {
            this.invisibleIndexes.stream().forEach(index ->
            {
                this.invisibles.get(index).setVisible(false);
            });
        } else if (invisibles != null && invisibleIndexes == null) {
            this.invisibles.stream().forEach(invisible -> {
                invisible.setVisible(false);
            });

        }
    }

    */
/**
     * for stop playing key frames animation
     *//*

    private void stopKeyFrames() {
        if (animations != null) {
            this.animations.stream().forEach(animation -> {
                animation.stop();
            });

            keyframesThatBecomsInvisibleAtTheEnd.stream().forEach(animation -> {
                animation.setVisible(false);
            });
        }

    }

    */
/**
     * sets visible all images or which the user indicated
     *//*

    private void visibleImages() {
        if (invisibles != null && invisibleIndexes != null) {
            this.invisibleIndexes.stream().forEach(index ->
            {
                this.invisibles.get(index).setVisible(true);
            });
        } else if (invisibles != null && invisibleIndexes == null) {
            this.invisibles.stream().forEach(invisible -> {
                invisible.setVisible(true);
            });
        }
    }


    */
/**
     * method for select key frame animation index from witch animation must be playing
     *
     * @param keyFrameIndexs
     *//*

    public void setStartAnimationIndexes(HashMap<Integer, Integer> keyFrameIndexs) {
        keyFrameIndexs.forEach((index, value) -> {
            KeyframeAnimationView animation = animations.get(index);
            if (animation.isPlaying()) {
                animations.get(index).gotoAndPlay(value);
            } else {
                animations.get(index).gotoAndPause(value);
            }
        });
    }

    */
/**
     * start flashing texts
     *//*

    private void playIndicators() {
        playTextIndicators = new PlayTextIndicators();
        firstTextFlsh();
    }

    */
/**
     * stop flashing texts
     *//*

    private void stopIndicators() {
        if (winIndicatorsIndexes.size() > 0) {
            setWinSkin(false);
        }
    }

    */
/**
     * flashing text by timeout
     *//*

    class PlayTextIndicators implements TimeoutCallback {

        @Override
        public void onTimeout() {
            playTextIndicators();
        }
    }

    */
/**
     * First step for flashing text.
     * If text not flashing yet and flag synchronizedTextFlashing="true" then start flashing timer for main frame.
     * In this case other frames listen to the event ChangeFontEvent.
     * <p>
     * Or if flag synchronizedTextFlashing="false" then start flashing timer for any frame. This frames don't listen the event ChangeFontEvent.
     *//*

    private void firstTextFlsh() {
        if (!textFlashing && synchronizedTextFlashing || !synchronizedTextFlashing) {
            if (!textFlashing && synchronizedTextFlashing) {
                textFlashing = true;
            }
            new Timeout(DELAY_BEFORE_POST_EVENT_FOR_TEXT_FLASHING, () -> {
                playTextIndicators();
            }, true);
        } else {
            subscription = GameEngine.current().getEventBus().register(new ChangeFontObserver(), ChangeFontEvent.class);
        }
    }

    */
/**
     * Change the font for the text for flashing it and notifies listeners
     *//*

    private void playTextIndicators() {
        if (isPlaying && winIndicatorsIndexes.size() > 0) {
            if (indicatorsChanged) {
                setWinSkin(true);
                GameEngine.current().getEventBus().post(new ChangeFontEvent(true));
                indicatorsChanged = false;
            } else {
                setWinSkin(false);
                GameEngine.current().getEventBus().post(new ChangeFontEvent(false));
                indicatorsChanged = true;
            }
            playTextIndicators = new PlayTextIndicators();
            new Timeout(timeInterval, playTextIndicators, true);
        }
    }

    */
/**
     * Change the font for the text for flashing it
     *
     * @param winSkin
     *//*

    private void setWinSkin(boolean winSkin) {
        String staticSkin;
        String activeSkin;
        if (winSkin) {
            staticSkin = indicatorsSkins.getChangedStatic();
            activeSkin = indicatorsSkins.getChangedActive();
        } else {
            staticSkin = indicatorsSkins.getNormalStatic();
            activeSkin = indicatorsSkins.getNormalActive();
        }


        for (int i = 0; i < staticTexts.size(); i++) {
            for (int winIndicatorsIndexe : winIndicatorsIndexes) {
                if ((winIndicatorsIndexe + indicatorPrefix).equals(staticTexts.get(i).getText())) {
                    staticTexts.get(i).setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(staticSkin));
                    activeTexts.get(i).setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(activeSkin));
                }
            }
        }

    }

    */
/**
     * Class for sending events to the listeners about changing the text font (flashing)
     *//*

    public class ChangeFontEvent {
        private boolean eventChanged = false;

        public ChangeFontEvent(boolean value) {
            eventChanged = value;
        }

        public boolean isEventChanged() {
            return eventChanged;
        }

        public void setEventChanged(boolean eventChanged) {
            this.eventChanged = eventChanged;
        }
    }

    */
/**
     * listens the ChangeFontEvent event and changes the text font
     *//*

    private class ChangeFontObserver extends NextObserver<ChangeFontEvent> {

        @Override
        public void onNext(ChangeFontEvent changeFontEvent) {
            setWinSkin(changeFontEvent.eventChanged);
        }
    }

    //getters and setters
    PlayTextIndicators playTextIndicators;

    @XmlAttribute(type = Boolean.class)
    private boolean synchronizedTextFlashing = true;

    public boolean getSynchronizedTextFlashing() {
        return this.synchronizedTextFlashing;
    }

    public void setSynchronizedTextFlashing(boolean synchronizedTextFlashing) {
        this.synchronizedTextFlashing = synchronizedTextFlashing;
    }

    @XmlCollectionElement(name = TEXTS_TYPE_STATIC, itemType = TextView.class, itemName = TEXT_TYPE_STATIC)
    private List<TextView> staticTexts;


    public void setStaticTexts(List<TextView> staticTexts) {
        this.staticTexts = staticTexts;
        this.staticTexts.stream().forEach(textView -> {
            textView.setDepth(Integer.MAX_VALUE);
            this.addChild(textView);
        });
    }

    public List<TextView> getStaticTexts() {
        return staticTexts;
    }

    @XmlCollectionElement(name = TEXTS_TYPE_ACTIVE, itemType = TextView.class, itemName = TEXT_TYPE_ACTIVE)
    private List<TextView> activeTexts;

    public void setActiveTexts(List<TextView> activeTexts) {
        this.activeTexts = activeTexts;
        this.activeTexts.stream().forEach(textView -> {
            textView.setDepth(Integer.MAX_VALUE);
            this.addChild(textView);
        });
    }

    public List<TextView> getActiveTexts() {
        return activeTexts;
    }

    @XmlCollectionElement(name = "animations", itemType = KeyframeAnimationView.class, itemName = "animation")
    private List<KeyframeAnimationView> animations;

    public List<KeyframeAnimationView> getAnimations() {
        return animations;
    }

    public void setAnimations(List<KeyframeAnimationView> animations) {
        this.animations = animations;
        this.animations.stream().forEach(animation -> {
            addChild(animation);
            if (!animation.isVisible()) {
                keyframesThatBecomsInvisibleAtTheEnd.add(animation);
            }
        });
    }


    @XmlCollectionElement(name = "invisibles", itemType = ImageView.class)
    private List<ImageView> invisibles;

    public List<ImageView> getInvisibles() {
        return invisibles;
    }

    public void setInvisibles(List<ImageView> invisibles) {
        this.invisibles = invisibles;
        this.invisibles.stream().forEach(invisible -> {
            addChild(invisible);
        });
    }

    @XmlAttribute(type = Integer.class)
    private Integer timeInterval;

    public Integer getTimeInterval() {
        return timeInterval;
    }

    public void setTimeInterval(Integer timeInterval) {
        this.timeInterval = timeInterval;
    }

    private boolean indicatorsChanged = false;

    @XmlAttribute(type = String.class)
    private String indicatorPrefix;

    public String getIndicatorPrefix() {
        return indicatorPrefix;
    }

    public void setIndicatorPrefix(String indicatorPrefix) {
        this.indicatorPrefix = indicatorPrefix;
    }

    @XmlElement(type = IndicatorsSkins.class)
    private IndicatorsSkins indicatorsSkins;

    public IndicatorsSkins getIndicatorsSkins() {
        return indicatorsSkins;
    }

    public void setIndicatorsSkins(IndicatorsSkins indicatorsSkins) {
        this.indicatorsSkins = indicatorsSkins;
    }

    private final static int DELAY_BEFORE_POST_EVENT_FOR_TEXT_FLASHING = 200;
    private final static String TEXTS_TYPE_STATIC = "staticTexts";
    private final static String TEXT_TYPE_STATIC = "staticText";
    private final static String TEXTS_TYPE_ACTIVE = "activeTexts";
    private final static String TEXT_TYPE_ACTIVE = "activeText";
}
*/
