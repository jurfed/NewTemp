package com.atsisa.gox.games.trextrack.logic;

import com.atsisa.gox.logic.FreeGameSpinResult;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.SpinRequest;
import com.atsisa.gox.reels.backend.IStep;
import com.atsisa.gox.reels.backend.adapter.ReelConverter;
import com.atsisa.gox.reels.backend.adapter.WinConverter;
import com.atsisa.gox.reels.logic.FreeGamesInfoResult;
import com.atsisa.gox.reels.logic.FreeGamesInfoType;
import com.atsisa.gox.reels.logic.FreeGamesProgressResult;
import com.atsisa.gox.reels.logic.model.GameplayProperties;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;

import java.util.HashMap;
import java.util.Map;

public class FixedParseFreeGameSpinResult implements IStep {
    private final SpinRequest spinRequest;
    private final FreeGameSpinResult freeGameSpinResult;
    private final int totalFreeGames;
    private final ReelConverter reelConverter = new ReelConverter();
    private final WinConverter winConverter = new WinConverter();
    private final long totalWin;
    private final long currentWin;
    private static final String NEXT_FREE_GAME_PRESENTATION = "FreeGameNext";
    private static final String FREE_GAMES_END_PRESENTATION = "FreeGamesWin";
    private final Map<Integer, String> reelStripStopSounds;
    private  Map<Integer, String> winSounds;
    private  Map<Integer, String> winAnimations;
//    private final Map<Integer, String> winAnimations;

    public FixedParseFreeGameSpinResult(SpinRequest spinRequest, FreeGameSpinResult freeGameSpinResult, int totalFreeGames, long currentWin, long totalWin, Map<Integer, String> reelStripStopSounds, Map<Integer, String> winSounds, Map<Integer, String> winAnimations) {
        this.spinRequest = spinRequest;
        this.freeGameSpinResult = freeGameSpinResult;
        this.totalFreeGames = totalFreeGames;
        this.totalWin = totalWin;
        this.currentWin = currentWin;
        this.reelStripStopSounds = reelStripStopSounds;
        this.winSounds = winSounds;
        this.winAnimations = winAnimations;

    }

    public Map<String, Object> execute(Map<String, Object> logicPresentationMap) throws GameLogicException {
        ReelGamePresentation reelGamePresentation = new ReelGamePresentation("FreeGameNext", new GameplayProperties(this.spinRequest.getLines(), this.spinRequest.getBet(), this.freeGameSpinResult.getBalance()), this.reelConverter.convert(this.freeGameSpinResult.getStopSymbols(), this.reelStripStopSounds), false, false);
        logicPresentationMap.put(ReelGamePresentation.class.getName(), reelGamePresentation);
        WinningPresentation winningPresentation;
        if (this.freeGameSpinResult.getFreeGamesPlayed() != this.totalFreeGames) {
            winningPresentation = new WinningPresentation("FreeGameNext", this.freeGameSpinResult.getBank().getWinAmount(), this.winConverter.convertWinningLines(this.freeGameSpinResult.getWinningLines(), this.freeGameSpinResult.getStopSymbols().size(), winSounds, winAnimations), "WinCount8", false, false);
            logicPresentationMap.put(WinningPresentation.class.getName(), winningPresentation);
            logicPresentationMap.put(FreeGamesProgressResult.class.getName(), new FreeGamesProgressResult(this.freeGameSpinResult.getFreeGamesPlayed(), this.totalFreeGames, this.freeGameSpinResult.getCurrentWinAmount(), this.freeGameSpinResult.getBank().getWinAmount()));
        } else {
            winningPresentation = new WinningPresentation("FreeGamesWin", this.totalWin, this.winConverter.convertWinningLines(this.freeGameSpinResult.getWinningLines(), this.freeGameSpinResult.getStopSymbols().size(), winSounds, winAnimations), "WinCount8", false, false);
            logicPresentationMap.put(WinningPresentation.class.getName(), winningPresentation);
            logicPresentationMap.put(FreeGamesProgressResult.class.getName(), new FreeGamesProgressResult(this.freeGameSpinResult.getFreeGamesPlayed(), this.totalFreeGames, this.currentWin, this.totalWin));
            logicPresentationMap.put(FreeGamesInfoType.GAMES_END.name(), new FreeGamesInfoResult(this.totalFreeGames, FreeGamesInfoType.GAMES_END));
        }

        return logicPresentationMap;
    }
}

