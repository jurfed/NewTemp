package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.PlaySoundAction;
import com.atsisa.gox.framework.action.PlaySoundActionData;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.utility.Timeout;

public class AfterFreeGamesRetriggerSound extends SyncAction {

    ISoundManager iSoundManager = GameEngine.current().getSoundManager();

    @Override
    protected void execute() {

        new Timeout(5500, () -> {
//            iSoundManager.stop("free_intro");
            iSoundManager.play("free_loop");

            PlaySoundActionData data = new PlaySoundActionData();
            data.setSoundId("free_loop");
            data.setBlocking(false);
            data.setLoop(true);

            PlaySoundAction playSoundAction = new PlaySoundAction();
            playSoundAction.setActionData(data);
            playSoundAction.executeStandalone();
//            GameEngine.current().getActionManager().getActionBinder().

        }, true);
    }
}
