package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.games.trextrack.screen.basegamescreen.TRexTrackBaseGameScreen;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class ExecuteNextDependingOnNoTakeWin extends ExecuteNextAction {
    @Override
    protected void execute() {
        allowFurtherProcessing();

        if (TRexTrackBaseGameScreen.getFreeGamesWinAmount() > 0) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }

}
