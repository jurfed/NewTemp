package com.atsisa.gox.games.trextrack.action.takewin;

import com.atsisa.gox.framework.action.Action;

public class UnLockCanTakeWin extends Action {
    @Override
    protected void execute() {
        CustomSendTakeWinRequest.setCanTake(true);
        finish();
    }

    @Override
    protected void terminate() {
        CustomSendTakeWinRequest.setCanTake(true);
    }
}
