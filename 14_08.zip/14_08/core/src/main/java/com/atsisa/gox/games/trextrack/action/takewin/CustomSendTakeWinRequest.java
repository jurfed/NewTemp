package com.atsisa.gox.games.trextrack.action.takewin;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.games.trextrack.screen.basegamescreen.TRexTrackBaseGameScreen;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.action.AbstractSendRequestAction;
import com.gwtent.reflection.client.annotations.Reflect_Mini;


@Reflect_Mini
public class CustomSendTakeWinRequest extends CustomAbstractSendRequestAction {

    private static volatile boolean canTake = true;

    /**
     * Initializes a new instance of the {@link CustomSendTakeWinRequest} class.
     */
    public CustomSendTakeWinRequest() {
        super();
    }

    /**
     * Initializes a new instance of the {@link CustomSendTakeWinRequest class.
     *
     * @param game reel game reference
     */
    public CustomSendTakeWinRequest(AbstractReelGame game) {
        super(game);
    }

    /**
     * Sends a take win request to the server.
     */
    @Override
    protected synchronized void execute() {
        if (canTake) {

            canTake = false;
            System.out.println(canTake);

            new Timeout(100, () -> {

                long freeGamesWinAmount = TRexTrackBaseGameScreen.getFreeGamesWinAmount();
                long totalWinAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
                if (freeGamesWinAmount != 0) {
                    totalWinAmount = freeGamesWinAmount;
                }
                if(totalWinAmount>0){
                    subscribeForResult(getGameLogic().takeWin());
                }

            }, true);

        }


    }

    public static void setCanTake(boolean parameter) {
        canTake = parameter;

    }

    @Override
    protected void terminate() {
        System.out.println();
    }

}