package com.atsisa.gox.games.trextrack.logic.infoscreen;

import com.atsisa.gox.framework.animation.IViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.view.View;

public class TRexTrackTopDownInfoScreenTransition extends TRexTrackInfoScreenTransition {
    public TRexTrackTopDownInfoScreenTransition() {
    }

    @Override
    public void beforeTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        nextScreen.setY(-this.getHeight());
        nextScreen.setDepth(1);
    }

    @Override
    public IViewAnimation getTransition(int prevScreenIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        return ((TweenViewAnimation) this.getAnimationFactory().createAnimation(TweenViewAnimation.class)).setTargetView(nextScreen).setDestinationY(0.0F).setTimeSpan(0.0F);

    }

    @Override
    public void afterTransition(int prevIdx, View prevScreen, int nextScreenIdx, View nextScreen) {
        nextScreen.setDepth(0);
    }
}
