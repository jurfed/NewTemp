package com.atsisa.gox.games.trextrack.screen.basegamescreen;

import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.View;

import java.util.List;

/**
 * for flashing text in the free games mode
 */
class FlashView implements TimeoutCallback {
    static List<View> texts;
    static int timer;

    FlashView(List<View> texts) {
        this.texts = texts;
    }

    @Override
    public void onTimeout() {

        texts.stream().forEach(text -> {
            if (text.isVisible()) {
                text.setVisible(false);
                timer = 200;
            } else {
                timer = 400;
                text.setVisible(true);
            }
        });

        if (TRexTrackBaseGameScreen.startFreeGamesTextFlash) {
            new Timeout(timer, new FlashView(texts), true);
        } else {
            texts.stream().forEach(text -> {
                text.setVisible(false);

            });
        }


    }
}