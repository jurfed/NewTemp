package com.atsisa.gox.games.trextrack.event.freegames;

public class EnterFreeGamesEvent {
    boolean enter;

    public EnterFreeGamesEvent(boolean enter) {
        this.enter = enter;
    }

    public boolean getEnter() {
        return enter;
    }

    public void setEnter(boolean enter) {
        this.enter = enter;
    }
}
