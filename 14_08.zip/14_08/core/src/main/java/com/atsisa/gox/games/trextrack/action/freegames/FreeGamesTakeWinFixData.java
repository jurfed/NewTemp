package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class FreeGamesTakeWinFixData extends ActionData {

    @XmlAttribute
    private boolean showUnderTrackSymbol;

    public boolean getShowUnderTrackSymbol() {
        return showUnderTrackSymbol;
    }

    public void setShowUnderTrackSymbol(boolean showUnderTrackSymbol) {
        this.showUnderTrackSymbol = showUnderTrackSymbol;
    }

}
