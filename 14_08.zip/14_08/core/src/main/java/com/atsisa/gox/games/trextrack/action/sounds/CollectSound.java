package com.atsisa.gox.games.trextrack.action.sounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.AbstractReelGame;

public class CollectSound extends Action<CollectSoundData> {

    @Override
    protected void execute() {
        String soundID;

        long winSum = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        long bet = ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider().getBetModel().getTotalBet();

        if (winSum / bet < 0.5) {
            if (this.actionData.getFreeGame()) {
                soundID = "free_collect_short";
            } else {
                soundID = "collect_short";
            }

        } else {

            if (this.actionData.getFreeGame()) {
                soundID = "free_collect";
            } else {
                soundID = "collect1";
            }

        }

        if (this.actionData.getPlay()) {
            GameEngine.current().getSoundManager().play(soundID);
        } else {
            GameEngine.current().getSoundManager().stop(soundID);
        }
        finish();
    }

    @Override
    public Class<CollectSoundData> getActionDataType() {
        return CollectSoundData.class;
    }
}
