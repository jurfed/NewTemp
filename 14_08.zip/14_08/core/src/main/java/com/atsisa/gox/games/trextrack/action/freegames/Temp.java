package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.animation.ReelAnimation;
import com.atsisa.gox.reels.view.ReelGroupView;

public class Temp extends Action {
    @Override
    protected void execute() {
        System.out.println();
        ReelGroupView reelGroupView = (ReelGroupView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        int trackSymbolValue;
        for (int i = 0; i < 5; i++) {
            ((ReelAnimation) reelGroupView.getReel(i).getReelAnimation()).stop();
        }

        finish();
    }
}
