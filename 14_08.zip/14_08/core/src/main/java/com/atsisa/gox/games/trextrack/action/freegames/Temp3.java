package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.action.Action;

public class Temp3 extends Action {
    @Override
    protected void execute() {
        System.out.println();
        finish();
    }
}
