package com.atsisa.gox.games.trextrack.screen.screensaver;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.ViewGroup;

import java.sql.Time;

/**
 * wild animation
 */
public class Scene1 {
    ViewGroup viewGroup = GameEngine.current().getViewManager().findViewById("screenSaver", "scene1");

    public static Scene1 scene1;

    private Scene1() {
    }

    public static Scene1 getInstance() {
        if (scene1 == null) {
            scene1 = new Scene1();
        }
        return scene1;
    }

    public void start() {
        viewGroup.setVisible(true);

        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(viewGroup);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(500);
        animationData.setDestinationAlpha(1f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();


        for(int i=1; i<=6; i++){
            GameEngine.current().getViewManager().findViewById("screenSaver","scene1"+i).setVisible(true);

            ((KeyframeAnimationView)GameEngine.current().getViewManager().findViewById("screenSaver","keyfr1"+i)).setVisible(true);
            ((KeyframeAnimationView)GameEngine.current().getViewManager().findViewById("screenSaver","keyfr1"+i)).play();

        }
        new Timeout(21000,()->{
            resetScene();
        },true);
        playScene();
    }

    void resetScene() {

        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(viewGroup);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(500);
        animationData.setDestinationAlpha(0f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
        new Timeout(500,()->{

            for(int i=1; i<=6; i++){
                GameEngine.current().getViewManager().findViewById("screenSaver","scene1"+i).setVisible(false);

                ((KeyframeAnimationView)GameEngine.current().getViewManager().findViewById("screenSaver","keyfr1"+i)).setVisible(false);
                ((KeyframeAnimationView)GameEngine.current().getViewManager().findViewById("screenSaver","keyfr1"+i)).stop();

            }
            viewGroup.setVisible(false);
        }, true);


    }

    void playScene() {

    }

}