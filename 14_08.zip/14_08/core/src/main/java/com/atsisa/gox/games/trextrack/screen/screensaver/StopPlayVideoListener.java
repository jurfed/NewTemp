package com.atsisa.gox.games.trextrack.screen.screensaver;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.view.IMovieCompleteListener;
import com.atsisa.gox.framework.view.MovieView;
import com.atsisa.gox.games.trextrack.event.movie.MovieCompleted;

class StopPlayVideoListener implements IMovieCompleteListener {

    MovieView movie;
    int moviewId;

    StopPlayVideoListener(MovieView movie, int moviewId) {
        this.movie = movie;
        this.moviewId = moviewId;
    }

    @Override
    public void onComplete() {
        GameEngine.current().getEventBus().post(new MovieCompleted(moviewId));

    }
}
