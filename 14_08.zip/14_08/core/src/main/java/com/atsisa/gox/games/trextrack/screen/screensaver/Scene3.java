package com.atsisa.gox.games.trextrack.screen.screensaver;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;

/**
 * Scatter animation
 */
public class Scene3 {
    public static Scene3 scene3;
    ViewGroup viewGroup = GameEngine.current().getViewManager().findViewById("screenSaver", "scene3");

    KeyframeAnimationView scatter;

    private Scene3() {
    }

    public static Scene3 getInstance() {
        if (scene3 == null) {
            scene3 = new Scene3();
        }
        return scene3;
    }

    public void start() {

        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(viewGroup);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(500);
        animationData.setDestinationAlpha(1f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();

        scatter = GameEngine.current().getViewManager().findViewById("screenSaver", "scatter");
        scatter.setVisible(true);
        scatter.play();
        for (int i = 1; i <= 5; i++) {
            View textView = GameEngine.current().getViewManager().findViewById("screenSaver", "scatter" + i);
            if (!textView.isVisible()) {
                textView.setVisible(true);
            }
        }

        new Timeout(20000, () -> {
            resetScene();
        }, true);
    }

    void resetScene() {
        viewGroup.setVisible(true);
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(viewGroup);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(500);
        animationData.setDestinationAlpha(0f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
        new Timeout(500, () -> {
            if (scatter != null) {
                scatter.stop();
                scatter.setVisible(false);
            }

            for (int i = 1; i <= 5; i++) {
                View textView = GameEngine.current().getViewManager().findViewById("screenSaver", "scatter" + i);
                if (textView.isVisible()) {
                    textView.setVisible(false);
                }
            }
        }, true);


    }

}
