package com.atsisa.gox.games.trextrack.action.collect;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.FinishControlPanelWinCollectCommand;
import com.atsisa.gox.games.octavian.reels.OLinesModelProvider;
import com.atsisa.gox.games.trextrack.screen.basegamescreen.TRexTrackBaseGameScreen;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.command.TransferCreditsCommand;

public class TransferWinCustom extends Action {
    @Override
    protected synchronized void execute() {

        long freeGamesWinAmount = TRexTrackBaseGameScreen.getFreeGamesWinAmount();


        long totalWinAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        if (freeGamesWinAmount != 0) {
            totalWinAmount = freeGamesWinAmount;
        }
        if(totalWinAmount>0){
            this.eventBus.post(new TransferCreditsCommand(totalWinAmount));
            this.eventBus.post(new FinishControlPanelWinCollectCommand());
        }


        TRexTrackBaseGameScreen.resetFreeGamesWinAmount();
        this.finish();
    }
}
