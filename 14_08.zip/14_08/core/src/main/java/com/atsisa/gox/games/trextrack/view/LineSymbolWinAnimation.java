package com.atsisa.gox.games.trextrack.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IBound;
import com.atsisa.gox.framework.utility.Rectangle;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.games.trextrack.TRexTrackWildHitChecker;
import com.atsisa.gox.games.trextrack.event.CleanCollectionWithWinSymbols;
import com.atsisa.gox.games.trextrack.screen.model.BaseGameScreenModel;
import com.atsisa.gox.reels.IWinLineInfo;
import com.gwtent.reflection.client.Reflectable;
import rx.Subscription;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * View for win lines symbols animation
 */
@XmlElement
@Reflectable
public class LineSymbolWinAnimation extends ViewGroup implements IBound {

    /**
     * frame border for interrupt lines
     */
    @XmlElement
    private Rectangle boundaries;

    /**
     * For specify the position of the symbol on the reels matrix
     */
    @XmlAttribute(type = String.class)
    private String frameName;

    /**
     * For specify the frame color on the win line
     */
    @XmlAttribute(type = String.class)
    private String frameColor;

    /**
     * symbol for playing in the win line
     */
    private KeyframeAnimationView keyFrameSymbol;

    private KeyframeAnimationView winld2Animation;

    /**
     * frame for win line symbols
     */
    private ImageView lineFrame;

    private ImageView separator;

    private TweenViewAnimationData animationDataStep;
    private TweenViewAnimation tweenViewAnimationStep1;
    private TweenViewAnimation tweenViewAnimationStep2;

    /**
     * flag for initialize start coordinates x & y
     */
    private boolean initXY = false;

    private float startX;
    private float startY;

    //parameters for the init values and for the steps
    private static final float SCALE_X_START = 1f;
    private static final float SCALE_Y_START = 1f;
    private static final float SCALE_X_FOR_STEP_1 = 1.5f;
    private static final float SCALE_Y_FOR_STEP_1 = 1.5f;
    private static final float SCALE_X_FOR_STEP_2 = 1.2f;
    private static final float SCALE_Y_FOR_STEP_2 = 1.2f;

    static Map<String, String> winSymbols;

    /**
     * animation loop boundaries
     */
    private static int START_FRAME_LOOP = 7;
    //    private static int STOP_FRAME_LOOP = 24;
    private static int STOP_FRAME_LOOP;


    private static float TIME_FOR_STEP_1 = 150;
    private static float TIME_FOR_STEP_2 = 160;

/*    private static final float TIME_FOR_STEP_1 = 1000;
    private static final float TIME_FOR_STEP_2 = 1000;*/

    private static int TIME_BEFORE_STEPS = 160;

    public static float getTimeForStep1() {
        return TIME_FOR_STEP_1;
    }

    public static void setTimeForStep1(float timeForStep1) {
        TIME_FOR_STEP_1 = timeForStep1;
    }

    public static float getTimeForStep2() {
        return TIME_FOR_STEP_2;
    }

    public static void setTimeForStep2(float timeForStep2) {
        TIME_FOR_STEP_2 = timeForStep2;
    }

    public static int getTimeBeforeSteps() {
        return TIME_BEFORE_STEPS;
    }

    public static void setTimeBeforeSteps(int timeBeforeSteps) {
        TIME_BEFORE_STEPS = timeBeforeSteps;
    }

    /**
     * set start coordinate X for the frame
     */
    private final static float originScaleX = GameEngine.current().getViewManager().getSkinManager().getSkin("forScale").getView().getScaleX();

    /**
     * set start coordinate X for the frame
     */
    private final static float originScaleY = GameEngine.current().getViewManager().getSkinManager().getSkin("forScale").getView().getScaleY();
    private float originWidth;
    private float originHeight;

    private String symbolName;

    public String getSymbolName() {
        return symbolName;
    }

    public void setSymbolName(String symbolName) {
        this.symbolName = symbolName;
    }

    /**
     * map for determine if the given symbol was playing at this position last time
     */
    static Map<String, Boolean> activeFrames = new HashMap() {{
        put("11", false);
        put("21", false);
        put("31", false);
        put("41", false);
        put("51", false);
        put("12", false);
        put("22", false);
        put("32", false);
        put("42", false);
        put("52", false);
        put("13", false);
        put("23", false);
        put("33", false);
        put("43", false);
        put("53", false);
        put("14", false);
        put("24", false);
        put("34", false);
        put("44", false);
        put("54", false);
    }};


    private static boolean needResetPositions = false;

    private TimeoutCallbackForStep2 timeoutCallbackForStep2;
    private Timeout timeoutForStep2;
    private static Subscription subscription;


    /**
     * fictitious dimensions of the frame for drawing lines
     *
     * @return
     */
    @Override

    public Rectangle getBoundaries() {
        if (boundaries != null) {
            return boundaries;
        } else
            return new Rectangle(getX() + 57, getY() + 80, 260, 160);
    }

    /**
     * set the frame and the initial picture in this view
     */
    public LineSymbolWinAnimation() {
        super();
        GameEngine.current().getEventBus().register(new CleanCollectionWithWinSymbolsObserver(), CleanCollectionWithWinSymbols.class);
        tweenViewAnimationStep1 = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimationStep2 = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);

        lineFrame = new ImageView();
        addChild(lineFrame);

        keyFrameSymbol = new KeyframeAnimationView();
        keyFrameSymbol.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin("symbolT"));
        keyFrameSymbol.setX(30);
        keyFrameSymbol.setY(0);
        keyFrameSymbol.setLoop(true);
        addChild(keyFrameSymbol);
        STOP_FRAME_LOOP = keyFrameSymbol.getFrames().size() - 1;
        separator = new ImageView();
        addChild(separator);
    }


    /**
     * For set the current KeyFrameAnimationView and start playing animation
     *
     * @param skinName
     * @param frameNumber
     */
    public void playWinSymbols(String skinName, int frameNumber) {
        lineFrame.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(getFrameColor()));
        separator.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(getFrameColor() + "s"));
        //initialize original coordinates and original width & hight
        if (!initXY) {
            initOriginalDimention();
        }

        setSymbolSkin(skinName);
        playAnimation(frameNumber);
    }

    public static void unsubscribe() {
        if (subscription != null) {
            subscription.unsubscribe();
        }
    }

    /**
     * initialize original coordinates and original width & high
     */
    private void initOriginalDimention() {
        initXY = true;
        this.startX = getX();
        this.startY = getY();
        originWidth = originScaleX * this.getWidth();
        originHeight = originScaleY * this.getHeight();
        this.addPropertyChangedListener((view, viewType, property) -> {
            tweenViewAnimationStep1.stop();

            if (isVisible()) {
                if (activeFrames.get(this.getFrameName())) {
                    setStep();
                } else {
                    timeoutCallbackForStep2 = new TimeoutCallbackForStep2();
                    timeoutForStep2 = new Timeout(TIME_BEFORE_STEPS, timeoutCallbackForStep2, true);
                    playStep(SCALE_X_FOR_STEP_1, SCALE_Y_FOR_STEP_1, TIME_FOR_STEP_1, tweenViewAnimationStep1);
                }
            } else {
                resetCoordinates();
            }
        });
    }

    /**
     * set the current Key Frame Animation skin
     * set current start and end loop numbers
     *
     * @param symbolName
     */
    public void setSymbolSkin(String symbolName) {
        keyFrameSymbol.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(symbolName));
//        keyFrameSymbol.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin(symbolName));
//        keyFrameSymbol.setBeginLoopFrameNumber(START_FRAME_LOOP);
//        keyFrameSymbol.setEndLoopFrameNumber(STOP_FRAME_LOOP);
        this.symbolName = symbolName;
        if (symbolName.equals("wildSymbolAnimation")) {
            keyFrameSymbol.setEndLoopFrameNumber(40);
            keyFrameSymbol.setX(7);
            keyFrameSymbol.setY(-14);
        } else if (symbolName.equals("scatterSymbolAnimation")) {
            keyFrameSymbol.setX(-13);
            keyFrameSymbol.setY(-42);
        } else if (symbolName.equals("wild2SymbolAnimation")) {
            keyFrameSymbol.setEndLoopFrameNumber(40);
            keyFrameSymbol.setX(-167);
            keyFrameSymbol.setY(-16);
        } else {
            keyFrameSymbol.setX(30);
            keyFrameSymbol.setY(0);
        }

        redraw();
    }

    /**
     * start playing animation
     *
     * @param frameNumber
     */
    private void playAnimation(int frameNumber) {
        if (keyFrameSymbol.isPlaying()) {
            keyFrameSymbol.stop();
        }

        if (keyFrameSymbol.getFrames().size() >= frameNumber && frameNumber >= 1) {
            keyFrameSymbol.gotoAndPlay(frameNumber);
        } else {
            keyFrameSymbol.gotoAndPlay(1);
        }

        if (!keyFrameSymbol.isVisible()) {
            keyFrameSymbol.setVisible(true);
        }

/*        lineFrame.setX(18);
        lineFrame.setY(26);*/
        lineFrame.setX(8);
        lineFrame.setY(17);
        if (!lineFrame.isVisible()) {
            lineFrame.setVisible(true);
        }

        if (keyFrameSymbol.getSkin().getName() != null && (
                keyFrameSymbol.getSkin().getName().equals("symbol5WinAnimation2")
                        || keyFrameSymbol.getSkin().getName().equals("symbol4WinAnimation2")
                        || keyFrameSymbol.getSkin().getName().equals("symbol3WinAnimation2")
                        || keyFrameSymbol.getSkin().getName().equals("symbol2WinAnimation2")
                        || keyFrameSymbol.getSkin().getName().equals("symbol1WinAnimation2")
        )) {
            separator.setX(173);
            separator.setY(36);
            if (!separator.isVisible() && !keyFrameSymbol.getSkin().getName().equals("wild2SymbolAnimation")) {
                separator.setVisible(true);
            }
        } else {
            separator.setVisible(false);
        }

        redraw();
    }

    /**
     * Running the second animation step and setting the winning symbol position
     */

    class TimeoutCallbackForStep2 implements TimeoutCallback {

        @Override
        public void onTimeout() {
            tweenViewAnimationStep1.stop();
            playStep(SCALE_X_FOR_STEP_2, SCALE_Y_FOR_STEP_2, TIME_FOR_STEP_2, tweenViewAnimationStep2);
            tweenListener(tweenViewAnimationStep2);
        }
    }

    /**
     * When the second animation ends, set the flag in the map that the animation at this position was done
     *
     * @param tweenViewAnimation2
     */
    public void tweenListener(TweenViewAnimation tweenViewAnimation2) {

        new Timeout((int) TIME_FOR_STEP_2 - 10, () -> {
            tweenViewAnimationStep2.stop();
            activeFrames.put(getFrameName(), true);
            needResetPositions = true;
        }, true);

    }


    /**
     * for playin animation
     *
     * @param scaleXForStep
     * @param scaleYForStep
     * @param timeForStep
     * @param tweenViewAnimationStep
     */
    private void playStep(float scaleXForStep, float scaleYForStep, float timeForStep, TweenViewAnimation tweenViewAnimationStep) {
        animationDataStep = new TweenViewAnimationData();
        animationDataStep.setDestinationScaleX(scaleXForStep);
        animationDataStep.setDestinationScaleY(scaleYForStep);
        animationDataStep.setDestinationX((float) (startX - (originWidth * scaleXForStep - originWidth) / 1.7));
//        animationDataStep.setDestinationX((float) (startX - (originWidth * scaleXForStep - originWidth) / 2));
        animationDataStep.setDestinationY((float) (startY - (originHeight * scaleYForStep - originHeight) / 2));
        animationDataStep.setTimeSpan(timeForStep);

        tweenViewAnimationStep.setTargetView(this);
        tweenViewAnimationStep.setViewAnimationData(animationDataStep);
        if (!tweenViewAnimationStep.isPlaying()) {
            tweenViewAnimationStep.play();
        }

    }

    /**
     * Setting dimensions and coordinates without animation
     */
    private void setStep() {
        this.setScaleX(SCALE_X_FOR_STEP_2);
        this.setScaleY(SCALE_Y_FOR_STEP_2);
        this.setX((float) (startX - (originWidth * SCALE_X_FOR_STEP_2 - originWidth) / 1.7));
//        this.setX((float) (startX - (originWidth * SCALE_X_FOR_STEP_2 - originWidth) / 2));
        this.setY((float) (startY - (originHeight * SCALE_Y_FOR_STEP_2 - originHeight) / 2));

    }

    /**
     * for reset coordinates and size
     */
    private void resetCoordinates() {
        this.setX(startX);
        this.setY(startY);
        this.setWidth(originWidth);
        this.setHeight(originHeight);
        this.setScaleX(SCALE_X_START);
        this.setScaleY(SCALE_Y_START);
    }

    /**
     * Reset positions on the previous line, if the positions with the current line do not coincide
     *
     * @param winLineSymbolsPositions
     */
    public static void refreshActiveFrames(ArrayList<String> winLineSymbolsPositions) {

        boolean findposition;
        for (Map.Entry<String, Boolean> entry : activeFrames.entrySet()) {
            findposition = false;
            for (String position : winLineSymbolsPositions) {
                if (position.equals(entry.getKey())) {
                    findposition = true;
                    break;
                }
            }

            if (!findposition) {
                activeFrames.put(entry.getKey(), false);
            }

        }
    }

    public void setWild2Symbol(Optional<IWinLineInfo> currentLine) {
        boolean wild = false;
        boolean dino = true;

        int reelNumber = 1;
        winSymbols = BaseGameScreenModel.getSymbolsMap();
        String trackSymbol = BaseGameScreenModel.getSymbolsForCountWinTxt().get(TRexTrackWildHitChecker.getWinTrackSymbol());
        for (int position : currentLine.get().getPositions()) {
            if (position >= 0) {

                String tempSymbol = winSymbols.get(reelNumber + "" + (position + 1));
                if (tempSymbol != null) {
                    if (tempSymbol.equals("Wild") || tempSymbol.equals("Wild2")) {
                        wild = true;
                    }
                    if ((tempSymbol.equals("SymbolJ") || tempSymbol.equals("Symbol10") || tempSymbol.equals("SymbolQ") || tempSymbol.equals("SymbolA") || tempSymbol.equals("SymbolK") || tempSymbol.equals("Scatter"))) {
                        dino = false;
                    }

                    if (tempSymbol.equals("Track") || tempSymbol.equals("TrackR")) {
                        dino = (trackSymbol.equals("Blue")
                                || trackSymbol.equals("Blue2") || trackSymbol.equals("Green")
                                || trackSymbol.equals("Green2") || trackSymbol.equals("Violet")
                                || trackSymbol.equals("Violet2") || trackSymbol.equals("Pink")
                                || trackSymbol.equals("Pink2") || trackSymbol.equals("Yellow")
                                || trackSymbol.equals("Yellow2")
                        );
                    }

                } else {
                }
            }
            reelNumber++;
        }

        if (dino && wild && keyFrameSymbol.getSkin().getName().equals("wildSymbolAnimation")) {
            int frameIndex = keyFrameSymbol.getCurrentFrameIndex();
            setSymbolSkin("wild2SymbolAnimation");
            keyFrameSymbol.gotoAndPlay(frameIndex + 1);
        } else if (!dino && wild && keyFrameSymbol.getSkin().getName().equals("wild2SymbolAnimation")) {
            int frameIndex = keyFrameSymbol.getCurrentFrameIndex();
            setSymbolSkin("wildSymbolAnimation");
            keyFrameSymbol.gotoAndPlay(frameIndex + 1);
        }

    }

    /**
     * for reset Map activeFrames
     */
    private class CleanCollectionWithWinSymbolsObserver extends NextObserver<CleanCollectionWithWinSymbols> {

        @Override
        public void onNext(CleanCollectionWithWinSymbols cleanCollectionWithWinSymbols) {
            if (needResetPositions) {
                for (Map.Entry<String, Boolean> entry : activeFrames.entrySet()) {
                    activeFrames.put(entry.getKey(), false);
                }
                needResetPositions = false;
            }
        }
    }


    public void setFrameName(String frameName) {
        this.frameName = frameName;
    }

    public String getFrameName() {
        return this.frameName;
    }

    public void setFrameColor(String frameColor) {
        this.frameColor = frameColor;
    }

    public String getFrameColor() {
        return this.frameColor;
    }

    public void setBoundaries(Rectangle boundaries) {
        this.boundaries = boundaries;
    }

}
