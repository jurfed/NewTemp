package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.games.trextrack.view.TRexTrackCoreViewModule;
import com.atsisa.gox.reels.AbstractReelGameComponent;
import com.atsisa.gox.reels.DebugAbstractReelGame;
import com.atsisa.gox.reels.event.LogicRequestCompleteEvent;
import com.atsisa.gox.reels.logic.DenominationResult;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class TRexTrack extends DebugAbstractReelGame {

    /**
     * Initializes a new instance of the {@link TRexTrack} class.
     *
     * @param reelGameComponents reel game components
     */
    @Inject
    public TRexTrack(Set<AbstractReelGameComponent> reelGameComponents, IEventBus eventBus) {
        super(reelGameComponents);
        eventBus.register(new LogicRequestCompleteEventObserver(),LogicRequestCompleteEvent.class);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        GameEngine.current().getViewManager().getViewBuilder().registerModule(new TRexTrackCoreViewModule());
        eventBus.post(getDenominationResult());

    }
    private class LogicRequestCompleteEventObserver extends NextObserver<LogicRequestCompleteEvent> {
        @Override
        public void onNext(LogicRequestCompleteEvent logicRequestCompleteEvent) {
            System.err.println(System.nanoTime()/ 1000000000);
        }
    }

    public DenominationResult getDenominationResult() {
        List<BigDecimal> denominationSteps = new ArrayList<>();
        denominationSteps.add(new BigDecimal(1));
        denominationSteps.add(new BigDecimal(2));
        denominationSteps.add(new BigDecimal(10));
        return new DenominationResult(denominationSteps.get(0), denominationSteps);
    }

}
