package com.atsisa.gox.games.trextrack.action.reelsRotationTime;


import com.atsisa.gox.framework.action.Action;

import java.util.List;

public class SetReelsRotationTime extends Action<ReelsRotationDataAction> {
    @Override
    protected void execute() {


        finish();
    }

    @Override
    public Class<ReelsRotationDataAction> getActionDataType() {
        return ReelsRotationDataAction.class;
    }
}
