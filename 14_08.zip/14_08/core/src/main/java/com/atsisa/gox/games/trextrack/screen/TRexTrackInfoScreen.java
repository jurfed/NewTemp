package com.atsisa.gox.games.trextrack.screen;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.HideScreenAction;
import com.atsisa.gox.framework.action.PlaySoundAction;
import com.atsisa.gox.framework.action.PlaySoundActionData;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.games.octavian.core.event.WakeUpScreenSaverEvent;
import com.atsisa.gox.games.octavian.core.screen.OctavianInfoScreen;
import com.atsisa.gox.games.trextrack.TRexTrack;
import com.atsisa.gox.games.trextrack.logic.infoscreen.TRexTrackInfoScreenTransition;
import com.atsisa.gox.games.trextrack.screen.screensaver.TRexTrackScreenSaver;
import com.atsisa.gox.reels.event.PayTableModelChangedEvent;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Represents the info screen.
 */
@Reflectable
public class TRexTrackInfoScreen extends OctavianInfoScreen {
    ISoundManager soundManager;
    TRexTrackInfoScreenTransition infoScreenTransition;
    TweenViewAnimationData viewAnimationData;

    /**
     * Initializes a new instance of the {@link TRexTrackInfoScreen} class.
     *
     * @param layoutId             layout identifier
     * @param model                {@link PayTableScreenModel}
     * @param renderer             {@link IRenderer}
     * @param viewManager          {@link IViewManager}
     * @param animationFactory     {@link IAnimationFactory}
     * @param logger               {@link ILogger}
     * @param eventBus             {@link IEventBus}
     * @param infoScreenTransition {@link InfoScreenTransition}
     */
    @Inject
    public TRexTrackInfoScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, PayTableScreenModel model, IRenderer renderer, IViewManager viewManager,
                               IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, TRexTrackInfoScreenTransition infoScreenTransition, ITranslator translator, ISoundManager soundManager, IEventBus iEventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition, translator);
        this.soundManager = soundManager;
        this.infoScreenTransition = infoScreenTransition;
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new PayTableModelChangedEventObserver(), PayTableModelChangedEvent.class);
    }

    /**
     * Handles pay table values changed.
     *
     * @param event event with changed values
     */
    @Subscribe
    public void handlePayTableModelChangedEvent(PayTableModelChangedEvent event) {
        ((PayTableScreenModel) getModel()).updatePayTableValues(event.getValues());
    }

    private class PayTableModelChangedEventObserver extends NextObserver<PayTableModelChangedEvent> {

        @Override
        public void onNext(final PayTableModelChangedEvent payTableModelChangedEvent) {
            handlePayTableModelChangedEvent(payTableModelChangedEvent);
        }
    }

    @Override
    public void hide(TweenViewAnimationData viewAnimationData, final IFinishCallback callback) {
        viewAnimationData.setTimeSpan(0);
        super.hide(viewAnimationData, callback);
        soundManager.play("help");
        GameEngine.current().getEventBus().post(new WakeUpScreenSaverEvent(true));
    }

    @Override
    protected void show(TweenViewAnimationData viewAnimationData, IFinishCallback finishCallback, Object triggeredEvent) {

        GameEngine.current().getEventBus().post(new WakeUpScreenSaverEvent(false));
        if (isActive()) {
            showNext(finishCallback, triggeredEvent);
        } else {
            super.show(viewAnimationData, finishCallback, triggeredEvent);
        }
    }


}
