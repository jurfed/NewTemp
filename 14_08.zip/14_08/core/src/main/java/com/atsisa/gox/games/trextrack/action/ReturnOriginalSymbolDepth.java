package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.gwtent.reflection.client.annotations.Reflect_Mini;


/**
 * To set the depth of symbols to the initial state: scatter=1, any other symbol=0
 * <p>
 * Depth of symbols versus activity and type:
 * -2 - lose symple symbol
 * -1 - lose scatter symbol
 * 0 - idle simple symbols
 * 1 - idle scatter symbols
 * 2 - not active simple win symbol
 * 3 - not active simple win scatter
 * 4 - active win symbol
 */
@Reflect_Mini
public class ReturnOriginalSymbolDepth extends Action {

    private final int NUMBERS_OF_REELS = 5;
    private final int NUMBERS_OF_CELLS = 4;

    private final String LAYOUT_BASE_GAME_SCREEN_ID = "baseGameScreen";
    private final String REEL_GROUP_VIEW = "reelGroupView";

    /**
     * For getting Reel Group
     */
    private ReelGroupView reelGroupView;

    /**
     * For getting symbol on the reel
     */
    private AbstractSymbol abstractSymbol;

    private final String SCATTER_SYMBOL = "Scatter";

    @Override
    protected void execute() {
        reelGroupView = GameEngine.current().getViewManager().findViewById(LAYOUT_BASE_GAME_SCREEN_ID, REEL_GROUP_VIEW);

        //Getting a list of reel cell object
        for (int i = 0; i < NUMBERS_OF_REELS; i++) {
            for (int j = 0; j < NUMBERS_OF_CELLS; j++) {
                abstractSymbol = reelGroupView.getReel(i).getDisplayedSymbol(j);
                if (abstractSymbol.getName().equals(SCATTER_SYMBOL)) {
                    abstractSymbol.setDepth(1);
                } else {
                    abstractSymbol.setDepth(0);
                }
            }
        }
       // WinAreaAnimation winAreaAnimation = new WinAreaAnimation();
        reelGroupView.redraw();
        finish();
    }
}
