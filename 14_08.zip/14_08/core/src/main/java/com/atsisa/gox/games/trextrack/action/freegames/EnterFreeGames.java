package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.TRexTrackWildHitChecker;
import com.atsisa.gox.games.trextrack.event.SymbolsTransparency;
import com.atsisa.gox.games.trextrack.event.freegames.EnterFreeGamesEvent;

public class EnterFreeGames extends Action<EnterFreeGamesData> {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new EnterFreeGamesEvent(this.actionData.getEnter()));
        if(this.actionData.getEnter()){
            TRexTrackWildHitChecker.setFreeGame(true);
        }else{
            GameEngine.current().getViewManager().findViewById("baseGameScreen","effect").setVisible(false);
            TRexTrackWildHitChecker.setFreeGame(false);
        }
        finish();
    }

    @Override
    public Class<EnterFreeGamesData> getActionDataType() {
        return EnterFreeGamesData.class;
    }
}
