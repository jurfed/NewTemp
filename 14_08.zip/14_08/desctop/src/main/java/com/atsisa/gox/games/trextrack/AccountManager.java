package com.atsisa.gox.games.trextrack;

import java.util.UUID;
import javax.inject.Inject;
import javax.inject.Singleton;

import com.atsisa.gox.financial.FinancialException;
import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.financial.IBalanceListener;

/**
 * Represents the account manager class.
 */
@Singleton
public class AccountManager implements IBalance, IAccount {

    /**
     * Name of property of initial credit value.
     */
    private long credits = 10000000;

    /**
     * Class constructor.
     */
    @Inject
    public AccountManager() {
    }

    @Override
    public long getBalance() throws FinancialException {
        return credits;
    }

    @Override
    public void withdraw(long amount, UUID uuid) throws FinancialException {
        credits -= amount;
    }

    @Override
    public void deposit(long amount, UUID uuid) throws FinancialException {
        credits += amount;
    }

    @Override
    public AutoCloseable addBalanceListener(IBalanceListener balanceListener) {
        return () -> {
        };
    }
}
