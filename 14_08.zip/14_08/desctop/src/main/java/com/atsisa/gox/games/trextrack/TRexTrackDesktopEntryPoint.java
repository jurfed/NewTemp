package com.atsisa.gox.games.trextrack;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.JavaGameEntryPoint;
import com.atsisa.gox.framework.configuration.BaseConfiguration;
import com.atsisa.gox.reels.screen.BaseGameScreen;
import org.apache.log4j.BasicConfigurator;

public class TRexTrackDesktopEntryPoint extends JavaGameEntryPoint {

    private Map<Class<?>, Object> controllerRegistry;
    private static TRexTrackDesktopEntryPoint tRexTrackDesktopEntryPoint;

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();
        if(tRexTrackDesktopEntryPoint==null){
            new TRexTrackDesktopEntryPoint().start();
        }
    }

    @Override
    protected IGameEngine createGameEngine() {
        System.err.println(System.nanoTime()/ 1000000000);
        TRexTrackDesktopContainer container = DaggerTRexTrackDesktopContainer.builder().build();
        controllerRegistry = container.getControllers();
        return container.gameEngine();
    }

    @Override
    public Map<Class<?>, Object> getServiceRegistry() {
        return controllerRegistry;
    }
}
