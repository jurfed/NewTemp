package com.atsisa.gox.games.trextrack.logic;

import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.model.*;
import com.atsisa.gox.logic.provider.IPayTableProvider;
import com.atsisa.gox.logic.provider.IReelsDescriptorProvider;
import com.atsisa.gox.logic.provider.IReelsGameConfigurationProvider;
import com.atsisa.gox.reels.logic.model.GameConfiguration;
import com.atsisa.gox.reels.logic.model.PayTableItem;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameConfigurationAdapter {

    private static final int GAMBLER_PLAY_WIN = 5;

    private static final long GAMBLER_WIN_LIMIT = 100000;

    private static final String CURRENCY_CODE = "USD";

    private static final String YIELD = "92.04";

    private static final String WIN_TYPE = "Line";

    private final IReelsGameConfigurationProvider reelGameConfigurationProvider;

    private final IPayTableProvider payTableProvider;

    private final IReelsDescriptorProvider reelsDescriptorProvider;

    @Inject
    public GameConfigurationAdapter(IReelsGameConfigurationProvider reelGameConfigurationProvider, IPayTableProvider payTableProvider,
                                    IReelsDescriptorProvider reelsDescriptorProvider) {
        this.reelGameConfigurationProvider = reelGameConfigurationProvider;
        this.payTableProvider = payTableProvider;
        this.reelsDescriptorProvider = reelsDescriptorProvider;
    }


    public GameConfiguration getGameConfiguration() throws GameLogicException {
        List<PayTableItem> gamePresentationPaytable = new ArrayList<>();

        if (!reelGameConfigurationProvider.get().isPresent()) {
            throw new GameLogicException("Reels game configuration model is missing");
        }
        ReelsGameConfiguration gameConfiguration = reelGameConfigurationProvider.get().get();

        if (!payTableProvider.get().isPresent()) {
            throw new GameLogicException("Pay table model is missing");
        }
        PayTable payTable = payTableProvider.get().get();

        for (LineWinDescriptor winLineDescriptor : payTable.getWinDescriptors()) {
            gamePresentationPaytable.add(new PayTableItem(String.format("%s_X_%d", winLineDescriptor.getWinDescriptor().getSymbol().getName().toUpperCase(),
                    winLineDescriptor.getWinDescriptor().getSymbolsAmount()), winLineDescriptor.getWinDescriptor().getScore(), WIN_TYPE));
        }

        long maxBet = gameConfiguration.getBetSteps().get(gameConfiguration.getBetSteps().size() - 1);

/*        return new GameConfiguration(gameConfiguration.getLineSteps(),
                gameConfiguration.getBetSteps(),
                maxBet,
                gameConfiguration.getMaxWinLimit(),
                GAMBLER_PLAY_WIN, GAMBLER_WIN_LIMIT,
                gamePresentationPaytable,
                CURRENCY_CODE,
                YIELD,
                createSymbolsMap());*/

        return new GameConfiguration(gameConfiguration.getLineSteps(), gameConfiguration.getBetSteps(), maxBet, gameConfiguration.getMaxWinLimit(),
                GAMBLER_PLAY_WIN, 5, 2, GAMBLER_WIN_LIMIT, gamePresentationPaytable, CURRENCY_CODE, YIELD, createSymbolsMap());
/*        return new GameConfiguration(
                gameConfiguration.getLineSteps(),
                gameConfiguration.getBetSteps(),
                maxBet,
                gameConfiguration.getMaxWinLimit(),
                GAMBLER_PLAY_WIN,
                10,
                10,
                GAMBLER_WIN_LIMIT,
                gamePresentationPaytable,
                CURRENCY_CODE,
                YIELD,
                createSymbolsMap());*/
    }

    private Map<Integer, String> createSymbolsMap() throws GameLogicException {
        if (!reelsDescriptorProvider.getReelsDescriptor().isPresent()) {
            throw new GameLogicException("Reels descriptor is missing");
        }

        ReelsDescriptor reelsDescriptor = reelsDescriptorProvider.getReelsDescriptor().get();
        Map<Integer, String> symbolMap = new HashMap<>();

        for (ReelStrip reelStrip : reelsDescriptor.getReelStrips()) {
            for (Symbol symbol : reelStrip.getSymbols()) {
                symbolMap.putIfAbsent(symbol.getId(), symbol.getName());
            }
        }

        return symbolMap;
    }
}
