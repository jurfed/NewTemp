package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.games.trextrack.view.TRexTrackCoreViewModule;
import com.atsisa.gox.reels.AbstractReelGameComponent;
import com.atsisa.gox.reels.DebugAbstractReelGame;
import com.atsisa.gox.reels.logic.DenominationResult;

import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class TRexTrack extends DebugAbstractReelGame {

    /**
     * Initializes a new instance of the {@link TRexTrack} class.
     *
     * @param reelGameComponents reel game components
     */
    @Inject
    public TRexTrack(Set<AbstractReelGameComponent> reelGameComponents) {
        super(reelGameComponents);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        GameEngine.current().getViewManager().getViewBuilder().registerModule(new TRexTrackCoreViewModule());
        eventBus.post(getDenominationResult());

    }


    public DenominationResult getDenominationResult() {
        List<BigDecimal> denominationSteps = new ArrayList<>();
        denominationSteps.add(new BigDecimal(1));
        denominationSteps.add(new BigDecimal(2));
        denominationSteps.add(new BigDecimal(10));
        return new DenominationResult(denominationSteps.get(0), denominationSteps);
    }

}
