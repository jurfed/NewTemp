package com.atsisa.gox.games.trextrack.event.freegames;

public class LastStepFreeGamesWinEvent {
    boolean winBeforeExitFreegame;

    public boolean isWinBeforeExitFreegame() {
        return winBeforeExitFreegame;
    }

    public LastStepFreeGamesWinEvent(boolean lastWin) {
        this.winBeforeExitFreegame = lastWin;
    }

}
