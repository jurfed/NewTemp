package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.configuration.GameConfiguration;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.resource.ResourceDescriptionModel;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.GameConfigurationStatics;
import com.atsisa.gox.framework.utility.IConfigurationProperties;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.framework.utility.localization.LocalResourceTranslationProvider;
import com.atsisa.gox.games.ODebugReelsCoreModule;
import com.atsisa.gox.games.OctavianControlPanelModule;
import com.atsisa.gox.games.OctavianCoreModule;
import com.atsisa.gox.games.octavian.core.service.ReelsService;
import com.atsisa.gox.games.octavian.formatter.IOctavianFormatter;
import com.atsisa.gox.games.octavian.formatter.OctavianFormatter;
import com.atsisa.gox.games.octavian.reels.ODenominationModelProvider;
import com.atsisa.gox.games.octavian.reels.OLinesModelProvider;
import com.atsisa.gox.games.trextrack.logic.TRexTrackRngService;
import com.atsisa.gox.games.trextrack.message.processing.TRexTrackFreeGamesMessageProcessor;
import com.atsisa.gox.games.trextrack.screen.TRexTrackGamblerScreen;
import com.atsisa.gox.games.trextrack.screen.TRexTrackInfoScreen;
import com.atsisa.gox.games.trextrack.screen.TRexTrackPayTableScreen;
import com.atsisa.gox.games.trextrack.screen.TRexTrackWinLinesScreen;
import com.atsisa.gox.games.trextrack.screen.basegamescreen.TRexTrackBaseGameScreen;
import com.atsisa.gox.games.trextrack.screen.model.TRexTrackPayTableScreenModel;
import com.atsisa.gox.games.trextrack.screen.model.WinLinesScreenModel;
import com.atsisa.gox.reels.FreeGamesModule;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.ReelSpinModule;
import com.atsisa.gox.reels.message.processing.IMessageProcessor;
import com.atsisa.gox.reels.model.*;
import com.atsisa.gox.reels.screen.*;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.reels.screen.transition.TopDownInfoScreenTransition;
import com.atsisa.gox.rng.IRngService;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoSet;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.HashMap;
import java.util.Map;

//import com.atsisa.gox.games.trextrack.controllers.PayTableWinAnimationController;

/**
 * Represents an IoC module configuration.
 */
@Module(includes = {
        ODebugReelsCoreModule.class,
        TRexTrackGameLogicModule.class,
        OctavianControlPanelModule.class,
        OctavianCoreModule.class,
        ReelSpinModule.class,
        FreeGamesModule.class})
public abstract class TRexTrackCoreModule {

    @Binds
    @Singleton
    abstract IValueFormatter bindIValueFormatter(OctavianFormatter formatter);

//    @Singleton
//    @Provides
//    @Named(ReelGameSpinSoundStrategy.SPIN_SOUND_ID_PROPERTY)
//    static String classicSpinSoundBind() {
//        return "sb_loop";
//    }

    @Singleton
    @Binds
    abstract IDenominationModelProvider bindIDenominationModelProvider(ODenominationModelProvider provider);

    @Provides
    @Named(IConfigurationProperties.CONFIGURATION_PROPERTIES)
    static Map<String, String> configurationPropertiesBind() {
        Map<String, String> configurationProperties = new HashMap<>();
        configurationProperties.put(GameConfigurationStatics.GAME_RESOLUTION, "FHD_TWO_MONITORS");
//        configurationProperties.put(GameConfigurationStatics.WINDOW_Y, "-1080");
        return configurationProperties;
    }

    @Binds
    @Singleton
    @IntoSet
    abstract IMessageProcessor gamesMessageProcessorBind(TRexTrackFreeGamesMessageProcessor gamesMessageProcessor);

    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel gameResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("TRexTrack", "resources.xml");
    }

    @Binds
    @Singleton
    abstract IGameConfiguration gameConfigurationBind(GameConfiguration gameConfiguration);

    @Provides
    @Singleton
    static IMutator<ILinesModel> linesModelMutatorBind() {
        return new NoLinesModelMutator();
    }


/*    @Singleton
    abstract BaseGameScreenModel baseGameScreenModelBind();*/

/*    @Provides
    @Singleton
    @IntoSet
    static Screen tRexTrackBaseGameScreenBind(@Named("BaseGameScreenLayoutId") String layoutId, BaseGameScreenModel model, IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory,
                                              ILogger logger, IEventBus eventBus, ISoundManager soundManager,IFreeGamesModelProvider freeGamesModelProvider) {
        return new TRexTrackBaseGameScreen(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, soundManager);
    }*/


    @Singleton
    @Provides
    @Named(GamblerScreen.LAYOUT_ID_PROPERTY)
    static String gamblerScreenLayoutBind() {
        return "gamblerScreen";
    }

    @Singleton
    @Provides
    @Named(InfoScreen.LAYOUT_ID_PROPERTY)
    static String infoScreenLayoutBind() {
        return "infoScreen";
    }

    @Singleton
    @Provides
    @Named(TRexTrackWinLinesScreen.LAYOUT_ID_PROPERTY)
    static String tRexTrackWinLineScreenLayoutBind() {
        return "winLinesScreen";
    }


//    @Singleton
//    @Provides
//    @Named(BottomPanelScreen.LAYOUT_ID_PROPERTY)
//    static String controlPanelScreenLayoutBind() {
//        return "controlPanelScreen";
//    }

    @Singleton
    @Provides
    @Named(BaseGameScreen.LAYOUT_ID_PROPERTY)
    static String baseGameScreenLayoutBind() {
        return "baseGameScreen";
    }

    @Provides
    @Singleton
    @Named(DebugScreen.LAYOUT_ID_PROPERTY)
    static String debugScreenLayoutBind() {
        return "debugScreen";
    }

    @Provides
    @Singleton
    @Named(ErrorScreen.LAYOUT_ID_PROPERTY)
    static String errorScreenLayoutBind() {
        return "errorScreen";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.SHOW_INFO_SCREEN_SOUND_ID_PROPERTY)
    static String infoScreenShowSoundBind() {
        return "Shift";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY)
    static String autoPlayOnSoundBind() {
        return "AutoPlayOff";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY)
    static String autoPlayOffSoundBind() {
        return "AutoPlayOn";
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY)
    static String betChangingSoundBind() {
        return "BetChanging";
    }

    @Provides
    @Singleton
    @Named(FadeScreen.LAYOUT_ID_PROPERTY)
    static String fadeScreenLayoutBind() {
        return FadeScreen.LAYOUT_ID_DEFAULT;
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyReversedRedCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_red_card_reverse.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyClubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyDiamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyHeartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historySpadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/small_spade_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String spadeCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/spade_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String clubsCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/clubs_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String heartCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/heart_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String diamondCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/diamond_card.png";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String reversedBlackCardBind() {
        return "@spriteSheet/GamblerSpriteSheet/blue_card_reverse.png";
    }

    @Provides
    @Singleton
    static InfoScreenTransition infoScreenTransitionBind() {
        return new TopDownInfoScreenTransition();
    }

    @Provides
    @Singleton
    static IRngService rngServiceBind() {
        return new TRexTrackRngService();
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(LocalResourceTranslationProvider.TRANSLATION_RESOURCE)
    static String languageListConfiguration() {
        return "LanguagesList";
    }


    @Binds
    @Singleton
    abstract IGame gameBind(TRexTrack game);

    @Binds
    @Singleton
    abstract ILinesModelProvider linesModelProviderBind(OLinesModelProvider linesModelProvider);

    @Singleton
    abstract GamblerScreenModel gamblerScreenModelBind();

//    @Singleton
//    abstract BottomPanelScreenModel bottomPanelScreenModelBind();

    @Binds
    @Singleton
    @IntoSet
    abstract Screen gamblerScreenBind(TRexTrackGamblerScreen gamblerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen infoScreenBind(TRexTrackInfoScreen infoScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen baseGameScreenBind(TRexTrackBaseGameScreen baseGameScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen debugScreenBind(DebugScreen debugScreen);


/*    @Provides
    @Singleton
    static ReelsRotationTime reelsRotationTimeTimenBind() {
        return new ReelsRotationTime();
    }*/

/*
    @Binds
    @Singleton
    @IntoSet
    abstract Screen winLinesScreenBind(WinLinesScreen winLinesScreen);
*/

    @Binds
    @Singleton
    @IntoSet
    abstract Screen tRexTrackWinLinesScreenBind(TRexTrackWinLinesScreen tRexTrackWinLinesScreen);

/*    @Provides
    @Singleton
    @IntoSet
    static Screen tRexTrackWinLinesScreenBind(String layoutId, ScreenModel model, IRenderer renderer, IViewManager viewManager,
                                     IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IMutator<ILinesModel> linesModelMutator){
        return new TRexTrackWinLinesScreen(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, linesModelMutator);
    }*/

    @Binds
    @Singleton
    @IntoSet
    abstract Screen errorScreenBind(ErrorScreen errorScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen fadeScreenBind(FadeScreen fadeScreen);

    @Binds
    @Singleton
    abstract ICreditsFormatter creditsFormatterBind(OctavianFormatter creditsFormatter);

    @Binds
    @Singleton
    abstract ITranslationProvider translationProviderBind(LocalResourceTranslationProvider localResourceTranslationProvider);

    @Singleton
    @Provides
    @Named(TRexTrackPayTableScreen.TREX_TRACK_PAYTABLE_LAYOUT_ID_PROPERTY)
    static String payTableScreenLayoutBind() {
        return "payTableScreen";
    }

    @Singleton
    abstract TRexTrackPayTableScreenModel tRexTrackPayTableScreenModelBind();

    @Singleton
    abstract WinLinesScreenModel winLinesScreenModelBind();

    @Binds
    @Singleton
    @IntoSet
    abstract Screen payTableScreenBind(TRexTrackPayTableScreen payTableScreen);

    @Provides
    @Singleton
    static ReelsService bindReelsService(IEventBus eventBus, @Named(BaseGameScreen.LAYOUT_ID_PROPERTY) String baseScreenLayoutId) {
        return new ReelsService(eventBus, baseScreenLayoutId, "reelGroupView");
    }

/*    @Provides
    @Singleton
    static PayTableWinAnimationController bindPayTableWinAnimationController(IEventBus eventBus) {
        return new PayTableWinAnimationController(eventBus);
    }*/

    @Singleton
    @Provides
    @Named(IOctavianFormatter.DENOMINATION_CURRENCY_CODE)
    static String bindDenominationCurrencyCode() {
        return "\u00A2";
//        return "c";
    }


}
