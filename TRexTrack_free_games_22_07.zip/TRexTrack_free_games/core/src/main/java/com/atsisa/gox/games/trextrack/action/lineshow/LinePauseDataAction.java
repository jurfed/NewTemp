package com.atsisa.gox.games.trextrack.action.lineshow;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class LinePauseDataAction extends ActionData {

    @XmlAttribute
    private boolean restore = false;

    public boolean getRestore() {
        return restore;
    }

    public void setRestore(boolean restore) {
        this.restore = restore;
    }

    private static boolean first = true;

    public boolean getFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    @XmlAttribute
    private int firstPause = 0;

    public int getFirstPause() {
        return firstPause;
    }

    public void setFirstPause(int firstPause) {
        this.firstPause = firstPause;
    }

    @XmlAttribute
    private int pause = 0;

    public int getPause() {
        return pause;
    }

    public void setPause(int pause) {
        this.pause = pause;
    }
}
