package com.atsisa.gox.games.trextrack;

import java.util.Map;

import com.atsisa.gox.framework.IGameEngine;
import com.atsisa.gox.framework.JavaGameEntryPoint;

public class TRexTrackDesktopEntryPoint extends JavaGameEntryPoint {

    private Map<Class<?>, Object> controllerRegistry;

    public static void main(String[] args) throws Exception {
        new TRexTrackDesktopEntryPoint().start();
    }

    @Override
    protected IGameEngine createGameEngine() {
        TRexTrackDesktopContainer container = DaggerTRexTrackDesktopContainer.builder().build();
        controllerRegistry = container.getControllers();
        return container.gameEngine();
    }

    @Override
    public Map<Class<?>, Object> getServiceRegistry() {
        return controllerRegistry;
    }
}
