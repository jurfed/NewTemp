package com.atsisa.gox.games.trextrack;

import com.atsisa.gox.financial.IAccount;
import com.atsisa.gox.financial.IBalance;
import com.atsisa.gox.framework.FrameworkDesktopModule;

import com.atsisa.gox.games.OFrameworkDesktopModule;
import dagger.Binds;
import dagger.Module;

@Module(includes = { TRexTrackCoreModule.class, FrameworkDesktopModule.class})
abstract class TRexTrackDesktopModule {

    @Binds
    abstract IBalance gameBalanceBind(AccountManager accountManager);

    @Binds
    abstract IAccount accountBind(AccountManager accountManager);

}
