package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

@Reflect_Mini
public class Temp4 extends ExecuteNextAction {
    @Override
    protected void execute() {
        finish();
    }
}
