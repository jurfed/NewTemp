package com.atsisa.gox.games.trextrack.screen.screensaver;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class Scene4 {
    public static Scene4 scene4;
    private static List<ViewGroup> trackGroups = new ArrayList<>();
    TweenViewAnimation reelTween0;
    TweenViewAnimation reelTween1;
    TweenViewAnimation reelTween2;
    TweenViewAnimation reelTween3;
    TweenViewAnimation reelTween4;

    TweenViewAnimationData reelData0;
    TweenViewAnimationData reelData1;
    TweenViewAnimationData reelData2;
    TweenViewAnimationData reelData3;
    TweenViewAnimationData reelData4;

    private Scene4() {
    }

    public static Scene4 getInstance() {
        if (scene4 == null) {
            scene4 = new Scene4();
            trackGroups.add(GameEngine.current().getViewManager().findViewById("screenSaver", "trackGroup1"));
            trackGroups.add(GameEngine.current().getViewManager().findViewById("screenSaver", "trackGroup2"));


        }
        return scene4;
    }


    public static class Reel0TimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {

        }
    }

    public static class Reel1TimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {

        }
    }

    public static class Reel2TimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {

        }
    }

    public static class Reel3TimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {

        }
    }

    public static class Reel4TimeOut implements TimeoutCallback {

        @Override
        public void onTimeout() {

        }
    }
}
