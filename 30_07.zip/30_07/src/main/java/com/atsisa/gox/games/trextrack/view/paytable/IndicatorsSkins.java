/*
package com.atsisa.gox.games.trextrack.view.paytable;


import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;

@XmlElement
public class IndicatorsSkins {

    @XmlAttribute(type = String.class)
    private String normalStatic;

    public String getNormalStatic() {
        return normalStatic;
    }

    public void setNormalStatic(String normalStatic) {
        this.normalStatic = normalStatic;
    }

    @XmlAttribute(type = String.class)
    private String changedStatic;

    public String getChangedStatic() {
        return changedStatic;
    }

    public void setChangedStatic(String changedStatic) {
        this.changedStatic = changedStatic;
    }

    @XmlAttribute(type = String.class)
    private String normalActive;

    public String getNormalActive() {
        return normalActive;
    }

    public void setNormalActive(String normalActive) {
        this.normalActive = normalActive;
    }

    @XmlAttribute(type = String.class)
    private String changedActive;

    public String getChangedActive() {
        return changedActive;
    }

    public void setChangedActive(String changedActive) {
        this.changedActive = changedActive;
    }
}
*/
