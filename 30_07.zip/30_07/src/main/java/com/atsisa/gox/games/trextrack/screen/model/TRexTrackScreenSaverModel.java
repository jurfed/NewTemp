package com.atsisa.gox.games.trextrack.screen.model;

import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.reels.model.IPayTableModelProvider;
import com.atsisa.gox.reels.model.IValueFormatter;

import javax.inject.Inject;

public class TRexTrackScreenSaverModel extends ScreenModel {

    @Inject
    public TRexTrackScreenSaverModel(ITranslator translator, IConfigurationProvider configurationProvider, IValueFormatter creditsFormatter, IEventBus eventBus) {
        super(translator);
    }
}
