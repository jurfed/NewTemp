package com.atsisa.gox.games.trextrack.screen;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.reels.event.PayTableModelChangedEvent;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.PayTableScreenModel;
import com.atsisa.gox.reels.screen.transition.InfoScreenTransition;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.gwtent.reflection.client.Reflectable;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Represents the info screen.
 */
@Reflectable
public class TRexTrackInfoScreen extends InfoScreen {

    /**
     * Initializes a new instance of the {@link TRexTrackInfoScreen} class.
     * @param layoutId             layout identifier
     * @param model                {@link PayTableScreenModel}
     * @param renderer             {@link IRenderer}
     * @param viewManager          {@link IViewManager}
     * @param animationFactory     {@link IAnimationFactory}
     * @param logger               {@link ILogger}
     * @param eventBus             {@link IEventBus}
     * @param infoScreenTransition {@link InfoScreenTransition}
     */
    @Inject
    public TRexTrackInfoScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, PayTableScreenModel model, IRenderer renderer, IViewManager viewManager,
            IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, InfoScreenTransition infoScreenTransition) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, infoScreenTransition);
    }

    /**
     * Registers events.
     */
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new PayTableModelChangedEventObserver(), PayTableModelChangedEvent.class);
    }

    /**
     * Handles pay table values changed.
     * @param event event with changed values
     */
    @Subscribe
    public void handlePayTableModelChangedEvent(PayTableModelChangedEvent event) {
        ((PayTableScreenModel) getModel()).updatePayTableValues(event.getValues());
    }

    private class PayTableModelChangedEventObserver extends NextObserver<PayTableModelChangedEvent> {

        @Override
        public void onNext(final PayTableModelChangedEvent payTableModelChangedEvent) {
            handlePayTableModelChangedEvent(payTableModelChangedEvent);
        }
    }

}
