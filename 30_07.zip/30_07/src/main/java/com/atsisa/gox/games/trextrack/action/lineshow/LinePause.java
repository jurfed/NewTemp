package com.atsisa.gox.games.trextrack.action.lineshow;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.games.trextrack.event.PlayDinoWinSoundEvent;
import com.atsisa.gox.games.trextrack.event.WinAnimationSpeed;
import com.atsisa.gox.reels.view.ReelGroupView;

public class LinePause extends Action<LinePauseDataAction> {
    private TimeOutLineShow timeOutLineShow;
    private Timeout timeout;

    @Override
    protected void execute() {

        if (this.actionData.getRestore()) {
            this.actionData.setFirst(true);
            GameEngine.current().getEventBus().post(new WinAnimationSpeed(false));
            if(!isFinished()){
                finish();
            }
        } else {
            timeOutLineShow = new TimeOutLineShow();
            if (this.actionData.getFirst()) {
                this.actionData.setFirst(false);
                GameEngine.current().getEventBus().post(new PlayDinoWinSoundEvent());
                timeout = new Timeout(this.actionData.getFirstPause(), timeOutLineShow, true);
            } else {
                GameEngine.current().getEventBus().post(new WinAnimationSpeed(true));
                timeout = new Timeout(this.actionData.getPause(), timeOutLineShow, true);
            }
        }

    }


    @Override
    protected void terminate() {
        if (!isFinished()) {
            super.terminate();
            if (timeout != null && !timeout.isCleaned()) {
                timeout.clear();
            }
        }
    }

    class TimeOutLineShow implements TimeoutCallback {

        @Override
        public void onTimeout() {
            finish();
        }
    }


    @Override
    public Class<LinePauseDataAction> getActionDataType() {
        return LinePauseDataAction.class;
    }
}
