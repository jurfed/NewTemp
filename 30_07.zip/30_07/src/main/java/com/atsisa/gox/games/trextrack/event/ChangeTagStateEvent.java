package com.atsisa.gox.games.trextrack.event;

/**
 * Command for visible needed symbols under the track symbols.
 * For example keyFrameAnimation: in the baseGameScreen - symbol5WinAnimation, symbol4WinAnimation
 */
public class ChangeTagStateEvent {
    private String tag;

    public ChangeTagStateEvent(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
