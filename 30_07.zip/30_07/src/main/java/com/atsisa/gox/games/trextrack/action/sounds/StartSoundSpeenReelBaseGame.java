package com.atsisa.gox.games.trextrack.action.sounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;

import java.util.HashMap;
import java.util.Random;

/**
 * Class for random playback of sound of rotation of reels in the basic mode.
 */
public class StartSoundSpeenReelBaseGame extends Action {
    /**
     * for sound management
     */
    private SoundManager spinReelSound;

    /**
     * Contains the sound ID and its name in the resources
     */
    private static final HashMap<Integer, String> REELS_SOUNDS = new HashMap<Integer, String>() {
        {
            put(1, "spin_1");
            put(2, "spin_2");
            put(3, "spin_3");
            put(4, "spin_4");
            put(5, "spin_5");
            put(6, "spin_6");
            put(7, "spin_7");
            put(8, "spin_8");

        }
    };

    /**
     * Assigned a randomly generated sound identifier
     */
    private static int soundId;

    @Override
    protected void execute() {
        playSound();
        finish();
    }

    /**
     * Generates a random sound identifier and plays a sound
     */
    private void playSound() {
        soundId = (new Random()).nextInt(7) + 1;
        spinReelSound = (SoundManager) GameEngine.current().getSoundManager();
        spinReelSound.setLooping(REELS_SOUNDS.get(soundId), false);
        spinReelSound.play(REELS_SOUNDS.get(soundId));
        new Timeout(2600, new TimeoutStopSound(soundId), false).start();

    }

    protected static String getSoundId() {
        return REELS_SOUNDS.get(soundId);
    }

    private class TimeoutStopSound implements TimeoutCallback {
        private int soundId;

        public TimeoutStopSound(int soundId) {
            this.soundId = soundId;
        }

        @Override
        public void onTimeout() {
            spinReelSound.stop(REELS_SOUNDS.get(soundId));
        }
    }
}
