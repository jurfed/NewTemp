package com.atsisa.gox.games.trextrack.event.movie;

public class MovieCompleted {
    private int movieId;

    public MovieCompleted(int movieId) {
        this.movieId = movieId;
    }

    public int getMovieId() {
        return movieId;
    }

}
