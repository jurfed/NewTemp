package com.atsisa.game.queencleopatra.action;

import com.atsisa.game.queencleopatra.action.animation.panel.collect.CanPlayCollectSound;
import com.atsisa.game.queencleopatra.action.animation.panel.collect.PlayCollectSound;
import com.atsisa.game.queencleopatra.action.animation.panel.collect.SimpleCollect;
import com.atsisa.game.queencleopatra.action.animation.panel.WinAreaTakeWinAnimation;
import com.atsisa.game.queencleopatra.action.animation.panel.collect.freeGamesCollect.PlayFreeGamesCollectSound;
import com.atsisa.game.queencleopatra.action.animation.panel.collect.gambleCollect.GambleCollect;
import com.atsisa.game.queencleopatra.action.bigWin.PauseAfterSkip;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.buttons.CanExitDenomination;
import com.atsisa.game.queencleopatra.action.buttons.CanExitSettings;
import com.atsisa.game.queencleopatra.action.configuretion.ExecuteNextDependingOnGambleOffAction;
import com.atsisa.game.queencleopatra.action.configuretion.SetConfigurationWinLineView;
import com.atsisa.game.queencleopatra.action.freeGames.FreeGamesMode;
import com.atsisa.game.queencleopatra.action.freeGames.ReturnBackgroundForBaseGameMode;
import com.atsisa.game.queencleopatra.action.freeGames.ShowFreeGamesWonPanel;
import com.atsisa.game.queencleopatra.action.helpers.CustomShowHideScreen;
import com.atsisa.game.queencleopatra.action.helpers.SetSkipEnable;
import com.atsisa.game.queencleopatra.action.language.Startlisteninglanguage;
import com.atsisa.game.queencleopatra.action.movie.InitHandlingLogoMovies;
import com.atsisa.game.queencleopatra.action.movie.StopSplashScreenVideo;
import com.atsisa.game.queencleopatra.action.playSounds.SpinFlashPlay;
import com.atsisa.game.queencleopatra.action.playSounds.StartSoundSpeenReelBaseGame;
import com.atsisa.game.queencleopatra.action.playSounds.StopSoundSpeenReelBaseGame;
import com.atsisa.game.queencleopatra.action.reelsSpeen.SetReelsSpeen;
import com.atsisa.gox.framework.action.AbstractActionModule;

/**
 * Action module for Book Of Ra Deluxe
 */
public class QueenCleopatraActionModule extends AbstractActionModule {

    /**
     * Book Of Ra Deluxe actions module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/game/queencleopatra/action";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    /**
     * Animation of the book and characters in the free game mode
     */
    @Override
    protected void register() {
        registerAction("StartSelectingExtendedSymbolAnimation", StartSelectingExtendedSymbolAnimationAction.class);
        registerAction("ShowSelectedExtendedSymbol", ShowSelectedExtendedSymbolAction.class);
        registerAction("HideSelectedExtendedSymbol", HideSelectedExtendedSymbolAction.class);
        registerAction("HighlightSelectedExtendedSymbol", HighlightSelectedExtendedSymbolAction.class);//flashing the selected character frame
        registerAction("ShowBgrFreeGames", ShowBgrFreeGames.class);//show background for Free Games
        registerAction("HideBgrFreeGames", HideBgrFreeGames.class);//hide background for Free Games
        registerAction("MoveUpBackground", MoveUpBackground.class);
        registerAction("SetYForTombTextWin", SetYForTombTextWin.class);//set the tomb symbol win text to center
        registerAction("ReturnOriginalSymbolDepth", ReturnOriginalSymbolDepth.class);//set the depth of symbols to the initial state: scatter=1, any other symbol=0
        registerAction("StartSoundSpeenReelBaseGame", StartSoundSpeenReelBaseGame.class);
        registerAction("StopSoundSpeenReelBaseGame", StopSoundSpeenReelBaseGame.class);
        registerAction("SpinFlashPlay", SpinFlashPlay.class);
        registerAction("Startlisteninglanguage", Startlisteninglanguage.class);
        registerAction("SetReelsSpeen", SetReelsSpeen.class);
        registerAction("InitHandlingLogoMovies", InitHandlingLogoMovies.class);
        registerAction("ShowFreeGamesWonPanel", ShowFreeGamesWonPanel.class);
        registerAction("SetConfigurationWinLineView", SetConfigurationWinLineView.class);
        registerAction("ShowBigWin", ShowBigWin.class);
        registerAction("FreeGamesMode", FreeGamesMode.class);
        registerAction("PauseAfterSkip", PauseAfterSkip.class);
        registerAction("WinAreaTakeWinAnimation", WinAreaTakeWinAnimation.class);
        registerAction("TurboMode", TurboMode.class);
        registerAction("StopSplashScreenVideo", StopSplashScreenVideo.class);
        registerAction("SetInitialVolume", SetInitialVolume.class);
        registerAction("ExecuteNextDependingOnGambleOffAction", ExecuteNextDependingOnGambleOffAction.class);
        registerAction("SetSkipEnable", SetSkipEnable.class);
        registerAction("ReturnBackgroundForBaseGameMode", ReturnBackgroundForBaseGameMode.class);
        registerAction("CustomShowHideScreen", CustomShowHideScreen.class);
        registerAction("CanExitSettings", CanExitSettings.class);
        registerAction("EmptyAction", EmptyAction.class);
        registerAction("CanExitDenomination", CanExitDenomination.class);
        registerAction("SimpleCollect", SimpleCollect.class);
        registerAction("GambleCollect", GambleCollect.class);
        registerAction("PlayCollectSound", PlayCollectSound.class);
        registerAction("CanPlayCollectSound", CanPlayCollectSound.class);
        registerAction("PlayFreeGamesCollectSound", PlayFreeGamesCollectSound.class);
    }

}