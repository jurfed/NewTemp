package com.atsisa.game.queencleopatra.helpers.bigWin;

import com.atsisa.game.queencleopatra.action.animation.panel.collect.SimpleCollect;
import com.atsisa.game.queencleopatra.action.bigWin.BigWin;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.InitState;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.WinObject;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;

import java.util.*;

/**
 * The class contains common methods for different animations
 */
public class BigWinHelper {
    private static boolean freeGamesMode = false;

    /**
     * Contains calculations of coordinates for text and indicator placement
     */
    private List<HashMap> textSteps = new ArrayList();


    /**
     * Amount of winnings
     */
    private static int collectSum;
    private static Boolean[] loopStop = new Boolean[1];
    private static long startTime;
    public static boolean terminateCollect = false;
    private ShowBigWin showBigWin;

    BottomPanelHelper bottomPanelHelper;

//    private Integer freeGamesWinCollect=0;

    public static void setTerminateCollect(boolean terminate) {
        terminateCollect = terminate;
    }

    static Set<String> sounds = new HashSet<>();
    private int previousWinSum = 0;

    public BigWinHelper() {
        try {
            bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
            previousWinSum = Integer.parseInt(bottomPanelHelper.getIndicatorSum()+"");
//            previousWinSum = Integer.parseInt(showBigWin.winTextIndicator.getText());
        } catch (Exception e) {
            previousWinSum = 0;
        }

    }


    /**
     * We start animation with the received parameters
     *
     * @param view       - Object for animation
     * @param x          - object coordinate
     * @param y          - object coordinate
     * @param scaleX
     * @param ScaleY
     * @param time       - Animation time for the object
     * @param alpha      - target object alpha
     * @param steps      - array of animation steps for the object
     * @param showBigWin - Concrete implementation of animation
     */
    public void runStep(View view, float x, float y, float scaleX, float ScaleY, int time, float alpha, Integer[] steps, BigWin showBigWin) {
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(view);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        moveSettings(animationData, x, y, scaleX, ScaleY, time, alpha);
        tweenViewAnimation.setViewAnimationData(animationData);
        showBigWin.tweenListener(view, tweenViewAnimation, steps, showBigWin);
        tweenViewAnimation.play();
    }

    /**
     * set animation parameters
     *
     * @param animationData
     * @param x
     * @param y
     * @param scaleX
     * @param ScaleY
     * @param time
     * @param alpha
     */
    public void moveSettings(TweenViewAnimationData animationData, float x, float y, float scaleX, float ScaleY, int time, float alpha) {
        animationData.setDestinationX(x);
        animationData.setDestinationY(y);
        animationData.setDestinationScaleX(scaleX);
        animationData.setDestinationScaleY(ScaleY);
        animationData.setDestinationAlpha(alpha);
        animationData.setTimeSpan(time);
    }

    /**
     * Make objects invisible and stop the sound
     *
     * @param objViews
     * @param soundId
     */
    public void end(ArrayList<View> objViews, String soundId) {

        for (View objView : objViews) {
            objView.setVisible(false);
        }
        for (String sound : sounds) {
            ((SoundManager) GameEngine.current().getSoundManager()).stop(sound);
        }
        ((SoundManager) GameEngine.current().getSoundManager()).play(soundId);
    }


    public float getFloat(Object value) {
        return Float.parseFloat(value + "");
    }

    public int getInt(Object value) {
        return Integer.parseInt(value + "");
    }

    /**
     * Start the music after the specified time. For example march Radetzky
     */
    public static class PlayMarshc implements TimeoutCallback {
        String soundId;

        public PlayMarshc(String soundId) {
            super();
            sounds.add(soundId);
            this.soundId = soundId;
        }

        @Override
        public void onTimeout() {
            ((SoundManager) GameEngine.current().getSoundManager()).play(soundId);
        }
    }

    /**
     * We calculate the coordinates and scaling for the text and indicator, depending on the length of the win.
     *
     * @param sum
     * @param IndicatorView
     * @param winTextView
     * @return - List with calculations
     */
    public List<HashMap> prepareTextParameters(int sum, View IndicatorView, View winTextView) {
        int length = (sum + "").length();

        textSteps.add(new HashMap<String, Object>() {//The first runStep of the animation
            {
                put("textX", 0f);
                put("textY", (float) (2.29 * length + 508.677));
                put("indicatorX", (float) (850.33 - 76.29 * length));
                put("scaleX", (float) (0.3 * length + 0.4));
            }
        });

        textSteps.add(new HashMap<String, Object>() {//The second runStep of the animation
            {
                put("textX", 0f);
                put("textY", (float) (500));
                put("indicatorX", (float) (855.33 - 76.29 * length));
                put("scaleX", (float) (0.3 * length + 0.4));
            }
        });

        textSteps.add(new HashMap<String, Object>() {////The third runStep of the animation
            {
                put("textX", 0f);
                put("textY", (float) (495));
                put("indicatorX", (float) (937.2 - 5.49 * length));
                put("scaleX", (float) (0.02 * length + 0.09));
            }
        });

        IndicatorView.setScaleX((float) (0.02 * length + 0.09));
        IndicatorView.setX((float) (937.2 - 5.49 * length));
        winTextView.setX(0f);

        return textSteps;
    }

    public static float getXByScaleXBigWin(float scaleX) {
        return (float) (961.63 - 504.65 * scaleX);
    }

    public static float getXByScaleXIndicator(float scaleX) {
        return (float) (482.74 - 215.74 * scaleX);
    }

    public static float getXByScaleXSuper(float scaleX) {
        return (float) (962.56 - 493.02 * scaleX);
    }

    /**
     * Performs visualization of the win amount collection
     */
    public class CollectTimer implements TimeoutCallback {
        int winSum;
        TextView textView;
        float times;

        public CollectTimer(int winSum, TextView textView, float times) {
            this.winSum = winSum;
            this.textView = textView;
            this.times = times;
        }

        /**
         * Calculate the percentage of elapsed time and calculate the appropriate percentage of the winning amount for display on the screen
         */
        @Override
        public void onTimeout() {

            freeGamesMode = showBigWin.getFreeGamesMode();

            if (collectSum < winSum && !terminateCollect) {

                long timeSpent = System.currentTimeMillis() - startTime;
                float timePercent = (timeSpent) / (times * 10);
                collectSum = Math.round((winSum * timePercent) / 100);
                if (collectSum > winSum) {
                    collectSum = winSum;
                }


                textView.setX(0f);
                textView.setText(collectSum + "");

/*                if (!freeGamesMode) {
                    showBigWin.winTextIndicator2.setText(textView.getText());
                } else {
                    showBigWin.winTextIndicator2.setText((previousWinSum + collectSum) + "");
                }*/


                new Timeout(80, new CollectTimer(winSum, textView, times), true).start();

            } else {
                SimpleCollect.setSkip(true);
                textView.setX(0f);
                textView.setText(winSum + "");
                loopStop[0] = true;
/*                showBigWin.winTextIndicator2.setText((previousWinSum + winSum) + "");
                showBigWin.winTextIndicator.setText((previousWinSum + winSum) + "");
                bottomPanelHelper.setIndicatorSum((long) (previousWinSum+winSum));*/
            }
        }
    }

    public void initObjects(ShowBigWin showBigWin, List<View> views, Integer[] steps, Boolean[] loopStop) {
        this.showBigWin = showBigWin;
        for (int i = 0; i < showBigWin.getObjectsSteps().size(); i++) {
            InitState initState = (InitState) ((WinObject) showBigWin.getObjectsSteps().get(i)).initState;
            views.get(i).setX(initState.X);
            views.get(i).setY(initState.Y);
            views.get(i).setScaleX(initState.SCALEX);
            views.get(i).setScaleY(initState.SCALEY);
            views.get(i).setVisible(initState.VISIBLE);
            views.get(i).setAlpha(initState.ALPHA);
        }

        for (int i = 0; i < steps.length; i++) {
            steps[i] = 0;
        }
        loopStop[0] = false;
    }

    /**
     * Run the collection with the parameters
     *
     * @param textView - Text to display the amount of the collection
     * @param winSum   - amount of winnings
     * @param times    - time for this type of animation
     * @param loopStop - Array of flags for the end of animation loops
     */
    public void collect(TextView textView, int winSum, float times, Boolean[] loopStop) {
        startTime = System.currentTimeMillis();
        collectSum = 0;
        this.loopStop = loopStop;
        new Timeout(100, new CollectTimer(winSum, textView, times), true).start();
    }

}
