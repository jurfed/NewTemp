package com.atsisa.game.queencleopatra.customviews;

import com.atsisa.gox.framework.view.AbstractViewModule;

/**
 * For register custom views
 */
public class CustomViewModule extends AbstractViewModule {
    @Override
    public String getXmlNamespace() {
        return "http://www.atsisa.com/customviews";
    }
    @Override
    protected void register() {
        this.registerView(CustomLineImageView.class);
        this.registerView(CustomKeyframeAnimationView.class);
        this.registerView(FrameParticleView.class);
    }
}
