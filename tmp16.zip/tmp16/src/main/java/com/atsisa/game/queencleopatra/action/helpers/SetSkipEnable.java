package com.atsisa.game.queencleopatra.action.helpers;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.helpers.data.SetSkipDataAction;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.AsyncAction;

public class SetSkipEnable extends Action<SetSkipDataAction> {
    boolean finish = false;

    @Override
    protected void execute() {
        finish = false;
        if (!this.actionData.getSkip()) {
            ShowBigWin.getBottomPanelHelper().setSkipEnable(false);
        } else {
            ShowBigWin.getBottomPanelHelper().setSkipEnable(true);
        }

        if (!finish) {
            finish = true;
            finish();
        }

    }

    @Override
    protected void terminate() {
        if (!finish) {
            finish = true;
            finish();
        }
    }

    @Override
    public Class<SetSkipDataAction> getActionDataType() {
        return SetSkipDataAction.class;
    }
}
