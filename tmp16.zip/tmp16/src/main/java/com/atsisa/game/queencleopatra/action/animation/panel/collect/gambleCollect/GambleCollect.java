package com.atsisa.game.queencleopatra.action.animation.panel.collect.gambleCollect;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.reels.AbstractReelGame;

public class GambleCollect extends Action {

    /**
     * Amount sum displayed in the collect indicator
     */
    private Long collectWinSum = 0L;

    /**
     * The total amount of winnings
     */
    private Long winSum = 0L;

    /**
     * Previous winnings for the accumulation collect in the free games mode
     */
    private Long oldSum = 0L;

    /**
     * For write a value to the textView on the button panel.
     * And for a write a previous value for the free games mode
     */
    private BottomPanelHelper bottomPanelHelper;

    /**
     * For display the collection sum
     */
    private TextView indicatorText;

    /**
     * the value of the old win sum, which we do not change
     */
    private StringBuilder startOldWinValue;

    /**
     * the value of the old win sum, which we collect and display
     */
    private StringBuilder oldWinValue;

    /**
     * the value of the gamble win sum
     */
    private StringBuilder newWinValue;

    /**
     * A flag for each digit of the sum.
     * Indicates if the full cycle of increasing the bit has passed
     */
    boolean[] initialIncrease;

    private static final int TIME_OUT=80;

    private static final String ZORO_VALUE = "0";
    private static final int TEN_VALUE = 57;

    @Override
    protected void execute() {

        bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
        winSum = ((AbstractReelGame) GameEngine.current().getGame()).getGamblerModelProvider().getGamblerModel().getBidAmount().get();
        oldSum = bottomPanelHelper.getIndicatorSum();
        indicatorText = bottomPanelHelper.getIndicatorTextID1();

        //Form a StringBuilder object from the new win amount
        newWinValue = new StringBuilder();
        for (long a = winSum; a > 0; a /= 10) {
            newWinValue.insert(0, a % 10);
        }


        initialIncrease = new boolean[newWinValue.length()];
        for (int i = 0; i < initialIncrease.length - 1; i++) {
            if (i == 0) {
                initialIncrease[i] = true;
            } else {
                initialIncrease[i] = false;
            }
        }

        startOldWinValue = initOldWinValue(startOldWinValue);
        oldWinValue = initOldWinValue(oldWinValue);

        new Timeout(100, new Collect(), true).start();//start collect

    }

    /**
     * Form a StringBuilder object from the old win amount
     *
     * @param oldValue - empty StringBuilder
     * @return - completed StringBuilder object
     */
    private StringBuilder initOldWinValue(StringBuilder oldValue) {

        oldValue = new StringBuilder();
        for (long a = oldSum; a > 0; a /= 10) {
            oldValue.insert(0, a % 10);
        }

        //
        if (oldValue.length() < newWinValue.length()) {
            oldValue.insert(0, " ");
        }

        return oldValue;
    }


    class Collect implements TimeoutCallback {
        @Override
        public void onTimeout() {
            //replacement of a space with a zero
            for (int i = newWinValue.length() - 1; i >= 0; i--) {
                if (oldWinValue.charAt(i) == ' ') {//Adding a new number (0) in the highest digit of the number
                    oldWinValue.replace(i, i + 1, ZORO_VALUE);
                }

                if (oldWinValue.charAt(i) != startOldWinValue.charAt(i) && oldWinValue.charAt(i) == '0') {
                    initialIncrease[i] = true;
                }

                if ((oldWinValue.charAt(i) != newWinValue.charAt(i)) || !initialIncrease[i]) {//If the digits in the corresponding digits do not match
                    if (oldWinValue.charAt(i) == TEN_VALUE) {//If the increased value is 10, then increase by 1 the next digit
                        oldWinValue.replace(i, i + 1, ZORO_VALUE);
                        initialIncrease[i] = true;

                        //add to the number the corresponding digit: 10,100,1000, ...
                        oldSum = Long.parseLong((String.valueOf(oldWinValue)).trim()) + (int) Math.round((Math.pow((double) 10, (double) (oldWinValue.length() - i))));
                    } else {//increase the value
                        oldWinValue.replace(i, i + 1, (String.valueOf((char) (oldWinValue.charAt(i) + 1))));
                    }
                    indicatorText.setText(oldWinValue.toString().trim());//display the value on the win indicator
                    break;
                }

            }

            //if the old win value and the new value do not match, then we call the action again
            if (!(oldWinValue.toString().equals(newWinValue.toString()))) {
                try {
                    new Timeout(TIME_OUT, new Collect(), true).start();//start collect
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {//save the new value and exit
                bottomPanelHelper.setIndicatorSum(Long.parseLong(oldWinValue.toString()));
                indicatorText.setText(oldWinValue.toString().trim());
                finish();
            }

        }
    }
}
