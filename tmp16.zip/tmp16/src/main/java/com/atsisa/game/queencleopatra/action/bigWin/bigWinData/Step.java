package com.atsisa.game.queencleopatra.action.bigWin.bigWinData;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("STEP")
public class Step {

    @XStreamAlias("X")
    public Float X;

    @XStreamAlias("Y")
    public Float Y;

    @XStreamAlias("SCALEX")
    public Float SCALEX;

    @XStreamAlias("SCALEY")
    public Float SCALEY;

    @XStreamAlias("TIME")
    public Integer TIME;

    @XStreamAlias("ALPHA")
    public Float ALPHA;

    @XStreamAlias("CYCLE")
    public Integer CYCLE;

}
