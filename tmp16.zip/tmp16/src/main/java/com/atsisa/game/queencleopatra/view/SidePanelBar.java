package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.view.GamblerCardView;

/**
 * Implementation for SidePaneBar on which are shown defined values.
 */
@XmlElement
public class SidePanelBar extends ViewGroup {

    /**
     * Animation factory reference.
     */
    private IAnimationFactory animationFactory;

    /**
     * hide panel animation
     */
    private TweenViewAnimation hideAnimation;

    /**
     * show panel animation
     */
    private TweenViewAnimation showAnimation;

    @XmlElement(name = "showLinesBar", type = TweenViewAnimationData.class)
    private TweenViewAnimationData showLinesBarData;

    @XmlElement(name = "hideLinesBar", type = TweenViewAnimationData.class)
    private TweenViewAnimationData hideLinesBarData;

    /**
     * Listener to listen when the flip animation will be finished.
     */
    private IFinishCallback onFinishShowCallback;

    /**
     * Initializes a new instance of the {@link SidePanelBar} class.
     * @param renderer         {@link IRenderer}
     * @param animationFactory {@link IAnimationFactory}
     */
    public SidePanelBar(IRenderer renderer, IAnimationFactory animationFactory) {
        super(renderer);
        this.animationFactory = animationFactory;
        initialize();
    }

    /**
     * Initializes a new instance of the {@link GamblerCardView} class.
     */
    public SidePanelBar() {
        this(GameEngine.current().getRenderer(), GameEngine.current().getAnimationFactory());
    }

    /**
     * Sets show panel bar animation data
     */
    public void setShowLinesBarData(TweenViewAnimationData showLinesBarData) {
        this.showLinesBarData = showLinesBarData;
        showAnimation.setViewAnimationData(showLinesBarData);
    }

    /**
     * Sets show panel bar animation data
     */
    public void setOpenPanelScaleY(float scaleY) {
        this.showLinesBarData.setDestinationScaleY(scaleY);
        showAnimation.setViewAnimationData(showLinesBarData);
    }

    /**
     * Sets hide panel bar animation data
     */
    public void setHideLinesBarData(TweenViewAnimationData hideLinesBarData) {
        this.hideLinesBarData = hideLinesBarData;
        hideAnimation.setViewAnimationData(hideLinesBarData);
    }

    /**
     * Initializes animations
     */
    private void initialize() {
        initializeShowAnimation();
        initializeHideAnimation();
    }

    /**
     * Creates show animation.
     */
    private void initializeShowAnimation() {
        showAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        showAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onShowAnimationComplete();
            }
        });
        showAnimation.setTargetView(this);
    }

    /**
     * Creates hide animation.
     */
    private void initializeHideAnimation() {
        hideAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        hideAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onHideAnimationComplete();
            }
        });
        hideAnimation.setTargetView(this);
    }

    /**
     * Starts animation of showing panel
     */
    public void showPanel() {
        showAnimation.play();
    }

    /**
     * Starts animation of hiding panel
     */
    public void hidePanel() {
        if (showAnimation.isPlaying()) {
            showAnimation.stop();
        }
        hideAnimation.play();
    }

    /**
     * Called when show animation will be completed.
     */
    private void onShowAnimationComplete() {
        if (onFinishShowCallback != null) {
            onFinishShowCallback.onFinish();
        }
    }

    /**
     * Called when hide animation will be completed.
     */
    private void onHideAnimationComplete() {

    }
}
