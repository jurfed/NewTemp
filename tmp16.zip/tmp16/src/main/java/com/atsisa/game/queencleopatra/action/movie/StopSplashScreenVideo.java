package com.atsisa.game.queencleopatra.action.movie;

import com.atsisa.game.queencleopatra.helpers.AniliseSymbolsForBlinking;
import com.atsisa.gox.framework.action.Action;

public class StopSplashScreenVideo extends Action{
    @Override
    protected void execute() {
        InitHandlingLogoMovies.enableTimer(false);
        AniliseSymbolsForBlinking.getLines=false;
        finish();
    }
}
