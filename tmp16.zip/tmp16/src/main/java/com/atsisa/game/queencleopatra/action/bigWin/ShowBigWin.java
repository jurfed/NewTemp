package com.atsisa.game.queencleopatra.action.bigWin;

import com.atsisa.game.queencleopatra.action.bigWin.awesomeWin.AwesomeWin;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.InitState;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.Step;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.WinData;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.WinObject;
import com.atsisa.game.queencleopatra.action.bigWin.megaBigWin.MegaBigWin;
import com.atsisa.game.queencleopatra.action.bigWin.standartBigWin.StandartBigWin;
import com.atsisa.game.queencleopatra.action.bigWin.superBigWin.SuperBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.game.queencleopatra.helpers.bigWin.BigWinHelper;
import com.atsisa.game.queencleopatra.screen.QueenCleopatraOctavianBottomPanelScreen;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.ISoundManager;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.view.AbstractReel;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.thoughtworks.xstream.XStream;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;


/**
 * Class for selecting and running the correct animation
 */
public class ShowBigWin extends Action {

    public static TextView winTextIndicator2;
    public static TextView winTextIndicator;

    private final String LAYOUT_ID = "BigWinScreen";
    private final String LAYOUT_BASE_GAME_ID = "baseGameScreen";
    private final String REEL_GROUP_VIEW_ID = "reelGroupView";
    private final int REEL_ROW_NUMBER = 3;

    private final String WIN_TEXT_ID = "winText";
    private final String XML_PATH = "assets/default/bigWin/";

    private static BottomPanelHelper bottomPanel;

    private static int monitors;


    /**
     * Flag, whether the mode of free games
     */
    private static boolean freeGamesMode = false;


    /**
     * Flag, whether the method finish() was called
     */
    private static boolean isFinish = false;

    /**
     * List of objects for animation with the steps and init value
     */
    private List objectsSteps;

    public static void setFreeGamesMode(boolean freeGamesMode) {
        ShowBigWin.freeGamesMode = freeGamesMode;
    }

    public static boolean getFreeGamesMode() {
        return ShowBigWin.freeGamesMode;
    }

    /**
     * @return -
     */
    public List getObjectsSteps() {
        return objectsSteps;
    }

    /**
     * Object with the collect time and with the list of objects
     */
    private WinData windata;

    public WinData getWindata() {
        return windata;
    }

    /**
     * List of characters for stopping animation in free play mode
     */
    // private static ArrayList<AbstractSymbol> symbolsExtended = new ArrayList<>();


    /**
     * Field for showing the amount of winnings.
     */
    private TextView winTextView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, WIN_TEXT_ID);
    private double winSum;
    private double bet;

    /**
     * For replace the standard win indicator
     */
    private ISoundManager soundManager = GameEngine.current().getSoundManager();

    private static BottomPanelHelper bottomPanelHelper = initDottomPanelHelper();

    View winArea;
    float x, y, w, h;


    static BottomPanelHelper initDottomPanelHelper() {
        Iterable<Screen> screens = GameEngine.current().getStartScreens();

        for (Screen screen : screens) {//get a BottomPanelScreen for two or three modes
            if (screen instanceof BottomPanelHelper) {
                bottomPanelHelper = (BottomPanelHelper) screen;
                if (bottomPanelHelper instanceof QueenCleopatraOctavianBottomPanelScreen) {
                    monitors = 2;
                } else {
                    monitors = 3;
                }
            }
        }
        return bottomPanelHelper;
    }

    /**
     * Determine the value of TTB and run the appropriate animation
     */
    @Override
    protected void execute() {

        winSum = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        bet = ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider().getBetModel().getTotalBet();

        double binWinSum = (double) winSum / bet;

        if (winSum >= 1) {
            if (monitors == 3 && !freeGamesMode) {
                winArea = bottomPanelHelper.getWinView();
            }

        }

        if (binWinSum >= 20d) {
//            bottomPanelHelper.setCustomIndicatorWinText(true);
            winTextView.setText((int) winSum + "");

            // ArrayList<BottomPanelHelper> target = new ArrayList<>();
            //  source.forEach(target::add);
//            winTextIndicator2 = bottomPanelHelper.getIndicatorTextID2();
//            winTextIndicator = bottomPanelHelper.getIndicatorTextID1();

            if (!freeGamesMode) {
//                winTextIndicator2.setText("");
            } else {
//                winTextIndicator2.setText(winTextIndicator.getText());
//                winTextIndicator2.setText(bottomPanelHelper.getIndicatorSum() + "");
            }

            BigWinHelper.setTerminateCollect(false);
            isFinish = false;

//            bottomPanelHelper.setCustomIndicatorWinText(true);


/*//        if (binWinSum > 0d) {
            soundManager.pauseAllSounds();
            //Run the animation if:
            //1 Base game mode
            //2 Free Games mode
            if (freeGamesMode) {
                ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById(LAYOUT_BASE_GAME_ID, REEL_GROUP_VIEW_ID);
                Iterable<AbstractReel> r = reelGroupView.getReels();
                for (AbstractReel s : r) {
                    for (int i = 0; i < REEL_ROW_NUMBER; i++) {
                        AbstractSymbol symbol = s.getDisplayedSymbol(i);
                        symbolsExtended.add(symbol);
                    }
                }
                extendedSymbolAnimation(true);
            }*/

            //for debug:
            //awesome Win - griffin 4
            //standard Bin Win - bracelet 5 or necklace 5
            //super - max 4
            //mega - max 5
            if (binWinSum >= 20d && binWinSum < 50d) {
                bottomPanelHelper.setSkipEnable(false);
                objectsSteps = parceXML("awesomeWin.xml");
                new Timeout(2000, new SkipTime(), true).start();
                new AwesomeWin((int) winSum, this, windata.COLLECT).execute();
            } else if (binWinSum >= 50d && binWinSum < 100d) {
                objectsSteps = parceXML("standartBinWin.xml");
                new Timeout(5000, new SkipTime(), true).start();
                new StandartBigWin((int) winSum, this, windata.COLLECT).execute();
            } else if (binWinSum >= 100d && binWinSum < 200d) {
                objectsSteps = parceXML("superBigWin.xml");
                new Timeout(5000, new SkipTime(), true).start();
                new SuperBigWin((int) winSum, this, windata.COLLECT).execute();
            } else if (binWinSum >= 200d) {
//                } else if (binWinSum >= 0 || binWinSum < 20) {
                objectsSteps = parceXML("megaBigWin.xml");
                new Timeout(5000, new SkipTime(), true).start();
                new MegaBigWin((int) winSum, this, windata.COLLECT).execute();
            } else {
                endAction();
            }

        } else {
            exitAction();
        }
    }

    private void exitAction() {
        if (!isFinish) {
            isFinish = true;
        }
        finish();
    }


    /**
     * Stops animation in free play mode
     *
     * @param stop - if true then stop the KeyFrameAnimation, else start KeyFrameAnimation
     */
/*    private void extendedSymbolAnimation(boolean stop) {
        for (AbstractSymbol symbol : symbolsExtended) {
            // Iterable<View> symbolView = symbol.getChildren();
            for (View symbolView : symbol.getChildren()) {

                if (symbolView instanceof KeyframeAnimationView) {
                    if (stop) {
                        ((KeyframeAnimationView) symbolView).stop();
                    } else {
                        ((KeyframeAnimationView) symbolView).play();
                    }
                }
            }
        }
    }*/

    /**
     * Get the data from xml
     *
     * @param fileName - Name of the xml file
     * @return - List of objects for animation with the steps and init value
     */
    private List parceXML(String fileName) {
        ClassLoader classLoader = this.getClass().getClassLoader();
        XStream xstream = new XStream();
        xstream.processAnnotations(WinData.class);
        xstream.processAnnotations(WinObject.class);
        xstream.processAnnotations(Step.class);
        xstream.processAnnotations(InitState.class);
        windata = (WinData) xstream.fromXML(classLoader.getResource(XML_PATH + fileName));
        List objectsSteps = windata.getObjects();
        return objectsSteps;
    }

    /**
     * Specify that the button skip was pressed
     */
    public void skip() {
        BigWinHelper.setTerminateCollect(true);
    }

    /**
     * Finish animation
     */
    public void endAction() {

        if (!isFinish) {
            //  bottomPanelHelper.setCustomIndicatorWinText(false);
            isFinish = true;
/*            if (freeGamesMode && symbolsExtended.size() > 0) {
                extendedSymbolAnimation(false);
            }
            symbolsExtended.clear();*/
            soundManager.resumeAllSounds();

            finish();
        }
    }

    @Override
    protected void terminate() {
        BigWinHelper.setTerminateCollect(true);
        if (!isFinish) {
            //bottomPanelHelper.setCustomIndicatorWinText(false);

            isFinish = true;
            //symbolsExtended.clear();
            soundManager.resumeAllSounds();
            bottomPanelHelper.setSkipEnable(false);
            PauseAfterSkip.isSkip = true;
        }
    }


    /**
     * Timer for unlocking the skip button
     */
    class SkipTime implements TimeoutCallback {

        @Override
        public void onTimeout() {
            bottomPanelHelper.setSkipEnable(true);
        }
    }

    public static BottomPanelHelper getBottomPanelHelper() {
        return bottomPanelHelper;
    }

}
