package com.atsisa.game.queencleopatra.logic.vocs;

import javax.inject.Singleton;
import java.util.Set;
import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.reels.logic.vocs.GameLogic;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;
import com.atsisa.gox.framework.utility.localization.ITranslationProvider;
import com.atsisa.gox.reels.logic.IReelGameLogic;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;

@Module
@SuppressWarnings("unused")
public abstract class QeenCleopatraGameLogicModule {

    @Provides
    @Singleton
        static DebugQueenCleopatraGameLogic debugQueenCleopatraGameLogicBind(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
            Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
                return new DebugQueenCleopatraGameLogic(xmlParser, network, configurationProvider, presentationSerializers, platform);
            }

/*    @Binds
    @Singleton
    abstract IReelGameLogic reelGameLogicBind(DebugQueenCleopatraGameLogic gameLogic);

    @Provides
    @Singleton
    static GameLogic gameLogicBind(DebugQueenCleopatraGameLogic gameLogic) {
        return gameLogic;
    }*/

    @Binds
    @Singleton
    abstract IReelGameLogic reelGameLogicBind(DebugQueenCleopatraGameLogic gameLogic);

    @Binds
    @Singleton
    abstract ITranslationProvider translationProviderBind(DebugQueenCleopatraGameLogic gameLogic);
}
