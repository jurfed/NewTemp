package com.atsisa.game.queencleopatra.action.configuretion;

import com.atsisa.game.queencleopatra.screen.QueenCleopatraSettingsScreen;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.reels.AbstractReelGame;

public class ExecuteNextDependingOnGambleOffAction extends ExecuteNextAction {

    @Override
    protected void execute() {
        allowFurtherProcessing();

        if (!QueenCleopatraSettingsScreen.getGambleOn()) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }
    }
}
