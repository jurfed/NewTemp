package com.atsisa.game.queencleopatra.action.animation.panel;

import com.atsisa.gox.framework.action.PlayMovieActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class WinAreaTakeWinAnimationActionData extends PlayMovieActionData {

    @XmlAttribute
    private int step;

    public int getStep() {
        return step;
    }

    public void setStep(int step) {
        this.step = step;
    }
}
