package com.atsisa.game.queencleopatra.gameobjects.staticClasses;

/**
 * A flag indicating whether a card game is running
 */
public class GamblerIsStart {
    public static boolean gamblerIsStart = false;

    /**
     *Signals flashing of the text "Cards of selected color pays 2 times"
     */
    public static boolean textShine = false;

    public static boolean pressed = false;
}
