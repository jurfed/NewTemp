package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.AnimationState;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.utility.IFinishCallback;
import com.atsisa.gox.reels.view.GamblerCardView;

/**
 * Implementation for SidePanelMaxButtonView.
 */
@XmlElement
public class SidePanelMaxButtonView extends SidePanelButtonView {

    /**
     * Animation factory reference.
     */
    private IAnimationFactory animationFactory;

    /**
     * Max button move down animation
     */
    private TweenViewAnimation hideAnimation;

    /**
     * Max button move up animation
     */
    private TweenViewAnimation showAnimation;

    /**
     * Listener to listen when the flip animation will be finished.
     */
    private IFinishCallback onFinishShowCallback;

    @XmlElement(name = "moveUp", type = TweenViewAnimationData.class)
    private TweenViewAnimationData moveUpData;

    @XmlElement(name = "moveDown", type = TweenViewAnimationData.class)
    private TweenViewAnimationData moveDownData;

    /**
     * Initializes a new instance of the {@link GamblerCardView} class.
     */
    public SidePanelMaxButtonView() {
        this(GameEngine.current().getRenderer(), GameEngine.current().getAnimationFactory());
    }

    /**
     * Initializes a new instance of the {@link SidePanelMaxButtonView} class.
     * @param renderer         {@link IRenderer}
     * @param animationFactory {@link IAnimationFactory}
     */
    public SidePanelMaxButtonView(IRenderer renderer, IAnimationFactory animationFactory) {
        super(renderer);
        this.animationFactory = animationFactory;
        initialize();
    }

    /**
     * Sets moveUp tween animation data
     * @param moveUpData TweenViewAnimationData
     */
    public void setMoveUpData(TweenViewAnimationData moveUpData) {
        this.moveUpData = moveUpData;
        showAnimation.setViewAnimationData(moveUpData);
    }

    /**
     * Sets moveDown tween animation data
     * @param moveDownData TweenViewAnimationData
     */
    public void setMoveDownData(TweenViewAnimationData moveDownData) {
        this.moveDownData = moveDownData;
        hideAnimation.setViewAnimationData(moveDownData);
    }

    /**
     * Sets new y position when amount of values is defined
     * @param posy New y position
     */
    public void setMoveUpY(float posy) {
        this.moveUpData.setDestinationY(posy);
        showAnimation.setViewAnimationData(moveUpData);
    }

    /**
     * Initializes animations
     */
    private void initialize() {
        initializeShowAnimation();
        initializeHideAnimation();
    }

    /**
     * Creates show animation.
     */
    private void initializeShowAnimation() {
        showAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        showAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onShowAnimationComplete();
            }
        });
        showAnimation.setTargetView(this);
    }

    /**
     * Creates hide animation.
     */
    private void initializeHideAnimation() {
        hideAnimation = animationFactory.createAnimation(TweenViewAnimation.class);
        hideAnimation.getAnimationStateObservable().subscribe(animationState -> {
            if (animationState == AnimationState.STOPPED) {
                onHideAnimationComplete();
            }
        });
        hideAnimation.setTargetView(this);
    }

    /**
     * Show animation of moving button up
     */
    public void moveUp() {
        showAnimation.play();
    }

    /**
     * Show animation of moving button down
     */
    public void moveDown() {
        if (showAnimation.isPlaying()) {
            showAnimation.stop();
        }
        hideAnimation.play();
    }

    /**
     * Called when show animation will be completed.
     */
    private void onShowAnimationComplete() {
        if (onFinishShowCallback != null) {
            onFinishShowCallback.onFinish();
        }

    }

    /**
     * Called when hide animation will be completed.
     */
    private void onHideAnimationComplete() {

    }

}
