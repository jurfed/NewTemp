package com.atsisa.game.queencleopatra.gameobjects.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration of the identifiers of the symple symbols, which are specified in the payTableBgrScreen.xml
 */
public enum LiveGlassSymbolsId {

    cleo(0), symbol10(1), symbolQ(2), necklace(3), symbolA(4), symbolJ(5), symbolK(6), snake(7), griffin(8);

    public static String[] getSyblosNames() {
        return Arrays.toString(LiveGlassSymbolsId.values()).replaceAll("^.|.$", "").split(", ");
    }

    private static final Map<Integer,LiveGlassSymbolsId> lookup
            = new HashMap<Integer,LiveGlassSymbolsId>();

    static {
        for(LiveGlassSymbolsId w : EnumSet.allOf(LiveGlassSymbolsId.class))
            lookup.put(w.getCode(), w);
    }

    private int code;

    private LiveGlassSymbolsId(int code) {
        this.code = code;
    }

    public int getCode() { return code; }

    public static LiveGlassSymbolsId get(int code) {
        return lookup.get(code);
    }
}