package com.atsisa.game.queencleopatra.gameobjects;

import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;

import java.util.HashMap;

/**
 * Implements methods for obtaining objects
 * Gives a list of LiveGlass symbols animation and LiveGlass icons
 */
public class GetLiveGlassObjects implements GetGameObjects{

    /**
     * For a template where the object is searched for
     */
    private String layout;

    /**
     *A map for animated symbols and their identifiers
     */
    private HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation;

    /**
     *A map for simple symbols and their identifiers
     */
    private HashMap<String, ImageView> symbolsImageView;

    IViewManager viewManager;

    /**
     *Initialize layout and viewManager
     *
     * @param layout
     * @param viewManager
     */
    public GetLiveGlassObjects(String layout, IViewManager viewManager){
        this.layout=layout;
        this.viewManager=viewManager;
    }

    /**
     *
     * @param animationsId
     */
    @Override
    public HashMap<String, KeyframeAnimationView> getLiveGlassAnimation(String[] animationsId) {
        mapUpperScreenSymbolsAnimation = new HashMap<>();
        for(String id: animationsId)
        {
            mapUpperScreenSymbolsAnimation.put(id, viewManager.findViewById(layout, id));
        }
        return mapUpperScreenSymbolsAnimation;
    }
    /**
     * @param imagesId
     */

    @Override
    public HashMap<String, ImageView> getLiveGlassSymbols(String[] imagesId) {
        symbolsImageView = new HashMap<>();
        for(String id: imagesId)
        {
            symbolsImageView.put(id, viewManager.findViewById(layout, id));
        }
        return symbolsImageView;
    }
}
