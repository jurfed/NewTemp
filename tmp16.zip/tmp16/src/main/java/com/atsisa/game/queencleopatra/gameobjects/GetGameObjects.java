package com.atsisa.game.queencleopatra.gameobjects;

import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.KeyframeAnimationView;

import java.util.HashMap;

/**
 * Describes methods for obtaining objects
 */
public interface GetGameObjects {

    public HashMap<String, KeyframeAnimationView> getLiveGlassAnimation(String [] animationsId);
    public HashMap<String, ImageView> getLiveGlassSymbols(String [] imagesId);

}
