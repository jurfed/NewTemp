package com.atsisa.game.queencleopatra.screen;

import com.atsisa.game.queencleopatra.action.movie.InitHandlingLogoMovies;
import com.atsisa.game.queencleopatra.event.TestEvent;
import com.atsisa.game.queencleopatra.event.VolumeChangedEvent;
import com.atsisa.game.queencleopatra.helpers.AutoplayButtomListener;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.game.queencleopatra.view.*;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.ChangeGlobalVolumeCommand;
import com.atsisa.gox.framework.command.PlaySoundCommand;
import com.atsisa.gox.framework.event.*;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.model.property.InputEventListenerProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.FreeGamesPresentationStates;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.IncreaseBetCommand;
import com.atsisa.gox.reels.command.SetBetCommand;
import com.atsisa.gox.reels.command.SetLinesCommand;
import com.atsisa.gox.reels.event.*;
import com.atsisa.gox.reels.message.BasicMessageType;
import com.atsisa.gox.reels.model.IDenominationModelProvider;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.view.ReelDelayedSequenceProvider;
import com.atsisa.gox.reels.view.ReelGroupView;
import com.gwtent.reflection.client.Reflectable;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Implementation for Octavian (FHD two monitors) bottom panel screen.
 */
@Reflectable
public class QueenCleopatraOctavianBottomPanelScreen extends BottomPanelScreen implements BottomPanelHelper {
    public static boolean turboMode = false;
    /**
     * Name of the property which is responsible if debug button is visible or not.
     */
    private static final String DEBUG_BUTTON_VISIBLE = "debugButtonVisible";

    /**
     * Name of the property which is responsible if increase bet button is enable or not.
     */
    private static final String BET_INCREASE_ENABLE = "betIncreaseEnable";

    /**
     * Name of the property which is responsible if decrease bet button is enable or not.
     */
    private static final String BET_DECREASE_ENABLE = "betDecreaseEnable";

    /**
     * Name of the property which is responsible if auto play button is enable or not.
     */
    private static final String AUTO_PLAY_ENABLE = "autoPlayEnable";

    /**
     * Name of the property which is responsible if auto stop button is visible or not.
     */
    private static final String AUTO_STOP_VISIBLE = "autoStopVisible";

    /**
     * Name of the property which is responsible if spin button is enable or not.
     */
    private static final String SPIN_ENABLE = "spinEnable";

    /**
     * Name of the property which is responsible if skip button is visible or not.
     */
    private static final String SKIP_VISIBLE = "skipVisible";

    /**
     * Name of the property which is responsible if take button is visible or not.
     */
    private static final String TAKE_VISIBLE = "takeVisible";

    /**
     * Win visible.
     */
    private static final String WIN_VISIBLE = "winVisible";

    /**
     * Name of the property which is responsible if info button is enable or not.
     */
    private static final String INFO_ENABLE = "infoEnable";

    /**
     * Name of the property which is responsible if increase lines button is enable or not.
     */
    private static final String LINES_INCREASE_ENABLE = "linesIncreaseEnable";

    /**
     * Name of the property which is responsible if decrease lines button is enable or not.
     */
    private static final String LINES_DECREASE_ENABLE = "linesDecreaseEnable";

    /**
     * Name of the property which is responsible if gamble button is visible or not.
     */
    private static final String GAMBLE_VISIBLE = "gambleVisible";

    /**
     * Name of the property which is responsible if  additional buttons are active or not.
     */
    private static final String ACTIVE_BUTTONS_VISIBLE = "activeButtonsVisible";

    /**
     * Name of the sound id property, id of the sound in game when max bet will be reached.
     */
    public static final String MAX_BET_SOUND_ID_PROPERTY = "MaxBetSound";

    /**
     * Name of the sound id property, id of the sound in game when min bet will be reached.
     */
    public static final String MIN_BET_SOUND_ID_PROPERTY = "MinBetSound";

    /**
     * Name of the sound id property, id of the sound in game when same bet is applied.
     */
    public static final String SAME_BET_SOUND_ID_PROPERTY = "SameBetSound";

    /**
     * Previously set bet.
     */
    long previousBet;

    // long previousLine;

    /**
     * Name of the property which is responsible if settings button is enable.
     */
    private static final String SETTINGS_BUTTON_ENABLE = "settingsButtonEnable";
    private static final String SETTINGS_BUTTON_ENABLE2 = "settingsButtonEnable2";

    /**
     * Previously set lines amount.
     */
    int previousLine;

    /**
     * Name of the properties which is responsible if english settings button is visible or not.
     */
    private static final String EN_SETTINGS_BUTTON_VISIBLE = "enSettingsButtonVisible";

    /**
     * Name of the properties which is responsible if german settings button is visible or not.
     */
    private static final String DE_SETTINGS_BUTTON_VISIBLE = "deSettingsButtonVisible";

    /**
     * Name of the properties which is responsible if czech settings button is visible or not.
     */
    private static final String CS_SETTINGS_BUTTON_VISIBLE = "csSettingsButtonVisible";

    /**
     * Name of the properties which is responsible if low volume button is visible or not.
     */
    private static final String LOW_VOLUME_BUTTON_VISIBLE = "lowVolumeButtonVisible";

    /**
     * Name of the properties which is responsible if mid volume button is visible or not.
     */
    private static final String MID_VOLUME_BUTTON_VISIBLE = "midVolumeButtonVisible";

    /**
     * Name of the properties which is responsible if high volume button is visible or not.
     */
    private static final String HIGH_VOLUME_BUTTON_VISIBLE = "highVolumeButtonVisible";

    /**
     * Boolean value that indicates whether auto play is on or off.
     */
    private boolean isAutoPlay;

    /**
     * Lines side panel {@link SidePanel}
     */
    SidePanel linesSidePanel;

    /**
     * Lines side panel bar {@link SidePanelBar}
     */
    SidePanelBar linesSidePanelBar;

    /**
     * Lines side panel max button view {@link SidePanelMaxButtonView}
     */
    SidePanelMaxButtonView linesSidePanelMaxButtonView;

    /**
     * Lines side panel min button view {@link SidePanelMinButtonView}
     */
    SidePanelMinButtonView linesSidePanelMinButtonView;

    /**
     * Lines side panel main button {@link SidePanelButtonView}
     */
    SidePanelButtonView linesSidePanelMainButton;

    /**
     * Lines side panel drag button {@link SidePanelButtonView}
     */
    SidePanelButtonView linesSidePanelDragButton;

    /**
     * Returns state if lines side panel is initialized
     */
    private boolean linesSidePanelInitialized = false;

    /**
     * List of side panel buttons
     */
    private List<SidePanelButton> linesButtonsList = new ArrayList<>();

    /**
     * Bets side panel {@link SidePanel}
     */
    SidePanel betsSidePanel;

    /**
     * Bets side panel bar {@link SidePanelBar}
     */
    SidePanelBar betsSidePanelBar;

    /**
     * Bets side panel max button view {@link SidePanelMaxButtonView}
     */
    SidePanelMaxButtonView betsSidePanelMaxButtonView;

    /**
     * Bets side panel min button view {@link SidePanelMaxButtonView}
     */
    SidePanelMinButtonView betsSidePanelMinButtonView;

    /**
     * Bets side panel main button {@link SidePanelButtonView}
     */
    SidePanelButtonView betsSidePanelMainButton;

    /**
     * Bets side panel drag button {@link SidePanelButtonView}
     */
    SidePanelButtonView betsSidePanelDragButton;

    /**
     * Returns state if bets side panel is initialized
     */
    private boolean betsSidePanelInitialized = false;

    /**
     * List of side panel buttons
     */
    private List<SidePanelButton> betsButtonsList = new ArrayList<>();

    /**
     * List of all infoscreens ids.
     */
    private List<String> infoScreensIds;

    /**
     * Animation data for showing info screen.
     */
    TweenViewAnimationData showInfoScreenAnimationData;

    /**
     * Denomination model provider.
     */
    private IDenominationModelProvider denominationModelProvider;

    /**
     * Reference to the {@link IFreeGamesModelProvider}.
     */
    private IFreeGamesModelProvider freeGamesModelProvider;

    private AutoplayButtomListener autoplayButtomListener;

    /**
     * Built-in indicator
     */
    private TextView indicatorTextID;

    /**
     * Indicator to replace when big wine
     */
    private TextView indicatorTextID2;
    private ViewGroup winView;

    private ButtonView quickButton;

    private ReelGroupView reelGroupView;// = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
    private final ArrayList<Integer> spinTime = new ArrayList(5);

    /**
     * Flag to know if the betsSidePanelDragButton was pressed
     */
    private static boolean isTouch = false;

    /**
     * Flag to know if the betsSidePanelDragButton was moved
     */
    private static boolean isMoved = false;

    /**
     * Shows old value Y for betsSidePanelDragButton during move
     */
    private Float dragButtonOldY = null;

    private String betSlideValue = "1";

    private boolean isHiddenSlidePanels;

    Timeout closeSlidePanelTimer, setButtonPressedTimer, showSidePanelTimer;
    ArrayList<Timeout> closeSlidePanelArrayTimers = new ArrayList<>();

    /**
     * For track a normal state for betsSidePanelDragButton and linesSidePanelDragButton
     */
    IViewPropertyChangedListener dragBottomPanelListener;

    /**
     * For track other states for betsSidePanelDragButton and linesSidePanelDragButton
     */
    IEventListener sidePanelDragButtonListener;

    /**
     * If the button betsSidePanelDragButton or linesSidePanelDragButton was pressed but was not released and became inactive
     * then set a new value and stop moving
     */

    SidePanelButtonView sidePanelDragButton;

    TweenViewAnimation tweenViewAnimationBets;

    int linesAmount = 0;
    boolean isOpenSlidePanels = false;

    private Long indicatorCollectSum = 0L;

    private static boolean collectPlaying = false;

    public boolean isCollectPlaying() {
        return collectPlaying;
    }

    public void setCollectPlaying(boolean collectPlaying) {
        QueenCleopatraOctavianBottomPanelScreen.collectPlaying = collectPlaying;
    }


//    ButtonView enSettingsButton;

    class OctavianDragBottomListener implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            if (((SidePanelButtonView) view).getCurrentState().name().equals("NORMAL_STATE") && isTouch) {
                if (setButtonPressedTimer != null) {
                    setButtonPressedTimer.clear();
                }
                isTouch = false;
                canMoveDragButton = false;
                if (((SidePanelButtonView) view).getId().equals("betsSidePanelDragButton")) {
                    placeBetAfterMoveDragButton();
                }
                ((SidePanelButtonView) view).setButtonNormalState();
            }
        }
    }


    /**
     * To handle button events - betsSidePanelDragButton and linesSidePanelDragButton
     */
    class SidepanelDragButtonListener implements IEventListener {

        @Override
        public void onEvent(IEvent event) {
            sidePanelDragButton = ((SidePanelButtonView) (event.getSource()));
            List<SidePanelButton> buttonsList;
            if (sidePanelDragButton.getId().equals("betsSidePanelDragButton")) {
                buttonsList = betsButtonsList;
            } else {
                buttonsList = linesButtonsList;
            }


            if (((InputEvent) event).getType() == InputEventType.RELEASED) {
                canMoveDragButton = false;
                if (!isMoved) {
                    setButtonPressedTimer.clear();//If the button was quickly pressed and released then do not flash betsSidePanelDragButton
                }
                placeBetAfterMoveDragButton();
                placeLineAfterMoveDragButton();//TODO for lines change
                isTouch = false;
            }

            if (((InputEvent) event).getType() == InputEventType.TOUCH_START) {
                setButtonPressedTimer = new Timeout(300, timeOutDragButton, true);
                dragButtonOldY = null;
                isTouch = true;
                isMoved = false;
                closeSlidePanelTimer();
            }

            if (((InputEvent) event).getType() == InputEventType.TOUCH_MOVE && canMoveDragButton) {
                closeSlidePanelTimer();
                float offset = 0;
                isMoved = true;
                if (dragButtonOldY == null) {
                    offset = 0;
                    dragButtonOldY = ((TouchEvent) event).getStageY();
                } else {
                    offset = ((TouchEvent) event).getStageY() - dragButtonOldY;
                    dragButtonOldY = ((TouchEvent) event).getStageY();
                }

                //Move the button within the specified limits of coordinates
                if (sidePanelDragButton.getCurrentState().name().equals("DOWN_STATE")) {
                    if (((TouchEvent) event).getStageY() > buttonsList.get(buttonsList.size() - 1).getAbsoluteY() + SidePanel.MAX_BUTTON_HEIGHT / 2 && ((TouchEvent) event).getStageY() < buttonsList.get(0).getAbsoluteY() + SidePanel.MAX_BUTTON_HEIGHT / 2) {
                        sidePanelDragButton.setY(sidePanelDragButton.getY() + offset);
                    }


                    //Analyze what value of bets make highlight
                    for (int i = 1; i < buttonsList.size(); i++) {
                        if (sidePanelDragButton.getAbsoluteY() <= buttonsList.get(i - 1).getAbsoluteY() && sidePanelDragButton.getAbsoluteY() > buttonsList.get(i).getAbsoluteY()) {
                            buttonsList.get(i - 1).setSelectedFont();
                        } else {
                            buttonsList.get(i - 1).setNormalFont();
                        }

                        if (sidePanelDragButton.getAbsoluteY() <= buttonsList.get(buttonsList.size() - 1).getAbsoluteY()) {
                            buttonsList.get(buttonsList.size() - 1).setSelectedFont();
                            buttonsList.get(buttonsList.size() - 2).setNormalFont();
                        } else {
                            buttonsList.get(buttonsList.size() - 1).setNormalFont();
                        }

                    }
                }

            }
        }
    }

    /**
     * Initializes a new instance of the {@link QueenCleopatraOctavianBottomPanelScreen} class.
     *
     * @param layoutId                  layout identifier
     * @param bottomPanelScreenModel    {@link BottomPanelScreenModel}
     * @param renderer                  {@link IRenderer}
     * @param viewManager               {@link IViewManager}
     * @param animationFactory          {@link IAnimationFactory}
     * @param logger                    {@link ILogger}
     * @param eventBus                  {@link IEventBus}
     * @param linesModelMutator         {@link IMutator<ILinesModel>} the lines model mutator
     * @param freeGamesModelProvider    {@link IFreeGamesModelProvider}
     * @param denominationModelProvider {@link IDenominationModelProvider}
     */
    @Inject
    public QueenCleopatraOctavianBottomPanelScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel,
                                                   IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus,
                                                   IMutator<ILinesModel> linesModelMutator, IResourceManager resourceManager, IParser parser, IXmlSerializer xmlSerializer,
                                                   IFreeGamesModelProvider freeGamesModelProvider, IDenominationModelProvider denominationModelProvider) {
        super(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger, eventBus, linesModelMutator, resourceManager, parser,
                xmlSerializer);
        this.freeGamesModelProvider = freeGamesModelProvider;
        this.denominationModelProvider = denominationModelProvider;
        autoplayButtomListener = new AutoplayButtomListener();
        dragBottomPanelListener = new OctavianDragBottomListener();
        sidePanelDragButtonListener = new SidepanelDragButtonListener();
    }


    @Override
    public void initializeIndicatorTextIDs() {
        ViewGroup vr = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "mainID");
        winView = GameEngine.current().getViewManager().findViewById(vr, "winView");
        indicatorTextID = GameEngine.current().getViewManager().findViewById(winView, "indicatorTextID");
        indicatorTextID2 = GameEngine.current().getViewManager().findViewById(winView, "indicatorTextID2");

        winView.addChild(indicatorTextID2);
    }

    @Override
    public View getWinView() {
        return null;
    }

    /**
     * For auto close slide panels
     */
    TimeoutCallback timeOutLogoAnimation = () -> {
        closeSlidePanles();

    };

    TimeoutCallback timeOutShowSidePanel = () -> {
        if (this.getModel().getProperty("infoEnable").get().equals(true) && isHiddenSlidePanels == true) {
            showLinesSidePanel();
            showBetsSidePanel();
            isHiddenSlidePanels = false;
        }
    };

    private void closeSlidePanles() {
        if (setButtonPressedTimer != null) {
            setButtonPressedTimer.clear();
        }
        isTouch = false;
        canMoveDragButton = false;
        placeBetAfterMoveDragButton();
        if (betsSidePanelDragButton != null) {
            betsSidePanelDragButton.setButtonNormalState();
        }

        linesSidePanelDragButton.setButtonNormalState();

        closeBetsSidePanel();
        //closeLinesSidePanel();
    }

    /**
     * for activate betsSidePanelDragButton
     */
    TimeoutCallback timeOutDragButton = () -> {
        getEventBus().post(new PlaySoundCommand(SAME_BET_SOUND_ID_PROPERTY));
        canMoveDragButton = true;
        sidePanelDragButton.setButtonPressedState();
    };


    private boolean canMoveDragButton = false;

    /**
     * Initializes side lines panel
     */
    private void initializeSideLinesPanel() {
        if (!linesSidePanelInitialized) {
            linesSidePanelBar = findViewById("linesSidePanelBar");
            linesSidePanelMaxButtonView = findViewById("maxLines");
            linesSidePanelMinButtonView = findViewById("minLines");
            linesSidePanelMainButton = findViewById("linesSidePanelMainButton");
            linesSidePanelDragButton = findViewById("linesSidePanelDragButton");
            linesSidePanel = findViewById("linesSidePanel");
            Iterable<Integer> availableLines = getLinesModel().getAvailableLines();
            Iterator<Integer> linesIterator = availableLines.iterator();

            List<Integer> lineValues = new ArrayList<>();
            while (linesIterator.hasNext()) {
                lineValues.add(linesIterator.next());
                linesAmount++;
            }

            if (linesAmount > 1) {
                this.linesSidePanel.setOpenable(true);
                linesSidePanelMainButton.setEnabled(true);
                linesSidePanelMaxButtonView.setEnabled(true);
                linesSidePanelMinButtonView.setEnabled(true);
                float originPanelHeight = linesSidePanelBar.getChildrenRaw().get(0).getHeight();
                float defaultPanelY = linesSidePanelBar.getY();
                float originPanelY = linesSidePanelBar.getOriginY();
                int panelHeight;
                panelHeight = linesAmount * (SidePanel.MAX_BUTTON_HEIGHT + 2 * SidePanel.MARGIN_OFFSET);
                panelHeight = (panelHeight > SidePanel.MAX_PANEL_HEIGHT) ? SidePanel.MAX_PANEL_HEIGHT : panelHeight;
                panelHeight = (panelHeight < SidePanel.MIN_PANEL_HEIGHT) ? SidePanel.MIN_PANEL_HEIGHT : panelHeight;

                float finalScaleY = panelHeight / originPanelHeight;
                linesSidePanelBar.setOpenPanelScaleY(finalScaleY);
                linesSidePanelBar.setOriginY(originPanelHeight / 2);

                float maxButtonHeight = linesSidePanelMaxButtonView.getChildrenRaw().get(0).getHeight();

                linesSidePanelMaxButtonView
                        .setMoveUpY(originPanelY - panelHeight / 2 - maxButtonHeight - Math.abs(linesSidePanelBar.getY()) + SidePanel.SPACE_BETWEEN_GRAPHICS);
                linesSidePanelMinButtonView
                        .setMoveDownY(originPanelY + panelHeight / 2 - Math.abs(linesSidePanelBar.getY()) - SidePanel.SPACE_BETWEEN_GRAPHICS);

                for (int count = linesAmount - 1; count >= 0; count--) {
                    int fontSize = (panelHeight - SidePanel.START_END_MARGIN * 2) / (linesAmount + 1) - SidePanel.START_END_MARGIN / 2;
                    if (fontSize > SidePanel.MAX_BUTTON_HEIGHT) {
                        fontSize = SidePanel.MAX_BUTTON_HEIGHT;
                    } else if (fontSize < SidePanel.MIN_BUTTON_HEIGHT) {
                        fontSize = SidePanel.MIN_BUTTON_HEIGHT;
                    }

                    float currentCenterPoint = originPanelY + defaultPanelY - panelHeight / 2;
                    SidePanelButton lineButton = new SidePanelButton(SidePanel.BUTTON_WIDTH, SidePanel.MAX_BUTTON_HEIGHT,
                            lineValues.get(linesAmount - 1 - count).toString(), fontSize);
                    linesButtonsList.add(lineButton);
                    IEventListener listener = new InputEventListenerProperty(lineButton, InputEventType.RELEASED);
                    lineButton.setReleaseListener(listener);
                    lineButton.setReleaseListener(event -> onLineButtonRelease(lineButton.getId()));
                    lineButton.setVisible(false);
                    lineButton.setX(linesSidePanel.getX() + SidePanel.BUTTON_LEFT_PADDING);

                    float newY = linesSidePanel.getY() + 2 * SidePanel.MARGIN_OFFSET + currentCenterPoint + (
                            count * (panelHeight - 2 * SidePanel.MARGIN_OFFSET - lineButton.getHeight()) / linesAmount);
                    lineButton.setY(newY);
                    ((ViewGroup) getLayout().getRootView()).addChild(lineButton);
                }
                this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
                this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
            } else {
                this.linesSidePanel.setOpenable(false);
                linesSidePanelMaxButtonView.setVisible(false);
                linesSidePanelMinButtonView.setVisible(false);
                linesSidePanelMainButton.setEnabled(false);
            }
            linesSidePanelInitialized = true;
        }
    }

    /**
     * Initializes side bets panel
     */
    private void initializeSideBetsPanel() {
        if (!betsSidePanelInitialized) {
            betsSidePanelBar = findViewById("betsSidePanelBar");
            betsSidePanelMaxButtonView = findViewById("maxBet");
            betsSidePanelMinButtonView = findViewById("minBet");
            betsSidePanelMainButton = findViewById("betsSidePanelMainButton");
            betsSidePanelDragButton = findViewById("betsSidePanelDragButton");
            betsSidePanel = findViewById("betsSidePanel");
            // betsSidePanel.setDepth(-2);
            Iterable<Long> availableBets = getBetModel().getBetSteps();
            Iterator<Long> betsIterator = availableBets.iterator();
            int betsAmount = 0;
            List<Long> betValues = new ArrayList<>();
            while (betsIterator.hasNext()) {
                betValues.add(betsIterator.next());
                betsAmount++;
            }

            if (betsAmount > 1) {
                this.betsSidePanel.setOpenable(true);
                betsSidePanelMainButton.setEnabled(true);
                betsSidePanelMaxButtonView.setEnabled(true);
                betsSidePanelMinButtonView.setEnabled(true);
                float originPanelHeight = betsSidePanelBar.getChildrenRaw().get(0).getHeight();
                float defaultPanelY = betsSidePanelBar.getY();
                float originPanelY = betsSidePanelBar.getOriginY();
                int panelHeight;
                panelHeight = betsAmount * (SidePanel.MAX_BUTTON_HEIGHT + 2 * SidePanel.MARGIN_OFFSET);
                panelHeight = (panelHeight > SidePanel.MAX_PANEL_HEIGHT) ? SidePanel.MAX_PANEL_HEIGHT : panelHeight;
                panelHeight = (panelHeight < SidePanel.MIN_PANEL_HEIGHT) ? SidePanel.MIN_PANEL_HEIGHT : panelHeight;

                float finalScaleY = panelHeight / originPanelHeight;
                betsSidePanelBar.setOpenPanelScaleY(finalScaleY);
                betsSidePanelBar.setOriginY(originPanelHeight / 2);

                float maxButtonHeight = betsSidePanelMaxButtonView.getChildrenRaw().get(0).getHeight();

                betsSidePanelMaxButtonView
                        .setMoveUpY(originPanelY - panelHeight / 2 - maxButtonHeight - Math.abs(betsSidePanelBar.getY()) + SidePanel.SPACE_BETWEEN_GRAPHICS);
                betsSidePanelMinButtonView.setMoveDownY(originPanelY + panelHeight / 2 - Math.abs(betsSidePanelBar.getY()) - SidePanel.SPACE_BETWEEN_GRAPHICS);

                for (int count = betsAmount - 1; count >= 0; count--) {
                    int fontSize = (panelHeight - SidePanel.START_END_MARGIN * 2) / (betsAmount + 1) - SidePanel.START_END_MARGIN / 2;
                    if (fontSize > SidePanel.MAX_BUTTON_HEIGHT) {
                        fontSize = SidePanel.MAX_BUTTON_HEIGHT;
                    } else if (fontSize < SidePanel.MIN_BUTTON_HEIGHT) {
                        fontSize = SidePanel.MIN_BUTTON_HEIGHT;
                    }

                    float currentCenterPoint = originPanelY + defaultPanelY - panelHeight / 2;
                    SidePanelButton betButton = new SidePanelButton(SidePanel.BUTTON_WIDTH, SidePanel.MAX_BUTTON_HEIGHT,
                            betValues.get(betsAmount - 1 - count).toString(), fontSize);
                    // betButton.setDepth(-1);
                    if (count == betsAmount - 1) {
                        betButton.setSelectedFont();
                    }
                    betsButtonsList.add(betButton);
                    IEventListener listener = new InputEventListenerProperty(betButton, InputEventType.RELEASED);
                    betButton.setReleaseListener(listener);
                    betButton.setReleaseListener(event -> onBetButtonRelease(betButton.getId()));
                    betButton.setVisible(false);
                    betButton.setX(betsSidePanel.getX() + SidePanel.BUTTON_LEFT_PADDING);

                    float newY = betsSidePanel.getY() + 2 * SidePanel.MARGIN_OFFSET + currentCenterPoint + (
                            count * (panelHeight - 2 * SidePanel.MARGIN_OFFSET - betButton.getHeight()) / betsAmount);
                    betButton.setY(newY);
                    ((ViewGroup) getLayout().getRootView()).addChild(betButton);
                }
                this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
                this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
            } else {
                this.betsSidePanel.setOpenable(false);
                betsSidePanelMaxButtonView.setVisible(false);
                betsSidePanelMainButton.setEnabled(false);
            }
            betsSidePanelInitialized = true;
            betsSidePanelDragButton.addPropertyChangedListener(dragBottomPanelListener);
            betsSidePanelDragButton.addEventListener(sidePanelDragButtonListener);
            betsSidePanelDragButton.setDepth(2);
        }
    }

    /**
     * Sets bet value and betsSidePanelDragButton position after TOUCH_MOVE
     */
    private void placeBetAfterMoveDragButton() {
        float accountBalance = ((AbstractReelGame) GameEngine.current().getGame()).getAccountModelProvider().getAccountModel().getBalance();

        if (betsButtonsList.size() > 1 && isMoved) {
            isMoved = false;
            for (int i = 1; i < betsButtonsList.size(); i++) {
                if (dragButtonOldY <= betsButtonsList.get(i - 1).getAbsoluteY() && dragButtonOldY > betsButtonsList.get(i).getAbsoluteY()) {
                    betsSidePanelDragButton.setY(betsButtonsList.get(i).getAbsoluteY());
                    betSlideValue = betsButtonsList.get(i).getLabel();
                    break;
                }
            }

            //for first and last values
            if (dragButtonOldY < betsButtonsList.get(betsButtonsList.size() - 1).getAbsoluteY()) {
                betSlideValue = betsButtonsList.get(betsButtonsList.size() - 1).getLabel();
            } else if (dragButtonOldY > betsButtonsList.get(0).getAbsoluteY()) {
                betSlideValue = betsButtonsList.get(0).getLabel();
            }

            //If there is enough balance, then we set new bets value
            if (getLinesModel().getSelectedLines() * Integer.parseInt(betSlideValue) <= ((AbstractReelGame) GameEngine.current().getGame()).getAccountModelProvider().getAccountModel().getBalance()) {
                onBetButtonRelease(betSlideValue);
            } else {//Otherwise, we set the nearest suitable value
                for (int i = betsButtonsList.size() - 1; i >= 0; i--) {
                    if (accountBalance >= Integer.parseInt(betsButtonsList.get(i).getLabel()) * getLinesModel().getSelectedLines()) {
                        betSlideValue = betsButtonsList.get(i).getLabel();
                        betsSidePanelDragButton.setY(betsButtonsList.get(i).getAbsoluteY());
                        onBetButtonRelease(betSlideValue);
                        break;
                    }
                }
            }
        }
    }

    //TODO  - for games where you can change the number of lines
    private void placeLineAfterMoveDragButton() {

    }

    /**
     * Opens side panels
     */
    @ExposeMethod
    public void openSidePanels() {
        closeSlidePanelTimer();
        getEventBus().post(new PlaySoundCommand("open_us"));
        isOpenSlidePanels = true;

        if (linesSidePanel.getOpenable() == true) {
            linesSidePanelDragButton.setY(setDragLinesButtonPosition());
            linesSidePanelBar.showPanel();
            linesSidePanelMaxButtonView.moveUp();
            linesSidePanelMinButtonView.moveDown();
            linesSidePanelMainButton.setVisible(false);
            linesSidePanelDragButton.setVisible(true);
            this.getModel().setProperty(SidePanel.MIN_LINE_VALUE, "MIN");
            this.getModel().setProperty(SidePanel.MAX_LINE_VALUE, "MAX");
            setVisibleValuesInLinesSidePanel(true);
        }
        if (betsSidePanel.getOpenable() == true) {
            betsSidePanelDragButton.setY(setDragBetsButtonPosition());
            betsSidePanelBar.showPanel();
            betsSidePanelMaxButtonView.moveUp();
            betsSidePanelMinButtonView.moveDown();
            betsSidePanelMainButton.setVisible(false);
            betsSidePanelDragButton.setVisible(true);
            this.getModel().setProperty(SidePanel.MIN_BET_VALUE, "MIN");
            this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX");
            setVisibleValuesInBetsSidePanel(true);
        }
    }

    /**
     * Closes side lines panel
     */
    @ExposeMethod
    public void closeLinesSidePanel() {
        if (linesSidePanel.getOpenable() == true) {
            linesSidePanelBar.hidePanel();
            linesSidePanelMaxButtonView.moveDown();
            linesSidePanelMinButtonView.moveUp();
            linesSidePanelMainButton.setVisible(true);
            linesSidePanelDragButton.setVisible(false);
            setVisibleValuesInLinesSidePanel(false);
            this.getModel().setProperty(SidePanel.MIN_LINE_VALUE, this.getLinesModel().getMinLines() + "\nMIN");
            this.getModel().setProperty(SidePanel.MAX_LINE_VALUE, "MAX\n" + this.getLinesModel().getMaxLines());
        }
        unpressButton();
    }

    /**
     * Closes side bets panel
     */
    @ExposeMethod
    public void closeBetsSidePanel() {
        if (isOpenSlidePanels) {
            isOpenSlidePanels = false;
            getEventBus().post(new PlaySoundCommand("close_us"));
        }

        if (betsSidePanel != null && betsSidePanel.getOpenable() == true) {

            betsSidePanelBar.hidePanel();
            betsSidePanelMaxButtonView.moveDown();
            betsSidePanelMinButtonView.moveUp();
            betsSidePanelMainButton.setVisible(true);
            betsSidePanelDragButton.setVisible(false);
            betsSidePanelDragButton.setButtonNormalState();
            setVisibleValuesInBetsSidePanel(false);
            this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
            this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
        }
        unpressButton();
    }

    /**
     * Hides side lines panel
     */
    private void hideLinesSidePanel() {
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(linesSidePanel);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(300);
        animationData.setDestinationX(-188f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();

        //linesSidePanel.setVisible(false);
        //linesSidePanelMainButton.setVisible(false);
        setVisibleValuesInLinesSidePanel(false);
    }

    /**
     * Hides side bets panel
     */
    private void hideBetsSidePanel() {
        TweenViewAnimation tweenViewAnimationBets = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimationBets.setTargetView(betsSidePanel);

        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(300);
        animationData.setDestinationX(1970f);
        tweenViewAnimationBets.setViewAnimationData(animationData);
        if (betsSidePanel != null) {
            tweenViewAnimationBets.play();
            // betsSidePanelMainButton.setVisible(false);
            setVisibleValuesInBetsSidePanel(false);
        }
        // betsSidePanel.setVisible(false);

    }

    /**
     * Shows lines side panel
     */
    private void showLinesSidePanel() {
        if (!linesSidePanelInitialized) {
            initializeSideLinesPanel();
            return;
        }

        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(linesSidePanel);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(300);
        animationData.setDestinationX(12f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
        linesSidePanel.setVisible(true);
        linesSidePanelMainButton.setVisible(true);
    }

    /**
     * Shows bets side panel
     */
    private void showBetsSidePanel() {
        if (!betsSidePanelInitialized) {
            initializeSideBetsPanel();
            return;
        }
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(betsSidePanel);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(300);
        animationData.setDestinationX(1770f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();


        // betsSidePanel.setVisible(true);
        betsSidePanelMainButton.setVisible(true);
    }

    /**
     * Shows buttons with values on lines side panel
     *
     * @param value line value on button
     */
    private void setVisibleValuesInLinesSidePanel(boolean value) {
        if (linesSidePanel.getOpenable() == true) {
            for (ButtonView button : linesButtonsList) {
                button.setVisible(value);
            }

            linesSidePanelDragButton.setY(setDragLinesButtonPosition());
        }
    }

    /**
     * Shows buttons with values on bets side panel
     *
     * @param value bet value on button
     */
    private void setVisibleValuesInBetsSidePanel(boolean value) {
        if (betsSidePanel.getOpenable() == true) {
            for (ButtonView button : betsButtonsList) {
                button.setVisible(value);

            }
            betsSidePanelDragButton.setY(setDragBetsButtonPosition());
        }
    }

    /**
     * Release handler for side panel line button
     */

    private void onLineButtonRelease(String buttonId) {//TODO - add Condition
        closeSlidePanelTimer();
        setSelectedLinesAmount(Integer.valueOf(buttonId));


        for (SidePanelButton lineButton : linesButtonsList) {
            if (lineButton.getId().equals(buttonId) && Integer.parseInt(lineButton.getId()) <= getLinesModel().getMaxLines()) {
                lineButton.setSelectedFont();
            } else {
                lineButton.setNormalFont();
            }
        }

        if (getLinesModel().getSelectedLines() == getLinesModel().getMaxLines()) {
            getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
        } else if (getLinesModel().getSelectedLines() == getLinesModel().getMinLines()) {
            getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));
        } else if (getBetModel().getBetPerLine() == previousBet) {
            getEventBus().post(new PlaySoundCommand(SAME_BET_SOUND_ID_PROPERTY));
        }
        previousLine = getLinesModel().getSelectedLines();
        linesSidePanelDragButton.setY(setDragLinesButtonPosition());
    }

    /**
     * Release handler for side panel bet button
     */
    private void onBetButtonRelease(String buttonId) {
        closeSlidePanelTimer();
        if (getLinesModel().getSelectedLines() * Integer.parseInt(buttonId) <= ((AbstractReelGame) GameEngine.current().getGame()).getAccountModelProvider().getAccountModel().getBalance()) {

            for (SidePanelButton betButton : betsButtonsList) {
                if (betButton.getId().equals(buttonId)) {
                    betButton.setSelectedFont();
                } else {
                    betButton.setNormalFont();
                }
            }
            getEventBus().post(new SetBetCommand(Long.valueOf(buttonId), true));
            if (getBetModel().getBetPerLine() == getBetModel().getMaxBet()) {
                getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
            } else if (getBetModel().getBetPerLine() == getBetModel().getMinBet()) {
                getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));
            } else if (getBetModel().getBetPerLine() == previousBet) {
                getEventBus().post(new PlaySoundCommand(SAME_BET_SOUND_ID_PROPERTY));
            }
            previousBet = getBetModel().getBetPerLine();
            betsSidePanelDragButton.setY(setDragBetsButtonPosition());
        }

    }

    /**
     * Sets positions of drag button on lines side panel
     */
    private float setDragLinesButtonPosition() {
        float positionY;
        int currentLine = getModel().getLine();
        for (SidePanelButton button : linesButtonsList) {
            if (button.getId().equals((Integer.toString(currentLine)))) {
                positionY = button.getY() - linesSidePanel.getY() - SidePanel.MARGIN_OFFSET;
                return positionY;
            }
        }
        throw new IllegalArgumentException("Could not find button for the line = " + currentLine);
    }

    /**
     * Sets positions of drag button on bets side panel
     */
    private float setDragBetsButtonPosition() {
        float positionY;
        long currentBet = getModel().getBet();
        for (SidePanelButton button : betsButtonsList) {
            if (button.getId().equals((Long.toString(currentBet)))) {
                positionY = button.getY() - betsSidePanel.getY() - SidePanel.MARGIN_OFFSET;
                return positionY;
            }
        }
        throw new IllegalArgumentException("Could not find button for the line = " + currentBet);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ScreenShowingEventObserver(), ScreenShowingEvent.class);
        getEventBus().register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        getEventBus().register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        getEventBus().register(new ScreenShownEventObserver(), ScreenShownEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
        getEventBus().register(new LanguageChangedEventObserver(), LanguageChangedEvent.class);
        getEventBus().register(new VolumeChangedEventObserver(), VolumeChangedEvent.class);
        getEventBus().register(new TestEventObserver(), TestEvent.class);
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
        setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.FALSE);

        setModelProperty(EN_SETTINGS_BUTTON_VISIBLE, Boolean.TRUE);
        setModelProperty(SETTINGS_BUTTON_ENABLE2, Boolean.TRUE);
        setModelProperty(DE_SETTINGS_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(CS_SETTINGS_BUTTON_VISIBLE, Boolean.FALSE);

        getEventBus().post(new VolumeChangedEvent(1));

        infoScreensIds = new ArrayList<String>();
        infoScreensIds.add("featureInfoScreen");
        infoScreensIds.add("rulesInfoScreen");
        infoScreensIds.add("gamblerInfoScreen");
        infoScreensIds.add("rtpInfoScreen");

        showInfoScreenAnimationData = new TweenViewAnimationData();
        showInfoScreenAnimationData.setDestinationY(0F);
        showInfoScreenAnimationData.setTimeSpan(400);

        quickButton = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "mainID"), "turbo");

/*        enSettingsButton = findViewById("enSettingsButton");

        enSettingsButton.addEventListener((e) -> {
            if (((InputEvent) e).getType() == InputEventType.TOUCH_START && enSettingsButton.isEnabled()) {
                setModelProperty(SETTINGS_BUTTON_ENABLE2, Boolean.FALSE);
                GameEngine.current().getActionManager().processQueue("EnterSettings", true);
//                getModel().setProperty(SETTINGS_BUTTON_ENABLE2, Boolean.FALSE);
                getModel().update();
*//*                new Timeout(600, () -> {
                    if(!enSettingsButton.isEnabled()){
                        setModelProperty(SETTINGS_BUTTON_ENABLE2, Boolean.TRUE);
//                        getModel().setProperty(SETTINGS_BUTTON_ENABLE2, Boolean.TRUE);
                        getModel().update();
                    }

                }, true).start();*//*
            }
        });*/

        /**
         * for flashing turbo button
         */
        class ButtonViewReleasedListener implements IEventListener<InputEvent> {
            private ButtonView buttonView;

            public ButtonViewReleasedListener(ButtonView buttonView) {
                this.buttonView = buttonView;
            }

            public void onEvent(InputEvent event) {
                if (event.getType() == InputEventType.RELEASED) {
                    if (turboMode) {
                        quickButton.setAlpha(0.01f);

                    } else {
                        quickButton.setAlpha(1f);
                    }

                }
            }
        }
        quickButton.addEventListener(new ButtonViewReleasedListener(quickButton));
        initializeSideLinesPanel();
        initializeSideBetsPanel();
        initializeIndicatorTextIDs();
    }

    /**
     * Sets panels property for displaying min max values
     */
    private void setPanelsProperties() {
        this.getModel().setProperty(SidePanel.MIN_LINE_VALUE, this.getLinesModel().getMinLines() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_LINE_VALUE, "MAX\n" + this.getLinesModel().getMaxLines());
        this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
    }

    @Override
    protected void stateChanged() {
        super.stateChanged();
        hideAllButtons();
        switch (getCurrentState()) {
            case ReelsPresentationStates.IDLE:
                if (showSidePanelTimer != null) {
                    showSidePanelTimer.clear();
                }
                showSidePanelTimer = new Timeout(3000, timeOutShowSidePanel, true);

                setModelProperty(SPIN_ENABLE, Boolean.TRUE);
                InitHandlingLogoMovies.enableTimer(true);//start splash screen video
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                setModelProperty(INFO_ENABLE, Boolean.TRUE);

                getModel().getProperty(INFO_ENABLE).get();

                GameEngine.current().getEventBus().post(new TestEvent());

                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);
                setModelProperty(SETTINGS_BUTTON_ENABLE, Boolean.TRUE);
                setPanelsProperties();
                updateVisibleBetButtons();
                updateVisibleLineButtons();
                break;
            case ReelsPresentationStates.RUNNING_REELS:
                if (setButtonPressedTimer != null) {
                    setButtonPressedTimer.clear();
                }

                hideLinesSidePanel();
                hideBetsSidePanel();
                isHiddenSlidePanels = true;
                //closeSlidePanles();
                break;
            case ReelsPresentationStates.WIN_COUNTING:
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.STOPPING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.REELS_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_STOPPING_REELS:
            case FreeGamesPresentationStates.FREE_GAMES_RETRIGGER:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.OFFER_GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                if (!isAutoPlay) {
                    setModelProperty(GAMBLE_VISIBLE, Boolean.TRUE);
                }
                break;
            case ReelsPresentationStates.GAMBLER_LOSE:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                break;
            case ReelsPresentationStates.GAMBLER_WIN:
                break;
            case ReelsPresentationStates.GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.HISTORY:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                break;
            case ReelsPresentationStates.HISTORY_WIN:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.NONE:
                closeSlidePanles();
                setModelProperty(INFO_ENABLE, Boolean.FALSE);
                setModelProperty(SETTINGS_BUTTON_ENABLE, Boolean.FALSE);
                break;
            case FreeGamesPresentationStates.FREE_GAMES_RUNNING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            case FreeGamesPresentationStates.FREE_GAMES_HISTORY:
                updateFreeGamesWin(freeGamesModelProvider.getModel());
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            default:
                break;
        }
    }

    /**
     * Sets button to normal, unpressed state.
     */
    private void unpressButton() {
        List<SidePanelButtonView> sidePanelButtonsViews = (List<SidePanelButtonView>) findViewInheritingType(SidePanelButtonView.class);
        InitHandlingLogoMovies.enableTimer(false);//stop splash screen video
        for (SidePanelButtonView view : sidePanelButtonsViews) {
            view.setButtonNormalState();
        }
    }

    @ExposeMethod
    boolean returnSettingEnable() {
        return true;
    }

    @ExposeMethod
    @Override
    public void decreaseBet() {
        closeSlidePanelTimer();
        super.decreaseBet();
        if (getBetModel().getBetPerLine() == getBetModel().getMinBet()) {
            getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));

            for (SidePanelButton button : betsButtonsList) {
                if (button.getId().equals(getBetModel().getMinBet() + "")) {
                    button.setSelectedFont();
                } else {
                    button.setNormalFont();
                }
            }

        } else {

            for (int i = betsButtonsList.size() - 1; i > 0; i--) {
                if (Integer.parseInt(betsButtonsList.get(i).getId()) <= getBetModel().getBetPerLine()) {
                    betsButtonsList.get(i).setSelectedFont();
                    break;
                } else {
                    betsButtonsList.get(i).setNormalFont();
                }
            }
        }
        betsSidePanelDragButton.setY(setDragBetsButtonPosition());
        unpressButton();
    }

    @ExposeMethod
    @Override
    public void increaseBet() {
        closeSlidePanelTimer();
        /**
         *For the assumed value
         */
        String newBetValue = null;

        for (ButtonView button : betsButtonsList) {
            if (Integer.parseInt(button.getId()) > getBetModel().getBetPerLine()) {
                newBetValue = button.getId();
                break;
            }
        }
        //Check if there is enough balance for the bets increase
        if (newBetValue != null && (getBetModel().getBetPerLine() < (getBetModel().getMaxBet())) && (getLinesModel().getSelectedLines() * Integer.parseInt(newBetValue) <=
                ((AbstractReelGame) GameEngine.current().getGame()).getAccountModelProvider().getAccountModel().getBalance())) {
            getEventBus().post(new IncreaseBetCommand(true));

            for (SidePanelButton betButton : betsButtonsList) {
                if (betButton.getId().equals(newBetValue)) {
                    betButton.setSelectedFont();
                } else {
                    betButton.setNormalFont();
                }
            }

        } else if (getBetModel().getBetPerLine() == getBetModel().getMaxBet()) {
            getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
        } else {
            getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
        }
        previousBet = getBetModel().getBetPerLine();
        betsSidePanelDragButton.setY(setDragBetsButtonPosition());
        unpressButton();
    }

    @ExposeMethod
    @Override
    public void decreaseLines() {
        closeSlidePanelTimer();
        if (getLinesModel().getSelectedLines() == getLinesModel().getSelectedLines()) {
            getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));

            for (SidePanelButton button : linesButtonsList) {
                if (button.getId().equals(getLinesModel().getMinLines() + "")) {
                    button.setSelectedFont();
                } else {
                    button.setNormalFont();
                }
            }

        } else {
            String newLineValue = null;

            for (int i = linesButtonsList.size() - 1; i > 0; i--) {
                if (Integer.parseInt(linesButtonsList.get(i).getId()) <= getLinesModel().getSelectedLines()) {
                    linesButtonsList.get(i).setSelectedFont();
                    break;
                } else {
                    linesButtonsList.get(i).setNormalFont();
                }
            }
        }
        super.decreaseLines();
        if (getLinesModel().getSelectedLines() == getLinesModel().getMaxLines()) {
            getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
        } else if (getLinesModel().getSelectedLines() == getLinesModel().getMinLines()) {
            getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));
        }
        linesSidePanelDragButton.setY(setDragLinesButtonPosition());
        unpressButton();
    }

    @ExposeMethod
    @Override
    public void increaseLines() {
        super.increaseLines();
        if (getLinesModel().getSelectedLines() == getLinesModel().getMaxLines()) {
            getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
        } else if (getLinesModel().getSelectedLines() == getLinesModel().getMinLines()) {
            getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));
        }
        linesSidePanelDragButton.setY(setDragLinesButtonPosition());
        unpressButton();

        String newLineValue = "";
        for (ButtonView button : linesButtonsList) {
            if (Integer.parseInt(button.getId()) == getLinesModel().getSelectedLines()) {
                newLineValue = button.getId();
                break;
            }
        }


        for (SidePanelButton lineButton : linesButtonsList) {
            if (lineButton.getId().equals(newLineValue)) {
                lineButton.setSelectedFont();
            } else {
                lineButton.setNormalFont();
            }
        }

    }

    /**
     * Set lines to value entered from the param.
     *
     * @param linesAmount number of chosen lines.
     */
    private void setSelectedLinesAmount(int linesAmount) {
        if (getCurrentState().equals(ReelsPresentationStates.IDLE)) {
            getEventBus().post(new SetLinesCommand(linesAmount, true));
            if (getLinesModel().getSelectedLines() == getLinesModel().getMaxLines()) {
                getEventBus().post(new PlaySoundCommand(MAX_BET_SOUND_ID_PROPERTY));
            } else if (getLinesModel().getSelectedLines() == getLinesModel().getMinLines()) {
                getEventBus().post(new PlaySoundCommand(MIN_BET_SOUND_ID_PROPERTY));
            } else if (getLinesModel().getSelectedLines() == previousLine) {
                getEventBus().post(new PlaySoundCommand(SAME_BET_SOUND_ID_PROPERTY));
            }
            previousLine = linesAmount;
            linesSidePanelDragButton.setY(setDragLinesButtonPosition());
        }
    }

    /**
     * Handles the visibility of active buttons.
     */
    @ExposeMethod
    public void toggleActiveButtonsView() {
        if (getProperty(ACTIVE_BUTTONS_VISIBLE).equals(true)) {
            setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.FALSE);
        } else {
            setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.TRUE);
        }
    }

    /**
     * Updates visible bet buttons.
     */
    private void updateVisibleBetButtons() {
/*        if (getBetModel() == null) {
            return;
        }
        setModelProperty(BET_INCREASE_ENABLE, getBetModel().getBetPerLine() < (getBetModel().getMaxBet()));
        setModelProperty(BET_DECREASE_ENABLE, getBetModel().getBetPerLine() > (getBetModel().getMinBet()));*/
    }

    /**
     * Updates visible line buttons.
     */
    private void updateVisibleLineButtons() {
        if (getLinesModel() == null) {
            return;
        }
        setModelProperty(LINES_DECREASE_ENABLE, getLinesModel().getSelectedLines() > getLinesModel().getMinLines());
        setModelProperty(LINES_INCREASE_ENABLE, getLinesModel().getSelectedLines() < getLinesModel().getMaxLines());
    }

    @Subscribe
    @Override
    public void handleMessageChangedEvent(MessageChangedEvent messageChangedEvent) {
        if (BasicMessageType.BOTTOM_PANEL.equals(messageChangedEvent.getMessage().getMessageType())) {
            String message = messageChangedEvent.getMessage().getContent().replace("\n", "- ").replace("\r", "- ");
            getModel().setMessage(message);
        }
    }

    /**
     * Reacts to start the info screen transition.
     *
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (screenShowingEvent.getScreen() instanceof InfoScreen) {
            InitHandlingLogoMovies.enableTimer(false);
            hideAllButtons();
        }
    }

    @Override
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        super.handleBetModelChangedEvent(betModelChangedEvent);
        updateVisibleBetButtons();
    }

    @Override
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        super.handleLinesModelChangedEvent(linesModelChangedEvent);
        String state = getCurrentState();
        if (state != null && state.equals(ReelsPresentationStates.IDLE)) {
            updateVisibleLineButtons();
        }
    }

    /**
     * Reacts to finish the info screen transition.
     *
     * @param screenShownEvent screen shown event
     */
    @Subscribe
    public void handleScreenShownEvent(ScreenShownEvent screenShownEvent) {
        if (screenShownEvent.getScreen() instanceof InfoScreen && getCurrentState().equals(ReelsPresentationStates.IDLE)) {
            setModelProperty(INFO_ENABLE, Boolean.TRUE);
            if (showSidePanelTimer != null) {
                showSidePanelTimer.clear();
            }
            showSidePanelTimer = new Timeout(3000, timeOutShowSidePanel, true);
            InitHandlingLogoMovies.enableTimer(true);

            setModelProperty(SPIN_ENABLE, Boolean.TRUE);
            setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
            setModelProperty(BET_DECREASE_ENABLE, Boolean.TRUE);
            setModelProperty(BET_INCREASE_ENABLE, Boolean.TRUE);
            updateVisibleBetButtons();
            updateVisibleLineButtons();
        }
    }

    /**
     * Hides all buttons.
     */
    private void hideAllButtons() {
        setModelProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        setModelProperty(SPIN_ENABLE, Boolean.FALSE);
        setModelProperty(TAKE_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(BET_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(GAMBLE_VISIBLE, Boolean.FALSE);
        setModelProperty(BET_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(INFO_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, isAutoPlay);
    }

    /**
     * Handles event about that auto play was started.
     *
     * @param autoPlayStartedEvent {@link AutoPlayStartedEvent}
     */
    @Subscribe
    public void handleAutoPlayStartedEvent(AutoPlayStartedEvent autoPlayStartedEvent) {
        isAutoPlay = true;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.TRUE);
        autoplayButtomListener.startPlaySound();
    }

    /**
     * Handles the free games model changed event.
     *
     * @param freeGamesModelChangedEvent {@link FreeGamesModelChangedEvent}
     */
    @Subscribe
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        updateFreeGamesWin(freeGamesModelChangedEvent.getFreeGamesModel());
    }

    /**
     * Handles the language changed event.
     *
     * @param languageChangedEvent {@link LanguageChangedEvent}
     */
    private void handleLanguageChangedEvent(LanguageChangedEvent languageChangedEvent) {
        setModelProperty(EN_SETTINGS_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(DE_SETTINGS_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(CS_SETTINGS_BUTTON_VISIBLE, Boolean.FALSE);
        switch (languageChangedEvent.getLanguageCode()) {
            case "EN":
                setModelProperty(EN_SETTINGS_BUTTON_VISIBLE, Boolean.TRUE);
                break;
            case "DE":
                setModelProperty(DE_SETTINGS_BUTTON_VISIBLE, Boolean.TRUE);
                break;
            case "CS":
                setModelProperty(CS_SETTINGS_BUTTON_VISIBLE, Boolean.TRUE);
                break;
            default:
                throw (new IllegalArgumentException(
                        "Illegal argument passed to handleLanguageChangedEvent(LanguageChangedEvent languageChangedEvent) method in QueenCleopatraBottomPanelScreen."));
        }

    }

    /**
     * Changes volume and updates volume buttons.
     *
     * @param volumeValue int
     */
    @ExposeMethod
    public void changeVolume(int volumeValue) {
        switch (volumeValue) {
            case 0:
                getEventBus().post(new ChangeGlobalVolumeCommand(0.6f));
                volumeValue = 1;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 1:
                getEventBus().post(new ChangeGlobalVolumeCommand(1));
                volumeValue = 2;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 2:
                getEventBus().post(new ChangeGlobalVolumeCommand(0.33f));
                volumeValue = 0;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            default:
                throw (new IllegalArgumentException("Illegal argument passed to changeVolume(int volumeValue) method in QueenCleopatraBottomPanelScreen."));
        }
        getEventBus().post(new VolumeChangedEvent(volumeValue));
    }

    /**
     * Handles volume changed event.
     */
    @ExposeMethod
    public void handleVolumeChangedEvent(VolumeChangedEvent volumeChangedEvent) {
        setModelProperty(LOW_VOLUME_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(MID_VOLUME_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(HIGH_VOLUME_BUTTON_VISIBLE, Boolean.FALSE);
        switch (volumeChangedEvent.getVolume()) {
            case 0:
                setModelProperty(LOW_VOLUME_BUTTON_VISIBLE, Boolean.TRUE);
//                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 1:
                setModelProperty(MID_VOLUME_BUTTON_VISIBLE, Boolean.TRUE);
//                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 2:
                setModelProperty(HIGH_VOLUME_BUTTON_VISIBLE, Boolean.TRUE);
//                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            default:
                throw (new IllegalArgumentException(
                        "Illegal argument passed to handleVolumeChangedEvent(VolumeChangedEvent volumeChangedEvent) method in QueenCleopatraBottomPanelScreen."));
        }
    }

    /**
     * Updates the win based on the current win in free games.
     *
     * @param freeGamesModel {@link IFreeGamesModel}
     */
    private void updateFreeGamesWin(IFreeGamesModel freeGamesModel) {
        if (freeGamesModel == null) {
            return;
        }
        long winAmount = freeGamesModel.getTotalWinAmount();
        long currentGameWinAmount = freeGamesModel.getCurrentGameWinAmount();
        if (freeGamesModel.getCurrentFreeGameNumber() > 0) {
            getCurrentWinController().setCurrentWin(winAmount - currentGameWinAmount);
            updateProperties();
        }
    }

    /**
     * Handles event about that auto play was stopped.
     *
     * @param autoPlayStoppedEvent {@link AutoPlayStoppedEvent}
     */
    @Subscribe
    public void handleAutoPlayStoppedEvent(AutoPlayStoppedEvent autoPlayStoppedEvent) {
        isAutoPlay = false;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.FALSE);
        autoplayButtomListener.stopPlaySound();
    }

    private class ScreenShowingEventObserver extends NextObserver<ScreenShowingEvent> {

        @Override
        public void onNext(final ScreenShowingEvent screenShowingEvent) {
            handleScreenShowingEvent(screenShowingEvent);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(final AutoPlayStoppedEvent autoPlayStoppedEvent) {
            handleAutoPlayStoppedEvent(autoPlayStoppedEvent);
            if (turboMode) {
                setTurboMode();
            }
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(final AutoPlayStartedEvent autoPlayStartedEvent) {
            handleAutoPlayStartedEvent(autoPlayStartedEvent);
        }
    }

    private class ScreenShownEventObserver extends NextObserver<ScreenShownEvent> {

        @Override
        public void onNext(final ScreenShownEvent screenShownEvent) {
            handleScreenShownEvent(screenShownEvent);
        }
    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);
        }
    }

    private class LanguageChangedEventObserver extends NextObserver<LanguageChangedEvent> {

        @Override
        public void onNext(final LanguageChangedEvent languageChangedEvent) {
            handleLanguageChangedEvent(languageChangedEvent);
        }
    }

    private class VolumeChangedEventObserver extends NextObserver<VolumeChangedEvent> {

        @Override
        public void onNext(final VolumeChangedEvent volumeChangedEvent) {
            handleVolumeChangedEvent(volumeChangedEvent);
        }
    }

    /**
     * Used for big win mode
     *
     * @param setEnable
     */
    @Override
    public void setSkipEnable(boolean setEnable) {
        if (setEnable) {
            setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
        } else {
            setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        }
    }


    @Override
    public TextView getIndicatorTextID2() {
        return indicatorTextID2;
    }

    @Override
    public TextView getIndicatorTextID1() {
        return indicatorTextID;
    }

    @ExposeMethod
    public void setTurboMode() {
        int reelTime;
        int increment;
        int numberOfReels = 5;
        if (!turboMode) {
            turboMode = true;
            reelTime = 0;
            increment = 50;

        } else {
            quickButton.setAlpha(1f);
            turboMode = false;
            reelTime = 400;
            increment = 300;
        }

        if (reelGroupView == null) {
            reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        }
        spinTime.clear();
        spinTime.add(reelTime);
        for (int i = 1; i < numberOfReels; i++) {
            spinTime.add(spinTime.get(i - 1) + increment);
        }
        reelGroupView.setStopOnSymbolsSequenceProvider(new ReelDelayedSequenceProvider(spinTime));
    }

    @ExposeMethod
    @Override
    public boolean getTurbomode() {
        return turboMode;
    }

    /**
     * For auto close slide panel
     */
    private void closeSlidePanelTimer() {
        if (closeSlidePanelTimer != null) {
            closeSlidePanelTimer.clear();
        }
        closeSlidePanelTimer = new Timeout(10000, timeOutLogoAnimation, true);
    }


    private class TestEventObserver extends NextObserver<TestEvent> {

        @Override
        public void onNext(TestEvent event) {
            System.out.println();
        }
    }

    @ExposeMethod
    public void spinOrCloseSlidePanels() {
        if (isOpenSlidePanels) {
            closeSlidePanles();
        } else {
            spin();
        }
    }

    public void setIndicatorSum(Long winSum) {
        indicatorCollectSum = winSum;
    }

    public Long getIndicatorSum() {
        return indicatorCollectSum;
    }
}