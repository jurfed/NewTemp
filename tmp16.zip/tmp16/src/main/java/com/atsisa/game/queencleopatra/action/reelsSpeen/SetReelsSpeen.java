package com.atsisa.game.queencleopatra.action.reelsSpeen;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.view.ReelDelayedSequenceProvider;
import com.atsisa.gox.reels.view.ReelGroupView;

import java.util.ArrayList;

/**
 * To adjust the speed of reels
 */
public class SetReelsSpeen extends Action<SetReelsSpeenActionData> {

    private int reelTime = 400;//Before first reel will be stopped
    private int increment = 300;//Before next reel will be stopped
    private final int numberOfReels = 5;

    @Override
    protected void execute() {
        if (!this.actionData.getTurboMode()){
            reelTime=400;
            increment = 300;
            
        }else{
            reelTime=200;
            increment = 100;
        }
        ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        ArrayList<Integer> spinTime = new ArrayList(numberOfReels);
        spinTime.add(reelTime);
        for (int i = 1; i < numberOfReels; i++) {
            spinTime.add(spinTime.get(i - 1) + increment);
        }

        reelGroupView.setStopOnSymbolsSequenceProvider(new ReelDelayedSequenceProvider(spinTime));

        finish();
    }

    @Override
    public Class<SetReelsSpeenActionData> getActionDataType() {
        return SetReelsSpeenActionData.class;
    }
}
