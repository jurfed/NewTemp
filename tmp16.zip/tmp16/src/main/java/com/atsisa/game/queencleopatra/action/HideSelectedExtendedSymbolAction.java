package com.atsisa.game.queencleopatra.action;


import com.atsisa.game.queencleopatra.command.HideSelectedExtendedSymbolCommand;
import com.atsisa.game.queencleopatra.event.HiddenExtendedSymbolEvent;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;

/**
 * Request for hide feature extended symbol animation
 */
public class HideSelectedExtendedSymbolAction extends WaitForEventAction<HiddenExtendedSymbolEvent> {

    /**
     * Initializes a new instance of the {@link HideSelectedExtendedSymbolAction} class.
     */
    public HideSelectedExtendedSymbolAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link HideSelectedExtendedSymbolAction} class.
     * @param logger   {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public HideSelectedExtendedSymbolAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new HideSelectedExtendedSymbolCommand());
    }

    @Override
    protected Class<HiddenExtendedSymbolEvent> getEventClass() {
        return HiddenExtendedSymbolEvent.class;
    }
}