package com.atsisa.game.queencleopatra.action.playSounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.view.TextView;

import static com.atsisa.game.queencleopatra.action.playSounds.StartSoundSpeenReelBaseGame.getSoundId;

public class StopSoundSpeenReelBaseGame extends Action {

    private SoundManager spinReelSound;

    @Override
    protected void execute() {
        spinReelSound = (SoundManager) GameEngine.current().getSoundManager();
        if(spinReelSound!=null) {
            spinReelSound.stop(getSoundId());
        }

        TextView tv = GameEngine.current().getViewManager().findViewById("bottomPanelScreen","win");

        tv.getText();

        finish();
    }
}
