package com.atsisa.game.queencleopatra;

import com.atsisa.game.queencleopatra.logic.vocs.QeenCleopatraGameLogicModule;
import com.atsisa.game.queencleopatra.message.processing.QueenCleopatraFreeGamesMessageProcessor;
import com.atsisa.game.queencleopatra.screen.*;
import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraFeatureScreenModel;
import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraFreeGamesInfoBannerScreenModel;
import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraPayTableScreenModel;
import com.atsisa.game.queencleopatra.screen.model.SettingsModel;
import com.atsisa.game.queencleopatra.screen.transitions.QueenCleopatraInfoScreenTransition;
import com.atsisa.game.queencleopatra.screen.transitions.QueenCleopatraTopDownInfoScreenTransition;
import com.atsisa.gox.framework.IGame;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.configuration.GameConfiguration;
import com.atsisa.gox.framework.configuration.IGameConfiguration;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.ResourceDescriptionModel;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.utility.GameConfigurationStatics;
import com.atsisa.gox.framework.utility.IConfigurationProperties;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.DebugReelsCoreModule;
import com.atsisa.gox.reels.ExtendedSymbolModule;
import com.atsisa.gox.reels.FreeGamesModule;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.controller.*;
import com.atsisa.gox.reels.logic.vocs.ExtendedSymbolPresentationName;
import com.atsisa.gox.reels.logic.vocs.FreeGamesPresentationName;
import com.atsisa.gox.reels.logic.vocs.serialization.response.*;
import com.atsisa.gox.reels.message.processing.IMessageProcessor;
import com.atsisa.gox.reels.model.*;
import com.atsisa.gox.reels.screen.*;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.screen.model.HistoryScreenModel;
import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import dagger.multibindings.IntoSet;

import javax.inject.Named;
import javax.inject.Singleton;
import java.util.*;

/**
 * Represents an IoC module configuration.
 */
@Module(includes = {QeenCleopatraGameLogicModule.class, DebugReelsCoreModule.class, FreeGamesModule.class, ExtendedSymbolModule.class})
@SuppressWarnings("unused")
public abstract class QueenCleopatraCoreModule {

    @Binds
    @Singleton
    abstract IGame gameBind(QueenCleopatra queenCleopatra);

//    @Binds
//    @Singleton
//    abstract IGameConfiguration gameConfigurationBind(QueenCleopatraConfiguration queenCleopatraConfiguration);

    @Provides
    @Named(IConfigurationProperties.CONFIGURATION_PROPERTIES)
    static Map<String, String> configurationPropertiesBind() {
        Map<String, String> configurationProperties = new HashMap<>();
        configurationProperties.put(GameConfigurationStatics.GAME_RESOLUTION, "FHD_TWO_MONITORS");
        return configurationProperties;
    }


    @Binds
    @Singleton
    abstract IGameConfiguration gameConfigurationBind(GameConfiguration gameConfiguration);

    @Singleton
    @Provides
    @IntoSet
    static ResourceDescriptionModel queenCleopatraResourceDescriptionModelBind() {
        return new ResourceDescriptionModel("", "resources.xml");
    }

/*    @Provides
    @Singleton
    static ITranslationProvider translationProviderBind(IResourceManager resourceManager, IXmlSerializer serializer, IParser parser, ILogger logger) {
        LocalResourceTranslationProvider localResourceTranslationProvider = new LocalResourceTranslationProvider(resourceManager, serializer, parser, logger);
        Set translationsIds = new HashSet<String>();
        translationsIds.add("translations");
        localResourceTranslationProvider.setLanguagesResourcesId(translationsIds);
        return localResourceTranslationProvider;
    }*/

    @Provides
    @Singleton
    static IMutator<ILinesModel> noLinesModelMutatorBind() {
        return new NoLinesModelMutator();
    }


    @Binds
    @Singleton
    abstract IDenominationModelProvider denominationModelProviderBind(DenominationModelProvider provider);

    @Binds
    @Singleton
    abstract IBottomPanelCreditsController controllerBind(BottomPanelCreditsDenominationController controller);

    @Binds
    @Singleton
    abstract IBottomPanelBetController betControllerBind(BetDenominationController controller);

    @Binds
    @Singleton
    abstract ICreditsFormatter creditsFormatterBind(CreditsDenominationFormatter creditsFormatter);

    @Binds
    @Singleton
    @IntoSet
    abstract IMessageProcessor gamesMessageProcessorBind(QueenCleopatraFreeGamesMessageProcessor gamesMessageProcessor);

    @Singleton
    @Provides
    @Named(ExtendedSymbolWinSerializationStrategy.EXTENDED_SYMBOL_WIN_PRESENTATIONS)
    static Set<String> extendedSymbolWinSerializationStrategyBind() {
        HashSet<String> freeGamesPresentations = new HashSet<>(FreeGamesPresentationName.AvailableNames);
        freeGamesPresentations.remove(FreeGamesPresentationName.ENTER_FREE_GAMES);
        return freeGamesPresentations;
    }

    @Singleton
    @Provides
    @Named(ExtendedSymbolSerializationStrategy.EXTENDED_SYMBOL_PRESENTATIONS)
    static Set<String> extendedSymbolSerializationStrategyBind() {
        HashSet<String> freeGamesPresentations = new HashSet<>(FreeGamesPresentationName.AvailableNames);
        freeGamesPresentations.remove(FreeGamesPresentationName.ENTER_FREE_GAMES);
        return freeGamesPresentations;
    }

    @Singleton
    @Provides
    @Named(CommonSerializationStrategy.COMMON_PRESENTATIONS)
    static Set<String> commonSerializationStrategyBind() {
        return new HashSet<String>() {{
            addAll(FreeGamesPresentationName.AvailableNames);
            addAll(ExtendedSymbolPresentationName.AvailableNames);
        }};
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesWinSerializationStrategy.FREE_GAMES_WIN_PRESENTATIONS)
    static String freeGamesWinSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesSerializationStrategy.FREE_GAMES_PRESENTATIONS)
    static String freeGamesSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }

    @Singleton
    @Provides
    @IntoSet
    @Named(FreeGamesInfoSerializationStrategy.FREE_GAMES_INFO_PRESENTATIONS)
    static String freeGamesInfoSpecialScatterBind() {
        return ExtendedSymbolPresentationName.SPECIAL_SCATTER;
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.LAYOUT_ID_PROPERTY)
    static String gamblerScreenLayoutBind() {
        return "gamblerScreen";
    }

    @Singleton
    @Provides
    @Named(InfoScreen.LAYOUT_ID_PROPERTY)
    static String infoScreenLayoutBind() {
        return "infoScreen";
    }

    @Singleton
    @Provides
    @Named(WinLinesScreen.LAYOUT_ID_PROPERTY)
    static String winLineScreenLayoutBind() {
        return "winLinesScreen";
    }

    @Singleton
    @Provides
    @Named(BottomPanelScreen.LAYOUT_ID_PROPERTY)
    static String bottomPanelScreenLayoutBind() {
        return "bottomPanelScreen";
    }

    @Singleton
    @Provides
    @Named(BaseGameScreen.LAYOUT_ID_PROPERTY)
    static String baseGameScreenLayoutBind() {
        return "baseGameScreen";
    }

    @Singleton
    @Provides
    @Named(DebugScreen.LAYOUT_ID_PROPERTY)
    static String debugScreenLayoutBind() {
        return "debugScreen";
    }

    @Singleton
    @Provides
    @Named(LanguageScreen.LAYOUT_ID_PROPERTY)
    static String languageScreenLayoutBind() {
        return "languageScreen";
    }

    @Singleton
    @Provides
    @Named(HistoryScreen.LAYOUT_ID_PROPERTY)
    static String historyScreenLayoutBind() {
        return "historyScreen";
    }

    @Provides
    @Singleton
    @Named(ErrorScreen.LAYOUT_ID_PROPERTY)
    static String errorScreenLayoutBind() {
        return "errorScreen";
    }

    @Provides
    @Singleton
    @Named(FadeScreen.LAYOUT_ID_PROPERTY)
    static String fadeScreenLayoutBind() {
        return FadeScreen.LAYOUT_ID_DEFAULT;
    }

    @Singleton
    @Provides
    @Named(QueenCleopatraFreeGamesBannerScreen.LAYOUT_ID_PROPERTY)
    static String freeGamesBannerScreenLayoutBind() {
        return "freeGamesBannerScreen";
    }

    @Singleton
    @Provides
    @Named(QueenCleopatraPayTableScreen.QUEEN_CLEOPATRA_PAYTABLE_LAYOUT_ID_PROPERTY)
    static String payTableScreenLayoutBind() {
        return "payTableScreen";
    }

    @Singleton
    @Provides
    @Named(QueenCleopatraEnterFeatureBannerScreen.LAYOUT_ID_PROPERTY)
    static String enterFeatureBannerScreenLayoutBind() {
        return "enterFeatureBannerScreen";
    }

    @Singleton
    @Provides
    @Named(QueenCleopatraDenominationScreen.LAYOUT_ID_PROPERTY)
    static String denominationScreenLayoutBind() {
        return "denominationScreen";
    }

    @Singleton
    @Provides
    @Named(QueenCleopatraSettingsScreen.LAYOUT_ID_PROPERTY)
    static String settingsScreenLayoutBind() {
        return "settingsScreen";
    }

    @Singleton
    @Provides
    @IntoSet
    static Screen bottomPanelScreenBind(IGameConfiguration gameConfiguration,
                                        @Named(BottomPanelScreen.LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel, IRenderer renderer,
                                        IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IMutator<ILinesModel> linesModelMutator,
                                        IResourceManager resourceManager, IParser parser, IXmlSerializer xmlSerializer, IFreeGamesModelProvider freeGamesModelProvider,
                                        IDenominationModelProvider denominationModelProvider,
                                        @Named(BottomPanelScreen.BUTTON_STATES_RESOURCES_ID) Optional<Set<String>> buttonStatesResourcesId,
                                        Optional<IBottomPanelBetController> bottomPanelBetController, Optional<IBottomPanelCreditsController> bottomPanelCreditsController,
                                        Optional<ICurrentWinController> currentWinController) {

        BottomPanelScreen bottomPanelScreen;

        switch (gameConfiguration.getResolution()) {
            case FHD_THREE_MONITORS:
                bottomPanelScreen = new QueenCleopatraVipLoungeBottomPanelScreen(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory,
                        logger, eventBus, linesModelMutator, resourceManager, parser, xmlSerializer, freeGamesModelProvider, denominationModelProvider);
                break;

            case FHD_TWO_MONITORS:
                bottomPanelScreen = new QueenCleopatraOctavianBottomPanelScreen(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory,
                        logger, eventBus, linesModelMutator, resourceManager, parser, xmlSerializer, freeGamesModelProvider, denominationModelProvider);
                break;

            case WXGA_5_3:
                bottomPanelScreen = new QueenCleopatraAGIBottomPanelScreen(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger,
                        eventBus, linesModelMutator, resourceManager, parser, xmlSerializer, freeGamesModelProvider, denominationModelProvider);
                break;

            default:
                throw (new IllegalArgumentException(
                        "Illegal argument displayResolutionType: \"" + gameConfiguration.getResolution() + "\" passed to bottomPanelScreenBind method in QueenCleopatraCoreModule"));
        }

        bottomPanelScreen.setButtonStatesResourcesId(buttonStatesResourcesId);
        bottomPanelScreen.setBetController(bottomPanelBetController);
        bottomPanelScreen.setCreditsController(bottomPanelCreditsController);
        bottomPanelScreen.setCurrentWinController(currentWinController);
        return bottomPanelScreen;
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.INFO_SCREEN_SHOW_ANIMATION_SOUND_ID_PROPERTY)
    static String infoScreenShowSoundBind(IGameConfiguration gameConfiguration) {
        switch (gameConfiguration.getResolution()) {
            case FHD_THREE_MONITORS:
            case WXGA_5_3:
                return "Shift";

            case FHD_TWO_MONITORS:
                return "ShiftDef";

            default:
                throw (new IllegalArgumentException("Illegal argument displayResolutionType: \"" + gameConfiguration.getResolution()
                        + "\" passed to infoScreenShowSoundBind method in QueenCleopatraCoreModule"));
        }
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_OFF_SOUND_ID_PROPERTY)
    static String autoPlayOnSoundBind(IGameConfiguration gameConfiguration) {
        switch (gameConfiguration.getResolution()) {
            case FHD_THREE_MONITORS:
            case WXGA_5_3:
                return "AutoPlayOff";

            case FHD_TWO_MONITORS:
                return "AutoPlayOffDef";

            default:
                throw (new IllegalArgumentException(
                        "Illegal argument displayResolutionType: \"" + gameConfiguration.getResolution() + "\" passed to autoPlayOnSoundBind method in QueenCleopatraCoreModule"));
        }
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.AUTO_PLAY_ON_SOUND_ID_PROPERTY)
    static String autoPlayOffSoundBind(IGameConfiguration gameConfiguration) {
        switch (gameConfiguration.getResolution()) {
            case FHD_THREE_MONITORS:
            case WXGA_5_3:
                return "AutoPlayOn";

            case FHD_TWO_MONITORS:
                return "AutoPlayOnDef";

            default:
                throw (new IllegalArgumentException(
                        "Illegal argument displayResolutionType: \"" + gameConfiguration.getResolution() + "\" passed to autoPlayOffSoundBind method in QueenCleopatraCoreModule"));
        }
    }

    @Singleton
    @Provides
    @Named(ReelGameSoundModel.BET_CHANGING_SOUND_ID_PROPERTY)
    static String betChangingSoundBind(IGameConfiguration gameConfiguration) {
        switch (gameConfiguration.getResolution()) {
            case FHD_THREE_MONITORS:
            case WXGA_5_3:
                return "BetChanging";

            case FHD_TWO_MONITORS:
                return "BetChangingDef";

            default:
                throw (new IllegalArgumentException(
                        "Illegal argument displayResolutionType: \"" + gameConfiguration.getResolution() + "\" passed to betChangingSoundBind method in QueenCleopatraCoreModule"));
        }
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_REVERSED_RED_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyReversedRedCardBind() {
        return "@spriteSheet/cardShift/shirt_full_small";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyClubsCardBind() {
        return "@spriteSheet/cardShift/clubs_small";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyDiamondCardBind() {
        return "@spriteSheet/cardShift/diamond_small";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historyHeartCardBind() {
        return "@spriteSheet/cardShift/heart_small";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HISTORY_SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String historySpadeCardBind() {
        return "@spriteSheet/cardShift/spades_small";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.SPADE_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String spadeCardBind() {
        return "@spriteSheet/cardShift/spades";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.CLUBS_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String clubsCardBind() {
        return "@spriteSheet/cardShift/clubs";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.HEART_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String heartCardBind() {
        return "@spriteSheet/cardShift/heart";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.DIAMOND_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String diamondCardBind() {
        return "@spriteSheet/cardShift/diamond";
    }

    @Singleton
    @Provides
    @Named(GamblerScreen.REVERSED_BLACK_CARD_RESOURCE_REFERENCE_PROPERTY)
    static String reversedBlackCardBind() {
        return "@spriteSheet/cardShift2/shirt_full";
    }

    @Singleton
    abstract HistoryScreenModel historyScreenModelBind();

    @Singleton
    abstract GamblerScreenModel gamblerScreenModelBind();

    @Provides
    @Singleton
    static BottomPanelScreenModel bottomPanelScreenModelBind(ITranslator translator) {
        return new BottomPanelScreenModel(translator);
    }

    @Singleton
    abstract QueenCleopatraPayTableScreenModel queenCleopatraPayTableScreenModelBind();

    @Singleton
    abstract QueenCleopatraFreeGamesInfoBannerScreenModel queenCleopatraFreeGamesInfoBannerScreenModelBind();

    @Singleton
    abstract QueenCleopatraFeatureScreenModel queenCleopatraFeatureScreenModelBind();

    @Provides
    @Singleton
    static QueenCleopatraInfoScreenTransition infoScreenTransitionBind() {
        return new QueenCleopatraTopDownInfoScreenTransition();
    }

    @Binds
    @Singleton
    @IntoSet
    abstract Screen enterFeatureBannerScreenBind(QueenCleopatraEnterFeatureBannerScreen enterFeatureBannerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen denominationScreenBind(QueenCleopatraDenominationScreen denominationScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen settingsScreenBind(QueenCleopatraSettingsScreen settingsScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen freeGamesBannerScreenBind(QueenCleopatraFreeGamesBannerScreen freeGamesBannerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen gamblerScreenBind(QueenCleopatraGamblerScreen gamblerScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen infoScreenBind(QueenCleopatraInfoScreen infoScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen baseGameScreenBind(BaseGameScreen baseGameScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen payTableScreenBind(QueenCleopatraPayTableScreen payTableScreen);

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen bottomPanelScreenBind(QueenCleopatraBottomPanelScreen bottomPanelScreen);*/

    @Binds
    @Singleton
    @IntoSet
    abstract Screen languageScreenBind(LanguageScreen languageScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen winLinesScreenBind(WinLinesScreen winLinesScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen debugScreenBind(DebugScreen debugScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen historyScreenBind(HistoryScreen historyScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen fadeScreenBind(FadeScreen fadeScreen);


    @Singleton
    @Provides
    static SettingsModel settingsModelBind(ITranslator translator) {
        return new SettingsModel(translator);
    }

/*    @Binds
    @Singleton
    @IntoSet
    abstract Screen sampleScreenBind(SampleScreen sampleScreen);

    @Binds
    @Singleton
    @IntoSet
    abstract Screen bigWinScreenBind(BigWinScreen bigWinScreen);*/


}