package com.atsisa.game.queencleopatra.action;

import com.atsisa.game.queencleopatra.command.ShowSelectedExtendedSymbolCommand;
import com.atsisa.gox.framework.action.WaitForEventAction;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.game.queencleopatra.event.ShownExtendedSymbolEvent;

/**
 * Request for stop feature extended symbol animation at specified symbol
 */
public class ShowSelectedExtendedSymbolAction extends WaitForEventAction<ShownExtendedSymbolEvent> {

    /**
     * Initializes a new instance of the {@link ShowSelectedExtendedSymbolAction} class.
     */
    public ShowSelectedExtendedSymbolAction() {
        super();
    }

    /**
     * Initializes a new instance of the {@link ShowSelectedExtendedSymbolAction} class.
     * @param logger   {@link ILogger} a logger reference
     * @param eventBus {@link IEventBus} a event bus reference
     */
    public ShowSelectedExtendedSymbolAction(ILogger logger, IEventBus eventBus) {
        super(logger, eventBus);
    }

    @Override
    protected void execute() {
        super.execute();
        eventBus.post(new ShowSelectedExtendedSymbolCommand());
    }

    @Override
    protected Class<ShownExtendedSymbolEvent> getEventClass() {
        return ShownExtendedSymbolEvent.class;
    }
}