package com.atsisa.game.queencleopatra.action.bigWin.awesomeWin;

import aurelienribon.tweenengine.TweenCallback;
import com.atsisa.game.queencleopatra.action.bigWin.BigWin;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.InitState;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.Step;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.WinObject;
import com.atsisa.game.queencleopatra.helpers.bigWin.BigWinHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.spi.IImageBlendMode;
import javafx.scene.effect.BlendMode;
import rx.functions.Action1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Describes the logic of the Awesome Win animation
 */
public class AwesomeWin implements BigWin {
    private boolean stop = false;
    private final String LAYOUT_ID = "BigWinScreen";

    private final String AWESOME_WIN_ID = "AWESOME_WIN_ID";
    private final String AWESOME_WIN_ID_2 = "AWESOME_WIN_ID_2";
    private final String INDICATOR_ID = "Indicator";
    private final String WIN_TEXT_ID = "winText";

    //sounds
    private final String BELL = "bell";
    private final String COLLECT = "collect";
    private final String COLLECT_END = "collect_end";

    private View bigWinImageView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, AWESOME_WIN_ID);
    private View bigWinImageView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, AWESOME_WIN_ID_2);
    private View IndicatorView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, INDICATOR_ID);
    private View winTextView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, WIN_TEXT_ID);

    private List<View> views = new ArrayList(){{
        add(bigWinImageView); add(IndicatorView); add(winTextView); add(bigWinImageView2);
    }};

    private int sum = 0;
    private ShowBigWin showBigWinClass;

    private List<WinObject> objects = new ArrayList();

    /**
     * List of parameters for each step for this object
     */
    private  WinObject bigWinStepParam, bigWinStepParam2, indicatorStepParam, winTextStepParam;

    /**
     * Step counter for each animation object
     */
    private Integer[] steps = new Integer[4];

    /**
     * Flag for the end of animation cycles
     */
    private static Boolean [] loopStop = new Boolean[1];

    /**
     * A list of hash maps with parameters that depend on the number of digits in the win sum
     */
    private List<HashMap> textSteps = new ArrayList();

    private BigWinHelper helper;

    /**
     * Collecting time
     */
    private Float collectTime;

    /**
     * Parsing the xml file awesomeWin.xml
     * @param sum - amount of winnings
     * @param showBigWinClass
     * @param collect
     */
    public AwesomeWin(int sum, ShowBigWin showBigWinClass, Float collect) {
        collectTime=collect;
        this.sum = sum;
        this.showBigWinClass = showBigWinClass;
        objects.add(bigWinStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(0));
        objects.add(indicatorStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(1));
        objects.add(winTextStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(2));
        objects.add(bigWinStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(3));
    }

    /**
     * initialization
     * music launch
     */
    @Override
    public void execute() {
        helper = new BigWinHelper();
        initStartStates();
        showBigWin();
        new Timeout(0, new BigWinHelper.PlayMarshc(BELL), true).start();
        new Timeout(2000, new BigWinHelper.PlayMarshc(COLLECT), true).start();
    }

    /**
     * Initial state of objects
     */
    @Override
    public void initStartStates() {
        stop = false;
        helper.initObjects(showBigWinClass, views, steps,loopStop);
        ((TextView) winTextView).setText("0");
        textSteps.clear();
        textSteps = helper.prepareTextParameters((int) sum, IndicatorView, winTextView);
    }

    /**
     * Running the first steps of the animation
     */
    @Override
    public void showBigWin() {

        Step step;

        for (int i = 0; i < steps.length; i++) {
            if(i!=2&&i!=1){
                step = ((Step) objects.get(i).steps.get(steps[i]));
                helper.runStep(views.get(i), step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) this);
            }
        }

        step = ((Step) indicatorStepParam.steps.get(steps[1]));
        helper.runStep(IndicatorView, (float) (textSteps.get(steps[1])).get("indicatorX"), step.Y, (float) (textSteps.get(steps[1])).get("scaleX"), step.SCALEY, step.TIME, step.ALPHA, steps, this);
        step = ((Step) winTextStepParam.steps.get(steps[2]));
        helper.runStep(winTextView, (float) (textSteps.get(steps[2])).get("textX"), (float) (textSteps.get(steps[2])).get("textY"), step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, this);
        helper.collect((TextView) winTextView, sum, collectTime, loopStop);
    }

    @Override
    public void tweenListener(View view, TweenViewAnimation tweenViewAnimation, Integer[] steps, BigWin showBigWin) {
        tweenViewAnimation.getTweenStateObservable().subscribe(new Action1<Integer>() {

            /**
             * Here we write what to do after the completion of any animation step of the object.
             * For example, we start the next step
             * @param tweenEvent
             */
            @Override
            public void call(Integer tweenEvent) {
                if (tweenEvent == TweenCallback.COMPLETE) {
                    Integer objectId = null;
                    Step step = null;
                    if (view.getId().equals(AWESOME_WIN_ID)) {
                        objectId = 0;
                        steps[objectId]++;
                        if (steps[objectId] == 3) {//Last runStep for all animation
                            lastStep();
                        }
                        if (steps[objectId] != 4) {//The usual next runStep
                            step = ((Step) bigWinStepParam.steps.get(steps[objectId]));
                            helper.runStep(bigWinImageView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) bigWinStepParam2.steps.get(steps[objectId]));
                            helper.runStep(bigWinImageView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        } else {
                            helper.end(new ArrayList() {{add(bigWinImageView);add(IndicatorView);add(winTextView);add(bigWinImageView2);}}, COLLECT_END);
                            showBigWinClass.endAction();
                        }
                    } else if (view.getId().equals(INDICATOR_ID)) {
                        objectId = 1;
                        steps[objectId]++;
                        if (steps[objectId] == 1) {//Do the second animation and do nothing more
                            step = ((Step) indicatorStepParam.steps.get(steps[objectId]));
                            helper.runStep(IndicatorView, (float) (textSteps.get(steps[objectId])).get("indicatorX"), step.Y, (float) (textSteps.get(steps[1])).get("scaleX"), step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    } else if (view.getId().equals(WIN_TEXT_ID)) {
                        objectId=2;
                        steps[objectId]++;
                        if (steps[objectId] == 1) {//Do the second animation and do nothing more
                            step = ((Step) winTextStepParam.steps.get(steps[objectId]));
                            helper.runStep(winTextView, (float) (textSteps.get(steps[objectId])).get("textX"), (float) (textSteps.get(steps[2])).get("textY"), step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    }
                    circle(steps, objectId,step);
                }
            }
        });
    }

    /**
     * Check to continue animations in the loop
     * @param steps
     * @param objectId
     * @param step
     */
    @Override
    public void circle(Integer[] steps, Integer objectId, Step step){
        if (!loopStop[0] && step!=null) {steps[objectId] = steps[objectId] - step.CYCLE;}
    }

    @Override
    public void lastStep() {
        stop = true;
        for (int i = 1; i < steps.length; i++) {
            Step step = ((Step) objects.get(i).steps.get(objects.get(i).steps.size() - 1));
            helper.runStep(views.get(i), step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) this);
        }
    }

}