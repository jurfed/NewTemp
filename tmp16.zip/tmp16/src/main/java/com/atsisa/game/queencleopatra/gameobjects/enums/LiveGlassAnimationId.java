package com.atsisa.game.queencleopatra.gameobjects.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration of the identifiers of the animation symbols, which are specified in the payTableBgrScreen.xml
 */
public enum LiveGlassAnimationId {

    cleoAnimationLong(0), tenAnimationShort(1),queenAnimationLong(2), tenAnimationLong(3), statueAnimationLong(4), aceAnimationLong(5),
    frame_upper_left(6), frame_bottom_right(7), frame_bottom_left(8),frame_middle_left(9), jackAnimationLong(10), kingAnimationLong(11),
    scarabAnimationLong(12),frame_upper_right(13), frame_middle_right(14), mummyAnimationLong(15), cleoAnimationShort(16),aceAnimationShort(17),
    kingAnimationShort(18), queenAnimationShort(19), jackAnimationShort(20), scarabAnimationShort(21), mummyAnimationShort(22), statueAnimationShort(23);

    public static String[] getSyblosAnimationsNames() {
        return Arrays.toString(LiveGlassAnimationId.values()).replaceAll("^.|.$", "").split(", ");
    }

    private static final Map<Integer,LiveGlassAnimationId> lookup
            = new HashMap<Integer,LiveGlassAnimationId>();

    static {
        for(LiveGlassAnimationId w : EnumSet.allOf(LiveGlassAnimationId.class))
            lookup.put(w.getCode(), w);
    }

    private int code;

    private LiveGlassAnimationId(int code) {
        this.code = code;
    }

    public int getCode() { return code; }

    public static LiveGlassAnimationId get(int code) {
        return lookup.get(code);
    }
}