package com.atsisa.game.queencleopatra.command;

import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.reels.command.ShowInfoScreenCommand;

public class ShowInfoScreenWithOrderCommand extends ShowInfoScreenCommand {

    /**
     * Order of currently displayed info screen.
     */
    private int order;

    /**
     * Amount of all info screens.
     */
    private int amount;

    /**
     * Initializes a new instance of the {@link ShowInfoScreenWithOrderCommand} class.
     * @param screenId              the id of the screen
     * @param showViewAnimationData {@link TweenViewAnimationData}
     */
    public ShowInfoScreenWithOrderCommand(String screenId, TweenViewAnimationData showViewAnimationData) {
        super(screenId, showViewAnimationData);
    }

    /**
     * Sets info screen's order.
     * @param order
     */
    public void setInfoScreenOrder(int order) {
        this.order = order;
    }

    /**
     * Returns info screen's order.
     * @return int
     */
    public int getInfoScreenOrder() {
        return this.order;
    }

    /**
     * Sets total info screens amount.
     * @param amount
     */
    public void setInfoScreensAmount(int amount) {
        this.amount = amount;
    }

    /**
     * Gets total info screens amount.
     * @return int
     */
    public int getInfoScreensAmount() {
        return amount;
    }
}

