package com.atsisa.game.queencleopatra.action.freeGames;

import aurelienribon.tweenengine.TweenCallback;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.View;
import rx.functions.Action1;

/**
 * Class for the effect of the appearance of the panel freeGamesBannerScreen
 */
public class ShowFreeGamesWonPanel extends Action {

    /**
     * The first picture of the panel
     */
    private final View WON_PANEL0 = GameEngine.current().getViewManager().findViewById("wonPanelScreen", "won0");

    /**
     * The second picture of the panel
     */
    private final View WON_PANEL1 = GameEngine.current().getViewManager().findViewById("wonPanelScreen", "won1");

    /**
     * The third picture of the panel
     */
    private final View WON_PANEL2 = GameEngine.current().getViewManager().findViewById("wonPanelScreen", "won2");

    /**
     * The fourth picture of the panel
     */
    private final View WON_PANEL3 = GameEngine.current().getViewManager().findViewById("wonPanelScreen", "won3");

    private final View MAIN_WON_PANEL = GameEngine.current().getViewManager().findViewById("wonPanelScreen", "you_won_plate");

    private final float BEGIN_TRANSPARENCY_FOR_FIRST_PICTURE = 0.02f;
    private final float END_TRANSPARENCY_FOR_FIRST_PICTURE = 1;
    private final float BEGIN_TRANSPARENCY_FOR_FOURTH_PICTURE = 1;
    private final float END_TRANSPARENCY_FOR_FOURTH_PICTURE = 0.009f;

    private final int TIME_FOR_FIRST_PICTURE = 700;
    private final int TIME_FOR_SECOND_PICTURE = 50;
    private final int TIME_FOR_THIRD_PICTURE = 250;

    private final float BEGIN_SCALE_X_FOR_FIRST_PICTURE = 1.41f;
    private final float BEGIN_SCALE_Y_FOR_FIRST_PICTURE = 1.29f;
    private final float END_SCALE_X_FOR_FIRST_PICTURE = 3.2f;
    private final float END_SCALE_Y_FOR_FIRST_PICTURE = 2.5f;

/*    private final float BEGIN_X_FOR_FIRST_PICTURE=580;
    private final float BEGIN_Y_FOR_FIRST_PICTURE=1323;
    private final float DESTINATION_X_FOR_FIRST_PICTURE=145f;
    private final float DESTINATION_Y_FOR_FIRST_PICTURE=725f;*/

    private final float BEGIN_X_FOR_FIRST_PICTURE = 385;
    private final float BEGIN_Y_FOR_FIRST_PICTURE = 224;
    private final float DESTINATION_X_FOR_FIRST_PICTURE = -50f;
    private final float DESTINATION_Y_FOR_FIRST_PICTURE = -374f;

    private final String ID_FOR_FIRST_PICTURE = "won0";
    private final String ID_FOR_SECOND_PICTURE = "won1";
    private final String ID_FOR_THIRD_PICTURE = "won2";
    private boolean finish = false;


    @Override
    protected void execute() {
        finish = false;
        ShowBigWin.getBottomPanelHelper().setSkipEnable(false);
        //Configure the first panel
        WON_PANEL0.setAlpha(BEGIN_TRANSPARENCY_FOR_FIRST_PICTURE);
        WON_PANEL0.setX(BEGIN_X_FOR_FIRST_PICTURE);
        WON_PANEL0.setY(BEGIN_Y_FOR_FIRST_PICTURE);
        WON_PANEL0.setScaleX(BEGIN_SCALE_X_FOR_FIRST_PICTURE);
        WON_PANEL0.setScaleY(BEGIN_SCALE_Y_FOR_FIRST_PICTURE);
        WON_PANEL0.setVisible(true);

        WON_PANEL3.setAlpha(BEGIN_TRANSPARENCY_FOR_FOURTH_PICTURE);

        showPanel0();//Show the first panel
//        finish();
    }

    /**
     * Animate the appearance of the first picture for the panel "10 Free Games won"
     */
    private void showPanel0() {
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(WON_PANEL0);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(TIME_FOR_FIRST_PICTURE);
        animationData.setDestinationAlpha(END_TRANSPARENCY_FOR_FIRST_PICTURE);
        animationData.setDestinationScaleX(END_SCALE_X_FOR_FIRST_PICTURE);
        animationData.setDestinationScaleY(END_SCALE_Y_FOR_FIRST_PICTURE);
        animationData.setDestinationX(DESTINATION_X_FOR_FIRST_PICTURE);
        animationData.setDestinationY(DESTINATION_Y_FOR_FIRST_PICTURE);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
        new Timeout(TIME_FOR_FIRST_PICTURE, new ShowNextWinPanelImage(WON_PANEL0, WON_PANEL1), true).start();
    }

    /**
     * The second picture of the panel
     */
    private void showPanel1() {
        WON_PANEL0.setVisible(false);
        WON_PANEL1.setVisible(true);
        new Timeout(TIME_FOR_SECOND_PICTURE, new ShowNextWinPanelImage(WON_PANEL1, WON_PANEL2), true).start();
    }

    ;

    /**
     * The third picture of the panel
     */
    private void showPanel2() {
        WON_PANEL1.setVisible(false);
        WON_PANEL2.setVisible(true);
        new Timeout(TIME_FOR_THIRD_PICTURE, new ShowNextWinPanelImage(WON_PANEL2, WON_PANEL3), true).start();
        showMainPanel();
    }

    /**
     * Animation transparency of the fourth panel
     */
    private void showMainPanel() {
        WON_PANEL2.setVisible(false);
        WON_PANEL3.setVisible(true);
        MAIN_WON_PANEL.setVisible(true);
        if(!finish){
            finish();
        }
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(WON_PANEL3);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(TIME_FOR_THIRD_PICTURE);
        animationData.setDestinationAlpha(END_TRANSPARENCY_FOR_FOURTH_PICTURE);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
        tweenListener(tweenViewAnimation);

    }

    public void tweenListener(TweenViewAnimation tweenViewAnimation) {
        tweenViewAnimation.getTweenStateObservable().subscribe(v -> {
            if (v == TweenCallback.COMPLETE) {
                ShowBigWin.getBottomPanelHelper().setSkipEnable(false);
            }
        });
    }


    /**
     * Timer for displaying the next picture of the panel
     */
    class ShowNextWinPanelImage implements TimeoutCallback {
        View viewPanelFalse;
        View viewPanelTrue;

        ShowNextWinPanelImage(View view1, View view2) {
            viewPanelFalse = view1;
            viewPanelTrue = view2;
        }

        @Override
        public void onTimeout() {

            if (viewPanelFalse.getId().equals(ID_FOR_FIRST_PICTURE)) {
                showPanel1();
            } else if (viewPanelFalse.getId().equals(ID_FOR_SECOND_PICTURE)) {
                showPanel2();
            } else if (viewPanelFalse.getId().equals(ID_FOR_THIRD_PICTURE)) {
                WON_PANEL3.setVisible(false);
                MAIN_WON_PANEL.setVisible(false);
            }
        }
    }

    @Override
    protected void terminate() {
        finish=true;

    }

}
