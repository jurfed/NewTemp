package com.atsisa.game.queencleopatra.action.bigWin;

import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.Step;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.view.View;

public interface BigWin{

    void execute();

    void showBigWin();

    void tweenListener(View view, TweenViewAnimation tweenViewAnimation, Integer[] steps, BigWin showBigWin);

    void initStartStates();

    void lastStep();

    void circle(Integer[] steps, Integer objectId, Step step);
}
