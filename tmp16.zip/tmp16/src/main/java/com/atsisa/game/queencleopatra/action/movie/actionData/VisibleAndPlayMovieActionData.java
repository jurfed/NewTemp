package com.atsisa.game.queencleopatra.action.movie.actionData;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

import java.util.HashMap;

/**
 * Data for classes SetVisibleAndPlayMovie and SetUnvisibleAndStopMovie
 */
@Reflect_Full
@XmlElement
public class VisibleAndPlayMovieActionData extends ActionData {

    @XmlAttribute
    private HashMap<Integer, String> videoLayoutId;

    @XmlAttribute
    private HashMap<Integer, String> videoId;

    public HashMap<Integer, String> getVideoLayoutId() {
        return videoLayoutId;
    }

    public void setVideoLayoutId(HashMap<Integer, String> videoLayoutId) {
        this.videoLayoutId = videoLayoutId;
    }


    public HashMap<Integer, String> getVideoId() {
        return videoId;
    }

    public void setVideoId(HashMap<Integer, String> videoId) {
        this.videoId = videoId;
    }

}
