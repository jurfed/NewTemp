package com.atsisa.game.queencleopatra.action.movie;

import com.atsisa.game.queencleopatra.action.movie.actionData.VisibleAndPlayMovieActionData;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.*;

import java.util.ArrayList;

/**
 * Standby video queue playback class
 */
public class SetVisibleAndPlayMovie extends Action<VisibleAndPlayMovieActionData> {
    private MovieView movie;

    /**
     * To determine the end of a video fragment
     */
    private VideoPlayListener videoPlayListener;

    /**
     * Current video number
     */
    private int currectVideoNumber;

    /**
     * Total video fragments in the queue
     */
    private int totalVideoNumber;

    /**
     * A flag that signals that the video needs to be stopped
     */
    static boolean stopMovie = false;

    /**
     * Flag, signaling that the video can be played
     */
    static boolean canPlay = true;

    private ArrayList<TextView> secondVideoText = new ArrayList<>();
    private ArrayList<KeyframeAnimationView> secondVideoFrames = new ArrayList<>();

    private ArrayList<TextView> fourthVideoText = new ArrayList<>();
    private ArrayList<KeyframeAnimationView> fourthVideoFrames = new ArrayList<>();

    private ArrayList<TextView> fifthVideoText = new ArrayList<>();
    private ArrayList<KeyframeAnimationView> fifthVideoFrames = new ArrayList<>();

    /**
     * Objects appear at a given value
     */
    private final float START_VISIBLE_ALPHA=0.02f;

    /**
     * Objects disappear at a given value
     */
    private final float END_VISIBLE_ALPHA=0.01f;

    /**
     * The Time of Becoming Transparency
     */
    private final int ANIMATION_TIME=1000;



    /**
     * Initialize the first video playback and video listener handler
     */
    @Override
    protected void execute() {
        initTextsAndFrames();
        currectVideoNumber = 1;
        videoPlayListener = new VideoPlayListener();
        playMoview(currectVideoNumber);
        totalVideoNumber = this.actionData.getVideoId().size();
        finish();
    }

    /**
     * Initialize additional objects above the playback video.
     */
    private void initTextsAndFrames() {
        //Objects for the second video fragment
        secondVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "LangOnActiveLinePays"));
        secondVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "Lang5000"));
        secondVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "LangTimesLineBet"));

        secondVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "cleoAnimationLong1"));
        secondVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "cleoAnimationLong2"));
        secondVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "cleoAnimationLong3"));
        secondVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "cleoAnimationLong4"));
        secondVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "cleoAnimationLong5"));

        //Objects for the fourth video fragment
        fourthVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "Lang3OrMoreScattered"));
        fourthVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "LangTrigger10Free"));

        fourthVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "tombSymbolWinShortAnimation"));

        //Objects for the fifth video fragment
        fifthVideoText.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "LangOneSymbolIs"));
        fifthVideoFrames.add(GameEngine.current().getViewManager().findViewById("payTableScreen", "bookAnimation"));
    }

    /**
     * Play video by its number
     *
     * @param number
     */
    private void playMoview(int number) {
        if (canPlay) {
            movie = GameEngine.current().getViewManager().findViewById(this.actionData.getVideoLayoutId().get(number), this.actionData.getVideoId().get(number));
            movie.setVisible(true);
            movie.addPropertyChangedListener(videoPlayListener);
            movie.play();
        }
    }

    /**
     * Plays all the videos in the queue
     */
    class VideoPlayListener implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            //If the video with this number is played, then we display the corresponding text and animation
            if (movie.isPlaying()) {
                switch (currectVideoNumber) {
                    case 2:
                        setStartKeyframeAnimation(secondVideoText, secondVideoFrames);
                        break;
                    case 4:
                        setStartKeyframeAnimation(fourthVideoText, fourthVideoFrames);
                        break;
                    case 5:
                        setStartKeyframeAnimation(fifthVideoText, fifthVideoFrames);
                        break;
                }
            }

            if (!movie.isPlaying()) {//Hide the video if it's played
                movie.removePropertyChangedListener(videoPlayListener);

                //If the video with this number is stop, then we hide the corresponding text and animation
                switch (currectVideoNumber) {
                    case 2:
                        setStopKeyframeAnimation(secondVideoText, secondVideoFrames);
                        break;
                    case 4:
                        setStopKeyframeAnimation(fourthVideoText, fourthVideoFrames);
                        break;
                    case 5:
                        setStopKeyframeAnimation(fifthVideoText, fifthVideoFrames);
                        break;
                }

                movie.stop();
                movie.setVisible(false);
                currectVideoNumber++;

                if (currectVideoNumber <= totalVideoNumber && !stopMovie) {//If there is still a video in the queue and the stop flag is not set
                    playMoview(currectVideoNumber);//Play the next video in the queue
                } else {
                    new Timeout(InitHandlingLogoMovies.videoTimer, new TimeOutLogoMoviePlay(InitHandlingLogoMovies.layoutIdHashMap, InitHandlingLogoMovies.videoIdHashMap), true).start();
                }
            }
        }
    }

    /**
     * Make smooth appearance and disappearance of video objects
     *
     * @param VideoText
     * @param VideoFrames
     */
    private void setStartKeyframeAnimation(ArrayList<TextView> VideoText, ArrayList<KeyframeAnimationView> VideoFrames) {
        for (TextView tv : VideoText) {
            tv.setVisible(true);
            tv.setAlpha(START_VISIBLE_ALPHA);
            tv.addPropertyChangedListener(new IViewPropertyChangedListener() {
                @Override
                public void propertyChanged(View view, ViewType viewType, int property) {
                    if (tv.getAlpha() < END_VISIBLE_ALPHA) {
                        tv.setVisible(false);
                        tv.removePropertyChangedListener(this::propertyChanged);
                    }
                }
            });
            playBeginTweenViewAnimation(tv, 1f);
        }

        for (KeyframeAnimationView kf : VideoFrames) {
            kf.setVisible(true);
            kf.setLoop(true);
            kf.setAlpha(START_VISIBLE_ALPHA);
            kf.addPropertyChangedListener(new IViewPropertyChangedListener() {
                @Override
                public void propertyChanged(View view, ViewType viewType, int property) {
                    if (kf.getAlpha() == 1) {
                        kf.play();
                    } else if (kf.getAlpha() < END_VISIBLE_ALPHA) {
                        kf.setVisible(false);
                        kf.setLoop(false);
                        kf.stop();
                        kf.removePropertyChangedListener(this::propertyChanged);
                    }
                }
            });
            playBeginTweenViewAnimation(kf, 1f);
        }
    }

    /**
     * Make transparency over the received object
     *
     * @param view
     * @param f
     */
    private void playBeginTweenViewAnimation(View view, float f) {
        TweenViewAnimation tweenViewAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        tweenViewAnimation.setTargetView(view);
        TweenViewAnimationData animationData = new TweenViewAnimationData();
        animationData.setTimeSpan(ANIMATION_TIME);
        animationData.setDestinationAlpha(f);
        tweenViewAnimation.setViewAnimationData(animationData);
        tweenViewAnimation.play();
    }

    /**
     * Hide character animation and text above the video
     *
     * @param VideoText
     * @param VideoFrames
     */
    private  void setStopKeyframeAnimation(ArrayList<TextView> VideoText, ArrayList<KeyframeAnimationView> VideoFrames) {
        for (TextView tv : VideoText) {
            playBeginTweenViewAnimation(tv, 0.009f);
        }

        for (KeyframeAnimationView kf : VideoFrames) {
            playBeginTweenViewAnimation(kf, 0.009f);
            kf.pause();

        }
    }


    @Override
    public void terminate() {
        movie.setVisible(false);
        movie.stop();
    }

    @Override
    public Class<VisibleAndPlayMovieActionData> getActionDataType() {
        return VisibleAndPlayMovieActionData.class;
    }
}
