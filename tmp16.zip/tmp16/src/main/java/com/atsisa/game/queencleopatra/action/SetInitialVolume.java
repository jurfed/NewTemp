package com.atsisa.game.queencleopatra.action;

import com.atsisa.game.queencleopatra.event.VolumeChangedEvent;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;

public class SetInitialVolume extends Action {

    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new VolumeChangedEvent(2));
        finish();
    }
}
