package com.atsisa.game.queencleopatra.action.playSounds;

import com.atsisa.game.queencleopatra.helpers.AutoplayButtomListener;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.view.*;

import java.util.ArrayList;
import java.util.List;

public class StartListeningAutoplayButton extends Action {
    boolean b = false;
    private final String LAYOUT_ID = "bottomPanelScreen";
    private final String START_BUTTOM_NAME = "autoPlayButton";
    private final String STOP_BUTTOM_NAME = "autoStopButton";
    private AutoplayButtomListener autoplayButtomListener;

    List<String> str2 = new ArrayList<String>();
    List<String> str = new ArrayList<String>();

    @Override
    protected void execute() {




        if (autoplayButtomListener == null) {

            autoplayButtomListener = new AutoplayButtomListener();

            ViewGroup activeGrp = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "autoPlayButtons");
            Iterable<View> children = activeGrp.getChildren();

            int viewNumber=0;
            for (View view : children){
                viewNumber++;
                if(viewNumber==1 || viewNumber==2){
                  //  ((ButtonView) view).addPropertyChangedListener(autoplayButtomListener);;
                }
            }

           // (GameEngine.current().getViewManager().findViewById(LAYOUT_ID, START_BUTTOM_NAME)).addPropertyChangedListener(autoplayButtomListener);
           // (GameEngine.current().getViewManager().findViewById(LAYOUT_ID, STOP_BUTTOM_NAME)).addPropertyChangedListener(autoplayButtomListener);
        }

       // ButtonView bv = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "skipButto2");


        class ButtonViewReleasedListener implements IEventListener<InputEvent> {
            private boolean released = false;

            @Override
            public void onEvent(InputEvent event) {

/*                if (!b && event.getType() == InputEventType.RELEASED) {
                    ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
//                    reelGroupView.getReel(4).stopOnSymbols(str);


                    b=true;

//                    reelGroupView.setSpinSequenceProvider(new ReelDelayedSequenceProvider(new ArrayList<Integer>(){{add(0);add(0);add(0);add(0);add(100);}}));;
                    //reelGroupView.getReel(4).getReelAnimation().getAnimatingSymbols();

                    Observer<AbstractSymbol> f = reelGroupView.getReel(4).getReelAnimation().getAnimatingSymbols();// getAnimatingSymbols();
                    Iterable<View> abs = reelGroupView.getReel(4).getChildren();

                    for (View v : abs) {
                        // int i=0;
                        for (View v2 : ((ViewGroup) v).getChildren()) {
                            if (v2 instanceof AbstractSymbol) {
                                // if(i<3) {
                                AbstractSymbol a = ((AbstractSymbol) v2);
                                System.out.println(a.getName());
                                str2.add(a.getName());
                                //     i++;
                                //  }
                            }
                        }
                    }
                    str=new ArrayList<String>();
                    str.add(0,str2.get(4));
                    str.add(1,str2.get(3));
                    str.add(2,str2.get(2));
                    str2=new ArrayList<String>();
*//*                    str.add("Jack");
                    str.add("Jack");
                    str.add("Jack");*//*

                    reelGroupView.getReel(4).forceStopOnSymbols(str);

                   // if()

*//*                    reelGroupView.getReel(4).setDisplayedSymbol(0, str.get(0));
                    reelGroupView.getReel(4).setDisplayedSymbol(0, str.get(1));
                    reelGroupView.getReel(4).setDisplayedSymbol(0, str.get(2));*//*
//                    reelGroupView.getReel(4).forceStopOnSymbols();
                    b=false;
                }*/

            }
        }
       // ButtonViewReleasedListener bb = new ButtonViewReleasedListener();
      //  bv.addEventListener(bb);

        finish();
    }
}
