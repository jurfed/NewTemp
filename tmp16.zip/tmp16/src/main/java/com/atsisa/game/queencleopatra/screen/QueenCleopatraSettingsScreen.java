package com.atsisa.game.queencleopatra.screen;

import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.game.queencleopatra.event.VolumeChangedEvent;
import com.atsisa.game.queencleopatra.screen.model.SettingsModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.command.ChangeGlobalVolumeCommand;
import com.atsisa.gox.framework.command.ChangeLanguageCommand;
import com.atsisa.gox.framework.command.PlaySoundCommand;
import com.atsisa.gox.framework.event.LanguageChangedEvent;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.gwtent.reflection.client.Reflectable;

@Reflectable
public class QueenCleopatraSettingsScreen extends Screen<SettingsModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "settingsScreen";

    /**
     * Name of the property which is responsible if language tab is visible or not.
     */
    private static final String LANGUAGE_TAB_VISIBLE = "languageTabVisible";

    /**
     * Name of the property which is responsible if sound tab is visible or not.
     */
    private static final String SOUND_TAB_VISIBLE = "soundTabVisible";

    /**
     * Name of the property which is responsible if gambler tab is visible or not.
     */
    private static final String GAMBLER_TAB_VISIBLE = "gamblerTabVisible";

    /**
     * Name of the property which is responsible if language button is visible or not.
     */
    private static final String LANGUAGE_BUTTON_VISIBLE = "languageButtonVisible";

    /**
     * Name of the property which is responsible if sound button is visible or not.
     */
    private static final String SOUND_BUTTON_VISIBLE = "soundButtonVisible";

    /**
     * Name of the property which is responsible if gambler button is visible or not.
     */
    private static final String GAMBLER_BUTTON_VISIBLE = "gamblerButtonVisible";

    /**
     * Name of the property which is responsible if english flag is visible or not.
     */
    private static final String ENGLISH_FLAG_VISIBLE = "englishFlagVisible";

    /**
     * Name of the property which is responsible if german flag is visible or not.
     */
    private static final String GERMAN_FLAG_VISIBLE = "germanFlagVisible";

    /**
     * Name of the property which is responsible if czech flag is visible or not.
     */
    private static final String CZECH_FLAG_VISIBLE = "czechFlagVisible";

    /**
     * Name of the property which is responsible if volume low button is visible or not.
     */
    private static final String VOLUME_LOW_VISIBLE = "volumeLowVisible";

    /**
     * Name of the property which is responsible if volume mid button is visible or not.
     */
    private static final String VOLUME_MID_VISIBLE = "volumeMidVisible";

    /**
     * Name of the property which is responsible if volume high button is visible or not.
     */
    private static final String VOLUME_HIGH_VISIBLE = "volumeHighVisible";

    /**
     * Name of the property which is responsible if mechanical sound on button is visible or not.
     */
    private static final String MECHANICAL_ON_VISIBLE = "mechanicalOnVisible";

    /**
     * Name of the property which is responsible if mechanical sound off button is visible or not.
     */
    private static final String MECHANICAL_OFF_VISIBLE = "mechanicalOffVisible";

    /**
     * Name of the property which is responsible if mechanical sound on button is visible or not.
     */
    private static final String MUSIC_ON_VISIBLE = "musicOnVisible";

    /**
     * Name of the property which is responsible if mechanical sound off button is visible or not.
     */
    private static final String MUSIC_OFF_VISIBLE = "musicOffVisible";

    /**
     * Name of the property which is responsible if mechanical sound on button is visible or not.
     */
    private static final String CLASSIC_ON_VISIBLE = "classicOnVisible";

    /**
     * Name of the property which is responsible if mechanical sound off button is visible or not.
     */
    private static final String CLASSIC_OFF_VISIBLE = "classicOffVisible";

    /**
     * Name of the property which is responsible if gambler on on button is visible or not.
     */
    private static final String GAMBLER_ON_ON_VISIBLE = "gamblerOnOnVisible";

    /**
     * Name of the property which is responsible if gambler on off button is visible or not.
     */
    private static final String GAMBLER_ON_OFF_VISIBLE = "gamblerOnOffVisible";

    /**
     * Name of the property which is responsible if gambler off on button is visible or not.
     */
    private static final String GAMBLER_OFF_ON_VISIBLE = "gamblerOffOnVisible";

    /**
     * Name of the property which is responsible if gambler off off button is visible or not.
     */
    private static final String GAMBLER_OFF_OFF_VISIBLE = "gamblerOffOffVisible";

    /**
     * option in the settings panel
     */
    private static boolean gambleOn = true;

    /**
     * Instance of a translator.
     */
    ITranslator translator;

    /**
     * Title text view.
     */
    // @InjectView
    //  TextView title;
    @Inject
    protected QueenCleopatraSettingsScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, SettingsModel model, IRenderer renderer, IViewManager viewManager,
                                           IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, ITranslator translator) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.translator = translator;

        setModelProperty(GAMBLER_ON_ON_VISIBLE, Boolean.TRUE);
        setModelProperty(GAMBLER_ON_OFF_VISIBLE, Boolean.FALSE);

        setModelProperty(GAMBLER_OFF_ON_VISIBLE, Boolean.FALSE);
        setModelProperty(GAMBLER_OFF_OFF_VISIBLE, Boolean.TRUE);
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();

        setModelProperty(LANGUAGE_TAB_VISIBLE, Boolean.TRUE);
        setModelProperty(SOUND_TAB_VISIBLE, Boolean.FALSE);
        setModelProperty(GAMBLER_TAB_VISIBLE, Boolean.FALSE);

        setModelProperty(LANGUAGE_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(SOUND_BUTTON_VISIBLE, Boolean.TRUE);
        setModelProperty(GAMBLER_BUTTON_VISIBLE, Boolean.TRUE);

        setModelProperty(MECHANICAL_ON_VISIBLE, Boolean.TRUE);
        setModelProperty(MUSIC_ON_VISIBLE, Boolean.FALSE);
        setModelProperty(CLASSIC_ON_VISIBLE, Boolean.FALSE);

        setModelProperty(MECHANICAL_OFF_VISIBLE, Boolean.FALSE);
        setModelProperty(MUSIC_OFF_VISIBLE, Boolean.TRUE);
        setModelProperty(CLASSIC_OFF_VISIBLE, Boolean.TRUE);



        //temp
//        title.setText(translator.translatePhrase("LangLanguage").get());
        //title.setText("LANGUAGE");

        updateLanguageFlag(translator.getActiveLanguageCode());

    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new LanguageChangedEventObserver(), LanguageChangedEvent.class);
        getEventBus().register(new VolumeChangedEventObserver(), VolumeChangedEvent.class);
    }

    private void handleLanguageChangedEvent(LanguageChangedEvent languageChangedEvent) {
        //temp
//        title.setText(translator.translatePhrase("LangLanguage").get());
        // title.setText("LANGUAGE");
        updateLanguageFlag(languageChangedEvent.getLanguageCode());
    }

    /**
     * Updates language flag.
     *
     * @param languageCode string
     */
    private void updateLanguageFlag(String languageCode) {
        setModelProperty(ENGLISH_FLAG_VISIBLE, Boolean.FALSE);
        setModelProperty(GERMAN_FLAG_VISIBLE, Boolean.FALSE);
        setModelProperty(CZECH_FLAG_VISIBLE, Boolean.FALSE);
        switch (languageCode) {
            case "EN":
                setModelProperty(ENGLISH_FLAG_VISIBLE, Boolean.TRUE);
                break;
            case "DE":
                setModelProperty(GERMAN_FLAG_VISIBLE, Boolean.TRUE);
                break;
            case "CS":
                setModelProperty(CZECH_FLAG_VISIBLE, Boolean.TRUE);
                break;
            default:
                throw (new IllegalArgumentException(
                        "Illegal argument passed to handleLanguageChangedEvent(LanguageChangedEvent languageChangedEvent) method in QueenCleopatraSettingsScreen."));
        }
    }

    /**
     * Changes language and updates flag image.
     *
     * @param languageCode code of a language
     */
    @ExposeMethod
    public void changeLanguage(String languageCode) {
        getEventBus().post(new ChangeLanguageCommand(languageCode));
    }

    private void handleVolumeChangedEvent(VolumeChangedEvent volumeChangedEvent) {
        setModelProperty(VOLUME_LOW_VISIBLE, Boolean.FALSE);
        setModelProperty(VOLUME_MID_VISIBLE, Boolean.FALSE);
        setModelProperty(VOLUME_HIGH_VISIBLE, Boolean.FALSE);
        switch (volumeChangedEvent.getVolume()) {
            case 0:
                setModelProperty(VOLUME_LOW_VISIBLE, Boolean.TRUE);
                break;
            case 1:
                setModelProperty(VOLUME_MID_VISIBLE, Boolean.TRUE);
                break;
            case 2:
                setModelProperty(VOLUME_HIGH_VISIBLE, Boolean.TRUE);
                break;
            default:
                throw (new IllegalArgumentException(
                        "Illegal argument passed to handleVolumeChangedEvent(VolumeChangedEvent volumeChangedEvent) method in QueenCleopatraSettingsScreen."));
        }
    }

    /**
     * Shows tab of specified index.
     *
     * @param tabIndex index of a tab
     */
    @ExposeMethod
    public void showTab(int tabIndex) {
        setModelProperty(LANGUAGE_TAB_VISIBLE, Boolean.FALSE);
        setModelProperty(SOUND_TAB_VISIBLE, Boolean.FALSE);
        setModelProperty(GAMBLER_TAB_VISIBLE, Boolean.FALSE);

        setModelProperty(LANGUAGE_BUTTON_VISIBLE, Boolean.TRUE);
        setModelProperty(SOUND_BUTTON_VISIBLE, Boolean.TRUE);
        setModelProperty(GAMBLER_BUTTON_VISIBLE, Boolean.TRUE);

        switch (tabIndex) {
            case 0:
                //temp
//                title.setText(translator.translatePhrase("LangLanguage").get());
                //  title.setText("LANGUAGE");
                setModelProperty(LANGUAGE_TAB_VISIBLE, Boolean.TRUE);
                setModelProperty(LANGUAGE_BUTTON_VISIBLE, Boolean.FALSE);
                break;
            case 1:
                //temp
//                title.setText(translator.translatePhrase("LangSound").get());
                //      title.setText("SOUND");
                setModelProperty(SOUND_TAB_VISIBLE, Boolean.TRUE);
                setModelProperty(SOUND_BUTTON_VISIBLE, Boolean.FALSE);
                break;
            case 2:
                //temp
//                title.setText(translator.translatePhrase("LangGambler").get());
                //    title.setText("GAMBLER");
                setModelProperty(GAMBLER_TAB_VISIBLE, Boolean.TRUE);
                setModelProperty(GAMBLER_BUTTON_VISIBLE, Boolean.FALSE);
                break;
            default:
                throw (new IllegalArgumentException("Illegal argument passed to showTab(int tabIndex) method in QueenCleopatraSettingsScreen."));
        }
    }

    /**
     * Changes volume and updates volume buttons.
     *
     * @param volumeValue int
     */
    @ExposeMethod
    public void changeVolume(int volumeValue) {
        switch (volumeValue) {
            case 0:
                getEventBus().post(new ChangeGlobalVolumeCommand(0.6f));
                volumeValue = 1;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 1:
                getEventBus().post(new ChangeGlobalVolumeCommand(1));
                volumeValue = 2;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            case 2:
                getEventBus().post(new ChangeGlobalVolumeCommand(0.33f));
                volumeValue = 0;
                getEventBus().post(new PlaySoundCommand("volume"));
                break;
            default:
                throw (new IllegalArgumentException("Illegal argument passed to changeVolume(int volumeValue) method in QueenCleopatraSettingsScreen."));
        }
        getEventBus().post(new VolumeChangedEvent(volumeValue));
    }

    /**
     * Changes reels sound and updates buttons.
     *
     * @param reelsSoundIndex
     */
    @ExposeMethod
    public void changeReelsSound(int reelsSoundIndex) {
        setModelProperty(MECHANICAL_ON_VISIBLE, Boolean.FALSE);
        setModelProperty(MUSIC_ON_VISIBLE, Boolean.FALSE);
        setModelProperty(CLASSIC_ON_VISIBLE, Boolean.FALSE);

        setModelProperty(MECHANICAL_OFF_VISIBLE, Boolean.TRUE);
        setModelProperty(MUSIC_OFF_VISIBLE, Boolean.TRUE);
        setModelProperty(CLASSIC_OFF_VISIBLE, Boolean.TRUE);

        switch (reelsSoundIndex) {
            case 0:
                setModelProperty(MECHANICAL_ON_VISIBLE, Boolean.TRUE);
                setModelProperty(MECHANICAL_OFF_VISIBLE, Boolean.FALSE);
                break;
            case 1:
                setModelProperty(MUSIC_ON_VISIBLE, Boolean.TRUE);
                setModelProperty(MUSIC_OFF_VISIBLE, Boolean.FALSE);
                break;
            case 2:
                setModelProperty(CLASSIC_ON_VISIBLE, Boolean.TRUE);
                setModelProperty(CLASSIC_OFF_VISIBLE, Boolean.FALSE);
                break;
            default:
                throw (new IllegalArgumentException(
                        "Illegal argument passed to changeReelsSound(int reelsSoundIndex) method in QueenCleopatraSettingsScreen."));
        }
    }

    /**
     * Changes gambler enabled and updates buttons.
     *
     * @param gamblerStateIndex
     */
    @ExposeMethod
    public void changeGambler(int gamblerStateIndex) {
        setModelProperty(GAMBLER_ON_ON_VISIBLE, Boolean.FALSE);
        setModelProperty(GAMBLER_OFF_ON_VISIBLE, Boolean.FALSE);

        setModelProperty(GAMBLER_ON_OFF_VISIBLE, Boolean.TRUE);
        setModelProperty(GAMBLER_OFF_OFF_VISIBLE, Boolean.TRUE);

        switch (gamblerStateIndex) {
            case 0:
                setModelProperty(GAMBLER_ON_ON_VISIBLE, Boolean.TRUE);
                setModelProperty(GAMBLER_ON_OFF_VISIBLE, Boolean.FALSE);

                gambleOn = true;
                break;
            case 1:
                setModelProperty(GAMBLER_OFF_ON_VISIBLE, Boolean.TRUE);
                setModelProperty(GAMBLER_OFF_OFF_VISIBLE, Boolean.FALSE);

                gambleOn = false;
                break;
            default:
                throw (new IllegalArgumentException("Illegal argument passed to changeGambler(int gamblerStateIndex) method in QueenCleopatraSettingsScreen."));
        }
    }

    public static boolean getGambleOn() {
        return gambleOn;
    }

    private class LanguageChangedEventObserver extends NextObserver<LanguageChangedEvent> {

        @Override
        public void onNext(final LanguageChangedEvent languageChangedEvent) {
            handleLanguageChangedEvent(languageChangedEvent);
        }
    }

    private class VolumeChangedEventObserver extends NextObserver<VolumeChangedEvent> {

        @Override
        public void onNext(final VolumeChangedEvent volumeChangedEvent) {
            handleVolumeChangedEvent(volumeChangedEvent);
        }
    }
}
