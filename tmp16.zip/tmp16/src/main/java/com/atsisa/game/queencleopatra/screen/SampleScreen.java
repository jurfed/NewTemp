package com.atsisa.game.queencleopatra.screen;

import com.atsisa.game.queencleopatra.screen.model.SampleScreenModel;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.TextView;
import com.gwtent.reflection.client.Reflectable;

import javax.inject.Inject;

@Reflectable
public class SampleScreen extends Screen<SampleScreenModel> {

    int i=0;

    @InjectView
    public ImageView myImage;

    @InjectView
    public TextView myText;

    public SampleScreen() {
        super("sample", new SampleScreenModel());
    }

    @Override
    protected void beforeActivated() {

    }

    @Override
    protected void afterActivated() {
/*        this.myImage.setVisible(false);
        this.myImage.setX(300);
        this.myImage.setY(300);
        this.myImage.setWidth(500);
        this.myImage.setHeight(500);

        this.myText.setVisible(true);
        this.myText.setText("Hello");
        this.myText.setFontSize(100);
        this.myText.setX(700);
        this.myText.setY(700);*/

        this.getModel().setProperty("text1", "Hello text 1!");
        this.getModel().setProperty("myFonstSize", 30);
//        new Timeout(1000, new MyTimer(), true).start();
    }

    @Override
    protected void beforeDeactivated() {

    }

    @Override
    protected void afterDeactivated() {

    }
    class MyTimer  implements TimeoutCallback{

        @Override
        public void onTimeout() {
            if((i++)%2==0){
                getModel().setProperty("text1", "!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                getModel().setProperty("myFonstSize", 50);
            }else{
                getModel().setProperty("text1", "Hello text 1!");
                getModel().setProperty("myFonstSize", 30);
            }

            new Timeout(1000, new MyTimer(), true).start();
        }
    }
}
