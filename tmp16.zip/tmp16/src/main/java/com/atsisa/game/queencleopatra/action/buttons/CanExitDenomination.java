package com.atsisa.game.queencleopatra.action.buttons;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;

public class CanExitDenomination  extends ExecuteNextAction {
    @Override
    protected void execute() {
        allowFurtherProcessing();
        if (GameEngine.current().getViewManager().findViewById("denominationScreen", "mainGroup").getAlpha() < 1) {
            cancelFurtherProcessing();
            try{
                super.execute();
            }catch(Exception e){
                System.out.println(e.getMessage());
            }

        } else {
            finish();
        }
    }
}
