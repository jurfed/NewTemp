package com.atsisa.game.queencleopatra.action.freeGames.actionData;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class FreeGamesModeActionData extends ActionData {

    @XmlAttribute
    private boolean isFreeGames;

    public boolean getIsFreeGames() {
        return isFreeGames;
    }

    public void setIsFreeGames(boolean isFreeGames) {
        this.isFreeGames = isFreeGames;
    }
}