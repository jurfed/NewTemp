package com.atsisa.game.queencleopatra.action.animation.panel.collect;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.SyncAction;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.IWinLineInfo;

import java.util.Iterator;

public class SimpleCollect extends SyncAction<SimpleCollectData> {

    /**
     * Amount sum displayed in the collect indicator
     */
    private static Long collectWinSum = 0L;

    /**
     * The total amount of winnings
     */
    private Long winSum = 0L;

    /**
     * Previous winnings for the accumulation collect in the free games mode
     */
    private Long oldSum = 0L;

    /**
     * For write a value to the textView on the button panel.
     * And for a write a previous value for the free games mode
     */
    private BottomPanelHelper bottomPanelHelper;

    /**
     * default collection time
     */
    private static Long collectTime;

    private final static Long DEFAULT_TIME = 500L;

    /**
     * start time for collect
     */
    private Long startTime = 0L;


    /**
     * Timer for collect
     */
    private Timeout collectTimer;

    private double bet;

    private static volatile boolean skip = false;

    /**
     * Flag for collect for free games mode
     */
    private static boolean freeGames = false;

    /**
     * flag for collect when extended symbols win (argument for this action)
     */
    private static boolean extended = false;


    /**
     * true means that the collect already played and you do not need to play it again with the extended symbols
     */
    private static boolean wasExtendedCollect = false;

    /**
     * Flag to determine whether all winning lines consist of extended symbols
     */
    public static boolean extendedCollect;

    /**
     * to determine the win mode - normal or extended symbols
     */
    private static final String EXTENDED_ANIMATION = "ExtendedAnimation";

    private double bigWinSum;

    /**
     * Determine whether to play the collect in the free games mode
     */
    private boolean playFreeGamesModeCollect = false;

    private static final Long ZERO_VALUE = 0L;
    private static final int TIME_BEFORE_START_COLLECT = 0;

    /**
     * To determine can play a collect in the free game mode.
     */
    private boolean canPlayCollectInFG = true;

    private static final Long COLLECT_TIME_FOR_AWESOME_WIN = 8700L;
    private static final Long COLLECT_TIME_FOR_BIG_WIN = 11500L;
    private static final Long COLLECT_TIME_FOR_SUPER_BIG_WIN = 19700L;
    private static final Long COLLECT_TIME_FOR_MEGA_BIG_WIN = 28900L;

    private static final int FREQUENCY_FOR_SHOW_COLLECT = 80;

    public static void setSkip(boolean skip){
        SimpleCollect.skip=skip;
    }


    @Override
    protected void execute() {
        initValues();
        extendedCollect = getExtendedWinLines();
        if (this.actionData.getReset()) {
            resetValues(); //For reset values and set clean sum in the text indicator
        } else if (this.actionData.getResetExtended()) {
            wasExtendedCollect = false;
        } else if (this.actionData.getSkip()) {
            skip = true; //For skip collect
        } else {
            startCollect();//For start collect
        }
    }

    /**
     * For initalize values
     */
    private void initValues() {
        extended = this.actionData.getExtended();
        freeGames = this.actionData.getFreeGames();
        skip = false;
    }

    /**
     * Method for initialize winSum, bet, etc..
     */
    private void initWinSumAndCollectTime() {
            bet = ((AbstractReelGame) GameEngine.current().getGame()).getBetModelProvider().getBetModel().getTotalBet();
            winSum = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
            collectTime = winSum*2;
            bigWinSum = (double) winSum / bet;
            collectTime = getTimeForBigWin();//get animation time for free games mode

    }

    /**
     * Method for start collect animation
     */
    private void startCollect() {
        initWinSumAndCollectTime();
        if (winSum > 0.01) {
            startTime = System.currentTimeMillis();
            bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
            oldSum = bottomPanelHelper.getIndicatorSum();//old sum for free games mode and gambler collect
            playCollect();
        }
    }

    /**
     * Method for play animation
     */
    private void playCollect() {
        canPlayCollectInFG = ((!extendedCollect && !extended) || (extendedCollect && extended)) && !wasExtendedCollect;
            //win in the base game and free games mode
            if (canPlayCollectInFG) {
                bottomPanelHelper.setIndicatorSum(bottomPanelHelper.getIndicatorSum() + winSum);
            }
            if (freeGames) {
                collectWinSum = ZERO_VALUE;
                collectTimer = new Timeout(TIME_BEFORE_START_COLLECT, new FreeGamesCollectTimer(), false);
                //bottomPanelHelper.getIndicatorTextID1().setText(winSum + oldSum + "");
            } else {
                collectTimer = new Timeout(TIME_BEFORE_START_COLLECT, new BaseGamesAndGambleCollect("BASE"), false);
            }
            bottomPanelHelper.setCollectPlaying(true);
            collectTimer.start();

    }

    /**
     * Define animation time
     *
     * @return
     */
    private Long getTimeForBigWin() {
        //Long time = DEFAULT_TIME;//for standard win
        //for big wins
        if (bigWinSum >= 20d && bigWinSum < 50d) {
            collectTime = COLLECT_TIME_FOR_AWESOME_WIN;
        } else if (bigWinSum >= 50d && bigWinSum < 100d) {
            collectTime = COLLECT_TIME_FOR_BIG_WIN;
        } else if (bigWinSum >= 100d && bigWinSum < 200d) {
            collectTime = COLLECT_TIME_FOR_SUPER_BIG_WIN;
        } else if (bigWinSum >= 200d) {
            collectTime = COLLECT_TIME_FOR_MEGA_BIG_WIN;
        }
        return collectTime;
    }

    /**
     * for reset values
     */
    private void resetValues() {
        bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
        collectWinSum = ZERO_VALUE;
        winSum = ZERO_VALUE;
        oldSum = ZERO_VALUE;
        bottomPanelHelper.setIndicatorSum(ZERO_VALUE);
        bottomPanelHelper.getIndicatorTextID1().setText("");
    }

    /**
     * Class for show collect in the base game mode and in the Gamble
     * Calculate the percentage of elapsed time and calculate the appropriate percentage of the winning amount for display on the screen
     */
    public class BaseGamesAndGambleCollect implements TimeoutCallback {
        Long difference = winSum - oldSum;
        Long sum = 0L;
        String collectType;

        BaseGamesAndGambleCollect(String type) {
            collectType = type;
            if (collectType.equals("BASE")) {
                sum = winSum;
            } else {
                sum = difference;
            }
        }

        @Override
        public void onTimeout() {
            if (collectWinSum < sum && !skip) {
                long timeSpent = System.currentTimeMillis() - startTime;
                float timePercent = (float) timeSpent * 100 / collectTime;
                collectWinSum = Long.valueOf((Math.round((sum * timePercent) / 100)));
                bottomPanelHelper.getIndicatorTextID1().setText(collectWinSum + oldSum + "");
                collectTimer = new Timeout(FREQUENCY_FOR_SHOW_COLLECT, new BaseGamesAndGambleCollect(collectType), true);
                collectTimer.start();
            } else {
                bottomPanelHelper.setCollectPlaying(false);
                bottomPanelHelper.getIndicatorTextID1().setText(sum + oldSum + "");
            }
        }
    }

    /**
     * Class for show collect in the base game mode and in the Gamble
     */
    public class FreeGamesCollectTimer implements TimeoutCallback {

        /**
         * Calculate the percentage of elapsed time and calculate the appropriate percentage of the winning amount for display on the screen
         */
        @Override
        public void onTimeout() {
            if (canPlayCollectInFG) {
                if ((collectWinSum < (winSum) && !skip)) {
                    long timeSpent = System.currentTimeMillis() - startTime;
//                    float timePercent = (float) timeSpent * 100 / collectTime;
                    float timePercent = (float) timeSpent * 100 / 4000;
                    collectWinSum = Long.valueOf((Math.round((winSum * timePercent) / 100)));
                    bottomPanelHelper.getIndicatorTextID1().setText(collectWinSum + oldSum + "");
                    collectTimer = new Timeout(FREQUENCY_FOR_SHOW_COLLECT, new FreeGamesCollectTimer(), true);
                    collectTimer.start();
                } else {
                    bottomPanelHelper.setCollectPlaying(false);
                    bottomPanelHelper.getIndicatorTextID1().setText(winSum + oldSum + "");
                    wasExtendedCollect = true;//For do not repeatedly play a collection with extended symbols
                }
            }

        }
    }

    /**
     * Whether it is necessary to play a separate collect for an extended symbols
     *
     * @return
     */
    boolean getExtendedWinLines() {
        boolean extendedWin = false;

        //Analyze the winning lines to see if there is a win on extended symbols
        Iterable<? extends
                IWinLineInfo> linesIterable = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getLinesModel().getWinningLines();
        if (linesIterable != null) {
            Iterator<? extends IWinLineInfo> lines = linesIterable.iterator();

            while (lines.hasNext()) {
                IWinLineInfo o = lines.next();
                if (o.getAnimationName().equals(EXTENDED_ANIMATION)) {
                    extendedWin = true;
                } else {//if in addition to winning extended symbols there are normal lines, then we return false
                    extendedWin = false;
                    break;
                }
            }
        }

        return extendedWin;
    }

    @Override
    public Class<SimpleCollectData> getActionDataType() {
        return SimpleCollectData.class;
    }
}
