package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.view.ButtonView;
import com.atsisa.gox.framework.view.HorizontalAlign;
import com.atsisa.gox.framework.view.VerticalAlign;

/**
 * Creates side panel button
 */
public class SidePanelButton extends ButtonView {
    private LabelFormat format;
    private float width, height;
    private String label;
    private int fontSize;


    /**
     * Creates new instance of SidePanelButton
     *
     * @param width    width of button
     * @param height   height of button
     * @param label    label on button
     * @param fontSize font size of label
     */
    public SidePanelButton(float width, float height, String label, int fontSize) {
        this.width = width;
        this.height = height;
        this.label = label;
        this.fontSize = fontSize;
        format = new ButtonView.LabelFormat();
        this.setWidth(width);
        this.setHeight(height);
        format.setY(format.getY() - 20);
        setFormatparameters("lines_amount");
        this.setLabel(label);
        this.setId(label);

    }

    public void setSelectedFont() {
        setFormatparameters("lines_amount_selected");
    }

    public void setNormalFont() {
        setFormatparameters("lines_amount");
    }

    private void setFormatparameters(String font) {
        format.setFontSize(fontSize);
        format.setScaleAutoWidth(true);
        format.setValign(VerticalAlign.MIDDLE);
        format.setHalign(HorizontalAlign.CENTER);
        format.setFontName(font);
        this.setNormalLabelFormat(format);
        this.setOverLabelFormat(format);
        this.setDownLabelFormat(format);
    }
}
