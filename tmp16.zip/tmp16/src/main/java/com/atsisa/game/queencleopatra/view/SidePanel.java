package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.ViewGroup;

/**
 * Implementation for SidePanel which enables user to quickly choose between defined values.
 */
@XmlElement
public class SidePanel extends ViewGroup {

    /**
     * Button width
     */
    public static final float BUTTON_WIDTH = 100f;

    /**
     * Vertical offset between two buttons
     */
    public static final int MARGIN_OFFSET = 20;

    /**
     * Offset before first and after last button
     */
    public static final int START_END_MARGIN = 40;

    /**
     *  Offset between bar and max min buttons graphics
     */
    public static final int SPACE_BETWEEN_GRAPHICS = 4;

    /**
     * Minimal button height
     */
    public static final int MIN_BUTTON_HEIGHT = 20;

    /**
     * Maximal button height
     */
    public static final int MAX_BUTTON_HEIGHT = 40;

    /**
     * Minimal side bar panel height
     */
    public static final int MIN_PANEL_HEIGHT = 400;

    /**
     * Maximal side bar panel height
     */
    public static final int MAX_PANEL_HEIGHT = 720;

    /**
     * Button left padding to center it on the bar
     */
    public static final int BUTTON_LEFT_PADDING = 24;


    /**
     * Name of the property which is responsible for showing minimum line value.
     */
    public static final String MIN_LINE_VALUE = "minLineValue";

    /**
     * Name of the property which is responsible for showing maximum line value.
     */
    public static final String MAX_LINE_VALUE = "maxLineValue";

    /**
     * Name of the property which is responsible for showing minimum bet value.
     */
    public static final String MIN_BET_VALUE = "minBetValue";

    /**
     * Name of the property which is responsible for showing maximum bet value.
     */
    public static final String MAX_BET_VALUE = "maxBetValue";

    /**
     * Indciates if panel can be opened.
     */
    private boolean openable;

    /**
     * Initializes a new instance of the {@link SidePanel} class.
     */
    public SidePanel() {
        this(GameEngine.current().getRenderer(), GameEngine.current().getAnimationFactory());
    }

    /**
     * Initializes a new instance of the {@link SidePanel} class.
     * @param renderer         {@link IRenderer}
     * @param animationFactory {@link IAnimationFactory}
     */
    public SidePanel(IRenderer renderer, IAnimationFactory animationFactory) {
        super(renderer);
    }

    /**
     * Sets openable
     * @param value
     */
    public void setOpenable(boolean value) {
        this.openable = value;
    }

    /**
     * Gets openable
     * @return openable
     */
    public boolean getOpenable() {
        return this.openable;
    }

}
