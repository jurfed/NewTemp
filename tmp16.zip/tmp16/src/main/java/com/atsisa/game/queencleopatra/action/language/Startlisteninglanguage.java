package com.atsisa.game.queencleopatra.action.language;

import com.atsisa.game.queencleopatra.listener.LanguageChangeListener;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.ButtonView;
import com.atsisa.gox.framework.view.ViewGroup;

/**
 * Class for listening to the events of the language change buttons.
 */
public class Startlisteninglanguage extends Action {
    private final String LAYOUT_ID = "bottomPanelScreen";
    private String[] buttons = {"enSettingsButton", "deSettingsButton", "csSettingsButton"};

    private LanguageChangeListener languageChangeListener;
    private ButtonView enButton;
    private ButtonView deButton;
    private ButtonView csButton;

    @Override
    protected void execute() {
        if (languageChangeListener == null) {
            languageChangeListener = new LanguageChangeListener();
            ViewGroup vg1 = GameEngine.current().getViewManager().findViewById("settingsScreen", "group1");
            ViewGroup vg2 = GameEngine.current().getViewManager().findViewById(vg1, "languageTab");
            ViewGroup vg3 = GameEngine.current().getViewManager().findViewById(vg2, "languageButtons");
            GameEngine.current().getViewManager().findViewById(vg3, "enButton").addPropertyChangedListener(languageChangeListener);;
            GameEngine.current().getViewManager().findViewById(vg3, "deButton").addPropertyChangedListener(languageChangeListener);;
            GameEngine.current().getViewManager().findViewById(vg3, "csButton").addPropertyChangedListener(languageChangeListener);;
        }
        finish();
    }
}
