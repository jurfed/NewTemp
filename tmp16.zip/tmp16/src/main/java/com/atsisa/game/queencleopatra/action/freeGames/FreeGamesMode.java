package com.atsisa.game.queencleopatra.action.freeGames;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.freeGames.actionData.FreeGamesModeActionData;
import com.atsisa.game.queencleopatra.screen.QueenCleopatraVipLoungeBottomPanelScreen;
import com.atsisa.gox.framework.action.Action;

/**
 * This action indicates whether the free game mode
 * For example:
 * <FreeGamesMode isFreeGames="false"/> - no free game mode
 * <FreeGamesMode isFreeGames="true"/> - free game mode
 */
public class FreeGamesMode extends Action<FreeGamesModeActionData> {
    public static boolean isFreeGames=false;

    @Override
    protected void execute() {

        if (this.actionData.getIsFreeGames()) {
            isFreeGames = true;
            ShowBigWin.setFreeGamesMode(true);
        } else {
            ShowBigWin.setFreeGamesMode(false);
            isFreeGames = false;
        }
        finish();
    }

    @Override
    public void terminate() {

    }

    @Override
    public Class<FreeGamesModeActionData> getActionDataType() {
        return FreeGamesModeActionData.class;
    }

}
