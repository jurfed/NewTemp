package com.atsisa.game.queencleopatra.action.animation.panel.collect.freeGamesCollect;

import com.atsisa.game.queencleopatra.action.animation.panel.collect.SimpleCollect;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.IViewPropertyChangedListener;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;
import com.atsisa.gox.reels.AbstractReelGame;

public class PlayFreeGamesCollectSound extends Action<FreeGamesSoundData> {

    private Timeout loopCollectTimeout;
    private long totalAmount = 0L;
    private BottomPanelHelper bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
    TextView winIndicatortext = bottomPanelHelper.getIndicatorTextID1();
    WinIndicatortextListener winIndicatortextListener;
    private long oldWinValue = bottomPanelHelper.getIndicatorSum();

    private Long temp = 0L;

    @Override
    protected void execute() {
/*        temp=0l;
*//*            totalAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
            if ((bottomPanelHelper.isCollectPlaying()) && (totalAmount > 0.01 && Integer.parseInt(winIndicatortext.getText()) < (totalAmount + oldWinValue)) && (!this.actionData.getExtended() && !SimpleCollect.extendedCollect)) {
                //init collect sound
                new Timeout(200, new Temp(),true).start();
            }else{
                finish();
            }*/

        try {
            totalAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
            oldWinValue = bottomPanelHelper.getIndicatorSum();
            if ((bottomPanelHelper.isCollectPlaying()) && (totalAmount > 0.01 && Integer.parseInt(winIndicatortext.getText()) < (/*totalAmount +*/ oldWinValue)) && (!this.actionData.getExtended() && !SimpleCollect.extendedCollect)) {
                //init collect sound
                GameEngine.current().getSoundManager().play("def_collect_intro");
                //time before play loop collect after init sound
                int timeForLoop = GameEngine.current().getSoundManager().length("def_collect_intro");

                loopCollectTimeout = new Timeout(timeForLoop, new StartloopCollect("def_collect_loop"));
                loopCollectTimeout.start();

                winIndicatortextListener = new WinIndicatortextListener();
                winIndicatortext.addPropertyChangedListener((IViewPropertyChangedListener) winIndicatortextListener);
            } else {
                finish();
            }
        } catch (Exception e) {
            finish();
            System.out.println(e.getMessage());
        }


    }

    class Temp implements TimeoutCallback {

        @Override
        public void onTimeout() {

            temp+=80;
            System.out.println(temp);
            if(temp<10000){
                new Timeout(200, new Temp(),true).start();
            }else{
                finish();
            }

        }
    }

    class WinIndicatortextListener implements IViewPropertyChangedListener {


        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            if (Integer.parseInt(winIndicatortext.getText()) == totalAmount + oldWinValue) {
                winIndicatortext.removePropertyChangedListener(this);
                exit();
            }
        }
    }


    class StartloopCollect implements TimeoutCallback {
        String soundId;

        StartloopCollect(String sound) {
            soundId = sound;
        }

        @Override
        public void onTimeout() {

            GameEngine.current().getSoundManager().play(soundId);
            GameEngine.current().getSoundManager().setLooping(soundId, true);

        }
    }

    @Override
    protected void terminate() {
        winIndicatortext.removePropertyChangedListener(winIndicatortextListener);
        stopSoundAndClear();
    }

    void exit() {
        stopSoundAndClear();
        finish();
    }

    void stopSoundAndClear() {
        if (loopCollectTimeout != null) {
            loopCollectTimeout.clear();
        }
        GameEngine.current().getSoundManager().stop("def_collect_intro");
        GameEngine.current().getSoundManager().setLooping("def_collect_loop", false);
        GameEngine.current().getSoundManager().stop("def_collect_loop");
        GameEngine.current().getSoundManager().play("def_collect_end");
    }

    @Override
    public Class<FreeGamesSoundData> getActionDataType() {
        return FreeGamesSoundData.class;
    }

}
