package com.atsisa.game.queencleopatra.screen.model;

import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;

public class SettingsModel  extends ScreenModel {

    public SettingsModel(ITranslator translator) {
        super(translator);
    }
}
