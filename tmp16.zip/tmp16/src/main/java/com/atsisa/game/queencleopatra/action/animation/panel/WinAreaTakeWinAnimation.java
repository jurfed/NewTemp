package com.atsisa.game.queencleopatra.action.animation.panel;

import aurelienribon.tweenengine.TweenCallback;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.game.queencleopatra.screen.QueenCleopatraOctavianBottomPanelScreen;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.reels.AbstractReelGame;
import rx.functions.Action1;

import java.util.ArrayList;
import java.util.List;

/**
 * Action for animate winArea before and after WinCount
 */
public class WinAreaTakeWinAnimation extends Action<WinAreaTakeWinAnimationActionData> {
    static int step = 0;
    static List<TweenViewAnimation> animation = new ArrayList();
    static TweenViewAnimationData animationData;
    static View winAreaView;
    static boolean skip = false;
    static BottomPanelHelper bottomPanelHelper;
    static int monitors;
    static View upperGroup;

    private ShowBigWin showBigWin;
    private long winSum;

    @Override
    protected void execute() {
        finish();
//        winSum = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
/*        if(winSum>0.9){
            collect();
        }*/


        skip = false;
        animation = new ArrayList();

        Iterable<Screen> screens = GameEngine.current().getStartScreens();

        for (Screen screen : screens) {//get a BottomPanelScreen for two or three modes
            if (screen instanceof BottomPanelHelper) {
                bottomPanelHelper = (BottomPanelHelper) screen;
                if (bottomPanelHelper instanceof QueenCleopatraOctavianBottomPanelScreen) {
                    monitors = 2;
                } else {
                    monitors = 3;
                }
            }
        }

        if (monitors == 2) {
            upperGroup = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "mainID");
            winAreaView = GameEngine.current().getViewManager().findViewById(upperGroup, "winView");
        } else {
            winAreaView = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "winArea");
        }
        for (int i = 0; i < 5; i++) {
            animation.add(GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class));
            if (winAreaView == null) {
                this.terminate();
            }
            animation.get(i).setTargetView(winAreaView);

        }

        try {
            animationData = new TweenViewAnimationData();

            switch (this.actionData.getStep()) {
                case 1:
                    firstStep();
                    break;
                case 2:
                    secondStep();
                    break;
                case 3:
                    loseStep();
                    break;
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }

    public void firstStep() {
        animationData = new TweenViewAnimationData();
        if (monitors == 3) {
            playAnimation(animation.get(0), -145f, -237f, 1.15f, 1.15f, 200);
        } else {
            playAnimation(animation.get(0), 730f, -30f, 1.15f, 1.15f, 200);
        }
    }


    public void secondStep() {
        KeyframeAnimationView winPanelAnimationId = GameEngine.current().getViewManager().findViewById(winAreaView, "winPanelAnimationId");
        winPanelAnimationId.gotoAndPlay(1);
        winPanelAnimationId.setVisible(true);
        animationData = new TweenViewAnimationData();
        tweenListener(animation.get(1));
        if (monitors == 3) {
            playAnimation(animation.get(1), -385f, -280f, 1.4f, 1.4f, 200);
        } else {
            playAnimation(animation.get(1), 670f, -60f, 1.4f, 1.4f, 200);
        }
    }


    public void thirdStep() {
        animationData = new TweenViewAnimationData();
        tweenListener(animation.get(2));
        if (monitors == 3) {
            playAnimation(animation.get(2), 0f, -217f, 1f, 1f, 200);

        } else {
            playAnimation(animation.get(2), 758f, -15f, 1f, 1f, 200);
        }
    }

    @Override
    public Class<WinAreaTakeWinAnimationActionData> getActionDataType() {
        return WinAreaTakeWinAnimationActionData.class;
    }

    public void tweenListener(TweenViewAnimation tweenViewAnimation) {
        tweenViewAnimation.getTweenStateObservable().subscribe(tweenEvent -> {
            if (!skip) {
                if (tweenEvent == TweenCallback.COMPLETE && step == 0) {
                    step++;
                    thirdStep();
                } else if (tweenEvent == TweenCallback.COMPLETE && step == 1) {
                    step = 0;
                    KeyframeAnimationView winPanelAnimationId = GameEngine.current().getViewManager().findViewById(winAreaView, "winPanelAnimationId");
                    winPanelAnimationId.setVisible(false);
                    winPanelAnimationId.stop();

                } else {
                    loseStep();
                }
            }
        });
    }


    public void loseStep() {
        if (monitors == 3) {
            setOriginal(0, -217, 1, 1);
        } else {
            setOriginal(758, -15, 1, 1);
        }

    }


    @Override
    protected void terminate() {
        skip = true;
        if (monitors == 3) {
            setOriginal(0, -217, 1, 1);
        } else {
            setOriginal(758, -15, 1, 1);
        }

    }

    private void playAnimation(TweenViewAnimation tva, float x, float y, float scaleX, float scaleY, float time) {
        animationData.setDestinationX(x);
        animationData.setDestinationY(y);
        animationData.setDestinationScaleX(scaleX);
        animationData.setDestinationScaleY(scaleY);
        animationData.setTimeSpan(time);
        tva.setViewAnimationData(animationData);
        tva.play();
    }

    private void setOriginal(float x, float y, float scaleX, float scaleY) {
        KeyframeAnimationView winPanelAnimationId = GameEngine.current().getViewManager().findViewById(winAreaView, "winPanelAnimationId");
        winPanelAnimationId.stop();
        animation.get(0).stop();
        animation.get(2).stop();
        winAreaView.setX(x);
        winAreaView.setY(y);
        winAreaView.setScaleX(scaleX);
        winAreaView.setScaleY(scaleY);
    }

/*    private void collect() {
        ShowBigWin.getBottomPanelHelper().getIndicatorTextID1().setText(winSum+"");

    }*/
}

