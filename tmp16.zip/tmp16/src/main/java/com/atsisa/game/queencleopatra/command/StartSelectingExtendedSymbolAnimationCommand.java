package com.atsisa.game.queencleopatra.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to play book select scatter animation
 */
@Reflectable
public class StartSelectingExtendedSymbolAnimationCommand {

}
