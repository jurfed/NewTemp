package com.atsisa.game.queencleopatra.action.bigWin.bigWinData;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("INITSTATE")
public class InitState {

    @XStreamAlias("X")
    public Float X;

    @XStreamAlias("Y")
    public Float Y;

    @XStreamAlias("SCALEX")
    public Float SCALEX;

    @XStreamAlias("SCALEY")
    public Float SCALEY;

    @XStreamAlias("VISIBLE")
    public Boolean VISIBLE;

    @XStreamAlias("ALPHA")
    public Float ALPHA;

}
