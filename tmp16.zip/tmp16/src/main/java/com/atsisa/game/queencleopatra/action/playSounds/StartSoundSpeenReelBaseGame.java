package com.atsisa.game.queencleopatra.action.playSounds;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.infrastructure.SoundManager;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;

import java.util.HashMap;
import java.util.Random;

/**
 * Class for random playback of sound of rotation of reels in the basic mode.
 */
public class StartSoundSpeenReelBaseGame extends Action {
    /**
     * for sound management
     */
    private SoundManager spinReelSound;

    /**
     * Contains the sound ID and its name in the resources
     */
    private static HashMap<Integer, String> REELS_SOUNDS = new HashMap<Integer, String>() {
        {
            put(1, "ReelSpinMelody1");
            put(2, "ReelSpinMelody2");
            put(3, "ReelSpinMelody3");
            put(4, "ReelSpinMelody4");
            put(5, "ReelSpinMelody5");
            put(6, "ReelSpinMelody6");
            put(7, "ReelSpinMelody7");
            put(8, "ReelSpinMelody8");
            put(9, "ReelSpinMelody9");
            put(10, "ReelSpinMelody10");
            put(11, "ReelSpinMelody11");
            put(12, "ReelSpinMelody12");
            put(13, "ReelSpinMelody13");
            put(14, "ReelSpinMelody14");
            put(15, "ReelSpinMelody15");
            put(16, "ReelSpinMelody16");
        }
    };

    /**
     * Assigned a randomly generated sound identifier
     */
    private static int soundId;

    @Override
    protected void execute() {
        playSound();
        finish();
    }

    /**
     * Generates a random sound identifier and plays a sound
     */
    private void playSound() {
        soundId = (new Random()).nextInt(15) + 1;
        spinReelSound = (SoundManager) GameEngine.current().getSoundManager();
        spinReelSound.setLooping(REELS_SOUNDS.get(soundId), false);
        spinReelSound.play(REELS_SOUNDS.get(soundId));

        new Timeout(2600, new TimeoutStopSound(soundId), false).start();

        /*        List<IActionQueue> actionQueues = GameEngine.current().getActionManager().getActionQueues();
        for (IActionQueue reels : actionQueues) {
            //System.out.println(reels.getState().name());
            if (reels.getName().equals("SpinReels")&& !soundPlaing) {
                reels.addStateListener(new IStateListener<ActionQueueState>() {
                    @Override
                    public void stateChanged(Object o, ActionQueueState actionQueueState) {
                        System.out.println();
                    }
                });
            }
        }*/

    }

    protected static String getSoundId() {
        return REELS_SOUNDS.get(soundId);
    }

    private class TimeoutStopSound implements TimeoutCallback {
        private int soundId;

        public TimeoutStopSound(int soundId) {
            this.soundId = soundId;
        }

        @Override
        public void onTimeout() {
            spinReelSound.stop(REELS_SOUNDS.get(soundId));
/*            if (!spinReelSound.isPlaying(REELS_SOUNDS.get(soundId))) {
                System.out.println();
            }*/
        }
    }
}
