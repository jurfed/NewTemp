package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.view.AbstractViewModule;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the core view types which could be created declaratively using XML.
 */
@Reflect_Mini
public class QueenCleopatraCoreViewModule extends AbstractViewModule {

    /**
     * Core views module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/queenCleopatra/view";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerView(VipLoungeLinesButtonView.class);
        registerView(SidePanelBar.class);
        registerView(SidePanelMaxButtonView.class);
        registerView(SidePanelMinButtonView.class);
        registerView(SidePanel.class);
        registerView(SidePanelButtonView.class);
    }
}
