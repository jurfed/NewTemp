package com.atsisa.game.queencleopatra.action.animation.panel.collect;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.IViewPropertyChangedListener;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;
import com.atsisa.gox.reels.AbstractReelGame;

public class PlayCollectSound extends Action {
    private Timeout loopCollectTimeout;
    private long totalAmount = 0L;
    TextView winIndicatortext = ShowBigWin.getBottomPanelHelper().getIndicatorTextID1();
    WinIndicatortextListener winIndicatortextListener;

    @Override
    protected void execute() {
        try {
            totalAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
            if (totalAmount > 0.01 && Integer.parseInt(winIndicatortext.getText()) < totalAmount) {
                //init collect sound
                GameEngine.current().getSoundManager().play("def_collect_intro");
                //time before play loop collect after init sound
                int timeForLoop = GameEngine.current().getSoundManager().length("def_collect_intro");

                loopCollectTimeout = new Timeout(timeForLoop, new StartloopCollect("def_collect_loop"));
                loopCollectTimeout.start();

                winIndicatortextListener = new WinIndicatortextListener();
                winIndicatortext.addPropertyChangedListener((IViewPropertyChangedListener) winIndicatortextListener);
            } else {
                finish();
            }
        } catch (Exception e) {
            finish();
            System.out.println(e.getMessage());
        }

    }

    class WinIndicatortextListener implements IViewPropertyChangedListener {


        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            if (Integer.parseInt(winIndicatortext.getText()) == totalAmount) {
                winIndicatortext.removePropertyChangedListener(this);
                exit();
            }
        }
    }


    class StartloopCollect implements TimeoutCallback {
        String soundId;

        StartloopCollect(String sound) {
            soundId = sound;
        }

        @Override
        public void onTimeout() {

            GameEngine.current().getSoundManager().play(soundId);
            GameEngine.current().getSoundManager().setLooping(soundId, true);

        }
    }

    @Override
    protected void terminate() {
        winIndicatortext.removePropertyChangedListener(winIndicatortextListener);
        stopSoundAndClear();
    }

    void exit() {
        stopSoundAndClear();
        finish();
    }

    void stopSoundAndClear() {
        if(loopCollectTimeout!=null){
            loopCollectTimeout.clear();
        }
        GameEngine.current().getSoundManager().stop("def_collect_intro");
        GameEngine.current().getSoundManager().setLooping("def_collect_loop", false);
        GameEngine.current().getSoundManager().stop("def_collect_loop");
        GameEngine.current().getSoundManager().play("def_collect_end");
    }

}
