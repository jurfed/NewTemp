package com.atsisa.game.queencleopatra.view;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.event.IEvent;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.model.property.ObservableProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.InteractiveViewState;
import com.atsisa.gox.framework.view.ViewGroup;

/**
 * Class representing side panel button.
 */
@XmlElement
public class SidePanelButtonView extends ViewGroup {

    /**
     * Gets a boolean value that indicates whether this button is enabled or not.
     * @return boolean
     */
    public boolean isEnabled() {
        return enabled.get();
    }

    /**
     * Sets a boolean value that.
     * @param enabled - boolean
     */
    public void setEnabled(boolean enabled) {
        this.enabled.set(enabled);
    }

    /**
     * Boolean value that indicates whether this button is enabled or not.
     */
    @XmlAttribute(type = Boolean.class)
    private final ObservableProperty<Boolean> enabled = new ObservableProperty<>(Boolean.class, Boolean.TRUE);

    /**
     * Boolean value that indicates if the button is pressed or not.
     */
    private boolean isPressed = false;

    /**
     * Image View for button in normal state.
     */
    @XmlAttribute(type = ImageView.class)
    public ImageView normalState = new ImageView();

    /**
     * Image View for button in disabled state.
     */
    @XmlElement(type = ImageView.class)
    public ImageView disabledState = new ImageView();

    /**
     * Image View for button in pressed state.
     */
    @XmlElement(type = ImageView.class)
    public ImageView pressedState = new ImageView();

    /**
     * Image View for button in disabled active state.
     */
    @XmlElement(type = ImageView.class)
    public ImageView disabledActiveState = new ImageView();

    /**
     * Image View for button in normal active state.
     */
    @XmlElement(type = ImageView.class)
    public ImageView normalActiveState = new ImageView();

    /**
     * Sets new image value for pressed state.
     * @param pressedState instance of {@link ImageView class}
     */
    public void setActiveState(ImageView pressedState) {
        this.pressedState = pressedState;
        addChild(pressedState);
    }

    /**
     * Sets new image value for disabled active state.
     * @param disabledActiveState instance of {@link ImageView class}
     */
    public void setDisabledActiveState(ImageView disabledActiveState) {
        this.disabledActiveState = disabledActiveState;
        addChild(disabledActiveState);
    }

    /**
     * Sets new image value for normal active state.
     * @param normalActiveState of {@link ImageView class}
     */
    public void setNormalActiveState(ImageView normalActiveState) {
        this.normalActiveState = normalActiveState;
        addChild(normalActiveState);
    }

    /**
     * Sets new image value for normal state.
     * @param normalState instance of {@link ImageView class}
     */
    public void setNormalState(ImageView normalState) {
        this.normalState = normalState;
        addChild(normalState);
    }

    /**
     * Sets new image value for normal state.
     * @param pressedState instance of {@link ImageView class}
     */
    public void setPressedState(ImageView pressedState) {
        this.pressedState = pressedState;
        addChild(pressedState);
    }

    /**
     * Sets new image value for disabled state.
     * @param disabledState instance of {@link ImageView class}
     */
    public void setDisabledState(ImageView disabledState) {
        this.disabledState = disabledState;
        addChild(disabledState);
    }

    /**
     * Checks if the button is pressed or not.
     */
    public boolean isPressed() {
        return isPressed;
    }

    /**
     * Sets button to unpressed state.
     */
    public void setUnpressedState() {
        isPressed = false;
    }

    /**
     * Sets button to pressed state.
     */
    public void setPressState() {
        isPressed = true;
    }

    /**
     * Handles the button visibility when they are in normal state.
     */
    public void setButtonNormalState() {
        normalState.setVisible(true);
        normalActiveState.setVisible(false);
        pressedState.setVisible(false);
        disabledState.setVisible(false);
        disabledActiveState.setVisible(false);
    }

    /**
     * Handles the button visibility when they are in active state.
     */
    public void setButtonActiveState() {
        normalState.setVisible(false);
        normalActiveState.setVisible(true);
        pressedState.setVisible(false);
        disabledState.setVisible(false);
        disabledActiveState.setVisible(false);
        this.setPressState();
    }

    /**
     * Handles the button visibility when they are in pressed state.
     */
    public void setButtonPressedState() {
        normalState.setVisible(false);
        normalActiveState.setVisible(false);
        pressedState.setVisible(true);
        disabledState.setVisible(false);
        disabledActiveState.setVisible(false);
    }

    /**
     * Handles the button visibility when they are in disabled state.
     */
    public void setButtonDisableState() {
        normalState.setVisible(false);
        normalActiveState.setVisible(false);
        pressedState.setVisible(false);
        disabledState.setVisible(true);
        disabledActiveState.setVisible(false);
    }

    /**
     * Handles the button visibility when they are in disabled active state.
     */
    public void setButtonDisableActiveState() {
        normalState.setVisible(false);
        normalActiveState.setVisible(false);
        pressedState.setVisible(false);
        disabledState.setVisible(false);
        disabledActiveState.setVisible(true);
    }

    @Override
    protected void setCurrentState(InteractiveViewState value) {
        super.setCurrentState(value);
        if (this.isEnabled()) {
            //if (value == InteractiveViewState.DOWN_STATE) {
            //    setButtonPressedState();
           // }
        }
    }

    @Override
    public void triggerEvent(IEvent event) {
        if (isEnabled()) {
            super.triggerEvent(event);
            switch (((InputEvent) event).getType()) {
                case MOUSE_OUT:
                    if (!isPressed()) {
                        setButtonNormalState();
                    } else {
                        setButtonActiveState();
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Initializes a new instance of the {@link SidePanelButtonView} class.
     */
    public SidePanelButtonView() {
        this(GameEngine.current().getRenderer());
    }

    /**
     * Initializes a new instance of the {@link SidePanelButtonView} class.
     * @param renderer {@link IRenderer}
     */

    public SidePanelButtonView(IRenderer renderer) {
        super(renderer);
    }
}
