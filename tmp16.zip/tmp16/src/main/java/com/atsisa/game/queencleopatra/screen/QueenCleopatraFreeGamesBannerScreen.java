package com.atsisa.game.queencleopatra.screen;

import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.game.queencleopatra.action.ChangeFramesAndBgrForFreeGames;
import com.atsisa.game.queencleopatra.gameobjects.staticClasses.ExtendedSymbolStatic;
import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraFreeGamesInfoBannerScreenModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.logic.FreeGamesInfoType;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.view.AbstractSymbol;
import com.gwtent.reflection.client.Reflectable;

@Reflectable
public class QueenCleopatraFreeGamesBannerScreen extends Screen<QueenCleopatraFreeGamesInfoBannerScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "freeGamesBannerScreen";

    /**
     * Retrigger message visible.
     */
    private static final String RETRIGGER_BANNER_VISIBLE = "retriggerBannerVisible";

    /**
     * Free Games end banner visible.
     */
    private static final String FREE_GAMES_END_BANNER_VISIBLE = "freeGamesEndBannerVisible";



    /**
     * Object that changes the animation frame for game types "Free games" and "Base games"
     */
    private static ChangeFramesAndBgrForFreeGames changeFramesForFreeGames;

    /**
     * Flag to prevent recursive method calls to changeFramesForFreeGames
     */
    private static boolean freeGames = false;

    /**
     * Flags that signal from which number of free games to change the background and animation and go back.
     */
    private static final String FLAG_START = "1";
    private static final String FLAG_END = "0";

    /**
     * Scatter symbol animation on the upper screen
     */
    private KeyframeAnimationView scatterAnimation;


    /**
     * Array for text labels "10 free games + special expanding symbol"
     */
    private TextView[] freeGames10Text;

    /**
     * Initializes a new instance of the {@link QueenCleopatraFreeGamesBannerScreen} class.
     *
     * @param layoutId         layout identifier
     * @param model            {@link QueenCleopatraFreeGamesInfoBannerScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public QueenCleopatraFreeGamesBannerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId,QueenCleopatraFreeGamesInfoBannerScreenModel model,
                                               IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new QueenCleopatraFreeGamesBannerScreen.FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
    }

    /**
     * Displays proper text message and game information according to received event.
     *
     * @param freeGamesModelChangedEvent {@link FreeGamesModelChangedEvent}
     */
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        IFreeGamesModel freeGamesModel = freeGamesModelChangedEvent.getFreeGamesModel();
        FreeGamesInfoType freeGamesInfoType = freeGamesModel.getFreeGamesInfoType();
        updateModelData(freeGamesModel);

        updateInfoVisibility(freeGamesInfoType);
    }

    /**
     * Updates text visibility depending on game type received.
     *
     * @param freeGamesInfoType {@link FreeGamesInfoType}
     */
    private void updateInfoVisibility(FreeGamesInfoType freeGamesInfoType) {
        setModelProperty(FREE_GAMES_END_BANNER_VISIBLE, Boolean.FALSE);
        setModelProperty(RETRIGGER_BANNER_VISIBLE, Boolean.FALSE);

        if (freeGamesInfoType == FreeGamesInfoType.GAMES_END) {
            setModelProperty(FREE_GAMES_END_BANNER_VISIBLE, Boolean.TRUE);
        } else if (freeGamesInfoType == FreeGamesInfoType.RETRIGGER) {
            setModelProperty(RETRIGGER_BANNER_VISIBLE, Boolean.TRUE);
        }
    }

    /**
     * Updates the model data based on the free games model.
     *
     * @param freeGamesModel {@link IFreeGamesModel}
     */
    private void updateModelData(IFreeGamesModel freeGamesModel) {
        try{
            this.getModel().setNumberWonGames(freeGamesModel.getAmountWonGames());
            this.getModel().setTotalFreeGamesNumber(freeGamesModel.getTotalFreeGamesNumber());
            this.getModel().setCurrentFreeGamesNumber(freeGamesModel.getCurrentFreeGameNumber());
            String winAmount = String.valueOf(freeGamesModel.getTotalWinAmount());
            this.getModel().setFreeGamesWinAmount(winAmount);
        }catch(Exception e){
            System.err.println("!!!! error null");
        }

    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);

            //Set the flag for the start of a free game
            if (("" + freeGamesModelChangedEvent.getFreeGamesModel().getFreeGamesInfoType()).equals(FreeGamesInfoType.WON + "")) {
                if (!freeGames) {
                    //Run the animation for scatterer symbol on the upper screen
                    if (scatterAnimation == null) {
                        scatterAnimation = getViewManager().findViewById("payTableBgrScreen", "tombSymbolWinShortAnimation");
                    }

                    freeGames = true;
                    if (changeFramesForFreeGames == null) {
                        freeGames = true;
                    }
                }
            }
            //Set the flag for the end of a free game
            if (("" + freeGamesModelChangedEvent.getFreeGamesModel().getFreeGamesInfoType()).equals(FreeGamesInfoType.GAMES_END + "")) {
                if (freeGames) {
                    freeGames = false;
                }
            }

            //If the extended character is finished, then we call the method to cancel the transparency of the other symbols
            if (ExtendedSymbolStatic.transparencyDone) {
                hideTransparency();
            }

            startChangeFrames(freeGamesModelChangedEvent);
            stopChangeFrames(freeGamesModelChangedEvent);
        }

    }

    /**
     * Change the frame for mode "free games" when the number of the current free game is 1
     *
     * @param freeGamesModelChangedEvent
     */
    void startChangeFrames(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        if (freeGames && ("" + freeGamesModelChangedEvent.getFreeGamesModel().getCurrentFreeGameNumber()).equals(FLAG_START)) {
            if (changeFramesForFreeGames == null) {
                changeFramesForFreeGames = new ChangeFramesAndBgrForFreeGames();
            }
            changeFramesForFreeGames.showFreeGamesFramesAndBgr();
        }
    }

    /**
     * Change the frame for mode "base game" when the number of the total free games is 0
     *
     * @param freeGamesModelChangedEvent
     */
    void stopChangeFrames(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        if (!freeGames && ("" + freeGamesModelChangedEvent.getFreeGamesModel().getTotalFreeGamesNumber()).equals(FLAG_END)) {
            if (changeFramesForFreeGames != null)
                changeFramesForFreeGames.hideFreeGamesFramesAndBgr();
        }
    }

    /**
     * Returns transparency to symbols in the free game mode
     */
    public void hideTransparency() {

        for (AbstractSymbol symbol : ExtendedSymbolStatic.symbolsTransparency) {
            symbol.setAlpha(1);
        }
        ExtendedSymbolStatic.symbolsTransparency.clear();
        ExtendedSymbolStatic.transparencyDone = false;
    }

}