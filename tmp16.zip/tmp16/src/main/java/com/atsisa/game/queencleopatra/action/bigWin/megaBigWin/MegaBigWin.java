package com.atsisa.game.queencleopatra.action.bigWin.megaBigWin;

import aurelienribon.tweenengine.TweenCallback;
import com.atsisa.game.queencleopatra.action.bigWin.BigWin;
import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.Step;
import com.atsisa.game.queencleopatra.action.bigWin.bigWinData.WinObject;
import com.atsisa.game.queencleopatra.helpers.bigWin.BigWinHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.framework.view.View;
import rx.functions.Action1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MegaBigWin implements BigWin {

    private boolean stop = false;
    private final String LAYOUT_ID = "BigWinScreen";
    private final String BIG_WIN_ID = "BIG_WIN";
    private final String BIG_WIN_ID2 = "BIG_WIN2";
    private final String INDICATOR_ID = "Indicator";
    private final String WIN_TEXT_ID = "winText";
    private final String RIGHT_STAR_ID = "rightStar";
    private final String RIGHT_STAR_ID2 = "rightStar2";
    private final String LEFT_STAR_ID = "leftStar";
    private final String LEFT_STAR_ID2 = "leftStar2";
    private final String MEGA_WIN_ID = "MEGA_WIN_ID";
    private final String MEGA_WIN_ID2 = "MEGA_WIN_ID2";
    private final String RIGHT_MEGA_STAR_ID = "rightMegaStar";
    private final String LEFT_MEGA_STAR_ID = "leftMegaStar";
    private final String RIGHT_MEGA_STAR_ID2 = "rightMegaStar2";
    private final String LEFT_MEGA_STAR_ID2 = "leftMegaStar2";

    //sounds
    private final String BELL = "bell";
    private final String RADETSKY_MARSCH = "radetzky_marsch";
    private final String BELL_SUPER_MEGA = "bell_super_mega";
    private final String COLLECT_SUPER_MEGA = "collect_super_mega";
    private final String COLLECT_END_SUPER_MEGA = "collect_end_super_mega";


    private View bigWinImageView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, BIG_WIN_ID);
    private View IndicatorView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, INDICATOR_ID);
    private View winTextView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, WIN_TEXT_ID);
    private View rightStarView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, RIGHT_STAR_ID);
    private View leftStarView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, LEFT_STAR_ID);
    private View superView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, MEGA_WIN_ID);
    private View bigWinImageView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, BIG_WIN_ID2);
    private View rightStarView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, RIGHT_STAR_ID2);
    private View leftStarView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, LEFT_STAR_ID2);
    private View superView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, MEGA_WIN_ID2);
    private View rigthMegaStarView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, RIGHT_MEGA_STAR_ID);
    private View leftMegaStarView = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, LEFT_MEGA_STAR_ID);
    private View rigthMegaStarView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, RIGHT_MEGA_STAR_ID2);
    private View leftMegaStarView2 = GameEngine.current().getViewManager().findViewById(LAYOUT_ID, LEFT_MEGA_STAR_ID2);

    private List<View> views = new ArrayList() {{add(bigWinImageView);add(IndicatorView);add(winTextView);add(rightStarView);add(leftStarView);add(superView);add(bigWinImageView2);add(rightStarView2);add(leftStarView2);add(superView2);add(rigthMegaStarView);add(leftMegaStarView);add(rigthMegaStarView2);add(leftMegaStarView2);
    }};

    private int sum = 0;
    private ShowBigWin showBigWinClass;

    /**
     * List of parameters for each step for this object
     */
    private WinObject bigWinStepParam, indicatorStepParam, winTextStepParam, rightStarStepParam, leftStarStepParam, superStepParam, bigWinStepParam2, rightStarStepParam2, leftStarStepParam2, superStepParam2, rightMegaStarStepParam, leftMegaStarStepParam, rightMegaStarStepParam2, leftMegaStarStepParam2;
    private List<WinObject> objects = new ArrayList();

    /**
     * Step counter for each animated object
     */
    private Integer[] steps = new Integer[14];

    /**
     * Exit animation loop flag
     */
    private static Boolean[] loopStop = new Boolean[1];

    /**
     * A list of hash maps with parameters that depend on the number of digits in the win sum
     */
    private List<HashMap> textSteps = new ArrayList();

    private BigWinHelper helper;

    private Float collectTime;

    public MegaBigWin(int sum, ShowBigWin showBigWinClass, Float collect) {
        this.sum = sum;
        collectTime = collect;
        this.showBigWinClass = showBigWinClass;
        objects.add(bigWinStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(0));
        objects.add(indicatorStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(1));
        objects.add(winTextStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(2));
        objects.add(rightStarStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(3));
        objects.add(leftStarStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(4));
        objects.add(superStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(5));
        objects.add(bigWinStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(6));
        objects.add(rightStarStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(7));
        objects.add(leftStarStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(8));
        objects.add(superStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(9));
        objects.add(rightMegaStarStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(10));
        objects.add(leftMegaStarStepParam = (WinObject) showBigWinClass.getObjectsSteps().get(11));
        objects.add(rightMegaStarStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(12));
        objects.add(leftMegaStarStepParam2 = (WinObject) showBigWinClass.getObjectsSteps().get(13));
    }

    @Override
    public void execute() {
        helper = new BigWinHelper();
        initStartStates();
        showBigWin();

        new Timeout(0, new BigWinHelper.PlayMarshc(BELL), true).start();
        new Timeout(0, new BigWinHelper.PlayMarshc(BELL_SUPER_MEGA), true).start();
        new Timeout(2000, new BigWinHelper.PlayMarshc(RADETSKY_MARSCH), true).start();
        new Timeout(2000, new BigWinHelper.PlayMarshc(COLLECT_SUPER_MEGA), true).start();
    }

    @Override
    public void initStartStates() {
        stop = false;
        helper.initObjects(showBigWinClass, views, steps, loopStop);
        ((TextView) winTextView).setText("0");
        textSteps.clear();
        textSteps = helper.prepareTextParameters((int) sum, IndicatorView, winTextView);
    }

    @Override
    public void showBigWin() {
        Step step;

        for (int i = 0; i < steps.length; i++) {
            if(i!=2&&i!=1){
                step = ((Step) objects.get(i).steps.get(steps[i]));
                helper.runStep(views.get(i), step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) this);
            }
        }
        step = ((Step) indicatorStepParam.steps.get(steps[1]));
        helper.runStep(IndicatorView, (float) (textSteps.get(steps[1])).get("indicatorX"), step.Y, (float) (textSteps.get(steps[1])).get("scaleX"), step.SCALEY, step.TIME, step.ALPHA, steps, this);
        step = ((Step) winTextStepParam.steps.get(steps[2]));
        helper.runStep(winTextView, (float) (textSteps.get(steps[2])).get("textX"), (float) (textSteps.get(steps[2])).get("textY"), step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, this);
        helper.collect((TextView) winTextView, sum, collectTime, loopStop);
    }

    @Override
    public void tweenListener(View view, TweenViewAnimation tweenViewAnimation, Integer[] steps, BigWin showBigWin) {

        tweenViewAnimation.getTweenStateObservable().subscribe(new Action1<Integer>() {

            @Override
            public void call(Integer tweenEvent) {

                if (tweenEvent == TweenCallback.COMPLETE) {
                    Integer objectId = null;
                    Step step = null;
                    if (view.getId().equals(BIG_WIN_ID)) {
                        objectId = 0;
                        steps[objectId]++;
                        if (!stop && steps[objectId] < bigWinStepParam.steps.size()) {
                            step = ((Step) bigWinStepParam.steps.get(steps[objectId]));
                            helper.runStep(bigWinImageView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) bigWinStepParam2.steps.get(steps[objectId]));
                            helper.runStep(bigWinImageView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            if (steps[objectId] == 3) {
                                objectId = 1;
                                step = ((Step) indicatorStepParam.steps.get(steps[objectId]));
                                helper.runStep(IndicatorView, IndicatorView.getX(), step.Y + 70, IndicatorView.getScaleX(), step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                                objectId = 2;
                                step = ((Step) winTextStepParam.steps.get(steps[objectId]));
                                helper.runStep(winTextView, winTextView.getX(), winTextView.getY() + 70, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                                objectId = 0;
                            }
                        }
                    } else if (view.getId().equals(MEGA_WIN_ID)) {
                        objectId = 5;
                        steps[objectId]++;
                        if (steps[objectId] == superStepParam.steps.size()) {
                            helper.end(new ArrayList() {{
                                add(bigWinImageView);add(IndicatorView);add(winTextView);add(rightStarView);add(leftStarView);add(superView);add(bigWinImageView2);add(rightStarView2);add(leftStarView2);add(superView2); add(rigthMegaStarView);
                            }}, COLLECT_END_SUPER_MEGA);
                            showBigWinClass.endAction();
                        }
                        if (steps[objectId] == superStepParam.steps.size() - 1) {
                            lastStep();
                        } else if (!stop) {
                            step = ((Step) superStepParam.steps.get(steps[5]));
                            helper.runStep(superView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) superStepParam2.steps.get(steps[5]));
                            helper.runStep(superView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);

                            if (steps[objectId] == 5) {
                                step = ((Step) indicatorStepParam.steps.get(steps[1]));
                                helper.runStep(IndicatorView, IndicatorView.getX(), IndicatorView.getY() + 60, IndicatorView.getScaleX(), step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);

                                step = ((Step) winTextStepParam.steps.get(steps[1]));
                                helper.runStep(winTextView, (float) winTextView.getX(), winTextView.getY() + 60, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            }

                        }
                    } else if (view.getId().equals(INDICATOR_ID)) {
                        objectId = 1;
                        steps[objectId]++;
                        if (steps[objectId] == 1) {
                            step = ((Step) indicatorStepParam.steps.get(steps[objectId]));
                            helper.runStep(IndicatorView, (float) (textSteps.get(steps[objectId])).get("indicatorX"), step.Y, (float) (textSteps.get(steps[1])).get("scaleX"), step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    } else if (view.getId().equals(WIN_TEXT_ID)) {
                        objectId = 2;
                        steps[objectId]++;
                        if (steps[objectId] == 1) {
                            step = ((Step) winTextStepParam.steps.get(steps[objectId]));
                            helper.runStep(winTextView, (float) (textSteps.get(steps[objectId])).get("textX"), (float) (textSteps.get(steps[2])).get("textY"), step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    } else if (view.getId().equals(RIGHT_STAR_ID)) {
                        objectId = 3;
                        steps[3]++;
                        if (!stop && steps[objectId] < rightStarStepParam.steps.size()) {
                            step = ((Step) rightStarStepParam.steps.get(steps[objectId]));
                            helper.runStep(rightStarView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) rightStarStepParam2.steps.get(steps[objectId]));
                            helper.runStep(rightStarView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    } else if (view.getId().equals(LEFT_STAR_ID)) {
                        objectId = 4;
                        steps[objectId]++;
                        if (!stop && steps[objectId] < leftStarStepParam.steps.size()) {
                            step = ((Step) leftStarStepParam.steps.get(steps[objectId]));
                            helper.runStep(leftStarView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) leftStarStepParam2.steps.get(steps[objectId]));
                            helper.runStep(leftStarView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    }else if (view.getId().equals(RIGHT_MEGA_STAR_ID)) {

                        objectId = 10;
                        steps[objectId]++;
                        if (!stop && steps[objectId] < rightMegaStarStepParam.steps.size()) {
                            step = ((Step) rightMegaStarStepParam.steps.get(steps[objectId]));
                            helper.runStep(rigthMegaStarView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) rightMegaStarStepParam2.steps.get(steps[objectId]));
                            helper.runStep(rigthMegaStarView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    }else if (view.getId().equals(LEFT_MEGA_STAR_ID)) {

                        objectId = 11;
                        steps[objectId]++;
                        if (!stop && steps[objectId] < leftMegaStarStepParam.steps.size()) {
                            step = ((Step) leftMegaStarStepParam.steps.get(steps[objectId]));
                            helper.runStep(leftMegaStarView, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                            step = ((Step) leftMegaStarStepParam2.steps.get(steps[objectId]));
                            helper.runStep(leftMegaStarView2, step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) showBigWin);
                        }
                    }
                    circle(steps, objectId, step);
                }
            }
        });
    }

    /**
     * Lower the animation counter for the cycle
     * @param steps - animation steps counter
     * @param objectId - object identifier
     * @param step - step parameters
     */
    @Override
    public void circle(Integer[] steps, Integer objectId, Step step) {
        if (!loopStop[0] && step != null) {
            steps[objectId] = steps[objectId] - step.CYCLE;
        }
    }

    /**
     * Run the last animation for each object
     */
    @Override
    public void lastStep() {
        stop = true;
        for (int i = 0; i < steps.length; i++) {
            Step step = ((Step) objects.get(i).steps.get(objects.get(i).steps.size() - 1));
            helper.runStep(views.get(i), step.X, step.Y, step.SCALEX, step.SCALEY, step.TIME, step.ALPHA, steps, (BigWin) this);
        }
    }
}