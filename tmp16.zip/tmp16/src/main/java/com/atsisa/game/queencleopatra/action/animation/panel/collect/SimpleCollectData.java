package com.atsisa.game.queencleopatra.action.animation.panel.collect;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class SimpleCollectData extends ActionData {
    /**
     * Flag for set the initial values
     */
    @XmlAttribute
    private boolean reset = false;

    public boolean getReset() {
        return reset;
    }

    public void setReset(boolean reset) {
        this.reset = reset;
    }

/*    *//**
     * Flag for gamblecollect
     *//*
    @XmlAttribute
    private boolean gambler = false;

    public boolean getGambler() {
        return gambler;
    }

    public void setGambler(boolean gambler) {
        this.gambler = gambler;
    }*/


    /**
     * Flag for skip collect
     */
    @XmlAttribute
    private boolean skip = false;

    public boolean getSkip() {
        return skip;
    }

    public void setSkip(boolean skip) {
        this.skip = skip;
    }

    /**
     * Flag for free games collect
     */
    @XmlAttribute
    private boolean freeGames = false;

    public boolean getFreeGames() {
        return freeGames;
    }

    public void setFreeGames(boolean freeGames) {
        this.freeGames = freeGames;
    }

    /**
     * Flag for free games extended symbols collect
     */
    @XmlAttribute
    private boolean extended = false;

    public boolean getExtended() {
        return extended;
    }

    public void setExtended(boolean extended) {
        this.extended = extended;
    }

    /**
     * Flag for determining whether a collect was played, including an extended character
     */
    @XmlAttribute
    private boolean resetExtended = false;

    public boolean getResetExtended() {
        return resetExtended;
    }

    public void setResetExtended(boolean resetExtended) {
        this.resetExtended = resetExtended;
    }

}
