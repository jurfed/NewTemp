package com.atsisa.game.queencleopatra.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when extended symbol was selected
 */
@Reflectable
public final class ShownExtendedSymbolEvent extends AbstractEvent {
}
