package com.atsisa.game.queencleopatra.gameobjects.staticClasses;

import com.atsisa.gox.reels.view.AbstractSymbol;

import java.util.ArrayList;

/**
 * Class for storing static objects related to the processing of the extended symbol
 */

public class ExtendedSymbolStatic {

    /**
     * List of symbols that need to be made transparent when the beginning of the symbol extention
     */
    public static ArrayList<AbstractSymbol> symbolsTransparency = new ArrayList<>();


    /**
     * Flag for track the beginning of the symbol extention
     */
    public static boolean transparencyDone = false;

    /**
     * Name of the current extended symbol.
     */
    public static String extendedSymbolName = "";

    public final static int DELAY_TIME = 10;
    public final static float TRANSPARENCY_STEP = 0.03f;
    public final static float MAX_TRANSPARENCY = 0.5f;
}
