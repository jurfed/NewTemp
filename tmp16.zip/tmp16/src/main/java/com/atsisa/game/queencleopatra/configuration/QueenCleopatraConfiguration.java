package com.atsisa.game.queencleopatra.configuration;

import javax.inject.Inject;

import com.atsisa.gox.framework.configuration.GameConfiguration;

/**
 * Queen Cleopatra configuration.
 */
//public class QueenCleopatraConfiguration extends GameConfiguration {
//
//    /**
//     * Initializes a new instance of the {@link QueenCleopatraConfiguration} class.
//     * setting options: texture resolution, fps, number of screens, etc.
//     */
//    @Inject
//    public QueenCleopatraConfiguration() {
//        this.setWindowDecorated(true);
//        this.setNumberOfScreens(1);
//        this.setWidth(1920);
//        this.setHeight(2160);
//        this.setGameName("QueenCleopatra");
//    }
//}
