package com.atsisa.game.queencleopatra.screen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Named;

import aurelienribon.tweenengine.TweenCallback;
import com.atsisa.game.queencleopatra.action.movie.InitHandlingLogoMovies;
import com.atsisa.game.queencleopatra.command.ShowInfoScreenWithOrderCommand;
import com.atsisa.game.queencleopatra.event.VolumeChangedEvent;
import com.atsisa.game.queencleopatra.helpers.AutoplayButtomListener;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.game.queencleopatra.view.SidePanel;
import com.atsisa.game.queencleopatra.view.VipLoungeLinesButtonView;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimation;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.ChangeGlobalVolumeCommand;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.command.PlaySoundCommand;
import com.atsisa.gox.framework.command.ScreenCommand;
import com.atsisa.gox.framework.event.IEventListener;
import com.atsisa.gox.framework.event.InputEvent;
import com.atsisa.gox.framework.event.InputEventType;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.resource.SpriteSheetResource;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.FreeGamesPresentationStates;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.ChangeDenominationCommand;
import com.atsisa.gox.reels.command.IncreaseBetCommand;
import com.atsisa.gox.reels.command.SetLinesCommand;
import com.atsisa.gox.reels.command.ShowInfoScreenCommand;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.event.MessageChangedEvent;
import com.atsisa.gox.reels.message.BasicMessageType;
import com.atsisa.gox.reels.model.IDenominationModelProvider;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;
import com.atsisa.gox.reels.view.ReelDelayedSequenceProvider;
import com.atsisa.gox.reels.view.ReelGroupView;

/**
 * Implementation for Vip Lounge (three monitors) bottom panel screen.
 */
public class QueenCleopatraVipLoungeBottomPanelScreen extends BottomPanelScreen implements BottomPanelHelper {
    public static boolean turboMode = false;

    /**
     * Name of the property which is responsible if increase bet button is enable or not.
     */
    private static final String BET_INCREASE_ENABLE = "betIncreaseEnable";

    /**
     * Name of the property which is responsible if decrease bet button is enable or not.
     */
    private static final String BET_DECREASE_ENABLE = "betDecreaseEnable";

    /**
     * Name of the property which is responsible if auto play button is enable or not.
     */
    private static final String AUTO_PLAY_ENABLE = "autoPlayEnable";
    private static final String AUTO_PLAY_VISIBLE = "autoPlayVisible";

    /**
     * Name of the property which is responsible if auto stop button is visible or not.
     */
    private static final String AUTO_STOP_VISIBLE = "autoStopVisible";

    /**
     * Name of the property which is responsible if spin button is enable or not.
     */
    private static final String SPIN_ENABLE = "spinEnable";

    /**
     * Name of the property which is responsible if skip button is visible or not.
     */
    private static final String SKIP_VISIBLE = "skipVisible";

    /**
     * Name of the property which is responsible if take button is visible or not.
     */
    private static final String TAKE_VISIBLE = "takeVisible";

    /**
     * Name of the property which is responsible if win text field is visible or not.
     */
    private static final String WIN_VISIBLE = "winVisible";

    /**
     * Name of the property which is responsible if info button is enable or not.
     */
    private static final String INFO_ENABLE = "infoEnable";

    /**
     * Name of the property which is responsible if gamble button is visible or not.
     */
    private static final String GAMBLE_VISIBLE = "gambleVisible";

    /**
     * Name of the property which is responsible if select red card button is visible or not.
     */
    private static final String SELECT_RED_CARD_VISIBLE = "selectRedCardVisible";

    /**
     * Name of the property which is responsible if select black card button is visible or not.
     */
    private static final String SELECT_BLACK_CARD_VISIBLE = "selectBlackCardVisible";

    /**
     * Name of the property which is responsible if menu button is enable or not.
     */
    private static final String MENU_ENABLE = "menuEnable";

    /**
     * Name of the property which is responsible if menu list is visible or not.
     */
    private static final String MENU_VISIBLE = "menuVisible";

    /**
     * Name of the property which is responsible if info screen is visible or not.
     */
    private static final String INFO_SCREEN_VISIBLE = "infoScreenVisible";

    /**
     * Name of the property which is responsible if info screen is enable.
     */
    private static final String INFO_SCREEN_ENABLE = "infoScreenEnable";

    /**
     * Name of the property which is responsible if credit text field and button are visible.
     */
    private static final String CREDIT_VISIBLE = "creditVisible";

    /**
     * Name of the property which is responsible if credit text field and button is hidden.
     */
    private static final String CREDIT_HIDDEN = "creditHidden";

    /**
     * Name of the property which is responsible if large buttons are visible.
     */
    private static final String LARGE_BUTTONS_VISIBLE = "largeButtonsVisible";

    /**
     * Name of the property which is responsible if medium buttons are visible.
     */
    private static final String MEDIUM_BUTTONS_VISIBLE = "mediumButtonsVisible";

    /**
     * Name of the property which is responsible if denomination screen is visible.
     */
    private static final String DENOMINATION_VISIBLE = "denominationVisible";

    /**
     * Name of the property which is responsible if denomination button is enable.
     */
    private static final String DENOMINATION_ENABLE = "denominationEnable";

    /**
     * Name of the property which is responsible if buttons for selecting lines are visible or not.
     */
    private static final String LINES_BUTTONS_VISIBLE = "linesButtonsVisible";

    /**
     * Boolean value that indicates whether auto play is on or off.
     */
    private boolean isAutoPlay;

    /**
     * List of instances of {@link VipLoungeLinesButtonView}.
     */
    List<VipLoungeLinesButtonView> vipLoungeLinesButtonViews;

    /**
     * Current info screen id.
     */
    private int currentInfoScreenId = 0;

    /**
     * List of all infoscreens ids.
     */
    private List<String> infoScreensIds;

    /**
     * Command used to show and hide infoscreens.
     */
    private ScreenCommand screenCommand;

    /**
     * Animation data for showing info screen.
     */
    TweenViewAnimationData showInfoScreenAnimationData;

    /**
     * Denomination model provider.
     */
    private IDenominationModelProvider denominationModelProvider;

    /**
     * Reference to the {@link IFreeGamesModelProvider}.
     */
    private IFreeGamesModelProvider freeGamesModelProvider;

    private AutoplayButtomListener autoplayButtomListener;

    /**
     * Built-in indicator
     */
    private TextView indicatorTextID;

    /**
     * Indicator to replace when big win
     */
    private TextView indicatorTextID2;
    private ViewGroup winView;

    private ReelGroupView reelGroupView;// = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
    private final ArrayList<Integer> spinTime = new ArrayList(5);

    private ButtonView quickButton;

    // private ChangeGlobalVolumeCommand changeGlobalVolumeCommand;

    private int volumeParameter;

    private Long indicatorCollectSum = 0L;

    /**
     * Initializes a new instance of the {@link QueenCleopatraVipLoungeBottomPanelScreen} class.
     *
     * @param layoutId                  layout identifier
     * @param bottomPanelScreenModel    {@link BottomPanelScreenModel}
     * @param renderer                  {@link IRenderer}
     * @param viewManager               {@link IViewManager}
     * @param animationFactory          {@link IAnimationFactory}
     * @param logger                    {@link ILogger}
     * @param eventBus                  {@link IEventBus}
     * @param linesModelMutator         {@link IMutator<ILinesModel>} the lines model mutator
     * @param resourceManager           {@link IResourceManager}
     * @param parser                    {@link IParser}
     * @param xmlSerializer             {@link IXmlSerializer}
     * @param freeGamesModelProvider    {@link IFreeGamesModelProvider}
     * @param denominationModelProvider {@link IDenominationModelProvider}
     */
    @Inject
    public QueenCleopatraVipLoungeBottomPanelScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel,
                                                    IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus,
                                                    IMutator<ILinesModel> linesModelMutator, IResourceManager resourceManager, IParser parser, IXmlSerializer xmlSerializer,
                                                    IFreeGamesModelProvider freeGamesModelProvider, IDenominationModelProvider denominationModelProvider) {
        super(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger, eventBus, linesModelMutator, resourceManager, parser,
                xmlSerializer);
        this.freeGamesModelProvider = freeGamesModelProvider;
        this.denominationModelProvider = denominationModelProvider;
        autoplayButtomListener = new AutoplayButtomListener();
    }


    @Override
    public void initializeIndicatorTextIDs() {
        winView = GameEngine.current().getViewManager().findViewById("bottomPanelScreen", "winArea");
        indicatorTextID = GameEngine.current().getViewManager().findViewById(winView, "indicatorTextID");
        indicatorTextID2 = GameEngine.current().getViewManager().findViewById(winView, "indicatorTextID2");

        winView.addChild(indicatorTextID2);
    }


    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ScreenShowingEventObserver(), ScreenShowingEvent.class);
        getEventBus().register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        getEventBus().register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        getEventBus().register(new ScreenShownEventObserver(), ScreenShownEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
        getEventBus().register(new VolumeChangedEventObserver(), VolumeChangedEvent.class);

    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
        setModelProperty(CREDIT_VISIBLE, Boolean.TRUE);
        setModelProperty(CREDIT_HIDDEN, Boolean.FALSE);
        setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
        setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
//        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
        setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
        clearAllLineButtonsState();

        infoScreensIds = new ArrayList<String>();
        infoScreensIds.add("featureInfoScreen");
        infoScreensIds.add("rulesInfoScreen");
        infoScreensIds.add("gamblerInfoScreen");
//        infoScreensIds.add("rtpInfoScreen");

        showInfoScreenAnimationData = new TweenViewAnimationData();
        showInfoScreenAnimationData.setDestinationY(0F);
        showInfoScreenAnimationData.setTimeSpan(1000);

        quickButton = getViewManager().findViewById(getViewManager().findViewById("bottomPanelScreen", "largeAutoPlayButtons"), "quickAutoplayButton");

        class ButtonViewReleasedListener implements IEventListener<InputEvent> {
            private ButtonView buttonView;

            public ButtonViewReleasedListener(ButtonView buttonView) {
                this.buttonView = buttonView;
            }

            public void onEvent(InputEvent event) {
                if (event.getType() == InputEventType.RELEASED) {
                    if (turboMode) {
                        buttonView.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin("quickAutoplayTextOn"));
                        buttonView.setDownStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("03"));
                        buttonView.setDisableStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("03"));
                        buttonView.setNormalStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("03"));
                        buttonView.setOverStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("03"));
                        buttonView.setScaleX(1.8f);
                        buttonView.setScaleY(1.8f);
                    } else {
                        buttonView.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin("quickAutoplayText"));
                        buttonView.setDownStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                        buttonView.setDisableStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                        buttonView.setNormalStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                        buttonView.setOverStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                        buttonView.setScaleX(1.8f);
                        buttonView.setScaleY(1.8f);
                    }

                }
            }
        }
        quickButton.addEventListener(new ButtonViewReleasedListener(quickButton));

        selectLinesButton(getLinesModel().getSelectedLines());
        initializeIndicatorTextIDs();
//        changeGlobalVolumeCommand = SetInitialVolume.changeGlobalVolumeCommand;
    }

    /**
     * Sets panels property for displaying min max values
     */
    private void setPanelsproperty() {
        this.getModel().setProperty(SidePanel.MIN_LINE_VALUE, this.getLinesModel().getMinLines() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_LINE_VALUE, "MAX\n" + this.getLinesModel().getMaxLines());
        this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
    }

    @Override
    protected void stateChanged() {
        super.stateChanged();
        hideAllButtons();
        InitHandlingLogoMovies.enableTimer(false);
        switch (getCurrentState()) {
            case ReelsPresentationStates.IDLE:
                InitHandlingLogoMovies.enableTimer(true);//start timer for splash screen video
                setModelProperty(SPIN_ENABLE, Boolean.TRUE);
                setModelProperty(MENU_ENABLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                //setModelProperty(AUTO_PLAY_VISIBLE, Boolean.TRUE);
                setModelProperty(INFO_ENABLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
//                setModelProperty(MENU_VISIBLE, Boolean.FALSE);
                setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
//                setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
                setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
                setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
                setModelProperty(DENOMINATION_ENABLE, Boolean.TRUE);
                setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
                setPanelsproperty();
                updateVisibleBetButtons();
                setAllButtonsToNormalState();
                break;
            case ReelsPresentationStates.WIN_COUNTING:
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.STOPPING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                //setModelProperty(AUTO_PLAY_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.REELS_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_STOPPING_REELS:
            case FreeGamesPresentationStates.FREE_GAMES_RETRIGGER:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.OFFER_GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                if (!isAutoPlay) {
                    setModelProperty(GAMBLE_VISIBLE, Boolean.TRUE);
                }
                break;
            case ReelsPresentationStates.GAMBLER_LOSE:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.GAMBLER_WIN:
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.GAMBLER:
                setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.HISTORY:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                break;
            case ReelsPresentationStates.HISTORY_WIN:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                break;
            case FreeGamesPresentationStates.FREE_GAMES_RUNNING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            case FreeGamesPresentationStates.FREE_GAMES_HISTORY:
                updateFreeGamesWin(freeGamesModelProvider.getModel());
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            default:
                break;
        }
    }

    /**
     * Disables all line buttons.
     */
    private void disableAllLineButtons() {
        vipLoungeLinesButtonViews = (List<VipLoungeLinesButtonView>) findViewInheritingType(VipLoungeLinesButtonView.class);
        if (vipLoungeLinesButtonViews != null) {
            for (int i = 0; i < vipLoungeLinesButtonViews.size(); i++) {
                if (vipLoungeLinesButtonViews.get(i).isPressed()) {
                    vipLoungeLinesButtonViews.get(i).setButtonDisableActiveState();
                    vipLoungeLinesButtonViews.get(i).setEnabled(false);
                } else {
                    vipLoungeLinesButtonViews.get(i).setButtonDisableState();
                    vipLoungeLinesButtonViews.get(i).setEnabled(false);
                }
            }
        }
    }

    /**
     * Sets all line changing buttons to normal state.
     */
    private void setAllButtonsToNormalState() {
        vipLoungeLinesButtonViews = (List<VipLoungeLinesButtonView>) findViewInheritingType(VipLoungeLinesButtonView.class);
        if (vipLoungeLinesButtonViews != null) {
            for (int i = 0; i < vipLoungeLinesButtonViews.size(); i++) {
                if (vipLoungeLinesButtonViews.get(i).isPressed()) {
                    vipLoungeLinesButtonViews.get(i).setButtonActiveState();
                } else {
                    vipLoungeLinesButtonViews.get(i).setButtonNormalState();
                }
                vipLoungeLinesButtonViews.get(i).setEnabled(true);
            }
        }
    }

    /**
     * Sets button to normal, unpressed state.
     */
    private void unpressButton() {
        vipLoungeLinesButtonViews = (List<VipLoungeLinesButtonView>) findViewInheritingType(VipLoungeLinesButtonView.class);
        for (int i = 0; i < vipLoungeLinesButtonViews.size(); i++) {
            vipLoungeLinesButtonViews.get(i).setButtonNormalState();
        }
    }

    @ExposeMethod
    @Override
    public void decreaseBet() {
        super.decreaseBet();
        unpressButton();
    }

    @ExposeMethod
    @Override
    public void increaseBet() {
        if (getBetModel().getBetPerLine() < (getBetModel().getMaxBet())) {
            getEventBus().post(new IncreaseBetCommand(true));
        }
        unpressButton();
    }

    /**
     * Enables and sets all buttons to normal and unpressed states.
     */
    private void clearAllLineButtonsState() {
        vipLoungeLinesButtonViews = (List<VipLoungeLinesButtonView>) findViewInheritingType(VipLoungeLinesButtonView.class);
        if (vipLoungeLinesButtonViews != null) {
            for (int i = 0; i < vipLoungeLinesButtonViews.size(); i++) {
                vipLoungeLinesButtonViews.get(i).setButtonNormalState();
                vipLoungeLinesButtonViews.get(i).setUnpressedState();
                vipLoungeLinesButtonViews.get(i).setEnabled(true);
            }
        }
    }

    /**
     * Set lines to value entered from the param.
     *
     * @param linesAmount number of chosen lines.
     */
    @ExposeMethod
    public void setSelectedLinesAmount(int linesAmount) {
        if (getCurrentState().equals(ReelsPresentationStates.IDLE)) {
            clearAllLineButtonsState();
            if (vipLoungeLinesButtonViews.size() > 0) {
                selectLinesButton(linesAmount);
            }
            getEventBus().post(new SetLinesCommand(linesAmount, true));
        }
    }

    /**
     * Updates button to selected state according to chosen lines amount.
     *
     * @param linesAmount number of chosen lines.
     */
    private void selectLinesButton(int linesAmount) {
        switch (linesAmount) {
            case 10:
                vipLoungeLinesButtonViews.get(4).setButtonActiveState();
                break;
            case 8:
                vipLoungeLinesButtonViews.get(3).setButtonActiveState();
                break;
            case 5:
                vipLoungeLinesButtonViews.get(2).setButtonActiveState();
                break;
            case 3:
                vipLoungeLinesButtonViews.get(1).setButtonActiveState();
                break;
            case 1:
                vipLoungeLinesButtonViews.get(0).setButtonActiveState();
                break;
        }
    }

    /**
     * Shows next info screen.
     */
    @ExposeMethod
    public void showNextInfoScreen() {
        currentInfoScreenId++;
        if (currentInfoScreenId == infoScreensIds.size()) {
            currentInfoScreenId = 0;
        }
        showCurrentInfoScreen();
    }

    /**
     * Shows previous info screen.
     */
    @ExposeMethod
    public void showPreviousInfoScreen() {
        currentInfoScreenId--;
        if (currentInfoScreenId < 0) {
            currentInfoScreenId = infoScreensIds.size() - 1;
        }
        showCurrentInfoScreen();
    }

    /**
     * Shows current info screen.
     */
    private void showCurrentInfoScreen() {
        screenCommand = new ShowInfoScreenWithOrderCommand("infoScreen", showInfoScreenAnimationData);
        ((ShowInfoScreenCommand) screenCommand).setViewId(infoScreensIds.get(currentInfoScreenId));
        ((ShowInfoScreenWithOrderCommand) screenCommand).setInfoScreenOrder(currentInfoScreenId + 1);
        ((ShowInfoScreenWithOrderCommand) screenCommand).setInfoScreensAmount(infoScreensIds.size());
        setModelProperty(INFO_SCREEN_ENABLE, Boolean.FALSE);
        getEventBus().post(screenCommand);
        getEventBus().post(new PlaySoundCommand("Shift"));
    }

    /**
     * Handles the visibly of credit value.
     */
    @ExposeMethod
    public void toggleCreditsView() {
        if (getProperty(CREDIT_VISIBLE).equals(true)) {
            setModelProperty(CREDIT_VISIBLE, Boolean.FALSE);
            setModelProperty(CREDIT_HIDDEN, Boolean.TRUE);
        } else {
            setModelProperty(CREDIT_VISIBLE, Boolean.TRUE);
            setModelProperty(CREDIT_HIDDEN, Boolean.FALSE);
        }
    }

    /**
     * Handles the visibly of info screen.
     */
    @ExposeMethod
    public void toggleInfoScreen() {
        if (getProperty(INFO_SCREEN_VISIBLE).equals(true)) {
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
            currentInfoScreenId = 0;
            getEventBus().post(new HideScreenCommand("infoScreen", null));
            setAllButtonsToNormalState();
            InitHandlingLogoMovies.enableTimer(true);
        } else {
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.TRUE);
//            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
//            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
            showCurrentInfoScreen();
            InitHandlingLogoMovies.enableTimer(false);
        }
    }

    /**
     * Handles the visibly of menu view.
     */
    @ExposeMethod
    public void toggleMenuView() {
        if (getProperty(MENU_VISIBLE).equals(true) && findViewById("menuScreen").getAlpha()==1) {
//            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
            InitHandlingLogoMovies.enableTimer(true);
            getEventBus().post(new PlaySoundCommand("close_panel"));
        } else if(findViewById("menuScreen").getAlpha()==0){
            setModelProperty(MENU_VISIBLE, Boolean.TRUE);
            setVisibleAnimation("menuScreen", 1f, 500f, MENU_VISIBLE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.TRUE);
//            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
            InitHandlingLogoMovies.enableTimer(false);
            getEventBus().post(new PlaySoundCommand("open_panel"));
        }
    }

    /**
     * Handles visibility of the denomination view.
     */
    @ExposeMethod
    public void toggleDenominationView() {
        if (getProperty(DENOMINATION_VISIBLE).equals(true) && findViewById("denominationView").getAlpha()==1) {
            //setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
            InitHandlingLogoMovies.enableTimer(true);
            setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
            getEventBus().post(new PlaySoundCommand("close_panel"));
        } else if(findViewById("denominationView").getAlpha()==0){
            setModelProperty(DENOMINATION_VISIBLE, Boolean.TRUE);
//            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
            InitHandlingLogoMovies.enableTimer(false);
            setVisibleAnimation("denominationView", 1f, 500f, DENOMINATION_VISIBLE);
            getEventBus().post(new PlaySoundCommand("open_panel"));
        }
    }

    private void setVisibleAnimation(String viewId, float alpha, float timelength, String VisibleParametrName) {
        View view;
        TweenViewAnimation denomVizibleAnimation = GameEngine.current().getAnimationFactory().createAnimation(TweenViewAnimation.class);
        TweenViewAnimationData denomVizibleData = new TweenViewAnimationData();
        view = findViewById(viewId);
        denomVizibleAnimation.setTargetView(view);
        denomVizibleData.setDestinationAlpha(alpha);
        denomVizibleData.setTimeSpan(timelength);
        denomVizibleAnimation.setViewAnimationData(denomVizibleData);
        denomVizibleAnimation.play();

        if (alpha == 0) {
            denomVizibleAnimation.getTweenStateObservable().subscribe(integer -> {
                if (integer == TweenCallback.COMPLETE) {
                    setModelProperty(VisibleParametrName, Boolean.FALSE);
                }
            });
        }else{
        }
    }

    @ExposeMethod
    @Override
    public void spin() {
        super.spin();
        setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
        setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
//        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
        setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
        disableAllLineButtons();
    }

    /**
     * Changes the denomination
     *
     * @param index the denomination step index.
     */
    @ExposeMethod
    public void changeDenomination(int index) {
        BigDecimal denomination = denominationModelProvider.getModel().getDenominationStep(index);
        getEventBus().post(new ChangeDenominationCommand(denomination));
    }

    /**
     * Updates visible bet buttons.
     */
    private void updateVisibleBetButtons() {
        if (getBetModel() == null) {
            return;
        }
        setModelProperty(BET_INCREASE_ENABLE, getBetModel().getBetPerLine() < (getBetModel().getMaxBet()));
        setModelProperty(BET_DECREASE_ENABLE, getBetModel().getBetPerLine() > (getBetModel().getMinBet()));
    }

    @Subscribe
    @Override
    public void handleMessageChangedEvent(MessageChangedEvent messageChangedEvent) {
        if (BasicMessageType.BOTTOM_PANEL.equals(messageChangedEvent.getMessage().getMessageType())) {
            String message = messageChangedEvent.getMessage().getContent().replace("\n", "- ").replace("\r", "- ");
            getModel().setMessage(message);
        }
    }

    /**
     * Reacts to start the info screen transition.
     *
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (screenShowingEvent.getScreen() instanceof InfoScreen) {
            hideAllButtons();
        }
    }

    @Override
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        super.handleBetModelChangedEvent(betModelChangedEvent);
        updateVisibleBetButtons();
    }

    /**
     * Reacts to finish the info screen transition.
     *
     * @param screenShownEvent screen shown event
     */
    @Subscribe
    public void handleScreenShownEvent(ScreenShownEvent screenShownEvent) {
        if (screenShownEvent.getScreen() instanceof InfoScreen && getCurrentState().equals(ReelsPresentationStates.IDLE)) {
            setModelProperty(INFO_ENABLE, Boolean.TRUE);
            setModelProperty(SPIN_ENABLE, Boolean.TRUE);
            setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
            //setModelProperty(AUTO_PLAY_VISIBLE, Boolean.TRUE);
            setModelProperty(MENU_ENABLE, Boolean.TRUE);
            setModelProperty(BET_DECREASE_ENABLE, Boolean.TRUE);
            setModelProperty(BET_INCREASE_ENABLE, Boolean.TRUE);
//            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
            setModelProperty(INFO_SCREEN_ENABLE, Boolean.TRUE);
//            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
            setModelProperty(DENOMINATION_ENABLE, Boolean.TRUE);
            updateVisibleBetButtons();
        }
    }

    /**
     * Hides all buttons.
     */
    private void hideAllButtons() {
        setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        setModelProperty(SPIN_ENABLE, Boolean.FALSE);
        InitHandlingLogoMovies.enableTimer(false);//stop splash screen video
        setModelProperty(TAKE_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        //setModelProperty(AUTO_PLAY_VISIBLE, Boolean.FALSE);
        setModelProperty(MENU_ENABLE, Boolean.FALSE);
//        setModelProperty(MENU_VISIBLE, Boolean.FALSE);
        setVisibleAnimation("menuScreen", 0f, 500f, MENU_VISIBLE);
//        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setVisibleAnimation("denominationView", 0f, 500f, DENOMINATION_VISIBLE);
        setModelProperty(DENOMINATION_ENABLE, Boolean.FALSE);
        setModelProperty(BET_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(GAMBLE_VISIBLE, Boolean.FALSE);
        setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(BET_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(INFO_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, isAutoPlay);
        setModelProperty(AUTO_PLAY_VISIBLE, !isAutoPlay);
        disableAllLineButtons();
    }

    /**
     * Handles event about that auto play was started.
     *
     * @param autoPlayStartedEvent {@link AutoPlayStartedEvent}
     */
    @Subscribe
    public void handleAutoPlayStartedEvent(AutoPlayStartedEvent autoPlayStartedEvent) {
        isAutoPlay = true;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_PLAY_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.TRUE);
        autoplayButtomListener.startPlaySound();
    }

    /**
     * Handles the free games model changed event.
     *
     * @param freeGamesModelChangedEvent {@link FreeGamesModelChangedEvent}
     */
    @Subscribe
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        updateFreeGamesWin(freeGamesModelChangedEvent.getFreeGamesModel());
    }

    /**
     * Updates the win based on the current win in free games.
     *
     * @param freeGamesModel {@link IFreeGamesModel}
     */
    private void updateFreeGamesWin(IFreeGamesModel freeGamesModel) {
        if (freeGamesModel == null) {
            return;
        }
        long winAmount = freeGamesModel.getTotalWinAmount();
        long currentGameWinAmount = freeGamesModel.getCurrentGameWinAmount();
        if (freeGamesModel.getCurrentFreeGameNumber() > 0) {
            getCurrentWinController().setCurrentWin(winAmount - currentGameWinAmount);
            updateProperties();
        }
    }

    /**
     * Handles event about that auto play was stopped.
     *
     * @param autoPlayStoppedEvent {@link AutoPlayStoppedEvent}
     */
    @Subscribe
    public void handleAutoPlayStoppedEvent(AutoPlayStoppedEvent autoPlayStoppedEvent) {
        isAutoPlay = false;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
        setModelProperty(AUTO_PLAY_VISIBLE, Boolean.TRUE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.FALSE);
        autoplayButtomListener.stopPlaySound();
    }

    private class ScreenShowingEventObserver extends NextObserver<ScreenShowingEvent> {

        @Override
        public void onNext(final ScreenShowingEvent screenShowingEvent) {
            handleScreenShowingEvent(screenShowingEvent);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(final AutoPlayStoppedEvent autoPlayStoppedEvent) {
            handleAutoPlayStoppedEvent(autoPlayStoppedEvent);
            if (turboMode) {
                setTurboMode();
                quickButton.setDownStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                quickButton.setDisableStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                quickButton.setNormalStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                quickButton.setOverStateResource(((SpriteSheetResource) GameEngine.current().getResourceManager().getResource("buttons1")).getChildResource("01"));
                quickButton.setSkin(GameEngine.current().getViewManager().getSkinManager().getSkin("quickAutoplayText"));
                quickButton.setScaleX(1.8f);
                quickButton.setScaleY(1.8f);

            }
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(final AutoPlayStartedEvent autoPlayStartedEvent) {
            handleAutoPlayStartedEvent(autoPlayStartedEvent);
        }
    }

    private class ScreenShownEventObserver extends NextObserver<ScreenShownEvent> {

        @Override
        public void onNext(final ScreenShownEvent screenShownEvent) {
            handleScreenShownEvent(screenShownEvent);
        }
    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);
        }
    }

    @Override
    public TextView getIndicatorTextID1() {
        return indicatorTextID;
    }

    @Override
    public TextView getIndicatorTextID2() {
        return indicatorTextID2;
    }

    @Override
    public View getWinView() {
        return winView;
    }

    /**
     * Used for big win mode
     *
     * @param setEnable
     */
    public void setSkipEnable(boolean setEnable) {
        if (setEnable) {
            setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
        } else {
            setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        }
    }


    @ExposeMethod
    public void setTurboMode() {
        int reelTime;
        int increment;
        int numberOfReels = 5;
        if (!turboMode) {
            turboMode = true;
            reelTime = 0;
            increment = 50;

        } else {
            turboMode = false;
            reelTime = 400;
            increment = 300;
        }

        if (reelGroupView == null) {
            reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        }
        spinTime.clear();
        spinTime.add(reelTime);
        for (int i = 1; i < numberOfReels; i++) {
            spinTime.add(spinTime.get(i - 1) + increment);
        }
        reelGroupView.setStopOnSymbolsSequenceProvider(new ReelDelayedSequenceProvider(spinTime));

    }


    private class VolumeChangedEventObserver extends NextObserver<VolumeChangedEvent> {

        @Override
        public void onNext(final VolumeChangedEvent volumeChangedEvent) {
            volumeParameter = volumeChangedEvent.getVolume();

            handleVolumeChangedEvent(volumeParameter);
        }
    }


    public void handleVolumeChangedEvent(int volumeParameter) {
        ButtonView butPlus = findViewById("butPlus");
        ButtonView butMinus = findViewById("butMinus");
        ImageView value0 = findViewById("value0");
        ImageView value1 = findViewById("value1");
        ImageView value2 = findViewById("value2");

        switch (volumeParameter) {
            case 0:
                value0.setVisible(true);
                value1.setVisible(false);
                value2.setVisible(false);
                butPlus.setEnabled(true);
                butMinus.setEnabled(false);
                break;
            case 1:
                value0.setVisible(false);
                value1.setVisible(true);
                value2.setVisible(false);
                butPlus.setEnabled(true);
                butMinus.setEnabled(true);
                break;
            case 2:
                value0.setVisible(false);
                value1.setVisible(false);
                value2.setVisible(true);
                butPlus.setEnabled(false);
                butMinus.setEnabled(true);
                break;
            default:
        }
    }

    /**
     * Changes volume and updates volume buttons.
     */
    @ExposeMethod
    public void changeVolume(String buttonType) {
        ChangeGlobalVolumeCommand changeGlobalVolumeCommand = null;
        if (buttonType.equals("+")) {
            switch (volumeParameter) {
                case 0:
                    changeGlobalVolumeCommand = new ChangeGlobalVolumeCommand(0.6f);
                    volumeParameter++;
                    break;
                case 1:
                    changeGlobalVolumeCommand = new ChangeGlobalVolumeCommand(1);
                    volumeParameter++;
                    break;
            }
        } else {
            switch (volumeParameter) {
                case 2:
                    changeGlobalVolumeCommand = new ChangeGlobalVolumeCommand(0.6f);
                    volumeParameter--;
                    break;
                case 1:
                    changeGlobalVolumeCommand = new ChangeGlobalVolumeCommand(0.33f);
                    volumeParameter--;
                    break;
            }
        }
        if (changeGlobalVolumeCommand != null) {
            getEventBus().post(new PlaySoundCommand("volume"));
            getEventBus().post(changeGlobalVolumeCommand);
            getEventBus().post(new VolumeChangedEvent(volumeParameter));
        }

    }

    @Override
    public boolean getTurbomode() {
        return turboMode;
    }

    public void setIndicatorSum(Long winSum) {
        indicatorCollectSum = winSum;
    }

    public Long getIndicatorSum(){
        return indicatorCollectSum;
    }

    @Override
    public boolean isCollectPlaying() {
        return false;
    }

    @Override
    public void setCollectPlaying(boolean collectPlaying) {

    }

}