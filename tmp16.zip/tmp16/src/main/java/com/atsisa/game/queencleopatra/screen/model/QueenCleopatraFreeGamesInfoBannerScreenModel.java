package com.atsisa.game.queencleopatra.screen.model;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import javax.inject.Inject;

/**
 * Free games info banner screen model. Contains information about current free games number, total free games number, total free games win amount, number won
 * games.
 */
public class QueenCleopatraFreeGamesInfoBannerScreenModel extends ScreenModel {

    /**
     * Contains information about current number of free games.
     */
    private final NamedProperty<Integer> currentFreeGamesNumber = new NamedProperty<>(Integer.class, "currentFreeGamesNumber", 0);

    /**
     * Contains information about amount of free games played.
     */
    private final NamedProperty<Integer> totalFreeGamesNumber = new NamedProperty<>(Integer.class, "totalFreeGamesNumber", 0);

    /**
     * Contains information about current win value in free games.
     */
    private final NamedProperty<String> freeGamesWinAmount = new NamedProperty<>(String.class, "freeGamesWinAmount", StringUtility.EMPTY);

    /**
     * Contains information about number of free games retriggered.
     */
    private final NamedProperty<Integer> numberWonGames = new NamedProperty<>(Integer.class, "numberWonGames", 0);

    /**
     * Initializes a new instance of the {@link QueenCleopatraFreeGamesInfoBannerScreenModel} class.
     * @param translator {@link ITranslator}
     */
    @Inject
    public QueenCleopatraFreeGamesInfoBannerScreenModel(ITranslator translator) {
        super(translator);
        registerProperties();
    }

    /**
     * Registers custom free games banner screen properties.
     */
    private void registerProperties() {
        registerProperty(freeGamesWinAmount);
        registerProperty(totalFreeGamesNumber);
        registerProperty(numberWonGames);
        registerProperty(currentFreeGamesNumber);
    }

    /**
     * Gets the total free games number property.
     * return the total free games number property.
     */
    public IObservableProperty<Integer> totalFreeGamesNumber() {
        return totalFreeGamesNumber;
    }

    /**
     * Gets the total free games win amount property.
     * return the total free games win amount property.
     */
    public IObservableProperty<String> freeGamesWinAmount() {
        return freeGamesWinAmount;
    }

    /**
     * Gets the number won games observable property.
     * return the number won games observable property.
     */
    public IObservableProperty<Integer> numberWonGames() {
        return numberWonGames;
    }

    /**
     * Gets the current free games number observable property.
     * return the current free games number observable property.
     */
    public IObservableProperty<Integer> currentFreeGamesNumber() {
        return currentFreeGamesNumber;
    }

    /**
     * Sets the total number of free games.
     * @param totalFreeGamesNumber the total number of free games
     */
    public void setTotalFreeGamesNumber(int totalFreeGamesNumber) {
        this.totalFreeGamesNumber.set(totalFreeGamesNumber);
    }

    /**
     * Sets the current number of free game.
     * @param freeGamesNumber the current number of free game
     */
    public void setCurrentFreeGamesNumber(int freeGamesNumber) {
        currentFreeGamesNumber.set(freeGamesNumber);
    }

    /**
     * Sets the number of recently won free games.
     * @param wonFreeGames the number of recently won free games
     */
    public void setNumberWonGames(int wonFreeGames) {
        numberWonGames.set(wonFreeGames);
    }

    /**
     * Sets the current win value in free games.
     * @param winAmount {@link String}
     */
    public void setFreeGamesWinAmount(String winAmount) {
        freeGamesWinAmount.set(winAmount);
    }

    /**
     * Gets the total number of free games.
     * @return the total number of free games
     */
    public int getTotalFreeGamesNumber() {
        return totalFreeGamesNumber.get();
    }

    /**
     * Gets the current number of free game.
     * @return the current number of free game
     */
    public int getCurrentFreeGamesNumber() {
        return currentFreeGamesNumber.get();
    }

    /**
     * Gets the number of recently won free games.
     * @return the number of recently won free games
     */
    public int getNumberWonGames() {
        return numberWonGames.get();
    }

    /**
     * Gets the current win value in free games.
     * @return the current win value in free games
     */
    public String getFreeGamesWinAmount() {
        return freeGamesWinAmount.get();
    }

}
