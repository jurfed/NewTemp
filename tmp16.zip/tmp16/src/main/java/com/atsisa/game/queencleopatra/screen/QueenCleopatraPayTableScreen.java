package com.atsisa.game.queencleopatra.screen;

import com.atsisa.game.queencleopatra.customviews.FrameParticleView;
import com.atsisa.game.queencleopatra.gameobjects.staticClasses.ExtendedSymbolStatic;
import com.atsisa.game.queencleopatra.helpers.*;
import com.atsisa.game.queencleopatra.listener.LanguageChangeListener;
import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraPayTableScreenModel;

import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.utility.*;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.atsisa.gox.reels.model.IPayTableModelItem;
import com.atsisa.gox.reels.screen.PayTableScreen;

import javax.inject.Inject;
import javax.inject.Named;


/**
 * Represents the pay table screen for feature and base games.
 */
public class QueenCleopatraPayTableScreen extends PayTableScreen {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String QUEEN_CLEOPATRA_PAYTABLE_LAYOUT_ID_PROPERTY = "QueenCleopatraPayTableScreen";

    /**
     * Pay table feature screen visible.
     */
    private static final String PAY_TABLE_FEATURE_SCREEN_VISIBLE = "payTableFeatureScreenVisible";

    /**
     * Pay table base game screen visible.
     */
    private static final String PAY_TABLE_BASE_GAME_SCREEN_VISIBLE = "payTableBaseGameScreenVisible";

    /**
     * Fourth scatter symbol visible.
     */
    private static final String TWO_SCATTER_PAYS_VISIBLE = "twoScatterPaysVisible";

    /**
     * Inject View of the extended symbol.
     */
    @InjectView
    public ViewGroup extendedSymbolGroup;


    /**
     * To get the logo animation object
     */
    private final String LAYOUT_ID_FOR_LOGO = "payTableBgrScreen";
    private final String KEY_FRAME_ANIMATION_VIEW_ID_FOR_UPPER_LOGO = "logoAnimation";

    /**
     * For logo animation object
     */
    private KeyframeAnimationView logoAnimation;

//    private CustomKeyframeAnimationView kf;

    LanguageChangeListener languageChangeListener;

    /**
     * Initializes a new instance of {@link PayTableScreen} class.
     *
     * @param layoutId         the layout identifier
     * @param model            {@link QueenCleopatraPayTableScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     */
    @Inject
    public QueenCleopatraPayTableScreen(@Named(QUEEN_CLEOPATRA_PAYTABLE_LAYOUT_ID_PROPERTY) String layoutId, QueenCleopatraPayTableScreenModel model,
                                        IRenderer renderer, IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
    }

    /**
     * Updates pay table with received scatter amount, updates Scatter symbol on pay table.
     */
    @Subscribe
    public void handleExtendedSymbolModelChangedEvent(ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
        IExtendedSymbolModel extendedSymbolModel = extendedSymbolModelChangedEvent.getExtendedSymbolModel();
        if (extendedSymbolModel != null && extendedSymbolModel.getExtendedSymbolPayTableItems() != null) {
            Iterable<IPayTableModelItem> symbols = extendedSymbolModel.getExtendedSymbolPayTableItems();
            if (Iterables.size(extendedSymbolModel.getExtendedSymbolPayTableItems()) > 3) {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.TRUE);
            } else {
                setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
            }
            ((QueenCleopatraPayTableScreenModel) getModel()).updateExtendedSymbols(symbols);
            updateFeatureInfo(extendedSymbolModel.getExtendedSymbolName());
            showFeatureInfo();
        } else {
            hideFeatureInfo();
        }
    }

    @Override
    protected void doInitialize() {
        super.doInitialize();
        hideFeatureInfo();

/*        ILayout layout = getLayout();
        ViewGroup viewGroup = (ViewGroup) layout.getRootView();*//*

//        ViewGroup viewGroup2 = (ViewGroup) GameEngine.current().getViewManager().getLayout("Line1Screen").getRootView();
        ViewGroup viewGroup2 = (ViewGroup) GameEngine.current().getViewManager().getLayout("Line1Screen").getRootView();

        ImageView lineImageView = new ImageView();
//        lineImageView.setId("line_tex");

        //get Image from resource
        IImageReference imageReference = GameEngine.current().getResourceManager().getResource("image.png");

        //get Image from SpriteSheet
        ((SpriteSheetResource)GameEngine.current().getResourceManager().getResource("bigWin")).getChildResource("Awesome_Win")

        lineImageView.setImage(imageReference);
//        viewGroup.addChild(lineImageView);
        System.err.println();*/
    }

    @Override
    protected void registerEvents() {
        getEventBus().register(new ExtendedSymbolModelChangedEventObserver(), ExtendedSymbolModelChangedEvent.class);
        super.registerEvents();
    }

    @Override
    protected void afterActivated() {

//        kf = getViewManager().findViewById("payTableScreen", "1811");

        if (!StringUtility.isNullOrEmpty(ExtendedSymbolStatic.extendedSymbolName)) {
            updateFeatureInfo(ExtendedSymbolStatic.extendedSymbolName);
        } else {
            hideFeatureInfo();
        }



        //Initialize the mechanism of blinking texts on the upper screen
        new AniliseSymbolsForBlinking(getEventBus());


/*
        ReelGroupView reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        reelGroupView.getReel(5).spin();
        reelGroupView.setSpinSequenceProvider(new ReelDelayedSequenceProvider(new ArrayList<Integer>(){{add(0);add(100);add(0);add(0);add(0);}}));
        reelGroupView.setStopOnSymbolsSequenceProvider(new ReelDelayedSequenceProvider(new ArrayList<Integer>(){{add(-100);add(100);add(100);add(100);add(100);}}));
*/

//        ParticleView p = findViewById("13qwe");
/*        FrameParticleView p = findViewById("13qwe");


        p.setEndScale(1.1f);
        p.setHeight(500);
        p.setMaxAngle(30);
        p.setMaxParticleLifetime(30);
        p.setMaxParticles(100);
        p.setWidth(500);
        p.setYOffset(3.5f);
        p.setRotation(1.5f);
        p.setEndingSpeed(1);
        p.setEndingSpeed(100);
        p.start();*/

        //Calling the method for logo animation
        logoAnimation();
        super.afterActivated();
    }

    /**
     * Shows feature screen.
     */
    private void showFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.TRUE);
    }

    /**
     * Hides feature screen.
     */
    private void hideFeatureInfo() {
        setModelProperty(PAY_TABLE_BASE_GAME_SCREEN_VISIBLE, Boolean.TRUE);
        setModelProperty(PAY_TABLE_FEATURE_SCREEN_VISIBLE, Boolean.FALSE);
        setModelProperty(TWO_SCATTER_PAYS_VISIBLE, Boolean.FALSE);
    }

    /**
     * Updates extended info visibility depending on the extended symbol name.
     *
     * @param extendedSymbolName the extended symbol name.
     */
    private void updateFeatureInfo(String extendedSymbolName) {
        ExtendedSymbolStatic.extendedSymbolName = extendedSymbolName;
        if (extendedSymbolGroup == null) {
            return;
        }
        for (View view : extendedSymbolGroup.getChildren()) {
            if (view.getId().contains(ExtendedSymbolStatic.extendedSymbolName)) {
                view.setVisible(true);
            } else {
                view.setVisible(false);
            }
        }
    }

    private class ExtendedSymbolModelChangedEventObserver extends NextObserver<ExtendedSymbolModelChangedEvent> {

        @Override
        public void onNext(final ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent) {
            handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);
        }
    }

    /**
     * Animation of the logo on the upper screen every 5 seconds
     */
    public void logoAnimation() {

        logoAnimation = getViewManager().findViewById(LAYOUT_ID_FOR_LOGO, KEY_FRAME_ANIMATION_VIEW_ID_FOR_UPPER_LOGO);
        /**
         *local class for start playing logo animation
         */


        TimeoutCallback timeOutLogoAnimation = () -> {
            logoAnimation.gotoAndPlay(1);
//            kf.setTest("go");
        };

        new Timeout(0, timeOutLogoAnimation, true).start();

        //Call every 5 seconds playing the logo
        logoAnimation.addPropertyChangedListener((view, viewType, i) -> {
            if (!logoAnimation.isPlaying()) {
                new Timeout(5000, timeOutLogoAnimation, true).start();

            }
        });

    }

}