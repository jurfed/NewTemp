package com.atsisa.game.queencleopatra.action;

import com.atsisa.gox.framework.action.Action;

public class EmptyAction extends Action{
    @Override
    protected void execute() {
        finish();
    }
}
