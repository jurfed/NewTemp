package com.atsisa.game.queencleopatra.screen.model;

import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.NamedProperty;
import com.atsisa.gox.framework.screen.model.ScreenModel;

public class SampleScreenModel extends ScreenModel {

    private final NamedProperty<Integer> height = new NamedProperty<Integer>(Integer.class, "height", 100);

    public SampleScreenModel() {
        this.setProperty("width", 200);
    }

    public void setHeight(Integer value) {
        this.height.set(value);
    }

}
