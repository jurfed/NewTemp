package com.atsisa.game.queencleopatra.action.animation.panel.collect.freeGamesCollect;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class FreeGamesSoundData extends ActionData {

    @XmlAttribute
    private boolean extended = false;


    public boolean getExtended() {
        return extended;
    }

    public void setExtended(boolean extended) {
        this.extended = extended;
    }
}
