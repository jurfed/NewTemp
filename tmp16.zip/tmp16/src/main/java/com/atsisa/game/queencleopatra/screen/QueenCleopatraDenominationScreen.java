package com.atsisa.game.queencleopatra.screen;

import java.math.BigDecimal;
import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.command.ChangeDenominationCommand;
import com.atsisa.gox.reels.model.IDenominationModelProvider;
import com.gwtent.reflection.client.Reflectable;

@Reflectable
public class QueenCleopatraDenominationScreen extends Screen<ScreenModel> {

    /**
     * Name of the layout id property, used with IoC to define id of the layout in game for this screen.
     */
    public static final String LAYOUT_ID_PROPERTY = "denominationScreen";

    /**
     * Denomination model provider.
     */
    private IDenominationModelProvider denominationModelProvider;

    /**
     * Action manager.
     */
    private IActionManager actionManager;

    /**
     * Initializes a new instance of the {@link QueenCleopatraDenominationScreen} class.
     * @param layoutId                  layout identifier
     * @param model                     {@link ScreenModel}
     * @param renderer                  {@link IRenderer}
     * @param viewManager               {@link IViewManager}
     * @param animationFactory          {@link IAnimationFactory}
     * @param logger                    {@link ILogger}
     * @param eventBus                  {@link IEventBus}
     * @param denominationModelProvider {@link IDenominationModelProvider}
     * @param actionManager             {@link IActionManager}
     */
    @Inject
    protected QueenCleopatraDenominationScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, ScreenModel model, IRenderer renderer,
                                               IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus,
                                               IDenominationModelProvider denominationModelProvider, IActionManager actionManager) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus);
        this.denominationModelProvider = denominationModelProvider;
        this.actionManager = actionManager;
    }

    /**
     * Changes the denomination
     * @param denominationIndex the denomination step index.
     */
    @ExposeMethod
    public void changeDenomination(int denominationIndex) {
        BigDecimal denomination = denominationModelProvider.getModel().getDenominationStep(denominationIndex);
        getEventBus().post(new ChangeDenominationCommand(denomination));
        actionManager.processQueue("ExitDenomination");
    }
}