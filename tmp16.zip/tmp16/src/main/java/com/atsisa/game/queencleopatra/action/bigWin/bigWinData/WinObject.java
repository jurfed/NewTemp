package com.atsisa.game.queencleopatra.action.bigWin.bigWinData;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("OBJECT")
        // another mapping
public class WinObject {

    @XStreamAlias("INITSTATE")
    public InitState initState;

    @XStreamImplicit(itemFieldName = "STEP")
    public List steps = new ArrayList();

    public List getSteps() {
        return steps;
    }

}
