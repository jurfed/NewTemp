package com.atsisa.game.queencleopatra.listener;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.view.*;

import javax.xml.soap.Text;

/**
 * Class for correcting texts when switching between languages
 */
public class LanguageChangeListener implements IViewPropertyChangedListener {
    private ButtonView languageButton;
    private TextView czText;
    private TextView deText;

    private TextView LangSpecialSymbolFreeGames;
    private TextView LangOnActiveLinePays;
    private TextView LangTimesLineBet;

    private TextView Lang3OrMoreScattered;
    private TextView LangTrigger10Free;

    private TextView LangOneSymbolIs;


    private TextView settingsTitle;
    private TextView soundTitle;
    private TextView gamblerTitle;

    private TextView reelsSound;

    private ButtonView settingsQuite;

    private ButtonView SoundVol1;
    private ButtonView SoundVol2;
    private ButtonView SoundVol3;

    private ButtonView soundMechnic1;
    private ButtonView soundMechnic2;

    private ButtonView music1;
    private ButtonView music2;
    private ButtonView classic1;
    private ButtonView classic2;

    private TextView LinesText;
    private TextView denomText;

    private TextView sidePanelBetShadow;
    private TextView sidePanelBet;
    private TextView betMainButtonText;
    private TextView myBetText;
    private TextView sidePanelLineShadow;
    private TextView sidePanelLine;

    private IViewManager viewManager = GameEngine.current().getViewManager();

    private TextView allPrizes;
    private TextView malfunction;

    public LanguageChangeListener() {
        czText = getTextView("freeGamesBannerScreen", "endGame", "wrongText");
        deText = getTextView("infoScreen", "gamblerInfoScreen", "LangGamblerFeatureDescription2");
        LangSpecialSymbolFreeGames = viewManager.findViewById("enterFeatureBannerScreen", "LangSpecialSymbolFreeGames");


        LangOnActiveLinePays = viewManager.findViewById("payTableScreen", "LangOnActiveLinePays");
        LangTimesLineBet = viewManager.findViewById("payTableScreen", "LangTimesLineBet");

        Lang3OrMoreScattered = viewManager.findViewById("payTableScreen", "Lang3OrMoreScattered");
        LangTrigger10Free = viewManager.findViewById("payTableScreen", "LangTrigger10Free");

        LangOneSymbolIs = viewManager.findViewById("payTableScreen", "LangOneSymbolIs");

        //controll panel
        ViewGroup vg1 = viewManager.findViewById("settingsScreen", "group1");
        ViewGroup vg2 = viewManager.findViewById(vg1, "languageTab");
        ViewGroup vg3 = viewManager.findViewById(vg2, "languageButtons");
        settingsTitle = viewManager.findViewById(vg3, "title1");

        vg2 = viewManager.findViewById(vg1, "soundTab");
        vg3 = viewManager.findViewById(vg2, "soundButtons");
        soundTitle = viewManager.findViewById(vg3, "title2");

        vg2 = viewManager.findViewById(vg1, "gamblerTab");
        vg3 = viewManager.findViewById(vg2, "gamblerButtons");
        gamblerTitle = GameEngine.current().getViewManager().findViewById(vg3, "title3");

        vg2 = viewManager.findViewById(vg1, "soundTab");
        reelsSound = viewManager.findViewById(vg2, "reelsSoundText");

        settingsQuite = viewManager.findViewById("settingsScreen", "settingsQuite");

        vg2 = viewManager.findViewById(vg1, "soundTab");
        vg3 = viewManager.findViewById(vg2, "soundButtons");
        SoundVol1 = viewManager.findViewById(vg3, "vol1");
        SoundVol2 = viewManager.findViewById(vg3, "vol2");
        SoundVol3 = viewManager.findViewById(vg3, "vol3");

        soundMechnic1 = viewManager.findViewById(vg3, "mechanic1");
        soundMechnic2 = viewManager.findViewById(vg3, "mechanic2");

        music1 = viewManager.findViewById(vg3, "music1");
        music2 = viewManager.findViewById(vg3, "music2");

        classic1 = viewManager.findViewById(vg3, "classic1");
        classic2 = viewManager.findViewById(vg3, "classic2");

        View sidePanel = viewManager.findViewById("bottomPanelScreen", "linesSidePanel");
        View linesSide = viewManager.findViewById(sidePanel, "linesSidePanelMainButton");
        LinesText = viewManager.findViewById(linesSide, "textLines");

        View denomGroup = viewManager.findViewById("denominationScreen", "denomId");
        denomText = viewManager.findViewById(denomGroup, "denomText");

        sidePanelBetShadow = viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "betsSidePanelDragButton"), "sidePanelBetShadow");
        sidePanelBet = viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "betsSidePanelDragButton"), "sidePanelBet");
        betMainButtonText = viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "betsSidePanelMainButton"), "betMainButtonText");
        myBetText = viewManager.findViewById(viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "mainID"), "myBet"), "myBetText");

        sidePanelLineShadow = viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "linesSidePanelDragButton"), "sidePanelLineShadow");
        sidePanelLine = viewManager.findViewById(viewManager.findViewById("bottomPanelScreen", "linesSidePanelDragButton"), "sidePanelLine");

        ViewGroup liveglass_info = viewManager.findViewById("payTableScreen", "liveglass_info");
        allPrizes = viewManager.findViewById(liveglass_info, "allPrizes");
        malfunction = viewManager.findViewById(liveglass_info, "malfunction");
    }

    private TextView getTextView(String layOutId, String groupViewIdm, String textViewId) {
        ViewGroup gamblerInfoScreen = GameEngine.current().getViewManager().findViewById(layOutId, groupViewIdm);

        for (View text : gamblerInfoScreen.getChildren()) {
            if (text.getId() != null && text.getId().equals(textViewId)) {
                return (TextView) text;
            }
        }
        return null;
    }

    /**
     * Analyze the pressed button and correct the texts
     *
     * @param view
     * @param viewType
     * @param i
     */
    @Override
    public void propertyChanged(View view, ViewType viewType, int i) {
        languageButton = (ButtonView) view;
        if (languageButton.getCurrentState().name().equals("DOWN_STATE")) {
            if (languageButton.getId().equals("enButton")) {
                czText.setVisible(false);
                deText.setVisible(false);
                LangSpecialSymbolFreeGames.setX(300);
                LangOnActiveLinePays.setText("on active line pays");
                LangTimesLineBet.setText("times line bet");

                Lang3OrMoreScattered.setText("3 or more scattered");
                LangTrigger10Free.setText("trigger 10 Free Games\nwith special expanding symbol");

                LangOneSymbolIs.setText("One symbol is randomly selected as\n" +
                        "the special symbol which expands and\n" +
                        "pays any on all lines played");

                settingsTitle.setText("LANGUAGE");
                soundTitle.setText("SOUND");
                gamblerTitle.setText("GAMBLE");
                settingsQuite.setLabel("Quit");
                reelsSound.setText("REELS SOUND");
                SoundVol1.setLabel("Volume");
                SoundVol2.setLabel("Volume");
                SoundVol3.setLabel("Volume");
                soundMechnic1.setLabel("Mechanical");
                soundMechnic2.setLabel("Mechanical");
                classic1.setLabel("Classic");
                classic2.setLabel("Classic");
                music1.setLabel("Music");
                music2.setLabel("Music");
                if (sidePanelBetShadow != null) {
                    LinesText.setText("LINES");
                    denomText.setText("DENOMINATION");
                    sidePanelBetShadow.setText("BET");
                    sidePanelBet.setText("BET");
                    betMainButtonText.setText("BET");
                    myBetText.setText("BET");

                    sidePanelLineShadow.setText("LINES");
                    sidePanelLine.setText("LINES");

                }
                allPrizes.setText("ALL PRIZES SHOWN IN CREDITS");
                malfunction.setText("MALFUNCTION VOIDS ALL PAYS AND PLAYS");
                malfunction.setX(1370);

            } else if (languageButton.getId().equals("deButton")) {
                czText.setVisible(false);
                deText.setVisible(true);
                LangSpecialSymbolFreeGames.setX(240);
                LangOnActiveLinePays.setText("auf einer aktiven Linie zahlt");
                LangTimesLineBet.setText("mal Einsatz pro Linie");

                Lang3OrMoreScattered.setText("3 oder mehr SCATTER");
                LangTrigger10Free.setText("lösen 10 Freispiele\nmit Bonus-Symbol aus");

                LangOneSymbolIs.setText("Ein Symbol wird als Bonus-Symbol zufällig gewählt.\n" +
                        "Dieses nimmt alle Positionen auf der Walze ein\n" +
                        "und zahlt in beliebiger Position\n" +
                        "auf allen gespielten Linien");

                settingsTitle.setText("SPRACHE");
                soundTitle.setText("TONAUSGABE");
                gamblerTitle.setText("RISIKOSPIEL");
                settingsQuite.setLabel("Beenden");
                reelsSound.setText("WALZEN-SOUND");
                SoundVol1.setLabel("Lautstärke");
                SoundVol2.setLabel("Lautstärke");
                SoundVol3.setLabel("Lautstärke");
                soundMechnic1.setLabel("Mechanisch");
                soundMechnic2.setLabel("Mechanisch");
                classic1.setLabel("Klassisch");
                classic2.setLabel("Klassisch");
                music1.setLabel("Musik");
                music2.setLabel("Musik");
                if (sidePanelBetShadow != null) {
                    LinesText.setText("LINIEN");
                    denomText.setText("KREDITVERT");
                    sidePanelBetShadow.setText("EINSATZ");
                    sidePanelBet.setText("EINSATZ");
                    betMainButtonText.setText("EINSATZ");
                    myBetText.setText("EINSATZ");

                    sidePanelLineShadow.setText("LINIEN");
                    sidePanelLine.setText("LINIEN");
                }
                allPrizes.setText("ALLE PREISE WERDEN IN KREDITEN ANGEZEIGT");
                malfunction.setText("FEHLFUNKTION MACHT ALLE SPIELE UND ZAHLUNGEN UNGÜLTIG");
                malfunction.setX(1250);
            } else if (languageButton.getId().equals("csButton")) {
                czText.setVisible(true);
                deText.setVisible(false);
                LangSpecialSymbolFreeGames.setX(240);
                LangOnActiveLinePays.setText("3 nebo více SCATTER-symbolů");
                LangTimesLineBet.setText("krát sázku na linii");

                Lang3OrMoreScattered.setText("times line bet");
                LangTrigger10Free.setText("spustí 10 Volných her\ns Bonus symbolem");

                LangOneSymbolIs.setText("Jeden symbol bude náhodně zvolen jako Bonus symbol,\n" +
                        "který se rozšíří na všechny pozice\n" +
                        "válce a platí na libovolných pozicích\n" +
                        "na všech hraných liniích");

                settingsTitle.setText("JAZYK");
                soundTitle.setText("ZVUK");
                gamblerTitle.setText("HRA S RIZIKEM");
                settingsQuite.setLabel("Ukončit");
                reelsSound.setText("ZVUK VÁLCŮ");
                SoundVol1.setLabel("Hlasitost");
                SoundVol2.setLabel("Hlasitost");
                SoundVol3.setLabel("Hlasitost");
                soundMechnic1.setLabel("Mechanický");
                soundMechnic2.setLabel("Mechanický");
                classic1.setLabel("Klasický");
                classic2.setLabel("Klasický");
                music1.setLabel("Hudba");
                music2.setLabel("Hudba");
                if (sidePanelBetShadow != null) {
                    LinesText.setText("LINIE");
                    denomText.setText("DENOMINATION");
                    sidePanelBetShadow.setText("SÁZKA");
                    sidePanelBet.setText("SÁZKA");
                    betMainButtonText.setText("SÁZKA");
                    myBetText.setText("SÁZKA");
                    sidePanelLineShadow.setText("LINIE");
                    sidePanelLine.setText("LINIE");
                }
                allPrizes.setText("VŠECHNY VÝHRY JSOU ZOBRAZENY V KREDITECH");
                malfunction.setText("PORUCHA ZNEMOŽŇUJE VŠECHNY VÝPLATY A HRY");
                malfunction.setX(1370);
            }
        }

    }
}