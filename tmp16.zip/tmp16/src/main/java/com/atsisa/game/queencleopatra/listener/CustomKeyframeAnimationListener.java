package com.atsisa.game.queencleopatra.listener;

import com.atsisa.game.queencleopatra.customviews.CustomKeyframeAnimationView;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.view.*;

import java.util.Map;

/**
 * To recognize when to display lines
 */
public class CustomKeyframeAnimationListener implements IViewPropertyChangedListener {
    private CustomKeyframeAnimationView[] customKeyframeAnimationView;
    private ImageView[] lines1Front;
    private ImageView[] lines1Back;
    private int segmentsLinesCount;
    private int indexVisibleLines;
    private final int REELS_COUNT = 5; //Number of reels
    Map<Integer, Integer[]> linesSegmentsToFrame;

    /**
     * @param customKeyframeAnimationView - Animated frame, the visibility of which we track
     * @param lines1Front                 - Array of front line segments
     * @param lines1Back                  - Array of back segments of lines
     * @param segmentsLinesCount          - number of win line segments
     * @param indexVisibleLines           - The segment number from which only the visible segments always start
     * @param linesSegmentsToFrame        - To specify which segments to which frame are attached
     */
    public CustomKeyframeAnimationListener(CustomKeyframeAnimationView[] customKeyframeAnimationView, ImageView[] lines1Front, ImageView[] lines1Back, int segmentsLinesCount, int indexVisibleLines, Map<Integer, Integer[]> linesSegmentsToFrame) {
        this.customKeyframeAnimationView = customKeyframeAnimationView;
        this.lines1Front = lines1Front;
        this.lines1Back = lines1Back;
        this.segmentsLinesCount = segmentsLinesCount;
        this.indexVisibleLines = indexVisibleLines;
        this.linesSegmentsToFrame = linesSegmentsToFrame;

    }

    @Override
    public void propertyChanged(View view, ViewType viewType, int property) {
        //If at least one of the frames is visible
        if (customKeyframeAnimationView[0].isVisible() || customKeyframeAnimationView[1].isVisible() || customKeyframeAnimationView[2].isVisible() || customKeyframeAnimationView[3].isVisible() || customKeyframeAnimationView[4].isVisible()) {

            for (int i = indexVisibleLines; i <= segmentsLinesCount; i++) {//for always visible lines
                lines1Front[i - 1].setVisible(true);
                lines1Back[i - 1].setVisible(true);
            }

            for (int i = 0; i < REELS_COUNT; i++) {
                if (customKeyframeAnimationView[i].isVisible()) {//If the frame is visible, we hide the corresponding segments
                    for (int j : linesSegmentsToFrame.get(i)) {
                        lines1Front[j].setVisible(false);
                        lines1Back[j].setVisible(false);
                    }
                } else {
                    for (int j : linesSegmentsToFrame.get(i)) {//If the frame is not visible, we show the corresponding segments
                        lines1Front[j].setVisible(true);
                        lines1Back[j].setVisible(true);
                    }
                }
            }

        } else {
            for (int i = 0; i < segmentsLinesCount; i++) {//Hide all segments of lines
                lines1Front[i].setVisible(false);
                lines1Back[i].setVisible(false);
            }
        }
    }
}