package com.atsisa.game.queencleopatra.screen;

import com.atsisa.game.queencleopatra.gameobjects.GetLiveGlassObjects;
import com.atsisa.game.queencleopatra.gameobjects.enums.LiveGlassAnimationId;
import com.atsisa.game.queencleopatra.gameobjects.staticClasses.GamblerIsStart;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.reels.command.ShowSelectedGamblerCardCommand;
import com.atsisa.gox.reels.model.GamblerCardType;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.screen.GamblerScreen;
import com.atsisa.gox.reels.screen.model.GamblerScreenModel;
import com.atsisa.gox.reels.view.AbstractGamblerCard;
import com.atsisa.gox.reels.view.GamblerCardView;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashMap;


/**
 * Represents the gambler screen.
 */
public class QueenCleopatraGamblerScreen extends GamblerScreen {

    /**
     * Red button enabled.
     */
    private static final String RED_BUTTON_ENABLED = "redButtonEnabled";

    /**
     * Black button enabled.
     */
    private static final String BLACK_BUTTON_ENABLED = "blackButtonEnabled";

    /**
     * Black button enabled.
     */
    private static final String BLACK_BUTTON_SELECTED = "blackButtonSelected";

    /**
     * Red button enabled.
     */
    private static final String RED_BUTTON_SELECTED = "redButtonSelected";

    /**
     * Main card visible.
     */
    private static final String MAIN_CARD_VISIBLE = "mainCardVisible";

    /**
     * Animation card visible.
     */
    private static final String ANIMATION_CARD_VISIBLE = "animationCardVisible";

    /**
     * for background animation under the buttons
     */
    private KeyframeAnimationView btn_bgr1;
    private KeyframeAnimationView btn_bgr2;

    /**
     * ids for background animation under the buttons
     */
    private static final String BTN_BGR_ID1 = "btn_bgr1";
    private static final String BTN_BGR_ID2 = "btn_bgr2";

    /**
     * ids for buttons
     */
    private static final String RED_GAMBLER_BUTTON = "redGamblerButton";
    private static final String BLACK_GAMBLER_BUTTON = "blackGamblerButton";

    /**
     * State for buttons
     */
    private static final String NORMAL_STATE_FORBUTTONS = "NORMAL_STATE";

    /**
     * Red and black buttons
     */
    private ButtonView bt;
    private ButtonView bt2;

    /**
     * The main card in the center
     */
    private GamblerCardView mainCard;

    /**
     * Childs in the component GamblerCardView
     */
    private Iterable<View> winCards;

    /**
     * Child counter of the mainCard component
     */
    private int winCardsChildCount;

    /**
     * The name of the buttons
     */
    private final String BUTTON_ID_RED = "RED";
    private final String BUTTON_ID_BLACK = "BLACK";

    /**
     * Name of the button you pressed
     */
    private String ButtonPressed;
    private final String GAMBLER_SCREEN = "gamblerScreen";
    private final String MAIN_CARD_ID = "mainCard";

    /**
     * Initializes a new instance of the {@link QueenCleopatraGamblerScreen} class.
     * @param layoutId         layout identifier
     * @param model            {@link GamblerScreenModel}
     * @param renderer         {@link IRenderer}
     * @param viewManager      {@link IViewManager}
     * @param animationFactory {@link IAnimationFactory}
     * @param logger           {@link ILogger}
     * @param eventBus         {@link IEventBus}
     * @param resourceManager  {@link IResourceManager}
     * @param creditsFormatter {@link ICreditsFormatter}
     */
    @Inject
    public QueenCleopatraGamblerScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, GamblerScreenModel model, IRenderer renderer, IViewManager viewManager,
                                       IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IResourceManager resourceManager, ICreditsFormatter creditsFormatter) {
        super(layoutId, model, renderer, viewManager, animationFactory, logger, eventBus, resourceManager);
    }


    @Override
    protected void stateChanged() {

        setModelProperty(RED_BUTTON_ENABLED, Boolean.FALSE);
        setModelProperty(BLACK_BUTTON_ENABLED, Boolean.FALSE);
        setModelProperty(BLACK_BUTTON_SELECTED, Boolean.FALSE);
        setModelProperty(RED_BUTTON_SELECTED, Boolean.FALSE);
        setModelProperty(MAIN_CARD_VISIBLE, Boolean.FALSE);

        //Flag the beginning of the game to stop the animation on the upper screen
        if (!GamblerIsStart.gamblerIsStart) {
            GamblerIsStart.gamblerIsStart = true;
/*            private GetLiveGlassObjects liveGlassObjects;
            private HashMap<String, KeyframeAnimationView> mapUpperScreenSymbolsAnimation = liveGlassObjects.getLiveGlassAnimation(LiveGlassAnimationId.getSyblosAnimationsNames());*/

        }

        //Initialize buttons and background under them
        if (bt == null || bt2 == null) {
            bt = getViewManager().findViewById(this.getLayout().getId(), RED_GAMBLER_BUTTON);
            bt2 = getViewManager().findViewById(this.getLayout().getId(), BLACK_GAMBLER_BUTTON);
            btn_bgr1 = getViewManager().findViewById(this.getLayout().getId(), BTN_BGR_ID1);
            btn_bgr2 = getViewManager().findViewById(this.getLayout().getId(), BTN_BGR_ID2);
        }

        //Animate the background under the buttons
        if (bt.getCurrentState().name().equals(NORMAL_STATE_FORBUTTONS) || bt2.getCurrentState().name().equals(NORMAL_STATE_FORBUTTONS)) {
            if (btn_bgr1.isPaused() && btn_bgr2.isPaused()) {
                btn_bgr1.gotoAndPlay(1);
                btn_bgr1.setBeginLoopFrameNumber(1);
                btn_bgr1.setEndLoopFrameNumber(2);

                btn_bgr2.gotoAndPlay(1);
                btn_bgr2.setBeginLoopFrameNumber(1);
                btn_bgr2.setEndLoopFrameNumber(2);

                GamblerIsStart.pressed = false;
                getViewManager().findViewById(GAMBLER_SCREEN, "cardTextBgr").setVisible(false);
                GamblerIsStart.textShine = false;
            }
        }

        //Run the handler that determines whether to shining the text
        if (mainCard == null) {
            mainCard = getViewManager().findViewById(GAMBLER_SCREEN, MAIN_CARD_ID);
        } else shiningText();


        switch (getCurrentState()) {
            case SELECT_CARD:
                setModelProperty(RED_BUTTON_ENABLED, Boolean.TRUE);
                setModelProperty(BLACK_BUTTON_ENABLED, Boolean.TRUE);
                break;
            case SELECTED_BLACK_CARD:
                ButtonPressed = BUTTON_ID_BLACK;
                GamblerIsStart.pressed = true;
                setModelProperty(BLACK_BUTTON_SELECTED, Boolean.TRUE);
                btn_bgr2.gotoAndPause(4);//4 - Background of the pressed button
                btn_bgr1.gotoAndPause(3);//3 - Background of an inactive button
                break;
            case SELECTED_RED_CARD:
                ButtonPressed = BUTTON_ID_RED;
                GamblerIsStart.pressed = true;
                setModelProperty(RED_BUTTON_SELECTED, Boolean.TRUE);
                btn_bgr1.gotoAndPause(4);//4 - Background of the pressed button
                btn_bgr2.gotoAndPause(3);//3 - Background of an inactive button
                break;
            case LOSE:
                showLatestSelectedButton(false);
                break;
            case HISTORY_LOSE:
                showLatestSelectedButton(true);
                setModelProperty(MAIN_CARD_VISIBLE, Boolean.TRUE);
                break;
            case HISTORY_WIN:
                showLatestSelectedButton(false);
                setModelProperty(MAIN_CARD_VISIBLE, Boolean.TRUE);
                break;
            case HISTORY_SELECTED_CARD:
                break;
            default:
                getLogger().warn("Unsupported gambler state: %s", getCurrentState());
                break;
        }
    }

    @Override
    public void handleShowSelectedGamblerCardCommand(ShowSelectedGamblerCardCommand showSelectedGamblerCardCommand) {
        super.handleShowSelectedGamblerCardCommand(showSelectedGamblerCardCommand);

        AbstractGamblerCard mainCard = super.mainCard;
//        super.mainCard.setWidth(200);
//        super.mainCard.setHeight(400);
//        super.mainCard.setScaleX(1.45f);
//        super.mainCard.setScaleY(1.45f);
        setModelProperty(ANIMATION_CARD_VISIBLE, true);
        setModelProperty(MAIN_CARD_VISIBLE, Boolean.TRUE);
        if (getCurrentState() == GamblerScreenState.HISTORY_LOSE) {
            showLatestSelectedButton(true);
        } else if (getCurrentState() == GamblerScreenState.HISTORY_WIN) {
            showLatestSelectedButton(false);
        }
    }

    /**
     * Shows recently selected gambler button, based on history.
     *
     * @param oppositeColor a boolean value that indicates whether this color should be opposite or not
     */
    private void showLatestSelectedButton(boolean oppositeColor) {
        String lastSelectedCard = getLastSelectedCard();
        boolean redButtonSelected = true;
        if (GamblerCardType.SPADES.equals(lastSelectedCard) || GamblerCardType.CLUBS.equals(lastSelectedCard)) {
            redButtonSelected = oppositeColor;
        } else if (GamblerCardType.DIAMONDS.equals(lastSelectedCard) || GamblerCardType.HEARTS.equals(lastSelectedCard)) {
            redButtonSelected = !oppositeColor;
        }
        setModelProperty(BLACK_BUTTON_SELECTED, redButtonSelected ? Boolean.FALSE : Boolean.TRUE);
        setModelProperty(RED_BUTTON_SELECTED, redButtonSelected ? Boolean.TRUE : Boolean.FALSE);
    }

    /**
     * Track whether text should be
     */
    public void shiningText() {

        mainCard.addPropertyChangedListener(new IViewPropertyChangedListener() {
            @Override
            public void propertyChanged(View view, ViewType viewType, int i) {
                winCards = mainCard.getChildren();
                winCardsChildCount = mainCard.getChildCount();
                if (winCards != null && GamblerIsStart.pressed && winCardsChildCount == 2 && !GamblerIsStart.textShine) {
                    for (View winCard : winCards) {
                        String cardId = ((ImageView) winCard).getImage().getId();

                        if (
                                ((cardId.equals("cardShift.clubs") || cardId.equals("cardShift.spades")) && ButtonPressed.equals(BUTTON_ID_BLACK)) ||
                                        ((cardId.equals("cardShift.diamond") || cardId.equals("cardShift.heart")) && ButtonPressed.equals(BUTTON_ID_RED))
                                ) {
                            if (!GamblerIsStart.textShine) {
                                GamblerIsStart.textShine = true;
                                getViewManager().findViewById(GAMBLER_SCREEN, "cardTextBgr").setVisible(true);
                            }
                        }
                    }
                }
            }
        });
    }
}
