package com.atsisa.game.queencleopatra.screen;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Named;

import com.atsisa.game.queencleopatra.command.ShowInfoScreenWithOrderCommand;
import com.atsisa.game.queencleopatra.view.SidePanel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.animation.TweenViewAnimationData;
import com.atsisa.gox.framework.command.HideScreenCommand;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.framework.eventbus.annotation.Subscribe;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IResourceManager;
import com.atsisa.gox.framework.screen.annotation.ExposeMethod;
import com.atsisa.gox.framework.screen.event.ScreenShowingEvent;
import com.atsisa.gox.framework.screen.event.ScreenShownEvent;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.framework.serialization.IXmlSerializer;
import com.atsisa.gox.framework.utility.IMutator;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.FreeGamesPresentationStates;
import com.atsisa.gox.reels.ILinesModel;
import com.atsisa.gox.reels.ReelsPresentationStates;
import com.atsisa.gox.reels.command.ChangeDenominationCommand;
import com.atsisa.gox.reels.event.AutoPlayStartedEvent;
import com.atsisa.gox.reels.event.AutoPlayStoppedEvent;
import com.atsisa.gox.reels.event.BetModelChangedEvent;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.event.LinesModelChangedEvent;
import com.atsisa.gox.reels.event.MessageChangedEvent;
import com.atsisa.gox.reels.message.BasicMessageType;
import com.atsisa.gox.reels.model.IDenominationModelProvider;
import com.atsisa.gox.reels.model.IFreeGamesModel;
import com.atsisa.gox.reels.model.IFreeGamesModelProvider;
import com.atsisa.gox.reels.screen.BottomPanelScreen;
import com.atsisa.gox.reels.screen.InfoScreen;
import com.atsisa.gox.reels.screen.model.BottomPanelScreenModel;

/**
 * Implementation for AGI (WEB) bottom panel screen.
 */
public class QueenCleopatraAGIBottomPanelScreen extends BottomPanelScreen {

    /**
     * Name of the property which is responsible if increase bet button is enable or not.
     */
    private static final String BET_INCREASE_ENABLE = "betIncreaseEnable";

    /**
     * Name of the property which is responsible if bet button is visible or not.
     */
    private static final String DEBUG_BUTTON_VISIBLE = "debugButtonVisible";

    /**
     * Name of the property which is responsible if decrease bet button is enable or not.
     */
    private static final String BET_DECREASE_ENABLE = "betDecreaseEnable";

    /**
     * Name of the property which is responsible if enter into history button is visible or not.
     */
    private static final String HISTORY_VISIBLE = "historyVisible";

    /**
     * Name of the property which is responsible if auto play button is enable or not.
     */
    private static final String AUTO_PLAY_ENABLE = "autoPlayEnable";

    /**
     * Name of the property which is responsible if auto stop button is visible or not.
     */
    private static final String AUTO_STOP_VISIBLE = "autoStopVisible";

    /**
     * Name of the property which is responsible if spin button is enable or not.
     */
    private static final String SPIN_ENABLE = "spinEnable";

    /**
     * Name of the property which is responsible if skip button is visible or not.
     */
    private static final String SKIP_VISIBLE = "skipVisible";

    /**
     * Name of the property which is responsible if take button is visible or not.
     */
    private static final String TAKE_VISIBLE = "takeVisible";

    /**
     * Name of the property which is responsible if win text field is visible or not.
     */
    private static final String WIN_VISIBLE = "winVisible";

    /**
     * Name of the property which is responsible if info button is enable or not.
     */
    private static final String INFO_ENABLE = "infoEnable";

    /**
     * Name of the property which is responsible if increase lines button is enable or not.
     */
    private static final String LINES_INCREASE_ENABLE = "linesIncreaseEnable";

    /**
     * Name of the property which is responsible if decrease lines button is enable or not.
     */
    private static final String LINES_DECREASE_ENABLE = "linesDecreaseEnable";

    /**
     * Name of the property which is responsible if gamble button is visible or not.
     */
    private static final String GAMBLE_VISIBLE = "gambleVisible";

    /**
     * Name of the property which is responsible if select red card button is visible or not.
     */
    private static final String SELECT_RED_CARD_VISIBLE = "selectRedCardVisible";

    /**
     * Name of the property which is responsible if select black card button is visible or not.
     */
    private static final String SELECT_BLACK_CARD_VISIBLE = "selectBlackCardVisible";

    /**
     * Name of the property which is responsible if menu button is enable or not.
     */
    private static final String MENU_ENABLE = "menuEnable";

    /**
     * Name of the property which is responsible if menu list is visible or not.
     */
    private static final String MENU_VISIBLE = "menuVisible";

    /**
     * Name of the property which is responsible if menu list is visible or not.
     */
    private static final String INFO_SCREEN_VISIBLE = "infoScreenVisible";

    /**
     * Name of the property which is responsible if info screen is enable.
     */
    private static final String INFO_SCREEN_ENABLE = "infoScreenEnable";

    /**
     * Name of the property which is responsible if credit value is visible.
     */
    private static final String CREDIT_VISIBLE = "creditVisible";

    /**
     * Name of the property which is responsible if credit value is hidden.
     */
    private static final String CREDIT_HIDDEN = "creditHidden";

    /**
     * Name of the property which is responsible if credit value is hidden.
     */
    private static final String LARGE_BUTTONS_VISIBLE = "largeButtonsVisible";

    /**
     * Name of the property which is responsible if credit value is hidden.
     */
    private static final String MEDIUM_BUTTONS_VISIBLE = "mediumButtonsVisible";

    /**
     * Name of the property which is responsible if credit value is hidden.
     */
    private static final String DENOMINATION_VISIBLE = "denominationVisible";

    /**
     * Name of the property which is responsible if denomination value is enable.
     */
    private static final String DENOMINATION_ENABLE = "denominationEnable";

    /**
     * Name of the property which is responsible if button for selecting lines are visible or not.
     */
    private static final String LINES_BUTTONS_VISIBLE = "linesButtonsVisible";

    /**
     * Name of the property which is responsible if  additional buttons are active or not.
     */
    private static final String ACTIVE_BUTTONS_VISIBLE = "activeButtonsVisible";

    /**
     * Boolean value that indicates whether auto play is on or off.
     */
    private boolean isAutoPlay;

    /**
     * Current info screen id.
     */
    private int currentInfoScreenId = 0;

    /**
     * List of all infoscreens ids.
     */
    private List<String> infoScreensIds;

    /**
     * Command used to show and hide infoscreens.
     */
    private ShowInfoScreenWithOrderCommand showInfoScreenWithOrderCommand;

    /**
     * Animation data for showing info screen.
     */
    TweenViewAnimationData showInfoScreenAnimationData;

    /**
     * Denomination model provider.
     */
    private IDenominationModelProvider denominationModelProvider;

    /**
     * Reference to the {@link IFreeGamesModelProvider}.
     */
    private IFreeGamesModelProvider freeGamesModelProvider;

    /**
     * Initializes a new instance of the {@link QueenCleopatraAGIBottomPanelScreen} class.
     * @param layoutId                  layout identifier
     * @param bottomPanelScreenModel    {@link BottomPanelScreenModel}
     * @param renderer                  {@link IRenderer}
     * @param viewManager               {@link IViewManager}
     * @param animationFactory          {@link IAnimationFactory}
     * @param logger                    {@link ILogger}
     * @param eventBus                  {@link IEventBus}
     * @param linesModelMutator         {@link IMutator<ILinesModel>} the lines model mutator
     * @param resourceManager           {@link IResourceManager}
     * @param parser                    {@link IParser}
     * @param xmlSerializer             {@link IXmlSerializer}
     * @param freeGamesModelProvider    {@link IFreeGamesModelProvider}
     * @param denominationModelProvider {@link IDenominationModelProvider}
     */
    @Inject
    public QueenCleopatraAGIBottomPanelScreen(@Named(LAYOUT_ID_PROPERTY) String layoutId, BottomPanelScreenModel bottomPanelScreenModel, IRenderer renderer,
            IViewManager viewManager, IAnimationFactory animationFactory, ILogger logger, IEventBus eventBus, IMutator<ILinesModel> linesModelMutator,
            IResourceManager resourceManager, IParser parser, IXmlSerializer xmlSerializer, IFreeGamesModelProvider freeGamesModelProvider,
            IDenominationModelProvider denominationModelProvider) {
        super(layoutId, bottomPanelScreenModel, renderer, viewManager, animationFactory, logger, eventBus, linesModelMutator, resourceManager, parser,
                xmlSerializer);
        this.freeGamesModelProvider = freeGamesModelProvider;
        this.denominationModelProvider = denominationModelProvider;
    }

    @Override
    protected void registerEvents() {
        super.registerEvents();
        getEventBus().register(new ScreenShowingEventObserver(), ScreenShowingEvent.class);
        getEventBus().register(new AutoPlayStoppedEventObserver(), AutoPlayStoppedEvent.class);
        getEventBus().register(new AutoPlayStartedEventObserver(), AutoPlayStartedEvent.class);
        getEventBus().register(new ScreenShownEventObserver(), ScreenShownEvent.class);
        getEventBus().register(new FreeGamesModelChangedEventObserver(), FreeGamesModelChangedEvent.class);
    }

    @Override
    protected void afterActivated() {
        super.afterActivated();
        setModelProperty(CREDIT_VISIBLE, Boolean.TRUE);
        setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.FALSE);
        setModelProperty(CREDIT_HIDDEN, Boolean.FALSE);
        setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
        setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);

        infoScreensIds = new ArrayList<String>();
        infoScreensIds.add("featureInfoScreen");
        infoScreensIds.add("rulesInfoScreen");
        infoScreensIds.add("gamblerInfoScreen");
        infoScreensIds.add("rtpInfoScreen");

        showInfoScreenAnimationData = new TweenViewAnimationData();
        showInfoScreenAnimationData.setDestinationY(0F);
        showInfoScreenAnimationData.setTimeSpan(1000);
    }

    /**
     * Sets panels property for displaying min max values
     */
    private void setMinMaxPanelsproperty() {
        this.getModel().setProperty(SidePanel.MIN_LINE_VALUE, this.getLinesModel().getMinLines() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_LINE_VALUE, "MAX\n" + this.getLinesModel().getMaxLines());
        this.getModel().setProperty(SidePanel.MIN_BET_VALUE, this.getBetModel().getMinBet() + "\nMIN");
        this.getModel().setProperty(SidePanel.MAX_BET_VALUE, "MAX\n" + this.getBetModel().getMaxBet());
    }

    @Override
    protected void stateChanged() {
        super.stateChanged();
        hideAllButtons();
        switch (getCurrentState()) {
            case ReelsPresentationStates.IDLE:
                setModelProperty(SPIN_ENABLE, Boolean.TRUE);
                setModelProperty(MENU_ENABLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                setModelProperty(INFO_ENABLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(MENU_VISIBLE, Boolean.FALSE);
                setModelProperty(HISTORY_VISIBLE, Boolean.TRUE);
                setModelProperty(DEBUG_BUTTON_VISIBLE, Boolean.TRUE);
                setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
                setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
                setModelProperty(DENOMINATION_ENABLE, Boolean.TRUE);
                setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
                setMinMaxPanelsproperty();
                updateVisibleBetButtons();
                updateVisibleLineButtons();
                break;
            case ReelsPresentationStates.WIN_COUNTING:
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.STOPPING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.REELS_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_WIN_ANIMATION:
            case FreeGamesPresentationStates.FREE_GAMES_STOPPING_REELS:
            case FreeGamesPresentationStates.FREE_GAMES_RETRIGGER:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SKIP_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.OFFER_GAMBLER:
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                if (!isAutoPlay) {
                    setModelProperty(GAMBLE_VISIBLE, Boolean.TRUE);
                }
                break;
            case ReelsPresentationStates.GAMBLER_LOSE:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.GAMBLER_WIN:
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.GAMBLER:
                setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
                setModelProperty(TAKE_VISIBLE, Boolean.TRUE);
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.TRUE);
                setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.TRUE);
                break;
            case ReelsPresentationStates.HISTORY:
                setModelProperty(WIN_VISIBLE, Boolean.FALSE);
                break;
            case ReelsPresentationStates.HISTORY_WIN:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                break;
            case FreeGamesPresentationStates.FREE_GAMES_RUNNING_REELS:
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            case FreeGamesPresentationStates.FREE_GAMES_HISTORY:
                updateFreeGamesWin(freeGamesModelProvider.getModel());
                setModelProperty(WIN_VISIBLE, Boolean.TRUE);
                getCurrentWinController().clearWinLineInfo();
                break;
            default:
                break;
        }
    }

    /**
     * Shows next info screen.
     */
    @ExposeMethod
    public void showNextInfoScreen() {
        currentInfoScreenId++;
        if (currentInfoScreenId == infoScreensIds.size()) {
            currentInfoScreenId = 0;
        }
        showCurrentInfoScreen();
    }

    /**
     * Shows previous info screen.
     */
    @ExposeMethod
    public void showPreviousInfoScreen() {
        currentInfoScreenId--;
        if (currentInfoScreenId < 0) {
            currentInfoScreenId = infoScreensIds.size() - 1;
        }
        showCurrentInfoScreen();
    }

    /**
     * Shows current info screen.
     */
    private void showCurrentInfoScreen() {
        showInfoScreenWithOrderCommand = new ShowInfoScreenWithOrderCommand("infoScreen", showInfoScreenAnimationData);
        showInfoScreenWithOrderCommand.setViewId(infoScreensIds.get(currentInfoScreenId));
        showInfoScreenWithOrderCommand.setInfoScreenOrder(currentInfoScreenId + 1);
        showInfoScreenWithOrderCommand.setInfoScreensAmount(infoScreensIds.size());
        setModelProperty(INFO_SCREEN_ENABLE, Boolean.FALSE);
        getEventBus().post(showInfoScreenWithOrderCommand);
    }

    /**
     * Handles the visibly of credit value.
     */
    @ExposeMethod
    public void toggleCreditsView() {
        if (getProperty(CREDIT_VISIBLE).equals(true)) {
            setModelProperty(CREDIT_VISIBLE, Boolean.FALSE);
            setModelProperty(CREDIT_HIDDEN, Boolean.TRUE);
        } else {
            setModelProperty(CREDIT_VISIBLE, Boolean.TRUE);
            setModelProperty(CREDIT_HIDDEN, Boolean.FALSE);
        }
    }

    /**
     * Handles the visibly of credit value.
     */
    @ExposeMethod
    public void toggleActiveButtonsView() {
        if (getProperty(ACTIVE_BUTTONS_VISIBLE).equals(true)) {
            setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.FALSE);
        } else {
            setModelProperty(ACTIVE_BUTTONS_VISIBLE, Boolean.TRUE);

        }
    }

    /**
     * Handles the visibly of info screen.
     */
    @ExposeMethod
    public void toggleInfoScreen() {
        if (getProperty(INFO_SCREEN_VISIBLE).equals(true)) {
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
            currentInfoScreenId = 0;
            getEventBus().post(new HideScreenCommand("infoScreen", null));
        } else {
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.TRUE);
            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
            showCurrentInfoScreen();
        }
    }

    /**
     * Handles the visibly of menu view.
     */
    @ExposeMethod
    public void toggleMenuView() {
        if (getProperty(MENU_VISIBLE).equals(true)) {
            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.TRUE);
        } else {
            setModelProperty(MENU_VISIBLE, Boolean.TRUE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
            setModelProperty(LINES_BUTTONS_VISIBLE, Boolean.FALSE);
        }
    }

    /**
     * Handles visibility of the denomination view.
     */
    @ExposeMethod
    public void toggleDenominationView() {
        if (getProperty(DENOMINATION_VISIBLE).equals(true)) {
            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);

        } else {
            setModelProperty(DENOMINATION_VISIBLE, Boolean.TRUE);
            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.FALSE);
            setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.TRUE);
            setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
        }
    }

    @ExposeMethod
    @Override
    public void spin() {
        super.spin();
        setModelProperty(LARGE_BUTTONS_VISIBLE, Boolean.TRUE);
        setModelProperty(MEDIUM_BUTTONS_VISIBLE, Boolean.FALSE);
        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setModelProperty(INFO_SCREEN_VISIBLE, Boolean.FALSE);
    }

    /**
     * Changes the denomination
     * @param index the denomination step index.
     */
    @ExposeMethod
    public void changeDenomination(int index) {
        BigDecimal denomination = denominationModelProvider.getModel().getDenominationStep(index);
        getEventBus().post(new ChangeDenominationCommand(denomination));
    }

    /**
     * Updates visible bet buttons.
     */
    private void updateVisibleBetButtons() {
        if (getBetModel() == null) {
            return;
        }
        setModelProperty(BET_INCREASE_ENABLE, getBetModel().getBetPerLine() < (getBetModel().getMaxBet()));
        setModelProperty(BET_DECREASE_ENABLE, getBetModel().getBetPerLine() > (getBetModel().getMinBet()));
    }

    /**
     * Updates visible line buttons.
     */
    private void updateVisibleLineButtons() {
        if (getLinesModel() == null) {
            return;
        }
        setModelProperty(LINES_DECREASE_ENABLE, getLinesModel().getSelectedLines() > getLinesModel().getMinLines());
        setModelProperty(LINES_INCREASE_ENABLE, getLinesModel().getSelectedLines() < getLinesModel().getMaxLines());
    }

    @Subscribe
    @Override
    public void handleMessageChangedEvent(MessageChangedEvent messageChangedEvent) {
        if (BasicMessageType.BOTTOM_PANEL.equals(messageChangedEvent.getMessage().getMessageType())) {
            String message = messageChangedEvent.getMessage().getContent().replace("\n", "- ").replace("\r", "- ");
            getModel().setMessage(message);
        }
    }

    /**
     * Reacts to start the info screen transition.
     * @param screenShowingEvent screen showing event
     */
    @Subscribe
    public void handleScreenShowingEvent(ScreenShowingEvent screenShowingEvent) {
        if (screenShowingEvent.getScreen() instanceof InfoScreen) {
            hideAllButtons();
        }
    }

    @Override
    @Subscribe
    public void handleBetModelChangedEvent(BetModelChangedEvent betModelChangedEvent) {
        super.handleBetModelChangedEvent(betModelChangedEvent);
        updateVisibleBetButtons();
    }

    @Override
    @Subscribe
    public void handleLinesModelChangedEvent(LinesModelChangedEvent linesModelChangedEvent) {
        super.handleLinesModelChangedEvent(linesModelChangedEvent);
        String state = getCurrentState();
        if (state != null && state.equals(ReelsPresentationStates.IDLE)) {
            updateVisibleLineButtons();
        }
    }

    /**
     * Reacts to finish the info screen transition.
     * @param screenShownEvent screen shown event
     */
    @Subscribe
    public void handleScreenShownEvent(ScreenShownEvent screenShownEvent) {
        if (screenShownEvent.getScreen() instanceof InfoScreen && getCurrentState().equals(ReelsPresentationStates.IDLE)) {
            setModelProperty(INFO_ENABLE, Boolean.TRUE);
            setModelProperty(SPIN_ENABLE, Boolean.TRUE);
            setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
            setModelProperty(MENU_ENABLE, Boolean.TRUE);
            setModelProperty(BET_DECREASE_ENABLE, Boolean.TRUE);
            setModelProperty(BET_INCREASE_ENABLE, Boolean.TRUE);
            setModelProperty(MENU_VISIBLE, Boolean.FALSE);
            setModelProperty(HISTORY_VISIBLE, Boolean.TRUE);
            setModelProperty(INFO_SCREEN_ENABLE, Boolean.TRUE);
            setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
            setModelProperty(DENOMINATION_ENABLE, Boolean.TRUE);
            updateVisibleBetButtons();
            updateVisibleLineButtons();
        }
    }

    /**
     * Hides all buttons.
     */
    private void hideAllButtons() {
        setModelProperty(DEBUG_BUTTON_VISIBLE, Boolean.FALSE);
        setModelProperty(SKIP_VISIBLE, Boolean.FALSE);
        setModelProperty(SPIN_ENABLE, Boolean.FALSE);
        setModelProperty(TAKE_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(MENU_ENABLE, Boolean.FALSE);
        setModelProperty(MENU_VISIBLE, Boolean.FALSE);
        setModelProperty(DENOMINATION_VISIBLE, Boolean.FALSE);
        setModelProperty(DENOMINATION_ENABLE, Boolean.FALSE);
        setModelProperty(BET_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(GAMBLE_VISIBLE, Boolean.FALSE);
        setModelProperty(SELECT_BLACK_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(BET_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(SELECT_RED_CARD_VISIBLE, Boolean.FALSE);
        setModelProperty(INFO_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_DECREASE_ENABLE, Boolean.FALSE);
        setModelProperty(LINES_INCREASE_ENABLE, Boolean.FALSE);
        setModelProperty(HISTORY_VISIBLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, isAutoPlay);
    }

    /**
     * Handles event about that auto play was started.
     * @param autoPlayStartedEvent {@link AutoPlayStartedEvent}
     */
    @Subscribe
    public void handleAutoPlayStartedEvent(AutoPlayStartedEvent autoPlayStartedEvent) {
        isAutoPlay = true;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.FALSE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.TRUE);
    }

    /**
     * Handles the free games model changed event.
     * @param freeGamesModelChangedEvent {@link FreeGamesModelChangedEvent}
     */
    @Subscribe
    public void handleFreeGamesModelChangedEvent(FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
        updateFreeGamesWin(freeGamesModelChangedEvent.getFreeGamesModel());
    }

    /**
     * Updates the win based on the current win in free games.
     * @param freeGamesModel {@link IFreeGamesModel}
     */
    private void updateFreeGamesWin(IFreeGamesModel freeGamesModel) {
        if (freeGamesModel == null) {
            return;
        }
        long winAmount = freeGamesModel.getTotalWinAmount();
        long currentGameWinAmount = freeGamesModel.getCurrentGameWinAmount();
        if (freeGamesModel.getCurrentFreeGameNumber() > 0) {
            getCurrentWinController().setCurrentWin(winAmount - currentGameWinAmount);
            updateProperties();
        }
    }

    /**
     * Handles event about that auto play was stopped.
     * @param autoPlayStoppedEvent {@link AutoPlayStoppedEvent}
     */
    @Subscribe
    public void handleAutoPlayStoppedEvent(AutoPlayStoppedEvent autoPlayStoppedEvent) {
        isAutoPlay = false;
        setModelProperty(AUTO_PLAY_ENABLE, Boolean.TRUE);
        setModelProperty(AUTO_STOP_VISIBLE, Boolean.FALSE);
    }

    /**
     * Updated balance display when denomination changes.
     */
    @Subscribe
    private void handleDenominationResult() {
        updateCredits();
    }

    private class ScreenShowingEventObserver extends NextObserver<ScreenShowingEvent> {

        @Override
        public void onNext(final ScreenShowingEvent screenShowingEvent) {
            handleScreenShowingEvent(screenShowingEvent);
        }
    }

    private class AutoPlayStoppedEventObserver extends NextObserver<AutoPlayStoppedEvent> {

        @Override
        public void onNext(final AutoPlayStoppedEvent autoPlayStoppedEvent) {
            handleAutoPlayStoppedEvent(autoPlayStoppedEvent);
        }
    }

    private class AutoPlayStartedEventObserver extends NextObserver<AutoPlayStartedEvent> {

        @Override
        public void onNext(final AutoPlayStartedEvent autoPlayStartedEvent) {
            handleAutoPlayStartedEvent(autoPlayStartedEvent);
        }
    }

    private class ScreenShownEventObserver extends NextObserver<ScreenShownEvent> {

        @Override
        public void onNext(final ScreenShownEvent screenShownEvent) {
            handleScreenShownEvent(screenShownEvent);
        }
    }

    private class FreeGamesModelChangedEventObserver extends NextObserver<FreeGamesModelChangedEvent> {

        @Override
        public void onNext(final FreeGamesModelChangedEvent freeGamesModelChangedEvent) {
            handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);
        }
    }
}