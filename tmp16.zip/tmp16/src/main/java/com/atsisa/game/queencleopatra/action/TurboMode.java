package com.atsisa.game.queencleopatra.action;

import com.atsisa.game.queencleopatra.gameobjects.staticClasses.GamblerIsStart;
import com.atsisa.game.queencleopatra.screen.QueenCleopatraOctavianBottomPanelScreen;
import com.atsisa.game.queencleopatra.screen.QueenCleopatraVipLoungeBottomPanelScreen;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.reels.view.ReelGroupView;

public class TurboMode extends Action {
    private static String GAMBLE_SCREEN_LAYOUT = "gamblerScreen";
    private static String MAIN_CARD_ID = "cardTextBgr";
    private static ReelGroupView reelGroupView=GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
    private static boolean speedUp = false;

    @Override
    protected void execute() {
        speedUp = false;
        if (GamblerIsStart.gamblerIsStart) {//reset the flag of the launch of the card game and shine text
            GamblerIsStart.gamblerIsStart = false;
            GamblerIsStart.pressed = false;
            GamblerIsStart.textShine = false;
            GameEngine.current().getViewManager().findViewById(GAMBLE_SCREEN_LAYOUT, MAIN_CARD_ID).setVisible(false);
        }
        turboMode();
        finish();
    }

    /**
     * for turbo autoplay
     */
    private void turboMode(){
        if(reelGroupView==null){
            reelGroupView = GameEngine.current().getViewManager().findViewById("baseGameScreen", "reelGroupView");
        }
        if ((QueenCleopatraVipLoungeBottomPanelScreen.turboMode && reelGroupView != null)||(QueenCleopatraOctavianBottomPanelScreen.turboMode && reelGroupView != null)) {

            if (!speedUp) {
                new Timeout(50, new TimeoutCallback() {
                    @Override
                    public void onTimeout() {
                        if (!speedUp) {
                            speedUp = true;
                            try {
                                for (int i = 0; i < 5; i++) {
                                    if (reelGroupView.getReel(i).getReelAnimation() != null)
                                        reelGroupView.getReel(i).getReelAnimation().speedUp();
                                }
                            } catch (Exception e) {

                            }

                        }
                    }
                }, true).start();
            }


            if (reelGroupView.getReel(4).getReelAnimation().isStopped() && speedUp) {
                speedUp = false;
            }
        }
    }
}
