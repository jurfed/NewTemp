package com.atsisa.game.queencleopatra;

import java.util.Set;
import javax.inject.Inject;

import com.atsisa.game.queencleopatra.customviews.CustomViewModule;
import com.atsisa.game.queencleopatra.screen.BigWinScreen;
import com.atsisa.game.queencleopatra.screen.SampleScreen;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.reels.AbstractReelGameComponent;
import com.atsisa.gox.reels.DebugAbstractReelGame;

public class QueenCleopatra extends DebugAbstractReelGame {

    /**
     * Initializes a new instance of the {@link QueenCleopatra} class.     *
     * @param reelGameComponents reel game components
     */
    @Inject
    public QueenCleopatra(Set<AbstractReelGameComponent> reelGameComponents) {
        super(reelGameComponents);
    }

    @Override
    public void onStart() {
        IViewManager viewManager = GameEngine.current().getViewManager();

        viewManager.addLayout("reel_bg_ground");
        viewManager.addLayout("bgrScreen");
        viewManager.addLayout("payTableScreen");
//        viewManager.addLayout("Line1Screen");
//        viewManager.addLayout("Line2Screen");
//        viewManager.addLayout("Line3Screen");
//        viewManager.addLayout("Line4Screen");
//        viewManager.addLayout("Line5Screen");
//        new WinLinesListenerStart().initTimer();
    }

    @Override
    public void onReady() {
        IViewManager viewManager = GameEngine.current().getViewManager();
        viewManager.addLayout("reel_bg");

        viewManager.addLayout("reel_bg_freegame");



        viewManager.addLayout("baseGameScreen");
//        viewManager.addLayout("winLinesScreen");
        viewManager.addLayout("wonPanelScreen");


        //Register and initialize the screen
        BigWinScreen bigWinScreen = new BigWinScreen();
        GameEngine.current().getViewManager().registerScreen(bigWinScreen);
        bigWinScreen.initialize();
        //Activate the layout
        GameEngine.current().getViewManager().getScreenById("BigWinScreen").show();

        viewManager.addLayout("payTableBgrScreen");
        viewManager.getViewBuilder().registerModule(new CustomViewModule());


        //Register and initialize the screen
        SampleScreen screen = new SampleScreen();
        GameEngine.current().getViewManager().registerScreen(screen);
        screen.initialize();
        //Activate the layout
        GameEngine.current().getViewManager().getScreenById("sample").show();



    }
}
