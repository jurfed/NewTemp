package com.atsisa.game.queencleopatra.screen.model;

import com.atsisa.gox.framework.screen.model.ScreenModel;

public class BigWinScreenModel extends ScreenModel {
}
