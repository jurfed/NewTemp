package com.atsisa.game.queencleopatra.command;

import com.gwtent.reflection.client.Reflectable;

/**
 * A command to select feature special scatter symbol
 */
@Reflectable
public class ShowSelectedExtendedSymbolCommand {

}
