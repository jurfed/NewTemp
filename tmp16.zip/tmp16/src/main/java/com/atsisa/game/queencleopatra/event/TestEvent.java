package com.atsisa.game.queencleopatra.event;

public class TestEvent {
}
