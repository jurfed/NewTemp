package com.atsisa.game.queencleopatra.logic.vocs;

import java.util.Set;

import javax.inject.Inject;

import com.atsisa.gox.framework.IPlatform;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.net.HttpMethod;
import com.atsisa.gox.framework.net.INetwork;
import com.atsisa.gox.framework.serialization.IParser;
import com.atsisa.gox.reels.logic.IExtendedSymbolGameLogic;
import com.atsisa.gox.reels.logic.IFreeGamesGameLogic;
import com.atsisa.gox.reels.logic.presentation.LogicPresentation;
import com.atsisa.gox.reels.logic.request.NextFreeGameRequest;
import com.atsisa.gox.reels.logic.request.SelectExtendedSymbolRequest;
import com.atsisa.gox.reels.logic.vocs.GameLogic;
import com.atsisa.gox.reels.logic.vocs.serialization.request.NextFreeGameRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.request.SelectExtendedSymbolRequestSerializer;
import com.atsisa.gox.reels.logic.vocs.serialization.response.IResponseSerializationStrategy;

import rx.Observable;

/**
 * Represents a game logic for book of ra deluxe.
 */
public class QueenCleopatraGameLogic extends GameLogic implements IExtendedSymbolGameLogic, IFreeGamesGameLogic {

    /**
     * Initializes a new instance of the {@link QueenCleopatraGameLogic} class.
     * @param xmlParser               {@link IParser}
     * @param network                 {@link INetwork}
     * @param configurationProvider   {@link IConfigurationProvider}
     * @param presentationSerializers the presentation serializers
     * @param platform                {@link IPlatform}
     */
    @Inject
    public QueenCleopatraGameLogic(IParser xmlParser, INetwork network, IConfigurationProvider configurationProvider,
                                   Set<IResponseSerializationStrategy> presentationSerializers, IPlatform platform) {
        super(xmlParser, network, configurationProvider, presentationSerializers, platform);
        registerDefaultRequestSerializers();
    }

    /**
     * Registers the default request serializers.
     */
    protected void registerDefaultRequestSerializers() {
        registerRequestSerializer(NextFreeGameRequest.class, new NextFreeGameRequestSerializer());
        registerRequestSerializer(SelectExtendedSymbolRequest.class, new SelectExtendedSymbolRequestSerializer());
    }

    @Override
    public Observable<LogicPresentation> nextFreeGame() {
        NextFreeGameRequest request = new NextFreeGameRequest();
        return sendLogicRequest(request, getProcessGameUri(request), HttpMethod.POST, headers);
    }

    @Override
    public Observable<LogicPresentation> selectExtendedSymbol() {
        SelectExtendedSymbolRequest request = new SelectExtendedSymbolRequest();
        return sendLogicRequest(request, getProcessGameUri(request), HttpMethod.POST, headers);
    }
}
