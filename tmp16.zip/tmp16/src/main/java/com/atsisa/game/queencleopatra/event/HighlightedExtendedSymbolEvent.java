package com.atsisa.game.queencleopatra.event;

import com.atsisa.gox.framework.event.AbstractEvent;
import com.gwtent.reflection.client.Reflectable;

/**
 * An event triggered when extended symbol was highlighted
 */
@Reflectable
public final class HighlightedExtendedSymbolEvent extends AbstractEvent {
}
