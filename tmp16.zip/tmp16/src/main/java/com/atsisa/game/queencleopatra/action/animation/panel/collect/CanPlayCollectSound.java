package com.atsisa.game.queencleopatra.action.animation.panel.collect;

import com.atsisa.game.queencleopatra.action.bigWin.ShowBigWin;
import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.framework.view.TextView;
import com.atsisa.gox.reels.AbstractReelGame;

public class CanPlayCollectSound extends ExecuteNextAction {
    private long totalAmount = 0L;
    BottomPanelHelper bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
    TextView winIndicatortext = bottomPanelHelper.getIndicatorTextID1();

    @Override
    protected void execute() {
        allowFurtherProcessing();

        totalAmount = ((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount();
        if (totalAmount > 0.01 && Integer.parseInt(winIndicatortext.getText()) < (totalAmount /*+ bottomPanelHelper.getIndicatorSum()*/)) {
            finish();
        } else {
            cancelFurtherProcessing();
            try {
                super.execute();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
