package com.atsisa.game.queencleopatra.gameobjects.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration of the identifiers of the symple symbols, which are specified in the payTableBgrScreen.xml
 */
public enum LiveGlassFramesId {
//
frame_upper_left(0), frame_bottom_right(1),frame_bottom_left(2),frame_middle_left(3), frame_middle_right(4), frame_upper_right(5);

    public static String[] getSyblosNames() {
        return Arrays.toString(LiveGlassFramesId.values()).replaceAll("^.|.$", "").split(", ");
    }

    private static final Map<Integer,LiveGlassFramesId> lookup
            = new HashMap<Integer,LiveGlassFramesId>();

    static {
        for(LiveGlassFramesId w : EnumSet.allOf(LiveGlassFramesId.class))
            lookup.put(w.getCode(), w);
    }

    private int code;

    private LiveGlassFramesId(int code) {
        this.code = code;
    }

    public int getCode() { return code; }

    public static LiveGlassFramesId get(int code) {
        return lookup.get(code);
    }
}