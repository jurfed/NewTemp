package com.atsisa.game.queencleopatra.screen;

import com.atsisa.game.queencleopatra.screen.model.BigWinScreenModel;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.screen.annotation.InjectView;
import com.atsisa.gox.framework.view.ImageView;
import com.atsisa.gox.framework.view.TextView;
import com.gwtent.reflection.client.Reflectable;

@Reflectable
public class BigWinScreen  extends Screen<BigWinScreenModel> {
    @InjectView
    public ImageView image1;

    @InjectView
    public TextView text1;


    public BigWinScreen() {
        super("BigWinScreen", new BigWinScreenModel());
    }

    @Override
    protected void beforeActivated() {
        getLogger().debug("beforeActivated");
    }

    @Override
    protected void afterActivated() {
        getLogger().debug("afterActivated");
        this.getModel().setProperty("bigwintext1","MEGA SUPER BIG WIN");
    }

    @Override
    protected void beforeDeactivated() {
        getLogger().debug("beforeDeactivated");
    }

    @Override
    protected void afterDeactivated() {
        getLogger().debug("afterDeactivated");
    }
}
