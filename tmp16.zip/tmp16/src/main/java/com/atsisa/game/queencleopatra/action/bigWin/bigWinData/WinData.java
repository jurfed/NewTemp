package com.atsisa.game.queencleopatra.action.bigWin.bigWinData;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("WINDATA")
public class WinData {

    @XStreamAlias("COLLECT")
    public Float COLLECT;

    @XStreamImplicit(itemFieldName = "OBJECT")
    public List objects = new ArrayList();

    public List getObjects() {
        return objects;
    }
}

