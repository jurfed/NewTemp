package com.atsisa.game.queencleopatra.action.bigWin;

import com.atsisa.game.queencleopatra.helpers.BottomPanelHelper;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.screen.Screen;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;

/**
 * Class for set pause after the skip Big Win Animation
 */
public class PauseAfterSkip extends Action/*<PauseAfterSkipActionData>*/ {

    private boolean end = false;
    private static Screen screen;

    private static int monitors;

    public static boolean isSkip = false;

    private BottomPanelHelper bottomPanelHelper;

    @Override
    protected void execute() {
        end = false;

        if (bottomPanelHelper == null) {
            bottomPanelHelper = ShowBigWin.getBottomPanelHelper();
        }


        if (isSkip) {
            isSkip = false;
            new Timeout(1600, new PauseTime(), true).start();
            bottomPanelHelper.setSkipEnable(false);
        } else {
            isSkip = false;
            finish();
        }
    }

    class PauseTime implements TimeoutCallback {

        @Override
        public void onTimeout() {

            if(!end){
                end=true;
                bottomPanelHelper.setSkipEnable(true);
                finish();
            }

        }
    }

    @Override
    protected void terminate() {
        end=true;
        bottomPanelHelper.setSkipEnable(true);
    }
}
