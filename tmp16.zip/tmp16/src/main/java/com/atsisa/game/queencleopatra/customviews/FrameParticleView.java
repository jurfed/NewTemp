package com.atsisa.game.queencleopatra.customviews;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.model.property.IObservableProperty;
import com.atsisa.gox.framework.model.property.ViewProperty;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.resource.IImageReference;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.atsisa.gox.framework.serialization.converter.DynamicClassConverter;
import com.atsisa.gox.framework.serialization.converter.HexColorConverter;
import com.atsisa.gox.framework.serialization.converter.ResourceRefConverter;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.framework.view.spi.IParticleSpawnType;
import com.gwtent.reflection.client.Reflectable;


/**
 * Represents a particles on the stage.
 */
@Reflectable
@XmlElement
public class FrameParticleView extends ParticleView {

    /**
     * Image resource reference.
     */
    @XmlAttribute(type = IImageReference.class, converters = ResourceRefConverter.class)
    private final ViewProperty<IImageReference> imageResource = new ViewProperty<>(IImageReference.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.IMAGE);

    /**
     * The ending speed of the particles.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> endingSpeed = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.ENDING_SPEED, 100);

    /**
     * The particle spawning type.
     */
    @XmlElement(converters = DynamicClassConverter.class)
    private final ViewProperty<IParticleSpawnType> spawnType = new ViewProperty<>(IParticleSpawnType.class, this, ViewType.PARTICLE_VIEW,
            ViewPropertyName.SPAWN_TYPE, new PointParticleSpawnType());

    /**
     * The starting speed of the particles.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> startingSpeed = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.STARTING_SPEED, 100);

    /**
     * The maximum rotation value in degrees per seconds that particle rotate.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> maxRotationSpeed = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.MAX_ROTATION_SPEED,
            0);

    /**
     * The minimum rotation value in degrees per seconds that particle rotate.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> minRotationSpeed = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.MIN_ROTATION_SPEED,
            0);

    /**
     * The maximum angle value at which particles are pointed when emitted.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> maxAngle = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.MAX_ANGLE, 0);

    /**
     * The minimum angle value at which particles are pointed when emitted.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> minAngle = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.MIN_ANGLE, 0);

    /**
     * The maximum lifetime value for a single particle in seconds.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> maxParticleLifetime = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW,
            ViewPropertyName.MAX_PARTICLE_LIFETIME, 1F);

    /**
     * The minimum lifetime value for a single particle in seconds.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> minParticleLifetime = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW,
            ViewPropertyName.MIN_PARTICLE_LIFETIME, 1F);

    /**
     * The end scale value for particle elements.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> endScale = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.END_SCALE, 1F);

    /**
     * The start scale value for particle elements.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> startScale = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.START_SCALE, 1F);

    /**
     * The end color value for particle elements.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> endColor = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.END_COLOR, 0xFFFFFF);

    /**
     * The start color value for particle elements.
     */
    @XmlAttribute(type = Integer.class, converters = HexColorConverter.class)
    private final ViewProperty<Integer> startColor = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.START_COLOR, 0xFFFFFF);

    /**
     * The end alpha value for particle elements.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> endAlpha = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.END_ALPHA, 1F);

    /**
     * The start alpha value for particle elements.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> startAlpha = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.START_ALPHA, 1F);

    /**
     * The y offset value where particles will be spawn.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> yOffset = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.OFFSET_Y, 0F);

    /**
     * Max number of particles.
     */
    @XmlAttribute(type = Integer.class)
    private final ViewProperty<Integer> maxParticles = new ViewProperty<>(Integer.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.MAX_PARTICLES, 10);

    /**
     * Number of particles generated per second.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> particlesPerSecond = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.PARTICLES_PER_SEC,
            1F);

    /**
     * The x offset value where particles will be spawning.
     */
    @XmlAttribute(type = Float.class)
    private final ViewProperty<Float> xOffset = new ViewProperty<>(Float.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.OFFSET_X, 0F);

    /**
     * Current particle state.
     */
    @XmlAttribute(type = State.class)
    private final ViewProperty<State> state = new ViewProperty<>(State.class, this, ViewType.PARTICLE_VIEW, ViewPropertyName.STATE, State.STOPPED);

    /**
     * Reference to the {@link ILogger} implementation.
     */
    private ILogger logger;

    /**
     * Initializes a new instance of the {@link FrameParticleView} class.
     */
    public FrameParticleView() {
        super();
        this.logger = GameEngine.current().getLogger();
    }

    /**
     * Initializes a new instance of the {@link FrameParticleView} class.
     * @param renderer {@link IRenderer}
     * @param logger   {@link ILogger}
     */
    public FrameParticleView(IRenderer renderer, ILogger logger) {
        super(renderer,logger);
        this.logger = logger;
    }

    /**
     * Sets the image resource for a single particle.
     * @param image image resource for a single particle
     */
    public void setImageResource(IImageReference image) {
        imageResource.set(image);
    }

    /**
     * Gets the image resource for a single particle.
     * @return image resource for a single particle
     */
    public IImageReference getImageResource() {
        return imageResource.get();
    }

    /**
     * Gets the image resource property.
     * @return the image resource property
     */
    public IObservableProperty<IImageReference> imageResource() {
        return imageResource;
    }

    /**
     * Sets the maximal amount of produced particles.
     * @param maxParticles maximal amount of produced particles
     */
    public void setMaxParticles(Integer maxParticles) {
        this.maxParticles.set(maxParticles);
    }

    /**
     * Gets the maximal amount of produced particles.
     * @return maximal amount of produced particles
     */
    public int getMaxParticles() {
        return maxParticles.get();
    }

    /**
     * Gets the max particles property.
     * @return the max particles property
     */
    public IObservableProperty<Integer> maxParticles() {
        return maxParticles;
    }

    /**
     * Gets the amount of particles generated per second.
     * @return amount of particles generated per second
     */
    public float getParticlesPerSecond() {
        return particlesPerSecond.get();
    }

    /**
     * Sets the amount of particles generated per second.
     * @param particlesPerSecond amount of particles generated per second
     */
    public void setParticlesPerSecond(float particlesPerSecond) {
        this.particlesPerSecond.set(particlesPerSecond);
    }

    /**
     * Gets the particles per second property.
     * @return the particles per second property
     */
    public IObservableProperty<Float> particlesPerSecond() {
        return particlesPerSecond;
    }

    /**
     * Gets the x offset property.
     * @return the x offset property
     */
    public ViewProperty<Float> xOffset() {
        return xOffset;
    }

    /**
     * Gets the x offset where particles will be spawning.
     * @return the x offset where particles will be spawning
     */
    public float getXOffset() {
        return xOffset.get();
    }

    /**
     * Sets the x offset where particles will be spawning.
     * @param xOffset the x offset where particles will be spawning
     */
    public void setXOffset(float xOffset) {
        this.xOffset.set(xOffset);
    }

    /**
     * Gets the y offset property.
     * @return the x offset property
     */
    public ViewProperty<Float> yOffset() {
        return yOffset;
    }

    /**
     * Gets the y offset where particles will be spawning.
     * @return the y offset where particles will be spawning
     */
    public float getYOffset() {
        return yOffset.get();
    }

    /**
     * Sets the y offset where particles will be spawning.
     * @param yOffset the y offset where particles will be spawning
     */
    public void setYOffset(float yOffset) {
        this.yOffset.set(yOffset);
    }

    @Override
    public View setOriginX(float value) {
        logger.warn("FrameParticleView | setOriginX | the origin x property is not supported in particle view, use setXOffset method instead.");
        return this;
    }

    @Override
    public View setOriginY(float value) {
        logger.warn("FrameParticleView | setOriginY | the origin y property is not supported in particle view, use setYOffset method instead.");
        return this;
    }

    @Override
    public View setRotation(float value) {
        logger.warn(
                "FrameParticleView | setRotation | the rotation property is not supported in particle view, use setMaxRotationSpeed and setMinRotationSpeed methods instead.");
        return this;
    }

    @Override
    public View setWidth(float value) {
        logger.warn("FrameParticleView | setWidth | the width property is not supported in particle view, use setSpawnType method instead with the right type.");
        return this;
    }

    @Override
    public View setScaleX(float value) {
        logger.warn("FrameParticleView | setScaleX | the scale x property is not supported in particle view, use setEndScale and setStartScale method instead.");
        return this;
    }

    @Override
    public View setScaleY(float value) {
        logger.warn("FrameParticleView | setScaleY | the scale y property is not supported in particle view, use setEndScale and setStartScale method instead.");
        return this;
    }

    @Override
    public View setHeight(float value) {
        logger.warn("FrameParticleView | setHeight | the height property is not supported in particle view, use setSpawnType method instead with the right type.");
        return this;
    }

    /**
     * Gets the start alpha property.
     * @return the start alpha property
     */
    public ViewProperty<Float> startAlpha() {
        return startAlpha;
    }

    /**
     * Gets the start alpha value for particles.
     * @return the start alpha value for particles
     */
    public float getStartAlpha() {
        return startAlpha.get();
    }

    /**
     * Sets the start alpha value for particles.
     * @param startAlpha the start alpha value for particles
     */
    public void setStartAlpha(float startAlpha) {
        this.startAlpha.set(startAlpha);
    }

    /**
     * Gets the end alpha property.
     * @return the end alpha property
     */
    public ViewProperty<Float> endAlpha() {
        return endAlpha;
    }

    /**
     * Gets the end alpha value for particles.
     * @return the end alpha value for particles
     */
    public float getEndAlpha() {
        return endAlpha.get();
    }

    /**
     * Sets the end alpha value for particles.
     * @param endAlpha the end alpha value for particles
     */
    public void setEndAlpha(float endAlpha) {
        this.endAlpha.set(endAlpha);
    }

    /**
     * Gets the start color property.
     * @return the start color property
     */
    public ViewProperty<Integer> startColor() {
        return startColor;
    }

    /**
     * Gets the start color value for particles.
     * @return the start color value for particles
     */
    public int getStartColor() {
        return startColor.get();
    }

    /**
     * Sets the start color value for particles.
     * @param startColor the start color value for particles
     */
    public void setStartColor(int startColor) {
        this.startColor.set(startColor);
    }

    /**
     * Gets the end color property.
     * @return the end color property
     */
    public ViewProperty<Integer> endColor() {
        return endColor;
    }

    /**
     * Gets the end color value for particles.
     * @return the end color value for particles
     */
    public int getEndColor() {
        return endColor.get();
    }

    /**
     * Sets the end color value for particles.
     * @param endColor the end color value for particles
     */
    public void setEndColor(int endColor) {
        this.endColor.set(endColor);
    }

    /**
     * Gets the start scale property.
     * @return the start scale property
     */
    public ViewProperty<Float> startScale() {
        return startScale;
    }

    /**
     * Gets the start scale value for particles.
     * @return the start scale value for particles
     */
    public float getStartScale() {
        return startScale.get();
    }

    /**
     * Sets the start scale value for particles.
     * @param startScale the start scale value for particles
     */
    public void setStartScale(float startScale) {
        this.startScale.set(startScale);
    }

    /**
     * Gets the end scale property.
     * @return the end scale property
     */
    public ViewProperty<Float> endScale() {
        return endScale;
    }

    /**
     * Gets the end scale value for particles.
     * @return the end scale value for particles
     */
    public float getEndScale() {
        return endScale.get();
    }

    /**
     * Sets the end scale value for particles.
     * @param endScale the end scale value for particles
     */
    public void setEndScale(float endScale) {
        this.endScale.set(endScale);
    }

    /**
     * Gets the minimum particle lifetime property.
     * @return the minimum particle lifetime
     */
    public ViewProperty<Float> minParticleLifetime() {
        return minParticleLifetime;
    }

    /**
     * Gets the minimum lifetime value for a single particle in seconds.
     * @return the minimum lifetime value for a single particle in seconds
     */
    public float getMinParticleLifetime() {
        return minParticleLifetime.get();
    }

    /**
     * Sets the minimum lifetime value for a single particle in seconds.
     * @param minParticleLifetime the minimum lifetime value for a single particle in seconds
     */
    public void setMinParticleLifetime(float minParticleLifetime) {
        this.minParticleLifetime.set(minParticleLifetime);
    }

    /**
     * Gets the maximum particle lifetime property.
     * @return the maximum particle lifetime
     */
    public ViewProperty<Float> maxParticleLifetime() {
        return maxParticleLifetime;
    }

    /**
     * Gets the maximum lifetime value for a single particle in seconds.
     * @return the maximum lifetime value for a single particle in seconds
     */
    public float getMaxParticleLifetime() {
        return maxParticleLifetime.get();
    }

    /**
     * Sets the maximum lifetime value for a single particle in seconds.
     * @param maxParticleLifetime the maximum lifetime value for a single particle in seconds
     */
    public void setMaxParticleLifetime(float maxParticleLifetime) {
        this.maxParticleLifetime.set(maxParticleLifetime);
    }

    /**
     * Gets the minimum angle property.
     * @return the minimum angle property
     */
    public ViewProperty<Integer> minAngle() {
        return minAngle;
    }

    /**
     * Gets the minimum angle value at which particles are pointed when emitted.
     * @return the minimum angle value at which particles are pointed when emitted
     */
    public int getMinAngle() {
        return minAngle.get();
    }

    /**
     * Sets the minimum angle value at which particles are pointed when emitted.
     * @param minAngle the minimum angle value at which particles are pointed when emitted
     */
    public void setMinAngle(int minAngle) {
        this.minAngle.set(minAngle);
    }

    /**
     * Gets the maximum angle property.
     * @return the maximum angle property
     */
    public ViewProperty<Integer> maxAngle() {
        return maxAngle;
    }

    /**
     * Gets the maximum angle value at which particles are pointed when emitted.
     * @return the maximum angle value at which particles are pointed when emitted
     */
    public int getMaxAngle() {
        return maxAngle.get();
    }

    /**
     * Sets the maximum angle value at which particles are pointed when emitted.
     * @param maxAngle the maximum angle value at which particles are pointed when emitted
     */
    public void setMaxAngle(int maxAngle) {
        this.maxAngle.set(maxAngle);
    }

    /**
     * Gets the minimum rotation speed property.
     * @return the minimum rotation speed property
     */
    public ViewProperty<Integer> minRotationSpeed() {
        return minRotationSpeed;
    }

    /**
     * Gets the minimum rotation value in degrees per seconds that particle rotate.
     * @return the minimum rotation value in degrees per seconds that particle rotate
     */
    public int getMinRotationSpeed() {
        return minRotationSpeed.get();
    }

    /**
     * Sets the minimum rotation value in degrees per seconds that particle rotate.
     * @param minRotationSpeed the minimum rotation value in degrees per seconds that particle rotate
     */
    public void setMinRotationSpeed(int minRotationSpeed) {
        this.minRotationSpeed.set(minRotationSpeed);
    }

    /**
     * Gets the maximum rotation speed property.
     * @return the maximum rotation speed property
     */
    public ViewProperty<Integer> maxRotationSpeed() {
        return maxRotationSpeed;
    }

    /**
     * Gets the maximum rotation value in degrees per seconds that particle rotate.
     * @return the maximum rotation value in degrees per seconds that particle rotate
     */
    public int getMaxRotationSpeed() {
        return maxRotationSpeed.get();
    }

    /**
     * Sets the maximum rotation value in degrees per seconds that particle rotate.
     * @param maxRotationSpeed the maximum rotation value in degrees per seconds that particle rotate
     */
    public void setMaxRotationSpeed(int maxRotationSpeed) {
        this.maxRotationSpeed.set(maxRotationSpeed);
    }

    /**
     * Gets the starting speed property.
     * @return the starting speed property
     */
    public ViewProperty<Integer> startingSpeed() {
        return startingSpeed;
    }

    /**
     * Gets the starting speed of the particles.
     * @return the starting speed of the particles
     */
    public int getStartingSpeed() {
        return startingSpeed.get();
    }

    /**
     * Sets the starting speed of the particles.
     * @param startingSpeed the starting speed of the particles
     */
    public void setStartingSpeed(int startingSpeed) {
        this.startingSpeed.set(startingSpeed);
    }

    /**
     * Gets the ending speed property.
     * @return the ending speed property
     */
    public ViewProperty<Integer> endingSpeed() {
        return endingSpeed;
    }

    /**
     * Gets the ending speed of the particles.
     * @return the ending speed of the particles
     */
    public int getEndingSpeed() {
        return endingSpeed.get();
    }

    /**
     * Sets the ending speed of the particles.
     * @param endingSpeed the ending speed of the particles
     */
    public void setEndingSpeed(int endingSpeed) {
        this.endingSpeed.set(endingSpeed);
    }

    /**
     * Gets the spawn type property.
     * @return the spawn type property
     */
    public ViewProperty<IParticleSpawnType> spawnType() {
        return spawnType;
    }

    /**
     * Gets the particle spawning type.
     * @return particle spawning type
     */
    public IParticleSpawnType getSpawnType() {
        return spawnType.get();
    }

    /**
     * Returns info whether the particles are running or not.
     * @return boolean value that indicates whether if particles are running or not
     */
    public boolean isRunning() {
        return state.get() == State.RUNNING;
    }

    /**
     * Gets the state type property
     * @return the state type property
     */
/*    public ViewProperty<State> state() {
        return  state;
    }*/


    /**
     * Sets particle state.
     * @param state {@link State}
     */
    public void setState(State state) {
        if (this.state.get() != state) {
            this.state.set(state);
        }
    }

    /**
     * Starts running particles.
     */
    public void start() {
        setState(State.RUNNING);
    }

    /**
     * Stops running particles.
     */
    public void stop() {
        setState(State.STOPPED);
    }

    /**
     * Sets the particle spawning type.
     * <br><br>
     * Spawn type can be also declared in the layout xml file, using the &lt;spawnType/&gt; tag inside particle view declaration:
     * <pre>
     * {@code
     *
     *  <FrameParticleView>
     *       <spawnType class="CLASS_FULL_PATH" attributes/>
     *   </FrameParticleView>
     * }
     * </pre>
     * There are 3 class types of spawning types:
     * <ul>
     * <li>{@link PointParticleSpawnType} (this type is set as default)</li>

     * </ul>
     * Each of the spawning type contains own attributes, which can be declared in the xml.
     * <br><br>
     * An example of a declaration:
     * <pre>
     * {@code
     *
     *  <FrameParticleView>
     *       <spawnType class="com.atsisa.gox.framework.view.CircleParticleSpawnType" radius="50" spawningOnEdges="false"/>
     *   </FrameParticleView>
     * }
     * </pre>
     * @param particleSpawnType {@link IParticleSpawnType}
     */
    public void setSpawnType(IParticleSpawnType particleSpawnType) {
        this.spawnType.set(particleSpawnType);
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (skin.getViewType() == FrameParticleView.class) {
            FrameParticleView skinView = (FrameParticleView) skin.getView();
            if (!skinView.particlesPerSecond.hasDefaultValue()) {
                setParticlesPerSecond(skinView.getParticlesPerSecond());
            }
            if (!skinView.maxParticles.hasDefaultValue()) {
                setMaxParticles(skinView.getMaxParticles());
            }
            if (!skinView.imageResource.hasDefaultValue()) {
                setImageResource(skinView.getImageResource());
            }
            if (!skinView.yOffset.hasDefaultValue()) {
                setYOffset(skinView.getYOffset());
            }
            if (!skinView.xOffset.hasDefaultValue()) {
                setXOffset(skinView.getXOffset());
            }
            if (!skinView.startAlpha.hasDefaultValue()) {
                setStartAlpha(skinView.getStartAlpha());
            }
            if (!skinView.endAlpha.hasDefaultValue()) {
                setEndAlpha(skinView.getEndAlpha());
            }
            if (!skinView.startColor.hasDefaultValue()) {
                setStartColor(skinView.getStartColor());
            }
            if (!skinView.endColor.hasDefaultValue()) {
                setEndColor(skinView.getEndColor());
            }
            if (!skinView.startScale.hasDefaultValue()) {
                setStartScale(skinView.getStartScale());
            }
            if (!skinView.endScale.hasDefaultValue()) {
                setEndScale(skinView.getEndScale());
            }
            if (!skinView.minParticleLifetime.hasDefaultValue()) {
                setMinParticleLifetime(skinView.getMinParticleLifetime());
            }
            if (!skinView.maxParticleLifetime.hasDefaultValue()) {
                setMaxParticleLifetime(skinView.getMaxParticleLifetime());
            }
            if (!skinView.maxAngle.hasDefaultValue()) {
                setMaxAngle(skinView.getMaxAngle());
            }
            if (!skinView.minAngle.hasDefaultValue()) {
                setMinAngle(skinView.getMinAngle());
            }
            if (!skinView.minRotationSpeed.hasDefaultValue()) {
                setMinRotationSpeed(skinView.getMinRotationSpeed());
            }
            if (!skinView.maxRotationSpeed.hasDefaultValue()) {
                setMaxRotationSpeed(skinView.getMaxRotationSpeed());
            }
            if (!skinView.spawnType.hasDefaultValue()) {
                setSpawnType(skinView.getSpawnType());
            }
            if (!skinView.startingSpeed.hasDefaultValue()) {
                setStartingSpeed(skinView.getStartingSpeed());
            }
            if (!skinView.endingSpeed.hasDefaultValue()) {
                setEndingSpeed(skinView.getEndingSpeed());
            }
            if (!skinView.state.hasDefaultValue()) {
                setState(skinView.getState());
            }
        }
    }

    @Override
    public void redraw() {
        super.redraw();
        propertyChanged(ViewType.PARTICLE_VIEW,
                ViewPropertyName.IMAGE | ViewPropertyName.PARTICLES_PER_SEC | ViewPropertyName.ENDING_SPEED | ViewPropertyName.STARTING_SPEED
                        | ViewPropertyName.SPAWN_TYPE | ViewPropertyName.MAX_ROTATION_SPEED | ViewPropertyName.MIN_ROTATION_SPEED | ViewPropertyName.MAX_ANGLE
                        | ViewPropertyName.MIN_ANGLE | ViewPropertyName.MAX_PARTICLE_LIFETIME | ViewPropertyName.MIN_PARTICLE_LIFETIME
                        | ViewPropertyName.END_SCALE | ViewPropertyName.START_SCALE | ViewPropertyName.END_COLOR | ViewPropertyName.START_COLOR
                        | ViewPropertyName.END_ALPHA | ViewPropertyName.START_ALPHA | ViewPropertyName.OFFSET_X | ViewPropertyName.OFFSET_Y
                        | ViewPropertyName.MAX_PARTICLES | ViewPropertyName.STATE);
    }

    /**
     * Describes possible particle states.
     */
    public enum State {

        /**
         * Represents running state.
         */
        RUNNING,

        /**
         * Represents stopped state.
         */
        STOPPED,

    }

    /**
     * View property names.
     */
    public static final class ViewPropertyName {

        /**
         * Represents a view property accessible via {@link FrameParticleView#getParticlesPerSecond}  setMethod.
         */
        public static final int PARTICLES_PER_SEC = 1;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getImageResource} setMethod.
         */
        public static final int IMAGE = 1 << 1;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getEndingSpeed} setMethod.
         */
        public static final int ENDING_SPEED = 1 << 2;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getStartingSpeed} setMethod.
         */
        public static final int STARTING_SPEED = 1 << 3;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getSpawnType} setMethod.
         */
        public static final int SPAWN_TYPE = 1 << 4;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMaxRotationSpeed} setMethod.
         */
        public static final int MAX_ROTATION_SPEED = 1 << 5;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMinRotationSpeed} setMethod.
         */
        public static final int MIN_ROTATION_SPEED = 1 << 6;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMaxAngle} setMethod.
         */
        public static final int MAX_ANGLE = 1 << 7;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMinAngle} setMethod.
         */
        public static final int MIN_ANGLE = 1 << 8;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMaxParticleLifetime} setMethod.
         */
        public static final int MAX_PARTICLE_LIFETIME = 1 << 9;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMinParticleLifetime} setMethod.
         */
        public static final int MIN_PARTICLE_LIFETIME = 1 << 10;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getEndScale} setMethod.
         */
        public static final int END_SCALE = 1 << 11;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getStartScale} setMethod.
         */
        public static final int START_SCALE = 1 << 12;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getEndColor} setMethod.
         */
        public static final int END_COLOR = 1 << 13;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getStartColor} setMethod.
         */
        public static final int START_COLOR = 1 << 14;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getEndAlpha} setMethod.
         */
        public static final int END_ALPHA = 1 << 15;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getStartAlpha} setMethod.
         */
        public static final int START_ALPHA = 1 << 16;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getXOffset} setMethod.
         */
        public static final int OFFSET_X = 1 << 17;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getYOffset} setMethod.
         */
        public static final int OFFSET_Y = 1 << 18;

        /**
         * Represents a view property accessible via {@link FrameParticleView#getMaxParticles} setMethod.
         */
        public static final int MAX_PARTICLES = 1 << 19;

        /**
         * Represents a view property accessible via getState setMethod.
         */
        public static final int STATE = 1 << 20;

        /**
         * Prevents the creation of an instance of this class.
         */
        private ViewPropertyName() {
        }
    }
}

