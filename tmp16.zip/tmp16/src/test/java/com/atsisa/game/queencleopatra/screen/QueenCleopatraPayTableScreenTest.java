package com.atsisa.game.queencleopatra.screen;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraPayTableScreenModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewGroup;
import com.atsisa.gox.reels.event.ExtendedSymbolModelChangedEvent;
import com.atsisa.gox.reels.model.IExtendedSymbolModel;
import com.atsisa.gox.reels.model.IPayTableModelItem;

/**
 * Tests for {@link QueenCleopatraPayTableScreen} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class QueenCleopatraPayTableScreenTest {

    /**
     * Name of the layout id property.
     */
    public static final String QUEEN_CLEOPATRA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY = "QueenCleopatraPayTableScreen";

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Pay table screen model mock.
     */
    @Mock
    private QueenCleopatraPayTableScreenModel model;

    /**
     * Renderer mock.
     */
    @Mock
    private IRenderer renderer;

    /**
     * View manager mock.
     */
    @Mock
    private IViewManager viewManager;

    /**
     * List of pay table items.
     */
    private List<IPayTableModelItem> symbols;

    /**
     * Animation factory mock.
     */
    @Mock
    private IAnimationFactory animationFactory;

    /**
     * Pay table item mock.
     */
    @Mock
    private IPayTableModelItem firstPayTableItem;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger logger;

    /**
     * Pay table screen instance for test.
     */
    private QueenCleopatraPayTableScreen queenCleopatraPayTableScreen;

    /**
     * Sets up mocks and create pay table screen class instance for tests.
     */
    @Before
    public void setUp() {
        symbols = new ArrayList<>();
        MockitoAnnotations.initMocks(this);
        queenCleopatraPayTableScreen = new QueenCleopatraPayTableScreen(QUEEN_CLEOPATRA_DELUXE_PAYTABLE_LAYOUT_ID_PROPERTY, model, renderer, viewManager,
                animationFactory, logger, eventBusMock);
    }

    /**
     * Tests whether the screen updates screen with data from model.
     */
    @Test
    public void shouldPassInfoAboutPayTableForExtendedSymbolToModelWhenExtendedSymbolModelWillChange() {
        //GIVEN
        ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent = mock(ExtendedSymbolModelChangedEvent.class);
        IExtendedSymbolModel extendedSymbolModel = mock(IExtendedSymbolModel.class);
        when(extendedSymbolModelChangedEvent.getExtendedSymbolModel()).thenReturn(extendedSymbolModel);
        when(extendedSymbolModel.getExtendedSymbolPayTableItems()).thenReturn(symbols);

        when(firstPayTableItem.getValue()).thenReturn(159L);
        symbols.add(firstPayTableItem);

        ViewGroup extendedSymbol = mock(ViewGroup.class);

        when(extendedSymbol.getChildren()).thenReturn(new ArrayList<>());
        queenCleopatraPayTableScreen.extendedSymbolGroup = extendedSymbol;

        //WHEN
        queenCleopatraPayTableScreen.handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);

        //THEN
        verify(model).updateExtendedSymbols(symbols);
    }

    /**
     * Tests whether the screen displays proper expanding symbol.
     */

    @Test
    public void shouldDisplayProperExpandingSymbolOnPayTable() {

        //GIVEN
        ExtendedSymbolModelChangedEvent extendedSymbolModelChangedEvent = mock(ExtendedSymbolModelChangedEvent.class);
        IExtendedSymbolModel extendedSymbolModel = mock(IExtendedSymbolModel.class);
        when(extendedSymbolModelChangedEvent.getExtendedSymbolModel()).thenReturn(extendedSymbolModel);
        when(extendedSymbolModel.getExtendedSymbolName()).thenReturn("Bracelet");

        when(extendedSymbolModel.getExtendedSymbolPayTableItems()).thenReturn(symbols);
        when(firstPayTableItem.getValue()).thenReturn(159L);
        symbols.add(firstPayTableItem);

        ViewGroup extendedSymbol = mock(ViewGroup.class);

        View cleopatraSymbol = mock(View.class);
        when(cleopatraSymbol.getId()).thenReturn("Cleopatra");

        View cleopatraBookSymbol = mock(View.class);
        when(cleopatraBookSymbol.getId()).thenReturn("CleopatraF");

        View griffinSymbol = mock(View.class);
        when(griffinSymbol.getId()).thenReturn("Griffin");

        View griffinBookSymbol = mock(View.class);
        when(griffinBookSymbol.getId()).thenReturn("GriffinF");

        View necklaceSymbol = mock(View.class);
        when(necklaceSymbol.getId()).thenReturn("Bracelet");

        View necklaceBookSymbol = mock(View.class);
        when(necklaceBookSymbol.getId()).thenReturn("BraceletF");

        View braceletSymbol = mock(View.class);
        when(braceletSymbol.getId()).thenReturn("Necklace");

        View braceletBookSymbol = mock(View.class);
        when(braceletBookSymbol.getId()).thenReturn("NecklaceF");

        ArrayList<View> expandingSymbols = new ArrayList<>();
        expandingSymbols.add(cleopatraSymbol);
        expandingSymbols.add(cleopatraBookSymbol);
        expandingSymbols.add(griffinSymbol);
        expandingSymbols.add(griffinBookSymbol);
        expandingSymbols.add(necklaceSymbol);
        expandingSymbols.add(necklaceBookSymbol);
        expandingSymbols.add(braceletSymbol);
        expandingSymbols.add(braceletBookSymbol);

        when(extendedSymbol.getChildren()).thenReturn(expandingSymbols);
        queenCleopatraPayTableScreen.extendedSymbolGroup = extendedSymbol;

        //WHEN
        queenCleopatraPayTableScreen.handleExtendedSymbolModelChangedEvent(extendedSymbolModelChangedEvent);

        //THEN
        verify(cleopatraSymbol).setVisible(false);
        verify(cleopatraBookSymbol).setVisible(false);
        verify(griffinSymbol).setVisible(false);
        verify(griffinBookSymbol).setVisible(false);
        verify(necklaceSymbol).setVisible(true);
        verify(necklaceBookSymbol).setVisible(true);
        verify(braceletSymbol).setVisible(false);
        verify(braceletBookSymbol).setVisible(false);

    }

}