package com.atsisa.game.queencleopatra.model;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraPayTableScreenModel;
import com.atsisa.gox.framework.configuration.IConfiguration;
import com.atsisa.gox.framework.infrastructure.IConfigurationProvider;
import com.atsisa.gox.framework.utility.localization.ITranslator;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IPayTableModelItem;

/**
 * Tests for {@link QueenCleopatraPayTableScreenModel} class.
 */
@RunWith(MockitoJUnitRunner.class)
public class QueenCleopatraPayTableScreenModelTest {

    /**
     * Translation mock.
     */
    @Mock
    ITranslator translator;

    /**
     * Configuration provider mock.
     */
    @Mock
    IConfigurationProvider configurationProvider;

    /**
     * Credits formatter mock.
     */
    @Mock
    ICreditsFormatter creditsFormatter;

    /**
     * Pay table screen model for test.
     */
    private QueenCleopatraPayTableScreenModel queenCleopatraPayTableScreenModel;

    /**
     * Called before each tests.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        queenCleopatraPayTableScreenModel = new QueenCleopatraPayTableScreenModel(translator, configurationProvider, creditsFormatter);

    }

    /**
     * Tests whether the book of ra deluxe screen model properly sorts received value.
     */
    @Test
    public void shouldSortPropertiesCorrectly() {
        //GIVEN
        long firstValue = 7500L;
        long secondValue = 2000L;
        long thirdValue = 5000L;

        IPayTableModelItem firstPayTableItem = mock(IPayTableModelItem.class);
        IPayTableModelItem secondPayTableItem = mock(IPayTableModelItem.class);
        IPayTableModelItem thirdPayTableItem = mock(IPayTableModelItem.class);

        ArrayList<IPayTableModelItem> payTableItems = new ArrayList<>();
        payTableItems.add(firstPayTableItem);
        payTableItems.add(secondPayTableItem);
        payTableItems.add(thirdPayTableItem);

        when(creditsFormatter.format(anyLong(), any())).thenAnswer(new Answer<String>() {

            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                long value = (long) invocation.getArguments()[0];
                if (value == firstValue) {
                    return "7500";
                } else if (value == secondValue) {
                    return "2000";
                } else if (value == thirdValue) {
                    return "5000";
                }
                return null;
            }
        });

        when(firstPayTableItem.getValue()).thenReturn(thirdValue);
        when(secondPayTableItem.getValue()).thenReturn(firstValue);
        when(thirdPayTableItem.getValue()).thenReturn(secondValue);
        when(configurationProvider.getConfiguration()).thenReturn(mock(IConfiguration.class));

        //WHEN
        queenCleopatraPayTableScreenModel.updateExtendedSymbols(payTableItems);

        //THEN
        Assert.assertEquals(7500L, queenCleopatraPayTableScreenModel.getProperty("extendedSymbolX5Pays").get());
        Assert.assertEquals(5000L, queenCleopatraPayTableScreenModel.getProperty("extendedSymbolX4Pays").get());
        Assert.assertEquals(2000L, queenCleopatraPayTableScreenModel.getProperty("extendedSymbolX3Pays").get());

    }

}
