package com.atsisa.game.queencleopatra.screen;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.atsisa.game.queencleopatra.screen.model.QueenCleopatraFreeGamesInfoBannerScreenModel;
import com.atsisa.gox.framework.animation.IAnimationFactory;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.infrastructure.IViewManager;
import com.atsisa.gox.framework.rendering.IRenderer;
import com.atsisa.gox.framework.utility.logger.ILogger;
import com.atsisa.gox.reels.event.FreeGamesModelChangedEvent;
import com.atsisa.gox.reels.logic.FreeGamesInfoType;
import com.atsisa.gox.reels.model.ICreditsFormatter;
import com.atsisa.gox.reels.model.IFreeGamesModel;

@RunWith(MockitoJUnitRunner.class)
public class QueenCleopatraFreeGamesInfoBannerScreenTest {

    /**
     * Name of the layout id property.
     */
    private static final String LAYOUT_ID_PROPERTY = "freeGamesBannerScreen";

    /**
     * Free games end banner visible.
     */
    private static final String FREE_GAMES_END_BANNER_VISIBLE = "freeGamesEndBannerVisible";

    /**
     * Retrigger message visible.
     */
    private static final String RETRIGGER_BANNER_VISIBLE = "retriggerBannerVisible";

    /**
     * The event bus mock.
     */
    @Mock
    private IEventBus eventBusMock;

    /**
     * Free games info banner screen model mock.
     */
    @Mock
    private QueenCleopatraFreeGamesInfoBannerScreenModel model;

    /**
     * Renderer mock.
     */
    @Mock
    private IRenderer renderer;

    /**
     * View manager mock.
     */
    @Mock
    private IViewManager viewManager;

    /**
     * Animation factory mock.
     */
    @Mock
    private IAnimationFactory animationFactory;

    /**
     * Logger mock.
     */
    @Mock
    private ILogger logger;

    /**
     * Free games info banner screen instance for test.
     */
    private QueenCleopatraFreeGamesBannerScreen queenCleopatraFreeGamesBannerScreen;

    /**
     * Credits formatter mock.
     */
    @Mock
    private ICreditsFormatter creditsFormatter;

    /**
     * Sets up mocks and create free games info banner screen class instance for tests.
     */
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        queenCleopatraFreeGamesBannerScreen = new QueenCleopatraFreeGamesBannerScreen(LAYOUT_ID_PROPERTY, model, renderer, viewManager, animationFactory,
                logger, eventBusMock);
    }

    /**
     * Tests whether the incoming event with proper info type is handled and game displays retrigger text message.
     */
    @Test
    public void shouldShowRetriggerBannerWhenEventWithInfoTypeReceived() {
        //GIVEN
        FreeGamesModelChangedEvent freeGamesModelChangedEvent = mock(FreeGamesModelChangedEvent.class);
        IFreeGamesModel freeGamesModel = mock(IFreeGamesModel.class);
        when(freeGamesModelChangedEvent.getFreeGamesModel()).thenReturn(freeGamesModel);
        when(freeGamesModel.getFreeGamesInfoType()).thenReturn(FreeGamesInfoType.RETRIGGER);

        //WHEN
        queenCleopatraFreeGamesBannerScreen.handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);

        //THEN
        verify(model).setProperty(RETRIGGER_BANNER_VISIBLE, true);
        verify(model).setProperty(FREE_GAMES_END_BANNER_VISIBLE, false);
    }

    /**
     * Tests whether the incoming event is handled and game displays game end text message.
     */
    @Test
    public void shouldShowGameEndBannerWhenEventReceived() {
        //GIVEN
        FreeGamesModelChangedEvent freeGamesModelChangedEvent = mock(FreeGamesModelChangedEvent.class);
        IFreeGamesModel freeGamesModel = mock(IFreeGamesModel.class);
        when(freeGamesModelChangedEvent.getFreeGamesModel()).thenReturn(freeGamesModel);
        when(freeGamesModel.getFreeGamesInfoType()).thenReturn(FreeGamesInfoType.GAMES_END);

        //WHEN
        queenCleopatraFreeGamesBannerScreen.handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);

        //THEN
        verify(model).setProperty(FREE_GAMES_END_BANNER_VISIBLE, true);
        verify(model).setProperty(RETRIGGER_BANNER_VISIBLE, false);
    }

    /**
     * Tests whether the screen stores information about free games.
     */
    @Test
    public void shouldScreenStoreInformationAboutFreeGames() {
        //GIVEN
        FreeGamesModelChangedEvent freeGamesModelChangedEvent = mock(FreeGamesModelChangedEvent.class);
        IFreeGamesModel freeGamesModel = mock(IFreeGamesModel.class);
        when(freeGamesModelChangedEvent.getFreeGamesModel()).thenReturn(freeGamesModel);
        when(freeGamesModel.getCurrentFreeGameNumber()).thenReturn(17);
        when(freeGamesModel.getTotalFreeGamesNumber()).thenReturn(50);
        when(freeGamesModel.getAmountWonGames()).thenReturn(20);

        //WHEN
        queenCleopatraFreeGamesBannerScreen.handleFreeGamesModelChangedEvent(freeGamesModelChangedEvent);

        //THEN
        verify(model, times(1)).setCurrentFreeGamesNumber(17);
        verify(model, times(1)).setTotalFreeGamesNumber(50);
        verify(model, times(1)).setNumberWonGames(20);
    }

}
