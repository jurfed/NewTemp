package com.atsisa.gox.games.trextrack.view;

import com.atsisa.gox.games.trextrack.TRexTrackWildHitChecker;
import com.atsisa.gox.games.trextrack.screen.model.BaseGameScreenModel;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.calculator.HitCheckResult;
import com.atsisa.gox.logic.calculator.IHitChecker;
import com.atsisa.gox.logic.calculator.ILinesCalculator;
import com.atsisa.gox.logic.model.*;
import com.atsisa.gox.logic.model.utils.ReelGameType;
import com.atsisa.gox.logic.provider.ILinesModelProvider;

import javax.inject.Inject;
import java.util.*;

/**
 * The lines calculator for reels game.
 */
public class TRexTrackLinesCalculator implements ILinesCalculator {

    /**
     * The symbol marked as already used.
     */
    private static final byte MARK_SYMBOL = Byte.MIN_VALUE;

    /**
     * The {@link ILinesModelProvider}
     */
    private final ILinesModelProvider linesProvider;

    /**
     * The hit checkers.
     */
    private final Set<IHitChecker> hitCheckers;

    /**
     * for check double wild symbol
     */
    private final static List<String> dinoSymbols = new ArrayList() {{
        add("Violet");
        add("Blue");
        add("Pink");
        add("Yellow");
        add("Green");
    }};

    /**
     * for get track symbolId
     */
    private int trackSymbolValue;

    private static Map<String, Set<Integer>> symbolsWinCounts;

    /**
     * Initializes a new instance of the {@link com.atsisa.gox.logic.calculator.LinesCalculator} class.
     *
     * @param linesProvider The lines provider
     * @param hitCheckers   The set of {@link IHitChecker}
     */
    @Inject
    public TRexTrackLinesCalculator(ILinesModelProvider linesProvider, Set<IHitChecker> hitCheckers) {
        this.linesProvider = linesProvider;
        this.hitCheckers = hitCheckers;
    }

    /**
     * Initializes a new instance of the {@link com.atsisa.gox.logic.calculator.LinesCalculator} class
     *
     * @param linesProvider The {@link ILinesModelProvider}
     */
    public TRexTrackLinesCalculator(ILinesModelProvider linesProvider) {
        this(linesProvider, Collections.emptySet());
    }

    /**
     * Calculates the win for given lines numer
     *
     * @param activeLines        number of lines
     * @param stopSymbols        stop symbols list
     * @param lineWinDescriptors the list of {@link LineWinDescriptor}
     * @return the list of {@link LineWinResult}
     * @throws GameLogicException when calculation could not be properly processed
     */
    @Override
    public List<LineWinResult> calculate(int activeLines, List<Reel> stopSymbols, List<LineWinDescriptor> lineWinDescriptors) throws GameLogicException {
        ArrayList<LineWinResult> winResults = new ArrayList<>();

        if (!linesProvider.getLineDescriptors().isPresent()) {
            throw new GameLogicException("The lines model is null");
        }

        List<LineDescriptor> linesDescriptors = linesProvider.getLineDescriptors().get();
        //1) cycle along all lines

        TRexTrackWildHitChecker.resetTrackSymbol();

        symbolsWinCounts = new HashMap<>();

        for (int line = 0; line < activeLines; line++) {
            //We take the positions of the cells in this line
            LineDescriptor lineDescriptor = linesDescriptors.get(line);
            //take all the symbols on the reels
            List<Reel> stopSymbolsCopy = deepCopy(stopSymbols);

            //2) Cycle of all winnings descriptions
            for (LineWinDescriptor lineWinDescriptor : lineWinDescriptors) {
                //line = line number+1
                evaluateWinDescriptor(lineWinDescriptor, stopSymbolsCopy, lineDescriptor, line, winResults);
            }
        }

        return winResults;
    }

    /**
     * Evaluates the win descriptor.
     *
     * @param lineWinDescriptor The win line descriptor.
     * @param stopSymbols       The stop symbols.
     * @param lineDescriptor    The line descriptor.
     * @param lineIndex         The line index.
     * @param winResults        The win results.
     */
    private void evaluateWinDescriptor(LineWinDescriptor lineWinDescriptor, List<Reel> stopSymbols, LineDescriptor lineDescriptor, int lineIndex,
                                       List<LineWinResult> winResults) {
        List<String> winLineCombinationStyles = lineWinDescriptor.getWinLineCombinationStyles();
        int reelsCount = stopSymbols.size();

        if (winLineCombinationStyles.containsAll(new ArrayList<String>() {{
            add(WinLineCombinationStyle.LEFT_TO_RIGHT);
            add(WinLineCombinationStyle.RIGHT_TO_LEFT);
        }})) {
            // check for hit starting at leftmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, false);

            // check for hit starting at rightmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, reelsCount - lineWinDescriptor.getWinDescriptor().getSymbolsAmount(), lineDescriptor,
                    lineIndex, winResults, false);
        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.LEFT_TO_RIGHT)) {

            // check for hit starting at leftmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, false);
        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.RIGHT_TO_LEFT)) {

            // check for hit starting at rightmost reel
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, reelsCount - lineWinDescriptor.getWinDescriptor().getSymbolsAmount(), lineDescriptor,
                    lineIndex, winResults, false);

        } else if (winLineCombinationStyles.contains(WinLineCombinationStyle.SCATTERED)) {
            evaluateWinDescriptor(lineWinDescriptor, stopSymbols, 0, lineDescriptor, lineIndex, winResults, true);
        }
    }

    /**
     * Evaluates the win descriptor.
     *
     * @param lineWinDescriptor The win line descriptor.
     * @param stopSymbols       The stop symbols.
     * @param startReel         The start reel.
     * @param lineDescriptor    The line descriptor.
     * @param lineIndex         The line index.
     * @param winResults        The win results.
     * @param isScattered       The {@link WinLineCombinationStyle} is scattered.
     */
    private void evaluateWinDescriptor(LineWinDescriptor lineWinDescriptor, List<Reel> stopSymbols, int startReel, LineDescriptor lineDescriptor, int lineIndex,
                                       List<LineWinResult> winResults, boolean isScattered) {
        int reelsCount = stopSymbols.size();

        // list of win symbols
        List<SymbolPosition> winSymbolPositions = new ArrayList<>(lineWinDescriptor.getWinDescriptor().getSymbolsAmount());

        // list of win symbols that are non repeatable
        List<SymbolPosition> nonRepeatableSymbolPositions = new ArrayList<>(lineWinDescriptor.getWinDescriptor().getSymbolsAmount());

        int occurrencesCount = 0;//the count of this checking symbol on the checking line

        //the number of symbols required for a given winning combination
        //int max = isScattered ? reelsCount : startReel + lineWinDescriptor.getWinDescriptor().getSymbolsAmount();


        for (int reel = 0; reel < 5; reel++) {//cycle for reel strips
            int row = lineDescriptor.getPositions().get(reel).getRow();//row number on this win line on this reel

            // if any symbol already used, there is no reason to check further symbols
            Symbol symbolToCheck = stopSymbols.get(reel).getSymbols().get(row);//get stopped symbol on this cell
            if (symbolToCheck.getId() == MARK_SYMBOL) {
                return;
            }

            boolean hit = false;//hit for chicking cell

            trackSymbolValue = TRexTrackWildHitChecker.getWinTrackSymbol();
            String trackSymbol;
            if (symbolToCheck.getName().equals("Track") || symbolToCheck.getName().equals("TrackR")) {
                trackSymbol = BaseGameScreenModel.getSymbolsForCountWinTxt().get(trackSymbolValue);
            } else {
                trackSymbol = "";
            }


            boolean doubleSymbol = ((lineWinDescriptor.getWinDescriptor().getSymbol().getName() + 2).equals(symbolToCheck.getName()) || (lineWinDescriptor.getWinDescriptor().getSymbol().getName() + 2).equals(trackSymbol));
            boolean doubleWild = dinoSymbols.contains(lineWinDescriptor.getWinDescriptor().getSymbol().getName()) && symbolToCheck.getName().equals("Wild");
            Iterator<IHitChecker> checkerIterator = hitCheckers.iterator();//Symbol checker and Wild checker
            while (checkerIterator.hasNext() && !hit) {//cell check for winnings

                HitCheckResult result = checkerIterator.next().check(lineWinDescriptor.getWinDescriptor().getSymbol(), symbolToCheck);
                boolean simpleSymbolHit = (result.isHit() ||(lineWinDescriptor.getWinDescriptor().getSymbol().getName()).equals(trackSymbol));


                if (simpleSymbolHit || doubleSymbol) {
                    hit = true;
                    if (simpleSymbolHit && !doubleWild) {
                        occurrencesCount++;
                    } else if (simpleSymbolHit && doubleWild) {
                        occurrencesCount += 2;
                    } else if (doubleSymbol) {
                        occurrencesCount += 2;
                    }

                    SymbolPosition winSymbolPosition = new SymbolPosition(reel, row);
                    winSymbolPositions.add(winSymbolPosition);
                    if (lineWinDescriptor.getWinDescriptor().getWinId() == 11 && lineIndex == 4) {
                        System.out.println();
                    }

                    if (!result.isRepeatable()) {
                        nonRepeatableSymbolPositions.add(winSymbolPosition);
                    }
                }
            }

            // None of checkers found a match, so we break evaluation.
            if (!hit && !isScattered) {
                return;
            }

            //if we get this winning combination but field reel steel <5
            if (occurrencesCount == lineWinDescriptor.getWinDescriptor().getSymbolsAmount()) {
                break;
            }

        }
        if (occurrencesCount != lineWinDescriptor.getWinDescriptor().getSymbolsAmount()) {
            return;
        }


        // If this symbol participates in this win combination, it is marked as used symbol and will prevent next combination from being evaluated.
        nonRepeatableSymbolPositions
                .forEach(symbolPosition -> stopSymbols.get(symbolPosition.getReel()).getSymbols().get(symbolPosition.getRow()).setId(MARK_SYMBOL));
        WinResult winResult = new WinResult(lineWinDescriptor.getWinDescriptor().getWinId(), lineWinDescriptor.getWinDescriptor().getScore(),
                winSymbolPositions);
        LineWinResult lineWinResult = new LineWinResult(winResult, lineIndex, ReelGameType.LINES);
        winResults.add(lineWinResult);

    }

    /**
     * Creates deep copy of {@link Reel} list
     *
     * @param listToCopy The list to copy
     * @return The deep copy of the listToCopy
     */
    private List<Reel> deepCopy(List<Reel> listToCopy) {
        List<Reel> deepCopy = new ArrayList<>(listToCopy.size());
        for (int i = 0; i < listToCopy.size(); i++) {
            List<Symbol> symbols = new ArrayList<>();
            for (Symbol symbol : listToCopy.get(i).getSymbols()) {
                symbols.add(new Symbol(symbol.getName(), symbol.getId(), symbol.getType()));
            }
            deepCopy.add(new Reel(i, symbols));
        }

        return deepCopy;
    }
}
