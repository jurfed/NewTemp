package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.ExecuteNextAction;
import com.atsisa.gox.reels.AbstractReelGame;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * if amount int this free game == 0
 */
@Reflect_Mini
public class ExecuteNextDependingOnLoseFreeGame extends ExecuteNextAction {

    @Override
    protected void execute() {
        allowFurtherProcessing();

        if (((AbstractReelGame) GameEngine.current().getGame()).getLinesModelProvider().getTotalWinAmount() == 0) {
            cancelFurtherProcessing();
            super.execute();
        } else {
            finish();
        }

    }

}
