package com.atsisa.gox.games.trextrack.logic;

import com.atsisa.gox.reels.logic.model.Reel;

import java.util.Arrays;
import java.util.List;

public class TRexTrackInitialStopReels {

    private final static String SOUND_NAME = "ReelStop0";

    static final List<Reel> INITIAL_REELS = Arrays.asList(
            new Reel(SOUND_NAME, Arrays.asList(2, 2, 6, 4)),
            new Reel(SOUND_NAME, Arrays.asList(4, 1, 3, 2)),
            new Reel(SOUND_NAME, Arrays.asList(4, 3, 3, 5)),
            new Reel(SOUND_NAME, Arrays.asList(2, 2, 6, 4)),
            new Reel(SOUND_NAME, Arrays.asList(4, 1, 3, 2))
    );
}
