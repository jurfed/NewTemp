package com.atsisa.gox.games.trextrack.logic.handler;

import com.atsisa.gox.logic.FreeGamesLogicPresentation;
import com.atsisa.gox.logic.IGameLogicStateRepository;
import com.atsisa.gox.logic.ReelsPresentation;
import com.atsisa.gox.logic.SpinRequest;
import com.atsisa.gox.logic.messaging.IMessage;
import com.atsisa.gox.logic.messaging.IMessageHandler;
import com.atsisa.gox.logic.messaging.MessagingException;

import javax.inject.Inject;

/**
 * Validates if gameplay is in proper state and request can be handled
 */
public class SpinStateValidator implements IMessageHandler<SpinRequest, SpinRequest> {

    /**
     * Game logic state repository
     */
    private final IGameLogicStateRepository gameLogicStateRepository;

    /**
     * Initializes new instance of the {@link SpinStateValidator}
     * @param gameLogicStateRepository {@link IGameLogicStateRepository}
     */
    @Inject
    public SpinStateValidator(IGameLogicStateRepository gameLogicStateRepository) {
        this.gameLogicStateRepository = gameLogicStateRepository;
    }

    @Override
    public IMessage<SpinRequest> handle(IMessage<SpinRequest> message) throws MessagingException {
        String presentation = gameLogicStateRepository.getState().getPresentation();
        if (presentation.equals(ReelsPresentation.GAME_START.getName()) || presentation.equals(ReelsPresentation.BASE_GAME_LOSE.getName()) || presentation
                .equals(FreeGamesLogicPresentation.NO_FREE_GAMES_WON.getName())) {
            return message;
        }

        throw new MessagingException("Wrong game state. Probably previous game was not finished");
    }
}
