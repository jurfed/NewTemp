package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.PayTableAnimation;
import com.atsisa.gox.games.trextrack.screen.TRexTrackWinLinesScreen;

public class StopPayTableAnimation extends Action {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new PayTableAnimation(TRexTrackWinLinesScreen.getSymbolsWinCounts(), false));
        finish();
    }
}
