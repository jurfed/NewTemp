package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.*;
import com.atsisa.gox.games.trextrack.action.SetSymbolsTransparencyData;
import com.atsisa.gox.games.trextrack.event.freegames.YouWonEvent;

public class PlayStartVideo extends Action<PlayVideoData> {
    MovieView freeStart;
    MovieView freeCycle;
    MovieView freeEnd;
    StartLoopVideo startLoopVideo;
    KeyframeAnimationView effect;
    boolean finish = false;

    @Override
    protected void execute() {
        finish = false;
        freeStart = (MovieView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "freeStart");
        freeCycle = (MovieView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "freeCycle");
        freeEnd = (MovieView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "freeEnd");



        effect = GameEngine.current().getViewManager().findViewById("baseGameScreen", "effect");

        if (startLoopVideo == null) {
            startLoopVideo = new StartLoopVideo();
        }

        freeStart.setVisible(true);
        freeStart.play();

            GameEngine.current().getEventBus().post(new YouWonEvent(this.actionData.getStage()));


        try {
            freeStart.removePropertyChangedListener(startLoopVideo);
        } catch (Exception e) {

        }
        freeStart.addPropertyChangedListener(startLoopVideo);

    }


    class StartLoopVideo implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            if (!((MovieView) view).isPlaying()) {
                effect.play();
                effect.setVisible(true);
                freeStart.stop();
                freeStart.setVisible(false);
                freeCycle.setVisible(true);
                freeCycle.setLoop(true);
                freeCycle.play();



/*                GameEngine.current().getViewManager().findViewById("baseGameScreen", "you_won").setVisible(true);
                GameEngine.current().getViewManager().findViewById("baseGameScreen", "you_won_numbers").setVisible(true);*/



                new Timeout(3000, new TimeoutCallback() {
                    @Override
                    public void onTimeout() {

                        freeCycle.setVisible(false);
                        freeCycle.setLoop(false);
                        freeCycle.stop();

                        if (!finish) {
                            finish = true;
                            try {
                                freeStart.removePropertyChangedListener(startLoopVideo);
                            } catch (Exception e) {

                            }
                            finish();
                        }
                    }
                }, true);

            }
        }
    }

    class StartEndVideo implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {

        }
    }

    @Override
    public Class<PlayVideoData> getActionDataType() {
        return PlayVideoData.class;
    }
}
