package com.atsisa.gox.games.trextrack.event;


import java.util.Map;

/**
 * for send Map with win symbold to the winLinesScreen
 */
public class SendWinSymbolsEvent {

    private final Map symbolsMap;
    public SendWinSymbolsEvent(Map symbolsMap) {
        this.symbolsMap = symbolsMap;
    }

    public Map getSymbolsMap() {
        return symbolsMap;
    }
}
