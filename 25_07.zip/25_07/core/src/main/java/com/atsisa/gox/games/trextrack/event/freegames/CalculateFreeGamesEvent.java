package com.atsisa.gox.games.trextrack.event.freegames;

import com.atsisa.gox.logic.CalculateFreeGamesResult;

/*public class CalculateFreeGamesEvent {
    CalculateFreeGamesResult calculateFreeGamesResult;


    public CalculateFreeGamesEvent(CalculateFreeGamesResult calculateFreeGamesResult) {
        this.calculateFreeGamesResult = calculateFreeGamesResult;
    }

    public CalculateFreeGamesResult getCalculateFreeGamesResult() {
        return calculateFreeGamesResult;
    }

    public void setCalculateFreeGamesResult(CalculateFreeGamesResult calculateFreeGamesResult) {
        this.calculateFreeGamesResult = calculateFreeGamesResult;
    }
}*/
