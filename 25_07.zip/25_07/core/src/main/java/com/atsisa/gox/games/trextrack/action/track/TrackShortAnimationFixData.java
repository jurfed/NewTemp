package com.atsisa.gox.games.trextrack.action.track;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class TrackShortAnimationFixData extends ActionData {
    @XmlAttribute
    private boolean shortFix;

    public boolean getShortFix() {
        return shortFix;
    }

    public void setShortFix(boolean shortFix) {
        this.shortFix = shortFix;
    }
}
