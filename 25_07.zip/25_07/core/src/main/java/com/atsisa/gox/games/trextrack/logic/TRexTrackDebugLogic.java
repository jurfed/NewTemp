package com.atsisa.gox.games.trextrack.logic;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.inject.Inject;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.Iterables;
import com.atsisa.gox.logic.CalculateFreeGamesRequest;
import com.atsisa.gox.logic.CalculateFreeGamesResult;
import com.atsisa.gox.logic.DebugSpinRequest;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.IExtendedSymbolLogic;
import com.atsisa.gox.logic.IFreeGamesLogic;
import com.atsisa.gox.logic.IGamblerLogic;
import com.atsisa.gox.logic.ILogicInitializable;
import com.atsisa.gox.logic.IReelsLogic;
import com.atsisa.gox.logic.IScatterLogic;
import com.atsisa.gox.logic.ScatterRequest;
import com.atsisa.gox.logic.ScatterResult;
import com.atsisa.gox.logic.SpinRequest;
import com.atsisa.gox.logic.provider.IReelsDescriptorProvider;
import com.atsisa.gox.reels.AbstractReelGame;
import com.atsisa.gox.reels.backend.PresentationBuilder;
import com.atsisa.gox.reels.backend.step.ParseCalculateFreeGameResult;
import com.atsisa.gox.reels.backend.step.ParseSpinResult;
import com.atsisa.gox.reels.logic.IDebugReelGameLogic;
import com.atsisa.gox.reels.logic.request.DebugBetRequest;
import com.atsisa.gox.reels.logic.request.DebugGambleRequest;

import rx.Observable;

/**
 * Contains implementation of the debug reels logic for game
 */
public class TRexTrackDebugLogic extends TRexTrackLogic implements IDebugReelGameLogic {

    /**
     * The reel strip symbol type
     */
    private final static String reelStripSymbolsType = "BaseGame";

    /**
     * The {@link IReelsDescriptorProvider}
     */
    private final IReelsDescriptorProvider reelsDescriptorProvider;

    /**
     * The {@link IReelsLogic}
     */
    private final IReelsLogic reelsLogic;

    /**
     * The {@link IScatterLogic}
     */
    private final IScatterLogic scatterLogic;

    /**
     * The {@link IFreeGamesLogic}
     */
    private final IFreeGamesLogic freeGamesLogic;

    /**
     * Initializes a new instance of the {@link TRexTrackDebugLogic}
     * @param logicInitializables the set of {@link ILogicInitializable}
     * @param presentationFactory the presentation factory
     * @param reelsLogic          the {@link IReelsLogic}
     * @param scatterLogic        the {@link IScatterLogic}
     * @param gamblerLogic        the {@link IGamblerLogic}
     * @param descriptorProvider  the {@link IReelsDescriptorProvider}
     */
    @Inject
    public TRexTrackDebugLogic(Set<ILogicInitializable> logicInitializables, TRexTrackPresentationFactory presentationFactory, IReelsLogic reelsLogic,
                                    IScatterLogic scatterLogic, IGamblerLogic gamblerLogic, IReelsDescriptorProvider descriptorProvider, IFreeGamesLogic freeGamesLogic, IExtendedSymbolLogic extendedSymbolLogic) {
        super(logicInitializables, presentationFactory, reelsLogic, scatterLogic, gamblerLogic, freeGamesLogic, extendedSymbolLogic);
        this.reelsLogic = reelsLogic;
        this.reelsDescriptorProvider = descriptorProvider;
        this.scatterLogic = scatterLogic;
        this.freeGamesLogic = freeGamesLogic;
    }

    @Override
    public Observable<Object> debugBet(DebugBetRequest debugBetRequest) {
        int[] stopPositions = convertStopPosition(debugBetRequest.getStopPositions());
        DebugSpinRequest request = new DebugSpinRequest(debugBetRequest.getBetAmount(), debugBetRequest.getLinesAmount(), stopPositions);
        spinRequest = new SpinRequest(debugBetRequest.getBetAmount(), debugBetRequest.getLinesAmount());
        ScatterRequest scatterRequest;
        ScatterResult scatterResult;
        CalculateFreeGamesResult calculateFreeGamesResult;
        try {


            spinResult = reelsLogic.spin(request);
            List<Iterable<String>> stopListSymbols = ((AbstractReelGame) GameEngine.current().getGame()).getReelGameStateHolder().getStoppedSymbols();
            scatterRequest = new ScatterRequest(spinResult.getStopSymbols(), spinRequest.getBet());
            scatterResult = scatterLogic.calculate(scatterRequest);
            calculateFreeGamesResult = freeGamesLogic.calculate(new CalculateFreeGamesRequest(scatterResult.getWinningLines()));
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Spin error", e));
        }

        List<Object> presentations;
        try {
            presentations = new PresentationBuilder()
                    .execute(new ParseSpinResult(spinResult, new SpinRequest(debugBetRequest.getBetAmount(), debugBetRequest.getLinesAmount())))
                    .execute(new FixedParseScatterResult(scatterRequest, scatterResult))
                    .execute(new ParseCalculateFreeGameResult(calculateFreeGamesResult, 0))
                    .get();
           // GameEngine.current().getEventBus().post(new CalculateFreeGamesEvent(calculateFreeGamesResult));
        } catch (GameLogicException e) {
            return Observable.error(new com.atsisa.gox.reels.logic.GameLogicException(2, "GameLogic", "Spin error", e));
        }

        return this.createObservable(presentations);
    }

    @Override
    public Observable<Object> debugGamble(DebugGambleRequest debugGambleRequest) {
        return null;
    }

    /**
     * Converts stop positions.
     * @param iterable stop position to convert
     * @return converted stop position
     */
    private int[] convertStopPosition(Iterable<Integer> iterable) {
        int size = Iterables.size(iterable);
        int[] stopPositions = new int[size];
        Iterator<Integer> iterator = iterable.iterator();
        for (int i = 0; i < size; i++) {
            int reelLength = reelsDescriptorProvider.getReelsLength(reelStripSymbolsType)[i];
            int position = iterator.next();

            // presentation shifts stop position by one
            // subtraction will be removed after gox-reel refactoring
            stopPositions[i] = (position == 0) ? reelLength - 1 : position - 1;
        }
        return stopPositions;
    }
}
