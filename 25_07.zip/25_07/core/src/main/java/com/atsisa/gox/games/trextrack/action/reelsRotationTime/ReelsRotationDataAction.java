package com.atsisa.gox.games.trextrack.action.reelsRotationTime;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class ReelsRotationDataAction extends ActionData {

    public Integer getReel0() {
        return reel0;
    }

    public void setReel0(Integer reel0) {
        this.reel0 = reel0;
    }

    public Integer getReel1() {
        return reel1;
    }

    public void setReel1(Integer reel1) {
        this.reel1 = reel1;
    }

    public Integer getReel2() {
        return reel2;
    }

    public void setReel2(Integer reel2) {
        this.reel2 = reel2;
    }

    public Integer getReel3() {
        return reel3;
    }

    public void setReel3(Integer reel3) {
        this.reel3 = reel3;
    }

    public Integer getReel4() {
        return reel4;
    }

    public void setReel4(Integer reel4) {
        this.reel4 = reel4;
    }

    @XmlAttribute
    private Integer reel0;

    @XmlAttribute
    private Integer reel1;

    @XmlAttribute
    private Integer reel2;

    @XmlAttribute
    private Integer reel3;

    @XmlAttribute
    private Integer reel4;

}
