package com.atsisa.gox.games.trextrack.event;

/**
 * For sets track symbols visible after click "start spin"
 */
public class FixTrackSymbolsAfterWin {
}
