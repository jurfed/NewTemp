package com.atsisa.gox.games.trextrack.view;

import com.atsisa.gox.framework.view.AbstractViewModule;
//import com.atsisa.gox.games.trextrack.view.paytable.PayTableWinAnimationView;
import com.gwtent.reflection.client.annotations.Reflect_Mini;

/**
 * Represents the core view types which could be created declaratively using XML.
 */
@Reflect_Mini
public class TRexTrackCoreViewModule extends AbstractViewModule {

    /**
     * Core views module xml namespace.
     */
    public static final String XML_NAMESPACE = "http://www.atsisa.com/gox/tRexTrack/view";

    @Override
    public String getXmlNamespace() {
        return XML_NAMESPACE;
    }

    @Override
    protected void register() {
        registerView(LineSymbolWinAnimation.class);
//        registerView(PayTableWinAnimationView.class);
    }

}
