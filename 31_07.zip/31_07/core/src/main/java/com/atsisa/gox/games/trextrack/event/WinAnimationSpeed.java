package com.atsisa.gox.games.trextrack.event;

public class WinAnimationSpeed {

    private boolean fast = false;

    public WinAnimationSpeed(boolean fast) {
        this.fast = fast;
    }

    public boolean getFast() {
        return fast;
    }

    public void setFast(boolean fast) {
        this.fast = fast;
    }
}
