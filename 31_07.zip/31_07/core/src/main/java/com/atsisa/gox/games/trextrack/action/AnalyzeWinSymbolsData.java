package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class AnalyzeWinSymbolsData extends ActionData{

    @XmlAttribute
    private boolean reset = false;

    public boolean getReset() {
        return reset;
    }

    public void setReset(boolean reset) {
        this.reset = reset;
    }
}
