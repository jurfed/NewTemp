package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;

public class SetReelsSpeed extends Action {
    @Override
    protected void execute() {

    }
}
