/*
package com.atsisa.gox.games.trextrack.controllers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.eventbus.IEventBus;
import com.atsisa.gox.framework.eventbus.NextObserver;
import com.atsisa.gox.games.trextrack.event.PayTableAnimation;
import com.atsisa.gox.games.trextrack.screen.TRexTrackPayTableScreen;
import com.atsisa.gox.games.trextrack.view.paytable.PayTableWinAnimationView;
import com.atsisa.gox.logic.model.PayTable;

import javax.inject.Inject;
import java.util.ArrayList;

public final class PayTableWinAnimationController {
    private IEventBus eventBus;



    @Inject
    public PayTableWinAnimationController(IEventBus eventBus) {
        this.eventBus = eventBus;
        eventBus.register(new PayTableAnimationtObserver(), PayTableAnimation.class);
    }


    private class PayTableAnimationtObserver extends NextObserver<PayTableAnimation> {

        @Override
        public void onNext(PayTableAnimation payTableAnimation) {
            payTableAnimation.getSymbolsWinCounts().forEach((symbol, symbolCount) -> {
                if(symbol.toString().equals("Blue"))
                ((PayTableWinAnimationView)findViewById(symbol.toString())).playAnimation(new ArrayList(){{add(symbolCount);}});
            });
        }
    }
}
*/
