package com.atsisa.gox.games.trextrack.event.movie;

public class PlayStandbyMovie {
    private boolean play;

    public PlayStandbyMovie(boolean play) {
        this.play = play;
    }

    public boolean isPlay() {
        return play;
    }
}
