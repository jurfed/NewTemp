package com.atsisa.gox.games.trextrack.action;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.trextrack.event.CleanCollectionWithWinSymbols;
import com.atsisa.gox.games.trextrack.event.CreateCollectionWithWinSymbols;

import java.awt.*;

/**
 * Class for send command for analyze win lines
 */
public class StartAnalyzeWinSymbolsAction extends Action<AnalyzeWinSymbolsData> {
    @Override
    protected void execute() {
        if(this.actionData.getReset()){
            GameEngine.current().getEventBus().post(new CleanCollectionWithWinSymbols());
        }else{
            GameEngine.current().getEventBus().post(new CreateCollectionWithWinSymbols());
        }
        finish();
    }

    @Override
    public Class<AnalyzeWinSymbolsData> getActionDataType() {
        return AnalyzeWinSymbolsData.class;
    }
}
