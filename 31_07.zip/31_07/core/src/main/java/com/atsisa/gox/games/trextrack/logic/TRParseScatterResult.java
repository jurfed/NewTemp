package com.atsisa.gox.games.trextrack.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.atsisa.gox.framework.utility.StringUtility;
import com.atsisa.gox.logic.GameLogicException;
import com.atsisa.gox.logic.ScatterRequest;
import com.atsisa.gox.logic.ScatterResult;
import com.atsisa.gox.reels.IWinLineInfo;
import com.atsisa.gox.reels.backend.IStep;
import com.atsisa.gox.reels.backend.adapter.WinConverter;
import com.atsisa.gox.reels.logic.model.Reel;
import com.atsisa.gox.reels.logic.presentation.ReelGamePresentation;
import com.atsisa.gox.reels.logic.presentation.WinningPresentation;

/**
 * Converts scatter result into proper logic presentation
 */
public class TRParseScatterResult implements IStep {

    /**
     * The scatter presentation name
     */
    private static final String SCATTER_PRESENTATION_NAME = "SpecialScatter";

    /**
     * The {@link ScatterRequest}
     */
    private final ScatterRequest scatterRequest;

    /**
     * The {@link ScatterResult}
     */
    private final ScatterResult scatterResult;

    /**
     * The {@link WinConverter}
     */
    private final WinConverter winConverter = new WinConverter();

    /**
     * Initializes a new instance of the {@link TRParseScatterResult}
     * @param scatterRequest The {@link ScatterRequest}
     * @param scatterResult  The {@link ScatterResult}
     */
    public TRParseScatterResult(ScatterRequest scatterRequest, ScatterResult scatterResult) {
        this.scatterRequest = scatterRequest;
        this.scatterResult = scatterResult;
    }

    @Override
    public Map<String, Object> execute(Map<String, Object> logicPresentationMap) throws GameLogicException {

        Optional<Map<String, Object>> features = scatterResult.getFeatures();

        if (features.isPresent()) {
            if (features.get().containsKey(ScatterResult.STOP_SOUNDS)) {
                @SuppressWarnings("unchecked")
                Map<Integer, String> stopSounds = (Map) features.get().get(ScatterResult.STOP_SOUNDS);
                ReelGamePresentation reelGamePresentation = (ReelGamePresentation) logicPresentationMap.get(ReelGamePresentation.class.getName());

                logicPresentationMap.put(ReelGamePresentation.class.getName(), updateSounds(reelGamePresentation, stopSounds));
            }

            if (!scatterResult.getWinningLines().isEmpty()) {

                @SuppressWarnings("unchecked")
                Map<Integer, String> winLineSounds = (Map<Integer, String>) features.get().get(ScatterResult.WIN_SOUNDS);
                @SuppressWarnings("unchecked")
                Map<Integer, String> winAnimations = (Map<Integer, String>) features.get().get(ScatterResult.WIN_ANIMATION);

                long winAmount = scatterResult.getBank().getWinAmount();

                List<IWinLineInfo> scatterWinLineInfos = winConverter
                        .convertWinning(scatterResult.getWinningLines(), scatterRequest.getStopSymbols().size(), winLineSounds, winAnimations);
                List<IWinLineInfo> winLineInfos = new ArrayList<>();

                if (logicPresentationMap.containsKey(WinningPresentation.class.getName())) {
                    winAmount += ((WinningPresentation) logicPresentationMap.get(WinningPresentation.class.getName())).getWinAmount();
                    winLineInfos = ((WinningPresentation) logicPresentationMap.get(WinningPresentation.class.getName())).getWinningLines();
                }

                winLineInfos.addAll(scatterWinLineInfos);
                logicPresentationMap.put(WinningPresentation.class.getName(),
                        new WinningPresentation(scatterResult.getPresentation().getName(), winAmount, winLineInfos, StringUtility.EMPTY, false, false));

            }
        }

        return logicPresentationMap;
    }

    /**
     * Updates sounds for scatter win
     * @param reelGamePresentation The reel game presentation
     * @param stopSounds           The stop sounds
     * @return The updated reel game presentation
     */
    private ReelGamePresentation updateSounds(ReelGamePresentation reelGamePresentation, Map<Integer, String> stopSounds) {
        List<Reel> reelList = new ArrayList<>();

        int i = 0;
        for (Reel reel : reelGamePresentation.getReels()) {
            if (stopSounds.containsKey(i)) {
                reelList.add(new Reel(stopSounds.get(i), reel.getPositions()));
            } else {
                reelList.add(reel);
            }
            i++;
        }

        return new ReelGamePresentation(reelGamePresentation.getName(), reelGamePresentation.getGameplayProperties(), reelList,
                reelGamePresentation.isResumed(), reelGamePresentation.isHistory());
    }
}
