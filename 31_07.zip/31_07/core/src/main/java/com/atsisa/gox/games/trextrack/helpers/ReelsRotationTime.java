/*
package com.atsisa.gox.games.trextrack.helpers;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.utility.Timeout;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.framework.view.KeyframeAnimationView;
import com.atsisa.gox.games.octavian.core.event.ApplyReelsRotationTimeEvent;
import com.atsisa.gox.games.trextrack.screen.TRexTrackBaseGameScreen;
import com.atsisa.gox.reels.view.ReelGroupView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReelsRotationTime {
    private static Map<Integer, Integer> trackLongSpinTimeStart;
    private static Timeout[] trackLongSpinTimeout;
    private ReelGroupView reelGroupView;


    public static void setTrackLongSpinTimeout(Timeout[] trackLongSpinTimeout) {
        ReelsRotationTime.trackLongSpinTimeout = trackLongSpinTimeout;
    }

    public void setReelGroupView(ReelGroupView reelGroupView) {
        this.reelGroupView = reelGroupView;
    }

    */
/**
     * Set time spin increase reels if in the reels 4 track symbols
     *
     * @param featureCounts
     *//*

    private void setRotation(int[] featureCounts) {
        List<Integer> spinTime = new ArrayList<>();
        spinTime.add(400);
        spinTime.add(700);
        trackLongSpinTimeStart = new HashMap<>();
        if (featureCounts[0] == 4 && featureCounts[1] == 4) {
            spinTime.add(3700);
            trackLongSpinTimeStart.put(3, 700);
            if (featureCounts[2] == 4) {
                trackLongSpinTimeStart.put(4, 3700);
                spinTime.add(6700);
                if (featureCounts[3] == 4) {
                    spinTime.add(9700);
                    trackLongSpinTimeStart.put(5, 6700);
                } else {
                    spinTime.add(7000);
                }
            } else {
                spinTime.add(4000);
                spinTime.add(4300);
            }
        } else {
            spinTime.add(1000);
            spinTime.add(1300);
            spinTime.add(1600);
        }
        GameEngine.current().getEventBus().post(new ApplyReelsRotationTimeEvent(spinTime));

        for (int trackLongKey : trackLongSpinTimeStart.keySet()) {
            KeyframeAnimationView keyframeAnimationView = (KeyframeAnimationView) GameEngine.current().getViewManager().findViewById("trackSpin" + trackLongKey);

            trackLongSpinTimeout[trackLongKey - 3] = new Timeout(trackLongSpinTimeStart.get(trackLongKey), new TrackLongSpinCallback(keyframeAnimationView, "tracksLongSound" + trackLongKey, true, trackLongKey), true);
            new Timeout(trackLongSpinTimeStart.get(trackLongKey) + 3000, new TrackLongSpinCallback(keyframeAnimationView, "tracksLongSound" + trackLongKey, false, trackLongKey), true);

        }

    }

    */
/**
     * for play track long animation and sound
     *//*

    class TrackLongSpinCallback implements TimeoutCallback {
        KeyframeAnimationView keyframeAnimationView;
        String sound;
        Boolean play;
        int reelNumber;


        public TrackLongSpinCallback(KeyframeAnimationView keyframeAnimationView, String sound, boolean play, int reelNumber) {
            this.keyframeAnimationView = keyframeAnimationView;
            this.play = play;
            this.sound = sound;
            this.reelNumber = reelNumber;
        }

        @Override
        public void onTimeout() {
            if (play && reelGroupView.getReel(reelNumber - 1).getReelState().name().equals(REEL_STATE_SPINNING)) {
                keyframeAnimationView.play();
                keyframeAnimationView.setVisible(true);
                GameEngine.current().getSoundManager().play(sound);

            } else {
                keyframeAnimationView.stop();
                keyframeAnimationView.setVisible(false);
                GameEngine.current().getSoundManager().stop(sound);
            }

        }
    }

}
*/
