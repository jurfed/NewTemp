package com.atsisa.gox.games.trextrack.action.movie;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.action.IActionManager;
import com.atsisa.gox.framework.utility.TimeoutCallback;
import com.atsisa.gox.games.trextrack.action.movie.actionData.VisibleAndPlayMovieActionData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * After the time elapses, it starts playing the video queue
 */
public class TimeOutLogoMoviePlay implements TimeoutCallback {

    /**
     * Counter of creating this class
     */
    private static int maxid;

    /**
     * The number of this instance of the class
     */
    private int currentid;

    /**
     * Maps with video numbers and IDs
     */
    private HashMap<Integer, String> layoutIdHashMap;
    private HashMap<Integer, String> videoIdHashMap;

    public TimeOutLogoMoviePlay(HashMap<Integer, String> layoutIdHashMap, HashMap<Integer, String> videoIdHashMap) {
        this.layoutIdHashMap = layoutIdHashMap;
        this.videoIdHashMap = videoIdHashMap;
        currentid = ++maxid;
    }


    /**
     * Start the splash screen movie
     */
    @Override
    public void onTimeout() {
        if (currentid == maxid) {//If this instance of the class is the last one, then run the playback of the videos queue

            IActionManager manager = GameEngine.current().getActionManager();
            List<Action> actionList = new ArrayList<Action>();
            VisibleAndPlayMovieActionData visibleAndPlayMovieActionData = new VisibleAndPlayMovieActionData();

            visibleAndPlayMovieActionData.setVideoLayoutId(layoutIdHashMap);
            visibleAndPlayMovieActionData.setVideoId(videoIdHashMap);

            SetVisibleAndPlayMovie setVisibleAndPlayMovie = new SetVisibleAndPlayMovie();
            setVisibleAndPlayMovie.setActionData(visibleAndPlayMovieActionData);

            actionList.add(setVisibleAndPlayMovie);

            //Start the splash screen movie only if the action queues is empty
            if (manager.getActionQueues().size() == 0) {
                manager.processQueue(actionList);
            }
        }
    }

}