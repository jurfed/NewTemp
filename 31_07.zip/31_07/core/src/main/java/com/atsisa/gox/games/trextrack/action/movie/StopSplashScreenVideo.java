package com.atsisa.gox.games.trextrack.action.movie;


import com.atsisa.gox.framework.action.Action;

public class StopSplashScreenVideo extends Action {
    @Override
    protected void execute() {

        finish();
    }
}
