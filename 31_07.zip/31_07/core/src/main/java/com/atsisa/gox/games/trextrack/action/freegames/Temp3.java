package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.reels.AbstractReelGame;

public class Temp3 extends Action {
    @Override
    protected void execute() {
        System.out.println();
        finish();
    }
}
