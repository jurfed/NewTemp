package com.atsisa.gox.games.trextrack.action.track;

import com.atsisa.gox.framework.action.ActionData;
import com.atsisa.gox.framework.serialization.annotation.XmlAttribute;
import com.atsisa.gox.framework.serialization.annotation.XmlElement;
import com.gwtent.reflection.client.annotations.Reflect_Full;

@Reflect_Full
@XmlElement
public class TrackTakeWinFixData extends ActionData {
    @XmlAttribute
    private boolean removeIDLE;


    public boolean getRemoveIDLE() {
        return removeIDLE;
    }

    public void setRemoveIDLE(boolean removeIDLE) {
        this.removeIDLE = removeIDLE;
    }
}
