package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.games.octavian.core.event.WinCountStopEvent;

public class Temp2 extends Action {
    @Override
    protected void execute() {
        GameEngine.current().getEventBus().post(new WinCountStopEvent(0L));
        finish();
    }
}
