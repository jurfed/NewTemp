package com.atsisa.gox.games.trextrack.screen.model;

import com.atsisa.gox.framework.screen.model.ScreenModel;
import com.atsisa.gox.framework.utility.localization.ITranslator;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseGameScreenModel extends ScreenModel {

    /**
     * Map for save win symbols positions and their names
     * 11|21|31|41|51
     * 12|22|32|42|52
     * 13|23|33|43|53
     * 14|24|34|44|54
     *
     * 13 - > Green
     * 23 - > Green
     * ...
     * 11 - > Blue
     * ...
     */
    static Map<String, String> winSymbols = new HashMap<>();

    @Inject
    public BaseGameScreenModel(ITranslator translator) {
        super(translator);
    }

    public void addToSymbolsMap(String position, String name) {
        winSymbols.put(position, name);
    }

    public void clearSymbolsMap() {
        winSymbols.clear();
    }

    public static Map getSymbolsMap() {
        return winSymbols;
    }


    private static Map<Integer, Iterable<String>> stopReelsSymbols = new HashMap();

    /**
     * @return all stopping symbols on the reels
     */
    public static Map<Integer, Iterable<String>> getStopReelsSymbols() {
        return stopReelsSymbols;
    }

    public void setStopReelsSymbols(Map<Integer, Iterable<String>> stopReelsSymbols) {
        this.stopReelsSymbols = stopReelsSymbols;
    }

    private static Map<String, String> trackAnimation = new HashMap<>();//track position and track type
    private static int[] counts = new int[5];//tracks count

    public static Map<String, String> getTrackAnimation2() {
        return trackAnimation;
    }

    public static void setTrackAnimation2(Map<String, String> trackAnimation2) {
        trackAnimation = trackAnimation2;
    }

    public int[] getCounts() {
        return counts;
    }

    public void setCounts(int[] counts) {
        this.counts = counts;
    }

    /**
     * for random symbols show under the tracks symbols
     */
    private final static Map<Integer, String> imageViews = new HashMap() {{
//        put(1, "violetSymbolD");

        put(1, "violetSymbol");
        put(2, "blueSymbol");
        put(3, "greenSymbol");
        put(4, "yellowSymbol");
        put(5, "pinkSymbol");
        put(6, "baseSymbolA");
        put(7, "baseSymbolK");
        put(8, "baseSymbolQ");
        put(9, "baseSymbolJ");
        put(10, "baseSymbol");//10
        put(11, "greenSymbolD");
        put(12, "yellowSymbolD");
        put(13, "pinkSymbolD");
        put(14, "blueSymbolD");
        put(15, "violetSymbolD");
    }};

    /**
     * for random animation show under the tracks symbols
     */
    private final static Map<Integer, String> keyFrameViews = new HashMap() {{
//        put(1, "symbol5WinAnimation2");

        put(1, "symbol5WinAnimation");
        put(2, "symbol4WinAnimation");
        put(3, "symbol1WinAnimation");
        put(4, "symbol2WinAnimation");
        put(5, "symbol3WinAnimation");
        put(6, "symbolAWinAnimation");
        put(7, "symbolKWinAnimation");
        put(8, "symbolQWinAnimation");
        put(9, "symbolJWinAnimation");
        put(10, "symbol10WinAnimation");
        put(11, "symbol1WinAnimation2");
        put(12, "symbol2WinAnimation2");
        put(13, "symbol3WinAnimation2");
        put(14, "symbol4WinAnimation2");
        put(15, "symbol5WinAnimation2");
    }};

    private final static Map<Integer, String> symbolsForCountWinTxt = new HashMap() {{
//        put(1, "Violet2");

        put(1, "Violet");
        put(2, "Blue");
        put(3, "Green");
        put(4, "Yellow");
        put(5, "Pink");
        put(6, "SymbolA");
        put(7, "SymbolK");
        put(8, "SymbolQ");
        put(9, "SymbolJ");
        put(10, "Symbol10");
        put(11, "Green2");
        put(12, "Yellow2");
        put(13, "Pink2");
        put(14, "Blue2");
        put(15, "Violet2");
    }};

    private final static List<String> dinoSymbols = new ArrayList() {{
        add("Violet");
        add("Blue");
        add("Green");
        add("Yellow");
        add("Pink");
        add("Green2");
        add("Yellow2");
        add("Pink2");
        add("Blue2");
        add("Violet2");
    }};

    public static List<String> getDinoSymbols() {
        return dinoSymbols;
    }

    public static Map<Integer, String> getSymbolsForCountWinTxt() {
        return symbolsForCountWinTxt;
    }

    public static Map<Integer, String> getImageViews() {
        return imageViews;
    }

    public static Map<Integer, String> getKeyFrameViews() {
        return keyFrameViews;
    }

}
