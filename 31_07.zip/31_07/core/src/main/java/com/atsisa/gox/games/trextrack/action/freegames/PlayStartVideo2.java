package com.atsisa.gox.games.trextrack.action.freegames;

import com.atsisa.gox.framework.GameEngine;
import com.atsisa.gox.framework.action.Action;
import com.atsisa.gox.framework.view.IViewPropertyChangedListener;
import com.atsisa.gox.framework.view.MovieView;
import com.atsisa.gox.framework.view.View;
import com.atsisa.gox.framework.view.ViewType;
import com.atsisa.gox.games.trextrack.screen.basegamescreen.TRexTrackBaseGameScreen;

public class PlayStartVideo2 extends Action<PlayVideoData> {
    MovieView freeEnd;
    EndVideoListener endVideoListener;
    boolean finish = false;

    @Override
    protected void execute() {
        finish = false;
        freeEnd = (MovieView) GameEngine.current().getViewManager().findViewById("baseGameScreen", "freeEnd");

        if (endVideoListener == null) {
            endVideoListener = new EndVideoListener();
        }

        freeEnd.setVisible(true);
        freeEnd.play();

        GameEngine.current().getViewManager().findViewById("baseGameScreen", "you_won").setVisible(false);
        GameEngine.current().getViewManager().findViewById("baseGameScreen", "you_won_numbers").setVisible(false);
        GameEngine.current().getViewManager().findViewById("baseGameScreen", "langYouWonExtra").setVisible(false);

        GameEngine.current().getViewManager().findViewById("baseGameScreen", "langWonPlayed").setVisible(false);
        GameEngine.current().getViewManager().findViewById("baseGameScreen", "played").setVisible(false);
        TRexTrackBaseGameScreen.setStartFreeGamesTextFlash(false);
        try {
            freeEnd.removePropertyChangedListener(endVideoListener);
        } catch (Exception e) {

        }
        freeEnd.addPropertyChangedListener(endVideoListener);

    }


    class EndVideoListener implements IViewPropertyChangedListener {

        @Override
        public void propertyChanged(View view, ViewType viewType, int property) {
            if (!((MovieView) view).isPlaying()) {
                freeEnd.stop();
                freeEnd.setVisible(false);
                if (!finish) {
                    finish = true;
                    try {
                        freeEnd.removePropertyChangedListener(endVideoListener);
                    } catch (Exception e) {

                    }
                    finish();
                }
            }
        }
    }

    @Override
    public Class<PlayVideoData> getActionDataType() {
        return PlayVideoData.class;
    }
}
