import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("DATA")
        // maps DATA element in XML to this class
class Data {

    @XStreamImplicit(itemFieldName = "BAN")
    private List bans = new ArrayList();

    public List getBans() {
        return bans;
    }
}

@XStreamAlias("BAN")
        // another mapping
class Ban {

    /*
     We want to have different field names in Java classes so
     we define what element should be mapped to each field
    */
    @XStreamAlias("UPDATED_AT") //
    private String dateOfUpdate;

    @XStreamAlias("TROUBLEMAKER")
    private Person person;

    public String toString() {
        return dateOfUpdate + person.getFirstName();
    }
}

@XStreamAlias("TROUBLEMAKER")
class Person {

    @XStreamAlias("NAME1")
    private String firstName;

    @XStreamAlias("NAME2")
    private String lastName;

    @XStreamAlias("AGE") // String will be auto converted to int value
    private int age;

    @XStreamAlias("NUMBER")
    private String documentNumber;

    String getFirstName(){
        return firstName;
    }
}

public class Temp {
    public static void main(String[] args) throws FileNotFoundException {
        FileReader reader = new FileReader("C:\\work\\tmp12\\projectXML\\src\\main\\java\\file.xml");  // load file

        XStream xstream = new XStream();
        xstream.processAnnotations(Data.class);     // inform XStream to parse annotations in Data class
        xstream.processAnnotations(Ban.class);      // and in two other classes...
        xstream.processAnnotations(Person.class);   // we use for mappings
        Data data = (Data) xstream.fromXML(reader); // parse

// Print some data to console to see if results are correct
        System.out.println("Number of bans = " + data.getBans().size());
        Ban firstBan = (Ban) data.getBans().get(0);
        System.out.println("First ban = " + firstBan.toString());
    }
}
